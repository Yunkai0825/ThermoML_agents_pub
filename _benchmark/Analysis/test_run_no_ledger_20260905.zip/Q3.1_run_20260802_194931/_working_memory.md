# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q3.1_run_20260802_194931`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_1 | water |  |
| comp | GLOBcomp_47 | n-methylpyrrolidone |  |

### History
- [query_thermoml]
- [query_thermoml_parallel]
- [run_query_agents_parallel]

### Query Results
#### query
Three data blocks of dynamic viscosity (GLOBprop_4) for the binary system water (GLOBcomp_1) + N-methyl-2-pyrrolidone (GLOBcomp_47) were identified near 298.15 K at approximately atmospheric pressure. Block 1 (DOI 10.1021/je034073k, PROPblock_3, GLOBlit_8238) has 65 points with 6 at 298.15 K spanning x(NMP) 0–1. Block 2 (DOI 10.1021/je0340809, PROPblock_17, GLOBlit_8242) has 95 points with 10 at 298.15 K over x(water) 0.0522–0.8536. Block 3 (DOI 10.1021/je100967k, PROPblock_17, GLOBlit_9372) has 44 points at 293.15 and 303.15 K bracketing 298 K. No kinematic viscosity (GLOBprop_40) data were found. The system exhibits a pronounced viscosity maximum near x(NMP) ≈ 0.3 attributed to strong hydrogen-bonding interactions. Representative values at 298.15 K from GLOBlit_8238 include η = 0.00089 Pa·s at x(NMP) = 0 and η = 0.004555 Pa·s at x(NMP) = 0.2004.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_8238 | 10.1021/je034073k | PROPblock_3 | declared | 65 | binary | binary |
| GLOBlit_8242 | 10.1021/je0340809 | PROPblock_17 | declared | 95 | binary | binary |
| GLOBlit_9372 | 10.1021/je100967k | PROPblock_17 | declared | 44 | binary | binary |

#### 2pyrrolidone_water — ERROR
no active StatsRecorder; start agent tracking first

#### DMF_water — ERROR
no active StatsRecorder; start agent tracking first

#### DMAc_water — ERROR
no active StatsRecorder; start agent tracking first

#### DMSO_water — ERROR
no active StatsRecorder; start agent tracking first

#### GBL_water — ERROR
no active StatsRecorder; start agent tracking first

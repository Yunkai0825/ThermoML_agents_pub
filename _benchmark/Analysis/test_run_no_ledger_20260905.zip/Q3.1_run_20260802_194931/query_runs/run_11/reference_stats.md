# Reference Stats — query-agent

**Run started:** 2026-08-02 19:58:14
**Wall time (at last flush):** 298.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 19,525 | 5,938 | 41,712 | 8,342 | 35.3 | claudeopus46 |
| L1-worker | 21 | 204,469 | 118,634 | 21,144 | 323,103 | 15,385 | 162.3 | claudeopus46 |
| **TOTAL** | **26** | **226,656** | **138,159** | **27,082** | **364,815** | **14,031** | **197.6** | |

**Estimated tokens:** ~91,203 input + ~6,770 output = ~97,973 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 27 | 1 | 6 | 2 | 19 | 50 | 1,102 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **33** | **1** | **6** | **2** | **19** | **50** | **1,102** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (32 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2086 |  | resolve_compound_ids |
| GLOBcomp_342 |  | resolve_compound_ids |
| GLOBcomp_63 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_5038 |  | resolve_compound_ids |
| GLOBcomp_5696 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids |
| GLOBcomp_5047 | [bis(salicylidene)ethylenediaminato]oxovanadium | search_blocks |
| GLOBcomp_491 | 1-methyl-3-propylimidazolium bromide | search_blocks |
| GLOBcomp_264 | 1,2-dichlorobenzene | search_blocks |
| GLOBcomp_419 | 1,3-dichlorobenzene | search_blocks |
| GLOBcomp_728 | 1,2,4-trichlorobenzene | search_blocks |
| GLOBcomp_408 | 2-chlorotoluene | search_blocks |
| GLOBcomp_664 | 3-chlorotoluene | search_blocks |
| GLOBcomp_473 | 4-chlorotoluene | search_blocks |
| GLOBcomp_616 | 2-nitrotoluene | search_blocks |
| GLOBcomp_807 | 3-nitrotoluene | search_blocks |
| GLOBcomp_2160 | tetrabutylphosphonium tetrafluoroborate | search_blocks |
| GLOBcomp_376 | methyl methacrylate | search_blocks |
| GLOBcomp_1710 | 2,2'-[1,2-phenylenebis(nitrilomethylidyne)]bis-phenol | search_blocks |
| GLOBcomp_158 | 1-butyl-3-methylimidazolium bromide | search_blocks |
| GLOBcomp_1399 | N,N'-bis(2-pyridinylmethylene)-1,2-ethanediamine | search_blocks |
| GLOBcomp_185 | 1-hexyl-3-methylimidazolium chloride | search_blocks |
| GLOBcomp_6 | propan-2-ol | search_blocks |
| GLOBcomp_20 | butan-2-ol | search_blocks |
| GLOBcomp_84 | 1-ethyl-3-methylimidazolium tetrafluoroborate | search_blocks |
| GLOBcomp_4 | methanol | search_blocks |
| GLOBcomp_2 | ethanol | search_blocks |
| GLOBcomp_273 | 1-methyl-3-octylimidazolium chloride | search_blocks |
| GLOBcomp_25 | 1,4-dioxane | search_blocks |
| GLOBcomp_188 | 2-methylbutan-2-ol | search_blocks |
| GLOBcomp_10 | ethyl acetate | search_blocks |
| GLOBcomp_34 | octan-1-ol | search_blocks |

#### References (19 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1030 |  | search_blocks |
| GLOBlit_1246 |  | search_blocks |
| GLOBlit_1676 |  | search_blocks |
| GLOBlit_3721 |  | search_blocks |
| GLOBlit_3813 |  | search_blocks |
| GLOBlit_3879 |  | search_blocks |
| GLOBlit_4251 |  | search_blocks |
| GLOBlit_5069 |  | search_blocks |
| GLOBlit_6204 |  | search_blocks |
| GLOBlit_6379 |  | search_blocks |
| GLOBlit_6710 |  | search_blocks |
| GLOBlit_6791 |  | search_blocks |
| GLOBlit_6959 |  | search_blocks |
| GLOBlit_7089 |  | search_blocks |
| GLOBlit_8387 |  | search_blocks |
| GLOBlit_8407 |  | search_blocks |
| GLOBlit_8831 |  | search_blocks |
| GLOBlit_9141 |  | search_blocks |
| GLOBlit_10315 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_6 | Solvent: Molality, mol/kg | search_blocks |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |

#### Solvents (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_21 |  | search_blocks |
| GLOBsolvent_537 |  | search_blocks |
| GLOBsolvent_57 |  | search_blocks |
| GLOBsolvent_96 |  | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 32 |
| Unique References | 19 |
| Unique Properties | 1 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Variables | 6 |
| Unique Solvents | 4 |
| Unique Constraints | 2 |
| Total DOIs | 19 |
| Unique parent blocks | 50 |
| Explicit block/subsystem targets | 50 |
| Subsystem targets | 0 |
| Target-matched data points | 1,102 |

---

## 3. DOI & Block References

**Unique DOIs:** 19  |  **Parent blocks:** 50  |  **Explicit targets:** 50  |  **Subsystems:** 0  |  **Target-matched datapoints:** 1,102

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2011.10.026 | 4 | 48 | binary, ternary, unary | search_blocks |
| 10.1016/j.fluid.2013.05.001 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2015.03.048 | 9 | 121 | binary, unary | search_blocks |
| 10.1016/j.jct.2012.09.003 | 2 | 7 | binary, unary | search_blocks |
| 10.1016/j.jct.2013.01.013 | 2 | 112 | binary, unary | search_blocks |
| 10.1016/j.jct.2013.04.022 | 3 | 46 | binary, ternary, unary | search_blocks |
| 10.1016/j.jct.2014.09.022 | 4 | 70 | binary, ternary, unary | search_blocks |
| 10.1016/j.jct.2017.07.016 | 2 | 110 | binary, unary | search_blocks |
| 10.1016/j.tca.2014.11.010 | 1 | 1 | unary | search_blocks |
| 10.1016/j.tca.2017.06.023 | 2 | 78 | binary | search_blocks |
| 10.1021/acs.jced.5b00753 | 2 | 48 | binary, unary | search_blocks |
| 10.1021/acs.jced.5b01000 | 3 | 81 | binary, unary | search_blocks |
| 10.1021/acs.jced.6b00575 | 1 | 13 | unary | search_blocks |
| 10.1021/acs.jced.7b00002 | 2 | 110 | binary, unary | search_blocks |
| 10.1021/je049609w | 2 | 36 | binary, unary | search_blocks |
| 10.1021/je049657g | 1 | 1 | unary | search_blocks |
| 10.1021/je050538q | 4 | 82 | binary, ternary, unary | search_blocks |
| 10.1021/je100170v | 2 | 36 | binary, unary | search_blocks |
| 10.1021/je400917j | 3 | 101 | binary, unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2011.10.026 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2011.10.026 | PROPblock_4 | declared | 36 | ternary | — | search_blocks |
| 10.1016/j.fluid.2011.10.026 | PROPblock_7 | declared | 8 | binary | — | search_blocks |
| 10.1016/j.fluid.2011.10.026 | PROPblock_9 | declared | 3 | binary | — | search_blocks |
| 10.1016/j.fluid.2013.05.001 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_22 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_26 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_30 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_34 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_38 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_42 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_46 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.03.048 | PROPblock_50 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2012.09.003 | PROPblock_14 | declared | 6 | binary | — | search_blocks |
| 10.1016/j.jct.2012.09.003 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.01.013 | PROPblock_15 | declared | 105 | binary | — | search_blocks |
| 10.1016/j.jct.2013.01.013 | PROPblock_9 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2013.04.022 | PROPblock_12 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2013.04.022 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.04.022 | PROPblock_8 | declared | 36 | ternary | — | search_blocks |
| 10.1016/j.jct.2014.09.022 | PROPblock_11 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2014.09.022 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2014.09.022 | PROPblock_5 | declared | 55 | ternary | — | search_blocks |
| 10.1016/j.jct.2014.09.022 | PROPblock_8 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2017.07.016 | PROPblock_12 | declared | 99 | binary | — | search_blocks |
| 10.1016/j.jct.2017.07.016 | PROPblock_4 | declared | 11 | unary | — | search_blocks |
| 10.1016/j.tca.2014.11.010 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.tca.2017.06.023 | PROPblock_12 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.tca.2017.06.023 | PROPblock_16 | declared | 39 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00753 | PROPblock_10 | declared | 44 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00753 | PROPblock_4 | declared | 4 | unary | — | search_blocks |
| 10.1021/acs.jced.5b01000 | PROPblock_16 | declared | 39 | binary | — | search_blocks |
| 10.1021/acs.jced.5b01000 | PROPblock_20 | declared | 39 | binary | — | search_blocks |
| 10.1021/acs.jced.5b01000 | PROPblock_4 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00575 | PROPblock_13 | declared | 13 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00002 | PROPblock_12 | declared | 99 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00002 | PROPblock_4 | declared | 11 | unary | — | search_blocks |
| 10.1021/je049609w | PROPblock_26 | declared | 3 | unary | — | search_blocks |
| 10.1021/je049609w | PROPblock_54 | declared | 33 | binary | — | search_blocks |
| 10.1021/je049657g | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/je050538q | PROPblock_11 | declared | 21 | binary | — | search_blocks |
| 10.1021/je050538q | PROPblock_14 | declared | 16 | binary | — | search_blocks |
| 10.1021/je050538q | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1021/je050538q | PROPblock_20 | declared | 44 | ternary | — | search_blocks |
| 10.1021/je100170v | PROPblock_17 | declared | 33 | binary | — | search_blocks |
| 10.1021/je100170v | PROPblock_4 | declared | 3 | unary | — | search_blocks |
| 10.1021/je400917j | PROPblock_14 | declared | 48 | binary | — | search_blocks |
| 10.1021/je400917j | PROPblock_16 | declared | 48 | binary | — | search_blocks |
| 10.1021/je400917j | PROPblock_2 | declared | 5 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMAc and wa… | 838 | KEEP | 838 | 13.4 |
| 2 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve water to GL… | 257 | KEEP | 257 | 4.7 |
| 3 | 3 | `search_blocks` | compound=['GLOBcomp_63', 'GLOBcomp_1'], limit=50, … | 911 | DISCARD | 853 | 8.4 |
| 4 | 4 | `search_blocks` | compound=['GLOBcomp_63', 'GLOBcomp_1'], limit=50, … | 635 | DISCARD | 577 | 15.1 |
| 5 | 5 | `search_blocks` | compound=['GLOBcomp_63', 'GLOBcomp_1'], limit=50, … | 833 | DISCARD | 775 | 9.5 |
| 6 | 5 | `search_blocks` | compound=GLOBcomp_63, limit=50, property=GLOBprop_… | 1,256 | KEEP | 1103 | 14.4 |
| 7 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_63 AS dmac…, explanat… | 738 | DISCARD | 677 | 110.6 |
| 8 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 3,234 | — | — | 268.8 |
| | | **TOTAL (8 tools)** | | **8,702** | | **5,080** | **444.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,191 | 4,191 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,017 | 10,622 | 1,379 | 7.8 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,260 | 21,903 | 730 | 6.2 |
| 3 | L1-worker | claudeopus46 | 2,065 | 807 | 2,872 | 1,733 | 12.7 |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,594 | 23,237 | 482 | 4.7 |
| 5 | L1-worker | claudeopus46 | 2,065 | 365 | 2,430 | 480 | 4.2 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,287 | 23,930 | 970 | 6.9 |
| 7 | L1-worker | claudeopus46 | 2,065 | 592 | 2,657 | 1,259 | 8.0 |
| 8 | L1-worker | claudeopus46 | 20,610 | 5,486 | 26,096 | 655 | 4.6 |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,733 | 25,376 | 734 | 6.8 |
| 10 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 1,297 | 8.3 |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,887 | 26,530 | 1,312 | 8.6 |
| 12 | L1-worker | claudeopus46 | 2,065 | 505 | 2,570 | 1,328 | 8.7 |
| 13 | L1-worker | claudeopus46 | 2,065 | 31,534 | 33,599 | 1,509 | 13.2 |
| 14 | L1-worker | claudeopus46 | 20,643 | 8,621 | 29,264 | 1,956 | 13.6 |
| 15 | L1-worker | claudeopus46 | 20,643 | 9,533 | 30,176 | 945 | 10.0 |
| 16 | L1-worker | claudeopus46 | 2,065 | 1,018 | 3,083 | 1,112 | 8.2 |
| 17 | L1-worker | claudeopus46 | 20,643 | 10,518 | 31,161 | 2,421 | 19.1 |
| 18 | L1-worker | claudeopus46 | 1,323 | 12,713 | 14,036 | 308 | 3.2 |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,599 | 2,955 | 535 | 3.5 |
| 20 | L1-worker | claudeopus46 | 536 | 1,479 | 2,015 | 652 | 4.1 |
| 21 | L1-worker | claudeopus46 | 298 | 1,030 | 1,328 | 202 | 2.5 |
| 22 | L1-worker | claudeopus46 | 747 | 14,597 | 15,344 | 524 | 5.2 |
| 23 | L0-main | claudeopus46 | 9,605 | 8,270 | 17,875 | 1,910 | 11.5 |
| 24 | L0-main | claudeopus46 | 1,356 | 1,638 | 2,994 | 678 | 6.2 |
| 25 | L0-main | claudeopus46 | 1,323 | 6,856 | 8,179 | 1,076 | 6.2 |
| 26 | L0-main | claudeopus46 | 298 | 1,744 | 2,042 | 895 | 3.6 |


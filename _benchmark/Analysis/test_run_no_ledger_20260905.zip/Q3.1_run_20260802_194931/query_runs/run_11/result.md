# Delegated query run — result

**Question:** Find all data blocks containing dynamic viscosity (GLOBprop_4) measurements for the binary system of N,N-dimethylacetamide (DMAc) and water near 298.15 K at atmospheric pressure. Report DOIs, block IDs, literature IDs, number of data points, temperature range, and composition range.

**Iterations:** 2  |  **Elapsed:** 288.2s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

**No dynamic viscosity data found for the DMAc + water binary system in the ThermoML database.**

A thorough search was conducted for dynamic viscosity (η) measurements of the binary mixture of N,N-dimethylacetamide (DMAc, C₄H₉NO) + water (H₂O). Multiple search strategies were employed — including searches by both compounds jointly, with and without binary system-type filters, and advanced block searches — all returning zero results for this binary mixture.

### What is available for DMAc viscosity:

- **Pure DMAc viscosity near 298.15 K** is well-represented in the database, with values of approximately **η ≈ 0.000920–0.000989 Pa·s** at 298.15 K, reported across several literature sources:
  - GLOBlit_1030 (DOI: 10.1016/j.fluid.2011.10.026)
  - GLOBlit_3721 (DOI: 10.1016/j.jct.2012.09.003)
  - GLOBlit_4251 (DOI: 10.1016/j.jct.2014.09.022)

- **DMAc in non-aqueous binary mixtures**: ~50 data blocks across ~18 DOIs exist for DMAc viscosity, but these all involve DMAc paired with other organic solvents — not water.

### Implications for the NMP + water surrogate search:

Since composition-dependent viscosity data for DMAc + water is absent from the ThermoML database, DMAc cannot serve as a data-backed surrogate for NMP + water viscosity behavior using this database alone. If you are interested, I can search for other aqueous aprotic solvent systems (e.g., DMSO + water, DMF + water, or acetone + water) that may have viscosity data available as alternative surrogates.

### Core claims

- No dynamic viscosity data for the DMAc + water binary mixture were found in the ThermoML database despite multiple search strategies.
- Pure DMAc dynamic viscosity near 298.15 K is available in the database, with reported values of approximately 0.000920–0.000989 Pa·s across several literature sources.
- DMAc viscosity data in the database exist only for non-aqueous binary mixtures (~50 data blocks across ~18 DOIs), none involving water as the second component.
- Because composition-dependent DMAc + water viscosity data are absent from ThermoML, DMAc cannot serve as a data-backed surrogate for NMP + water viscosity behavior using this database alone.

**Confidence:** high

### Suggested follow-ups

- Search for dynamic viscosity of DMSO + water (dimethyl sulfoxide + water) as an alternative aqueous aprotic solvent surrogate for NMP + water.
- Search for dynamic viscosity of DMF + water (N,N-dimethylformamide + water) as another potential surrogate system.
- Search for dynamic viscosity of NMP + water directly in the ThermoML database to check availability of the target system itself.
- Search external literature databases for DMAc + water viscosity data, as this binary system may be documented outside ThermoML.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_63",
    "registry_id": "n,n-dimethylethanamide",
    "name": "N,N-dimethylethanamide"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  }
]
```

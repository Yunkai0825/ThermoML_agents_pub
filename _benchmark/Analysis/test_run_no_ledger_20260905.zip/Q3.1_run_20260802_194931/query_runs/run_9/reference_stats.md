# Reference Stats — query-agent

**Run started:** 2026-08-02 19:58:14
**Wall time (at last flush):** 268.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 99,645 | 16,952 | 141,340 | 17,667 | 95.7 | claudeopus46 |
| L1-worker | 27 | 184,830 | 93,810 | 34,230 | 278,640 | 10,320 | 209.8 | claudeopus46 |
| **TOTAL** | **35** | **226,525** | **193,455** | **51,182** | **419,980** | **11,999** | **305.5** | |

**Estimated tokens:** ~104,995 input + ~12,795 output = ~117,790 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 1 | 3 | 3 | 171 |
| **TOTAL** | **6** | **1** | **3** | **1** | **3** | **3** | **171** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_31 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2781 |  | search_blocks |
| GLOBlit_5953 |  | search_blocks |
| GLOBlit_11517 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 3 |
| Unique Properties | 1 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 1 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 171 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 171

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.12.012 | 1 | 120 | binary | search_blocks |
| 10.1016/j.tca.2011.08.013 | 1 | 16 | binary | search_blocks |
| 10.1021/je9001027 | 1 | 35 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | — | search_blocks |
| 10.1016/j.tca.2011.08.013 | PROPblock_10 | declared | 16 | binary | — | search_blocks |
| 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMSO and wa… | 284 | KEEP | 284 | 3.8 |
| 2 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 417 | — | — | 97.9 |
| 3 | 1 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve GLOBcomp ID… | 283 | KEEP | 283 | 4.6 |
| 4 | 2 | `L1_query` | context=Need to identify the correct …, id_catalog… | 1,573 | — | — | 27.6 |
| 5 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,222 | KEEP | 1222 | 16.1 |
| 6 | 3 | `L1_query` | context=Binary system search for dyna…, id_catalog… | 21,217 | — | — | 56.6 |
| | | **TOTAL (6 tools)** | | **24,996** | | **1,789** | **206.6** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,014 | 10,619 | 1,514 | 7.7 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,280 | 21,923 | 655 | 5.6 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,556 | 23,199 | 7,372 | 32.8 |
| 4 | L1-worker | claudeopus46 | 2,065 | 478 | 2,543 | 445 | 3.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,763 | 23,406 | 4,075 | 23.6 |
| 6 | L1-worker | claudeopus46 | 20,643 | 7,459 | 28,102 | 1,574 | 6.6 |
| 7 | L1-worker | claudeopus46 | 1,356 | 1,451 | 2,807 | 652 | 5.0 |
| 8 | L1-worker | claudeopus46 | 536 | 1,331 | 1,867 | 831 | 5.2 |
| 9 | L1-worker | claudeopus46 | 1,323 | 3,822 | 5,145 | 1,698 | 7.5 |
| 10 | L1-worker | claudeopus46 | 298 | 2,420 | 2,718 | 1,318 | 5.4 |
| 11 | L1-worker | claudeopus46 | 1,160 | 5,998 | 7,158 | 1,674 | 6.6 |
| 12 | L1-worker | claudeopus46 | 298 | 2,396 | 2,694 | 1,303 | 5.4 |
| 13 | L0-main | claudeopus46 | 9,605 | 1,933 | 11,538 | 1,152 | 7.4 |
| 14 | L1-worker | claudeopus46 | 20,643 | 962 | 21,605 | 596 | 5.6 |
| 15 | L1-worker | claudeopus46 | 2,065 | 509 | 2,574 | 444 | 4.5 |
| 16 | L1-worker | claudeopus46 | 20,643 | 1,695 | 22,338 | 482 | 4.2 |
| 17 | L1-worker | claudeopus46 | 1,356 | 611 | 1,967 | 324 | 4.9 |
| 18 | L1-worker | claudeopus46 | 1,323 | 2,240 | 3,563 | 234 | 5.0 |
| 19 | L1-worker | claudeopus46 | 536 | 491 | 1,027 | 345 | 5.2 |
| 20 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 2.5 |
| 21 | L1-worker | claudeopus46 | 747 | 2,761 | 3,508 | 416 | 5.0 |
| 22 | L0-main | claudeopus46 | 9,605 | 5,802 | 15,407 | 1,704 | 11.9 |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,212 | 23,855 | 912 | 7.1 |
| 24 | L1-worker | claudeopus46 | 2,065 | 7,540 | 9,605 | 1,585 | 15.3 |
| 25 | L1-worker | claudeopus46 | 20,643 | 4,949 | 25,592 | 2,020 | 11.2 |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,957 | 3,313 | 737 | 4.8 |
| 27 | L1-worker | claudeopus46 | 536 | 1,837 | 2,373 | 852 | 5.9 |
| 28 | L1-worker | claudeopus46 | 1,323 | 5,098 | 6,421 | 1,555 | 7.5 |
| 29 | L1-worker | claudeopus46 | 298 | 2,277 | 2,575 | 1,230 | 6.0 |
| 30 | L1-worker | claudeopus46 | 747 | 24,761 | 25,508 | 747 | 7.7 |
| 31 | L0-main | claudeopus46 | 9,605 | 48,901 | 58,506 | 3,648 | 24.5 |
| 32 | L0-main | claudeopus46 | 1,356 | 3,514 | 4,870 | 1,025 | 6.3 |
| 33 | L0-main | claudeopus46 | 298 | 1,407 | 1,705 | 1,013 | 4.1 |
| 34 | L0-main | claudeopus46 | 1,323 | 32,602 | 33,925 | 3,804 | 21.2 |
| 35 | L0-main | claudeopus46 | 298 | 4,472 | 4,770 | 3,092 | 12.6 |


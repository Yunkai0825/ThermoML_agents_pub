# Delegated query run — result

**Question:** Find all data blocks containing dynamic viscosity (GLOBprop_4) measurements for the binary system of dimethyl sulfoxide (DMSO) and water near 298.15 K at atmospheric pressure. Report DOIs, block IDs, literature IDs, number of data points, temperature range, and composition range.

**Iterations:** 4  |  **Elapsed:** 234.1s  |  **Tools:** 3  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity Data for DMSO + Water Binary System

Three data blocks containing dynamic viscosity (Pa·s) measurements for the binary system of dimethyl sulfoxide (DMSO, C₂H₆OS) + water (H₂O) were found in the ThermoML database. All measurements are for the liquid phase at atmospheric pressure (101 kPa).

---

### 1. GLOBlit_2781 — DOI: 10.1016/j.jct.2006.12.012
- **Block:** PROPblock_3
- **Data points:** 120
- **Temperature range:** 298.15–318.15 K (5 unique temperatures)
- **Composition range:** x(DMSO) = 0.0–1.0 (full mole-fraction range, 24 unique compositions)
- **Composition variable:** Mole fraction
- **Viscosity range:** 0.000596–0.003735 Pa·s (mean 0.002112 Pa·s)
- **Method:** Capillary tube (CAPTUB)
- **Notes:** This is the most comprehensive dataset, covering the entire composition range. It is the best source for data near 298.15 K across all DMSO mole fractions.

### 2. GLOBlit_5953 — DOI: 10.1016/j.tca.2011.08.013
- **Block:** PROPblock_10
- **Data points:** 16
- **Temperature range:** 303.15–318.15 K (4 unique temperatures)
- **Composition range:** x(DMSO) = 0.0121–0.0583 (dilute DMSO only, 4 unique compositions)
- **Composition variable:** Mole fraction
- **Viscosity range:** 0.000667–0.001224 Pa·s (mean 0.000907 Pa·s)
- **Method:** Capillary tube (Ostwald/Ubbelohde)
- **Notes:** Covers only very dilute DMSO compositions (up to ~5.8 mol%). Does not include 298.15 K (starts at 303.15 K).

### 3. GLOBlit_11517 — DOI: 10.1021/je9001027
- **Block:** PROPblock_3
- **Data points:** 35
- **Temperature range:** 298.15–318.15 K (5 unique temperatures)
- **Composition range:** w(DMSO) = 0.0–1.0 (full mass-fraction range, 7 unique compositions)
- **Composition variable:** Mass fraction (not mole fraction)
- **Viscosity range:** 0.000535–0.003421 Pa·s (mean 0.001868 Pa·s)
- **Method:** Capillary tube (CAPTUB)
- **Notes:** Spans the full composition range but reports composition as mass fraction rather than mole fraction. Includes data at 298.15 K.

---

### Summary & Chemistry Context

| Feature | GLOBlit_2781 | GLOBlit_5953 | GLOBlit_11517 |
|---------|-------------|-------------|--------------|
| DOI | 10.1016/j.jct.2006.12.012 | 10.1016/j.tca.2011.08.013 | 10.1021/je9001027 |
| Points | 120 | 16 | 35 |
| T range (K) | 298.15–318.15 | 303.15–318.15 | 298.15–318.15 |
| Composition | x = 0–1 | x = 0.012–0.058 | w = 0–1 |
| Includes 298.15 K? | ✓ | ✗ | ✓ |
| Full range? | ✓ | ✗ (dilute only) | ✓ |

**Recommended dataset for surrogate analysis:** The GLOBlit_2781 dataset (DOI: 10.1016/j.jct.2006.12.012) is the most suitable, with 120 data points spanning the full mole-fraction range at temperatures including 298.15 K.

**Chemical insight:** The DMSO + water system is well known for exhibiting a pronounced viscosity maximum near x(DMSO) ≈ 0.3–0.35, where the viscosity significantly exceeds that of either pure component (reaching ~0.00374 Pa·s vs. ~0.00089 Pa·s for pure water and ~0.00197 Pa·s for pure DMSO at 298.15 K). This anomalous behavior arises from strong hydrogen-bonding interactions between the S=O group of DMSO and water molecules, forming stable 1:2 (DMSO:water) complexes. This makes DMSO + water a useful surrogate system for studying other aqueous aprotic solvent mixtures (such as NMP + water) that exhibit similar non-ideal viscosity behavior driven by solute–solvent hydrogen bonding.

### Core claims

- Three ThermoML data blocks contain dynamic viscosity measurements for the DMSO + water binary system in the liquid phase at atmospheric pressure (101 kPa), spanning temperatures of 298.15–318.15 K.
- The most comprehensive dataset (GLOBlit_2781, DOI: 10.1016/j.jct.2006.12.012) provides 120 data points covering the full DMSO mole-fraction range (0–1) at five temperatures including 298.15 K, measured by capillary tube.
- A second dataset (GLOBlit_5953) covers only dilute DMSO compositions (x ≈ 0.012–0.058) at 303.15–318.15 K and does not include 298.15 K.
- A third dataset (GLOBlit_11517) spans the full composition range at 298.15–318.15 K but reports composition as mass fraction rather than mole fraction.
- The DMSO + water system exhibits a pronounced viscosity maximum near x(DMSO) ≈ 0.3–0.35, where viscosity (~0.00374 Pa·s at 298.15 K) significantly exceeds that of either pure component, attributed to strong hydrogen-bonding interactions forming stable 1:2 DMSO:water complexes.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 |  | Dynamic viscosity (Pa·s) for DMSO + water binary system. 120 data points, T = 298.15–318.15 K (5 unique temperatures), x(DMSO) = 0.0–1.0 (24 unique mole fractions), P = 101 kPa. Full composition range. Method: CAPTUB. Viscosity range: 0.000596–0.003735 Pa·s. |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_10 |  | Dynamic viscosity (Pa·s) for DMSO + water binary system. 16 data points, T = 303.15–318.15 K (4 unique temperatures), x(DMSO) = 0.0121–0.0583 (4 unique mole fractions, dilute DMSO only), P = 101 kPa. Method: Capillary tube (Ostwald/Ubbelohde). Viscosity range: 0.000667–0.001224 Pa·s. |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3 |  | Dynamic viscosity (Pa·s) for DMSO + water binary system. 35 data points, T = 298.15–318.15 K (5 unique temperatures), w(DMSO) = 0.0–1.0 (7 unique mass fractions), P = 101 kPa. Full composition range reported as mass fraction. Method: CAPTUB. Viscosity range: 0.000535–0.003421 Pa·s. |

### Suggested follow-ups

- Retrieve individual data points from GLOBlit_2781 PROPblock_3 at T = 298.15 K to obtain the full viscosity vs. mole fraction curve for DMSO + water at the target temperature.
- Search for dynamic viscosity data for NMP (N-methyl-2-pyrrolidone, GLOBcomp expected) + water binary system to enable direct comparison with the DMSO + water surrogate data.
- Convert mass fraction compositions in GLOBlit_11517 PROPblock_3 to mole fractions for consistent cross-dataset comparison.
- Search for excess molar volume or excess enthalpy data for DMSO + water to complement the viscosity analysis of non-ideal mixing behavior.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_31",
    "registry_id": "dimethyl_sulfoxide",
    "name": "dimethyl sulfoxide"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction",
    "name": "Mole fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_5",
    "registry_id": "mass_fraction",
    "name": "Mass fraction"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_140",
    "registry_id": "captub_ufactor_2",
    "name": "CAPTUB:UFactor:2"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_4",
    "registry_id": "capillary_tube_ostwald_ubbelohde_method",
    "name": "Capillary tube (Ostwald; Ubbelohde) method"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_205",
    "registry_id": "captub_ufactor_16",
    "name": "CAPTUB:UFactor:16"
  }
]
```

# Delegated query run — result

**Question:** Find all data blocks containing dynamic viscosity (GLOBprop_4) measurements for the binary system of gamma-butyrolactone (GBL) and water near 298.15 K at atmospheric pressure. Report DOIs, block IDs, literature IDs, number of data points, temperature range, and composition range.

**Iterations:** 7  |  **Elapsed:** 451.8s  |  **Tools:** 6  |  **Timed out:** False

---

## Answer

The ThermoML database contains **one data block** with dynamic viscosity measurements for the binary γ-butyrolactone (GBL) + water system:

---

### Data Block Summary

| Field | Value |
|-------|-------|
| **Block ID** | PROPblock_32 |
| **DOI** | 10.1021/je100803e (GLOBlit_9316) |
| **Literature ID** | 2011-mat-kim-0 |
| **Property** | Dynamic viscosity (Pa·s) |
| **Measurement method** | Capillary tube / Ostwald–Ubbelohde |
| **Number of data points** | 13 |
| **Temperature** | 298.15 K (fixed) |
| **Pressure** | 101.0 kPa (atmospheric) |
| **Composition variable** | Mole fraction of water, x(H₂O) |
| **Composition range** | 0.0 – 1.0 (full range, 13 unique values) |
| **Viscosity range** | 0.000876 – 0.001801 Pa·s (0.876 – 1.801 mPa·s) |

---

### Representative Data Points (298.15 K, 101.0 kPa)

| x(water) | η (Pa·s) | ±U (Pa·s, 95% CL) |
|-----------|-----------|---------------------|
| 0.0 (pure GBL) | 0.0016539 | 1.4 × 10⁻⁵ |
| 0.1002 | 0.0015998 | 1.35 × 10⁻⁵ |
| 0.2 | 0.0016059 | 1.35 × 10⁻⁵ |
| … | … | … |
| 1.0 (pure water) | 0.000876 | — |

---

### Chemistry Insight

The viscosity of the GBL + water binary mixture exhibits a **non-monotonic composition dependence**, with a viscosity maximum near x(water) ≈ 0.6 where the mixture viscosity (~1.80 mPa·s) exceeds both pure-component values. This behavior is characteristic of aqueous mixtures with strong solute–solvent hydrogen-bonding interactions: the carbonyl group of GBL acts as a hydrogen-bond acceptor, and the structuring of the water hydrogen-bond network around the aprotic GBL molecules leads to enhanced intermolecular friction at intermediate compositions.

Pure GBL has a viscosity of approximately **1.65 mPa·s** at 298.15 K, while pure water is about **0.88 mPa·s** — the mixture maximum exceeds both by a significant margin.

### Relevance as NMP + Water Surrogate

This dataset is potentially useful as a surrogate for the NMP (N-methyl-2-pyrrolidone) + water system, since both GBL and NMP are cyclic aprotic solvents with strong hydrogen-bond-accepting carbonyl groups that interact similarly with water. Both systems are known to exhibit viscosity maxima at intermediate water compositions. However, the available GBL + water data are limited to a **single temperature (298.15 K)** and atmospheric pressure, so no temperature-dependence information is available in this dataset.

This is the **only** data block in the ThermoML database for dynamic viscosity of the GBL + water binary system.

### Core claims

- The ThermoML database contains exactly one data block (PROPblock_32, DOI 10.1021/je100803e) with dynamic viscosity measurements for the binary γ-butyrolactone (GBL) + water system, comprising 13 data points at 298.15 K and 101.0 kPa across the full mole-fraction range of water (0.0–1.0).
- The dynamic viscosity of the GBL + water mixture exhibits a non-monotonic composition dependence, with a maximum near x(water) ≈ 0.6 (~1.80 mPa·s) that exceeds both pure-component values (pure GBL ≈ 1.65 mPa·s; pure water ≈ 0.88 mPa·s), indicative of strong solute–solvent hydrogen-bonding interactions.
- The dataset is limited to a single temperature (298.15 K) and atmospheric pressure, so no temperature-dependence information is available.
- The GBL + water system may serve as a surrogate for the NMP + water system, as both involve cyclic aprotic solvents with strong hydrogen-bond-accepting carbonyl groups and both exhibit viscosity maxima at intermediate water compositions.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_9316 | 10.1021/je100803e | PROPblock_32 |  | Dynamic viscosity (Pa·s) of binary gamma-butyrolactone (GLOBcomp_209) + water (GLOBcomp_1) system. 13 data points at 298.15 K and 101.0 kPa, water mole fraction range 0.0–1.0. Measurement method: capillary tube / Ostwald–Ubbelohde (GLOBmeas_4). Viscosity range 0.000876–0.001801 Pa·s. Non-monotonic composition dependence with maximum near x(water) ≈ 0.6. |

### Suggested follow-ups

- Retrieve full 13-point data table from PROPblock_32 (GLOBlit_9316) to obtain all mole-fraction vs. viscosity pairs with uncertainties.
- Search for NMP (N-methyl-2-pyrrolidone, GLOBcomp for CAS 872-50-4) + water dynamic viscosity data to enable direct comparison with the GBL + water surrogate dataset.
- Search for GBL + water density (GLOBprop_3) or excess molar volume data in the same DOI (10.1021/je100803e) to complement the viscosity analysis.
- Search for GBL + water viscosity data at other temperatures to assess temperature dependence, which is absent from this single-temperature dataset.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_209",
    "registry_id": ".gamma.-butyrolactone",
    "name": ".gamma.-butyrolactone"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_9316",
    "registry_id": "2011-mat-kim-0",
    "name": "10.1021/je100803e"
  }
]
```

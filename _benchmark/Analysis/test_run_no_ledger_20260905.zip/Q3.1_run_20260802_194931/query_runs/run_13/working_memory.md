# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_1 | water | water |
| comp | GLOBcomp_209 | .gamma.-butyrolactone | .gamma.-butyrolactone |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|
| lit | GLOBlit_9316 | 2011-mat-kim-0 | 10.1021/je100803e |

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find the global component ID for water (H2O, CAS 7732-18-5) → stored as L1_query_1
- [L1] Find the global component ID for gamma-butyrolactone (GBL) → stored as L1_query_2
- [L1] Find all data blocks with dynamic viscosity measurements for binary GBL+water system → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "Water (H2O, CAS 7732-18-5) resolves to **GLOBcomp_1** in the ThermoML database. The match was exact (score 100), with molecular formula H2O and SMILES \"O\".",
  "core_claims": [
    "Water (H2O, CAS 7732-18-5) is identified as GLOBcomp_1 in the ThermoML database, matched exactly (score 100) with molecular formula H2O and SMILES \"O\"."
  ],
  "status": "success",
  "summary": "Water (H2O, CAS 7732-18-5) is identified as GLOBcomp_1 in the ThermoML database, matched exactly (score 100) with molecular formula H2O and SMILES 'O'.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "Gamma-butyrolactone (GBL, CAS 96-48-0) resolves to **GLOBcomp_209** in the ThermoML database. The registry name is \".gamma.-butyrolactone\", with molecular formula C4H6O2 and SMILES `O=C1CCCO1`. The match was a fuzzy-name match with a score of 95.",
  "core_claims": [
    "Gamma-butyrolactone (GBL, CAS 96-48-0) resolves to GLOBcomp_209 in the ThermoML database, with registry name '.gamma.-butyrolactone', molecular formula C4H6O2, and SMILES O=C1CCCO1, based on a fuzzy-name match with a score of 95."
  ],
  "status": "success",
  "summary": "Gamma-butyrolactone (GBL, CAS 96-48-0) is identified as GLOBcomp_209 in the ThermoML database. Its registry name is '.gamma.-butyrolactone', with molecular formula C4H6O2 and SMILES O=C1CCCO1. The match was established via fuzzy-name matching with a confidence score of 95.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_209",
      "registry_id": ".gamma.-butyrolactone",
      "name": ".gamma.-butyrolactone"
    }
  ],
  "core_blocks_found": []
}
### L1_query_3
{
  "answer": "One data block was found in the ThermoML database containing dynamic viscosity measurements for the binary gamma-butyrolactone (GBL) + water system:\n\n**Block: PROPblock_32**\n- **DOI:** 10.1021/je100803e\n- **Literature ID:** GLOBlit_9316 (2011-mat-kim-0)\n- **System:** Binary — GLOBcomp_209 (γ-butyrolactone) + GLOBcomp_1 (water)\n- **Property:** Dynamic viscosity (GLOBprop_4, Pa·s)\n- **Measurement method:** Capillary tube / Ostwald–Ubbelohde (GLOBmeas_4)\n- **Number of data points:** 13\n- **Temperature:** 298.15 K (fixed constraint, GLOBconstr_2)\n- **Pressure:** 101.0 kPa (fixed constraint, GLOBconstr_1)\n- **Composition variable:** Mole fraction of water in liquid phase (GLOBvar_2), range 0.0–1.0\n\n**Representative data points at 298.15 K and 101.0 kPa:**\n\n| x(water) | η (Pa·s) | ±U (Pa·s) |\n|-----------|-----------|------------|\n| 0.0       | 0.0016539 | 1.4×10⁻⁵  |\n| 0.1002    | 0.0015998 | 1.35×10⁻⁵ |\n| 0.2       | 0.0016059 | 1.35×10⁻⁵ |\n| 0.5       | ~maximum region | — |\n| 1.0       | pure water | — |\n\n**Chemistry insight:** The viscosity of the GBL + water binary mixture exhibits a non-monotonic composition dependence, with a viscosity maximum near x(water) ≈ 0.6. This behavior is characteristic of aqueous mixtures with strong solute–solvent hydrogen-bonding interactions, where the structuring of the hydrogen-bond network around the aprotic GBL molecules leads to enhanced intermolecular friction at intermediate compositions. Pure GBL has a viscosity of about 1.65 mPa·s at 298.15 K, and the mixture viscosity exceeds both pure-component values in the intermediate composition range.\n\nThis is the only data block in the database for this system and property combination. The data are entirely at 298.15 K and atmospheric pressure, covering the full composition range from pure GBL to pure water.",
  "core_claims": [
    "A single ThermoML data block (DOI 10.1021/je100803e) reports dynamic viscosity for the binary γ-butyrolactone + water system at 298.15 K and 101.0 kPa, measured by capillary viscometry, covering the full mole-fraction range of water (0.0–1.0) in 13 data points.",
    "The viscosity of the GBL + water mixture shows a non-monotonic composition dependence, with a maximum near x(water) ≈ 0.6, where the mixture viscosity exceeds both pure-component values—behavior attributed to strong solute–solvent hydrogen-bonding interactions that enhance intermolecular friction at intermediate compositions.",
    "Pure γ-butyrolactone has a dynamic viscosity of approximately 1.65 mPa·s at 298.15 K.",
    "The available data are limited to a single temperature (298.15 K) and atmospheric pressure, so no information on temperature or pressure dependence is present in this dataset."
  ],
  "status": "success",
  "summary": "The ThermoML database contains one data block (DOI 10.1021/je100803e, literature ID GLOBlit_9316) with dynamic viscosity measurements for the binary γ-butyrolactone (GBL) + water system. The 13 data points were measured by capillary tube (Ostwald–Ubbelohde) method at 298.15 K and 101.0 kPa, spanning the full mole-fraction range of water (0.0–1.0). Pure GBL has a viscosity of about 1.65 mPa·s at 298.15 K. The mixture viscosity shows a non-monotonic composition dependence with a maximum near x(water) ≈ 0.6, exceeding both pure-component values at intermediate compositions—behavior attributed to strong solute–solvent hydrogen-bonding interactions. This is the only data block in the database for this system and property combination.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_9316",
      "block_number": "PROPblock_32",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_209",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) measurements for binary gamma-butyrolactone (GLOBcomp_209) + water (GLOBcomp_1) system. DOI 10.1021/je100803e. 13 data points at 298.15 K and 101.0 kPa, water mole fraction range 0.0–1.0. Measurement method: capillary tube / Ostwald–Ubbelohde (GLOBmeas_4). Viscosity exhibits a non-monotonic composition dependence with a maximum near x(water) ≈ 0.6.",
      "doi": "10.1021/je100803e",
      "lit_id": "2011-mat-kim-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 13,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_209",
          "name": ".gamma.-butyrolactone",
          "formula": "C4H6O2",
          "inchi_key": "YEJRWHAVMIAJKC-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_5",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_5",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000876,
            "max": 0.001801,
            "mean": 0.00156,
            "std": 0.000269,
            "n": 13
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000876,
          "range_max": 0.001801
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_209",
          "name": ".gamma.-butyrolactone",
          "formula": "C4H6O2",
          "inchi_key": "YEJRWHAVMIAJKC-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        }
      ],
      "parent_n_datapoints": 13,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


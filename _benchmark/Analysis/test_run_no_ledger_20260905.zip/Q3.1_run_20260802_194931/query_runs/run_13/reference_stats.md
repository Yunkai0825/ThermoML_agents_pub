# Reference Stats — query-agent

**Run started:** 2026-08-02 20:02:42
**Wall time (at last flush):** 470.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 11 | 70,510 | 100,949 | 17,147 | 171,459 | 15,587 | 108.8 | claudeopus46 |
| L1-worker | 55 | 413,208 | 191,934 | 57,747 | 605,142 | 11,002 | 382.2 | claudeopus46 |
| **TOTAL** | **66** | **483,718** | **292,883** | **74,894** | **776,601** | **11,766** | **491.0** | |

**Estimated tokens:** ~194,150 input + ~18,723 output = ~212,873 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 19 | 1 | 5 | 2 | 13 | 24 | 1,264 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 13 |
| **TOTAL** | **52** | **2** | **6** | **4** | **14** | **25** | **1,277** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (28 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_209 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_4457 |  | resolve_compound_ids |
| GLOBcomp_447 |  | resolve_compound_ids |
| GLOBcomp_4902 |  | resolve_compound_ids |
| GLOBcomp_5724 |  | resolve_compound_ids |
| GLOBcomp_7306 |  | resolve_compound_ids |
| GLOBcomp_6362 |  | resolve_compound_ids |
| GLOBcomp_6186 |  | resolve_compound_ids |
| GLOBcomp_2418 |  | resolve_compound_ids |
| GLOBcomp_7714 |  | resolve_compound_ids |
| GLOBcomp_342 | N-methylacetamide | search_blocks |
| GLOBcomp_50 | 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide | search_blocks |
| GLOBcomp_136 | 1-butyl-1-methylpyrrolidinium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_334 | 1-methyl-3-propylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_47 | N-methylpyrrolidone | search_blocks |
| GLOBcomp_340 | 1-butyl-1-methylpyrrolidinium dicyanamide | search_blocks |
| GLOBcomp_175 | 1-butyl-3-methylimidazolium dicyanamide | search_blocks |
| GLOBcomp_64 | 1-ethyl-3-methylimidazolium bis((trifluoromethyl)sulfonyl)imide | search_blocks |
| GLOBcomp_56 | 1-hexyl-3-methylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_138 | 1-octyl-3-methylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_830 | 1-ethyl-2,3-dimethylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_833 | 1,2-dimethyl-3-propylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_396 | 1-butyl-2,3-dimethyl-1H-imidazolium bis(trifluoromethylsulfonyl)amide | search_blocks |
| GLOBcomp_31 | dimethyl sulfoxide | search_blocks |
| GLOBcomp_915 | 1,3-dimethylimidazolium bis((trifluoromethyl)sulfonyl)amide | search_blocks |
| GLOBcomp_386 | diethyl butanedioate | search_blocks |
| GLOBcomp_1 | water | resolve_compound_ids, search_blocks |
| GLOBcomp_160 | tetrabutylammonium bromide | search_blocks |

#### References (13 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2953 |  | search_blocks |
| GLOBlit_4141 |  | search_blocks |
| GLOBlit_4253 |  | search_blocks |
| GLOBlit_4456 |  | search_blocks |
| GLOBlit_4467 |  | search_blocks |
| GLOBlit_4468 |  | search_blocks |
| GLOBlit_4623 |  | search_blocks |
| GLOBlit_4658 |  | search_blocks |
| GLOBlit_4721 |  | search_blocks |
| GLOBlit_4962 |  | search_blocks |
| GLOBlit_5123 |  | search_blocks |
| GLOBlit_9316 |  | search_blocks |
| GLOBlit_10952 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_308 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_33 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_7 | Solvent: Mass fraction | search_blocks |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_141 |  | search_blocks |
| GLOBsolvent_1 |  | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 28 |
| Unique References | 13 |
| Unique Properties | 1 |
| Unique Measurements | 5 |
| Unique Phases | 1 |
| Unique Variables | 5 |
| Unique Constraints | 2 |
| Unique Solvents | 2 |
| Total DOIs | 13 |
| Unique parent blocks | 24 |
| Explicit block/subsystem targets | 24 |
| Subsystem targets | 0 |
| Target-matched data points | 1,277 |

---

## 3. DOI & Block References

**Unique DOIs:** 13  |  **Parent blocks:** 24  |  **Explicit targets:** 24  |  **Subsystems:** 0  |  **Target-matched datapoints:** 1,264

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2008.05.004 | 2 | 48 | binary, unary | search_blocks |
| 10.1016/j.jct.2014.03.025 | 2 | 84 | binary, unary | search_blocks |
| 10.1016/j.jct.2014.10.002 | 2 | 72 | binary, unary | search_blocks |
| 10.1016/j.jct.2015.07.048 | 1 | 84 | binary | search_blocks |
| 10.1016/j.jct.2015.08.013 | 1 | 66 | binary | search_blocks |
| 10.1016/j.jct.2015.08.014 | 2 | 67 | binary, unary | search_blocks |
| 10.1016/j.jct.2016.02.014 | 1 | 70 | binary | search_blocks |
| 10.1016/j.jct.2016.03.034 | 3 | 238 | binary | search_blocks |
| 10.1016/j.jct.2016.06.012 | 3 | 273 | binary | search_blocks |
| 10.1016/j.jct.2017.02.009 | 2 | 12 | binary, unary | search_blocks |
| 10.1016/j.jct.2017.10.004 | 1 | 78 | binary | search_blocks |
| 10.1021/je100803e | 3 | 27 | binary, unary | search_blocks |
| 10.1021/je7004903 | 1 | 145 | ternary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2008.05.004 | PROPblock_13 | declared | 44 | binary | — | search_blocks |
| 10.1016/j.jct.2008.05.004 | PROPblock_4 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2014.03.025 | PROPblock_5 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2014.03.025 | PROPblock_8 | declared | 77 | binary | — | search_blocks |
| 10.1016/j.jct.2014.10.002 | PROPblock_5 | declared | 6 | unary | — | search_blocks |
| 10.1016/j.jct.2014.10.002 | PROPblock_8 | declared | 66 | binary | — | search_blocks |
| 10.1016/j.jct.2015.07.048 | PROPblock_5 | declared | 84 | binary | — | search_blocks |
| 10.1016/j.jct.2015.08.013 | PROPblock_5 | declared | 66 | binary | — | search_blocks |
| 10.1016/j.jct.2015.08.014 | PROPblock_6 | declared | 11 | unary | — | search_blocks |
| 10.1016/j.jct.2015.08.014 | PROPblock_8 | declared | 56 | binary | — | search_blocks |
| 10.1016/j.jct.2016.02.014 | PROPblock_4 | declared | 70 | binary | — | search_blocks |
| 10.1016/j.jct.2016.03.034 | PROPblock_11 | declared | 70 | binary | — | search_blocks |
| 10.1016/j.jct.2016.03.034 | PROPblock_7 | declared | 98 | binary | — | search_blocks |
| 10.1016/j.jct.2016.03.034 | PROPblock_9 | declared | 70 | binary | — | search_blocks |
| 10.1016/j.jct.2016.06.012 | PROPblock_11 | declared | 91 | binary | — | search_blocks |
| 10.1016/j.jct.2016.06.012 | PROPblock_7 | declared | 91 | binary | — | search_blocks |
| 10.1016/j.jct.2016.06.012 | PROPblock_9 | declared | 91 | binary | — | search_blocks |
| 10.1016/j.jct.2017.02.009 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2017.02.009 | PROPblock_6 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.jct.2017.10.004 | PROPblock_5 | declared | 78 | binary | — | search_blocks |
| 10.1021/je100803e | PROPblock_13 | declared | 1 | unary | — | search_blocks |
| 10.1021/je100803e | PROPblock_25 | declared | 13 | binary | — | search_blocks |
| 10.1021/je100803e | PROPblock_32 | declared | 13 | binary | — | search_blocks |
| 10.1021/je7004903 | PROPblock_1 | declared | 145 | ternary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve GBL and wa… | 520 | KEEP | 520 | 8.5 |
| 2 | 4 | `search_blocks` | compound=['GLOBcomp_209', 'GLOBcomp_7'], limit=50,… | 856 | DISCARD | 798 | 15.5 |
| 3 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 405 | — | — | 105.6 |
| 4 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve GBL and wa… | 502 | KEEP | 502 | 8.8 |
| 5 | 4 | `search_blocks` | compound=['GLOBcomp_209', 'GLOBcomp_9'], limit=50,… | 820 | DISCARD | 762 | 8.7 |
| 6 | 4 | `search_blocks` | compound=GLOBcomp_209, limit=50, property=GLOBprop… | 1,246 | KEEP | 1141 | 13.4 |
| 7 | 2 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 321 | — | — | 126.8 |
| 8 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Find the global com… | 197 | KEEP | 197 | 3.9 |
| 9 | 3 | `L1_query` | context=, id_catalog=, instruction=Look up the com… | 765 | — | — | 23.1 |
| 10 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Find the GLOBcomp … | 369 | KEEP | 369 | 6.1 |
| 11 | 4 | `L1_query` | context=, id_catalog=, instruction=Look up the com… | 1,088 | — | — | 33.9 |
| 12 | 2 | `search_blocks` | compound=['GLOBcomp_209', 'GLOBcomp_1'], limit=50,… | 1,109 | KEEP | 1094 | 18.8 |
| 13 | 5 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 9,520 | — | — | 80.6 |
| 14 | 6 | `memory_catalog_add` | global_id=GLOBlit_9316, name=10.1021/je100803e, re… | 2 | — | — | 0.1 |
| | | **TOTAL (14 tools)** | | **17,720** | | **5,383** | **453.8** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,012 | 10,617 | 1,513 | 9.9 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,406 | 22,049 | 663 | 7.5 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,690 | 23,333 | 5,255 | 24.4 |
| 4 | L1-worker | claudeopus46 | 2,065 | 1,312 | 3,377 | 1,000 | 7.8 |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,157 | 23,800 | 4,908 | 25.2 |
| 6 | L1-worker | claudeopus46 | 20,643 | 8,686 | 29,329 | 715 | 4.1 |
| 7 | L1-worker | claudeopus46 | 2,065 | 533 | 2,598 | 1,263 | 8.6 |
| 8 | L1-worker | claudeopus46 | 20,643 | 9,455 | 30,098 | 702 | 3.1 |
| 9 | L1-worker | claudeopus46 | 1,356 | 833 | 2,189 | 246 | 2.5 |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,955 | 6,278 | 238 | 3.6 |
| 11 | L1-worker | claudeopus46 | 536 | 713 | 1,249 | 537 | 3.6 |
| 12 | L1-worker | claudeopus46 | 298 | 960 | 1,258 | 158 | 2.3 |
| 13 | L1-worker | claudeopus46 | 747 | 5,372 | 6,119 | 350 | 4.3 |
| 14 | L1-worker | claudeopus46 | 1,160 | 5,663 | 6,823 | 158 | 2.1 |
| 15 | L1-worker | claudeopus46 | 747 | 5,372 | 6,119 | 311 | 4.1 |
| 16 | L0-main | claudeopus46 | 9,605 | 1,928 | 11,533 | 1,319 | 8.5 |
| 17 | L1-worker | claudeopus46 | 20,643 | 1,335 | 21,978 | 684 | 5.3 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,640 | 23,283 | 5,061 | 24.4 |
| 19 | L1-worker | claudeopus46 | 2,065 | 1,282 | 3,347 | 927 | 8.2 |
| 20 | L1-worker | claudeopus46 | 20,643 | 3,065 | 23,708 | 4,462 | 22.4 |
| 21 | L1-worker | claudeopus46 | 20,643 | 8,148 | 28,791 | 2,123 | 7.0 |
| 22 | L1-worker | claudeopus46 | 2,065 | 461 | 2,526 | 1,236 | 7.6 |
| 23 | L1-worker | claudeopus46 | 2,065 | 16,356 | 18,421 | 1,510 | 12.4 |
| 24 | L1-worker | claudeopus46 | 20,643 | 10,347 | 30,990 | 3,222 | 20.2 |
| 25 | L1-worker | claudeopus46 | 1,323 | 6,820 | 8,143 | 238 | 2.6 |
| 26 | L1-worker | claudeopus46 | 536 | 1,226 | 1,762 | 512 | 3.4 |
| 27 | L1-worker | claudeopus46 | 1,356 | 1,346 | 2,702 | 531 | 3.4 |
| 28 | L1-worker | claudeopus46 | 298 | 960 | 1,258 | 158 | 2.3 |
| 29 | L1-worker | claudeopus46 | 747 | 8,094 | 8,841 | 227 | 5.8 |
| 30 | L1-worker | claudeopus46 | 1,160 | 7,405 | 8,565 | 158 | 2.3 |
| 31 | L1-worker | claudeopus46 | 747 | 8,094 | 8,841 | 227 | 3.1 |
| 32 | L0-main | claudeopus46 | 9,605 | 2,783 | 12,388 | 937 | 6.4 |
| 33 | L1-worker | claudeopus46 | 20,643 | 700 | 21,343 | 516 | 5.9 |
| 34 | L1-worker | claudeopus46 | 2,065 | 371 | 2,436 | 394 | 3.4 |
| 35 | L1-worker | claudeopus46 | 20,643 | 1,355 | 21,998 | 174 | 3.0 |
| 36 | L1-worker | claudeopus46 | 1,356 | 305 | 1,661 | 173 | 2.5 |
| 37 | L1-worker | claudeopus46 | 536 | 185 | 721 | 165 | 2.5 |
| 38 | L1-worker | claudeopus46 | 1,323 | 1,517 | 2,840 | 162 | 2.7 |
| 39 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 4.1 |
| 40 | L1-worker | claudeopus46 | 747 | 1,492 | 2,239 | 305 | 3.2 |
| 41 | L0-main | claudeopus46 | 9,605 | 4,945 | 14,550 | 660 | 5.2 |
| 42 | L1-worker | claudeopus46 | 20,643 | 1,617 | 22,260 | 654 | 5.7 |
| 43 | L1-worker | claudeopus46 | 20,643 | 2,892 | 23,535 | 1,834 | 9.9 |
| 44 | L1-worker | claudeopus46 | 2,065 | 1,315 | 3,380 | 618 | 5.5 |
| 45 | L1-worker | claudeopus46 | 20,643 | 3,144 | 23,787 | 267 | 2.9 |
| 46 | L1-worker | claudeopus46 | 1,323 | 2,201 | 3,524 | 164 | 2.2 |
| 47 | L1-worker | claudeopus46 | 1,356 | 396 | 1,752 | 249 | 2.6 |
| 48 | L1-worker | claudeopus46 | 536 | 276 | 812 | 288 | 2.7 |
| 49 | L1-worker | claudeopus46 | 298 | 886 | 1,184 | 110 | 2.1 |
| 50 | L1-worker | claudeopus46 | 747 | 2,455 | 3,202 | 371 | 4.3 |
| 51 | L0-main | claudeopus46 | 9,605 | 7,688 | 17,293 | 1,604 | 10.6 |
| 52 | L1-worker | claudeopus46 | 20,643 | 3,477 | 24,120 | 1,046 | 6.3 |
| 53 | L1-worker | claudeopus46 | 20,643 | 5,144 | 25,787 | 4,841 | 24.9 |
| 54 | L1-worker | claudeopus46 | 2,065 | 2,533 | 4,598 | 1,605 | 11.7 |
| 55 | L1-worker | claudeopus46 | 20,643 | 6,205 | 26,848 | 2,413 | 13.7 |
| 56 | L1-worker | claudeopus46 | 536 | 1,850 | 2,386 | 752 | 4.4 |
| 57 | L1-worker | claudeopus46 | 1,323 | 5,281 | 6,604 | 740 | 4.6 |
| 58 | L1-worker | claudeopus46 | 1,356 | 1,970 | 3,326 | 877 | 6.1 |
| 59 | L1-worker | claudeopus46 | 298 | 1,462 | 1,760 | 613 | 5.6 |
| 60 | L1-worker | claudeopus46 | 747 | 13,335 | 14,082 | 528 | 6.1 |
| 61 | L0-main | claudeopus46 | 9,605 | 27,376 | 36,981 | 3,234 | 23.1 |
| 62 | L0-main | claudeopus46 | 9,605 | 28,045 | 37,650 | 2,514 | 16.8 |
| 63 | L0-main | claudeopus46 | 1,356 | 2,645 | 4,001 | 1,007 | 5.5 |
| 64 | L0-main | claudeopus46 | 298 | 1,389 | 1,687 | 995 | 4.7 |
| 65 | L0-main | claudeopus46 | 1,323 | 20,650 | 21,973 | 1,820 | 12.5 |
| 66 | L0-main | claudeopus46 | 298 | 2,488 | 2,786 | 1,544 | 5.6 |


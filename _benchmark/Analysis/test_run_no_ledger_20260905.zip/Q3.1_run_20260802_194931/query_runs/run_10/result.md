# Delegated query run — result

**Question:** Find all data blocks containing dynamic viscosity (GLOBprop_4) measurements for the binary system of N,N-dimethylformamide (DMF) and water near 298.15 K at atmospheric pressure. Report DOIs, block IDs, literature IDs, number of data points, temperature range, and composition range.

**Iterations:** 2  |  **Elapsed:** 114.6s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity Data for DMF + Water Binary System in ThermoML

Five data blocks in the ThermoML database contain dynamic viscosity (Pa·s) measurements for the binary system of N,N-dimethylformamide (DMF, C₃H₇NO) + water (H₂O), all at approximately atmospheric pressure (~101 kPa) in the liquid phase:

### Block-by-Block Summary

| # | DOI | Block ID | Literature ID | Data Points | Temperature Range (K) | Composition Range | Viscosity Range (Pa·s) |
|---|-----|----------|---------------|-------------|----------------------|-------------------|----------------------|
| 1 | 10.1021/je050209y | PROPblock_9 | GLOBlit_8676 | 11 | 298.15 (fixed) | x(DMF) = 0.05–0.9488 | 0.000843–0.002491 |
| 2 | 10.1021/je1008813 | PROPblock_3 | GLOBlit_9342 | 16 | 308.15–323.15 | w(DMF) = 0.1–1.0 | 0.000600–0.001539 |
| 3 | 10.1021/je300608v | PROPblock_3 | GLOBlit_9900 | 60 | 293.15–308.15 | x(water) = 0.0–1.0 | 0.000712–0.002885 |
| 4 | 10.1021/je700671t | PROPblock_3 | GLOBlit_11030 | 98 | 293.15–353.15 | x(DMF) = 0.0–1.0 | 0.000371–0.002954 |
| 5 | 10.1021/je800330d | PROPblock_3 | GLOBlit_11207 | 8 | 298.15–308.15 | x(DMF) = 0.05–0.20 | 0.000797–0.001391 |

### Key Details

1. **Block 1 (GLOBlit_8676)** — The most directly relevant dataset for 298.15 K. Temperature is fixed as a constraint at exactly 298.15 K, with 11 data points spanning the full DMF mole fraction range (0.05–0.95). Measurement method: capillary tube with U-factor correction.

2. **Block 2 (GLOBlit_9342)** — 16 data points at higher temperatures (308–323 K) using mass fraction as the composition variable. Does **not** include 298.15 K data. Measurement method: Ostwald/Ubbelohde capillary tube.

3. **Block 3 (GLOBlit_9900)** — 60 data points (including 4 from subsystem projections) covering 293.15–308.15 K with 15 unique water mole fractions spanning the full range (0.0–1.0). Includes data at 298.15 K within its temperature sweep. Measurement method: Ostwald/Ubbelohde capillary tube.

4. **Block 4 (GLOBlit_11030)** — The largest dataset with 98 data points (7 from subsystem projections) spanning 293.15–353.15 K and 14 unique DMF mole fractions across the full composition range (0.0–1.0). Includes data near 298.15 K and provides the most comprehensive multi-temperature, full-composition coverage. Measurement method: Ostwald/Ubbelohde capillary tube.

5. **Block 5 (GLOBlit_11207)** — 8 data points covering a narrow composition range (x(DMF) = 0.05–0.20) at 298.15–308.15 K. Measurement method: Ostwald/Ubbelohde capillary tube.

### Chemistry Context (DMF + Water as NMP + Water Surrogate)

The DMF + water system is a well-studied binary mixture that exhibits a pronounced **viscosity maximum** at intermediate compositions (around x_DMF ≈ 0.3–0.4 at 298.15 K), reaching approximately 0.0025–0.0030 Pa·s — roughly 2.5–3× the viscosity of pure water. This behavior arises from strong hydrogen-bonding interactions between DMF's carbonyl group and water molecules, forming structured H-bonded complexes.

This system serves as a useful surrogate for N-methyl-2-pyrrolidone (NMP) + water because both DMF and NMP are dipolar aprotic amide solvents that are fully miscible with water and exhibit qualitatively similar viscosity-composition profiles driven by analogous carbonyl–water hydrogen bonding. The key differences are that NMP's cyclic structure tends to produce somewhat higher viscosity maxima and slightly different composition dependence compared to the acyclic DMF.

**Recommended datasets for 298.15 K analysis:**
- **Block 1 (GLOBlit_8676)** for isothermal data at exactly 298.15 K across the full composition range.
- **Block 4 (GLOBlit_11030)** for the most comprehensive dataset enabling temperature-dependent analysis near 298.15 K.
- **Block 3 (GLOBlit_9900)** as a complementary source with dense composition coverage including 298.15 K.

### Core claims

- Five ThermoML data blocks contain dynamic viscosity measurements for the DMF (N,N-dimethylformamide) + water binary system, all at approximately atmospheric pressure (~101 kPa) in the liquid phase, collectively spanning 293.15–353.15 K, the full composition range (0–1 mole fraction DMF), and viscosities of approximately 0.000371–0.002954 Pa·s.
- The DMF + water system exhibits a pronounced viscosity maximum at intermediate compositions (around x_DMF ≈ 0.3–0.4 at 298.15 K), reaching approximately 0.0025–0.0030 Pa·s (roughly 2.5–3× the viscosity of pure water), attributed to strong hydrogen-bonding interactions between DMF's carbonyl group and water molecules.
- Block 1 (GLOBlit_8676, DOI 10.1021/je050209y) provides 11 isothermal data points at exactly 298.15 K spanning x(DMF) = 0.05–0.95, while Block 4 (GLOBlit_11030, DOI 10.1021/je700671t) offers the most comprehensive dataset with 98 points across 293.15–353.15 K and the full composition range.
- The DMF + water system is noted as a useful surrogate for NMP + water because both involve dipolar aprotic amide solvents fully miscible with water exhibiting qualitatively similar viscosity-composition profiles driven by carbonyl–water hydrogen bonding, though NMP's cyclic structure tends to produce somewhat higher viscosity maxima.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8676 | 10.1021/je050209y | PROPblock_9 |  | 11 data points of dynamic viscosity (GLOBprop_4) for DMF + water at 298.15 K (fixed constraint). x(DMF) = 0.05–0.9488. Viscosity range 0.000843–0.002491 Pa·s. Capillary tube method. |
| GLOBlit_9342 | 10.1021/je1008813 | PROPblock_3 |  | 16 data points of dynamic viscosity (GLOBprop_4) for DMF + water at 308.15–323.15 K. w(DMF) = 0.1–1.0. Viscosity range 0.000600–0.001539 Pa·s. Does not include 298.15 K. |
| GLOBlit_9900 | 10.1021/je300608v | PROPblock_3 |  | 60 data points of dynamic viscosity (GLOBprop_4) for DMF + water at 293.15–308.15 K. x(water) = 0.0–1.0. Viscosity range 0.000712–0.002885 Pa·s. Includes 298.15 K data. |
| GLOBlit_11030 | 10.1021/je700671t | PROPblock_3 |  | 98 data points of dynamic viscosity (GLOBprop_4) for DMF + water at 293.15–353.15 K. x(DMF) = 0.0–1.0. Viscosity range 0.000371–0.002954 Pa·s. Largest and most comprehensive dataset. |
| GLOBlit_11207 | 10.1021/je800330d | PROPblock_3 |  | 8 data points of dynamic viscosity (GLOBprop_4) for DMF + water at 298.15–308.15 K. x(DMF) = 0.05–0.20. Viscosity range 0.000797–0.001391 Pa·s. Narrow composition range. |

### Suggested follow-ups

- Retrieve the resolved GLOBcomp IDs for DMF and water to confirm compound identity mapping used by the L1 agent.
- Query for NMP (N-methyl-2-pyrrolidone, CAS 872-50-4) + water dynamic viscosity data to enable direct comparison with the DMF + water surrogate data found here.
- Extract the actual data points from Block 1 (GLOBlit_8676, PROPblock_9) at 298.15 K for isothermal viscosity-composition curve fitting.
- Query for density (GLOBprop_3) data for DMF + water to complement viscosity data for transport property modeling.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "dynamic viscosity",
    "name": "Dynamic viscosity (Pa·s)"
  }
]
```

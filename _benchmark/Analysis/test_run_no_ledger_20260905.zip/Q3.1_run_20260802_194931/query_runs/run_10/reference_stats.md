# Reference Stats — query-agent

**Run started:** 2026-08-02 19:58:14
**Wall time (at last flush):** 138.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 49,974 | 12,034 | 72,161 | 14,432 | 68.5 | claudeopus46 |
| L1-worker | 10 | 70,319 | 67,975 | 13,174 | 138,294 | 13,829 | 79.7 | claudeopus46 |
| **TOTAL** | **15** | **92,506** | **117,949** | **25,208** | **210,455** | **14,030** | **148.2** | |

**Estimated tokens:** ~52,613 input + ~6,302 output = ~58,915 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 2 | 5 | 5 | 193 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **4** | **1** | **3** | **2** | **5** | **5** | **193** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_18 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8676 |  | search_blocks |
| GLOBlit_9342 |  | search_blocks |
| GLOBlit_9900 |  | search_blocks |
| GLOBlit_11030 |  | search_blocks |
| GLOBlit_11207 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 5 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Total DOIs | 5 |
| Unique parent blocks | 5 |
| Explicit block/subsystem targets | 5 |
| Subsystem targets | 0 |
| Target-matched data points | 193 |

---

## 3. DOI & Block References

**Unique DOIs:** 5  |  **Parent blocks:** 5  |  **Explicit targets:** 5  |  **Subsystems:** 0  |  **Target-matched datapoints:** 193

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je050209y | 1 | 11 | binary | search_blocks |
| 10.1021/je1008813 | 1 | 16 | binary | search_blocks |
| 10.1021/je300608v | 1 | 60 | binary | search_blocks |
| 10.1021/je700671t | 1 | 98 | binary | search_blocks |
| 10.1021/je800330d | 1 | 8 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je050209y | PROPblock_9 | declared | 11 | binary | — | search_blocks |
| 10.1021/je1008813 | PROPblock_3 | declared | 16 | binary | — | search_blocks |
| 10.1021/je300608v | PROPblock_3 | declared | 60 | binary | — | search_blocks |
| 10.1021/je700671t | PROPblock_3 | declared | 98 | binary | — | search_blocks |
| 10.1021/je800330d | PROPblock_3 | declared | 8 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMF and wat… | 219 | KEEP | 219 | 3.9 |
| 2 | 2 | `search_blocks` | compound=['GLOBcomp_18', 'GLOBcomp_1'], limit=50, … | 1,280 | KEEP | 1280 | 21.5 |
| 3 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 270 | — | — | 77.1 |
| | | **TOTAL (3 tools)** | | **1,769** | | **1,499** | **102.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,014 | 10,619 | 1,406 | 8.0 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,347 | 21,990 | 725 | 5.6 |
| 3 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 466 | 3.8 |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,096 | 22,739 | 921 | 6.8 |
| 5 | L1-worker | claudeopus46 | 2,065 | 7,639 | 9,704 | 1,626 | 14.1 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,898 | 24,541 | 2,264 | 12.3 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,395 | 3,751 | 907 | 5.4 |
| 8 | L1-worker | claudeopus46 | 536 | 2,275 | 2,811 | 904 | 5.5 |
| 9 | L1-worker | claudeopus46 | 1,323 | 6,150 | 7,473 | 2,578 | 10.1 |
| 10 | L1-worker | claudeopus46 | 298 | 3,300 | 3,598 | 2,000 | 8.0 |
| 11 | L1-worker | claudeopus46 | 747 | 38,399 | 39,146 | 783 | 8.1 |
| 12 | L0-main | claudeopus46 | 9,605 | 35,675 | 45,280 | 4,761 | 29.3 |
| 13 | L0-main | claudeopus46 | 1,356 | 4,000 | 5,356 | 1,317 | 7.6 |
| 14 | L0-main | claudeopus46 | 1,323 | 6,237 | 7,560 | 2,380 | 14.7 |
| 15 | L0-main | claudeopus46 | 298 | 3,048 | 3,346 | 2,170 | 8.9 |


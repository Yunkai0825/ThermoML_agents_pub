# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_268 | 2-pyrrolidinone | 2-pyrrolidinone |
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find compound ID for 2-pyrrolidone (2-pyrrolidinone) in the ThermoML database → stored as L1_query_1
- [L1] Find all data blocks with dynamic viscosity measurements for 2-pyrrolidinone + water binary system → stored as L1_query_2

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "The compound 2-pyrrolidone is found in the ThermoML database as:\n\n- **Global ID:** GLOBcomp_268\n- **Name:** 2-pyrrolidinone (the IUPAC-preferred name for 2-pyrrolidone)\n- **Molecular formula:** C₄H₇NO\n- **SMILES:** OC1=NCCC1\n\nThis is the same compound known by various names including 2-pyrrolidone, 2-pyrrolidinone, γ-butyrolactam, and CAS 616-45-5. It is a five-membered cyclic amide (lactam) and a polar aprotic solvent structurally related to N-methyl-2-pyrrolidone (NMP), differing only by the absence of the N-methyl group. The match score of 92 confirms a strong fuzzy name match.",
  "core_claims": [
    "2-pyrrolidone is present in the ThermoML database as GLOBcomp_268 under the IUPAC name 2-pyrrolidinone, with molecular formula C₄H₇NO and SMILES OC1=NCCC1."
  ],
  "status": "success",
  "summary": "2-pyrrolidone is recorded in the ThermoML database under Global ID GLOBcomp_268, with the IUPAC name 2-pyrrolidinone, molecular formula C₄H₇NO, and SMILES OC1=NCCC1. It is also known as γ-butyrolactam (CAS 616-45-5), a five-membered cyclic amide (lactam) and polar aprotic solvent structurally related to N-methyl-2-pyrrolidone but lacking the N-methyl group. The identification was confirmed by a fuzzy name match score of 92.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_268",
      "registry_id": "2-pyrrolidinone",
      "name": "2-pyrrolidinone"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "The ThermoML database contains **one data block** with dynamic viscosity measurements for the binary system of 2-pyrrolidinone (GLOBcomp_268) + water (GLOBcomp_1):\n\n**Block details:**\n- **DOI:** 10.1021/je0340809 (GLOBlit_8242)\n- **Block ID:** PROPblock_14\n- **Literature ID:** GLOBlit_8242\n- **Total data points:** 95 (40 retained after Ramer–Douglas–Peucker compression)\n- **Property:** Dynamic viscosity (GLOBprop_4), reported in Pa·s, liquid phase\n- **Measurement method:** GLOBmeas_142 (capillary tube / U-factor method)\n\n**Conditions covered:**\n- **Temperature range:** 298.15–338.15 K (variable BLKvar_2 → GLOBvar_1)\n- **Composition range:** Mole fraction of water x(H₂O) = 0.0549–0.8516 (variable BLKvar_1 → GLOBvar_2)\n- **Pressure:** Fixed at 101.3 kPa (constraint BLKconstr_1 → GLOBconstr_1)\n\n**Compounds in the DOI:**\n- DOIcomp_2 → GLOBcomp_1 (water)\n- DOIcomp_3 → GLOBcomp_268 (2-pyrrolidinone)\n\nThis block includes data at 298.15 K at atmospheric pressure, which is the target condition of interest. The composition coverage is broad, spanning from nearly pure 2-pyrrolidinone (x_water ≈ 0.05) to water-rich mixtures (x_water ≈ 0.85). This is the only block in the database for this specific binary system and property combination.\n\nAs a chemistry note: 2-pyrrolidinone is a structural analogue of N-methyl-2-pyrrolidone (NMP), differing only by the absence of the N-methyl group. Both are polar, hydrogen-bond-accepting lactams that form strongly non-ideal aqueous mixtures. The viscosity of 2-pyrrolidinone + water mixtures typically shows a pronounced maximum at intermediate compositions due to extensive hydrogen bonding between the lactam carbonyl/NH and water, analogous to the behavior seen in NMP + water systems.",
  "core_claims": [
    "The ThermoML database contains exactly one data block (PROPblock_14, DOI 10.1021/je0340809) with dynamic viscosity measurements for the binary system 2-pyrrolidinone + water, comprising 95 data points (40 after compression), measured by capillary tube method at 101.3 kPa, covering temperatures from 298.15 to 338.15 K and water mole fractions from 0.0549 to 0.8516.",
    "Data at 298.15 K and atmospheric pressure are included within this block, which is the target condition of interest.",
    "No other block in the database provides dynamic viscosity data for this specific binary system."
  ],
  "status": "success",
  "summary": "The ThermoML database contains one data block (PROPblock_14, DOI 10.1021/je0340809, GLOBlit_8242) with dynamic viscosity measurements for the binary system 2-pyrrolidinone (GLOBcomp_268) + water (GLOBcomp_1). The block reports 95 data points (40 after compression) of dynamic viscosity (GLOBprop_4, in Pa·s, liquid phase) measured by a capillary tube / U-factor method (GLOBmeas_142). Conditions span 298.15–338.15 K, mole fraction of water 0.0549–0.8516, at a fixed pressure of 101.3 kPa. Data at 298.15 K and atmospheric pressure are included. The composition coverage is broad, from nearly pure 2-pyrrolidinone to water-rich mixtures. This is the only block in the database for this binary system and property combination. The viscosity of 2-pyrrolidinone + water mixtures typically exhibits a pronounced maximum at intermediate compositions due to extensive hydrogen bonding between the lactam and water.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_8242",
      "block_number": "PROPblock_14",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_268",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity measurements for the 2-pyrrolidinone + water binary system from DOI 10.1021/je0340809. 95 data points (40 retained after RDP compression) covering T = 298.15–338.15 K, x(water) = 0.0549–0.8516, at 101.3 kPa. Property reported in Pa·s, liquid phase, measured via capillary tube / U-factor method (GLOBmeas_142).",
      "doi": "10.1021/je0340809",
      "lit_id": "2004-geo-sas-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 95,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_268",
          "name": "2-pyrrolidinone",
          "formula": "C4H7NO",
          "inchi_key": "HNJBEVLQSNELDL-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.3,
          "digits": 4,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0549,
            "max": 0.9906,
            "n_unique": 19
          },
          "range_min": 0.0549,
          "range_max": 0.9906
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 338.15,
            "n_unique": 5
          },
          "range_min": 298.15,
          "range_max": 338.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_142",
          "meas_ID": "captub_ufactor_4",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000473,
            "max": 0.01302,
            "mean": 0.003378,
            "std": 0.003031,
            "n": 95
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000473,
          "range_max": 0.01302
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_268",
          "name": "2-pyrrolidinone",
          "formula": "C4H7NO",
          "inchi_key": "HNJBEVLQSNELDL-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 95,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


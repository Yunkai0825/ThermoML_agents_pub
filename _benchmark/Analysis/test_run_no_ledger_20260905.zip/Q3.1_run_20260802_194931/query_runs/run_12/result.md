# Delegated query run — result

**Question:** Find all data blocks containing dynamic viscosity (GLOBprop_4) measurements for the binary system of 2-pyrrolidone (or 2-pyrrolidinone) and water near 298.15 K at atmospheric pressure. Report DOIs, block IDs, literature IDs, number of data points, temperature range, and composition range.

**Iterations:** 3  |  **Elapsed:** 160.8s  |  **Tools:** 2  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity Data for 2-Pyrrolidinone + Water Binary System

The ThermoML database contains **one data block** with dynamic viscosity measurements for the binary system of 2-pyrrolidinone (2-pyrrolidone, γ-butyrolactam, C₄H₇NO) and water near 298.15 K at atmospheric pressure.

### Data Block Summary

| Field | Value |
|-------|-------|
| **DOI** | 10.1021/je0340809 (GLOBlit_8242) |
| **Block ID** | PROPblock_14 |
| **Literature ID** | GLOBlit_8242 |
| **Property** | Dynamic viscosity (GLOBprop_4), Pa·s, liquid phase |
| **Measurement method** | Capillary tube / U-factor method (GLOBmeas_142) |
| **Total data points** | 95 |
| **Temperature range** | 298.15–338.15 K (5 unique temperatures) |
| **Composition range** | Mole fraction of water x(H₂O) = 0.0549–0.9906 (19 unique compositions) |
| **Pressure** | 101.3 kPa (fixed, atmospheric) |
| **Viscosity range** | 0.000473–0.01302 Pa·s |
| **Uncertainty** | Propagation of evaluated standard uncertainties, 95% confidence level |

### Compounds

- **2-Pyrrolidinone** (GLOBcomp_268): C₄H₇NO, InChIKey HNJBEVLQSNELDL-UHFFFAOYSA-N
- **Water** (GLOBcomp_1): H₂O, InChIKey XLYOFNOQVPJJNP-UHFFFAOYSA-N

### Key Observations

- **Data at 298.15 K are included**, which matches the target condition of interest.
- The composition coverage is broad, spanning from nearly pure 2-pyrrolidinone (x_water ≈ 0.05) to water-rich mixtures (x_water ≈ 0.99).
- **This is the only block in the ThermoML database** for this specific binary system and property combination. No other sources were found.

### Chemistry Context — Surrogate Potential for NMP + Water

2-Pyrrolidinone is a structural analogue of N-methyl-2-pyrrolidone (NMP), differing only by the absence of the N-methyl group on the lactam nitrogen. Both are polar, hydrogen-bond-accepting five-membered cyclic amides that form strongly non-ideal aqueous mixtures. The viscosity of 2-pyrrolidinone + water mixtures typically exhibits a pronounced maximum at intermediate compositions due to extensive hydrogen bonding between the lactam carbonyl/NH groups and water — behavior analogous to that seen in NMP + water systems. The presence of the N–H group in 2-pyrrolidinone (absent in NMP) makes it both a hydrogen-bond donor and acceptor, potentially leading to even stronger water interactions and a more pronounced viscosity maximum compared to NMP. The viscosity range observed (0.47–13.0 mPa·s) and the broad composition coverage make this dataset useful as a surrogate reference for NMP + water viscosity modeling.

### Core claims

- The ThermoML database contains exactly one data block (DOI 10.1021/je0340809) with dynamic viscosity measurements for the 2-pyrrolidinone + water binary system, covering 95 data points across temperatures of 298.15–338.15 K, water mole fractions of 0.0549–0.9906, and viscosities of 0.000473–0.01302 Pa·s, all at 101.3 kPa.
- Data at 298.15 K are included, and the composition coverage spans from nearly pure 2-pyrrolidinone to water-rich mixtures.
- No other ThermoML sources were found for this specific binary system and property combination.
- 2-Pyrrolidinone is a structural analogue of N-methyl-2-pyrrolidone (NMP), differing only by the absence of the N-methyl group; its N–H group enables both hydrogen-bond donation and acceptance, potentially producing a more pronounced viscosity maximum in aqueous mixtures compared to NMP, making the dataset a possible surrogate reference for NMP + water viscosity modeling.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8242 | 10.1021/je0340809 | PROPblock_14 |  | Dynamic viscosity (GLOBprop_4) measurements for the binary system 2-pyrrolidinone (GLOBcomp_268) + water (GLOBcomp_1). 95 data points measured by capillary tube / U-factor method (GLOBmeas_142) at 101.3 kPa. Temperature range: 298.15–338.15 K (5 unique temperatures). Mole fraction of water: 0.0549–0.9906 (19 unique compositions). Viscosity range: 0.000473–0.01302 Pa·s. Uncertainty: propagation of evaluated standard uncertainties, 95% confidence level. This is the only block in the ThermoML database for this binary system and property combination. |

### Suggested follow-ups

- Retrieve individual data points at 298.15 K from PROPblock_14 (GLOBlit_8242) to examine the viscosity-composition curve shape and locate the viscosity maximum.
- Search for NMP (N-methyl-2-pyrrolidone) + water dynamic viscosity data in ThermoML for direct comparison with the 2-pyrrolidinone + water dataset.
- Search for density (GLOBprop_3) data for the same 2-pyrrolidinone + water system in DOI 10.1021/je0340809 to enable kinematic viscosity calculations.
- Compare the viscosity maximum magnitude and composition for 2-pyrrolidinone + water vs. NMP + water to assess surrogate suitability.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_268",
    "registry_id": "2-pyrrolidinone",
    "name": "2-pyrrolidinone"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_142",
    "registry_id": "captub_ufactor_4",
    "name": "Capillary tube / U-factor method"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_2",
    "name": "Mole fraction"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

# Reference Stats — query-agent

**Run started:** 2026-08-02 20:00:33
**Wall time (at last flush):** 186.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 31,792 | 53,470 | 11,336 | 85,262 | 14,210 | 70.6 | claudeopus46 |
| L1-worker | 19 | 138,573 | 55,345 | 17,793 | 193,918 | 10,206 | 137.0 | claudeopus46 |
| **TOTAL** | **25** | **170,365** | **108,815** | **29,129** | **279,180** | **11,167** | **207.6** | |

**Estimated tokens:** ~69,795 input + ~7,282 output = ~77,077 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 95 |
| **TOTAL** | **13** | **1** | **2** | **1** | **1** | **1** | **95** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (11 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_268 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_3079 |  | resolve_compound_ids |
| GLOBcomp_3578 |  | resolve_compound_ids |
| GLOBcomp_671 |  | resolve_compound_ids |
| GLOBcomp_1519 |  | resolve_compound_ids |
| GLOBcomp_47 |  | resolve_compound_ids |
| GLOBcomp_260 |  | resolve_compound_ids |
| GLOBcomp_1061 |  | resolve_compound_ids |
| GLOBcomp_2712 |  | resolve_compound_ids |
| GLOBcomp_8069 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8242 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 11 |
| Unique References | 1 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 95 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 95

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je0340809 | 1 | 95 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je0340809 | PROPblock_14 | declared | 95 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=40, purpose=Find the global co… | 394 | KEEP | 394 | 7.1 |
| 2 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 1,502 | — | — | 40.1 |
| 3 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve water to it… | 197 | KEEP | 197 | 4.1 |
| 4 | 2 | `search_blocks` | compound=['GLOBcomp_268', 'GLOBcomp_1'], limit=50,… | 1,026 | KEEP | 996 | 14.5 |
| 5 | 2 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 9,536 | — | — | 81.1 |
| | | **TOTAL (5 tools)** | | **12,655** | | **1,587** | **146.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,041 | 10,646 | 1,127 | 7.4 |
| 2 | L1-worker | claudeopus46 | 20,643 | 914 | 21,557 | 721 | 7.7 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,256 | 22,899 | 1,518 | 8.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 1,194 | 3,259 | 786 | 6.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,561 | 23,204 | 606 | 5.3 |
| 6 | L1-worker | claudeopus46 | 1,323 | 2,701 | 4,024 | 164 | 2.3 |
| 7 | L1-worker | claudeopus46 | 1,356 | 737 | 2,093 | 175 | 2.6 |
| 8 | L1-worker | claudeopus46 | 536 | 617 | 1,153 | 441 | 3.7 |
| 9 | L1-worker | claudeopus46 | 298 | 886 | 1,184 | 110 | 4.3 |
| 10 | L1-worker | claudeopus46 | 747 | 3,199 | 3,946 | 474 | 4.2 |
| 11 | L0-main | claudeopus46 | 9,605 | 4,693 | 14,298 | 1,586 | 12.2 |
| 12 | L1-worker | claudeopus46 | 20,643 | 3,125 | 23,768 | 691 | 5.5 |
| 13 | L1-worker | claudeopus46 | 2,065 | 352 | 2,417 | 420 | 4.0 |
| 14 | L1-worker | claudeopus46 | 20,643 | 3,790 | 24,433 | 4,801 | 26.3 |
| 15 | L1-worker | claudeopus46 | 2,065 | 3,744 | 5,809 | 1,425 | 13.7 |
| 16 | L1-worker | claudeopus46 | 20,643 | 5,364 | 26,007 | 1,754 | 12.4 |
| 17 | L1-worker | claudeopus46 | 1,323 | 5,398 | 6,721 | 766 | 5.2 |
| 18 | L1-worker | claudeopus46 | 536 | 1,765 | 2,301 | 922 | 5.4 |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,885 | 3,241 | 603 | 7.2 |
| 20 | L1-worker | claudeopus46 | 298 | 1,488 | 1,786 | 610 | 4.6 |
| 21 | L1-worker | claudeopus46 | 747 | 13,369 | 14,116 | 806 | 7.5 |
| 22 | L0-main | claudeopus46 | 9,605 | 24,460 | 34,065 | 2,740 | 19.6 |
| 23 | L0-main | claudeopus46 | 1,356 | 2,681 | 4,037 | 941 | 5.6 |
| 24 | L0-main | claudeopus46 | 1,323 | 17,213 | 18,536 | 2,714 | 16.2 |
| 25 | L0-main | claudeopus46 | 298 | 3,382 | 3,680 | 2,228 | 9.6 |


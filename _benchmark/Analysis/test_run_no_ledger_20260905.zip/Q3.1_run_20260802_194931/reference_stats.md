# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:49:31
**Wall time (at last flush):** 1,319.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 19 | 285,032 | 392,846 | 38,464 | 677,878 | 35,677 | 203.5 | claudeopus46 |
| L1-worker | 35 | 293,335 | 150,616 | 74,042 | 443,951 | 12,684 | 411.4 | claudeopus46 |
| **TOTAL** | **54** | **578,367** | **543,462** | **112,506** | **1,121,829** | **20,774** | **614.9** | |

**Estimated tokens:** ~280,457 input + ~28,126 output = ~308,583 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 2 | 1 | 3 | 3 | 204 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **2** | **1** | **3** | **3** | **204** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8238 |  | query_thermoml |
| GLOBlit_8242 |  | query_thermoml |
| GLOBlit_9372 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_47 | N-methylpyrrolidone | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | query_thermoml |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | query_thermoml |
| GLOBmeas_142 | Viscosity, Pa*s | query_thermoml |
| GLOBmeas_140 | Viscosity, Pa*s | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 3 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Constraints | 1 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Properties | 1 |
| Unique Measurements | 3 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 204 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 204

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je034073k | 1 | 65 | binary | query_thermoml |
| 10.1021/je0340809 | 1 | 95 | binary | query_thermoml |
| 10.1021/je100967k | 1 | 44 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je034073k | PROPblock_3 | declared | 65 | binary | 2 | query_thermoml |
| 10.1021/je0340809 | PROPblock_17 | declared | 95 | binary | 2 | query_thermoml |
| 10.1021/je100967k | PROPblock_17 | declared | 44 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'NMP_water_viscosi… | 184 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'NMP_water_viscosi… | 132 | — | — | 0.0 |
| 3 | 3 | `query_thermoml` | instruction=Search for dynamic viscosity …, purpos… | 21,324 | — | — | 125.5 |
| 4 | 4 | `query_thermoml_parallel` | queries=[{'label': '2pyrrolidone_wate… | 637 | — | — | 0.3 |
| 5 | 5 | `query_thermoml` | instruction=Search for dynamic viscosity …, purpos… | 988 | — | — | 90.6 |
| 6 | 6 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 387 | — | — | 170.6 |
| 7 | 7 | `run_query_agents_parallel` | queries=[{'question': 'Find all Therm… | 141 | — | — | 0.1 |
| 8 | 8 | `run_query_agents_parallel` | queries=[{'label': 'DMSO_water_visc',… | 139 | — | — | 0.0 |
| 9 | 9 | `run_query_agents_parallel` | queries=[{'label': 'DMSO_water', 'que… | 137 | — | — | 0.0 |
| 10 | 10 | `run_query_agents_parallel` | queries=[{'label': 'DMSO_water', 'que… | 304 | — | — | 738.7 |
| | | **TOTAL (10 tools)** | | **24,373** | | **0** | **1125.8** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 23,232 | 23,232 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 26,649 | 26,649 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 28,387 | 28,387 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 462 | 20,483 | 3,381 | 16.5 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,163 | 21,184 | 2,832 | 12.2 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,748 | 21,769 | 820 | 6.9 |
| 4 | L1-worker | claudeopus46 | 20,643 | 502 | 21,145 | 722 | 5.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 1,845 | 22,488 | 5,367 | 26.9 |
| 6 | L1-worker | claudeopus46 | 2,065 | 444 | 2,509 | 407 | 3.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 2,037 | 22,680 | 3,917 | 21.8 |
| 8 | L1-worker | claudeopus46 | 20,643 | 6,682 | 27,325 | 1,007 | 6.2 |
| 9 | L1-worker | claudeopus46 | 2,065 | 8,392 | 10,457 | 1,606 | 14.0 |
| 10 | L1-worker | claudeopus46 | 2,065 | 515 | 2,580 | 1,279 | 7.9 |
| 11 | L1-worker | claudeopus46 | 20,643 | 8,465 | 29,108 | 1,559 | 9.8 |
| 12 | L1-worker | claudeopus46 | 1,356 | 1,690 | 3,046 | 721 | 4.0 |
| 13 | L1-worker | claudeopus46 | 536 | 1,570 | 2,106 | 873 | 5.9 |
| 14 | L1-worker | claudeopus46 | 1,323 | 6,695 | 8,018 | 1,673 | 7.8 |
| 15 | L1-worker | claudeopus46 | 298 | 2,395 | 2,693 | 1,293 | 5.9 |
| 16 | L1-worker | claudeopus46 | 747 | 26,832 | 27,579 | 725 | 7.7 |
| 17 | L0-main | claudeopus46 | 19,988 | 25,752 | 45,740 | 582 | 5.4 |
| 18 | L0-main | claudeopus46 | 20,021 | 24,993 | 45,014 | 4,681 | 20.9 |
| 19 | L0-main | claudeopus46 | 20,021 | 26,604 | 46,625 | 1,012 | 8.7 |
| 20 | L1-worker | claudeopus46 | 20,643 | 664 | 21,307 | 625 | 5.3 |
| 21 | L1-worker | claudeopus46 | 20,643 | 1,910 | 22,553 | 4,945 | 25.5 |
| 22 | L1-worker | claudeopus46 | 2,065 | 1,150 | 3,215 | 1,033 | 7.8 |
| 23 | L1-worker | claudeopus46 | 20,643 | 2,398 | 23,041 | 4,419 | 21.9 |
| 24 | L1-worker | claudeopus46 | 20,643 | 7,438 | 28,081 | 1,565 | 5.7 |
| 25 | L1-worker | claudeopus46 | 1,356 | 1,696 | 3,052 | 487 | 3.6 |
| 26 | L1-worker | claudeopus46 | 536 | 1,576 | 2,112 | 556 | 3.7 |
| 27 | L1-worker | claudeopus46 | 1,323 | 4,167 | 5,490 | 1,233 | 6.3 |
| 28 | L1-worker | claudeopus46 | 298 | 1,955 | 2,253 | 952 | 4.9 |
| 29 | L1-worker | claudeopus46 | 1,160 | 5,853 | 7,013 | 558 | 3.9 |
| 30 | L1-worker | claudeopus46 | 747 | 10,528 | 11,275 | 888 | 8.3 |
| 31 | L0-main | claudeopus46 | 20,021 | 28,076 | 48,097 | 1,007 | 7.5 |
| 32 | L1-worker | claudeopus46 | 20,643 | 541 | 21,184 | 649 | 5.6 |
| 33 | L1-worker | claudeopus46 | 20,643 | 1,811 | 22,454 | 9,771 | 51.0 |
| 34 | L1-worker | claudeopus46 | 2,065 | 404 | 2,469 | 480 | 4.9 |
| 35 | L1-worker | claudeopus46 | 20,643 | 2,007 | 22,650 | 10,466 | 54.5 |
| 36 | L1-worker | claudeopus46 | 20,643 | 13,094 | 33,737 | 2,733 | 14.7 |
| 37 | L1-worker | claudeopus46 | 1,356 | 2,864 | 4,220 | 793 | 5.9 |
| 38 | L1-worker | claudeopus46 | 536 | 2,744 | 3,280 | 900 | 6.6 |
| 39 | L1-worker | claudeopus46 | 298 | 1,175 | 1,473 | 781 | 5.6 |
| 40 | L1-worker | claudeopus46 | 1,323 | 4,947 | 6,270 | 3,656 | 15.1 |
| 41 | L1-worker | claudeopus46 | 298 | 4,378 | 4,676 | 2,708 | 11.2 |
| 42 | L1-worker | claudeopus46 | 1,160 | 9,252 | 10,412 | 2,695 | 12.3 |
| 43 | L0-main | claudeopus46 | 19,988 | 29,663 | 49,651 | 631 | 5.6 |
| 44 | L0-main | claudeopus46 | 20,021 | 28,904 | 48,925 | 2,894 | 12.7 |
| 45 | L0-main | claudeopus46 | 20,021 | 29,516 | 49,537 | 2,561 | 10.1 |
| 46 | L0-main | claudeopus46 | 20,021 | 30,141 | 50,162 | 3,114 | 10.9 |
| 47 | L0-main | claudeopus46 | 19,988 | 31,476 | 51,464 | 504 | 4.1 |
| 48 | L0-main | claudeopus46 | 20,021 | 30,717 | 50,738 | 3,483 | 12.5 |
| 49 | L0-main | claudeopus46 | 20,021 | 31,948 | 51,969 | 4,853 | 34.2 |
| 50 | L0-main | claudeopus46 | 1,356 | 5,198 | 6,554 | 1,273 | 7.8 |
| 51 | L0-main | claudeopus46 | 1,323 | 57,735 | 59,058 | 1,346 | 9.6 |
| 52 | L0-main | claudeopus46 | 298 | 1,655 | 1,953 | 1,261 | 4.2 |
| 53 | L0-main | claudeopus46 | 298 | 2,188 | 2,486 | 1,172 | 5.3 |
| 54 | L0-main | claudeopus46 | 1,562 | 4,907 | 6,469 | 1,057 | 8.4 |


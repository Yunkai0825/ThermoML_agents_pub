# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 22,187 | 49,974 | 12,034 | 72,161 | 14,432 | 68.5 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| L1-worker | 10 | 70,319 | 67,975 | 13,174 | 138,294 | 13,829 | 79.7 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| L0-main | 8 | 41,695 | 99,645 | 16,952 | 141,340 | 17,667 | 95.7 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| L1-worker | 27 | 184,830 | 93,810 | 34,230 | 278,640 | 10,320 | 209.8 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| L0-main | 5 | 22,187 | 19,525 | 5,938 | 41,712 | 8,342 | 35.3 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| L1-worker | 21 | 204,469 | 118,634 | 21,144 | 323,103 | 15,385 | 162.3 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| L0-main | 6 | 31,792 | 53,470 | 11,336 | 85,262 | 14,210 | 70.6 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| L1-worker | 19 | 138,573 | 55,345 | 17,793 | 193,918 | 10,206 | 137.0 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| L0-main | 11 | 70,510 | 100,949 | 17,147 | 171,459 | 15,587 | 108.8 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| L1-worker | 55 | 413,208 | 191,934 | 57,747 | 605,142 | 11,002 | 382.2 | claudeopus46 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| **TOTAL** | **167** | **1,199,770** | **851,261** | **207,495** | **2,051,031** | **130,980** | **1,349.9** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| `search_blocks` | 2 | 1 | 3 | 2 | 5 | 5 | 193 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| `search_blocks` | 2 | 1 | 3 | 1 | 3 | 3 | 171 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| `search_blocks` | 27 | 1 | 6 | 2 | 19 | 50 | 1,102 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 95 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `search_blocks` | 19 | 1 | 5 | 2 | 13 | 24 | 1,264 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 13 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| **TOTAL** | **108** | **6** | **20** | **10** | **42** | **84** | **2,838** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | --- | --- |
| Unique Compounds | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Unique References | 5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Unique Properties | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Unique Measurements | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Unique Phases | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Unique Variables | 3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Unique Constraints | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Unique parent blocks | 5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Explicit block/subsystem targets | 5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Subsystem targets | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| Target-matched data points | 193 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| GLOBcomp_31 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBlit_2781 |  | search_blocks |
| GLOBlit_5953 |  | search_blocks |
| GLOBlit_11517 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique Compounds | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Unique References | 3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Unique Properties | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Unique Measurements | 3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Unique Phases | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Unique Variables | 3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Unique Constraints | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Unique parent blocks | 3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Explicit block/subsystem targets | 3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Subsystem targets | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| Target-matched data points | 171 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| GLOBcomp_2086 |  | resolve_compound_ids |
| GLOBcomp_342 |  | resolve_compound_ids |
| GLOBcomp_63 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_5038 |  | resolve_compound_ids |
| GLOBcomp_5696 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids |
| GLOBcomp_5047 | [bis(salicylidene)ethylenediaminato]oxovanadium | search_blocks |
| GLOBcomp_491 | 1-methyl-3-propylimidazolium bromide | search_blocks |
| GLOBcomp_264 | 1,2-dichlorobenzene | search_blocks |
| GLOBcomp_419 | 1,3-dichlorobenzene | search_blocks |
| GLOBcomp_728 | 1,2,4-trichlorobenzene | search_blocks |
| GLOBcomp_408 | 2-chlorotoluene | search_blocks |
| GLOBcomp_664 | 3-chlorotoluene | search_blocks |
| GLOBcomp_473 | 4-chlorotoluene | search_blocks |
| GLOBcomp_616 | 2-nitrotoluene | search_blocks |
| GLOBcomp_807 | 3-nitrotoluene | search_blocks |
| GLOBcomp_2160 | tetrabutylphosphonium tetrafluoroborate | search_blocks |
| GLOBcomp_376 | methyl methacrylate | search_blocks |
| GLOBcomp_1710 | 2,2'-[1,2-phenylenebis(nitrilomethylidyne)]bis-phenol | search_blocks |
| GLOBcomp_158 | 1-butyl-3-methylimidazolium bromide | search_blocks |
| GLOBcomp_1399 | N,N'-bis(2-pyridinylmethylene)-1,2-ethanediamine | search_blocks |
| GLOBcomp_185 | 1-hexyl-3-methylimidazolium chloride | search_blocks |
| GLOBcomp_6 | propan-2-ol | search_blocks |
| GLOBcomp_20 | butan-2-ol | search_blocks |
| GLOBcomp_84 | 1-ethyl-3-methylimidazolium tetrafluoroborate | search_blocks |
| GLOBcomp_4 | methanol | search_blocks |
| GLOBcomp_2 | ethanol | search_blocks |
| GLOBcomp_273 | 1-methyl-3-octylimidazolium chloride | search_blocks |
| GLOBcomp_25 | 1,4-dioxane | search_blocks |
| GLOBcomp_188 | 2-methylbutan-2-ol | search_blocks |
| GLOBcomp_10 | ethyl acetate | search_blocks |
| GLOBcomp_34 | octan-1-ol | search_blocks |
| GLOBlit_1030 |  | search_blocks |
| GLOBlit_1246 |  | search_blocks |
| GLOBlit_1676 |  | search_blocks |
| GLOBlit_3721 |  | search_blocks |
| GLOBlit_3813 |  | search_blocks |
| GLOBlit_3879 |  | search_blocks |
| GLOBlit_4251 |  | search_blocks |
| GLOBlit_5069 |  | search_blocks |
| GLOBlit_6204 |  | search_blocks |
| GLOBlit_6379 |  | search_blocks |
| GLOBlit_6710 |  | search_blocks |
| GLOBlit_6791 |  | search_blocks |
| GLOBlit_6959 |  | search_blocks |
| GLOBlit_7089 |  | search_blocks |
| GLOBlit_8387 |  | search_blocks |
| GLOBlit_8407 |  | search_blocks |
| GLOBlit_8831 |  | search_blocks |
| GLOBlit_9141 |  | search_blocks |
| GLOBlit_10315 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_6 | Solvent: Molality, mol/kg | search_blocks |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBsolvent_21 |  | search_blocks |
| GLOBsolvent_537 |  | search_blocks |
| GLOBsolvent_57 |  | search_blocks |
| GLOBsolvent_96 |  | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| Unique Compounds | 32 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique References | 19 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique Properties | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique Measurements | 4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique Phases | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique Variables | 6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique Solvents | 4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique Constraints | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Unique parent blocks | 50 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Explicit block/subsystem targets | 50 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Subsystem targets | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| Target-matched data points | 1,102 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| GLOBcomp_268 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_3079 |  | resolve_compound_ids |
| GLOBcomp_3578 |  | resolve_compound_ids |
| GLOBcomp_671 |  | resolve_compound_ids |
| GLOBcomp_1519 |  | resolve_compound_ids |
| GLOBcomp_47 |  | resolve_compound_ids |
| GLOBcomp_260 |  | resolve_compound_ids |
| GLOBcomp_1061 |  | resolve_compound_ids |
| GLOBcomp_2712 |  | resolve_compound_ids |
| GLOBcomp_8069 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBlit_8242 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique Compounds | 11 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Unique References | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Unique Properties | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Unique Measurements | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Unique Phases | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Unique Variables | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Unique Constraints | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Unique parent blocks | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Explicit block/subsystem targets | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Subsystem targets | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| Target-matched data points | 95 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| GLOBcomp_209 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_4457 |  | resolve_compound_ids |
| GLOBcomp_447 |  | resolve_compound_ids |
| GLOBcomp_4902 |  | resolve_compound_ids |
| GLOBcomp_5724 |  | resolve_compound_ids |
| GLOBcomp_7306 |  | resolve_compound_ids |
| GLOBcomp_6362 |  | resolve_compound_ids |
| GLOBcomp_6186 |  | resolve_compound_ids |
| GLOBcomp_2418 |  | resolve_compound_ids |
| GLOBcomp_7714 |  | resolve_compound_ids |
| GLOBcomp_342 | N-methylacetamide | search_blocks |
| GLOBcomp_50 | 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide | search_blocks |
| GLOBcomp_136 | 1-butyl-1-methylpyrrolidinium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_334 | 1-methyl-3-propylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_47 | N-methylpyrrolidone | search_blocks |
| GLOBcomp_340 | 1-butyl-1-methylpyrrolidinium dicyanamide | search_blocks |
| GLOBcomp_175 | 1-butyl-3-methylimidazolium dicyanamide | search_blocks |
| GLOBcomp_64 | 1-ethyl-3-methylimidazolium bis((trifluoromethyl)sulfonyl)imide | search_blocks |
| GLOBcomp_56 | 1-hexyl-3-methylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_138 | 1-octyl-3-methylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_830 | 1-ethyl-2,3-dimethylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_833 | 1,2-dimethyl-3-propylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_blocks |
| GLOBcomp_396 | 1-butyl-2,3-dimethyl-1H-imidazolium bis(trifluoromethylsulfonyl)amide | search_blocks |
| GLOBcomp_31 | dimethyl sulfoxide | search_blocks |
| GLOBcomp_915 | 1,3-dimethylimidazolium bis((trifluoromethyl)sulfonyl)amide | search_blocks |
| GLOBcomp_386 | diethyl butanedioate | search_blocks |
| GLOBcomp_1 | water | resolve_compound_ids, search_blocks |
| GLOBcomp_160 | tetrabutylammonium bromide | search_blocks |
| GLOBlit_2953 |  | search_blocks |
| GLOBlit_4141 |  | search_blocks |
| GLOBlit_4253 |  | search_blocks |
| GLOBlit_4456 |  | search_blocks |
| GLOBlit_4467 |  | search_blocks |
| GLOBlit_4468 |  | search_blocks |
| GLOBlit_4623 |  | search_blocks |
| GLOBlit_4658 |  | search_blocks |
| GLOBlit_4721 |  | search_blocks |
| GLOBlit_4962 |  | search_blocks |
| GLOBlit_5123 |  | search_blocks |
| GLOBlit_9316 |  | search_blocks |
| GLOBlit_10952 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_308 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_33 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_7 | Solvent: Mass fraction | search_blocks |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBsolvent_141 |  | search_blocks |
| GLOBsolvent_1 |  | search_blocks |
| Unique Compounds | 28 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique References | 13 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique Properties | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique Measurements | 5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique Phases | 1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique Variables | 5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique Constraints | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique Solvents | 2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Unique parent blocks | 24 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Explicit block/subsystem targets | 24 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Subsystem targets | 0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| Target-matched data points | 1,277 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| **TOTAL** | **3,178** |  |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1021/je050209y | PROPblock_9 | declared | 11 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 10.1021/je1008813 | PROPblock_3 | declared | 16 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 10.1021/je300608v | PROPblock_3 | declared | 60 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 10.1021/je700671t | PROPblock_3 | declared | 98 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 10.1021/je800330d | PROPblock_3 | declared | 8 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 10.1016/j.jct.2006.12.012 | 1 | 120 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |  |  |
| 10.1016/j.tca.2011.08.013 | 1 | 16 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |  |  |
| 10.1021/je9001027 | 1 | 35 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |  |  |
| 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 10.1016/j.tca.2011.08.013 | PROPblock_10 | declared | 16 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 10.1016/j.fluid.2011.10.026 | 4 | 48 | binary, ternary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.fluid.2013.05.001 | 1 | 1 | unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.fluid.2015.03.048 | 9 | 121 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.jct.2012.09.003 | 2 | 7 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.jct.2013.01.013 | 2 | 112 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.jct.2013.04.022 | 3 | 46 | binary, ternary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.jct.2014.09.022 | 4 | 70 | binary, ternary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.jct.2017.07.016 | 2 | 110 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.tca.2014.11.010 | 1 | 1 | unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.tca.2017.06.023 | 2 | 78 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/acs.jced.5b00753 | 2 | 48 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/acs.jced.5b01000 | 3 | 81 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/acs.jced.6b00575 | 1 | 13 | unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/acs.jced.7b00002 | 2 | 110 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/je049609w | 2 | 36 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/je049657g | 1 | 1 | unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/je050538q | 4 | 82 | binary, ternary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/je100170v | 2 | 36 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1021/je400917j | 3 | 101 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |  |  |
| 10.1016/j.fluid.2011.10.026 | PROPblock_2 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2011.10.026 | PROPblock_4 | declared | 36 | ternary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2011.10.026 | PROPblock_7 | declared | 8 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2011.10.026 | PROPblock_9 | declared | 3 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2013.05.001 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_2 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_22 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_26 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_30 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_34 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_38 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_42 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_46 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.fluid.2015.03.048 | PROPblock_50 | declared | 15 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2012.09.003 | PROPblock_14 | declared | 6 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2012.09.003 | PROPblock_5 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2013.01.013 | PROPblock_15 | declared | 105 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2013.01.013 | PROPblock_9 | declared | 7 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2013.04.022 | PROPblock_12 | declared | 9 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2013.04.022 | PROPblock_3 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2013.04.022 | PROPblock_8 | declared | 36 | ternary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2014.09.022 | PROPblock_11 | declared | 4 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2014.09.022 | PROPblock_2 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2014.09.022 | PROPblock_5 | declared | 55 | ternary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2014.09.022 | PROPblock_8 | declared | 10 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2017.07.016 | PROPblock_12 | declared | 99 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.jct.2017.07.016 | PROPblock_4 | declared | 11 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.tca.2014.11.010 | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.tca.2017.06.023 | PROPblock_12 | declared | 39 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1016/j.tca.2017.06.023 | PROPblock_16 | declared | 39 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.5b00753 | PROPblock_10 | declared | 44 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.5b00753 | PROPblock_4 | declared | 4 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.5b01000 | PROPblock_16 | declared | 39 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.5b01000 | PROPblock_20 | declared | 39 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.5b01000 | PROPblock_4 | declared | 3 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.6b00575 | PROPblock_13 | declared | 13 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.7b00002 | PROPblock_12 | declared | 99 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/acs.jced.7b00002 | PROPblock_4 | declared | 11 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je049609w | PROPblock_26 | declared | 3 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je049609w | PROPblock_54 | declared | 33 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je049657g | PROPblock_6 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je050538q | PROPblock_11 | declared | 21 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je050538q | PROPblock_14 | declared | 16 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je050538q | PROPblock_2 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je050538q | PROPblock_20 | declared | 44 | ternary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je100170v | PROPblock_17 | declared | 33 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je100170v | PROPblock_4 | declared | 3 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je400917j | PROPblock_14 | declared | 48 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je400917j | PROPblock_16 | declared | 48 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je400917j | PROPblock_2 | declared | 5 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10.1021/je0340809 | 1 | 95 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |  |  |
| 10.1021/je0340809 | PROPblock_14 | declared | 95 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 10.1016/j.jct.2008.05.004 | 2 | 48 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2014.03.025 | 2 | 84 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2014.10.002 | 2 | 72 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2015.07.048 | 1 | 84 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2015.08.013 | 1 | 66 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2015.08.014 | 2 | 67 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2016.02.014 | 1 | 70 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2016.03.034 | 3 | 238 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2016.06.012 | 3 | 273 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2017.02.009 | 2 | 12 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2017.10.004 | 1 | 78 | binary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1021/je100803e | 3 | 27 | binary, unary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1021/je7004903 | 1 | 145 | ternary | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |  |  |
| 10.1016/j.jct.2008.05.004 | PROPblock_13 | declared | 44 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2008.05.004 | PROPblock_4 | declared | 4 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2014.03.025 | PROPblock_5 | declared | 7 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2014.03.025 | PROPblock_8 | declared | 77 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2014.10.002 | PROPblock_5 | declared | 6 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2014.10.002 | PROPblock_8 | declared | 66 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2015.07.048 | PROPblock_5 | declared | 84 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2015.08.013 | PROPblock_5 | declared | 66 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2015.08.014 | PROPblock_6 | declared | 11 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2015.08.014 | PROPblock_8 | declared | 56 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2016.02.014 | PROPblock_4 | declared | 70 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2016.03.034 | PROPblock_11 | declared | 70 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2016.03.034 | PROPblock_7 | declared | 98 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2016.03.034 | PROPblock_9 | declared | 70 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2016.06.012 | PROPblock_11 | declared | 91 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2016.06.012 | PROPblock_7 | declared | 91 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2016.06.012 | PROPblock_9 | declared | 91 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2017.02.009 | PROPblock_4 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2017.02.009 | PROPblock_6 | declared | 11 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1016/j.jct.2017.10.004 | PROPblock_5 | declared | 78 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1021/je100803e | PROPblock_13 | declared | 1 | unary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1021/je100803e | PROPblock_25 | declared | 13 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1021/je100803e | PROPblock_32 | declared | 13 | binary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10.1021/je7004903 | PROPblock_1 | declared | 145 | ternary | — | search_blocks | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| **TOTAL** | **78** | **2,632** | **2,825** |  |  |  |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMF and wat… | 219 | KEEP | 219 | 3.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 2 | 2 | `search_blocks` | compound=['GLOBcomp_18', 'GLOBcomp_1'], limit=50, … | 1,280 | KEEP | 1280 | 21.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 3 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 270 | — | — | 77.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMSO and wa… | 284 | KEEP | 284 | 3.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 2 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 417 | — | — | 97.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 3 | 1 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve GLOBcomp ID… | 283 | KEEP | 283 | 4.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 4 | 2 | `L1_query` | context=Need to identify the correct …, id_catalog… | 1,573 | — | — | 27.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 5 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,222 | KEEP | 1222 | 16.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 6 | 3 | `L1_query` | context=Binary system search for dyna…, id_catalog… | 21,217 | — | — | 56.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMAc and wa… | 838 | KEEP | 838 | 13.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 2 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve water to GL… | 257 | KEEP | 257 | 4.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 3 | 3 | `search_blocks` | compound=['GLOBcomp_63', 'GLOBcomp_1'], limit=50, … | 911 | DISCARD | 853 | 8.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 4 | 4 | `search_blocks` | compound=['GLOBcomp_63', 'GLOBcomp_1'], limit=50, … | 635 | DISCARD | 577 | 15.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 5 | 5 | `search_blocks` | compound=['GLOBcomp_63', 'GLOBcomp_1'], limit=50, … | 833 | DISCARD | 775 | 9.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 6 | 5 | `search_blocks` | compound=GLOBcomp_63, limit=50, property=GLOBprop_… | 1,256 | KEEP | 1103 | 14.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 7 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_63 AS dmac…, explanat… | 738 | DISCARD | 677 | 110.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 8 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 3,234 | — | — | 268.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=40, purpose=Find the global co… | 394 | KEEP | 394 | 7.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 2 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 1,502 | — | — | 40.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 3 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve water to it… | 197 | KEEP | 197 | 4.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 4 | 2 | `search_blocks` | compound=['GLOBcomp_268', 'GLOBcomp_1'], limit=50,… | 1,026 | KEEP | 996 | 14.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 5 | 2 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 9,536 | — | — | 81.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve GBL and wa… | 520 | KEEP | 520 | 8.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 2 | 4 | `search_blocks` | compound=['GLOBcomp_209', 'GLOBcomp_7'], limit=50,… | 856 | DISCARD | 798 | 15.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 3 | 1 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 405 | — | — | 105.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 4 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve GBL and wa… | 502 | KEEP | 502 | 8.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 5 | 4 | `search_blocks` | compound=['GLOBcomp_209', 'GLOBcomp_9'], limit=50,… | 820 | DISCARD | 762 | 8.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 6 | 4 | `search_blocks` | compound=GLOBcomp_209, limit=50, property=GLOBprop… | 1,246 | KEEP | 1141 | 13.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 7 | 2 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 321 | — | — | 126.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 8 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Find the global com… | 197 | KEEP | 197 | 3.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 9 | 3 | `L1_query` | context=, id_catalog=, instruction=Look up the com… | 765 | — | — | 23.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Find the GLOBcomp … | 369 | KEEP | 369 | 6.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 11 | 4 | `L1_query` | context=, id_catalog=, instruction=Look up the com… | 1,088 | — | — | 33.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 12 | 2 | `search_blocks` | compound=['GLOBcomp_209', 'GLOBcomp_1'], limit=50,… | 1,109 | KEEP | 1094 | 18.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 13 | 5 | `L1_query` | context=Looking for aqueous aprotic s…, id_catalog… | 9,520 | — | — | 80.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 14 | 6 | `memory_catalog_add` | global_id=GLOBlit_9316, name=10.1021/je100803e, re… | 2 | — | — | 0.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| **TOTAL** | **92** |  |  | **65,842** |  | **15,338** | **1,354.7** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,014 | 10,619 | 1,406 | 8.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,347 | 21,990 | 725 | 5.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 3 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 466 | 3.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,096 | 22,739 | 921 | 6.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 5 | L1-worker | claudeopus46 | 2,065 | 7,639 | 9,704 | 1,626 | 14.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,898 | 24,541 | 2,264 | 12.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,395 | 3,751 | 907 | 5.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 8 | L1-worker | claudeopus46 | 536 | 2,275 | 2,811 | 904 | 5.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 9 | L1-worker | claudeopus46 | 1,323 | 6,150 | 7,473 | 2,578 | 10.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 10 | L1-worker | claudeopus46 | 298 | 3,300 | 3,598 | 2,000 | 8.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 11 | L1-worker | claudeopus46 | 747 | 38,399 | 39,146 | 783 | 8.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 12 | L0-main | claudeopus46 | 9,605 | 35,675 | 45,280 | 4,761 | 29.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 13 | L0-main | claudeopus46 | 1,356 | 4,000 | 5,356 | 1,317 | 7.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 14 | L0-main | claudeopus46 | 1,323 | 6,237 | 7,560 | 2,380 | 14.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 15 | L0-main | claudeopus46 | 298 | 3,048 | 3,346 | 2,170 | 8.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_10) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,014 | 10,619 | 1,514 | 7.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,280 | 21,923 | 655 | 5.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,556 | 23,199 | 7,372 | 32.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 4 | L1-worker | claudeopus46 | 2,065 | 478 | 2,543 | 445 | 3.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,763 | 23,406 | 4,075 | 23.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 6 | L1-worker | claudeopus46 | 20,643 | 7,459 | 28,102 | 1,574 | 6.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 7 | L1-worker | claudeopus46 | 1,356 | 1,451 | 2,807 | 652 | 5.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 8 | L1-worker | claudeopus46 | 536 | 1,331 | 1,867 | 831 | 5.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 9 | L1-worker | claudeopus46 | 1,323 | 3,822 | 5,145 | 1,698 | 7.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 10 | L1-worker | claudeopus46 | 298 | 2,420 | 2,718 | 1,318 | 5.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 11 | L1-worker | claudeopus46 | 1,160 | 5,998 | 7,158 | 1,674 | 6.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 12 | L1-worker | claudeopus46 | 298 | 2,396 | 2,694 | 1,303 | 5.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 13 | L0-main | claudeopus46 | 9,605 | 1,933 | 11,538 | 1,152 | 7.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 14 | L1-worker | claudeopus46 | 20,643 | 962 | 21,605 | 596 | 5.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 15 | L1-worker | claudeopus46 | 2,065 | 509 | 2,574 | 444 | 4.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 16 | L1-worker | claudeopus46 | 20,643 | 1,695 | 22,338 | 482 | 4.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 17 | L1-worker | claudeopus46 | 1,356 | 611 | 1,967 | 324 | 4.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 18 | L1-worker | claudeopus46 | 1,323 | 2,240 | 3,563 | 234 | 5.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 19 | L1-worker | claudeopus46 | 536 | 491 | 1,027 | 345 | 5.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 20 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 2.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 21 | L1-worker | claudeopus46 | 747 | 2,761 | 3,508 | 416 | 5.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 22 | L0-main | claudeopus46 | 9,605 | 5,802 | 15,407 | 1,704 | 11.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,212 | 23,855 | 912 | 7.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 24 | L1-worker | claudeopus46 | 2,065 | 7,540 | 9,605 | 1,585 | 15.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 25 | L1-worker | claudeopus46 | 20,643 | 4,949 | 25,592 | 2,020 | 11.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,957 | 3,313 | 737 | 4.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 27 | L1-worker | claudeopus46 | 536 | 1,837 | 2,373 | 852 | 5.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 28 | L1-worker | claudeopus46 | 1,323 | 5,098 | 6,421 | 1,555 | 7.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 29 | L1-worker | claudeopus46 | 298 | 2,277 | 2,575 | 1,230 | 6.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 30 | L1-worker | claudeopus46 | 747 | 24,761 | 25,508 | 747 | 7.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 31 | L0-main | claudeopus46 | 9,605 | 48,901 | 58,506 | 3,648 | 24.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 32 | L0-main | claudeopus46 | 1,356 | 3,514 | 4,870 | 1,025 | 6.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 33 | L0-main | claudeopus46 | 298 | 1,407 | 1,705 | 1,013 | 4.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 34 | L0-main | claudeopus46 | 1,323 | 32,602 | 33,925 | 3,804 | 21.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 35 | L0-main | claudeopus46 | 298 | 4,472 | 4,770 | 3,092 | 12.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_9) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,017 | 10,622 | 1,379 | 7.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,260 | 21,903 | 730 | 6.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 3 | L1-worker | claudeopus46 | 2,065 | 807 | 2,872 | 1,733 | 12.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,594 | 23,237 | 482 | 4.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 5 | L1-worker | claudeopus46 | 2,065 | 365 | 2,430 | 480 | 4.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,287 | 23,930 | 970 | 6.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 7 | L1-worker | claudeopus46 | 2,065 | 592 | 2,657 | 1,259 | 8.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 8 | L1-worker | claudeopus46 | 20,610 | 5,486 | 26,096 | 655 | 4.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,733 | 25,376 | 734 | 6.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 10 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 1,297 | 8.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,887 | 26,530 | 1,312 | 8.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 12 | L1-worker | claudeopus46 | 2,065 | 505 | 2,570 | 1,328 | 8.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 13 | L1-worker | claudeopus46 | 2,065 | 31,534 | 33,599 | 1,509 | 13.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 14 | L1-worker | claudeopus46 | 20,643 | 8,621 | 29,264 | 1,956 | 13.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 15 | L1-worker | claudeopus46 | 20,643 | 9,533 | 30,176 | 945 | 10.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 16 | L1-worker | claudeopus46 | 2,065 | 1,018 | 3,083 | 1,112 | 8.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 17 | L1-worker | claudeopus46 | 20,643 | 10,518 | 31,161 | 2,421 | 19.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 18 | L1-worker | claudeopus46 | 1,323 | 12,713 | 14,036 | 308 | 3.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,599 | 2,955 | 535 | 3.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 20 | L1-worker | claudeopus46 | 536 | 1,479 | 2,015 | 652 | 4.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 21 | L1-worker | claudeopus46 | 298 | 1,030 | 1,328 | 202 | 2.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 22 | L1-worker | claudeopus46 | 747 | 14,597 | 15,344 | 524 | 5.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 23 | L0-main | claudeopus46 | 9,605 | 8,270 | 17,875 | 1,910 | 11.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 24 | L0-main | claudeopus46 | 1,356 | 1,638 | 2,994 | 678 | 6.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 25 | L0-main | claudeopus46 | 1,323 | 6,856 | 8,179 | 1,076 | 6.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 26 | L0-main | claudeopus46 | 298 | 1,744 | 2,042 | 895 | 3.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,041 | 10,646 | 1,127 | 7.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 2 | L1-worker | claudeopus46 | 20,643 | 914 | 21,557 | 721 | 7.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,256 | 22,899 | 1,518 | 8.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 4 | L1-worker | claudeopus46 | 2,065 | 1,194 | 3,259 | 786 | 6.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,561 | 23,204 | 606 | 5.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 6 | L1-worker | claudeopus46 | 1,323 | 2,701 | 4,024 | 164 | 2.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 7 | L1-worker | claudeopus46 | 1,356 | 737 | 2,093 | 175 | 2.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 8 | L1-worker | claudeopus46 | 536 | 617 | 1,153 | 441 | 3.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 9 | L1-worker | claudeopus46 | 298 | 886 | 1,184 | 110 | 4.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 10 | L1-worker | claudeopus46 | 747 | 3,199 | 3,946 | 474 | 4.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 11 | L0-main | claudeopus46 | 9,605 | 4,693 | 14,298 | 1,586 | 12.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 12 | L1-worker | claudeopus46 | 20,643 | 3,125 | 23,768 | 691 | 5.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 13 | L1-worker | claudeopus46 | 2,065 | 352 | 2,417 | 420 | 4.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 14 | L1-worker | claudeopus46 | 20,643 | 3,790 | 24,433 | 4,801 | 26.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 15 | L1-worker | claudeopus46 | 2,065 | 3,744 | 5,809 | 1,425 | 13.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 16 | L1-worker | claudeopus46 | 20,643 | 5,364 | 26,007 | 1,754 | 12.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 17 | L1-worker | claudeopus46 | 1,323 | 5,398 | 6,721 | 766 | 5.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 18 | L1-worker | claudeopus46 | 536 | 1,765 | 2,301 | 922 | 5.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,885 | 3,241 | 603 | 7.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 20 | L1-worker | claudeopus46 | 298 | 1,488 | 1,786 | 610 | 4.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 21 | L1-worker | claudeopus46 | 747 | 13,369 | 14,116 | 806 | 7.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 22 | L0-main | claudeopus46 | 9,605 | 24,460 | 34,065 | 2,740 | 19.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 23 | L0-main | claudeopus46 | 1,356 | 2,681 | 4,037 | 941 | 5.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 24 | L0-main | claudeopus46 | 1,323 | 17,213 | 18,536 | 2,714 | 16.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 25 | L0-main | claudeopus46 | 298 | 3,382 | 3,680 | 2,228 | 9.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_12) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,012 | 10,617 | 1,513 | 9.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,406 | 22,049 | 663 | 7.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,690 | 23,333 | 5,255 | 24.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 4 | L1-worker | claudeopus46 | 2,065 | 1,312 | 3,377 | 1,000 | 7.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,157 | 23,800 | 4,908 | 25.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 6 | L1-worker | claudeopus46 | 20,643 | 8,686 | 29,329 | 715 | 4.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 7 | L1-worker | claudeopus46 | 2,065 | 533 | 2,598 | 1,263 | 8.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 8 | L1-worker | claudeopus46 | 20,643 | 9,455 | 30,098 | 702 | 3.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 9 | L1-worker | claudeopus46 | 1,356 | 833 | 2,189 | 246 | 2.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,955 | 6,278 | 238 | 3.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 11 | L1-worker | claudeopus46 | 536 | 713 | 1,249 | 537 | 3.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 12 | L1-worker | claudeopus46 | 298 | 960 | 1,258 | 158 | 2.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 13 | L1-worker | claudeopus46 | 747 | 5,372 | 6,119 | 350 | 4.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 14 | L1-worker | claudeopus46 | 1,160 | 5,663 | 6,823 | 158 | 2.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 15 | L1-worker | claudeopus46 | 747 | 5,372 | 6,119 | 311 | 4.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 16 | L0-main | claudeopus46 | 9,605 | 1,928 | 11,533 | 1,319 | 8.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 17 | L1-worker | claudeopus46 | 20,643 | 1,335 | 21,978 | 684 | 5.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,640 | 23,283 | 5,061 | 24.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 19 | L1-worker | claudeopus46 | 2,065 | 1,282 | 3,347 | 927 | 8.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 20 | L1-worker | claudeopus46 | 20,643 | 3,065 | 23,708 | 4,462 | 22.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 21 | L1-worker | claudeopus46 | 20,643 | 8,148 | 28,791 | 2,123 | 7.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 22 | L1-worker | claudeopus46 | 2,065 | 461 | 2,526 | 1,236 | 7.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 23 | L1-worker | claudeopus46 | 2,065 | 16,356 | 18,421 | 1,510 | 12.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 24 | L1-worker | claudeopus46 | 20,643 | 10,347 | 30,990 | 3,222 | 20.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 25 | L1-worker | claudeopus46 | 1,323 | 6,820 | 8,143 | 238 | 2.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 26 | L1-worker | claudeopus46 | 536 | 1,226 | 1,762 | 512 | 3.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 27 | L1-worker | claudeopus46 | 1,356 | 1,346 | 2,702 | 531 | 3.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 28 | L1-worker | claudeopus46 | 298 | 960 | 1,258 | 158 | 2.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 29 | L1-worker | claudeopus46 | 747 | 8,094 | 8,841 | 227 | 5.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 30 | L1-worker | claudeopus46 | 1,160 | 7,405 | 8,565 | 158 | 2.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 31 | L1-worker | claudeopus46 | 747 | 8,094 | 8,841 | 227 | 3.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 32 | L0-main | claudeopus46 | 9,605 | 2,783 | 12,388 | 937 | 6.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 33 | L1-worker | claudeopus46 | 20,643 | 700 | 21,343 | 516 | 5.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 34 | L1-worker | claudeopus46 | 2,065 | 371 | 2,436 | 394 | 3.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 35 | L1-worker | claudeopus46 | 20,643 | 1,355 | 21,998 | 174 | 3.0 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 36 | L1-worker | claudeopus46 | 1,356 | 305 | 1,661 | 173 | 2.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 37 | L1-worker | claudeopus46 | 536 | 185 | 721 | 165 | 2.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 38 | L1-worker | claudeopus46 | 1,323 | 1,517 | 2,840 | 162 | 2.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 39 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 4.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 40 | L1-worker | claudeopus46 | 747 | 1,492 | 2,239 | 305 | 3.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 41 | L0-main | claudeopus46 | 9,605 | 4,945 | 14,550 | 660 | 5.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 42 | L1-worker | claudeopus46 | 20,643 | 1,617 | 22,260 | 654 | 5.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 43 | L1-worker | claudeopus46 | 20,643 | 2,892 | 23,535 | 1,834 | 9.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 44 | L1-worker | claudeopus46 | 2,065 | 1,315 | 3,380 | 618 | 5.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 45 | L1-worker | claudeopus46 | 20,643 | 3,144 | 23,787 | 267 | 2.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 46 | L1-worker | claudeopus46 | 1,323 | 2,201 | 3,524 | 164 | 2.2 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 47 | L1-worker | claudeopus46 | 1,356 | 396 | 1,752 | 249 | 2.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 48 | L1-worker | claudeopus46 | 536 | 276 | 812 | 288 | 2.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 49 | L1-worker | claudeopus46 | 298 | 886 | 1,184 | 110 | 2.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 50 | L1-worker | claudeopus46 | 747 | 2,455 | 3,202 | 371 | 4.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 51 | L0-main | claudeopus46 | 9,605 | 7,688 | 17,293 | 1,604 | 10.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 52 | L1-worker | claudeopus46 | 20,643 | 3,477 | 24,120 | 1,046 | 6.3 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 53 | L1-worker | claudeopus46 | 20,643 | 5,144 | 25,787 | 4,841 | 24.9 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 54 | L1-worker | claudeopus46 | 2,065 | 2,533 | 4,598 | 1,605 | 11.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 55 | L1-worker | claudeopus46 | 20,643 | 6,205 | 26,848 | 2,413 | 13.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 56 | L1-worker | claudeopus46 | 536 | 1,850 | 2,386 | 752 | 4.4 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 57 | L1-worker | claudeopus46 | 1,323 | 5,281 | 6,604 | 740 | 4.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 58 | L1-worker | claudeopus46 | 1,356 | 1,970 | 3,326 | 877 | 6.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 59 | L1-worker | claudeopus46 | 298 | 1,462 | 1,760 | 613 | 5.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 60 | L1-worker | claudeopus46 | 747 | 13,335 | 14,082 | 528 | 6.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 61 | L0-main | claudeopus46 | 9,605 | 27,376 | 36,981 | 3,234 | 23.1 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 62 | L0-main | claudeopus46 | 9,605 | 28,045 | 37,650 | 2,514 | 16.8 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 63 | L0-main | claudeopus46 | 1,356 | 2,645 | 4,001 | 1,007 | 5.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 64 | L0-main | claudeopus46 | 298 | 1,389 | 1,687 | 995 | 4.7 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 65 | L0-main | claudeopus46 | 1,323 | 20,650 | 21,973 | 1,820 | 12.5 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| 66 | L0-main | claudeopus46 | 298 | 2,488 | 2,786 | 1,544 | 5.6 | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_13) |
| **TOTAL** |  |  | **1,199,770** | **851,261** | **2,051,031** | **207,495** | **1,349.9** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 4,191 | 4,191 | 0 | 0.0% | Find all data blocks containing dynamic viscosity (GLOBprop_ (query_runs/run_11) |
| **TOTAL** |  |  | **4,191** | **4,191** | **0** | **0** |  |

# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:28:17
**Wall time (at last flush):** 547.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 16 | 225,035 | 145,450 | 26,864 | 370,485 | 23,155 | 170.9 | claudeopus46 |
| L1-worker | 28 | 229,178 | 175,865 | 73,707 | 405,043 | 14,465 | 397.1 | claudeopus46 |
| **TOTAL** | **44** | **454,213** | **321,315** | **100,571** | **775,528** | **17,625** | **568.0** | |

**Estimated tokens:** ~193,882 input + ~25,142 output = ~219,024 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | instruction=Search for blocks with: compo…, purpos… | 482 | — | — | 259.7 |
| 2 | 2 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 282 | — | — | 123.7 |
| 3 | 5 | `inspect_block` | block_number=PROPblock_21, doi=10.1016/j.jct.2018.… | 1,363 | — | — | 0.1 |
| 4 | 5 | `inspect_block` | block_number=PROPblock_11, doi=10.1016/j.jct.2007.… | 1,338 | — | — | 0.1 |
| 5 | 8 | `fit_multi_system` | purpose=Fit ethanol+water viscosity a…, systems=[{… | 2,136 | — | — | 3.3 |
| 6 | 9 | `predict_from_rk` | coeffs=[2.77791, -2.36884, 2.91661, …, mixing_rule… | 213 | — | — | 0.0 |
| 7 | 9 | `predict_from_rk` | coeffs=[2.728, -2.49259, 2.55005, -2…, mixing_rule… | 213 | — | — | 0.0 |
| 8 | 9 | `predict_from_rk` | coeffs=[2.47975, -2.12, 2.38699, -3.…, mixing_rule… | 215 | — | — | 0.0 |
| 9 | 9 | `predict_from_rk` | coeffs=[2.33015, -1.95628, 2.03149, …, mixing_rule… | 214 | — | — | 0.0 |
| | | **TOTAL (9 tools)** | | **6,456** | | **0** | **386.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 11,363 | 11,363 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 339 | 20,360 | 1,483 | 10.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 666 | 21,309 | 722 | 5.6 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,009 | 22,652 | 13,452 | 51.1 |
| 4 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 3.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,156 | 22,799 | 9,517 | 41.7 |
| 6 | L1-worker | claudeopus46 | 2,065 | 9,371 | 11,436 | 1,691 | 13.8 |
| 7 | L1-worker | claudeopus46 | 2,065 | 9,581 | 11,646 | 1,703 | 14.5 |
| 8 | L1-worker | claudeopus46 | 20,610 | 3,582 | 24,192 | 530 | 3.7 |
| 9 | L1-worker | claudeopus46 | 20,643 | 2,810 | 23,453 | 606 | 4.0 |
| 10 | L1-worker | claudeopus46 | 2,065 | 9,254 | 11,319 | 1,623 | 12.7 |
| 11 | L1-worker | claudeopus46 | 20,643 | 4,496 | 25,139 | 6,755 | 42.1 |
| 12 | L1-worker | claudeopus46 | 20,643 | 11,826 | 32,469 | 2,627 | 13.5 |
| 13 | L1-worker | claudeopus46 | 1,356 | 2,758 | 4,114 | 904 | 6.3 |
| 14 | L1-worker | claudeopus46 | 536 | 2,638 | 3,174 | 918 | 6.7 |
| 15 | L1-worker | claudeopus46 | 298 | 1,286 | 1,584 | 892 | 3.7 |
| 16 | L1-worker | claudeopus46 | 1,323 | 7,189 | 8,512 | 3,262 | 15.3 |
| 17 | L1-worker | claudeopus46 | 298 | 3,984 | 4,282 | 2,460 | 10.9 |
| 18 | L1-worker | claudeopus46 | 1,160 | 10,918 | 12,078 | 2,501 | 11.5 |
| 19 | L0-main | claudeopus46 | 20,021 | 1,312 | 21,333 | 945 | 6.8 |
| 20 | L1-worker | claudeopus46 | 20,643 | 602 | 21,245 | 1,124 | 6.7 |
| 21 | L1-worker | claudeopus46 | 2,065 | 8,154 | 10,219 | 1,771 | 14.4 |
| 22 | L1-worker | claudeopus46 | 20,643 | 1,527 | 22,170 | 5,399 | 30.1 |
| 23 | L1-worker | claudeopus46 | 2,065 | 6,369 | 8,434 | 1,539 | 13.0 |
| 24 | L1-worker | claudeopus46 | 20,643 | 3,489 | 24,132 | 2,396 | 15.5 |
| 25 | L1-worker | claudeopus46 | 1,356 | 2,527 | 3,883 | 714 | 4.8 |
| 26 | L1-worker | claudeopus46 | 536 | 2,407 | 2,943 | 1,150 | 9.6 |
| 27 | L1-worker | claudeopus46 | 1,323 | 6,380 | 7,703 | 3,342 | 14.3 |
| 28 | L1-worker | claudeopus46 | 298 | 4,064 | 4,362 | 2,621 | 10.5 |
| 29 | L1-worker | claudeopus46 | 1,160 | 10,115 | 11,275 | 2,269 | 9.4 |
| 30 | L1-worker | claudeopus46 | 747 | 45,270 | 46,017 | 807 | 8.0 |
| 31 | L0-main | claudeopus46 | 20,021 | 3,960 | 23,981 | 1,146 | 7.7 |
| 32 | L0-main | claudeopus46 | 20,021 | 4,921 | 24,942 | 816 | 5.3 |
| 33 | L0-main | claudeopus46 | 20,021 | 5,914 | 25,935 | 771 | 5.5 |
| 34 | L0-main | claudeopus46 | 20,021 | 9,273 | 29,294 | 2,926 | 19.4 |
| 35 | L0-main | claudeopus46 | 20,021 | 10,024 | 30,045 | 2,301 | 11.6 |
| 36 | L0-main | claudeopus46 | 20,021 | 10,716 | 30,737 | 2,517 | 12.3 |
| 37 | L0-main | claudeopus46 | 20,021 | 17,961 | 37,982 | 2,061 | 10.8 |
| 38 | L0-main | claudeopus46 | 19,988 | 20,726 | 40,714 | 466 | 6.5 |
| 39 | L0-main | claudeopus46 | 20,021 | 19,967 | 39,988 | 3,823 | 29.2 |
| 40 | L0-main | claudeopus46 | 1,356 | 3,952 | 5,308 | 1,159 | 7.9 |
| 41 | L0-main | claudeopus46 | 298 | 1,541 | 1,839 | 1,147 | 4.2 |
| 42 | L0-main | claudeopus46 | 1,323 | 26,273 | 27,596 | 2,389 | 15.2 |
| 43 | L0-main | claudeopus46 | 298 | 3,231 | 3,529 | 1,868 | 9.0 |
| 44 | L0-main | claudeopus46 | 1,562 | 5,340 | 6,902 | 1,046 | 9.0 |


# Analysis Run — 20260802_203725 (Round 1)

**Question:** At 25 °C, at what ethanol mole fraction is the viscosity of liquid ethanol + water greatest, and how does that composition shift as temperature rises?

**Time:** 514.0s | **Iterations:** 10 | **Tools:** 15

---

## Answer

## Viscosity Maximum of Liquid Ethanol + Water and Its Temperature Shift

### Key Finding

At 25 °C (298.15 K), the dynamic viscosity of the ethanol–water binary mixture reaches its **maximum at an ethanol mole fraction of x_EtOH ≈ 0.24**, corresponding to a viscosity of **2.414 × 10⁻³ Pa·s** — roughly 2.7 times the viscosity of pure water (0.897 × 10⁻³ Pa·s) and 2.2 times that of pure ethanol (1.091 × 10⁻³ Pa·s) at the same temperature.

This dramatic non-ideal enhancement arises from the strong hydrogen-bonding network that forms between ethanol and water molecules. Near x_EtOH ≈ 0.2–0.3, ethanol molecules are thought to reinforce and restructure the water hydrogen-bond network rather than simply disrupting it, creating long-lived, cage-like hydration structures (clathrate-like microheterogeneity) that resist shear flow.

### Temperature Dependence of the Peak Composition

As temperature increases, the viscosity maximum **shifts to slightly higher ethanol mole fractions**:

| Temperature (K) | Peak x_EtOH | Peak Viscosity (mPa·s) | Max ln-excess |
|:---:|:---:|:---:|:---:|
| 293.15 | **0.230** | 2.918 | 0.979 |
| 298.15 | **0.240** | 2.414 | 0.945 |
| 303.15 | **0.245** | 2.045 | 0.852 |
| 308.15 | **0.250** | 1.734 | 0.784 |

Over the 15 K range studied, the peak shifts from x_EtOH = 0.23 to 0.25 — a modest but systematic increase of about Δx ≈ +0.001 per kelvin. Simultaneously, the peak viscosity drops by ~40% and the magnitude of the excess (in ln-space, reflecting the Arrhenius mixing rule) decreases from 0.98 to 0.78, indicating that thermal energy progressively disrupts the cooperative hydrogen-bonding structures responsible for the anomalous viscosity enhancement.

### Physical Interpretation

- **Low temperature (293 K):** The H-bond network is strongest; even a relatively small amount of ethanol (x ≈ 0.23) maximally enhances the structured water environment.
- **Higher temperature (308 K):** Thermal fluctuations weaken the network, so a slightly higher ethanol concentration (x ≈ 0.25) is needed to achieve the (now reduced) maximum structuring effect.
- The composition x ≈ 0.24 at 25 °C corresponds roughly to a 1:3 ethanol:water molar ratio, consistent with models where each ethanol molecule is surrounded by approximately 3 water molecules in a locally ordered solvation shell.

### Redlich-Kister Fit Details

All fits used the **Arrhenius mixing rule** (ln η is fitted) with BIC-selected polynomial order. Data source: DOI [10.1016/j.jct.2018.02.022](https://doi.org/10.1016/j.jct.2018.02.022) (GLOBlit_5201), block PROPblock_21, 100 data points across 4 isotherms (23–25 points each), full mole-fraction range 0–1, at 92.3 kPa.

| T (K) | RK Order | R² | RMSE | Pure η_EtOH (Pa·s) | Pure η_H₂O (Pa·s) | RK Coefficients |
|:---:|:---:|:---:|:---:|:---:|:---:|:---|
| 293.15 | 5 | 0.99687 | 0.01495 | 1.202×10⁻³ | 1.067×10⁻³ | [2.778, −2.369, 2.917, −4.225, 0.925, 2.756] |
| 298.15 | 4 | 0.99933 | 0.00661 | 1.091×10⁻³ | 0.897×10⁻³ | [2.728, −2.493, 2.550, −2.448, 1.536] |
| 303.15 | 5 | 0.99833 | 0.00948 | 0.992×10⁻³ | 0.839×10⁻³ | [2.480, −2.120, 2.387, −3.144, 0.855, 1.730] |
| 308.15 | 5 | 0.99754 | 0.01067 | 0.904×10⁻³ | 0.759×10⁻³ | [2.330, −1.956, 2.031, −2.816, 0.892, 1.575] |

Pure-component endpoint values were extracted directly from the block edges at each isotherm (quality: good for both components at all temperatures).

### Summary

The ethanol–water viscosity maximum at 25 °C occurs at **x_EtOH ≈ 0.24** (≈ 52 wt% ethanol). As temperature rises from 293 to 308 K, this peak shifts modestly toward higher ethanol content (x_EtOH ≈ 0.23 → 0.25) while the peak viscosity and excess both decrease, reflecting the thermal weakening of the cooperative hydrogen-bonding microstructure that drives the anomalous viscosity enhancement.

### Core claims

- At 298.15 K and 92.3 kPa, the dynamic viscosity of the ethanol–water binary mixture reaches a maximum of approximately 2.414 × 10⁻³ Pa·s at an ethanol mole fraction of about 0.24, roughly 2.7 times the viscosity of pure water.
- Over the temperature range 293–308 K, the composition at which the viscosity maximum occurs shifts systematically to slightly higher ethanol mole fractions (from x_EtOH ≈ 0.23 to ≈ 0.25), at a rate of approximately +0.001 per kelvin.
- As temperature increases from 293 to 308 K, the peak viscosity decreases by about 40% and the ln-excess viscosity magnitude decreases from ~0.98 to ~0.78, indicating progressive thermal disruption of cooperative hydrogen-bonding structures responsible for the anomalous viscosity enhancement.
- The viscosity maximum near x_EtOH ≈ 0.24 (a ~1:3 ethanol-to-water molar ratio) is attributed to strong hydrogen-bonding interactions that create long-lived, clathrate-like hydration structures resisting shear flow.
- Redlich-Kister fits using the Arrhenius mixing rule (orders 4–5, selected by BIC) achieved R² values of 0.997–0.999 across all four isotherms studied.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 |  | Binary ethanol + water dynamic viscosity (GLOBprop_4, BLKprop_1) measured by concentric cylinders viscometry (GLOBmeas_11) in the liquid phase (GLOBphase_1). 100 data points spanning mole_fraction_<ethanol> 0–1 at four isotherms (293.15, 298.15, 303.15, 308.15 K) and 92.3 kPa. Compounds: ethanol (GLOBcomp_2), water (GLOBcomp_1). Pure-component endpoint viscosities extracted from block edges (quality: good for both components at all temperatures). |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_21 | viscosity_pa_s | 5 | 2.77791; -2.36884; 2.91661; -4.2245; 0.924678; 2.75595 | 0.99687 | 0.0149466 | 23 | 293.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_21 | viscosity_pa_s | 4 | 2.728; -2.49259; 2.55005; -2.44775; 1.53644 | 0.999334 | 0.00661284 | 23 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_21 | viscosity_pa_s | 5 | 2.47975; -2.12; 2.38699; -3.14437; 0.855239; 1.73 | 0.998334 | 0.00948398 | 23 | 303.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_5201 | PROPblock_21 | viscosity_pa_s | 5 | 2.33015; -1.95628; 2.03149; -2.8161; 0.891963; 1.5752 | 0.997541 | 0.0106696 | 23 | 308.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |

---

## Verdict

**Data Quality**
Real mixture viscosity data from a ThermoML source (DOI 10.1016/j.jct.2018.02.022) were used, with fit_multi_system confirmed in the trace — no fabrication. Pure-component values extracted from block edges are appropriate. The Arrhenius mixing rule (ln η fitted) is the correct approach for viscosity, and the excess is properly defined in ln-space. Data appear to be in mole fraction; no basis conversion issues noted. 100 points across 4 isotherms is adequate.

**Fit Quality**
R² values (0.997–0.999) are excellent. RK orders 4–5 are reasonable for the strongly asymmetric viscosity excess of ethanol–water. No overfitting concerns given ~25 points per isotherm.

**Scientific Verdict**
The peak at x_EtOH ≈ 0.24 at 25 °C is consistent with well-established literature values (~0.2–0.3). The modest shift to higher ethanol content with increasing temperature is physically reasonable and well-supported. The structural interpretation involving clathrate-like hydration is appropriate. Results are reliable and well-documented.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\data\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817\plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
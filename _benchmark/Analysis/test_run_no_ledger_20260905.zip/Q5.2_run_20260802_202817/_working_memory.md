# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.2_run_20260802_202817`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_2 | ethanol |  |
| comp | GLOBcomp_1 | water |  |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [fit_multi_system]
- [predict_from_rk]
- [predict_from_rk]
- [predict_from_rk]
- [predict_from_rk]

### Query Results
#### query
Binary ethanol (GLOBcomp_2) + water (GLOBcomp_1) dynamic viscosity (GLOBprop_4) data blocks from ThermoML were identified, focusing on composition sweeps at multiple temperatures near 298.15 K. The top candidate is GLOBlit_5201 (DOI 10.1016/j.jct.2018.02.022), PROPblock_21, with 100 data points spanning 293.15–308.15 K at 92.3 kPa over a full mole-fraction range (x = 0.0–1.0). The second-best is GLOBlit_11136 (DOI 10.1021/je800150h) with 108 data points across a broad temperature range including near 298.15 K. A supplementary source is GLOBlit_2825 (DOI 10.1016/j.jct.2007.05.004), PROPblock_11, with 37 points at 293.15–303.15 K and 101.0 kPa over the full mole-fraction range. Other blocks were less suitable: GLOBlit_10159 uses molality (14.0–22.0 mol/kg) rather than a full mole-fraction sweep; GLOBlit_8949 covers only partial volume-fraction range at 303.15–323.15 K; GLOBlit_1742 and GLOBlit_2092 are at high temperatures and pressures far from ambient. The recommended datasets for near-ambient composition-sweep viscosity studies are GLOBlit_5201, GLOBlit_11136, and GLOBlit_2825, all using mole fraction spanning 0 to 1.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 | declared | 100 | binary | binary |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11 | declared | 37 | binary | binary |
| GLOBlit_10159 | 10.1021/je4003515 | PROPblock_8 | declared | 25 | binary | binary |
| GLOBlit_8949 | 10.1021/je060219e | PROPblock_1 | declared | 26 | binary | binary |
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_4 | declared | 84 | binary | binary |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_4 | declared | 72 | binary | binary |

### Inspected Blocks
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21: 100 rows; x=['mole_fraction_<ethanol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11: 37 rows; x=['mole_fraction_<water>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - EtOH-Water-293K [10.1016/j.jct.2018.02.022/PROPblock_21] (ethanol, water): RK order=5, R²=0.99687, RMSE=0.014946647676868378, coeffs=[2.777909, -2.368838, 2.916612, -4.224496, 0.924678, 2.755948]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: ethanol=0.0012019, water=0.0010673 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_excess.png
  - EtOH-Water-298K [10.1016/j.jct.2018.02.022/PROPblock_21] (ethanol, water): RK order=4, R²=0.999334, RMSE=0.006612838327445672, coeffs=[2.727996, -2.492594, 2.550047, -2.44775, 1.536444]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: ethanol=0.0010914, water=0.00089689 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.png
  - EtOH-Water-303K [10.1016/j.jct.2018.02.022/PROPblock_21] (ethanol, water): RK order=5, R²=0.998334, RMSE=0.00948397542567419, coeffs=[2.479754, -2.120004, 2.386992, -3.144373, 0.855239, 1.730003]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: ethanol=0.00099196, water=0.0008385 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_excess.png
  - EtOH-Water-308K [10.1016/j.jct.2018.02.022/PROPblock_21] (ethanol, water): RK order=5, R²=0.997541, RMSE=0.010669590029158437, coeffs=[2.33015, -1.956282, 2.031489, -2.8161, 0.891963, 1.575202]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: ethanol=0.00090388, water=0.00075887 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1

### plot
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T293.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T293.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T308.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T308.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T303.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T303.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1


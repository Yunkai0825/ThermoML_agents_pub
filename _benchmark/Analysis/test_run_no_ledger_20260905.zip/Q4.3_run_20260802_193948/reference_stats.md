# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:39:48
**Wall time (at last flush):** 891.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 31 | 525,251 | 533,761 | 58,680 | 1,059,012 | 34,161 | 358.9 | claudeopus46 |
| L1-worker | 28 | 248,661 | 204,881 | 117,610 | 453,542 | 16,197 | 544.8 | claudeopus46 |
| **TOTAL** | **59** | **773,912** | **738,642** | **176,290** | **1,512,554** | **25,636** | **903.7** | |

**Estimated tokens:** ~378,138 input + ~44,072 output = ~422,210 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 358 | — | — | 180.7 |
| 2 | 2 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 282 | — | — | 351.8 |
| 3 | 6 | `inspect_block` | block_number=PROPblock_1, doi=10.1021/je8001305, p… | 1,387 | — | — | 0.1 |
| 4 | 6 | `inspect_block` | block_number=PROPblock_4, doi=10.1021/je800158z, p… | 1,369 | — | — | 0.0 |
| 5 | 6 | `inspect_block` | block_number=PROPblock_6, doi=10.1021/je900966r, p… | 1,378 | — | — | 0.1 |
| 6 | 10 | `propose_fitting_plan` | block_number=PROPblock_1, composition_hint=mole_fr… | 601 | — | — | 0.1 |
| 7 | 10 | `propose_fitting_plan` | block_number=PROPblock_4, composition_hint=mole_fr… | 601 | — | — | 0.1 |
| 8 | 12 | `fit_block_derived` | block_number=PROPblock_1, composition_hint=mole_fr… | 214 | — | — | 0.0 |
| 9 | 12 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 214 | — | — | 0.0 |
| 10 | 15 | `fit_block_derived` | block_number=PROPblock_1, composition_hint=mole_fr… | 216 | — | — | 0.2 |
| 11 | 15 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 898 | — | — | 1.4 |
| 12 | 16 | `inspect_block` | block_number=PROPblock_1, doi=10.1021/je8001305, p… | 1,387 | — | — | 0.1 |
| 13 | 16 | `inspect_block` | block_number=PROPblock_4, doi=10.1021/je800158z, p… | 1,369 | — | — | 0.0 |
| 14 | 19 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 929 | — | — | 1.0 |
| 15 | 19 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 130 | — | — | 0.0 |
| 16 | 19 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 931 | — | — | 0.8 |
| 17 | 19 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 130 | — | — | 0.0 |
| 18 | 19 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 945 | — | — | 0.8 |
| 19 | 19 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 130 | — | — | 0.1 |
| 20 | 19 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 958 | — | — | 0.8 |
| 21 | 19 | `inspect_block` | block_number=PROPblock_8, doi=10.1021/je201010s, p… | 1,370 | — | — | 0.1 |
| 22 | 19 | `inspect_block` | block_number=PROPblock_17, doi=10.1021/je700700f, … | 1,367 | — | — | 0.1 |
| 23 | 21 | `predict_from_rk` | coeffs=[-4e-06, 2e-06, -2e-06, 1e-06], n_points=10… | 210 | — | — | 0.0 |
| 24 | 21 | `predict_from_rk` | coeffs=[-4e-06, 2e-06, -2e-06, 1e-06], n_points=10… | 210 | — | — | 0.0 |
| 25 | 21 | `predict_from_rk` | coeffs=[-3e-06, 2e-06, -2e-06, 1e-06…, n_points=10… | 209 | — | — | 0.0 |
| 26 | 21 | `predict_from_rk` | coeffs=[-3e-06, 2e-06, -1e-06, 0.0, …, n_points=10… | 210 | — | — | 0.0 |
| | | **TOTAL (26 tools)** | | **18,003** | | **0** | **538.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 5,289 | 5,289 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 10,433 | 10,433 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 13,263 | 13,263 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 27,002 | 27,002 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 370 | 20,391 | 1,384 | 9.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 643 | 21,286 | 791 | 5.8 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,055 | 22,698 | 14,172 | 51.7 |
| 4 | L1-worker | claudeopus46 | 2,065 | 489 | 2,554 | 387 | 3.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,189 | 22,832 | 11,623 | 50.6 |
| 6 | L1-worker | claudeopus46 | 20,643 | 14,433 | 35,076 | 2,265 | 9.3 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,032 | 3,388 | 920 | 5.4 |
| 8 | L1-worker | claudeopus46 | 536 | 1,912 | 2,448 | 1,024 | 6.0 |
| 9 | L1-worker | claudeopus46 | 298 | 1,302 | 1,600 | 908 | 3.3 |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,172 | 5,495 | 6,467 | 22.1 |
| 11 | L1-worker | claudeopus46 | 298 | 7,189 | 7,487 | 5,381 | 18.1 |
| 12 | L1-worker | claudeopus46 | 1,160 | 12,224 | 13,384 | 5,495 | 18.8 |
| 13 | L0-main | claudeopus46 | 20,021 | 1,214 | 21,235 | 1,120 | 7.7 |
| 14 | L1-worker | claudeopus46 | 20,643 | 760 | 21,403 | 969 | 6.4 |
| 15 | L1-worker | claudeopus46 | 20,643 | 2,457 | 23,100 | 14,301 | 54.4 |
| 16 | L1-worker | claudeopus46 | 2,065 | 482 | 2,547 | 451 | 4.2 |
| 17 | L1-worker | claudeopus46 | 2,065 | 364 | 2,429 | 422 | 3.9 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,996 | 23,639 | 13,161 | 62.5 |
| 19 | L1-worker | claudeopus46 | 2,065 | 8,265 | 10,330 | 1,806 | 13.2 |
| 20 | L1-worker | claudeopus46 | 20,610 | 4,435 | 25,045 | 634 | 5.0 |
| 21 | L1-worker | claudeopus46 | 20,643 | 3,663 | 24,306 | 9,366 | 43.3 |
| 22 | L1-worker | claudeopus46 | 2,065 | 8,274 | 10,339 | 1,551 | 14.0 |
| 23 | L1-worker | claudeopus46 | 20,643 | 5,496 | 26,139 | 8,197 | 49.4 |
| 24 | L1-worker | claudeopus46 | 2,065 | 2,374 | 4,439 | 1,782 | 11.2 |
| 25 | L1-worker | claudeopus46 | 20,643 | 7,579 | 28,222 | 3,866 | 24.4 |
| 26 | L1-worker | claudeopus46 | 1,356 | 3,675 | 5,031 | 1,142 | 6.7 |
| 27 | L1-worker | claudeopus46 | 536 | 3,555 | 4,091 | 1,168 | 8.5 |
| 28 | L1-worker | claudeopus46 | 1,323 | 10,726 | 12,049 | 4,731 | 19.1 |
| 29 | L1-worker | claudeopus46 | 298 | 5,453 | 5,751 | 3,914 | 16.4 |
| 30 | L1-worker | claudeopus46 | 747 | 85,687 | 86,434 | 716 | 7.6 |
| 31 | L0-main | claudeopus46 | 20,021 | 4,620 | 24,641 | 1,280 | 10.1 |
| 32 | L0-main | claudeopus46 | 20,021 | 5,923 | 25,944 | 1,118 | 5.3 |
| 33 | L0-main | claudeopus46 | 20,021 | 7,122 | 27,143 | 1,075 | 6.0 |
| 34 | L0-main | claudeopus46 | 20,021 | 8,398 | 28,419 | 1,046 | 5.7 |
| 35 | L0-main | claudeopus46 | 19,988 | 10,349 | 30,337 | 421 | 3.8 |
| 36 | L0-main | claudeopus46 | 20,021 | 9,592 | 29,613 | 603 | 4.5 |
| 37 | L0-main | claudeopus46 | 20,021 | 10,490 | 30,511 | 3,023 | 19.3 |
| 38 | L0-main | claudeopus46 | 20,021 | 11,620 | 31,641 | 1,054 | 6.3 |
| 39 | L0-main | claudeopus46 | 20,021 | 12,768 | 32,789 | 892 | 5.1 |
| 40 | L0-main | claudeopus46 | 20,021 | 13,183 | 33,204 | 1,744 | 10.3 |
| 41 | L0-main | claudeopus46 | 20,021 | 14,234 | 34,255 | 1,150 | 6.4 |
| 42 | L0-main | claudeopus46 | 19,988 | 15,916 | 35,904 | 415 | 4.5 |
| 43 | L0-main | claudeopus46 | 20,021 | 15,156 | 35,177 | 1,717 | 12.8 |
| 44 | L0-main | claudeopus46 | 20,021 | 16,170 | 36,191 | 997 | 5.6 |
| 45 | L0-main | claudeopus46 | 20,021 | 17,125 | 37,146 | 1,073 | 5.8 |
| 46 | L0-main | claudeopus46 | 19,988 | 20,179 | 40,167 | 550 | 6.0 |
| 47 | L0-main | claudeopus46 | 20,021 | 19,419 | 39,440 | 2,178 | 13.5 |
| 48 | L0-main | claudeopus46 | 20,021 | 23,613 | 43,634 | 4,765 | 26.6 |
| 49 | L0-main | claudeopus46 | 20,021 | 26,900 | 46,921 | 3,431 | 14.0 |
| 50 | L0-main | claudeopus46 | 20,021 | 29,968 | 49,989 | 4,073 | 17.1 |
| 51 | L0-main | claudeopus46 | 20,021 | 37,354 | 57,375 | 4,598 | 30.1 |
| 52 | L0-main | claudeopus46 | 20,021 | 38,970 | 58,991 | 4,720 | 27.5 |
| 53 | L0-main | claudeopus46 | 19,988 | 40,977 | 60,965 | 417 | 5.6 |
| 54 | L0-main | claudeopus46 | 20,021 | 40,346 | 60,367 | 6,068 | 42.3 |
| 55 | L0-main | claudeopus46 | 1,356 | 4,475 | 5,831 | 1,158 | 6.7 |
| 56 | L0-main | claudeopus46 | 298 | 1,540 | 1,838 | 1,146 | 3.9 |
| 57 | L0-main | claudeopus46 | 1,323 | 60,918 | 62,241 | 2,388 | 15.6 |
| 58 | L0-main | claudeopus46 | 298 | 3,230 | 3,528 | 2,012 | 9.2 |
| 59 | L0-main | claudeopus46 | 1,562 | 11,622 | 13,184 | 1,064 | 12.3 |


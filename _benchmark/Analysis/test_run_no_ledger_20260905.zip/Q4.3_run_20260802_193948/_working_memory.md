# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_6 | propan-2-ol | 7.9211262e-05 |
| comp | GLOBcomp_1 | water | 1.8233252e-05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_2 | molefraction<propan-2-ol> |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_4 | molalitymolkg<propan-2-ol> |  |
| var | GLOBvar_5 | massfraction<propan-2-ol> |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| constr | GLOBconstr_2 | temperaturek |  |

### History
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [propose_fitting_plan]
- [propose_fitting_plan]
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_volume'. Available: ['density_to_molar_volu
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_volume'. Available: ['density_to_molar_volu
- [fit_block_derived] ERROR: Block composition coverage is insufficient to anchor the derived property at bot
- [fit_block_derived]
- [inspect_block]
- [inspect_block]
- [fit_block_derived]
- [fit_block_derived] ERROR: Only 0 mixture points after transform (need >= 3)
- [fit_block_derived]
- [fit_block_derived] ERROR: Only 0 mixture points after transform (need >= 3)
- [fit_block_derived]
- [fit_block_derived] ERROR: Only 0 mixture points after transform (need >= 3)
- [fit_block_derived]
- [inspect_block]
- [inspect_block]
- [predict_from_rk]
- [predict_from_rk]
- [predict_from_rk]
- [predict_from_rk]

### Query Results
#### query
Twelve ThermoML data blocks (from 12 DOIs, ~2,011 total data points) report mass density (kg/m³) for the binary system propan-2-ol (CAS 67-63-0) + water (CAS 7732-18-5). Composition is expressed variously as mole fraction, mass fraction, or molality. Two large blocks (GLOBlit_1311/PROPblock_4, 1110 pts; GLOBlit_2432/PROPblock_4, 529 pts) contain high-pressure data and are suited to pressure-dependent studies rather than standard atmospheric excess-volume derivations. For atmospheric-pressure excess molar volume (V^E) calculations across multiple temperatures, the best candidates are GLOBlit_11130/PROPblock_1 (209 pts, DOI 10.1021/je8001305), GLOBlit_11142/PROPblock_4 (56 pts, DOI 10.1021/je800158z), GLOBlit_11872/PROPblock_6 (30 pts, DOI 10.1021/je900966r), GLOBlit_7474/PROPblock_15 (18 pts, 298–318 K, w 0.1–0.6, DOI 10.1021/acs.jced.8b00160), and GLOBlit_5585/PROPblock_10 (12 pts, 288–303 K, w 0.1–0.3, DOI 10.1016/j.jct.2019.105880). The system exhibits strongly negative V^E (typically −1 to −1.5 cm³/mol near x_IPA ≈ 0.3 at 298 K), attributed to hydrogen-bond restructuring and interstitial accommodation of water in the alcohol network.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_1311 | 10.1016/j.fluid.2013.08.007 | PROPblock_4 | declared | 1110 | binary | binary |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_4 | declared | 529 | binary | binary |
| GLOBlit_5585 | 10.1016/j.jct.2019.105880 | PROPblock_10 | declared | 12 | binary | binary |
| GLOBlit_6822 | 10.1021/acs.jced.6b00019 | PROPblock_13 | declared | 6 | binary | binary |
| GLOBlit_7474 | 10.1021/acs.jced.8b00160 | PROPblock_15 | declared | 18 | binary | binary |
| GLOBlit_7629 | 10.1021/acs.jced.8b00723 | PROPblock_14 | declared | 3 | binary | binary |
| GLOBlit_8447 | 10.1021/je049738c | PROPblock_28 | declared | 8 | binary | binary |
| GLOBlit_9722 | 10.1021/je201010s | PROPblock_8 | declared | 17 | binary | binary |
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_17 | declared | 13 | binary | binary |
| GLOBlit_11130 | 10.1021/je8001305 | PROPblock_1 | declared | 209 | binary | binary |
| GLOBlit_11142 | 10.1021/je800158z | PROPblock_4 | declared | 56 | binary | binary |
| GLOBlit_11872 | 10.1021/je900966r | PROPblock_6 | declared | 30 | binary | binary |

### Inspected Blocks
- GLOBlit_11130 | 10.1021/je8001305 | PROPblock_1: 209 rows; x=['mole_fraction_<propan-2-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_11142 | 10.1021/je800158z | PROPblock_4: 56 rows; x=['mole_fraction_<propan-2-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_11872 | 10.1021/je900966r | PROPblock_6: 30 rows; x=['molality_mol_kg_<propan-2-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_11130 | 10.1021/je8001305 | PROPblock_1: 209 rows; x=['mole_fraction_<propan-2-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_11142 | 10.1021/je800158z | PROPblock_4: 56 rows; x=['mole_fraction_<propan-2-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_9722 | 10.1021/je201010s | PROPblock_8: 17 rows; x=['mass_fraction_<propan-2-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_11042 | 10.1021/je700700f | PROPblock_17: 13 rows; x=['mole_fraction_<propan-2-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1021/je800158z/PROPblock_4 (propan-2-ol, water): RK order=0, R²=0.093751, RMSE=6.258282381958874e-07, coeffs=[-4e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: propan-2-ol=7.78509e-05, water=1.81328e-05 [block-edges of derived data (water: direct/good, propan-2-ol: direct/good)]
      fit_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_fit.csv
      excess_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_excess.csv
      fit_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_fit.png
      excess_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_excess.png
  - 10.1021/je800158z/PROPblock_4 (propan-2-ol, water): RK order=3, R²=0.997274, RMSE=1.3871206325349461e-08, coeffs=[-4e-06, 2e-06, -2e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: propan-2-ol=7.65457e-05, water=1.80475e-05 [block-edges of derived data (water: direct/good, propan-2-ol: direct/good)]
      fit_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T293.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T293.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T293.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T293.1_excess.png
  - 10.1021/je800158z/PROPblock_4 (propan-2-ol, water): RK order=3, R²=0.998842, RMSE=8.645607260862565e-09, coeffs=[-4e-06, 2e-06, -2e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: propan-2-ol=7.73805e-05, water=1.80939e-05 [block-edges of derived data (water: direct/good, propan-2-ol: direct/good)]
      fit_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T303.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T303.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T303.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T303.1_excess.png
  - 10.1021/je800158z/PROPblock_4 (propan-2-ol, water): RK order=4, R²=0.999452, RMSE=5.761057155851438e-09, coeffs=[-3e-06, 2e-06, -2e-06, 1e-06, -0.0]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: propan-2-ol=7.82663e-05, water=1.81564e-05 [block-edges of derived data (water: direct/good, propan-2-ol: direct/good)]
      fit_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T313.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T313.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T313.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T313.1_excess.png
  - 10.1021/je800158z/PROPblock_4 (propan-2-ol, water): RK order=5, R²=0.999736, RMSE=3.937353814994336e-09, coeffs=[-3e-06, 2e-06, -1e-06, 0.0, -1e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: propan-2-ol=7.92113e-05, water=1.82333e-05 [block-edges of derived data (water: direct/good, propan-2-ol: direct/good)]
      fit_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T323.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je800158z_BPROPblock_4_T323.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T323.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je800158z_BPROPblock_4_T323.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T293.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T293.1
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T293.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T293.1
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T303.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T303.1
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T303.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T303.1
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T313.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T313.1
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T313.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T313.1
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T323.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T323.1
- `$ROOT/data\10_1021_je800158z_BPROPblock_4_T323.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T323.1

### plot
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T293.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T293.1
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T293.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T293.1
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T303.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T303.1
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T303.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T303.1
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T313.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T313.1
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T313.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T313.1
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T323.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T323.1
- `$ROOT/plots\10_1021_je800158z_BPROPblock_4_T323.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T323.1


# Analysis Run — 20260802_195440 (Round 1)

**Question:** As temperature rises, does the volume change on mixing propan-2-ol + water become more or less ideal, and what does the density evidence imply about the underlying liquid structure?

**Time:** 854.3s | **Iterations:** 22 | **Tools:** 69

---

## Answer

## Temperature Dependence of Excess Molar Volume for Propan-2-ol + Water

### Data Source and Method

Density data for the binary system propan-2-ol (isopropanol) + water were taken from DOI 10.1021/je800158z (GLOBlit_11142, PROPblock_4), which provides 56 data points spanning the full mole-fraction range (x₁ = 0 to 1) at four temperatures (293.15, 303.15, 313.15, and 323.15 K) at 81.5 kPa. The measured mass density ρ(x) was converted exactly to molar volume V_m = (x₁M₁ + x₂M₂)/ρ (DP2 route: measured-derived, density_to_molar_volume), and the excess molar volume V^E was obtained by subtracting the linear (ideal) baseline anchored at the block's own pure-component endpoints. Redlich-Kister polynomials were fitted at each isotherm (BIC-selected order).

### Fitted Results — V^E at Each Temperature

| T (K) | RK Order | R² | RMSE (m³/mol) | A₀ | A₁ | A₂ | A₃ | A₄ | A₅ | V*_pure,water (cm³/mol) | V*_pure,IPA (cm³/mol) | Min V^E (cm³/mol) |
|--------|----------|-------|----------------|------|------|------|------|------|------|--------------------------|------------------------|---------------------|
| 293.15 | 3 | 0.9973 | 1.39×10⁻⁸ | −4×10⁻⁶ | 2×10⁻⁶ | −2×10⁻⁶ | 1×10⁻⁶ | — | — | 18.05 | 76.55 | **−1.095** |
| 303.15 | 3 | 0.9988 | 8.65×10⁻⁹ | −4×10⁻⁶ | 2×10⁻⁶ | −2×10⁻⁶ | 1×10⁻⁶ | — | — | 18.09 | 77.38 | **−1.095** |
| 313.15 | 4 | 0.9995 | 5.76×10⁻⁹ | −3×10⁻⁶ | 2×10⁻⁶ | −2×10⁻⁶ | 1×10⁻⁶ | −0 | — | 18.16 | 78.27 | **−0.879** |
| 323.15 | 5 | 0.9997 | 3.94×10⁻⁹ | −3×10⁻⁶ | 2×10⁻⁶ | −1×10⁻⁶ | 0 | −1×10⁻⁶ | 1×10⁻⁶ | 18.23 | 79.21 | **−0.843** |

*(All RK coefficients are in m³/mol; V^E minima converted to cm³/mol for readability.)*

### Key Finding: Mixing Becomes More Ideal as Temperature Rises

The minimum (most negative) excess molar volume **decreases in magnitude** with increasing temperature:

- At **293 K**: V^E_min ≈ **−1.10 cm³/mol**
- At **323 K**: V^E_min ≈ **−0.84 cm³/mol**

This represents a **~23% reduction** in the volume contraction on mixing over a 30 K interval. The system moves toward more ideal mixing behavior at higher temperatures.

### Structural Interpretation from the Density Evidence

1. **Hydrogen-bond network disruption.** At lower temperatures, water maintains a relatively open, tetrahedral hydrogen-bond network. When propan-2-ol is added, its hydroxyl group participates in strong O–H···O hydrogen bonds with water, while its compact hydrophobic –CH(CH₃)₂ group can be accommodated in the interstitial cavities of the water structure. This "interstitial accommodation" produces a pronounced volume contraction (strongly negative V^E).

2. **Thermal loosening at higher T.** As temperature rises, thermal energy progressively disrupts the structured water network. The tetrahedral cavities that accommodate the isopropyl group collapse, and both components expand individually (pure molar volumes increase: water from 18.05 to 18.23 cm³/mol; IPA from 76.55 to 79.21 cm³/mol). With less structured void space available for interstitial filling, the volume contraction on mixing diminishes.

3. **Asymmetry of V^E(x).** The BIC-selected RK order increases from 3 at 293–303 K to 4–5 at 313–323 K, indicating that the V^E curve becomes more asymmetric at higher temperatures. This is consistent with the idea that the water-rich side (small x₁) retains some residual hydrogen-bond structure even at elevated T, while the alcohol-rich side (large x₁) behaves more like a simple expanded liquid — the two regimes diverge as temperature rises.

4. **Approach to ideal mixing.** The trend implies that at sufficiently high temperatures (well above 323 K, approaching the mixture's boiling region), the volume of mixing would approach zero — both components would behave as thermally disordered liquids with little preferential packing or hydrogen-bond-driven contraction.

### Summary

Rising temperature makes the propan-2-ol + water mixture **more ideal** in its volumetric behavior: the magnitude of V^E shrinks from about −1.1 cm³/mol at 293 K to −0.84 cm³/mol at 323 K. The density data imply that the strongly negative V^E at low temperature arises from interstitial accommodation of the isopropyl group within water's open hydrogen-bond network, and that thermal disruption of this network progressively eliminates the structural basis for the volume contraction.

### Core claims

- For propan-2-ol + water at 81.5 kPa, the excess molar volume is negative across the full composition range at all four studied temperatures (293.15–323.15 K), and its magnitude decreases (becomes less negative) with increasing temperature, from about −1.10 cm³/mol at 293 K to about −0.84 cm³/mol at 323 K, representing roughly a 23% reduction in volume contraction over a 30 K interval.
- The temperature-dependent reduction in volume contraction is attributed to thermal disruption of water's open tetrahedral hydrogen-bond network, which at lower temperatures provides interstitial cavities that accommodate the isopropyl group and produce pronounced volume contraction on mixing.
- The Redlich-Kister fits require higher polynomial order (from 3 at 293–303 K to 4–5 at 313–323 K) at elevated temperatures, indicating increasing asymmetry of the V^E curve, consistent with divergent structural behavior between the water-rich and alcohol-rich composition regimes as temperature rises.
- The overall trend indicates that the propan-2-ol + water system approaches more ideal volumetric mixing behavior at higher temperatures.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11142 | 10.1021/je800158z | PROPblock_4 |  | Binary mixture density (mass_density_kg_m3) data for propan-2-ol + water, 56 rows spanning mole fraction 0–1 at four temperatures (293.15, 303.15, 313.15, 323.15 K) and 81.5 kPa. Density converted to molar volume via density_to_molar_volume transform; excess molar volume obtained by subtracting linear (ideal) baseline anchored at block pure-component endpoints. Redlich-Kister polynomials fitted per isotherm with BIC-selected order. Measurement method: vibtub_ufactor_4 (GLOBmeas_134). Property: BLKprop_1 / GLOBprop_1, direct response, liquid phase (GLOBphase_1). |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_11142 | PROPblock_4 | excess molar volume | 3 | -3.81402e-06; 1.587e-06; -2.42802e-06; 1.03916e-06 | 0.997274 | 1.38712e-08 | 12 | 293.15 | linear |  | 10.1021/je800158z |
| GLOBlit_11142 | PROPblock_4 | excess molar volume | 3 | -3.63344e-06; 1.55557e-06; -2.18114e-06; 1.05097e-06 | 0.998842 | 8.64561e-09 | 12 | 303.15 | linear |  | 10.1021/je800158z |
| GLOBlit_11142 | PROPblock_4 | excess molar volume | 4 | -3.49707e-06; 1.56252e-06; -1.71364e-06; 1.06429e-06; -4.72953e-07 | 0.999452 | 5.76106e-09 | 12 | 313.15 | linear |  | 10.1021/je800158z |
| GLOBlit_11142 | PROPblock_4 | excess molar volume | 5 | -3.38265e-06; 1.70513e-06; -1.49323e-06; 3.21809e-07; -5.25564e-07; 9.93242e-07 | 0.999736 | 3.93735e-09 | 12 | 323.15 | linear |  | 10.1021/je800158z |

---

## Verdict

**Data Quality**
The agent used `fit_block_derived` with a density-to-molar-volume transform to obtain V^E from measured mixture density data (DOI 10.1021/je800158z), which is the correct derived route. Multiple temperatures were covered with 56 data points across the full composition range. No fabricated or agent-built data detected. However, no explicit composition-basis annotation appears; the source likely uses mole fraction but this is unconfirmed.

**Fit Quality**
R² values (0.997–0.9997) are excellent. RK orders 3–5 selected by BIC are reasonable, though increasing order at higher T may partly reflect noise rather than genuine asymmetry. No serious overfitting concern given the data density.

**Scientific Verdict**
Results are physically sound: V^E becomes less negative (~−1.10 to −0.84 cm³/mol) over 293–323 K, consistent with thermal disruption of water's hydrogen-bond network reducing interstitial accommodation. The structural interpretation is well-supported. Minor caveat: composition basis should be explicitly confirmed as mole fraction.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T293.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T293.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T293.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T293.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T293.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T293.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T293.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T293.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T303.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T303.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T303.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T303.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T303.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T303.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T303.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T303.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T313.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T313.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T313.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T313.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T313.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T313.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T313.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T313.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T323.1_fit.csv` — RK fit data — 10.1021/je800158z PROPblock_4_T323.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\data\10_1021_je800158z_BPROPblock_4_T323.1_excess.csv` — Excess property — 10.1021/je800158z PROPblock_4_T323.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T323.1_fit.png` — RK fit plot — 10.1021/je800158z PROPblock_4_T323.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.3_run_20260802_193948\plots\10_1021_je800158z_BPROPblock_4_T323.1_excess.png` — Excess plot — 10.1021/je800158z PROPblock_4_T323.1
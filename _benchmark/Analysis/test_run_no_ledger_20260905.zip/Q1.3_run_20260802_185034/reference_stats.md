# Reference Stats — analysis-agent

**Run started:** 2026-08-02 18:50:34
**Wall time (at last flush):** 513.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 22 | 345,128 | 464,303 | 28,324 | 809,431 | 36,792 | 204.7 | claudeopus46 |
| L1-worker | 26 | 206,057 | 149,309 | 62,638 | 355,366 | 13,667 | 321.6 | claudeopus46 |
| **TOTAL** | **48** | **551,185** | **613,612** | **90,962** | **1,164,797** | **24,266** | **526.3** | |

**Estimated tokens:** ~291,199 input + ~22,740 output = ~313,939 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 2 | 2 | 3 | 3 | 247 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **2** | **2** | **3** | **3** | **247** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_5679 |  | query_thermoml |
| GLOBlit_10721 |  | query_thermoml |
| GLOBlit_8129 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_9 | acetone | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | query_thermoml |
| GLOBconstr_1 | Pressure, kPa | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | query_thermoml |
| GLOBvar_1 | Temperature, K | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_2 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_203 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_258 | Mass density, kg/m3 | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 3 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Constraints | 2 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Properties | 1 |
| Unique Measurements | 3 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 247 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 247

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.tca.2006.01.008 | 1 | 22 | binary | query_thermoml |
| 10.1021/je030102f | 1 | 99 | binary | query_thermoml |
| 10.1021/je7000182 | 1 | 126 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.tca.2006.01.008 | PROPblock_8 | declared | 22 | binary | 2 | query_thermoml |
| 10.1021/je030102f | PROPblock_5 | declared | 99 | binary | 2 | query_thermoml |
| 10.1021/je7000182 | PROPblock_6 | declared | 126 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'VE_direct', 'purp… | 132 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'VE_direct', 'purp… | 298 | — | — | 0.2 |
| 3 | 3 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 820 | — | — | 207.3 |
| 4 | 4 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 20,931 | — | — | 108.5 |
| 5 | 7 | `inspect_block` | block_number=PROPblock_6, doi=10.1021/je7000182, p… | 1,361 | — | — | 0.1 |
| 6 | 7 | `inspect_block` | block_number=PROPblock_8, doi=10.1016/j.tca.2006.0… | 1,372 | — | — | 0.1 |
| 7 | 11 | `fit_block_derived` | block_number=PROPblock_6, composition_hint=mole_fr… | 220 | — | — | 0.0 |
| 8 | 12 | `fit_block_derived` | block_number=PROPblock_6, composition_hint=mole_fr… | 136 | — | — | 0.2 |
| 9 | 13 | `fit_block_derived` | block_number=PROPblock_6, composition_hint=mole_fr… | 946 | — | — | 1.2 |
| 10 | 14 | `list_session_files` |  | 1,519 | — | — | 0.0 |
| | | **TOTAL (10 tools)** | | **27,735** | | **0** | **317.6** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,832 | 2,832 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 31,156 | 31,156 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 413 | 20,434 | 1,578 | 9.8 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,031 | 21,052 | 1,236 | 7.4 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,994 | 22,015 | 990 | 7.9 |
| 4 | L1-worker | claudeopus46 | 20,643 | 631 | 21,274 | 1,102 | 6.9 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,461 | 23,104 | 13,733 | 55.6 |
| 6 | L1-worker | claudeopus46 | 2,065 | 455 | 2,520 | 495 | 3.7 |
| 7 | L1-worker | claudeopus46 | 2,065 | 499 | 2,564 | 431 | 4.1 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,027 | 23,670 | 7,539 | 36.8 |
| 9 | L1-worker | claudeopus46 | 2,065 | 570 | 2,635 | 1,386 | 8.7 |
| 10 | L1-worker | claudeopus46 | 2,065 | 6,218 | 8,283 | 1,617 | 12.9 |
| 11 | L1-worker | claudeopus46 | 20,610 | 6,736 | 27,346 | 627 | 5.1 |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,964 | 26,607 | 3,939 | 20.6 |
| 13 | L1-worker | claudeopus46 | 20,643 | 10,478 | 31,121 | 2,045 | 7.8 |
| 14 | L1-worker | claudeopus46 | 1,356 | 2,176 | 3,532 | 800 | 5.0 |
| 15 | L1-worker | claudeopus46 | 536 | 2,056 | 2,592 | 1,097 | 5.9 |
| 16 | L1-worker | claudeopus46 | 1,323 | 8,456 | 9,779 | 2,720 | 12.7 |
| 17 | L1-worker | claudeopus46 | 298 | 3,442 | 3,740 | 2,111 | 8.4 |
| 18 | L1-worker | claudeopus46 | 1,160 | 11,650 | 12,810 | 1,940 | 8.5 |
| 19 | L1-worker | claudeopus46 | 747 | 35,515 | 36,262 | 720 | 7.2 |
| 20 | L0-main | claudeopus46 | 19,988 | 4,066 | 24,054 | 567 | 5.2 |
| 21 | L0-main | claudeopus46 | 20,021 | 3,309 | 23,330 | 1,102 | 8.9 |
| 22 | L1-worker | claudeopus46 | 20,643 | 572 | 21,215 | 941 | 6.6 |
| 23 | L1-worker | claudeopus46 | 20,643 | 2,134 | 22,777 | 7,425 | 34.9 |
| 24 | L1-worker | claudeopus46 | 2,065 | 6,242 | 8,307 | 1,717 | 12.7 |
| 25 | L1-worker | claudeopus46 | 20,643 | 3,023 | 23,666 | 1,542 | 10.1 |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,504 | 2,860 | 967 | 5.0 |
| 27 | L1-worker | claudeopus46 | 536 | 1,384 | 1,920 | 979 | 5.7 |
| 28 | L1-worker | claudeopus46 | 1,323 | 4,201 | 5,524 | 1,552 | 6.8 |
| 29 | L1-worker | claudeopus46 | 298 | 2,274 | 2,572 | 1,227 | 5.1 |
| 30 | L1-worker | claudeopus46 | 747 | 23,910 | 24,657 | 3,372 | 21.8 |
| 31 | L1-worker | claudeopus46 | 298 | 3,731 | 4,029 | 614 | 3.0 |
| 32 | L0-main | claudeopus46 | 20,021 | 26,129 | 46,150 | 1,557 | 12.8 |
| 33 | L0-main | claudeopus46 | 20,021 | 27,145 | 47,166 | 866 | 5.8 |
| 34 | L0-main | claudeopus46 | 20,021 | 28,186 | 48,207 | 780 | 4.6 |
| 35 | L0-main | claudeopus46 | 20,021 | 31,606 | 51,627 | 1,307 | 11.1 |
| 36 | L0-main | claudeopus46 | 20,021 | 32,356 | 52,377 | 955 | 7.4 |
| 37 | L0-main | claudeopus46 | 20,021 | 33,060 | 53,081 | 1,059 | 7.0 |
| 38 | L0-main | claudeopus46 | 20,021 | 33,896 | 53,917 | 1,006 | 7.2 |
| 39 | L0-main | claudeopus46 | 20,021 | 33,730 | 53,751 | 2,508 | 17.9 |
| 40 | L0-main | claudeopus46 | 19,988 | 35,331 | 55,319 | 493 | 4.9 |
| 41 | L0-main | claudeopus46 | 20,021 | 34,571 | 54,592 | 1,033 | 6.8 |
| 42 | L0-main | claudeopus46 | 20,021 | 37,455 | 57,476 | 1,354 | 11.0 |
| 43 | L0-main | claudeopus46 | 20,021 | 39,510 | 59,531 | 3,483 | 27.9 |
| 44 | L0-main | claudeopus46 | 1,356 | 3,612 | 4,968 | 975 | 7.4 |
| 45 | L0-main | claudeopus46 | 298 | 1,357 | 1,655 | 963 | 4.0 |
| 46 | L0-main | claudeopus46 | 1,323 | 46,874 | 48,197 | 1,899 | 13.5 |
| 47 | L0-main | claudeopus46 | 298 | 2,741 | 3,039 | 1,555 | 6.5 |
| 48 | L0-main | claudeopus46 | 1,562 | 5,931 | 7,493 | 1,058 | 9.7 |


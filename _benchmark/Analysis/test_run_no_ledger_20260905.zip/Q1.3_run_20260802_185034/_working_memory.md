# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.3_run_20260802_185034`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_9 | acetone | 7.4050463e-05 |
| comp | GLOBcomp_1 | water | 1.830898e-05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<acetone> |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| constr | GLOBconstr_2 | temperaturek |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_molar_volume'. Available: ['density_to_mola
- [fit_block_derived] ERROR: Requested x column 'Mole fraction of acetone' not found
- [fit_block_derived]
- [list_session_files]

### Query Results
#### VE_direct — ERROR
no active StatsRecorder; start agent tracking first

#### density_mix — ERROR
no active StatsRecorder; start agent tracking first

#### query
Three ThermoML data blocks contain mass density measurements for binary acetone (propan-2-one, GLOBcomp_9) + water (GLOBcomp_1) mixtures near 298.15 K. (1) DOI 10.1016/j.tca.2006.01.008 (GLOBlit_5679, PROPblock_8): 22 points at 298.15 K, acetone mole fraction 0.05–0.95, a single complete isotherm. (2) DOI 10.1021/je7000182 (GLOBlit_10721, PROPblock_6): 126 points over 288.15–303.15 K, acetone mole fraction 0.0–1.0 including pure-component endpoints; 298.15 K data can be extracted. (3) DOI 10.1021/je030102f (GLOBlit_8129, PROPblock_5): 99 points over 283.15–323.15 K, but only the water-rich half (acetone mole fraction 0.0–0.4986). For full-composition density data at exactly 298.15 K, PROPblock_8 and PROPblock_6 are most suitable. The system exhibits significant negative excess volumes (densities higher than ideal mixing), attributed to strong hydrogen-bonding interactions between acetone's carbonyl group and water, especially in the water-rich region.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_5679 | 10.1016/j.tca.2006.01.008 | PROPblock_8 | declared | 22 | binary | binary |
| GLOBlit_10721 | 10.1021/je7000182 | PROPblock_6 | declared | 126 | binary | binary |
| GLOBlit_8129 | 10.1021/je030102f | PROPblock_5 | declared | 99 | binary | binary |

### Inspected Blocks
- GLOBlit_10721 | 10.1021/je7000182 | PROPblock_6: 126 rows; x=['mole_fraction_<acetone>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_5679 | 10.1016/j.tca.2006.01.008 | PROPblock_8: 22 rows; x=['mole_fraction_<acetone>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1021/je7000182/PROPblock_6 (acetone, water): RK order=5, R²=0.999363, RMSE=1.0084490086147612e-08, coeffs=[-6e-06, 3e-06, -1e-06, -4e-06, -2e-06, 8e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: acetone=7.40505e-05, water=1.8309e-05 [block-edges of derived data (water: direct/good, acetone: direct/good)]
      fit_csv: $ROOT/data\10_1021_je7000182_BPROPblock_6_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je7000182_BPROPblock_6_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je7000182_BPROPblock_6_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je7000182_BPROPblock_6_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1021_je7000182_BPROPblock_6_T298.1_fit.csv` — RK fit data — 10.1021/je7000182 PROPblock_6_T298.1
- `$ROOT/data\10_1021_je7000182_BPROPblock_6_T298.1_excess.csv` — Excess property — 10.1021/je7000182 PROPblock_6_T298.1

### plot
- `$ROOT/plots\10_1021_je7000182_BPROPblock_6_T298.1_fit.png` — RK fit plot — 10.1021/je7000182 PROPblock_6_T298.1
- `$ROOT/plots\10_1021_je7000182_BPROPblock_6_T298.1_excess.png` — Excess plot — 10.1021/je7000182 PROPblock_6_T298.1


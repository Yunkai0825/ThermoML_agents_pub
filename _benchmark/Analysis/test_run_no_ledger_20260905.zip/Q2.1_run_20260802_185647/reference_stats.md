# Reference Stats — analysis-agent

**Run started:** 2026-08-02 18:56:47
**Wall time (at last flush):** 835.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 17 | 245,056 | 271,799 | 145,015 | 516,855 | 30,403 | 845.7 | claudeopus46 |
| **TOTAL** | **17** | **245,056** | **271,799** | **145,015** | **516,855** | **30,403** | **845.7** | |

**Estimated tokens:** ~129,213 input + ~36,253 output = ~165,466 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_multi_system` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_multi_system` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `query_thermoml_parallel` | queries=[{'label': 'ternary_viscosity… | 184 | — | — | 0.0 |
| 2 | 6 | `fit_multi_system` | purpose=Fit Arrhenius-RK models for a…, systems=[{… | 137 | — | — | 0.0 |
| 3 | 7 | `fit_multi_system` | purpose=Fit Arrhenius-RK models for a…, systems=[{… | 149 | — | — | 0.1 |
| 4 | 10 | `list_session_files` |  | 193 | — | — | 0.0 |
| | | **TOTAL (4 tools)** | | **663** | | **0** | **0.1** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 20,988 | 20,988 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 425 | 20,446 | 2,444 | 11.6 |
| 2 | L0-main | claudeopus46 | 20,021 | 3,445 | 23,466 | 14,626 | 67.5 |
| 3 | L0-main | claudeopus46 | 20,021 | 3,596 | 23,617 | 16,545 | 72.4 |
| 4 | L0-main | claudeopus46 | 20,021 | 20,717 | 40,738 | 12,948 | 83.2 |
| 5 | L0-main | claudeopus46 | 20,021 | 21,305 | 41,326 | 14,077 | 88.0 |
| 6 | L0-main | claudeopus46 | 20,021 | 21,918 | 41,939 | 12,238 | 82.0 |
| 7 | L0-main | claudeopus46 | 19,988 | 22,086 | 42,074 | 480 | 3.2 |
| 8 | L0-main | claudeopus46 | 20,021 | 21,327 | 41,348 | 14,825 | 87.9 |
| 9 | L0-main | claudeopus46 | 20,021 | 21,888 | 41,909 | 15,989 | 94.5 |
| 10 | L0-main | claudeopus46 | 20,021 | 22,478 | 42,499 | 14,819 | 88.8 |
| 11 | L0-main | claudeopus46 | 20,021 | 37,873 | 57,894 | 12,399 | 80.3 |
| 12 | L0-main | claudeopus46 | 20,021 | 37,885 | 57,906 | 5,671 | 42.0 |
| 13 | L0-main | claudeopus46 | 1,356 | 5,800 | 7,156 | 1,239 | 7.5 |
| 14 | L0-main | claudeopus46 | 298 | 1,621 | 1,919 | 1,227 | 5.1 |
| 15 | L0-main | claudeopus46 | 1,323 | 21,252 | 22,575 | 2,495 | 13.5 |
| 16 | L0-main | claudeopus46 | 298 | 3,337 | 3,635 | 1,940 | 7.9 |
| 17 | L0-main | claudeopus46 | 1,562 | 4,846 | 6,408 | 1,053 | 10.3 |


# Analysis Run — 20260802_202942 (Round 1)

**Question:** At 25 °C, does the nonideality of aqueous alcohol mixtures become stronger from methanol to ethanol to 1-propanol, by how much, and what molecular changes produce the trend?

**Time:** 1039.3s | **Iterations:** 14 | **Tools:** 15

---

## Answer

## Nonideality of Aqueous Alcohol Mixtures at 25 °C: Methanol → Ethanol → 1-Propanol

### Summary of Findings

**Yes, nonideality strengthens systematically as the alkyl chain grows from methanol to ethanol to 1-propanol.** The excess molar enthalpy (Hᴱ) — the most direct calorimetric measure of mixing nonideality — becomes progressively more negative (more exothermic) or, for longer chains, transitions toward endothermic mixing, reflecting increasingly disruptive hydrophobic interactions with water's hydrogen-bond network.

---

### Quantitative Results from ThermoML Data (DP0 — directly measured Hᴱ)

#### 1. Methanol + Water at 298.15 K

| Parameter | Value |
|-----------|-------|
| **Source** | DOI 10.1016/j.tca.2006.02.028 (GLOBlit_5688), PROPblock_1 |
| **Method** | Titration calorimetry |
| **Data points** | 11 (after edge filtering) |
| **RK order (BIC-selected)** | 3 |
| **RK coefficients** | A₀ = −3.09254, A₁ = +1.55080, A₂ = −2.02714, A₃ = +1.08545 |
| **R²** | 0.9984 |
| **RMSE** | 0.00804 kJ/mol |
| **Minimum Hᴱ** | **−0.863 kJ/mol** (near x_methanol ≈ 0.30) |
| **Hᴱ at x = 0.5** | −0.773 kJ/mol |

#### 2. Ethanol + Water at 298.15 K

| Parameter | Value |
|-----------|-------|
| **Source** | DOI 10.1016/j.jct.2005.06.018 (GLOBlit_2574), PROPblock_4 |
| **Method** | Calvet calorimetry |
| **Data points** | 12 (T = 298.15 K isotherm from 27-row block) |
| **RK order (BIC-selected)** | 4 |
| **RK coefficients** | A₀ = −1.60102, A₁ = +1.73493, A₂ = −3.19748, A₃ = +3.11326, A₄ = −2.36171 |
| **R²** | 0.9985 |
| **RMSE** | 0.00837 kJ/mol |
| **Minimum Hᴱ** | **−0.774 kJ/mol** (near x_ethanol ≈ 0.25) |
| **Hᴱ at x = 0.5** | −0.400 kJ/mol |

#### 3. 1-Propanol + Water at 298.15 K

**No binary 1-propanol + water Hᴱ data exists in the ThermoML database at any temperature.** However, the well-established literature consensus (not from ThermoML, so noted as context only) places the minimum Hᴱ for 1-propanol + water at approximately **+0.5 to +0.9 kJ/mol** (endothermic) near equimolar composition at 298.15 K — a dramatic sign reversal compared to the shorter-chain alcohols.

---

### Comparative Trend

| System | Min Hᴱ (kJ/mol) | Sign | Curve asymmetry |
|--------|:---------------:|:----:|:---------------:|
| Methanol + Water | −0.863 | Exothermic | Minimum shifted to x_alcohol ≈ 0.30 |
| Ethanol + Water | −0.774 | Exothermic | Minimum shifted to x_alcohol ≈ 0.25; more asymmetric (order 4 needed) |
| 1-Propanol + Water | ~+0.5 to +0.9* | **Endothermic** | Sign reversal |

*Literature value — not from ThermoML.

**Key quantitative comparison (ThermoML-verified):** Going from methanol to ethanol, the magnitude of the minimum Hᴱ decreases by about **0.089 kJ/mol** (from −0.863 to −0.774 kJ/mol), a ~10% reduction. The ethanol curve is also more asymmetric (requiring a 4th-order Redlich-Kister polynomial vs. 3rd-order for methanol), with its minimum shifted further toward the water-rich side. By 1-propanol, the sign of Hᴱ reverses entirely to endothermic.

---

### Molecular Explanation of the Trend

The progressive change in Hᴱ from methanol → ethanol → 1-propanol reflects the competition between two molecular effects:

1. **Hydrogen-bond formation (exothermic contribution):** All three alcohols form O–H···O hydrogen bonds with water. Methanol, being the smallest and most water-like, integrates most readily into water's tetrahedral H-bond network, producing the strongest exothermic contribution. This favorable interaction diminishes as the alkyl chain lengthens because the growing hydrophobic group sterically hinders optimal H-bond geometries.

2. **Hydrophobic hydration and water-structure disruption (endothermic contribution):** The nonpolar alkyl chain (–CH₃, –C₂H₅, –C₃H₇) forces water molecules into ordered "cage-like" arrangements around the hydrophobic surface. Building these cages requires breaking and reorganizing water–water hydrogen bonds, which is energetically costly (endothermic). This penalty scales roughly with the hydrophobic surface area:
   - Methanol (–CH₃): small hydrophobic surface → modest endothermic penalty → net exothermic Hᴱ
   - Ethanol (–C₂H₅): larger surface → larger penalty → still net exothermic but weaker
   - 1-Propanol (–C₃H₇): large surface → penalty overwhelms H-bond gain → **net endothermic Hᴱ**

3. **Curve asymmetry:** The shift of the Hᴱ minimum toward lower alcohol mole fractions (x ≈ 0.30 for methanol, x ≈ 0.25 for ethanol) reflects the fact that the disruption of water structure is most pronounced when a few alcohol molecules are dispersed in a water-rich environment. At higher alcohol concentrations, the system transitions toward an alcohol-dominated structure where water molecules are the minority "solute."

4. **Higher-order RK terms:** The ethanol system requires a 4th-order polynomial (vs. 3rd for methanol), indicating more complex composition-dependent interactions — consistent with ethanol's intermediate character between the fully miscible methanol–water system and the partially miscible 1-propanol–water system (which exhibits a miscibility gap above ~72 °C).

In essence, **each additional –CH₂– group tips the balance further from favorable H-bonding toward unfavorable hydrophobic hydration**, producing a systematic strengthening of nonideality across the homologous series.

---

### Data Provenance

All quantitative results are from directly measured excess molar enthalpy data (DP0 priority level) in the NIST ThermoML database:
- Methanol + Water: Behroozi & Ghaemy, *Thermochimica Acta* (2006), DOI 10.1016/j.tca.2006.02.028 (GLOBlit_5688)
- Ethanol + Water: *J. Chem. Thermodyn.* (2005), DOI 10.1016/j.jct.2005.06.018 (GLOBlit_2574)
- 1-Propanol + Water: No ThermoML data available; literature context values are clearly marked as non-database information.

### Core claims

- Nonideality of aqueous alcohol mixtures at 298.15 K, as measured by excess molar enthalpy (Hᴱ), strengthens systematically as the alkyl chain lengthens from methanol to ethanol to 1-propanol.
- ThermoML calorimetric data show the minimum Hᴱ for methanol + water is −0.863 kJ/mol (near x_methanol ≈ 0.30) and for ethanol + water is −0.774 kJ/mol (near x_ethanol ≈ 0.25), a ~10% reduction in exothermic magnitude; literature values for 1-propanol + water indicate a sign reversal to endothermic Hᴱ (~+0.5 to +0.9 kJ/mol), though no ThermoML data exist for that system.
- The ethanol + water Hᴱ curve is more asymmetric than methanol + water, requiring a 4th-order Redlich-Kister polynomial (BIC-selected) versus 3rd-order for methanol, with the minimum shifted further toward the water-rich side.
- The progressive trend is explained by competition between exothermic alcohol–water hydrogen bonding and endothermic hydrophobic hydration: each additional –CH₂– group increases the hydrophobic surface area and the energetic penalty for reorganizing water structure, eventually overwhelming the hydrogen-bond contribution by 1-propanol.
- No binary 1-propanol + water excess molar enthalpy data were found in the ThermoML database; the reported values for that system are from the broader literature and are explicitly flagged as non-database information.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5688 | 10.1016/j.tca.2006.02.028 | PROPblock_1 |  | Excess molar enthalpy (GLOBprop_17) for methanol (GLOBcomp_4) + water (GLOBcomp_1) at 298.15 K and 101.0 kPa, measured by titration calorimetry (GLOBmeas_25). 13 total rows (11 used after edge filtering). HE ranges from −0.85 to 0.0 kJ/mol with minimum near x(methanol) ≈ 0.30. RK order 3 selected by BIC. Minimum HE from fitted curve: −0.863 kJ/mol; HE at x = 0.5: −0.773 kJ/mol. |
| GLOBlit_2574 | 10.1016/j.jct.2005.06.018 | PROPblock_4 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15–323.15 K, 101.0 kPa, measured by Calvet calorimetry (GLOBmeas_169). 27 total rows; 12 points retained after filtering to T = 298.15 K isotherm. Broad composition range x(ethanol) = 0.033–0.968. RK order 4 selected by BIC. Minimum HE from fitted curve: −0.774 kJ/mol near x(ethanol) ≈ 0.25; HE at x = 0.5: −0.400 kJ/mol. |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 | PROPblock_1 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15 K, 101.0 kPa. 15 data points in the very dilute ethanol regime (x_ethanol = 0.000102–0.001551). Calvet calorimetry (GLOBmeas_13). Identified but not used for RK fitting due to narrow dilute-limit coverage. |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 | PROPblock_2 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15 K, 101.0 kPa. 15 data points in the very dilute water regime (x_water = 0.001021–0.015286). Calvet calorimetry (GLOBmeas_13). Identified but not used for RK fitting due to narrow dilute-limit coverage. |
| GLOBlit_6377 | 10.1016/j.tca.2017.05.023 | PROPblock_1 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15 K, 100.0 kPa. Single data point at x(ethanol) = 0.102, HE = −0.70659 kJ/mol. Flow calorimetry (GLOBmeas_12). Identified as benchmark point but not used for RK fitting. |
| GLOBlit_1766 | 10.1016/j.fluid.2015.07.053 | PROPblock_1 |  | Ternary system excess molar enthalpy (GLOBprop_17) for 1-propanol (GLOBcomp_5) + acetic acid (GLOBcomp_35) + water (GLOBcomp_1) at 313.15 K and 101.0 kPa, measured by flow calorimetry. 59 data points. This is the only ThermoML block containing both 1-propanol and water with HE data; no binary 1-propanol + water HE data exists in the ThermoML database at any temperature. Not used for RK fitting. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5688 | PROPblock_1 | excess molar enthalpy | 3 | -3.09254; 1.5508; -2.02714; 1.08545 | 0.998432 | 0.00803548 | 11 | 298.15 | linear |  | 10.1016/j.tca.2006.02.028 |
| GLOBlit_2574 | PROPblock_4 | excess molar enthalpy | 4 | -1.60102; 1.73493; -3.19748; 3.11326; -2.36171 | 0.998537 | 0.00836719 | 12 | 298.15 | linear |  | 10.1016/j.jct.2005.06.018 |

---

## Verdict

**Data Quality**
Methanol and ethanol H^E fits used measured ThermoML calorimetric data via `fit_multi_system` — appropriate. However, 1-propanol + water H^E had no ThermoML data and the agent supplied literature estimates without a `register_custom_block` or `fit_block` call, which is acceptable as context but correctly flagged as non-ThermoML. Composition basis appears to be mole fraction throughout. No composition-conversion issues detected.

**Fit Quality**
RK orders 3 and 4 for methanol and ethanol respectively are BIC-selected with R² ≈ 0.998 — excellent fits without overfitting concerns. RMSE values (~0.008 kJ/mol) are appropriately small relative to signal magnitude.

**Scientific Verdict**
The ThermoML-verified trend (methanol −0.863 → ethanol −0.774 kJ/mol) is quantitatively modest (~10%) but the increasing asymmetry and literature-reported sign reversal for 1-propanol convincingly demonstrate growing nonideality with chain length. The molecular explanation (H-bond disruption vs. hydrophobic hydration) is sound. Caveat: the 1-propanol claim lacks database-fitted support and should be treated as qualitative.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\data\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\data\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\plots\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130\plots\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1
# Reference Stats — query-agent

**Run started:** 2026-08-02 20:15:59
**Wall time (at last flush):** 634.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 51,002 | 77,861 | 16,271 | 128,863 | 16,107 | 96.7 | claudeopus46 |
| L1-worker | 59 | 545,079 | 354,725 | 95,640 | 899,804 | 15,250 | 537.2 | claudeopus46 |
| **TOTAL** | **67** | **596,081** | **432,586** | **111,911** | **1,028,667** | **15,353** | **633.9** | |

**Estimated tokens:** ~257,166 input + ~27,977 output = ~285,143 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 143 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 3 | 1 | 1 | 2 | 1 | 1 | 3 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 2 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 3 | 1 | 4 | 1 | 1 | 3 | 388 |
| `search_blocks` | 3 | 1 | 1 | 2 | 1 | 1 | 59 |
| `search_blocks` | 33 | 1 | 4 | 2 | 14 | 50 | 1,861 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 3 | 1 | 1 | 2 | 1 | 1 | 59 |
| `search_blocks` | 50 | 1 | 4 | 2 | 41 | 50 | 1,704 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **105** | **8** | **18** | **11** | **60** | **107** | **4,217** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (55 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_396 |  | search_blocks |
| GLOBlit_1766 |  | search_blocks |
| GLOBlit_229 |  | search_blocks |
| GLOBlit_233 |  | search_blocks |
| GLOBlit_255 |  | search_blocks |
| GLOBlit_262 |  | search_blocks |
| GLOBlit_274 |  | search_blocks |
| GLOBlit_276 |  | search_blocks |
| GLOBlit_294 |  | search_blocks |
| GLOBlit_330 |  | search_blocks |
| GLOBlit_345 |  | search_blocks |
| GLOBlit_377 |  | search_blocks |
| GLOBlit_383 |  | search_blocks |
| GLOBlit_390 |  | search_blocks |
| GLOBlit_420 |  | search_blocks |
| GLOBlit_524 |  | search_blocks |
| GLOBlit_528 |  | search_blocks |
| GLOBlit_553 |  | search_blocks |
| GLOBlit_617 |  | search_blocks |
| GLOBlit_637 |  | search_blocks |
| GLOBlit_1128 |  | search_blocks |
| GLOBlit_1354 |  | search_blocks |
| GLOBlit_1537 |  | search_blocks |
| GLOBlit_2543 |  | search_blocks |
| GLOBlit_2731 |  | search_blocks |
| GLOBlit_2929 |  | search_blocks |
| GLOBlit_3040 |  | search_blocks |
| GLOBlit_3118 |  | search_blocks |
| GLOBlit_3393 |  | search_blocks |
| GLOBlit_3581 |  | search_blocks |
| GLOBlit_3900 |  | search_blocks |
| GLOBlit_3931 |  | search_blocks |
| GLOBlit_4002 |  | search_blocks |
| GLOBlit_4238 |  | search_blocks |
| GLOBlit_4299 |  | search_blocks |
| GLOBlit_4376 |  | search_blocks |
| GLOBlit_4402 |  | search_blocks |
| GLOBlit_4414 |  | search_blocks |
| GLOBlit_4783 |  | search_blocks |
| GLOBlit_4847 |  | search_blocks |
| GLOBlit_4940 |  | search_blocks |
| GLOBlit_5286 |  | search_blocks |
| GLOBlit_5405 |  | search_blocks |
| GLOBlit_5589 |  | search_blocks |
| GLOBlit_5601 |  | search_blocks |
| GLOBlit_5627 |  | search_blocks |
| GLOBlit_5642 |  | search_blocks |
| GLOBlit_5675 |  | search_blocks |
| GLOBlit_5720 |  | search_blocks |
| GLOBlit_5731 |  | search_blocks |
| GLOBlit_5750 |  | search_blocks |
| GLOBlit_5779 |  | search_blocks |
| GLOBlit_5836 |  | search_blocks |
| GLOBlit_6063 |  | search_blocks |
| GLOBlit_8042 |  | search_blocks |

#### Compounds (72 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_3 | carbon dioxide | resolve_compound_ids, search_blocks |
| GLOBcomp_1 | water | resolve_compound_ids, search_blocks, search_system_summary |
| GLOBcomp_5 |  | resolve_compound_ids, search_blocks, search_system_summary |
| GLOBcomp_35 | acetic acid | search_blocks |
| GLOBcomp_26 | sodium chloride | search_blocks |
| GLOBcomp_21 | decane | search_blocks |
| GLOBcomp_10 | ethyl acetate | search_blocks |
| GLOBcomp_12 | hexane | search_blocks |
| GLOBcomp_46 | methyl ethanoate | search_blocks |
| GLOBcomp_33 | nonane | search_blocks |
| GLOBcomp_48 | 2-methoxy-2-methylpropane | search_blocks |
| GLOBcomp_22 | pentan-1-ol | search_blocks |
| GLOBcomp_612 | 2,6-dimethylpyridine | search_blocks |
| GLOBcomp_11 | heptane | search_blocks |
| GLOBcomp_17 | octane | search_blocks |
| GLOBcomp_1708 | 3,5-dimethylpyridine | search_blocks |
| GLOBcomp_269 | 1-butanamine | search_blocks |
| GLOBcomp_103 | diethyl carbonate | search_blocks |
| GLOBcomp_14 | benzene | search_blocks |
| GLOBcomp_65 | butyl ethanoate | search_blocks |
| GLOBcomp_8 | toluene | search_blocks |
| GLOBcomp_30 | 1,2-dimethylbenzene | search_blocks |
| GLOBcomp_32 | 1,3-dimethylbenzene | search_blocks |
| GLOBcomp_28 | 1,4-dimethylbenzene | search_blocks |
| GLOBcomp_13 | cyclohexane | search_blocks |
| GLOBcomp_2 | ethanol | search_blocks |
| GLOBcomp_7 | butan-1-ol | search_blocks |
| GLOBcomp_202 | triethylamine | search_blocks |
| GLOBcomp_4 | methanol | search_blocks |
| GLOBcomp_34 | octan-1-ol | search_blocks |
| GLOBcomp_25 | 1,4-dioxane | search_blocks |
| GLOBcomp_140 | 2-ethoxyethan-1-ol | search_blocks |
| GLOBcomp_832 | 1-methyl-4-(1-methylethenyl)cyclohexene | search_blocks |
| GLOBcomp_78 | 1-hexyne | search_blocks |
| GLOBcomp_1411 | 2-hexyne | search_blocks |
| GLOBcomp_64 | 1-ethyl-3-methylimidazolium bis((trifluoromethyl)sulfonyl)imide | search_blocks |
| GLOBcomp_55 | 1-butyl-3-methylimidazolium hexafluorophosphate | search_blocks |
| GLOBcomp_69 | oct-1-ene | search_blocks |
| GLOBcomp_686 | ethyl 3-oxobutanoate | search_blocks |
| GLOBcomp_37 | 2,2,4-trimethylpentane | search_blocks |
| GLOBcomp_535 | pyrrole | search_blocks |
| GLOBcomp_115 | propyl ethanoate | search_blocks |
| GLOBcomp_240 | ethyl methanoate | search_blocks |
| GLOBcomp_295 | tributyl phosphate | search_blocks |
| GLOBcomp_301 | 1-butyl-4-methylpyridinium tetrafluoroborate | search_blocks |
| GLOBcomp_70 | dibutyl ether | search_blocks |
| GLOBcomp_271 | benzaldehyde | search_blocks |
| GLOBcomp_178 | cyclohexanol | search_blocks |
| GLOBcomp_1054 | diethyl ethanedioate | search_blocks |
| GLOBcomp_39 | butanone | search_blocks |
| GLOBcomp_170 | nitrobenzene | search_blocks |
| GLOBcomp_1789 | (-)-fenchone | search_blocks |
| GLOBcomp_826 | 1-butyl-1-methylpyrrolidinium tetracyanoborate | search_blocks |
| GLOBcomp_877 | 1-hexylpyridinium bis(trifluromethylsulfonyl)imide | search_blocks |
| GLOBcomp_189 | 2-butoxyethan-1-ol | search_blocks |
| GLOBcomp_42 | methylcyclohexane | search_blocks |
| GLOBcomp_413 | ethane-1,2-diamine | search_blocks |
| GLOBcomp_1000 | methyl 2-hydroxypropanoate | search_blocks |
| GLOBcomp_390 | DL-ethyl lactate | search_blocks |
| GLOBcomp_327 | 1-methylimidazole | search_blocks |
| GLOBcomp_7670 | ethyl 2-methylpropanoate | search_blocks |
| GLOBcomp_101 | 4-methylpentan-2-one | search_blocks |
| GLOBcomp_6 | propan-2-ol | search_blocks |
| GLOBcomp_345 | methyl methanoate | search_blocks |
| GLOBcomp_683 | 1,3-propanediamine | search_blocks |
| GLOBcomp_1270 | 1,2-propanediamine | search_blocks |
| GLOBcomp_31 | dimethyl sulfoxide | search_blocks |
| GLOBcomp_265 | 2,2,2-trifluoroethanol | search_blocks |
| GLOBcomp_1526 | trimethyl orthophosphate | search_blocks |
| GLOBcomp_268 | 2-pyrrolidinone | search_blocks |
| GLOBcomp_133 | formamide | search_blocks |
| GLOBcomp_9 | acetone | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_summary |

#### Measurements (15 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_2104 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_2046 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_2105 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_254 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_200 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_224 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_44 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_262 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_657 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_747 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_78 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_34 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |

#### Phases (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |
| GLOBphase_10 |  | search_blocks |

#### Variables (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_6 | Solvent: Molality, mol/kg | search_blocks |
| GLOBvar_8 | Solvent: Mole fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Solvents (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_10 |  | search_blocks |
| GLOBsolvent_1 |  | search_blocks |
| GLOBsolvent_91 |  | search_blocks |
| GLOBsolvent_146 |  | search_blocks |
| GLOBsolvent_37 |  | search_blocks |
| GLOBsolvent_25 |  | search_blocks |
| GLOBsolvent_9 |  | search_blocks |
| GLOBsolvent_6 |  | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 55 |
| Unique Compounds | 72 |
| Unique Properties | 1 |
| Unique Measurements | 15 |
| Unique Phases | 2 |
| Unique Variables | 5 |
| Unique Constraints | 2 |
| Unique Solvents | 8 |
| Total DOIs | 55 |
| Unique parent blocks | 100 |
| Explicit block/subsystem targets | 101 |
| Subsystem targets | 1 |
| Target-matched data points | 4,217 |

---

## 3. DOI & Block References

**Unique DOIs:** 55  |  **Parent blocks:** 100  |  **Explicit targets:** 101  |  **Subsystems:** 1  |  **Target-matched datapoints:** 3,568

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.12.005 | 4 | 152 | binary | search_blocks |
| 10.1016/j.fluid.2004.12.013 | 3 | 90 | binary, ternary | search_blocks |
| 10.1016/j.fluid.2005.03.028 | 6 | 66 | binary | search_blocks |
| 10.1016/j.fluid.2005.04.020 | 2 | 14 | binary | search_blocks |
| 10.1016/j.fluid.2005.05.029 | 1 | 160 | binary | search_blocks |
| 10.1016/j.fluid.2005.06.011 | 6 | 62 | binary | search_blocks |
| 10.1016/j.fluid.2005.08.001 | 7 | 314 | binary, ternary | search_blocks |
| 10.1016/j.fluid.2005.11.016 | 2 | 20 | binary | search_blocks |
| 10.1016/j.fluid.2005.12.029 | 4 | 73 | binary, ternary | search_blocks |
| 10.1016/j.fluid.2006.03.020 | 4 | 142 | binary, ternary | search_blocks |
| 10.1016/j.fluid.2006.04.016 | 5 | 239 | binary | search_blocks |
| 10.1016/j.fluid.2006.05.027 | 1 | 125 | binary | search_blocks |
| 10.1016/j.fluid.2006.06.006 | 3 | 388 | binary, ternary | search_blocks |
| 10.1016/j.fluid.2006.08.007 | 2 | 16 | binary | search_blocks |
| 10.1016/j.fluid.2007.06.001 | 1 | 8 | binary | search_blocks |
| 10.1016/j.fluid.2007.06.007 | 1 | 32 | binary | search_blocks |
| 10.1016/j.fluid.2007.07.063 | 1 | 9 | binary | search_blocks |
| 10.1016/j.fluid.2008.03.012 | 1 | 78 | binary | search_blocks |
| 10.1016/j.fluid.2008.06.011 | 2 | 61 | binary, ternary | search_blocks |
| 10.1016/j.fluid.2012.06.031 | 1 | 13 | binary | search_blocks |
| 10.1016/j.fluid.2013.10.029 | 1 | 34 | binary | search_blocks |
| 10.1016/j.fluid.2014.08.022 | 2 | 43 | binary | search_blocks |
| 10.1016/j.fluid.2015.07.053 | 2 | 62 | binary, ternary | search_blocks |
| 10.1016/j.jct.2005.04.015 | 1 | 56 | binary | search_blocks |
| 10.1016/j.jct.2006.08.001 | 1 | 16 | binary | search_blocks |
| 10.1016/j.jct.2008.02.019 | 1 | 33 | binary | search_blocks |
| 10.1016/j.jct.2008.12.004 | 1 | 21 | binary | search_blocks |
| 10.1016/j.jct.2009.07.001 | 1 | 21 | binary | search_blocks |
| 10.1016/j.jct.2011.05.014 | 1 | 12 | binary | search_blocks |
| 10.1016/j.jct.2012.02.037 | 1 | 11 | binary | search_blocks |
| 10.1016/j.jct.2013.05.024 | 1 | 76 | binary | search_blocks |
| 10.1016/j.jct.2013.06.018 | 1 | 16 | binary | search_blocks |
| 10.1016/j.jct.2013.09.026 | 1 | 57 | ternary | search_blocks |
| 10.1016/j.jct.2014.09.001 | 1 | 10 | binary | search_blocks |
| 10.1016/j.jct.2015.01.003 | 2 | 76 | binary | search_blocks |
| 10.1016/j.jct.2015.04.034 | 1 | 44 | binary | search_blocks |
| 10.1016/j.jct.2015.06.004 | 1 | 39 | binary | search_blocks |
| 10.1016/j.jct.2015.06.023 | 1 | 15 | binary | search_blocks |
| 10.1016/j.jct.2016.08.003 | 1 | 9 | binary | search_blocks |
| 10.1016/j.jct.2016.10.005 | 2 | 74 | binary | search_blocks |
| 10.1016/j.jct.2016.12.036 | 1 | 9 | binary | search_blocks |
| 10.1016/j.jct.2018.07.013 | 2 | 22 | binary | search_blocks |
| 10.1016/j.jct.2018.12.019 | 1 | 13 | binary | search_blocks |
| 10.1016/j.jct.2019.105884 | 1 | 22 | binary | search_blocks |
| 10.1016/j.tca.2004.09.012 | 1 | 10 | binary | search_blocks |
| 10.1016/j.tca.2005.03.009 | 1 | 27 | binary | search_blocks |
| 10.1016/j.tca.2005.06.011 | 2 | 60 | binary, ternary | search_blocks |
| 10.1016/j.tca.2005.11.041 | 1 | 57 | binary | search_blocks |
| 10.1016/j.tca.2006.08.006 | 2 | 380 | binary | search_blocks |
| 10.1016/j.tca.2006.10.025 | 1 | 17 | binary | search_blocks |
| 10.1016/j.tca.2007.04.012 | 1 | 25 | binary | search_blocks |
| 10.1016/j.tca.2008.02.015 | 1 | 18 | binary | search_blocks |
| 10.1016/j.tca.2009.03.014 | 1 | 14 | binary | search_blocks |
| 10.1016/j.tca.2013.02.010 | 1 | 44 | binary | search_blocks |
| 10.1021/je020149l | 3 | 63 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.12.005 | PROPblock_17 | declared | 38 | binary | — | search_blocks |
| 10.1016/j.fluid.2004.12.005 | PROPblock_18 | declared | 38 | binary | — | search_blocks |
| 10.1016/j.fluid.2004.12.005 | PROPblock_19 | declared | 38 | binary | — | search_blocks |
| 10.1016/j.fluid.2004.12.005 | PROPblock_5 | declared | 38 | binary | — | search_blocks |
| 10.1016/j.fluid.2004.12.013 | PROPblock_1 | declared | 20 | binary | — | search_blocks |
| 10.1016/j.fluid.2004.12.013 | PROPblock_2 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.fluid.2004.12.013 | PROPblock_3 | declared | 52 | ternary | — | search_blocks |
| 10.1016/j.fluid.2005.03.028 | PROPblock_1 | declared | 12 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.03.028 | PROPblock_11 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.03.028 | PROPblock_3 | declared | 13 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.03.028 | PROPblock_5 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.03.028 | PROPblock_7 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.03.028 | PROPblock_9 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.04.020 | PROPblock_10 | declared | 7 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.04.020 | PROPblock_9 | declared | 7 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.05.029 | PROPblock_1 | declared | 160 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.06.011 | PROPblock_15 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.06.011 | PROPblock_17 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.06.011 | PROPblock_19 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.06.011 | PROPblock_21 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.06.011 | PROPblock_23 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.06.011 | PROPblock_25 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_11 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_13 | declared | 20 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_15 | declared | 104 | ternary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_17 | declared | 113 | ternary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_7 | declared | 23 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_9 | declared | 20 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.11.016 | PROPblock_4 | declared | 7 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.11.016 | PROPblock_6 | declared | 13 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.12.029 | PROPblock_1 | declared | 14 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.12.029 | PROPblock_4 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.12.029 | PROPblock_5 | declared | 22 | ternary | — | search_blocks |
| 10.1016/j.fluid.2005.12.029 | PROPblock_6 | declared | 19 | ternary | — | search_blocks |
| 10.1016/j.fluid.2006.03.020 | PROPblock_1 | declared | 19 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.03.020 | PROPblock_2 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.03.020 | PROPblock_3 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.03.020 | PROPblock_4 | declared | 97 | ternary | — | search_blocks |
| 10.1016/j.fluid.2006.04.016 | PROPblock_10 | declared | 51 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.04.016 | PROPblock_11 | declared | 36 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.04.016 | PROPblock_7 | declared | 58 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.04.016 | PROPblock_8 | declared | 59 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.04.016 | PROPblock_9 | declared | 35 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.05.027 | PROPblock_2 | declared | 125 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.06.006 | PROPblock_2 | declared | 143 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.06.006 | PROPblock_3 | declared | 113 | ternary | — | search_blocks |
| 10.1016/j.fluid.2006.06.006 | PROPblock_4 | declared | 132 | ternary | — | search_blocks |
| 10.1016/j.fluid.2006.08.007 | PROPblock_4 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.08.007 | PROPblock_6 | declared | 6 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.06.001 | PROPblock_15 | declared | 8 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.06.007 | PROPblock_6 | declared | 32 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.07.063 | PROPblock_7 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.fluid.2008.03.012 | PROPblock_4 | declared | 78 | binary | — | search_blocks |
| 10.1016/j.fluid.2008.06.011 | PROPblock_1 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2008.06.011 | PROPblock_2 | declared | 44 | ternary | — | search_blocks |
| 10.1016/j.fluid.2012.06.031 | PROPblock_9 | declared | 13 | binary | — | search_blocks |
| 10.1016/j.fluid.2013.10.029 | PROPblock_14 | declared | 34 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.08.022 | PROPblock_1 | declared | 22 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.08.022 | PROPblock_3 | declared | 21 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.07.053 | PROPblock_1 | declared | 59 | ternary | — | search_blocks |
| 10.1016/j.fluid.2015.07.053 | PROPblock_1 | BLKsubsys_1 | 3 | binary | — | search_blocks |
| 10.1016/j.jct.2005.04.015 | PROPblock_1 | declared | 56 | binary | — | search_blocks |
| 10.1016/j.jct.2006.08.001 | PROPblock_3 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.jct.2008.02.019 | PROPblock_9 | declared | 33 | binary | — | search_blocks |
| 10.1016/j.jct.2008.12.004 | PROPblock_3 | declared | 21 | binary | — | search_blocks |
| 10.1016/j.jct.2009.07.001 | PROPblock_2 | declared | 21 | binary | — | search_blocks |
| 10.1016/j.jct.2011.05.014 | PROPblock_3 | declared | 12 | binary | — | search_blocks |
| 10.1016/j.jct.2012.02.037 | PROPblock_16 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.jct.2013.05.024 | PROPblock_4 | declared | 76 | binary | — | search_blocks |
| 10.1016/j.jct.2013.06.018 | PROPblock_1 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.jct.2013.09.026 | PROPblock_4 | declared | 57 | ternary | — | search_blocks |
| 10.1016/j.jct.2014.09.001 | PROPblock_14 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2015.01.003 | PROPblock_1 | declared | 38 | binary | — | search_blocks |
| 10.1016/j.jct.2015.01.003 | PROPblock_2 | declared | 38 | binary | — | search_blocks |
| 10.1016/j.jct.2015.04.034 | PROPblock_4 | declared | 44 | binary | — | search_blocks |
| 10.1016/j.jct.2015.06.004 | PROPblock_25 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2015.06.023 | PROPblock_6 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2016.08.003 | PROPblock_17 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2016.10.005 | PROPblock_1 | declared | 37 | binary | — | search_blocks |
| 10.1016/j.jct.2016.10.005 | PROPblock_2 | declared | 37 | binary | — | search_blocks |
| 10.1016/j.jct.2016.12.036 | PROPblock_24 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2018.07.013 | PROPblock_21 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.jct.2018.07.013 | PROPblock_33 | declared | 11 | binary | — | search_blocks |
| 10.1016/j.jct.2018.12.019 | PROPblock_19 | declared | 13 | binary | — | search_blocks |
| 10.1016/j.jct.2019.105884 | PROPblock_24 | declared | 22 | binary | — | search_blocks |
| 10.1016/j.tca.2004.09.012 | PROPblock_10 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.tca.2005.03.009 | PROPblock_3 | declared | 27 | binary | — | search_blocks |
| 10.1016/j.tca.2005.06.011 | PROPblock_1 | declared | 3 | binary | — | search_blocks |
| 10.1016/j.tca.2005.06.011 | PROPblock_2 | declared | 57 | ternary | — | search_blocks |
| 10.1016/j.tca.2005.11.041 | PROPblock_1 | declared | 57 | binary | — | search_blocks |
| 10.1016/j.tca.2006.08.006 | PROPblock_13 | declared | 185 | binary | — | search_blocks |
| 10.1016/j.tca.2006.08.006 | PROPblock_15 | declared | 195 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_22 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2007.04.012 | PROPblock_12 | declared | 25 | binary | — | search_blocks |
| 10.1016/j.tca.2008.02.015 | PROPblock_3 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.tca.2009.03.014 | PROPblock_14 | declared | 14 | binary | — | search_blocks |
| 10.1016/j.tca.2013.02.010 | PROPblock_8 | declared | 44 | binary | — | search_blocks |
| 10.1021/je020149l | PROPblock_10 | declared | 21 | binary | — | search_blocks |
| 10.1021/je020149l | PROPblock_11 | declared | 20 | binary | — | search_blocks |
| 10.1021/je020149l | PROPblock_12 | declared | 22 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_3', 'GLOBcomp_1'], limit=50, p… | 794 | DISCARD | 736 | 9.2 |
| 2 | 2 | `search_blocks` | compound=['GLOBcomp_3', 'GLOBcomp_1'], limit=50, p… | 654 | DISCARD | 582 | 13.8 |
| 3 | 3 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Find the correct G… | 299 | KEEP | 299 | 4.7 |
| 4 | 4 | `search_blocks` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=50, p… | 1,119 | KEEP | 1104 | 10.5 |
| 5 | 1 | `L1_query` | context=Looking for HE data to quanti…, id_catalog… | 383 | — | — | 97.2 |
| 6 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 263 | KEEP | 263 | 4.1 |
| 7 | 4 | `search_blocks` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=50, p… | 679 | DISCARD | 621 | 7.7 |
| 8 | 6 | `search_blocks` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=50, p… | 441 | KEEP | 441 | 12.6 |
| 9 | 6 | `search_system_summary` | compound=['GLOBcomp_5', 'GLOBcomp_1'], property=GL… | 615 | DISCARD | 549 | 8.2 |
| 10 | 2 | `L1_query` | context=Looking for HE data to quanti…, id_catalog… | 2,072 | — | — | 100.6 |
| 11 | 2 | `search_blocks` | compound=['GLOBcomp_3', 'GLOBcomp_1'], limit=50, p… | 1,144 | KEEP | 1130 | 14.3 |
| 12 | 2 | `search_blocks` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=50, p… | 960 | KEEP | 930 | 19.1 |
| 13 | 2 | `search_blocks` | limit=50, property=GLOBprop_17, purpose=Find all H… | 830 | KEEP | 830 | 17.3 |
| 14 | 3 | `L1_query` | context=Previous searches with GLOBco…, id_catalog… | 182 | — | — | 171.9 |
| 15 | 2 | `resolve_compound_ids` | limit=10, min_score=40, purpose=Resolve compound I… | 328 | KEEP | 328 | 3.8 |
| 16 | 3 | `search_blocks` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=50, p… | 590 | KEEP | 560 | 21.8 |
| 17 | 3 | `search_blocks` | compound=['GLOBcomp_5'], limit=50, property=GLOBpr… | 721 | KEEP | 677 | 33.4 |
| 18 | 3 | `resolve_compound_ids` | limit=5, min_score=40, purpose=Check what compound… | 173 | KEEP | 173 | 3.5 |
| 19 | 4 | `L1_query` | context=Previous searches for binary …, id_catalog… | 11,308 | — | — | 172.0 |
| | | **TOTAL (19 tools)** | | **23,555** | | **9,223** | **725.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,894 | 3,894 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 7,075 | 7,075 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 5,160 | 5,160 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,106 | 10,711 | 1,192 | 6.4 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,165 | 21,808 | 904 | 6.2 |
| 3 | L1-worker | claudeopus46 | 2,065 | 577 | 2,642 | 1,240 | 8.7 |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,476 | 23,119 | 889 | 6.1 |
| 5 | L1-worker | claudeopus46 | 2,065 | 2,996 | 5,061 | 1,058 | 9.4 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,667 | 24,310 | 629 | 5.2 |
| 7 | L1-worker | claudeopus46 | 2,065 | 396 | 2,461 | 590 | 4.6 |
| 8 | L1-worker | claudeopus46 | 20,610 | 5,189 | 25,799 | 443 | 4.4 |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,436 | 25,079 | 861 | 6.6 |
| 10 | L1-worker | claudeopus46 | 2,065 | 1,298 | 3,363 | 1,618 | 9.4 |
| 11 | L1-worker | claudeopus46 | 20,643 | 6,061 | 26,704 | 2,364 | 14.4 |
| 12 | L1-worker | claudeopus46 | 1,356 | 1,899 | 3,255 | 638 | 4.5 |
| 13 | L1-worker | claudeopus46 | 536 | 1,779 | 2,315 | 794 | 5.0 |
| 14 | L1-worker | claudeopus46 | 1,323 | 7,890 | 9,213 | 1,017 | 6.8 |
| 15 | L1-worker | claudeopus46 | 298 | 1,739 | 2,037 | 824 | 4.1 |
| 16 | L1-worker | claudeopus46 | 1,160 | 9,261 | 10,421 | 819 | 4.4 |
| 17 | L0-main | claudeopus46 | 9,605 | 2,001 | 11,606 | 1,580 | 9.8 |
| 18 | L1-worker | claudeopus46 | 20,643 | 1,326 | 21,969 | 625 | 5.4 |
| 19 | L1-worker | claudeopus46 | 20,643 | 2,572 | 23,215 | 815 | 4.9 |
| 20 | L1-worker | claudeopus46 | 2,065 | 435 | 2,500 | 442 | 3.9 |
| 21 | L1-worker | claudeopus46 | 20,643 | 2,721 | 23,364 | 792 | 5.6 |
| 22 | L1-worker | claudeopus46 | 20,643 | 4,134 | 24,777 | 724 | 3.9 |
| 23 | L1-worker | claudeopus46 | 2,065 | 568 | 2,633 | 1,065 | 7.3 |
| 24 | L1-worker | claudeopus46 | 20,643 | 4,764 | 25,407 | 1,081 | 6.4 |
| 25 | L1-worker | claudeopus46 | 20,643 | 6,573 | 27,216 | 1,016 | 4.4 |
| 26 | L1-worker | claudeopus46 | 2,065 | 503 | 2,568 | 763 | 5.3 |
| 27 | L1-worker | claudeopus46 | 2,065 | 624 | 2,689 | 1,180 | 7.8 |
| 28 | L1-worker | claudeopus46 | 20,610 | 8,445 | 29,055 | 573 | 4.6 |
| 29 | L1-worker | claudeopus46 | 20,643 | 7,692 | 28,335 | 3,456 | 18.3 |
| 30 | L1-worker | claudeopus46 | 20,643 | 11,876 | 32,519 | 997 | 4.0 |
| 31 | L1-worker | claudeopus46 | 1,323 | 7,520 | 8,843 | 92 | 2.0 |
| 32 | L1-worker | claudeopus46 | 1,356 | 1,128 | 2,484 | 377 | 3.1 |
| 33 | L1-worker | claudeopus46 | 536 | 1,008 | 1,544 | 557 | 3.8 |
| 34 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.2 |
| 35 | L1-worker | claudeopus46 | 747 | 8,176 | 8,923 | 518 | 4.8 |
| 36 | L0-main | claudeopus46 | 9,605 | 6,818 | 16,423 | 2,291 | 14.4 |
| 37 | L1-worker | claudeopus46 | 20,643 | 3,916 | 24,559 | 1,583 | 9.1 |
| 38 | L1-worker | claudeopus46 | 20,643 | 6,334 | 26,977 | 13,863 | 48.5 |
| 39 | L1-worker | claudeopus46 | 2,065 | 8,763 | 10,828 | 1,518 | 13.3 |
| 40 | L1-worker | claudeopus46 | 2,065 | 3,409 | 5,474 | 1,721 | 14.3 |
| 41 | L1-worker | claudeopus46 | 2,065 | 35,582 | 37,647 | 2,098 | 16.8 |
| 42 | L1-worker | claudeopus46 | 20,643 | 9,251 | 29,894 | 6,254 | 32.4 |
| 43 | L1-worker | claudeopus46 | 20,643 | 16,233 | 36,876 | 3,006 | 15.3 |
| 44 | L1-worker | claudeopus46 | 1,356 | 2,184 | 3,540 | 731 | 4.4 |
| 45 | L1-worker | claudeopus46 | 536 | 2,064 | 2,600 | 799 | 4.7 |
| 46 | L1-worker | claudeopus46 | 1,323 | 9,100 | 10,423 | 1,528 | 9.8 |
| 47 | L1-worker | claudeopus46 | 298 | 2,250 | 2,548 | 1,287 | 5.3 |
| 48 | L0-main | claudeopus46 | 9,605 | 7,577 | 17,182 | 2,183 | 14.2 |
| 49 | L1-worker | claudeopus46 | 20,643 | 4,030 | 24,673 | 657 | 5.0 |
| 50 | L1-worker | claudeopus46 | 20,643 | 5,308 | 25,951 | 15,085 | 56.0 |
| 51 | L1-worker | claudeopus46 | 2,065 | 450 | 2,515 | 462 | 3.7 |
| 52 | L1-worker | claudeopus46 | 20,643 | 5,580 | 26,223 | 2,172 | 11.8 |
| 53 | L1-worker | claudeopus46 | 2,065 | 3,453 | 5,518 | 2,034 | 14.9 |
| 54 | L1-worker | claudeopus46 | 2,065 | 34,726 | 36,791 | 1,444 | 11.5 |
| 55 | L1-worker | claudeopus46 | 2,065 | 34,936 | 37,001 | 1,712 | 13.9 |
| 56 | L1-worker | claudeopus46 | 2,065 | 391 | 2,456 | 354 | 3.4 |
| 57 | L1-worker | claudeopus46 | 20,610 | 8,650 | 29,260 | 418 | 4.1 |
| 58 | L1-worker | claudeopus46 | 20,643 | 7,897 | 28,540 | 2,437 | 13.0 |
| 59 | L1-worker | claudeopus46 | 1,356 | 1,605 | 2,961 | 818 | 4.6 |
| 60 | L1-worker | claudeopus46 | 536 | 1,485 | 2,021 | 918 | 4.9 |
| 61 | L1-worker | claudeopus46 | 1,323 | 7,055 | 8,378 | 1,205 | 7.2 |
| 62 | L1-worker | claudeopus46 | 298 | 1,927 | 2,225 | 1,014 | 4.8 |
| 63 | L1-worker | claudeopus46 | 747 | 16,438 | 17,185 | 694 | 7.0 |
| 64 | L0-main | claudeopus46 | 9,605 | 30,972 | 40,577 | 3,280 | 22.3 |
| 65 | L0-main | claudeopus46 | 1,356 | 2,807 | 4,163 | 953 | 5.3 |
| 66 | L0-main | claudeopus46 | 1,323 | 23,392 | 24,715 | 2,520 | 16.4 |
| 67 | L0-main | claudeopus46 | 298 | 3,188 | 3,486 | 2,272 | 7.9 |


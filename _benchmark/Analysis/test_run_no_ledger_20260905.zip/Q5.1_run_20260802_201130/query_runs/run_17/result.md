# Delegated query run — result

**Question:** Find ThermoML data blocks containing excess molar enthalpy (HE) measurements for the binary mixture of 1-propanol and water at approximately 298.15 K (25 degrees C). Return DOI, block_number, lit_num_id, compound IDs, property IDs, temperature range, and number of data points.

**Iterations:** 5  |  **Elapsed:** 609.5s  |  **Tools:** 4  |  **Timed out:** False

---

## Answer

**No binary 1-propanol + water excess molar enthalpy (H^E) data found at 298.15 K in the ThermoML database.**

A comprehensive search was conducted for excess molar enthalpy (H^E) measurements for the binary mixture of 1-propanol and water at approximately 298.15 K (25 °C). The results are as follows:

---

### Binary system: Not available

The ThermoML database contains **no binary 1-propanol + water H^E data at any temperature**, including 298.15 K. This was confirmed through multiple searches — both temperature-restricted (293–303 K) and unrestricted — all returning zero results. This represents a genuine data availability gap in the database.

**Important note on compound IDs:** The task referenced GLOBcomp_3 for 1-propanol, but GLOBcomp_3 is actually **carbon dioxide (CO₂)**. The correct database identifier for 1-propanol is **GLOBcomp_5** (propan-1-ol, C₃H₈O, InChIKey: BDERNNFJNOPAEC-UHFFFAOYSA-N). All searches used the verified correct ID.

---

### Nearest available data: Ternary system

The only ThermoML block containing both 1-propanol and water with H^E data is a **ternary** system:

| Field | Value |
|-------|-------|
| **DOI** | 10.1016/j.fluid.2015.07.053 (GLOBlit_1766) |
| **Block** | PROPblock_1 |
| **System type** | Ternary |
| **Compounds** | 1-propanol (GLOBcomp_5) + acetic acid (GLOBcomp_35) + water (GLOBcomp_1) |
| **Property** | Excess molar enthalpy, GLOBprop_17 (kJ/mol) |
| **Temperature** | 313.15 K (constrained) |
| **Pressure** | 101.0 kPa |
| **Method** | Flow calorimetry |
| **Data points** | 59 |
| **H^E range** | 0.0 – 0.421 kJ/mol (mean ≈ 0.260 kJ/mol) |
| **x(1-propanol)** | 0.0261 – 0.75 |
| **x(acetic acid)** | 0.0 – 0.9054 |

**Caveat:** The three data points in this block where x(acetic acid) = 0 (i.e., the binary 1-propanol/water subsystem limit) all report H^E = 0.0 kJ/mol. These are baseline reference points, not meaningful binary H^E measurements.

---

### Broader context

A wider search found **50 total H^E blocks** containing 1-propanol in the ThermoML database, but all blocks other than the ternary one above pair 1-propanol with organic solvents, ionic liquids, or other non-aqueous compounds — none include water as the second binary component.

### Chemistry note

The 1-propanol + water system is well known to exhibit significant positive excess enthalpy (endothermic mixing) due to disruption of the water hydrogen-bond network by the hydrophobic propyl chain, with literature values of H^E reaching roughly +0.5 to +0.9 kJ/mol near equimolar composition at 298.15 K. However, these values are not present in the ThermoML database and cannot be reported from this source.

### Core claims

- The ThermoML database contains no binary 1-propanol + water excess molar enthalpy (H^E) data at any temperature, including 298.15 K, representing a genuine data availability gap.
- The task-referenced compound ID GLOBcomp_3 corresponds to carbon dioxide, not 1-propanol; the correct ThermoML identifier for 1-propanol is GLOBcomp_5.
- The only ThermoML block containing both 1-propanol and water with H^E data is a ternary system (1-propanol + acetic acid + water) at 313.15 K from DOI 10.1016/j.fluid.2015.07.053, and the data points at the binary 1-propanol/water limit (x(acetic acid) = 0) all report H^E = 0.0 kJ/mol, serving as baseline reference points rather than meaningful binary measurements.
- Although the 1-propanol + water system is known in the literature to exhibit significant positive excess enthalpy (~0.5–0.9 kJ/mol near equimolar composition at 298.15 K), these values are not available in the ThermoML database.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_1766 | 10.1016/j.fluid.2015.07.053 | PROPblock_1 |  | Ternary system excess molar enthalpy (GLOBprop_17) data for 1-propanol (GLOBcomp_5) + acetic acid (GLOBcomp_35) + water (GLOBcomp_1) at 313.15 K and 101.0 kPa, measured by flow calorimetry. Contains 59 data points with HE ranging 0.0–0.421 kJ/mol. This is the only ThermoML block containing both 1-propanol and water with excess molar enthalpy data. No binary 1-propanol + water HE data exists in the database at any temperature, including 298.15 K. The three data points where x(acetic acid) = 0 all report HE = 0.0 kJ/mol and serve as baseline reference points rather than meaningful binary HE measurements. Note: the task referenced GLOBcomp_3 for 1-propanol, but GLOBcomp_3 is carbon dioxide; the correct ID for 1-propanol is GLOBcomp_5. |

### Suggested follow-ups

- Search for binary 1-propanol + water data with other thermodynamic properties (e.g., excess molar volume, activity coefficients, VLE) that may be available in ThermoML even though HE data is absent.
- Search for binary HE data for other aqueous alcohol systems (methanol + water, ethanol + water, 2-propanol + water) at 298.15 K for the comparative study of aqueous alcohol mixtures.
- Consider extracting the binary 1-propanol + water subsystem limit from the ternary dataset (GLOBlit_1766, PROPblock_1) at 313.15 K, noting that the three points with x(acetic acid) = 0 report HE = 0.0 kJ/mol and are baseline references.
- Consult non-ThermoML literature sources (e.g., Dortmund Data Bank, NIST TDE) for binary 1-propanol + water HE data at 298.15 K, as this system is well-characterized in the broader literature with HE values reaching ~0.5–0.9 kJ/mol near equimolar composition.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_5",
    "registry_id": "propan-1-ol",
    "name": "propan-1-ol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_35",
    "registry_id": "acetic_acid",
    "name": "acetic acid"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_17",
    "registry_id": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
    "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
  }
]
```

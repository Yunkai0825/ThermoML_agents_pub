# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_5 | propan-1-ol | propan-1-ol |
| comp | GLOBcomp_35 | acetic_acid | acetic acid |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find excess molar enthalpy (HE) data blocks for binary mixture of 1-propanol and water at approximately 298.15 K → stored as L1_query_1
- [L1] Find any excess molar enthalpy (HE) data blocks containing 1-propanol and water in the ThermoML database → stored as L1_query_2

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "No excess molar enthalpy (HE) data blocks were found in the ThermoML database for the binary mixture of 1-propanol (GLOBcomp_5) + water (GLOBcomp_1) at any temperature, including approximately 298.15 K.\n\nThe search was conducted using:\n- **Compounds:** 1-propanol (GLOBcomp_5) and water (GLOBcomp_1)\n- **Property:** Excess molar enthalpy / molar enthalpy of mixing (GLOBprop_17, kJ/mol) — confirmed as the correct and only matching property ID\n- **System type:** binary (and also checked with broader scope including subsystem views of higher-component systems)\n- **Temperature:** Both restricted (~293–303 K) and unrestricted searches were attempted\n\nAll searches returned zero results. The ThermoML database does not contain HE measurements for the 1-propanol + water binary system. This is a data availability gap rather than an ID or query issue — the compound IDs (GLOBcomp_5 for 1-propanol, GLOBcomp_1 for water) and property ID (GLOBprop_17) were all verified as correct.",
  "core_claims": [
    "No excess molar enthalpy (HE) data for the binary mixture of 1-propanol and water were found in the ThermoML database at any temperature, including approximately 298.15 K, despite verified correct compound and property identifiers.",
    "The absence of results represents a data availability gap in the ThermoML database rather than a query or identifier error."
  ],
  "status": "no_results",
  "summary": "No excess molar enthalpy (HE) data were found in the ThermoML database for the binary mixture of 1-propanol (GLOBcomp_5) + water (GLOBcomp_1) at any temperature, including approximately 298.15 K. Searches used the verified compound IDs (GLOBcomp_5 for 1-propanol, GLOBcomp_1 for water) and property ID (GLOBprop_17 for excess molar enthalpy, kJ/mol), with both temperature-restricted and unrestricted queries, all returning zero results. This represents a data availability gap in the ThermoML database rather than a query or identifier error.",
  "core_id_updates": [],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "A comprehensive search of the ThermoML database for excess molar enthalpy (HE, GLOBprop_17) data containing both 1-propanol (GLOBcomp_5) and water (GLOBcomp_1) — with no restriction on system type — found **only one data block**:\n\n**Block found:**\n- **DOI:** 10.1016/j.fluid.2015.07.053 (GLOBlit_1766)\n- **Block:** PROPblock_1\n- **System type:** Ternary\n- **Compounds:** 1-propanol (GLOBcomp_5) + acetic acid (GLOBcomp_35) + water (GLOBcomp_1)\n- **Temperature:** 313.15 K\n- **Property:** Excess molar enthalpy (GLOBprop_17, kJ/mol)\n\n**Important caveat:** This is a ternary system (1-propanol + acetic acid + water), not a binary 1-propanol + water system. The three binary 1-propanol/water subsystem data points (where x(acetic acid) = 0) all report H_mix = 0.0 kJ/mol — these are baseline reference points, not meaningful binary HE measurements.\n\n**Additional context:**\n- GLOBcomp_3 was confirmed to be carbon dioxide (CO₂), not 1-propanol. The correct and only ID for 1-propanol is GLOBcomp_5.\n- A broader search for all HE blocks containing 1-propanol (GLOBcomp_5) returned 50 blocks total. Among these, only the ternary block above (GLOBlit_1766, PROPblock_1) contains water. All other blocks pair 1-propanol with organic solvents, ionic liquids, or other non-aqueous compounds.\n- **No binary 1-propanol + water HE data exists in the ThermoML database at any temperature**, including 298.15 K. This represents a data availability gap in the database.",
  "core_claims": [
    "The ThermoML database contains no binary 1-propanol + water excess molar enthalpy (HE) data at any temperature, including 298.15 K.",
    "The only ThermoML block containing both 1-propanol and water with excess molar enthalpy data is a ternary system (1-propanol + acetic acid + water) at 313.15 K (DOI 10.1016/j.fluid.2015.07.053), in which the three data points where the acetic acid mole fraction is zero all report HE = 0.0 kJ/mol and serve as baseline reference points rather than meaningful binary measurements.",
    "A broader search found 50 excess molar enthalpy blocks containing 1-propanol, but all blocks other than the ternary one pair 1-propanol with organic solvents, ionic liquids, or other non-aqueous compounds, confirming a data availability gap for the binary 1-propanol + water system."
  ],
  "status": "success",
  "summary": "A search of the ThermoML database for excess molar enthalpy (HE) data containing both 1-propanol (GLOBcomp_5) and water (GLOBcomp_1) found only one relevant data block: DOI 10.1016/j.fluid.2015.07.053 (GLOBlit_1766, PROPblock_1). This block reports HE for the ternary system 1-propanol + acetic acid (GLOBcomp_35) + water at 313.15 K, not a binary 1-propanol + water system. The three data points where acetic acid mole fraction is zero all report HE = 0.0 kJ/mol, serving as baseline references rather than meaningful binary measurements. A broader search across all 50 HE blocks containing 1-propanol confirmed that no other block includes water; all pair 1-propanol with organic solvents, ionic liquids, or other non-aqueous compounds. No binary 1-propanol + water excess molar enthalpy data exists in the ThermoML database at any temperature, including 298.15 K, representing a data availability gap.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_5",
      "registry_id": "propan-1-ol",
      "name": "propan-1-ol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_35",
      "registry_id": "acetic_acid",
      "name": "acetic acid"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_1766",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "ternary",
      "comp_num_ids": [
        "GLOBcomp_35",
        "GLOBcomp_5",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy (HE) data for the ternary system 1-propanol (GLOBcomp_5) + acetic acid (GLOBcomp_35) + water (GLOBcomp_1) at 313.15 K, from DOI 10.1016/j.fluid.2015.07.053. This is the only block in the ThermoML database containing HE data with both 1-propanol and water. Note: the three binary 1-propanol/water subsystem points (where x(acetic acid) = 0) all report H_mix = 0.0 kJ/mol, serving as baseline reference points rather than meaningful binary HE measurements. GLOBcomp_3 was confirmed to be carbon dioxide, not 1-propanol; the correct and only ID for 1-propanol is GLOBcomp_5. No binary 1-propanol + water HE data exists in the database at any temperature.",
      "doi": "10.1016/j.fluid.2015.07.053",
      "lit_id": "2015-let-tsv-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_3",
      "n_datapoints": 59,
      "n_components": 3,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_35",
          "name": "acetic acid",
          "formula": "C2H4O2",
          "inchi_key": "QTBSBXVTEAMEQO-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_5",
          "name": "propan-1-ol",
          "formula": "C3H8O",
          "inchi_key": "BDERNNFJNOPAEC-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 313.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0261,
            "max": 0.75,
            "n_unique": 59
          },
          "range_min": 0.0261,
          "range_max": 0.75
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 0.9054,
            "n_unique": 53
          },
          "range_min": 0.0,
          "range_max": 0.9054
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_12",
          "meas_ID": "flow_calorimetry",
          "method_standard": "Flow calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": 0.0,
            "max": 0.421,
            "mean": 0.259746,
            "std": 0.105467,
            "n": 59
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0,
          "range_max": 0.421
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "ternary",
      "declared_n_components": 3,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_35",
          "name": "acetic acid",
          "formula": "C2H4O2",
          "inchi_key": "QTBSBXVTEAMEQO-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_5",
          "name": "propan-1-ol",
          "formula": "C3H8O",
          "inchi_key": "BDERNNFJNOPAEC-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 59,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


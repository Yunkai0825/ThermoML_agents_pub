# Delegated query run — result

**Question:** Find ThermoML data blocks containing excess molar enthalpy (HE) measurements for the binary mixture of ethanol and water at approximately 298.15 K (25 degrees C). Return DOI, block_number, lit_num_id, compound IDs, property IDs, temperature range, and number of data points.

**Iterations:** 2  |  **Elapsed:** 117.7s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

The ThermoML database contains **four data blocks** reporting excess molar enthalpy (H^E) for the binary ethanol + water system at approximately 298.15 K (25 °C). Here is a summary of each:

---

### Block 1 — GLOBlit_528 / PROPblock_1
- **DOI:** 10.1016/j.fluid.2007.06.007
- **Compounds:** ethanol (GLOBcomp_2) + water (GLOBcomp_1)
- **Property:** Excess molar enthalpy (GLOBprop_17), kJ/mol
- **Temperature:** 298.15 K (fixed constraint)
- **Pressure:** 101.0 kPa
- **Data points:** 15
- **Composition range:** x(ethanol) = 0.000102–0.001551 (very dilute ethanol in water)
- **H^E range:** −0.01537 to −0.00104 kJ/mol
- **Method:** Calvet calorimetry (GLOBmeas_13)

### Block 2 — GLOBlit_528 / PROPblock_2
- **DOI:** 10.1016/j.fluid.2007.06.007
- **Compounds:** ethanol (GLOBcomp_2) + water (GLOBcomp_1)
- **Property:** Excess molar enthalpy (GLOBprop_17), kJ/mol
- **Temperature:** 298.15 K (fixed constraint)
- **Pressure:** 101.0 kPa
- **Data points:** 15
- **Composition range:** x(water) = 0.001021–0.015286 (very dilute water in ethanol)
- **H^E range:** −0.02961 to −0.00212 kJ/mol
- **Method:** Calvet calorimetry (GLOBmeas_13)

### Block 3 — GLOBlit_2574 / PROPblock_4
- **DOI:** 10.1016/j.jct.2005.06.018
- **Compounds:** ethanol (GLOBcomp_2) + water (GLOBcomp_1)
- **Property:** Excess molar enthalpy (GLOBprop_17), kJ/mol
- **Temperature range:** 298.15–323.15 K (variable; only a subset of points at exactly 298.15 K)
- **Pressure:** 101.0 kPa
- **Data points:** 27 total (across both temperatures)
- **Composition range:** x(ethanol) = 0.033–0.968 (broad, full-range coverage)
- **H^E range:** −0.77 to −0.018 kJ/mol
- **Method:** Calvet calorimetry (GLOBmeas_169)

### Block 4 — GLOBlit_6377 / PROPblock_1
- **DOI:** 10.1016/j.tca.2017.05.023
- **Compounds:** ethanol (GLOBcomp_2) + water (GLOBcomp_1)
- **Property:** Excess molar enthalpy (GLOBprop_17), kJ/mol
- **Temperature:** 298.15 K
- **Pressure:** 100.0 kPa
- **Data points:** 1
- **Composition:** x(ethanol) = 0.102
- **H^E value:** −0.70659 kJ/mol
- **Method:** Flow calorimetry (GLOBmeas_12)

---

### Chemistry Context

All reported H^E values are **negative**, confirming the well-known **exothermic mixing** of ethanol and water. This arises from the extensive hydrogen-bond reorganization that occurs when ethanol molecules are inserted into the water network (or vice versa). The most negative values (around −0.77 kJ/mol) appear near intermediate compositions, consistent with the characteristic asymmetric H^E curve for this system, which typically reaches its minimum near x(ethanol) ≈ 0.3–0.4.

- **Blocks 1 & 2** (GLOBlit_528) together cover both dilute limits with high precision but do not span the full composition range.
- **Block 3** (GLOBlit_2574) provides the broadest composition coverage (x = 0.033–0.968) but includes data at two temperatures; filtering for T = 298.15 K is needed.
- **Block 4** (GLOBlit_6377) offers a single high-quality flow-calorimetry point at x(ethanol) = 0.102, useful as a benchmark.

For a comparative study of aqueous alcohol mixtures, Block 3 is likely the most useful starting point due to its wide composition range, supplemented by the dilute-regime precision of Blocks 1 and 2.

### Core claims

- The ThermoML database contains four data blocks reporting excess molar enthalpy (H^E) for the binary ethanol + water system at approximately 298.15 K and ambient pressure (~101 kPa), sourced from three distinct DOIs.
- All reported H^E values are negative, confirming exothermic mixing of ethanol and water, with the most negative values (around −0.77 kJ/mol) appearing near intermediate compositions, consistent with the characteristic asymmetric H^E curve that typically reaches its minimum near x(ethanol) ≈ 0.3–0.4.
- Two blocks (GLOBlit_528) cover both dilute limits (very dilute ethanol in water and very dilute water in ethanol) with high precision using Calvet calorimetry but do not span the full composition range.
- One block (GLOBlit_2574) provides the broadest composition coverage (x(ethanol) = 0.033–0.968) but includes data at two temperatures (298.15–323.15 K), requiring filtering for the 298.15 K subset.
- One block (GLOBlit_6377) provides a single flow-calorimetry data point at x(ethanol) = 0.102 and 298.15 K, with H^E = −0.70659 kJ/mol, useful as a benchmark.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 | PROPblock_1 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15 K, 101.0 kPa. 15 data points in the very dilute ethanol regime (x_ethanol = 0.000102–0.001551). Calvet calorimetry (GLOBmeas_13). |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 | PROPblock_2 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15 K, 101.0 kPa. 15 data points in the very dilute water regime (x_water = 0.001021–0.015286). Calvet calorimetry (GLOBmeas_13). |
| GLOBlit_2574 | 10.1016/j.jct.2005.06.018 | PROPblock_4 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15–323.15 K, 101.0 kPa. 27 total data points across two temperatures; broad composition range x_ethanol = 0.033–0.968. Calvet calorimetry (GLOBmeas_169). |
| GLOBlit_6377 | 10.1016/j.tca.2017.05.023 | PROPblock_1 |  | Excess molar enthalpy (GLOBprop_17) for ethanol (GLOBcomp_2) + water (GLOBcomp_1) at 298.15 K, 100.0 kPa. Single data point at x_ethanol = 0.102, HE = −0.70659 kJ/mol. Flow calorimetry (GLOBmeas_12). |

### Suggested follow-ups

- Filter GLOBlit_2574 / PROPblock_4 to extract only the data points at exactly 298.15 K (the block spans 298.15–323.15 K).
- Retrieve excess molar enthalpy data for other aqueous alcohol mixtures (methanol+water, 1-propanol+water) at 298.15 K for the comparative study.
- Combine Blocks 1 and 2 from GLOBlit_528 with Block 3 from GLOBlit_2574 to construct a full-composition-range HE curve at 298.15 K.
- Cross-validate the single point from GLOBlit_6377 (x_ethanol = 0.102, HE = −0.70659 kJ/mol) against the broad-range data in GLOBlit_2574.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_17",
    "registry_id": "Excess molar enthalpy",
    "name": "Excess molar enthalpy (kJ/mol)"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_13",
    "registry_id": "Calvet calorimetry",
    "name": "Calvet calorimetry"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_169",
    "registry_id": "Calvet calorimetry",
    "name": "Calvet calorimetry"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_12",
    "registry_id": "Flow calorimetry",
    "name": "Flow calorimetry"
  }
]
```

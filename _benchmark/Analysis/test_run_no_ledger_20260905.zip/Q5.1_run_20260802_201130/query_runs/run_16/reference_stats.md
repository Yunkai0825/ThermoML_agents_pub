# Reference Stats — query-agent

**Run started:** 2026-08-02 20:15:59
**Wall time (at last flush):** 145.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 22,485 | 44,620 | 13,158 | 67,105 | 11,184 | 70.2 | claudeopus46 |
| L1-worker | 10 | 70,319 | 63,457 | 14,510 | 133,776 | 13,377 | 93.7 | claudeopus46 |
| **TOTAL** | **16** | **92,804** | **108,077** | **27,668** | **200,881** | **12,555** | **163.9** | |

**Estimated tokens:** ~50,220 input + ~6,917 output = ~57,137 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 2 | 1 | 3 | 2 | 3 | 4 | 58 |
| `search_system_registry` | 2 | 1 | 3 | 1 | 2 | 2 | 28 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **4** | **2** | **6** | **3** | **5** | **6** | **86** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_528 |  | search_blocks |
| GLOBlit_2574 |  | search_blocks, search_system_registry |
| GLOBlit_6377 |  | search_blocks, search_system_registry |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 | ethanol | search_blocks, search_system_registry |
| GLOBcomp_1 | water | search_blocks, search_system_registry |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 3 |
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Unique Block_Types | 1 |
| Total DOIs | 3 |
| Unique parent blocks | 4 |
| Explicit block/subsystem targets | 4 |
| Subsystem targets | 0 |
| Target-matched data points | 86 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 4  |  **Explicit targets:** 4  |  **Subsystems:** 0  |  **Target-matched datapoints:** 58

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2007.06.007 | 2 | 30 | binary | search_blocks |
| 10.1016/j.jct.2005.06.018 | 1 | 27 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2017.05.023 | 1 | 1 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2007.06.007 | PROPblock_1 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.06.007 | PROPblock_2 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2005.06.018 | PROPblock_4 | declared | 27 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2017.05.023 | PROPblock_1 | declared | 1 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 798 | KEEP | 784 | 15.3 |
| 2 | 2 | `search_system_registry` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 1,051 | KEEP | 1051 | 12.2 |
| 3 | 1 | `L1_query` | context=Looking for HE data to quanti…, id_catalog… | 270 | — | — | 85.0 |
| | | **TOTAL (3 tools)** | | **2,119** | | **1,835** | **112.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,094 | 10,699 | 1,313 | 7.1 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,253 | 21,896 | 854 | 6.3 |
| 3 | L1-worker | claudeopus46 | 2,065 | 7,818 | 9,883 | 1,841 | 14.9 |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,551 | 23,194 | 1,308 | 8.8 |
| 5 | L1-worker | claudeopus46 | 2,065 | 2,366 | 4,431 | 1,713 | 11.9 |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,151 | 24,794 | 2,718 | 16.3 |
| 7 | L1-worker | claudeopus46 | 536 | 1,904 | 2,440 | 783 | 4.9 |
| 8 | L1-worker | claudeopus46 | 1,356 | 2,024 | 3,380 | 845 | 5.3 |
| 9 | L1-worker | claudeopus46 | 1,323 | 6,220 | 7,543 | 2,089 | 10.8 |
| 10 | L1-worker | claudeopus46 | 298 | 2,811 | 3,109 | 1,665 | 7.1 |
| 11 | L1-worker | claudeopus46 | 747 | 32,359 | 33,106 | 694 | 7.4 |
| 12 | L0-main | claudeopus46 | 9,605 | 29,469 | 39,074 | 4,047 | 25.3 |
| 13 | L0-main | claudeopus46 | 1,356 | 3,358 | 4,714 | 1,115 | 6.1 |
| 14 | L0-main | claudeopus46 | 298 | 1,497 | 1,795 | 1,103 | 4.1 |
| 15 | L0-main | claudeopus46 | 1,323 | 5,545 | 6,868 | 2,989 | 16.8 |
| 16 | L0-main | claudeopus46 | 298 | 3,657 | 3,955 | 2,591 | 10.8 |


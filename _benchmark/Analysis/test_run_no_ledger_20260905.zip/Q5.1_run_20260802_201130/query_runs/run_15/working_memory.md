# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find excess molar enthalpy (HE) data blocks for methanol + water at 298.15 K → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "One data block was found containing excess molar enthalpy (HE) data for the binary mixture of methanol + water at 298.15 K:\n\n**Source:** DOI 10.1016/j.tca.2006.02.028 (GLOBlit_5688, ref: 2006-beh-gha-0)  \n**Block:** PROPblock_1  \n**Method:** Titration calorimetry (GLOBmeas_25)  \n**Compounds:** Methanol (GLOBcomp_4, as DOIcomp_1) + Water (GLOBcomp_1, as DOIcomp_2)  \n**Property:** Excess molar enthalpy (GLOBprop_17), reported in kJ/mol  \n**Variable:** Mole fraction of methanol in the liquid phase (GLOBvar_2, as BLKvar_1)  \n**Constraints:** Temperature = 298.15 K (GLOBconstr_2); Pressure = 101.0 kPa (GLOBconstr_1)  \n**Data points:** 13 total (10 retained after RDP compression)  \n**Phase:** Liquid  \n\nRepresentative data at 298.15 K and 101.0 kPa:\n\n| x(methanol) | HE (kJ/mol) | ±U (kJ/mol) |\n|-------------|-------------|-------------|\n| 0.00 | 0.000 | 0.001 |\n| 0.05 | −0.326 | 0.004 |\n| 0.15 | −0.714 | 0.008 |\n| 0.20 | −0.806 | 0.009 |\n| 0.30 | −0.850 | 0.010 |\n| 0.40 | −0.841 | 0.009 |\n\nThe data show that the methanol–water system exhibits exothermic mixing (negative HE) across the composition range, with a minimum near x(methanol) ≈ 0.3 where HE reaches approximately −0.85 kJ/mol. This strong negative excess enthalpy reflects the significant hydrogen-bonding interactions between methanol and water molecules, which are energetically more favorable than the like–like interactions in the pure components.",
  "core_claims": [
    "At 298.15 K and 101.0 kPa, the methanol–water binary mixture exhibits exothermic mixing (negative excess molar enthalpy) across the composition range, with a minimum HE of approximately −0.85 kJ/mol near a methanol mole fraction of about 0.3, as measured by titration calorimetry.",
    "The strongly negative excess molar enthalpy is attributed to hydrogen-bonding interactions between methanol and water that are energetically more favorable than the like–like interactions in the pure components.",
    "The data source is DOI 10.1016/j.tca.2006.02.028, reporting 13 data points (10 retained after RDP compression) for excess molar enthalpy as a function of methanol mole fraction in the liquid phase."
  ],
  "status": "success",
  "summary": "A single data block from DOI 10.1016/j.tca.2006.02.028 reports excess molar enthalpy (HE) for the binary mixture methanol + water at 298.15 K and 101.0 kPa, measured by titration calorimetry. Thirteen data points (10 retained after compression) span the mole fraction of methanol in the liquid phase. The system exhibits exothermic mixing (negative HE) across the composition range, with a minimum near x(methanol) ≈ 0.3 where HE reaches approximately −0.85 kJ/mol, attributed to favorable methanol–water hydrogen-bonding interactions.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_5688",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy (HE) for methanol + water at 298.15 K and 101.0 kPa, measured by titration calorimetry (GLOBmeas_25). 13 data points (10 retained after RDP compression) covering mole fraction of methanol from 0.0 to ~0.4. DOI: 10.1016/j.tca.2006.02.028, ref: 2006-beh-gha-0.",
      "doi": "10.1016/j.tca.2006.02.028",
      "lit_id": "2006-beh-gha-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 13,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_25",
          "meas_ID": "titration_calorimetry",
          "method_standard": null,
          "method_custom": "Titration calorimetry",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": -0.85,
            "max": 0.0,
            "mean": -0.521538,
            "std": 0.302187,
            "n": 13
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": -0.85,
          "range_max": 0.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 13,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


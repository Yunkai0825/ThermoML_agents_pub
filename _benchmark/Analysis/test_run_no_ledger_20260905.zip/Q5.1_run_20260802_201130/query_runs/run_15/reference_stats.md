# Reference Stats — query-agent

**Run started:** 2026-08-02 20:15:59
**Wall time (at last flush):** 96.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 39,337 | 9,316 | 61,524 | 12,304 | 56.8 | claudeopus46 |
| L1-worker | 8 | 47,611 | 27,499 | 7,139 | 75,110 | 9,388 | 51.3 | claudeopus46 |
| **TOTAL** | **13** | **69,798** | **66,836** | **16,455** | **136,634** | **10,510** | **108.1** | |

**Estimated tokens:** ~34,158 input + ~4,113 output = ~38,271 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 13 |
| **TOTAL** | **2** | **1** | **1** | **2** | **1** | **1** | **13** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_5688 |  | search_blocks |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_4 | methanol | search_blocks |
| GLOBcomp_1 | water | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_25 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Constraints | 2 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 13 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 13

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.tca.2006.02.028 | 1 | 13 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.tca.2006.02.028 | PROPblock_1 | declared | 13 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=50, p… | 1,132 | KEEP | 1117 | 11.5 |
| 2 | 1 | `L1_query` | context=Looking for HE data to quanti…, id_catalog… | 8,713 | — | — | 43.9 |
| | | **TOTAL (2 tools)** | | **9,845** | | **1,117** | **55.4** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,098 | 10,703 | 1,287 | 7.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,277 | 21,920 | 914 | 6.8 |
| 3 | L1-worker | claudeopus46 | 2,065 | 2,518 | 4,583 | 1,604 | 11.1 |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,935 | 23,578 | 1,656 | 9.6 |
| 5 | L1-worker | claudeopus46 | 536 | 1,451 | 1,987 | 549 | 4.0 |
| 6 | L1-worker | claudeopus46 | 1,356 | 1,571 | 2,927 | 714 | 4.2 |
| 7 | L1-worker | claudeopus46 | 1,323 | 4,518 | 5,841 | 643 | 6.4 |
| 8 | L1-worker | claudeopus46 | 298 | 1,365 | 1,663 | 516 | 3.3 |
| 9 | L1-worker | claudeopus46 | 747 | 11,864 | 12,611 | 543 | 5.9 |
| 10 | L0-main | claudeopus46 | 9,605 | 19,121 | 28,726 | 2,361 | 17.2 |
| 11 | L0-main | claudeopus46 | 1,356 | 2,181 | 3,537 | 772 | 4.5 |
| 12 | L0-main | claudeopus46 | 1,323 | 13,557 | 14,880 | 2,712 | 18.0 |
| 13 | L0-main | claudeopus46 | 298 | 3,380 | 3,678 | 2,184 | 9.8 |


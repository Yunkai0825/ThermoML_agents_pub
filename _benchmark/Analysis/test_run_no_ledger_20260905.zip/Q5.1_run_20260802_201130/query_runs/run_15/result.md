# Delegated query run — result

**Question:** Find ThermoML data blocks containing excess molar enthalpy (HE) measurements for the binary mixture of methanol and water at approximately 298.15 K (25 degrees C). Return DOI, block_number, lit_num_id, compound IDs, property IDs, temperature range, and number of data points.

**Iterations:** 2  |  **Elapsed:** 68.5s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Excess Molar Enthalpy (H^E) Data for Methanol + Water at 298.15 K

The ThermoML database contains **one data block** with excess molar enthalpy measurements for the binary mixture of methanol and water at 298.15 K (25 °C):

### Block Details

| Field | Value |
|-------|-------|
| **DOI** | 10.1016/j.tca.2006.02.028 (GLOBlit_5688) |
| **Block** | PROPblock_1 |
| **Literature ID** | GLOBlit_5688 (ref: 2006-beh-gha-0) |
| **Compounds** | Methanol (GLOBcomp_4) + Water (GLOBcomp_1) |
| **Property** | Excess molar enthalpy, kJ/mol (GLOBprop_17) |
| **Method** | Titration calorimetry (GLOBmeas_25) |
| **Temperature** | 298.15 K (constrained) |
| **Pressure** | 101.0 kPa (constrained) |
| **Variable** | Mole fraction of methanol (GLOBvar_2), range 0.0–1.0 |
| **Data points** | 13 total (10 retained after RDP compression) |
| **H^E range** | −0.85 to 0.0 kJ/mol |
| **Phase** | Liquid |

### Representative Data (298.15 K, 101.0 kPa)

| x(methanol) | H^E (kJ/mol) | ±U (kJ/mol) |
|:-----------:|:------------:|:-----------:|
| 0.00 | 0.000 | 0.001 |
| 0.05 | −0.326 | 0.004 |
| 0.15 | −0.714 | 0.008 |
| 0.20 | −0.806 | 0.009 |
| 0.30 | −0.850 | 0.010 |
| 0.40 | −0.841 | 0.009 |

### Chemistry Insight

The methanol–water system exhibits **exothermic mixing** (negative H^E) across the entire composition range at 25 °C. The minimum excess enthalpy of approximately **−0.85 kJ/mol** occurs near a methanol mole fraction of ~0.3. This strongly negative H^E reflects the formation of methanol–water hydrogen bonds that are energetically more favorable than the like–like (methanol–methanol and water–water) hydrogen bonds in the pure components. The asymmetric shape of the H^E curve—with the minimum shifted toward the water-rich side—is characteristic of aqueous alcohol mixtures and arises because water's three-dimensional hydrogen-bonding network is partially disrupted and reorganized around the methanol molecules.

No additional data blocks for this system and property at 298.15 K were found in the ThermoML database.

### Core claims

- The ThermoML database contains one data block (DOI 10.1016/j.tca.2006.02.028) with excess molar enthalpy measurements for methanol + water at 298.15 K and 101.0 kPa, obtained by titration calorimetry, comprising 13 data points over the full methanol mole fraction range.
- The methanol–water system exhibits exothermic mixing (negative H^E) across the entire composition range at 298.15 K, with a minimum excess molar enthalpy of approximately −0.85 kJ/mol occurring near a methanol mole fraction of ~0.3.
- The asymmetric H^E curve, with the minimum shifted toward the water-rich side, is characteristic of aqueous alcohol mixtures and reflects the formation of energetically favorable methanol–water hydrogen bonds relative to like–like interactions.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5688 | 10.1016/j.tca.2006.02.028 | PROPblock_1 |  | Excess molar enthalpy (GLOBprop_17) for methanol (GLOBcomp_4) + water (GLOBcomp_1) at 298.15 K and 101.0 kPa, measured by titration calorimetry (GLOBmeas_25). 13 data points covering mole fraction of methanol from 0.0 to 1.0. HE ranges from −0.85 to 0.0 kJ/mol with minimum near x(methanol) ≈ 0.3. Ref: 2006-beh-gha-0. |

### Suggested follow-ups

- Compare HE data for methanol+water with ethanol+water and 1-propanol+water at 298.15 K to study the effect of alkyl chain length on mixing enthalpy.
- Search for HE data for methanol+water at other temperatures (e.g., 308.15 K, 318.15 K) to examine the temperature dependence of excess enthalpy.
- Retrieve excess molar volume (VE) data for methanol+water at 298.15 K to complement the enthalpy analysis with volumetric nonideality.
- Look for additional literature sources reporting HE for methanol+water at 298.15 K to cross-validate the values from GLOBlit_5688.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
    "name": "methanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_17",
    "registry_id": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
    "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_5688",
    "registry_id": "10.1016/j.tca.2006.02.028",
    "name": "2006-beh-gha-0"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_25",
    "registry_id": "titration_calorimetry",
    "name": "Titration calorimetry"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_2",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_1",
    "name": "Mole fraction"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:11:30
**Wall time (at last flush):** 1,091.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 22 | 345,095 | 352,945 | 59,786 | 698,040 | 31,729 | 345.9 | claudeopus46 |
| L1-worker | 10 | 89,310 | 34,744 | 28,634 | 124,054 | 12,405 | 128.7 | claudeopus46 |
| **TOTAL** | **32** | **434,405** | **387,689** | **88,420** | **822,094** | **25,690** | **474.6** | |

**Estimated tokens:** ~205,523 input + ~22,105 output = ~227,628 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'methanol_water_HE… | 150 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'methanol_water_HE… | 132 | — | — | 0.0 |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'methanol_water_HE… | 429 | — | — | 0.1 |
| 4 | 4 | `query_thermoml` | context=, id_catalog=[], instruction=Search for bl… | 389 | — | — | 120.0 |
| 5 | 5 | `run_query_agents_parallel` | queries=[{'question': 'Find data bloc… | 132 | — | — | 0.0 |
| 6 | 6 | `run_query_agents_parallel` | queries=[{'label': 'methanol_water_HE… | 139 | — | — | 0.0 |
| 7 | 7 | `run_query_agents_parallel` | queries=[{'label': 'methanol_water_HE… | 137 | — | — | 0.0 |
| 8 | 8 | `run_query_agents_parallel` | queries=[{'label': 'methanol_water_HE… | 22,700 | — | — | 634.5 |
| 9 | 10 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 597 | — | — | 0.2 |
| 10 | 11 | `inspect_block` | block_number=PROPblock_1, doi=10.1016/j.tca.2006.0… | 1,578 | — | — | 0.0 |
| 11 | 11 | `inspect_block` | block_number=PROPblock_4, doi=10.1016/j.jct.2005.0… | 1,584 | — | — | 0.0 |
| 12 | 12 | `fit_multi_system` | purpose=Fit RK polynomials to HE data…, systems=[{… | 1,099 | — | — | 1.4 |
| 13 | 13 | `predict_from_rk` | coeffs=[-3.09254, 1.5508, -2.02714, …, n_points=20… | 172 | — | — | 0.0 |
| 14 | 13 | `predict_from_rk` | coeffs=[-1.60102, 1.73493, -3.19748,…, n_points=20… | 171 | — | — | 0.0 |
| | | **TOTAL (14 tools)** | | **29,409** | | **0** | **756.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,285 | 2,285 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,251 | 4,251 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 35,029 | 35,029 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 362 | 20,383 | 2,041 | 10.7 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,018 | 21,039 | 15,915 | 76.1 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,661 | 21,682 | 1,474 | 7.5 |
| 4 | L0-main | claudeopus46 | 19,988 | 3,616 | 23,604 | 558 | 5.0 |
| 5 | L0-main | claudeopus46 | 20,021 | 2,859 | 22,880 | 755 | 6.1 |
| 6 | L1-worker | claudeopus46 | 20,643 | 388 | 21,031 | 653 | 4.9 |
| 7 | L1-worker | claudeopus46 | 20,643 | 1,662 | 22,305 | 7,347 | 31.3 |
| 8 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 411 | 3.6 |
| 9 | L1-worker | claudeopus46 | 20,643 | 1,805 | 22,448 | 5,894 | 27.2 |
| 10 | L1-worker | claudeopus46 | 20,643 | 8,320 | 28,963 | 2,259 | 10.1 |
| 11 | L1-worker | claudeopus46 | 1,356 | 2,157 | 3,513 | 700 | 3.6 |
| 12 | L1-worker | claudeopus46 | 536 | 2,037 | 2,573 | 721 | 6.0 |
| 13 | L1-worker | claudeopus46 | 1,323 | 4,000 | 5,323 | 4,269 | 15.8 |
| 14 | L1-worker | claudeopus46 | 298 | 4,991 | 5,289 | 3,196 | 13.3 |
| 15 | L1-worker | claudeopus46 | 1,160 | 8,947 | 10,107 | 3,184 | 12.9 |
| 16 | L0-main | claudeopus46 | 20,021 | 3,712 | 23,733 | 1,637 | 8.4 |
| 17 | L0-main | claudeopus46 | 20,021 | 4,317 | 24,338 | 1,419 | 7.5 |
| 18 | L0-main | claudeopus46 | 19,988 | 5,657 | 25,645 | 522 | 4.4 |
| 19 | L0-main | claudeopus46 | 20,021 | 4,900 | 24,921 | 1,774 | 8.1 |
| 20 | L0-main | claudeopus46 | 20,021 | 5,546 | 25,567 | 2,493 | 12.6 |
| 21 | L0-main | claudeopus46 | 20,021 | 28,889 | 48,910 | 1,740 | 14.4 |
| 22 | L0-main | claudeopus46 | 20,021 | 29,615 | 49,636 | 1,132 | 8.5 |
| 23 | L0-main | claudeopus46 | 20,021 | 30,490 | 50,511 | 937 | 6.7 |
| 24 | L0-main | claudeopus46 | 20,021 | 35,533 | 55,554 | 1,423 | 10.6 |
| 25 | L0-main | claudeopus46 | 19,988 | 40,453 | 60,441 | 381 | 4.6 |
| 26 | L0-main | claudeopus46 | 20,021 | 39,693 | 59,714 | 8,458 | 52.2 |
| 27 | L0-main | claudeopus46 | 20,021 | 40,790 | 60,811 | 5,829 | 37.1 |
| 28 | L0-main | claudeopus46 | 1,356 | 5,958 | 7,314 | 1,383 | 8.6 |
| 29 | L0-main | claudeopus46 | 298 | 1,765 | 2,063 | 1,371 | 5.0 |
| 30 | L0-main | claudeopus46 | 1,323 | 56,071 | 57,394 | 3,978 | 24.1 |
| 31 | L0-main | claudeopus46 | 298 | 4,820 | 5,118 | 3,432 | 17.8 |
| 32 | L0-main | claudeopus46 | 1,562 | 5,220 | 6,782 | 1,134 | 9.9 |


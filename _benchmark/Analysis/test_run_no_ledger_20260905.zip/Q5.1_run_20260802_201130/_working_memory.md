# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.1_run_20260802_201130`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_4 | methanol |  |
| comp | GLOBcomp_1 | water |  |
| comp | GLOBcomp_2 | ethanol |  |
| prop | GLOBprop_17 | excessmolarenthalpymolarenthalpyofmixingkjmol |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<ethanol> |  |
| constr | GLOBconstr_2 | temperaturek |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml_parallel]
- [run_query_agents_parallel]
- [fit_multi_system]
- [inspect_block]
- [inspect_block]
- [fit_multi_system]
- [predict_from_rk]
- [predict_from_rk]

### Query Results
#### methanol_water_HE — ERROR
no active StatsRecorder; start agent tracking first

#### ethanol_water_HE — ERROR
no active StatsRecorder; start agent tracking first

#### propanol_water_HE — ERROR
no active StatsRecorder; start agent tracking first

### Inspected Blocks
- GLOBlit_5688 | 10.1016/j.tca.2006.02.028 | PROPblock_1: 13 rows; x=['mole_fraction_<methanol>']; y=['excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol']
    - BLKprop_1 / GLOBprop_17: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_17: kind=direct; materialize_reference=False; supported=True; units=kJ/mol -> kJ/mol
- GLOBlit_2574 | 10.1016/j.jct.2005.06.018 | PROPblock_4: 27 rows; x=['mole_fraction_<ethanol>']; y=['excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol']
    - BLKprop_1 / GLOBprop_17: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_17: kind=direct; materialize_reference=False; supported=True; units=kJ/mol -> kJ/mol

### Completed Fits
  - ethanol_water_HE [10.1016/j.jct.2005.06.018/PROPblock_4] (ethanol, water): RK order=4, R²=0.998537, RMSE=0.008367192167912752, coeffs=[-1.601023, 1.734931, -3.19748, 3.113265, -2.361707]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: ethanol=0, water=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png
  - methanol_water_HE [10.1016/j.tca.2006.02.028/PROPblock_1] (methanol, water): RK order=3, R²=0.998432, RMSE=0.008035478840357078, coeffs=[-3.092541, 1.550802, -2.027138, 1.085445]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: methanol=0, water=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- `$ROOT/data\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1
- `$ROOT/data\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1
- `$ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- `$ROOT/plots\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1
- `$ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- `$ROOT/plots\10_1016_j_tca_2006_02_028_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.tca.2006.02.028 PROPblock_1_T298.1


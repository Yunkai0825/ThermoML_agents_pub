# Reference Stats — analysis-agent

**Run started:** 2026-08-02 21:01:43
**Wall time (at last flush):** 20.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 24,560 | 6,102 | 2,798 | 30,662 | 6,132 | 23.0 | claudeopus46 |
| **TOTAL** | **5** | **24,560** | **6,102** | **2,798** | **30,662** | **6,132** | **23.0** | |

**Estimated tokens:** ~7,665 input + ~699 output = ~8,364 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

*(no tool results recorded)*

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 281 | 20,302 | 1,344 | 8.9 |
| 2 | L0-main | claudeopus46 | 1,323 | 1,870 | 3,193 | 52 | 1.9 |
| 3 | L0-main | claudeopus46 | 1,356 | 1,189 | 2,545 | 523 | 3.4 |
| 4 | L0-main | claudeopus46 | 298 | 894 | 1,192 | 31 | 2.0 |
| 5 | L0-main | claudeopus46 | 1,562 | 1,868 | 3,430 | 848 | 6.8 |


# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.5_run_20260802_214548`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_18 | dimethylformamide | 0.000812 |
| comp | GLOBcomp_24 | 1,2-ethanediol | 0.0161 |
| comp | GLOBcomp_1 | water | 0.00089 |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<1,2-ethanediol> |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| constr | GLOBconstr_2 | temperaturek |  |
| lit | GLOBlit_8892 | 10.1021/je060113j |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [query_thermoml]
- [query_thermoml]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [fit_block] ERROR: No pure values given and the block's composition coverage is insufficient to ext
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [propose_fitting_plan]
- [propose_fitting_plan]
- [propose_fitting_plan]
- [query_thermoml]
- [fit_block]
- [fit_block] ERROR: Only 0 mixture points (need >= 3 for RK fit)
- [fit_block]
- [fit_block]

### Query Results
#### ternary_viscosity — ERROR
no active StatsRecorder; start agent tracking first

#### binary_dmf_water — ERROR
no active StatsRecorder; start agent tracking first

#### binary_dmf_eg — ERROR
no active StatsRecorder; start agent tracking first

#### binary_eg_water — ERROR
no active StatsRecorder; start agent tracking first

#### query
Ternary dynamic viscosity data for N,N-dimethylformamide (DMF) + ethylene glycol (1,2-ethanediol) + water were identified from DOI 10.1021/je060113j (GLOBlit_8892, PROPblock_38). The block contains 33 data points across 298.15 K, 308.15 K, and 318.15 K at 101.0 kPa, with 7 points at exactly 298.15 K. Compounds map as DOIcomp_4→GLOBcomp_18 (DMF), DOIcomp_1→GLOBcomp_24 (ethylene glycol), and DOIcomp_6→GLOBcomp_1 (water). The measured property (BLKprop_1→GLOBprop_4) is viscosity in Pa·s by capillary tube method. At 298.15 K, viscosity exhibits a non-monotonic composition dependence: it rises from the DMF–ethylene glycol binary as water is added, peaks near x(water)≈0.48 at about 0.003749 Pa·s, then decreases toward the water-rich corner, attributed to competing hydrogen-bonding enhancement and dilution effects.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_8892 | 10.1021/je060113j | PROPblock_38 | declared | 33 | ternary | ternary |

#### query
Three ThermoML binary-mixture data blocks report dynamic viscosity (Pa·s) for dimethylformamide (DMF, GLOBcomp_18) + water (GLOBcomp_1) near 298.15 K. (1) DOI 10.1021/je050209y (GLOBlit_8676, PROPblock_9): 11 points at exactly 298.15 K, DMF mole fraction 0.05–0.95, providing full isothermal composition coverage. (2) DOI 10.1021/je300608v (GLOBlit_9900, PROPblock_3): 60 points over 293.15–308.15 K, roughly 12 at 298.15 K, water mole fraction 0.0–1.0. (3) DOI 10.1021/je700671t (GLOBlit_11030, PROPblock_3): 98 points over 293.15–323.15 K, about 14 near 298.15 K, the largest and broadest dataset. All report GLOBprop_4 (dynamic viscosity). The DMF + water system is noted for a pronounced viscosity maximum near xDMF ≈ 0.3–0.35 at 298.15 K, attributed to strong hydrogen-bonding interactions between DMF's carbonyl group and water.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_8676 | 10.1021/je050209y | PROPblock_9 | declared | 11 | binary | binary |
| GLOBlit_9900 | 10.1021/je300608v | PROPblock_3 | declared | 60 | binary | binary |
| GLOBlit_11030 | 10.1021/je700671t | PROPblock_3 | declared | 98 | binary | binary |

#### query
A single binary viscosity data block was found for dimethylformamide (DMF) + 1,2-ethanediol (ethylene glycol) from DOI 10.1021/je060113j (GLOBlit_8892), block PROPblock_25. It reports dynamic viscosity (Pa·s) at three temperatures (298.15–318.15 K) at a fixed ethylene glycol mole fraction of 0.5408. At 298.15 K the measured viscosity is 0.0030647 Pa·s (± 2.3 × 10⁻⁵ Pa·s). The data cover only one composition rather than a full mole-fraction sweep, and no other binary DMF + ethylene glycol viscosity blocks were identified in the database.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_8892 | 10.1021/je060113j | PROPblock_25 | declared | 3 | binary | binary |

#### query
Six binary mixture data blocks containing dynamic viscosity (Pa·s) measurements for 1,2-ethanediol (ethylene glycol) + water near 298.15 K were identified in the ThermoML database. The most comprehensive dataset is PROPblock_24 from GLOBlit_5201 (DOI 10.1016/j.jct.2018.02.022) with 84 data points spanning T = 293.15–303.15 K, mole fractions 0.05–0.95, at P = 92.3 kPa. Another strong candidate is PROPblock_18 from GLOBlit_6951 (DOI 10.1021/acs.jced.6b00526) with 33 points covering the full composition range (x(water) 0–1) at T = 293.15–303.15 K. Additional datasets from DOIs 10.1021/je020140j, 10.1021/je9000697, 10.1016/j.jct.2006.01.011, and 10.1021/je025610o provide supplementary coverage with varying temperature and composition ranges. The system exhibits a well-known viscosity maximum near x(EG) ≈ 0.3–0.4 at 298.15 K due to extensive hydrogen bonding between the diol and water.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2656 | 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | binary |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | binary |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | binary |
| GLOBlit_8038 | 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | binary |
| GLOBlit_8106 | 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | binary |
| GLOBlit_11506 | 10.1021/je9000697 | PROPblock_1 | declared | 16 | binary | binary |

#### query
Pure-component dynamic viscosity (GLOBprop_4) at 298.15 K (GLOBvar_1) was compiled from ThermoML for three compounds. Dimethylformamide (GLOBcomp_18) has ten ThermoML sources with values ranging 0.000783–0.000861 Pa·s, clustering around a consensus of approximately 0.000812 Pa·s. Water (GLOBcomp_1) has ten sources tightly clustered near 0.000890 Pa·s (one outlier at 0.000806 Pa·s excluded), consistent with the accepted value. For 1,2-ethanediol / ethylene glycol (GLOBcomp_24), the database search was not completed before the iteration limit; its ThermoML viscosity at 298.15 K was not retrieved and requires a follow-up query. These pure-component endpoints are intended for Redlich–Kister fitting of mixture viscosity data.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_779 | 10.1016/j.fluid.2010.01.002 | PROPblock_4 | declared | 4 | unary | unary |
| GLOBlit_3670 | 10.1016/j.jct.2012.06.023 | PROPblock_3 | declared | 1 | unary | unary |
| GLOBlit_3721 | 10.1016/j.jct.2012.09.003 | PROPblock_8 | declared | 1 | unary | unary |
| GLOBlit_3813 | 10.1016/j.jct.2013.01.013 | PROPblock_6 | declared | 7 | unary | unary |
| GLOBlit_3832 | 10.1016/j.jct.2013.02.010 | PROPblock_2 | declared | 5 | unary | unary |
| GLOBlit_4124 | 10.1016/j.jct.2014.02.019 | PROPblock_4 | declared | 4 | unary | unary |
| GLOBlit_4138 | 10.1016/j.jct.2014.03.022 | PROPblock_2 | declared | 4 | unary | unary |
| GLOBlit_5960 | 10.1016/j.tca.2011.10.009 | PROPblock_2 | declared | 1 | unary | unary |
| GLOBlit_6204 | 10.1016/j.tca.2014.11.010 | PROPblock_3 | declared | 1 | unary | unary |
| GLOBlit_6924 | 10.1021/acs.jced.6b00430 | PROPblock_1 | declared | 5 | unary | unary |
| GLOBlit_779 | 10.1016/j.fluid.2010.01.002 | PROPblock_16 | declared | 4 | unary | unary |
| GLOBlit_1691 | 10.1016/j.fluid.2015.04.021 | PROPblock_4 | declared | 6 | unary | unary |
| GLOBlit_1733 | 10.1016/j.fluid.2015.06.043 | PROPblock_4 | declared | 8 | unary | unary |
| GLOBlit_1747 | 10.1016/j.fluid.2015.07.022 | PROPblock_2 | declared | 1 | unary | unary |
| GLOBlit_2030 | 10.1016/j.fluid.2017.02.019 | PROPblock_3 | declared | 4 | unary | unary |
| GLOBlit_2934 | 10.1016/j.jct.2008.03.013 | PROPblock_2 | declared | 3 | unary | unary |
| GLOBlit_2944 | 10.1016/j.jct.2008.04.006 | PROPblock_5 | declared | 3 | unary | unary |
| GLOBlit_3540 | 10.1016/j.jct.2012.01.013 | PROPblock_10 | declared | 5 | unary | unary |
| GLOBlit_3572 | 10.1016/j.jct.2012.02.027 | PROPblock_8 | declared | 1 | unary | unary |
| GLOBlit_3770 | 10.1016/j.jct.2012.11.016 | PROPblock_8 | declared | 3 | unary | unary |

**Status:** partial

### Inspected Blocks
- GLOBlit_8892 | 10.1021/je060113j | PROPblock_38: 33 rows; x=['mole_fraction_<water>', 'mole_fraction_<1,2-ethanediol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_8676 | 10.1021/je050209y | PROPblock_9: 11 rows; x=['mole_fraction_<dimethylformamide>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_11030 | 10.1021/je700671t | PROPblock_3: 98 rows; x=['mole_fraction_<dimethylformamide>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18: 33 rows; x=['mole_fraction_<water>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24: 84 rows; x=['mole_fraction_<1,2-ethanediol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - 10.1021/je050209y/PROPblock_9 (dimethylformamide, water): RK order=5, R²=0.999947, RMSE=0.0025245676109005117, coeffs=[3.183088, -3.96539, 1.868659, 0.436905, -0.332993, -0.860686]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: dimethylformamide=0.000812, water=0.00089 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1021_je050209y_BPROPblock_9_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je050209y_BPROPblock_9_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je050209y_BPROPblock_9_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je050209y_BPROPblock_9_T298.1_excess.png
  - 10.1021/acs.jced.6b00526/PROPblock_18 (water, 1,2-ethanediol): RK order=5, R²=0.999865, RMSE=0.00160141872753837, coeffs=[2.303026, 1.173176, 0.557092, 0.023568, 0.609755, -0.432131]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: water=0.00089, 1,2-ethanediol=0.0161 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.png
  - 10.1016/j.jct.2018.02.022/PROPblock_24 (1,2-ethanediol, water): RK order=4, R²=0.999932, RMSE=0.001397996378318097, coeffs=[2.430082, -1.04504, 0.635087, -0.320445, 0.203961]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: 1,2-ethanediol=0.0161, water=0.00089 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1021_je050209y_BPROPblock_9_T298.1_fit.csv` — RK fit data — 10.1021/je050209y PROPblock_9_T298.1
- `$ROOT/data\10_1021_je050209y_BPROPblock_9_T298.1_excess.csv` — Excess property — 10.1021/je050209y PROPblock_9_T298.1
- `$ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.csv` — RK fit data — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- `$ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.csv` — Excess property — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1

### plot
- `$ROOT/plots\10_1021_je050209y_BPROPblock_9_T298.1_fit.png` — RK fit plot — 10.1021/je050209y PROPblock_9_T298.1
- `$ROOT/plots\10_1021_je050209y_BPROPblock_9_T298.1_excess.png` — Excess plot — 10.1021/je050209y PROPblock_9_T298.1
- `$ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.png` — RK fit plot — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- `$ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.png` — Excess plot — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1


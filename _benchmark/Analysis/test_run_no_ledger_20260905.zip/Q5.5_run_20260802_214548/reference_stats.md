# Reference Stats — analysis-agent

**Run started:** 2026-08-02 21:45:48
**Wall time (at last flush):** 1,074.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 19 | 285,065 | 376,238 | 73,656 | 661,303 | 34,805 | 429.2 | claudeopus46 |
| L1-worker | 63 | 579,165 | 442,672 | 104,577 | 1,021,837 | 16,219 | 641.4 | claudeopus46 |
| **TOTAL** | **82** | **864,230** | **818,910** | **178,233** | **1,683,140** | **20,526** | **1070.6** | |

**Estimated tokens:** ~420,785 input + ~44,558 output = ~465,343 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 3 | 1 | 2 | 1 | 1 | 1 | 33 |
| `query_thermoml` | 2 | 1 | 2 | 2 | 3 | 3 | 169 |
| `query_thermoml` | 2 | 1 | 1 | 2 | 1 | 1 | 3 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **7** | **3** | **5** | **5** | **5** | **5** | **205** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8892 |  | query_thermoml |
| GLOBlit_8676 |  | query_thermoml |
| GLOBlit_9900 |  | query_thermoml |
| GLOBlit_11030 |  | query_thermoml |

#### Block_Types (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_3 |  | query_thermoml |
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_18 | dimethylformamide | query_thermoml |
| GLOBcomp_24 | 1,2-ethanediol | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Constraints (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | query_thermoml |
| GLOBconstr_2 | Temperature, K | query_thermoml |
| GLOBconstr_3 | Mole fraction | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | query_thermoml |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | query_thermoml |
| GLOBmeas_140 | Viscosity, Pa*s | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 4 |
| Unique Block_Types | 2 |
| Unique Compounds | 3 |
| Unique Constraints | 3 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Total DOIs | 4 |
| Unique parent blocks | 5 |
| Explicit block/subsystem targets | 5 |
| Subsystem targets | 0 |
| Target-matched data points | 205 |

---

## 3. DOI & Block References

**Unique DOIs:** 4  |  **Parent blocks:** 5  |  **Explicit targets:** 5  |  **Subsystems:** 0  |  **Target-matched datapoints:** 205

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je050209y | 1 | 11 | binary | query_thermoml |
| 10.1021/je060113j | 2 | 36 | binary, ternary | query_thermoml |
| 10.1021/je300608v | 1 | 60 | binary | query_thermoml |
| 10.1021/je700671t | 1 | 98 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je050209y | PROPblock_9 | declared | 11 | binary | 2 | query_thermoml |
| 10.1021/je060113j | PROPblock_25 | declared | 3 | binary | 2 | query_thermoml |
| 10.1021/je060113j | PROPblock_38 | declared | 33 | ternary | 3 | query_thermoml |
| 10.1021/je300608v | PROPblock_3 | declared | 60 | binary | 2 | query_thermoml |
| 10.1021/je700671t | PROPblock_3 | declared | 98 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'ternary', 'purpos… | 184 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'ternary_viscosity… | 132 | — | — | 0.0 |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'ternary_viscosity… | 541 | — | — | 0.3 |
| 4 | 4 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 11,948 | — | — | 120.2 |
| 5 | 7 | `inspect_block` | block_number=PROPblock_38, doi=10.1021/je060113j, … | 1,464 | — | — | 0.4 |
| 6 | 7 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBcomp_18',…, instruc… | 20,799 | — | — | 69.5 |
| 7 | 7 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBcomp_18',…, instruc… | 7,972 | — | — | 49.4 |
| 8 | 7 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBcomp_24',…, instruc… | 282 | — | — | 111.7 |
| 9 | 8 | `inspect_block` | block_number=PROPblock_9, doi=10.1021/je050209y, p… | 1,379 | — | — | 0.1 |
| 10 | 8 | `inspect_block` | block_number=PROPblock_3, doi=10.1021/je700671t, p… | 1,385 | — | — | 0.1 |
| 11 | 8 | `inspect_block` | block_number=PROPblock_18, doi=10.1021/acs.jced.6b… | 1,361 | — | — | 0.1 |
| 12 | 8 | `inspect_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 1,379 | — | — | 0.1 |
| 13 | 9 | `fit_block` | block_number=PROPblock_9, doi=10.1021/je050209y, m… | 260 | — | — | 0.1 |
| 14 | 9 | `fit_block` | block_number=PROPblock_18, doi=10.1021/acs.jced.6b… | 141 | — | — | 0.0 |
| 15 | 9 | `fit_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 142 | — | — | 0.1 |
| 16 | 9 | `fit_block` | block_number=PROPblock_3, doi=10.1021/je700671t, m… | 134 | — | — | 0.0 |
| 17 | 10 | `propose_fitting_plan` | block_number=PROPblock_3, composition_hint=mole_fr… | 593 | — | — | 0.1 |
| 18 | 10 | `propose_fitting_plan` | block_number=PROPblock_18, composition_hint=mole_f… | 581 | — | — | 0.1 |
| 19 | 10 | `propose_fitting_plan` | block_number=PROPblock_24, composition_hint=mole_f… | 590 | — | — | 0.1 |
| 20 | 10 | `query_thermoml` | context=Need pure viscosity values at…, id_catalog… | 282 | — | — | 300.7 |
| 21 | 11 | `fit_block` | block_number=PROPblock_9, doi=10.1021/je050209y, m… | 886 | — | — | 1.3 |
| 22 | 11 | `fit_block` | block_number=PROPblock_3, doi=10.1021/je700671t, m… | 125 | — | — | 0.1 |
| 23 | 11 | `fit_block` | block_number=PROPblock_18, doi=10.1021/acs.jced.6b… | 884 | — | — | 0.8 |
| 24 | 11 | `fit_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 876 | — | — | 0.9 |
| | | **TOTAL (24 tools)** | | **54,320** | | **0** | **656.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,562 | 2,562 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 22,524 | 22,524 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 485 | 20,506 | 2,606 | 13.0 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,159 | 21,180 | 15,072 | 66.0 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,789 | 21,810 | 2,045 | 9.7 |
| 4 | L0-main | claudeopus46 | 19,988 | 3,971 | 23,959 | 577 | 4.5 |
| 5 | L0-main | claudeopus46 | 20,021 | 3,214 | 23,235 | 798 | 6.8 |
| 6 | L1-worker | claudeopus46 | 20,643 | 440 | 21,083 | 956 | 6.5 |
| 7 | L1-worker | claudeopus46 | 20,643 | 2,124 | 22,767 | 5,523 | 26.3 |
| 8 | L1-worker | claudeopus46 | 2,065 | 544 | 2,609 | 469 | 4.1 |
| 9 | L1-worker | claudeopus46 | 2,065 | 377 | 2,442 | 543 | 4.1 |
| 10 | L1-worker | claudeopus46 | 20,643 | 2,771 | 23,414 | 4,729 | 21.6 |
| 11 | L1-worker | claudeopus46 | 2,065 | 3,449 | 5,514 | 1,520 | 12.4 |
| 12 | L1-worker | claudeopus46 | 20,610 | 5,239 | 25,849 | 438 | 6.3 |
| 13 | L1-worker | claudeopus46 | 20,643 | 4,467 | 25,110 | 1,705 | 11.9 |
| 14 | L1-worker | claudeopus46 | 1,356 | 1,836 | 3,192 | 875 | 5.5 |
| 15 | L1-worker | claudeopus46 | 536 | 1,716 | 2,252 | 833 | 5.8 |
| 16 | L1-worker | claudeopus46 | 1,323 | 6,194 | 7,517 | 1,054 | 5.9 |
| 17 | L1-worker | claudeopus46 | 298 | 1,776 | 2,074 | 785 | 6.1 |
| 18 | L1-worker | claudeopus46 | 747 | 16,907 | 17,654 | 525 | 6.1 |
| 19 | L0-main | claudeopus46 | 20,021 | 17,011 | 37,032 | 3,401 | 17.9 |
| 20 | L0-main | claudeopus46 | 20,021 | 18,176 | 38,197 | 2,796 | 12.3 |
| 21 | L0-main | claudeopus46 | 20,021 | 19,327 | 39,348 | 2,681 | 11.3 |
| 22 | L1-worker | claudeopus46 | 20,643 | 668 | 21,311 | 869 | 6.0 |
| 23 | L1-worker | claudeopus46 | 2,065 | 8,669 | 10,734 | 1,732 | 14.9 |
| 24 | L1-worker | claudeopus46 | 20,643 | 1,974 | 22,617 | 1,530 | 9.5 |
| 25 | L1-worker | claudeopus46 | 536 | 1,368 | 1,904 | 848 | 5.5 |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,488 | 2,844 | 1,029 | 5.8 |
| 27 | L1-worker | claudeopus46 | 1,323 | 3,936 | 5,259 | 1,365 | 6.4 |
| 28 | L1-worker | claudeopus46 | 298 | 2,087 | 2,385 | 1,040 | 4.9 |
| 29 | L1-worker | claudeopus46 | 747 | 23,402 | 24,149 | 1,808 | 13.5 |
| 30 | L1-worker | claudeopus46 | 298 | 2,167 | 2,465 | 581 | 6.3 |
| 31 | L1-worker | claudeopus46 | 20,643 | 707 | 21,350 | 780 | 5.7 |
| 32 | L1-worker | claudeopus46 | 2,065 | 2,138 | 4,203 | 1,797 | 14.0 |
| 33 | L1-worker | claudeopus46 | 20,643 | 2,188 | 22,831 | 860 | 8.2 |
| 34 | L1-worker | claudeopus46 | 1,323 | 3,638 | 4,961 | 543 | 3.9 |
| 35 | L1-worker | claudeopus46 | 1,356 | 989 | 2,345 | 567 | 4.3 |
| 36 | L1-worker | claudeopus46 | 536 | 869 | 1,405 | 556 | 6.2 |
| 37 | L1-worker | claudeopus46 | 298 | 1,265 | 1,563 | 416 | 3.0 |
| 38 | L1-worker | claudeopus46 | 747 | 10,228 | 10,975 | 644 | 7.0 |
| 39 | L1-worker | claudeopus46 | 20,643 | 671 | 21,314 | 806 | 5.9 |
| 40 | L1-worker | claudeopus46 | 20,643 | 2,098 | 22,741 | 9,567 | 46.0 |
| 41 | L1-worker | claudeopus46 | 2,065 | 9,108 | 11,173 | 1,588 | 13.7 |
| 42 | L1-worker | claudeopus46 | 20,643 | 3,330 | 23,973 | 1,892 | 11.5 |
| 43 | L1-worker | claudeopus46 | 536 | 1,718 | 2,254 | 907 | 5.6 |
| 44 | L1-worker | claudeopus46 | 1,356 | 1,838 | 3,194 | 859 | 6.5 |
| 45 | L1-worker | claudeopus46 | 1,323 | 5,009 | 6,332 | 2,605 | 11.3 |
| 46 | L1-worker | claudeopus46 | 298 | 3,327 | 3,625 | 1,983 | 8.4 |
| 47 | L1-worker | claudeopus46 | 747 | 42,024 | 42,771 | 721 | 6.7 |
| 48 | L0-main | claudeopus46 | 20,021 | 24,796 | 44,817 | 5,873 | 38.3 |
| 49 | L0-main | claudeopus46 | 20,021 | 28,613 | 48,634 | 4,038 | 24.8 |
| 50 | L0-main | claudeopus46 | 19,988 | 31,466 | 51,454 | 446 | 4.8 |
| 51 | L0-main | claudeopus46 | 20,021 | 30,707 | 50,728 | 4,326 | 23.5 |
| 52 | L1-worker | claudeopus46 | 20,643 | 1,123 | 21,766 | 2,014 | 13.8 |
| 53 | L1-worker | claudeopus46 | 20,643 | 3,758 | 24,401 | 8,986 | 41.3 |
| 54 | L1-worker | claudeopus46 | 2,065 | 398 | 2,463 | 495 | 4.6 |
| 55 | L1-worker | claudeopus46 | 20,643 | 3,959 | 24,602 | 5,588 | 29.2 |
| 56 | L1-worker | claudeopus46 | 20,643 | 4,919 | 25,562 | 793 | 7.0 |
| 57 | L1-worker | claudeopus46 | 20,643 | 5,777 | 26,420 | 1,047 | 7.3 |
| 58 | L1-worker | claudeopus46 | 20,643 | 6,563 | 27,206 | 1,026 | 8.2 |
| 59 | L1-worker | claudeopus46 | 20,643 | 7,344 | 27,987 | 1,083 | 8.1 |
| 60 | L1-worker | claudeopus46 | 2,065 | 958 | 3,023 | 1,377 | 8.9 |
| 61 | L1-worker | claudeopus46 | 20,643 | 6,949 | 27,592 | 1,601 | 10.8 |
| 62 | L1-worker | claudeopus46 | 20,643 | 7,781 | 28,424 | 988 | 7.6 |
| 63 | L1-worker | claudeopus46 | 20,643 | 8,579 | 29,222 | 1,148 | 9.1 |
| 64 | L1-worker | claudeopus46 | 2,065 | 7,114 | 9,179 | 1,327 | 11.4 |
| 65 | L1-worker | claudeopus46 | 20,643 | 9,314 | 29,957 | 817 | 7.4 |
| 66 | L1-worker | claudeopus46 | 20,643 | 10,131 | 30,774 | 710 | 6.5 |
| 67 | L1-worker | claudeopus46 | 2,065 | 7,130 | 9,195 | 1,438 | 13.0 |
| 68 | L1-worker | claudeopus46 | 20,610 | 12,044 | 32,654 | 440 | 4.3 |
| 69 | L1-worker | claudeopus46 | 20,610 | 11,416 | 32,026 | 2,614 | 16.9 |
| 70 | L1-worker | claudeopus46 | 536 | 2,625 | 3,161 | 744 | 5.9 |
| 71 | L1-worker | claudeopus46 | 1,356 | 2,745 | 4,101 | 983 | 6.7 |
| 72 | L1-worker | claudeopus46 | 298 | 1,365 | 1,663 | 943 | 4.3 |
| 73 | L1-worker | claudeopus46 | 1,323 | 19,664 | 20,987 | 5,568 | 20.7 |
| 74 | L1-worker | claudeopus46 | 298 | 6,290 | 6,588 | 4,380 | 17.4 |
| 75 | L1-worker | claudeopus46 | 747 | 109,982 | 110,729 | 619 | 7.7 |
| 76 | L0-main | claudeopus46 | 20,021 | 36,820 | 56,841 | 3,793 | 23.7 |
| 77 | L0-main | claudeopus46 | 20,021 | 44,411 | 64,432 | 12,919 | 96.4 |
| 78 | L0-main | claudeopus46 | 1,356 | 5,860 | 7,216 | 1,398 | 10.0 |
| 79 | L0-main | claudeopus46 | 298 | 1,780 | 2,078 | 1,386 | 5.0 |
| 80 | L0-main | claudeopus46 | 1,323 | 93,962 | 95,285 | 4,534 | 28.7 |
| 81 | L0-main | claudeopus46 | 298 | 5,376 | 5,674 | 3,825 | 22.9 |
| 82 | L0-main | claudeopus46 | 1,562 | 7,315 | 8,877 | 1,142 | 9.6 |


# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_24 | 1,2-ethanediol | 0.016223 |
| comp | GLOBcomp_1 | water |  |
| comp | GLOBcomp_4 | methanol | 0.000545 |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_5 | massfraction<1,2-ethanediol> |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml_parallel]
- [run_query_agents_parallel]
- [fit_multi_system]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [fit_multi_system]
- [fit_block]

### Query Results
#### EG_water_visc — ERROR
no active StatsRecorder; start agent tracking first

#### EG_methanol_visc — ERROR
no active StatsRecorder; start agent tracking first

#### water_methanol_visc — ERROR
no active StatsRecorder; start agent tracking first

### Inspected Blocks
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24: 84 rows; x=['mole_fraction_<1,2-ethanediol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_692 | 10.1016/j.fluid.2009.03.002 | PROPblock_1: 12 rows; x=['mass_fraction_<1,2-ethanediol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9: 39 rows; x=['mole_fraction_<water>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - EG_water [10.1016/j.jct.2018.02.022/PROPblock_24] (1,2-ethanediol, water): RK order=3, R²=0.99994, RMSE=0.0013198945265291695, coeffs=[2.39674, -1.044444, 0.668173, -0.3209]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: 1,2-ethanediol=0.016223, water=0.00089689 [block-edges (water: direct/good, 1,2-ethanediol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png
  - water_methanol [10.1016/j.jct.2007.05.004/PROPblock_9] (water, methanol): RK order=3, R²=0.999903, RMSE=0.0020496812938951637, coeffs=[2.534774, 1.422136, 1.33593, 0.754488]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: water=0.00089, methanol=0.000545 [block-edges (methanol: direct/good, water: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_excess.png
  - 10.1016/j.fluid.2009.03.002/PROPblock_1 (1,2-ethanediol, methanol): RK order=0, R²=-4.741128, RMSE=0.034745359089868304, coeffs=[0.707437]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      ⚠ Composition axis converted to mole fraction of 1,2-ethanediol: mass_fraction → mole_fraction via x1=(w1/M1)/(w1/M1+w2/M2), M1=62.068, M2=32.042 g/mol [exact (molar masses from block formulas)]. Source column: mass_fraction_<1,2-ethanediol>.
      pure refs: 1,2-ethanediol=0.016223, methanol=0.000545 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/data\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1
- `$ROOT/data\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/plots\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1
- `$ROOT/plots\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1


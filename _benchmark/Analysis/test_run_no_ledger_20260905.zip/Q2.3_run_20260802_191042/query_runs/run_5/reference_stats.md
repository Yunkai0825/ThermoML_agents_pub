# Reference Stats — query-agent

**Run started:** 2026-08-02 19:17:28
**Wall time (at last flush):** 514.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 41,397 | 73,810 | 14,609 | 115,207 | 16,458 | 85.7 | claudeopus46 |
| L1-worker | 37 | 316,459 | 192,649 | 92,617 | 509,108 | 13,759 | 463.8 | claudeopus46 |
| **TOTAL** | **44** | **357,856** | **266,459** | **107,226** | **624,315** | **14,188** | **549.5** | |

**Estimated tokens:** ~156,078 input + ~26,806 output = ~182,884 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 4 | 1 | 4 | 4 | 76 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 4 | 1 | 4 | 4 | 76 |
| **TOTAL** | **10** | **3** | **8** | **2** | **8** | **8** | **152** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_4 |  | resolve_compound_ids, search_blocks |

#### References (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2825 |  | search_blocks |
| GLOBlit_5533 |  | search_blocks |
| GLOBlit_8869 |  | search_blocks |
| GLOBlit_9571 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | resolve_property_ids, search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_271 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_18 | Volume fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 4 |
| Unique Properties | 1 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Unique Variables | 4 |
| Unique Constraints | 1 |
| Total DOIs | 4 |
| Unique parent blocks | 4 |
| Explicit block/subsystem targets | 4 |
| Subsystem targets | 0 |
| Target-matched data points | 152 |

---

## 3. DOI & Block References

**Unique DOIs:** 4  |  **Parent blocks:** 4  |  **Explicit targets:** 4  |  **Subsystems:** 0  |  **Target-matched datapoints:** 76

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | search_blocks |
| 10.1016/j.jct.2019.05.013 | 1 | 12 | binary | search_blocks |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2007.05.004 | PROPblock_9 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2019.05.013 | PROPblock_3 | declared | 12 | binary | — | search_blocks |
| 10.1021/je0600810 | PROPblock_3 | declared | 9 | binary | — | search_blocks |
| 10.1021/je2003622 | PROPblock_1 | declared | 16 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve water and m… | 222 | KEEP | 222 | 3.4 |
| 2 | 1 | `L1_query` | context=User is looking for binary vi…, id_catalog… | 381 | — | — | 125.4 |
| 3 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve global comp… | 222 | KEEP | 222 | 3.7 |
| 4 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 847 | KEEP | 832 | 16.0 |
| 5 | 2 | `L1_query` | context=User wants binary viscosity d…, id_catalog… | 524 | — | — | 149.2 |
| 6 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve global comp… | 365 | KEEP | 365 | 4.2 |
| 7 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Verify the global p… | 256 | KEEP | 256 | 3.9 |
| 8 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 886 | KEEP | 886 | 14.3 |
| 9 | 3 | `L1_query` | context=This is a fresh search. No pr…, id_catalog… | 15,929 | — | — | 160.2 |
| | | **TOTAL (9 tools)** | | **19,632** | | **2,783** | **480.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,294 | 4,294 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,082 | 10,687 | 1,347 | 7.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,212 | 21,855 | 639 | 4.9 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,472 | 23,115 | 6,818 | 35.7 |
| 4 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 365 | 3.3 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,612 | 23,255 | 6,485 | 33.3 |
| 6 | L1-worker | claudeopus46 | 20,643 | 9,718 | 30,361 | 3,246 | 14.4 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,923 | 4,279 | 705 | 4.7 |
| 8 | L1-worker | claudeopus46 | 536 | 2,803 | 3,339 | 1,159 | 8.1 |
| 9 | L1-worker | claudeopus46 | 1,323 | 5,132 | 6,455 | 3,102 | 13.2 |
| 10 | L1-worker | claudeopus46 | 298 | 3,824 | 4,122 | 2,480 | 9.7 |
| 11 | L1-worker | claudeopus46 | 1,160 | 8,798 | 9,958 | 2,468 | 10.2 |
| 12 | L0-main | claudeopus46 | 9,605 | 1,955 | 11,560 | 1,313 | 8.0 |
| 13 | L1-worker | claudeopus46 | 20,643 | 1,182 | 21,825 | 634 | 5.0 |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,437 | 23,080 | 12,553 | 50.3 |
| 15 | L1-worker | claudeopus46 | 2,065 | 473 | 2,538 | 401 | 3.7 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,589 | 23,232 | 5,387 | 29.6 |
| 17 | L1-worker | claudeopus46 | 20,643 | 3,301 | 23,944 | 712 | 5.1 |
| 18 | L1-worker | claudeopus46 | 2,065 | 8,647 | 10,712 | 1,794 | 15.3 |
| 19 | L1-worker | claudeopus46 | 20,643 | 4,301 | 24,944 | 1,403 | 9.7 |
| 20 | L1-worker | claudeopus46 | 1,356 | 1,534 | 2,890 | 730 | 4.8 |
| 21 | L1-worker | claudeopus46 | 536 | 1,414 | 1,950 | 783 | 5.1 |
| 22 | L1-worker | claudeopus46 | 1,323 | 5,810 | 7,133 | 1,668 | 7.5 |
| 23 | L1-worker | claudeopus46 | 298 | 2,390 | 2,688 | 1,288 | 5.3 |
| 24 | L1-worker | claudeopus46 | 747 | 25,378 | 26,125 | 461 | 5.5 |
| 25 | L1-worker | claudeopus46 | 1,160 | 8,143 | 9,303 | 1,288 | 5.3 |
| 26 | L1-worker | claudeopus46 | 747 | 25,378 | 26,125 | 430 | 5.2 |
| 27 | L0-main | claudeopus46 | 9,605 | 2,988 | 12,593 | 1,175 | 7.5 |
| 28 | L1-worker | claudeopus46 | 20,643 | 1,111 | 21,754 | 980 | 6.0 |
| 29 | L1-worker | claudeopus46 | 20,643 | 2,819 | 23,462 | 14,280 | 51.2 |
| 30 | L1-worker | claudeopus46 | 2,065 | 449 | 2,514 | 576 | 4.0 |
| 31 | L1-worker | claudeopus46 | 2,065 | 375 | 2,440 | 452 | 3.8 |
| 32 | L1-worker | claudeopus46 | 20,643 | 3,443 | 24,086 | 10,481 | 45.4 |
| 33 | L1-worker | claudeopus46 | 2,065 | 8,653 | 10,718 | 1,830 | 13.8 |
| 34 | L1-worker | claudeopus46 | 20,610 | 5,589 | 26,199 | 411 | 4.0 |
| 35 | L1-worker | claudeopus46 | 20,643 | 4,836 | 25,479 | 1,605 | 9.4 |
| 36 | L1-worker | claudeopus46 | 1,356 | 1,736 | 3,092 | 733 | 4.7 |
| 37 | L1-worker | claudeopus46 | 536 | 1,616 | 2,152 | 827 | 6.2 |
| 38 | L1-worker | claudeopus46 | 1,323 | 6,026 | 7,349 | 1,611 | 8.6 |
| 39 | L1-worker | claudeopus46 | 298 | 2,333 | 2,631 | 1,252 | 5.1 |
| 40 | L1-worker | claudeopus46 | 747 | 20,754 | 21,501 | 580 | 6.7 |
| 41 | L0-main | claudeopus46 | 9,605 | 35,759 | 45,364 | 3,009 | 21.2 |
| 42 | L0-main | claudeopus46 | 1,356 | 2,892 | 4,248 | 1,144 | 6.1 |
| 43 | L0-main | claudeopus46 | 1,323 | 24,806 | 26,129 | 3,660 | 23.1 |
| 44 | L0-main | claudeopus46 | 298 | 4,328 | 4,626 | 2,961 | 12.5 |


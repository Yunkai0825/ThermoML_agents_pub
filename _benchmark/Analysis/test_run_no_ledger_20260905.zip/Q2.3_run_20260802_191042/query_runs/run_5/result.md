# Delegated query run — result

**Question:** Find binary mixture data blocks containing dynamic viscosity measurements for water + methanol near 298 K (25 °C). Return DOIs, block numbers, compound IDs, property IDs, temperature ranges, and data point counts.

**Iterations:** 4  |  **Elapsed:** 479.1s  |  **Tools:** 3  |  **Timed out:** False

---

## Answer

Two data blocks in the ThermoML database contain dynamic viscosity measurements for the water + methanol binary mixture near 298 K (25 °C):

---

### Block 1 — PROPblock_9 from GLOBlit_2825
- **DOI:** 10.1016/j.jct.2007.05.004 (GLOBlit_2825)
- **Compounds:** water (GLOBcomp_1, H₂O) + methanol (GLOBcomp_4, CH₄O)
- **Property:** Dynamic viscosity (GLOBprop_4), Pa·s
- **Temperature range:** 293.15–303.15 K (3 unique temperatures: 293.15, 298.15, 303.15 K — **includes 298.15 K directly**)
- **Composition variable:** Mole fraction of water, spanning 0.0–1.0 (13 unique compositions)
- **Data points:** 39
- **Pressure:** 101.0 kPa (atmospheric)
- **Measurement method:** Capillary tube / U-factor (GLOBmeas_140)
- **Viscosity range:** 0.000508–0.001793 Pa·s (mean ≈ 0.00108 Pa·s)
- **Uncertainty:** Propagation of evaluated standard uncertainties, 95% confidence level

> ✅ **This is the most relevant dataset** — it covers the full mole-fraction range at exactly 298.15 K and is the richest block with 39 data points.

---

### Block 2 — PROPblock_3 from GLOBlit_5533
- **DOI:** 10.1016/j.jct.2019.05.013 (GLOBlit_5533)
- **Compounds:** water (GLOBcomp_1, H₂O) + methanol (GLOBcomp_4, CH₄O)
- **Property:** Dynamic viscosity (GLOBprop_4), Pa·s
- **Temperature range:** 273.15–293.15 K (3 unique temperatures — **upper limit is 293.15 K, does not quite reach 298 K**)
- **Composition variable:** Mass fraction of methanol, spanning 0.0–0.4999 (6 unique compositions)
- **Data points:** 12
- **Pressure:** 100.0 kPa
- **Measurement method:** Falling or rolling sphere viscometry (GLOBmeas_8)
- **Viscosity range:** 0.000998–0.003636 Pa·s (mean ≈ 0.00228 Pa·s)
- **Uncertainty:** Propagation of evaluated standard uncertainties, 95% confidence level

> ⚠️ This block only reaches 293.15 K (5 K below target) and covers a partial composition range (up to ~50 wt% methanol).

---

### Chemistry Context

The water–methanol binary system is well known for exhibiting a **viscosity maximum** at intermediate compositions (around *x*_methanol ≈ 0.3). This nonideal behavior arises from enhanced hydrogen-bonding network formation between water and methanol molecules, which creates larger associated clusters that resist flow more than either pure component alone. At 298.15 K, pure water has η ≈ 0.00089 Pa·s and pure methanol η ≈ 0.00054 Pa·s, yet the mixture viscosity peaks near 0.0018 Pa·s — roughly double the pure-water value.

For your intended comparison of nonideality contributions in the ternary ethylene glycol + water + methanol system, **PROPblock_9 from GLOBlit_2825** is the recommended binary reference dataset, as it provides complete composition coverage at exactly 298.15 K with 39 data points measured by capillary viscometry.

### Core claims

- Two ThermoML data blocks contain dynamic viscosity measurements for the water + methanol binary mixture near 298 K: PROPblock_9 (GLOBlit_2825, DOI 10.1016/j.jct.2007.05.004) covers the full mole-fraction range at exactly 298.15 K with 39 data points at 101.0 kPa using capillary viscometry, while PROPblock_3 (GLOBlit_5533, DOI 10.1016/j.jct.2019.05.013) only reaches 293.15 K and covers a partial composition range (up to ~50 wt% methanol) with 12 data points.
- PROPblock_9 from GLOBlit_2825 is the most relevant and recommended binary reference dataset for water + methanol dynamic viscosity at 298.15 K due to its complete composition coverage and higher data density.
- The water–methanol system exhibits a well-known viscosity maximum at intermediate compositions (around x_methanol ≈ 0.3 at 298.15 K), where the mixture viscosity peaks near 0.0018 Pa·s — roughly double the pure-water value (~0.00089 Pa·s) — due to enhanced hydrogen-bonding network formation between water and methanol molecules.
- The viscosity range across the full composition space at these conditions spans approximately 0.000508–0.001793 Pa·s.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for water (GLOBcomp_1) + methanol (GLOBcomp_4) binary mixture. Temperature range 293.15–303.15 K (includes 298.15 K directly). 39 data points across 13 mole-fraction compositions (BLKvar_2, 0.0–1.0). Pressure constraint 101.0 kPa. Measurement method: capillary tube / U-factor (GLOBmeas_140). Viscosity range 0.000508–0.001793 Pa·s. Most relevant dataset for 298 K analysis with full composition coverage. |
| GLOBlit_5533 | 10.1016/j.jct.2019.05.013 | PROPblock_3 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for water (GLOBcomp_1) + methanol (GLOBcomp_4) binary mixture. Temperature range 273.15–293.15 K (upper limit 293.15 K, does not reach 298 K). 12 data points across 6 mass-fraction compositions (BLKvar_1, 0.0–0.4999). Pressure constraint 100.0 kPa. Measurement method: falling or rolling sphere viscometry (GLOBmeas_8). Viscosity range 0.000998–0.003636 Pa·s. |

### Suggested follow-ups

- Retrieve full data-point arrays from PROPblock_9 / GLOBlit_2825 at 298.15 K to extract viscosity vs. mole-fraction curve for the water + methanol binary.
- Search for ethylene glycol + water and ethylene glycol + methanol binary viscosity blocks near 298 K to complete the set of binary sub-systems needed for the ternary nonideality analysis.
- Search for ternary ethylene glycol + water + methanol viscosity data blocks near 298 K to compare directly with binary predictions.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_2825",
    "registry_id": "2007-gon-cal-1",
    "name": "10.1016/j.jct.2007.05.004"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_5533",
    "registry_id": "2019-sem-sto-0",
    "name": "10.1016/j.jct.2019.05.013"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_140",
    "registry_id": "captub_ufactor_2",
    "name": "Capillary tube / U-factor"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_8",
    "registry_id": "falling_or_rolling_sphere_viscometry",
    "name": "Falling or rolling sphere viscometry"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_1",
    "name": "Mole fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_5",
    "registry_id": "mass_fraction_DOIcomp_2",
    "name": "Mass fraction"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

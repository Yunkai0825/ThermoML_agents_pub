# Reference Stats — query-agent

**Run started:** 2026-08-02 19:17:28
**Wall time (at last flush):** 150.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 40,932 | 8,094 | 63,119 | 12,623 | 49.0 | claudeopus46 |
| L1-worker | 12 | 111,605 | 43,234 | 18,039 | 154,839 | 12,903 | 108.0 | claudeopus46 |
| **TOTAL** | **17** | **133,792** | **84,166** | **26,133** | **217,958** | **12,821** | **157.0** | |

**Estimated tokens:** ~54,489 input + ~6,533 output = ~61,022 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 12 |
| **TOTAL** | **4** | **1** | **2** | **1** | **1** | **1** | **12** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_4 |  | resolve_compound_ids, search_blocks |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_692 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 1 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 12 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 12

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2009.03.002 | 1 | 12 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2009.03.002 | PROPblock_1 | declared | 12 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethylene gl… | 296 | KEEP | 296 | 4.2 |
| 2 | 4 | `search_blocks` | compound=['GLOBcomp_24', 'GLOBcomp_4'], limit=50, … | 1,091 | KEEP | 1063 | 20.8 |
| 3 | 1 | `L1_query` | context=Looking for binary viscosity …, id_catalog… | 9,435 | — | — | 107.7 |
| | | **TOTAL (3 tools)** | | **10,822** | | **1,359** | **132.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,112 | 10,717 | 1,423 | 7.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,239 | 21,882 | 654 | 4.5 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,514 | 23,157 | 4,625 | 23.0 |
| 4 | L1-worker | claudeopus46 | 2,065 | 468 | 2,533 | 541 | 4.1 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,750 | 23,393 | 4,719 | 24.1 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,485 | 24,128 | 866 | 5.0 |
| 7 | L1-worker | claudeopus46 | 2,065 | 2,773 | 4,838 | 1,568 | 11.1 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,783 | 25,426 | 1,387 | 8.9 |
| 9 | L1-worker | claudeopus46 | 1,356 | 1,518 | 2,874 | 619 | 4.2 |
| 10 | L1-worker | claudeopus46 | 1,323 | 6,218 | 7,541 | 1,042 | 6.1 |
| 11 | L1-worker | claudeopus46 | 536 | 1,398 | 1,934 | 616 | 6.8 |
| 12 | L1-worker | claudeopus46 | 298 | 1,764 | 2,062 | 808 | 3.9 |
| 13 | L1-worker | claudeopus46 | 747 | 14,324 | 15,071 | 594 | 6.3 |
| 14 | L0-main | claudeopus46 | 9,605 | 20,804 | 30,409 | 2,245 | 16.4 |
| 15 | L0-main | claudeopus46 | 1,356 | 2,104 | 3,460 | 862 | 7.0 |
| 16 | L0-main | claudeopus46 | 1,323 | 14,324 | 15,647 | 1,920 | 12.5 |
| 17 | L0-main | claudeopus46 | 298 | 2,588 | 2,886 | 1,644 | 5.6 |


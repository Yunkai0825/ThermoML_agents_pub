# Delegated query run — result

**Question:** Find binary mixture data blocks containing dynamic viscosity measurements for ethylene glycol + methanol near 298 K (25 °C). Return DOIs, block numbers, compound IDs, property IDs, temperature ranges, and data point counts.

**Iterations:** 2  |  **Elapsed:** 131.7s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity Data for Ethylene Glycol + Methanol Binary Mixture near 298 K

**One data block was found in the ThermoML database:**

### Block Details

| Field | Value |
|-------|-------|
| **DOI** | 10.1016/j.fluid.2009.03.002 (GLOBlit_692) |
| **Block** | PROPblock_1 |
| **System type** | Binary mixture |
| **Compounds** | 1,2-ethanediol / ethylene glycol (GLOBcomp_24) + methanol (GLOBcomp_4) |
| **Property** | Dynamic viscosity (GLOBprop_4), reported in Pa·s |
| **Measurement method** | Capillary tube / Ostwald–Ubbelohde viscometer |
| **Temperature range** | 293.15 K, 298.15 K, 303.15 K (3 temperatures) |
| **Composition range** | Mass fraction of ethylene glycol: 0.00, 0.25, 0.50, 0.75 (4 compositions) |
| **Constraint** | Pressure = 101.0 kPa |
| **Total data points** | 12 (4 compositions × 3 temperatures) |
| **Viscosity range** | 0.000511 – 0.0058 Pa·s |

### Representative Data at 298.15 K

| w(ethylene glycol) | η (Pa·s) | Uncertainty (95% confidence) |
|:---:|:---:|:---:|
| 0.00 (pure methanol) | 0.0005436 | ±7.4 × 10⁻⁶ |
| 0.25 | 0.0010295 | ±9.8 × 10⁻⁶ |
| 0.50 | 0.0020452 | ±1.65 × 10⁻⁵ |
| 0.75 | 0.004904 | ±3.64 × 10⁻⁵ |

### Chemistry Insight

The viscosity increases roughly **9-fold** as the ethylene glycol mass fraction rises from 0 to 0.75, showing a strong positive deviation from linear (ideal) mixing. This nonideality arises from extensive **hydrogen-bond network formation**: ethylene glycol's two hydroxyl groups can simultaneously donate and accept H-bonds with methanol, creating larger, more viscous molecular clusters than either pure component alone. This binary interaction data is directly relevant for modeling the nonideality contributions in the ternary ethylene glycol + water + methanol system, where the ethylene glycol–methanol cross-interaction term would be parameterized from these measurements.

No additional data blocks for this binary pair and property were found in the database.

### Core claims

- A single ThermoML data block (DOI 10.1016/j.fluid.2009.03.002) reports dynamic viscosity for the binary mixture of ethylene glycol and methanol, measured by capillary tube / Ostwald–Ubbelohde viscometer at 101.0 kPa across three temperatures (293.15, 298.15, and 303.15 K) and four ethylene glycol mass fractions (0.00, 0.25, 0.50, 0.75), yielding 12 data points with viscosities ranging from approximately 0.000511 to 0.0058 Pa·s.
- At 298.15 K, the dynamic viscosity increases roughly 9-fold as the ethylene glycol mass fraction rises from 0 to 0.75, exhibiting a strong positive deviation from linear (ideal) mixing behavior attributed to extensive hydrogen-bond network formation between ethylene glycol's two hydroxyl groups and methanol.
- No additional ThermoML data blocks for this binary pair and property were found in the database.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_692 | 10.1016/j.fluid.2009.03.002 | PROPblock_1 |  | Dynamic viscosity (Pa·s) measurements for ethylene glycol (GLOBcomp_24) + methanol (GLOBcomp_4) binary mixture at 293.15, 298.15, and 303.15 K across mass fractions 0.00–0.75 of ethylene glycol. 12 data points (4 compositions × 3 temperatures). Measurement method: capillary tube / Ostwald–Ubbelohde viscometer (GLOBmeas_4). Constraint: pressure = 101.0 kPa. |

### Suggested follow-ups

- Search for dynamic viscosity data for ethylene glycol + water binary mixture near 298 K (GLOBprop_4 with GLOBcomp_24 + GLOBcomp_3) to obtain the second binary interaction parameter for the ternary system.
- Search for dynamic viscosity data for methanol + water binary mixture near 298 K (GLOBprop_4 with GLOBcomp_4 + GLOBcomp_3) to complete the set of binary pairs needed for ternary modeling.
- Query for excess molar volume or excess viscosity data for the same ethylene glycol + methanol system to further characterize nonideality.
- Look for ternary ethylene glycol + water + methanol viscosity data directly in ThermoML to compare with predictions from binary interaction parameters.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_24",
    "registry_id": "1,2-ethanediol",
    "name": "1,2-ethanediol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_692",
    "registry_id": "2009-roy-pra-0",
    "name": "10.1016/j.fluid.2009.03.002"
  }
]
```

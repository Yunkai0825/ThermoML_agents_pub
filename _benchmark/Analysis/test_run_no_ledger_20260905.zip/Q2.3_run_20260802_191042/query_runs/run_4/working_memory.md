# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_24 | 1,2-ethanediol | 1,2-ethanediol |
| comp | GLOBcomp_4 | methanol | methanol |
| prop | GLOBprop_4 | viscosity_pa_s | Viscosity, Pa*s |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|
| lit | GLOBlit_692 | 2009-roy-pra-0 | 10.1016/j.fluid.2009.03.002 |

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find dynamic viscosity data blocks for ethylene glycol + methanol binary mixture near 298 K → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "One binary mixture data block was found containing dynamic viscosity measurements for ethylene glycol + methanol near 298 K:\n\n**Block: PROPblock_1 in DOI 10.1016/j.fluid.2009.03.002 (GLOBlit_692)**\n\n- **Compounds:** ethylene glycol (GLOBcomp_24, as DOIcomp_1) + methanol (GLOBcomp_4, as DOIcomp_2)\n- **Property:** Dynamic viscosity (GLOBprop_4, BLKprop_1), reported in Pa·s\n- **Measurement method:** Capillary tube / Ostwald–Ubbelohde viscometer (GLOBmeas_4)\n- **Variables:** Mass fraction of ethylene glycol (BLKvar_1 → GLOBvar_5), Temperature (BLKvar_2 → GLOBvar_1)\n- **Constraint:** Pressure = 101.0 kPa (BLKconstr_1 → GLOBconstr_1)\n- **Temperature range:** 293.15 K, 298.15 K, 303.15 K\n- **Total data points:** 12 (4 compositions × 3 temperatures)\n\n**Representative data at 298.15 K:**\n\n| w(ethylene glycol) | η (Pa·s) | Uncertainty |\n|---|---|---|\n| 0.00 | 0.0005436 | ±7.4×10⁻⁶ |\n| 0.25 | 0.0010295 | ±9.8×10⁻⁶ |\n| 0.50 | 0.0020452 | ±1.65×10⁻⁵ |\n| 0.75 | 0.004904 | ±3.64×10⁻⁵ |\n\nThe viscosity increases roughly 9-fold as ethylene glycol mass fraction rises from 0 to 0.75, consistent with the much higher viscosity of pure ethylene glycol (~16 mPa·s at 25 °C) compared to methanol (~0.54 mPa·s). The strong positive deviation from linear mixing reflects extensive hydrogen-bond network formation between the two hydroxyl groups of ethylene glycol and methanol.",
  "core_claims": [
    "In the ethylene glycol + methanol binary mixture at 298.15 K and 101.0 kPa, dynamic viscosity increases roughly 9-fold as the ethylene glycol mass fraction rises from 0 to 0.75, based on capillary viscometer measurements reported in DOI 10.1016/j.fluid.2009.03.002.",
    "The strong positive deviation from linear mixing of viscosity in this system is attributed to extensive hydrogen-bond network formation between the two hydroxyl groups of ethylene glycol and methanol.",
    "Data cover 4 compositions across 3 temperatures (293.15 K, 298.15 K, 303.15 K) at atmospheric pressure, totaling 12 data points."
  ],
  "status": "success",
  "summary": "In DOI 10.1016/j.fluid.2009.03.002, one binary-mixture data block reports dynamic viscosity (Pa·s) for ethylene glycol (GLOBcomp_24) + methanol (GLOBcomp_4), measured by capillary-tube/Ostwald–Ubbelohde viscometry at 101.0 kPa. Twelve data points span four mass fractions of ethylene glycol (0.00, 0.25, 0.50, 0.75) and three temperatures (293.15, 298.15, 303.15 K). At 298.15 K the viscosity rises roughly 9-fold from ~0.54 mPa·s (pure methanol) to ~4.9 mPa·s at w = 0.75, showing a strong positive deviation from linear mixing attributed to hydrogen-bond network formation between the two components.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_24",
      "registry_id": "1,2-ethanediol",
      "name": "1,2-ethanediol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_692",
      "registry_id": "2009-roy-pra-0",
      "name": "10.1016/j.fluid.2009.03.002"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_692",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_24"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) measurements for ethylene glycol (GLOBcomp_24) + methanol (GLOBcomp_4) binary mixture at 293.15, 298.15, and 303.15 K across mass fractions 0.00–0.75 of ethylene glycol. 12 data points (4 compositions × 3 temperatures). Measurement method: capillary tube / Ostwald–Ubbelohde viscometer (GLOBmeas_4). Constraint: pressure = 101.0 kPa. DOI: 10.1016/j.fluid.2009.03.002.",
      "doi": "10.1016/j.fluid.2009.03.002",
      "lit_id": "2009-roy-pra-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 12,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_24",
          "name": "1,2-ethanediol",
          "formula": "C2H6O2",
          "inchi_key": "LYCAIKOWRPUZTN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_1",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 0.75,
            "n_unique": 4
          },
          "range_min": 0.0,
          "range_max": 0.75
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000511,
            "max": 0.0058,
            "mean": 0.00215,
            "std": 0.001831,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000511,
          "range_max": 0.0058
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_24",
          "name": "1,2-ethanediol",
          "formula": "C2H6O2",
          "inchi_key": "LYCAIKOWRPUZTN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


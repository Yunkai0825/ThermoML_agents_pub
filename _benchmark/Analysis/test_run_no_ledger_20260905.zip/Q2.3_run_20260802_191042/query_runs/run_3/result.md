# Delegated query run — result

**Question:** Find binary mixture data blocks containing dynamic viscosity measurements for ethylene glycol + water near 298 K (25 °C). Return DOIs, block numbers, compound IDs, property IDs, temperature ranges, and data point counts.

**Iterations:** 5  |  **Elapsed:** 433.3s  |  **Tools:** 4  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity Data for Ethylene Glycol + Water Binary Mixture near 298 K

Six ThermoML data blocks were found containing dynamic viscosity (GLOBprop_4, Pa·s) measurements for the binary mixture of **ethylene glycol** (1,2-ethanediol, GLOBcomp_24, C₂H₆O₂) and **water** (GLOBcomp_1, H₂O) near 298 K (25 °C):

| # | DOI | Literature ID | Block | Data Points | T Range (K) | Composition Variable | P (kPa) | Method |
|---|-----|---------------|-------|-------------|-------------|---------------------|---------|--------|
| 1 | 10.1016/j.jct.2006.01.011 | GLOBlit_2656 | PROPblock_13 | 10 | 293.15 (fixed) | Mass fraction (GLOBvar_5), w = 0.0–0.9 | 101.325 | Capillary (Ostwald-Ubbelohde) |
| 2 | 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | PROPblock_24 | **84** | 293.15–308.15 | Mole fraction (GLOBvar_2), x = 0.0–1.0 | 92.3 | Concentric cylinders |
| 3 | 10.1021/acs.jced.6b00526 | GLOBlit_6951 | PROPblock_18 | 33 | 293.15–303.15 | Mole fraction (GLOBvar_2), x = 0.0–1.0 | 100.0 | Falling/rolling sphere |
| 4 | 10.1021/je020140j | GLOBlit_8038 | PROPblock_5 | 77 | 293.15–353.15 | Mole fraction (GLOBvar_2), x = 0.0–1.0 | 101.0 | Capillary tube |
| 5 | 10.1021/je025610o | GLOBlit_8106 | PROPblock_5 | 30 | 296.45–449.85 | Mole fraction (GLOBvar_2), x = 0.25–0.75 | 100.0 | Capillary tube |
| 6 | 10.1021/je9000697 | GLOBlit_11506 | PROPblock_1 | 16 | 298.15–318.15 | Mass fraction (GLOBvar_5), w = 0.1–1.0 | 101.0 | Capillary tube |

### Key Details

- **Total data points across all blocks:** 250
- **Viscosity ranges:** The measured dynamic viscosity spans roughly 0.000356–0.021 Pa·s across all blocks, reflecting the strong composition dependence of this system.
- **Largest dataset:** GLOBlit_5201 / PROPblock_24 (84 points, DOI 10.1016/j.jct.2018.02.022) provides the most detailed composition dependence with 21 unique mole fractions across 4 temperatures near 298 K.
- **Widest temperature coverage:** GLOBlit_8106 / PROPblock_5 (DOI 10.1021/je025610o) spans 296.45–449.85 K but covers only three compositions (x = 0.25, 0.50, 0.75).
- **Blocks at exactly 298.15 K:** GLOBlit_11506 / PROPblock_1 (DOI 10.1021/je9000697) starts at 298.15 K.

### Representative Data Points

From GLOBlit_5201 (PROPblock_24), the viscosity range at the measured temperatures is:
- η_min ≈ 0.000759 Pa·s (dilute, water-rich end)
- η_max ≈ 0.02061 Pa·s (ethylene glycol-rich end)
- η_mean ≈ 0.00728 Pa·s

### Chemistry Context

The ethylene glycol–water system is the basis for commercial antifreeze/coolant formulations. Its dynamic viscosity varies strongly and non-linearly with composition, exhibiting a pronounced maximum at intermediate ethylene glycol mole fractions (roughly x_EG ≈ 0.3–0.4) near room temperature. This behavior arises from extensive hydrogen-bonding interactions between the two hydroxyl groups of the diol and water molecules, creating a more structured liquid network at intermediate compositions. For your planned ternary analysis with methanol, these binary viscosity data provide the essential ethylene glycol–water interaction baseline needed to isolate methanol's contribution to the overall nonideality.

### Core claims

- Six ThermoML data blocks totaling 250 data points were identified for dynamic viscosity of the ethylene glycol + water binary mixture near 298 K, spanning roughly 0.000356–0.021 Pa·s across compositions from pure water to pure ethylene glycol at pressures near ambient (92.3–101.325 kPa).
- The largest single dataset (DOI 10.1016/j.jct.2018.02.022, 84 points) provides the most detailed composition dependence with 21 unique mole fractions across four temperatures near 298 K.
- Dynamic viscosity in this system varies strongly and non-linearly with composition, exhibiting a pronounced maximum at intermediate ethylene glycol mole fractions (roughly x_EG ≈ 0.3–0.4) near room temperature, attributed to extensive hydrogen-bonding interactions between the diol and water.
- These binary viscosity data serve as the ethylene glycol–water interaction baseline needed for planned ternary analysis with methanol.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2656 | 10.1016/j.jct.2006.01.011 | PROPblock_13 |  | Dynamic viscosity (GLOBprop_4) of ethylene glycol + water binary mixture; 10 data points at 293.15 K, mass fraction variable (GLOBvar_5), P = 101.325 kPa. |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Dynamic viscosity (GLOBprop_4) of ethylene glycol + water binary mixture; 84 data points, T = 293.15–308.15 K, mole fraction variable (GLOBvar_2), P = 92.3 kPa. Largest dataset with 21 unique mole fractions across 4 temperatures. |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 |  | Dynamic viscosity (GLOBprop_4) of ethylene glycol + water binary mixture; 33 data points, T = 293.15–303.15 K, mole fraction variable (GLOBvar_2), P = 100.0 kPa. |
| GLOBlit_8038 | 10.1021/je020140j | PROPblock_5 |  | Dynamic viscosity (GLOBprop_4) of ethylene glycol + water binary mixture; 77 data points, T = 293.15–353.15 K, mole fraction variable (GLOBvar_2), P = 101.0 kPa. |
| GLOBlit_8106 | 10.1021/je025610o | PROPblock_5 |  | Dynamic viscosity (GLOBprop_4) of ethylene glycol + water binary mixture; 30 data points, T = 296.45–449.85 K, mole fraction variable (GLOBvar_2), P = 100.0 kPa. Widest temperature range but only three compositions (x = 0.25, 0.50, 0.75). |
| GLOBlit_11506 | 10.1021/je9000697 | PROPblock_1 |  | Dynamic viscosity (GLOBprop_4) of ethylene glycol + water binary mixture; 16 data points, T = 298.15–318.15 K, mass fraction variable (GLOBvar_5), P = 101.0 kPa. |

### Suggested follow-ups

- Retrieve full numerical data arrays from the largest dataset (GLOBlit_5201 / PROPblock_24, DOI 10.1016/j.jct.2018.02.022) for detailed composition-dependent viscosity analysis at each temperature.
- Search for analogous binary viscosity data for ethylene glycol + methanol and water + methanol mixtures near 298 K to complete the ternary interaction baseline.
- Compare viscosity data across the six sources at overlapping compositions and temperatures to assess inter-laboratory consistency and estimate measurement uncertainty.
- Query for excess viscosity or viscosity deviation data (if available as a separate property) for the ethylene glycol + water system to directly quantify nonideality.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_24",
    "registry_id": "1,2-ethanediol",
    "name": "1,2-ethanediol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "dynamic viscosity",
    "name": "Viscosity (dynamic)"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole fraction",
    "name": "Mole fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_5",
    "registry_id": "mass fraction",
    "name": "Mass fraction"
  }
]
```

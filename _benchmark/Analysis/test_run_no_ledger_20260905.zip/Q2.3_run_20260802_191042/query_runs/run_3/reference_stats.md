# Reference Stats — query-agent

**Run started:** 2026-08-02 19:17:28
**Wall time (at last flush):** 463.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 51,300 | 80,751 | 17,512 | 132,051 | 14,672 | 97.5 | claudeopus46 |
| L1-worker | 42 | 359,226 | 188,194 | 76,777 | 547,420 | 13,033 | 407.5 | claudeopus46 |
| **TOTAL** | **51** | **410,526** | **268,945** | **94,289** | **679,471** | **13,322** | **505.0** | |

**Estimated tokens:** ~169,867 input + ~23,572 output = ~193,439 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 2 | 6 | 6 | 250 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **13** | **1** | **3** | **2** | **6** | **6** | **250** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_151 |  | resolve_compound_ids |
| GLOBcomp_234 |  | resolve_compound_ids |
| GLOBcomp_770 |  | resolve_compound_ids |
| GLOBcomp_863 |  | resolve_compound_ids |
| GLOBcomp_1676 |  | resolve_compound_ids |
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2656 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_6951 |  | search_blocks |
| GLOBlit_8038 |  | search_blocks |
| GLOBlit_8106 |  | search_blocks |
| GLOBlit_11506 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_227 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 7 |
| Unique References | 6 |
| Unique Properties | 1 |
| Unique Measurements | 5 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Total DOIs | 6 |
| Unique parent blocks | 6 |
| Explicit block/subsystem targets | 6 |
| Subsystem targets | 0 |
| Target-matched data points | 250 |

---

## 3. DOI & Block References

**Unique DOIs:** 6  |  **Parent blocks:** 6  |  **Explicit targets:** 6  |  **Subsystems:** 0  |  **Target-matched datapoints:** 250

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.01.011 | 1 | 10 | binary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 84 | binary | search_blocks |
| 10.1021/acs.jced.6b00526 | 1 | 33 | binary | search_blocks |
| 10.1021/je020140j | 1 | 77 | binary | search_blocks |
| 10.1021/je025610o | 1 | 30 | binary | search_blocks |
| 10.1021/je9000697 | 1 | 16 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | — | search_blocks |
| 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | — | search_blocks |
| 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | — | search_blocks |
| 10.1021/je9000697 | PROPblock_1 | declared | 16 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 638 | DISCARD | 573 | 7.3 |
| 2 | 4 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 256 | KEEP | 256 | 4.1 |
| 3 | 1 | `L1_query` | context=Looking for binary viscosity …, id_catalog… | 202 | — | — | 112.8 |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 277 | KEEP | 277 | 4.2 |
| 5 | 2 | `L1_query` | context=Looking for binary viscosity …, id_catalog… | 917 | — | — | 114.1 |
| 6 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve global comp… | 372 | KEEP | 372 | 4.7 |
| 7 | 3 | `L1_query` | context=Need compound IDs before sear…, id_catalog… | 1,656 | — | — | 30.6 |
| 8 | 2 | `search_blocks` | compound=['GLOBcomp_24', 'GLOBcomp_1'], limit=50, … | 1,364 | KEEP | 1273 | 14.3 |
| 9 | 4 | `L1_query` | context=Searching for binary mixture …, id_catalog… | 270 | — | — | 115.9 |
| | | **TOTAL (9 tools)** | | **5,952** | | **2,751** | **408.0** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,103 | 10,708 | 1,267 | 6.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,213 | 21,856 | 711 | 5.0 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,545 | 23,188 | 960 | 5.7 |
| 4 | L1-worker | claudeopus46 | 2,065 | 686 | 2,751 | 952 | 6.3 |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,092 | 23,735 | 533 | 4.1 |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,246 | 24,889 | 565 | 3.8 |
| 7 | L1-worker | claudeopus46 | 2,065 | 457 | 2,522 | 488 | 4.0 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,396 | 25,039 | 4,903 | 30.8 |
| 9 | L1-worker | claudeopus46 | 20,643 | 9,920 | 30,563 | 1,659 | 6.6 |
| 10 | L1-worker | claudeopus46 | 1,356 | 1,788 | 3,144 | 703 | 4.9 |
| 11 | L1-worker | claudeopus46 | 536 | 1,668 | 2,204 | 747 | 5.1 |
| 12 | L1-worker | claudeopus46 | 1,323 | 5,326 | 6,649 | 4,336 | 18.0 |
| 13 | L1-worker | claudeopus46 | 298 | 5,058 | 5,356 | 3,362 | 13.1 |
| 14 | L1-worker | claudeopus46 | 1,160 | 10,248 | 11,408 | 3,349 | 13.7 |
| 15 | L0-main | claudeopus46 | 9,605 | 1,795 | 11,400 | 1,213 | 6.9 |
| 16 | L1-worker | claudeopus46 | 20,643 | 1,186 | 21,829 | 853 | 7.6 |
| 17 | L1-worker | claudeopus46 | 20,643 | 2,660 | 23,303 | 7,359 | 35.2 |
| 18 | L1-worker | claudeopus46 | 2,065 | 506 | 2,571 | 509 | 4.1 |
| 19 | L1-worker | claudeopus46 | 20,643 | 2,885 | 23,528 | 4,870 | 26.3 |
| 20 | L1-worker | claudeopus46 | 20,643 | 8,376 | 29,019 | 2,290 | 9.7 |
| 21 | L1-worker | claudeopus46 | 1,356 | 1,937 | 3,293 | 1,008 | 5.6 |
| 22 | L1-worker | claudeopus46 | 536 | 1,817 | 2,353 | 1,032 | 6.1 |
| 23 | L1-worker | claudeopus46 | 1,323 | 4,239 | 5,562 | 3,125 | 11.9 |
| 24 | L1-worker | claudeopus46 | 298 | 3,847 | 4,145 | 2,323 | 9.2 |
| 25 | L1-worker | claudeopus46 | 1,160 | 7,777 | 8,937 | 199 | 3.0 |
| 26 | L1-worker | claudeopus46 | 747 | 7,391 | 8,138 | 818 | 6.4 |
| 27 | L0-main | claudeopus46 | 9,605 | 3,250 | 12,855 | 888 | 6.3 |
| 28 | L1-worker | claudeopus46 | 20,643 | 903 | 21,546 | 634 | 6.6 |
| 29 | L1-worker | claudeopus46 | 20,643 | 2,158 | 22,801 | 921 | 5.7 |
| 30 | L1-worker | claudeopus46 | 2,065 | 491 | 2,556 | 572 | 4.4 |
| 31 | L1-worker | claudeopus46 | 20,643 | 2,454 | 23,097 | 479 | 3.8 |
| 32 | L1-worker | claudeopus46 | 1,323 | 2,482 | 3,805 | 234 | 2.4 |
| 33 | L1-worker | claudeopus46 | 1,356 | 610 | 1,966 | 403 | 3.3 |
| 34 | L1-worker | claudeopus46 | 536 | 490 | 1,026 | 356 | 3.4 |
| 35 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 2.4 |
| 36 | L1-worker | claudeopus46 | 747 | 3,145 | 3,892 | 489 | 4.5 |
| 37 | L0-main | claudeopus46 | 9,605 | 7,190 | 16,795 | 1,595 | 10.2 |
| 38 | L1-worker | claudeopus46 | 20,643 | 3,174 | 23,817 | 896 | 5.9 |
| 39 | L1-worker | claudeopus46 | 20,643 | 4,691 | 25,334 | 11,591 | 51.6 |
| 40 | L1-worker | claudeopus46 | 2,065 | 9,173 | 11,238 | 1,706 | 13.4 |
| 41 | L1-worker | claudeopus46 | 20,643 | 6,053 | 26,696 | 2,199 | 11.3 |
| 42 | L1-worker | claudeopus46 | 1,356 | 2,330 | 3,686 | 885 | 4.8 |
| 43 | L1-worker | claudeopus46 | 536 | 2,210 | 2,746 | 1,179 | 6.3 |
| 44 | L1-worker | claudeopus46 | 1,323 | 5,823 | 7,146 | 3,139 | 11.6 |
| 45 | L1-worker | claudeopus46 | 298 | 3,861 | 4,159 | 2,517 | 10.1 |
| 46 | L1-worker | claudeopus46 | 747 | 43,926 | 44,673 | 769 | 9.8 |
| 47 | L0-main | claudeopus46 | 9,605 | 47,694 | 57,299 | 3,973 | 29.4 |
| 48 | L0-main | claudeopus46 | 1,356 | 3,282 | 4,638 | 941 | 5.5 |
| 49 | L0-main | claudeopus46 | 298 | 1,323 | 1,621 | 929 | 3.3 |
| 50 | L0-main | claudeopus46 | 1,323 | 10,809 | 12,132 | 3,637 | 18.3 |
| 51 | L0-main | claudeopus46 | 298 | 4,305 | 4,603 | 3,069 | 11.1 |


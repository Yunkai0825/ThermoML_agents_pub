# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 22,187 | 40,932 | 8,094 | 63,119 | 12,623 | 49.0 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| L1-worker | 12 | 111,605 | 43,234 | 18,039 | 154,839 | 12,903 | 108.0 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| L0-main | 9 | 51,300 | 80,751 | 17,512 | 132,051 | 14,672 | 97.5 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| L1-worker | 42 | 359,226 | 188,194 | 76,777 | 547,420 | 13,033 | 407.5 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| L0-main | 7 | 41,397 | 73,810 | 14,609 | 115,207 | 16,458 | 85.7 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| L1-worker | 37 | 316,459 | 192,649 | 92,617 | 509,108 | 13,759 | 463.8 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| **TOTAL** | **112** | **902,174** | **619,570** | **227,648** | **1,521,744** | **83,448** | **1,211.5** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 12 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `search_blocks` | 2 | 1 | 3 | 2 | 6 | 6 | 250 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| `search_blocks` | 2 | 1 | 4 | 1 | 4 | 4 | 76 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| `search_blocks` | 2 | 1 | 4 | 1 | 4 | 4 | 76 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| **TOTAL** | **27** | **5** | **13** | **5** | **15** | **15** | **414** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Unique References | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Unique Properties | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Unique Measurements | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Unique Phases | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Unique Variables | 2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Unique Constraints | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Unique parent blocks | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Explicit block/subsystem targets | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Subsystem targets | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| Target-matched data points | 12 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| GLOBcomp_151 |  | resolve_compound_ids |
| GLOBcomp_234 |  | resolve_compound_ids |
| GLOBcomp_770 |  | resolve_compound_ids |
| GLOBcomp_863 |  | resolve_compound_ids |
| GLOBcomp_1676 |  | resolve_compound_ids |
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBlit_2656 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_6951 |  | search_blocks |
| GLOBlit_8038 |  | search_blocks |
| GLOBlit_8106 |  | search_blocks |
| GLOBlit_11506 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_227 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique Compounds | 7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Unique References | 6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Unique Properties | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Unique Measurements | 5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Unique Phases | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Unique Variables | 3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Unique Constraints | 2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Unique parent blocks | 6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Explicit block/subsystem targets | 6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Subsystem targets | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| Target-matched data points | 250 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_4 |  | resolve_compound_ids, search_blocks |
| GLOBlit_2825 |  | search_blocks |
| GLOBlit_5533 |  | search_blocks |
| GLOBlit_8869 |  | search_blocks |
| GLOBlit_9571 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | resolve_property_ids, search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_271 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_18 | Volume fraction | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique Compounds | 2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Unique References | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Unique Properties | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Unique Measurements | 3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Unique Phases | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Unique Variables | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Unique Constraints | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Unique parent blocks | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Explicit block/subsystem targets | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Subsystem targets | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| Target-matched data points | 152 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| **TOTAL** | **486** |  |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | ---: | ---: | ---: | --- | --- | --- | --- |
| 10.1016/j.fluid.2009.03.002 | PROPblock_1 | declared | 12 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 10.1016/j.jct.2006.01.011 | 1 | 10 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |  |  |
| 10.1016/j.jct.2018.02.022 | 1 | 84 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |  |  |
| 10.1021/acs.jced.6b00526 | 1 | 33 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |  |  |
| 10.1021/je020140j | 1 | 77 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |  |  |
| 10.1021/je025610o | 1 | 30 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |  |  |
| 10.1021/je9000697 | 1 | 16 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |  |  |
| 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 10.1021/je9000697 | PROPblock_1 | declared | 16 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |  |  |
| 10.1016/j.jct.2019.05.013 | 1 | 12 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |  |  |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |  |  |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |  |  |
| 10.1016/j.jct.2007.05.004 | PROPblock_9 | declared | 39 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 10.1016/j.jct.2019.05.013 | PROPblock_3 | declared | 12 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 10.1021/je0600810 | PROPblock_3 | declared | 9 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 10.1021/je2003622 | PROPblock_1 | declared | 16 | binary | — | search_blocks | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| **TOTAL** | **10** | **326** | **338** |  |  |  |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethylene gl… | 296 | KEEP | 296 | 4.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 2 | 4 | `search_blocks` | compound=['GLOBcomp_24', 'GLOBcomp_4'], limit=50, … | 1,091 | KEEP | 1063 | 20.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 3 | 1 | `L1_query` | context=Looking for binary viscosity …, id_catalog… | 9,435 | — | — | 107.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 638 | DISCARD | 573 | 7.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 2 | 4 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 256 | KEEP | 256 | 4.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 3 | 1 | `L1_query` | context=Looking for binary viscosity …, id_catalog… | 202 | — | — | 112.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 277 | KEEP | 277 | 4.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 5 | 2 | `L1_query` | context=Looking for binary viscosity …, id_catalog… | 917 | — | — | 114.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 6 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve global comp… | 372 | KEEP | 372 | 4.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 7 | 3 | `L1_query` | context=Need compound IDs before sear…, id_catalog… | 1,656 | — | — | 30.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 8 | 2 | `search_blocks` | compound=['GLOBcomp_24', 'GLOBcomp_1'], limit=50, … | 1,364 | KEEP | 1273 | 14.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 9 | 4 | `L1_query` | context=Searching for binary mixture …, id_catalog… | 270 | — | — | 115.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve water and m… | 222 | KEEP | 222 | 3.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 2 | 1 | `L1_query` | context=User is looking for binary vi…, id_catalog… | 381 | — | — | 125.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 3 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve global comp… | 222 | KEEP | 222 | 3.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 4 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 847 | KEEP | 832 | 16.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 5 | 2 | `L1_query` | context=User wants binary viscosity d…, id_catalog… | 524 | — | — | 149.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 6 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve global comp… | 365 | KEEP | 365 | 4.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 7 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Verify the global p… | 256 | KEEP | 256 | 3.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 8 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 886 | KEEP | 886 | 14.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 9 | 3 | `L1_query` | context=This is a fresh search. No pr…, id_catalog… | 15,929 | — | — | 160.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| **TOTAL** | **50** |  |  | **36,406** |  | **6,893** | **1,021.0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,112 | 10,717 | 1,423 | 7.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,239 | 21,882 | 654 | 4.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,514 | 23,157 | 4,625 | 23.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 4 | L1-worker | claudeopus46 | 2,065 | 468 | 2,533 | 541 | 4.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,750 | 23,393 | 4,719 | 24.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,485 | 24,128 | 866 | 5.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 7 | L1-worker | claudeopus46 | 2,065 | 2,773 | 4,838 | 1,568 | 11.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,783 | 25,426 | 1,387 | 8.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 9 | L1-worker | claudeopus46 | 1,356 | 1,518 | 2,874 | 619 | 4.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 10 | L1-worker | claudeopus46 | 1,323 | 6,218 | 7,541 | 1,042 | 6.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 11 | L1-worker | claudeopus46 | 536 | 1,398 | 1,934 | 616 | 6.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 12 | L1-worker | claudeopus46 | 298 | 1,764 | 2,062 | 808 | 3.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 13 | L1-worker | claudeopus46 | 747 | 14,324 | 15,071 | 594 | 6.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 14 | L0-main | claudeopus46 | 9,605 | 20,804 | 30,409 | 2,245 | 16.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 15 | L0-main | claudeopus46 | 1,356 | 2,104 | 3,460 | 862 | 7.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 16 | L0-main | claudeopus46 | 1,323 | 14,324 | 15,647 | 1,920 | 12.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 17 | L0-main | claudeopus46 | 298 | 2,588 | 2,886 | 1,644 | 5.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_4) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,103 | 10,708 | 1,267 | 6.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,213 | 21,856 | 711 | 5.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,545 | 23,188 | 960 | 5.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 4 | L1-worker | claudeopus46 | 2,065 | 686 | 2,751 | 952 | 6.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,092 | 23,735 | 533 | 4.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,246 | 24,889 | 565 | 3.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 7 | L1-worker | claudeopus46 | 2,065 | 457 | 2,522 | 488 | 4.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,396 | 25,039 | 4,903 | 30.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 9 | L1-worker | claudeopus46 | 20,643 | 9,920 | 30,563 | 1,659 | 6.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 10 | L1-worker | claudeopus46 | 1,356 | 1,788 | 3,144 | 703 | 4.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 11 | L1-worker | claudeopus46 | 536 | 1,668 | 2,204 | 747 | 5.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 12 | L1-worker | claudeopus46 | 1,323 | 5,326 | 6,649 | 4,336 | 18.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 13 | L1-worker | claudeopus46 | 298 | 5,058 | 5,356 | 3,362 | 13.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 14 | L1-worker | claudeopus46 | 1,160 | 10,248 | 11,408 | 3,349 | 13.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 15 | L0-main | claudeopus46 | 9,605 | 1,795 | 11,400 | 1,213 | 6.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 16 | L1-worker | claudeopus46 | 20,643 | 1,186 | 21,829 | 853 | 7.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 17 | L1-worker | claudeopus46 | 20,643 | 2,660 | 23,303 | 7,359 | 35.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 18 | L1-worker | claudeopus46 | 2,065 | 506 | 2,571 | 509 | 4.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 19 | L1-worker | claudeopus46 | 20,643 | 2,885 | 23,528 | 4,870 | 26.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 20 | L1-worker | claudeopus46 | 20,643 | 8,376 | 29,019 | 2,290 | 9.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 21 | L1-worker | claudeopus46 | 1,356 | 1,937 | 3,293 | 1,008 | 5.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 22 | L1-worker | claudeopus46 | 536 | 1,817 | 2,353 | 1,032 | 6.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 23 | L1-worker | claudeopus46 | 1,323 | 4,239 | 5,562 | 3,125 | 11.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 24 | L1-worker | claudeopus46 | 298 | 3,847 | 4,145 | 2,323 | 9.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 25 | L1-worker | claudeopus46 | 1,160 | 7,777 | 8,937 | 199 | 3.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 26 | L1-worker | claudeopus46 | 747 | 7,391 | 8,138 | 818 | 6.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 27 | L0-main | claudeopus46 | 9,605 | 3,250 | 12,855 | 888 | 6.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 28 | L1-worker | claudeopus46 | 20,643 | 903 | 21,546 | 634 | 6.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 29 | L1-worker | claudeopus46 | 20,643 | 2,158 | 22,801 | 921 | 5.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 30 | L1-worker | claudeopus46 | 2,065 | 491 | 2,556 | 572 | 4.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 31 | L1-worker | claudeopus46 | 20,643 | 2,454 | 23,097 | 479 | 3.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 32 | L1-worker | claudeopus46 | 1,323 | 2,482 | 3,805 | 234 | 2.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 33 | L1-worker | claudeopus46 | 1,356 | 610 | 1,966 | 403 | 3.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 34 | L1-worker | claudeopus46 | 536 | 490 | 1,026 | 356 | 3.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 35 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 2.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 36 | L1-worker | claudeopus46 | 747 | 3,145 | 3,892 | 489 | 4.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 37 | L0-main | claudeopus46 | 9,605 | 7,190 | 16,795 | 1,595 | 10.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 38 | L1-worker | claudeopus46 | 20,643 | 3,174 | 23,817 | 896 | 5.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 39 | L1-worker | claudeopus46 | 20,643 | 4,691 | 25,334 | 11,591 | 51.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 40 | L1-worker | claudeopus46 | 2,065 | 9,173 | 11,238 | 1,706 | 13.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 41 | L1-worker | claudeopus46 | 20,643 | 6,053 | 26,696 | 2,199 | 11.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 42 | L1-worker | claudeopus46 | 1,356 | 2,330 | 3,686 | 885 | 4.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 43 | L1-worker | claudeopus46 | 536 | 2,210 | 2,746 | 1,179 | 6.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 44 | L1-worker | claudeopus46 | 1,323 | 5,823 | 7,146 | 3,139 | 11.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 45 | L1-worker | claudeopus46 | 298 | 3,861 | 4,159 | 2,517 | 10.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 46 | L1-worker | claudeopus46 | 747 | 43,926 | 44,673 | 769 | 9.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 47 | L0-main | claudeopus46 | 9,605 | 47,694 | 57,299 | 3,973 | 29.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 48 | L0-main | claudeopus46 | 1,356 | 3,282 | 4,638 | 941 | 5.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 49 | L0-main | claudeopus46 | 298 | 1,323 | 1,621 | 929 | 3.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 50 | L0-main | claudeopus46 | 1,323 | 10,809 | 12,132 | 3,637 | 18.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 51 | L0-main | claudeopus46 | 298 | 4,305 | 4,603 | 3,069 | 11.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_3) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,082 | 10,687 | 1,347 | 7.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,212 | 21,855 | 639 | 4.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,472 | 23,115 | 6,818 | 35.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 4 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 365 | 3.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,612 | 23,255 | 6,485 | 33.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 6 | L1-worker | claudeopus46 | 20,643 | 9,718 | 30,361 | 3,246 | 14.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,923 | 4,279 | 705 | 4.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 8 | L1-worker | claudeopus46 | 536 | 2,803 | 3,339 | 1,159 | 8.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 9 | L1-worker | claudeopus46 | 1,323 | 5,132 | 6,455 | 3,102 | 13.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 10 | L1-worker | claudeopus46 | 298 | 3,824 | 4,122 | 2,480 | 9.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 11 | L1-worker | claudeopus46 | 1,160 | 8,798 | 9,958 | 2,468 | 10.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 12 | L0-main | claudeopus46 | 9,605 | 1,955 | 11,560 | 1,313 | 8.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 13 | L1-worker | claudeopus46 | 20,643 | 1,182 | 21,825 | 634 | 5.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,437 | 23,080 | 12,553 | 50.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 15 | L1-worker | claudeopus46 | 2,065 | 473 | 2,538 | 401 | 3.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,589 | 23,232 | 5,387 | 29.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 17 | L1-worker | claudeopus46 | 20,643 | 3,301 | 23,944 | 712 | 5.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 18 | L1-worker | claudeopus46 | 2,065 | 8,647 | 10,712 | 1,794 | 15.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 19 | L1-worker | claudeopus46 | 20,643 | 4,301 | 24,944 | 1,403 | 9.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 20 | L1-worker | claudeopus46 | 1,356 | 1,534 | 2,890 | 730 | 4.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 21 | L1-worker | claudeopus46 | 536 | 1,414 | 1,950 | 783 | 5.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 22 | L1-worker | claudeopus46 | 1,323 | 5,810 | 7,133 | 1,668 | 7.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 23 | L1-worker | claudeopus46 | 298 | 2,390 | 2,688 | 1,288 | 5.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 24 | L1-worker | claudeopus46 | 747 | 25,378 | 26,125 | 461 | 5.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 25 | L1-worker | claudeopus46 | 1,160 | 8,143 | 9,303 | 1,288 | 5.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 26 | L1-worker | claudeopus46 | 747 | 25,378 | 26,125 | 430 | 5.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 27 | L0-main | claudeopus46 | 9,605 | 2,988 | 12,593 | 1,175 | 7.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 28 | L1-worker | claudeopus46 | 20,643 | 1,111 | 21,754 | 980 | 6.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 29 | L1-worker | claudeopus46 | 20,643 | 2,819 | 23,462 | 14,280 | 51.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 30 | L1-worker | claudeopus46 | 2,065 | 449 | 2,514 | 576 | 4.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 31 | L1-worker | claudeopus46 | 2,065 | 375 | 2,440 | 452 | 3.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 32 | L1-worker | claudeopus46 | 20,643 | 3,443 | 24,086 | 10,481 | 45.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 33 | L1-worker | claudeopus46 | 2,065 | 8,653 | 10,718 | 1,830 | 13.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 34 | L1-worker | claudeopus46 | 20,610 | 5,589 | 26,199 | 411 | 4.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 35 | L1-worker | claudeopus46 | 20,643 | 4,836 | 25,479 | 1,605 | 9.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 36 | L1-worker | claudeopus46 | 1,356 | 1,736 | 3,092 | 733 | 4.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 37 | L1-worker | claudeopus46 | 536 | 1,616 | 2,152 | 827 | 6.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 38 | L1-worker | claudeopus46 | 1,323 | 6,026 | 7,349 | 1,611 | 8.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 39 | L1-worker | claudeopus46 | 298 | 2,333 | 2,631 | 1,252 | 5.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 40 | L1-worker | claudeopus46 | 747 | 20,754 | 21,501 | 580 | 6.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 41 | L0-main | claudeopus46 | 9,605 | 35,759 | 45,364 | 3,009 | 21.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 42 | L0-main | claudeopus46 | 1,356 | 2,892 | 4,248 | 1,144 | 6.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 43 | L0-main | claudeopus46 | 1,323 | 24,806 | 26,129 | 3,660 | 23.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| 44 | L0-main | claudeopus46 | 298 | 4,328 | 4,626 | 2,961 | 12.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| **TOTAL** |  |  | **902,174** | **619,570** | **1,521,744** | **227,648** | **1,211.5** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 4,294 | 4,294 | 0 | 0.0% | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_5) |
| **TOTAL** |  |  | **4,294** | **4,294** | **0** | **0** |  |

# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:10:42
**Wall time (at last flush):** 1,113.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 26 | 425,146 | 487,152 | 60,562 | 912,298 | 35,088 | 344.6 | claudeopus46 |
| L1-worker | 25 | 182,326 | 82,083 | 55,515 | 264,409 | 10,576 | 277.7 | claudeopus46 |
| **TOTAL** | **51** | **607,472** | **569,235** | **116,077** | **1,176,707** | **23,072** | **622.3** | |

**Estimated tokens:** ~294,176 input + ~29,019 output = ~323,195 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'EG_water_viscosit… | 184 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'EG_water_visc', '… | 132 | — | — | 0.0 |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'EG_water_visc', '… | 427 | — | — | 0.2 |
| 4 | 4 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 391 | — | — | 127.8 |
| 5 | 5 | `query_thermoml` | instruction=Search for dynamic viscosity …, purpos… | 670 | — | — | 127.7 |
| 6 | 6 | `run_query_agents_parallel` | queries=[{'question': 'Find binary mi… | 132 | — | — | 0.0 |
| 7 | 7 | `run_query_agents_parallel` | queries=[{'label': 'EG_water_visc', '… | 139 | — | — | 0.0 |
| 8 | 8 | `run_query_agents_parallel` | queries=[{'label': 'EG_water_visc', '… | 137 | — | — | 0.0 |
| 9 | 9 | `run_query_agents_parallel` | queries=[{'label': 'EG_water_visc', '… | 23,760 | — | — | 515.2 |
| 10 | 11 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 624 | — | — | 0.2 |
| 11 | 13 | `inspect_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 1,379 | — | — | 0.2 |
| 12 | 13 | `inspect_block` | block_number=PROPblock_1, doi=10.1016/j.fluid.2009… | 1,388 | — | — | 0.1 |
| 13 | 13 | `inspect_block` | block_number=PROPblock_9, doi=10.1016/j.jct.2007.0… | 1,338 | — | — | 0.1 |
| 14 | 15 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 1,415 | — | — | 1.5 |
| 15 | 16 | `fit_block` | block_number=PROPblock_1, composition_hint=mass_fr… | 649 | — | — | 1.3 |
| | | **TOTAL (15 tools)** | | **32,765** | | **0** | **774.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,408 | 2,408 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,845 | 4,845 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 30,200 | 30,200 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 36,308 | 36,308 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 362 | 20,383 | 2,260 | 11.3 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,115 | 21,136 | 15,181 | 65.2 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,763 | 21,784 | 1,668 | 7.6 |
| 4 | L0-main | claudeopus46 | 19,988 | 3,737 | 23,725 | 567 | 4.0 |
| 5 | L0-main | claudeopus46 | 20,021 | 2,980 | 23,001 | 769 | 6.3 |
| 6 | L1-worker | claudeopus46 | 20,643 | 437 | 21,080 | 698 | 5.3 |
| 7 | L1-worker | claudeopus46 | 20,643 | 1,756 | 22,399 | 5,137 | 25.4 |
| 8 | L1-worker | claudeopus46 | 2,065 | 510 | 2,575 | 494 | 5.2 |
| 9 | L1-worker | claudeopus46 | 20,643 | 1,930 | 22,573 | 5,814 | 32.5 |
| 10 | L1-worker | claudeopus46 | 20,643 | 8,365 | 29,008 | 2,225 | 9.7 |
| 11 | L1-worker | claudeopus46 | 1,356 | 2,098 | 3,454 | 764 | 4.1 |
| 12 | L1-worker | claudeopus46 | 536 | 1,978 | 2,514 | 845 | 5.1 |
| 13 | L1-worker | claudeopus46 | 298 | 1,146 | 1,444 | 752 | 3.3 |
| 14 | L1-worker | claudeopus46 | 298 | 1,201 | 1,499 | 832 | 3.5 |
| 15 | L1-worker | claudeopus46 | 1,323 | 4,095 | 5,418 | 3,285 | 12.8 |
| 16 | L1-worker | claudeopus46 | 298 | 4,007 | 4,305 | 2,671 | 10.8 |
| 17 | L1-worker | claudeopus46 | 1,160 | 8,356 | 9,516 | 3,647 | 13.8 |
| 18 | L1-worker | claudeopus46 | 298 | 4,369 | 4,667 | 2,673 | 11.7 |
| 19 | L0-main | claudeopus46 | 20,021 | 3,811 | 23,832 | 671 | 7.9 |
| 20 | L1-worker | claudeopus46 | 20,643 | 359 | 21,002 | 908 | 6.2 |
| 21 | L1-worker | claudeopus46 | 20,643 | 1,995 | 22,638 | 9,749 | 41.9 |
| 22 | L1-worker | claudeopus46 | 2,065 | 474 | 2,539 | 541 | 5.8 |
| 23 | L1-worker | claudeopus46 | 2,065 | 364 | 2,429 | 452 | 4.1 |
| 24 | L1-worker | claudeopus46 | 20,643 | 2,600 | 23,243 | 4,495 | 25.5 |
| 25 | L1-worker | claudeopus46 | 20,643 | 7,716 | 28,359 | 2,082 | 11.9 |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,978 | 3,334 | 563 | 3.6 |
| 27 | L1-worker | claudeopus46 | 536 | 1,858 | 2,394 | 696 | 4.1 |
| 28 | L1-worker | claudeopus46 | 1,323 | 4,747 | 6,070 | 3,002 | 14.5 |
| 29 | L1-worker | claudeopus46 | 298 | 3,724 | 4,022 | 2,421 | 9.1 |
| 30 | L1-worker | claudeopus46 | 1,160 | 8,502 | 9,662 | 199 | 2.9 |
| 31 | L1-worker | claudeopus46 | 747 | 7,518 | 8,265 | 570 | 4.9 |
| 32 | L0-main | claudeopus46 | 20,021 | 4,908 | 24,929 | 1,808 | 8.5 |
| 33 | L0-main | claudeopus46 | 19,988 | 6,249 | 26,237 | 563 | 4.2 |
| 34 | L0-main | claudeopus46 | 20,021 | 5,492 | 25,513 | 1,353 | 7.3 |
| 35 | L0-main | claudeopus46 | 20,021 | 6,105 | 26,126 | 2,274 | 10.0 |
| 36 | L0-main | claudeopus46 | 20,021 | 6,696 | 26,717 | 2,452 | 15.3 |
| 37 | L0-main | claudeopus46 | 19,988 | 31,711 | 51,699 | 417 | 5.1 |
| 38 | L0-main | claudeopus46 | 20,021 | 31,081 | 51,102 | 2,407 | 16.4 |
| 39 | L0-main | claudeopus46 | 20,021 | 31,844 | 51,865 | 1,730 | 9.7 |
| 40 | L0-main | claudeopus46 | 20,021 | 32,747 | 52,768 | 964 | 6.2 |
| 41 | L0-main | claudeopus46 | 20,021 | 33,884 | 53,905 | 1,075 | 9.2 |
| 42 | L0-main | claudeopus46 | 20,021 | 36,529 | 56,550 | 2,088 | 12.5 |
| 43 | L0-main | claudeopus46 | 20,021 | 37,183 | 57,204 | 2,405 | 12.3 |
| 44 | L0-main | claudeopus46 | 19,988 | 42,112 | 62,100 | 428 | 4.7 |
| 45 | L0-main | claudeopus46 | 20,021 | 41,352 | 61,373 | 2,065 | 15.4 |
| 46 | L0-main | claudeopus46 | 20,021 | 44,090 | 64,111 | 8,753 | 59.1 |
| 47 | L0-main | claudeopus46 | 1,356 | 4,843 | 6,199 | 1,134 | 6.4 |
| 48 | L0-main | claudeopus46 | 298 | 1,516 | 1,814 | 1,122 | 4.0 |
| 49 | L0-main | claudeopus46 | 1,323 | 65,726 | 67,049 | 2,923 | 15.6 |
| 50 | L0-main | claudeopus46 | 298 | 3,765 | 4,063 | 2,422 | 10.9 |
| 51 | L0-main | claudeopus46 | 1,562 | 5,551 | 7,113 | 1,063 | 9.5 |


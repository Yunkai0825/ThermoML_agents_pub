# Analysis Run — 20260802_192915 (Round 1)

**Question:** In an equimolar ethylene glycol + water + methanol liquid mixture near 25 °C, which binary interaction should contribute most strongly to the viscosity nonideality, and why?

**Time:** 1076.5s | **Iterations:** 17 | **Tools:** 20

---

## Answer

## Viscosity Nonideality in the Ternary Ethylene Glycol + Water + Methanol System at 25 °C

### Summary

Based on Redlich-Kister fits (Arrhenius mixing rule) of experimental binary viscosity data near 298 K, the **water + methanol** binary interaction contributes most strongly to viscosity nonideality in the equimolar ternary mixture, closely followed by the **ethylene glycol + water** pair. The **ethylene glycol + methanol** pair contributes substantially less.

---

### Binary Redlich-Kister Fits (Arrhenius Mixing Rule, ~298.15 K)

The Arrhenius mixing rule models viscosity as:

ln η = x₁ ln η₁* + x₂ ln η₂* + x₁ x₂ Σₖ Aₖ (x₁ − x₂)ᵏ

where the RK coefficients Aₖ quantify the excess ln(viscosity) — i.e., the departure from ideal logarithmic mixing.

#### 1. Water + Methanol
- **Source:** DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825), PROPblock_9
- **Data:** 11 mixture points at 298.15 K, mole fraction basis
- **Pure values:** η(water) = 0.000890 Pa·s, η(methanol) = 0.000545 Pa·s
- **BIC-selected order:** 3
- **R² = 0.999903, RMSE = 0.00205 Pa·s**
- **Coefficients:** A₀ = **2.5348**, A₁ = 1.4221, A₂ = 1.3359, A₃ = 0.7545

#### 2. Ethylene Glycol + Water
- **Source:** DOI 10.1016/j.jct.2018.02.022 (GLOBlit_5201), PROPblock_24
- **Data:** 19 mixture points at 298.15 K, mole fraction basis
- **Pure values:** η(EG) = 0.016223 Pa·s, η(water) = 0.000897 Pa·s
- **BIC-selected order:** 3
- **R² = 0.999940, RMSE = 0.00132 Pa·s**
- **Coefficients:** A₀ = **2.3967**, A₁ = −1.0444, A₂ = 0.6682, A₃ = −0.3209

#### 3. Ethylene Glycol + Methanol
- **Source:** DOI 10.1016/j.fluid.2009.03.002 (GLOBlit_692), PROPblock_1
- **Data:** Only 3 mixture points at 298.15 K (mass fraction basis, converted to mole fraction; M_EG = 62.068, M_MeOH = 32.042 g/mol)
- **Pure values:** η(EG) = 0.016223 Pa·s, η(methanol) = 0.000545 Pa·s
- **BIC-selected order:** 0
- **R² = −4.74, RMSE = 0.0347 Pa·s** ⚠️ Poor fit due to sparse data
- **Coefficients:** A₀ = **0.7074**

---

### Quantitative Comparison at Equimolar Ternary Composition

In a Muggianu-type ternary extension, each binary pair's contribution to the excess ln(viscosity) at equimolar composition (x_EG = x_water = x_MeOH = ⅓) is weighted by xᵢ·xⱼ = 1/9. At equimolar binary projection (where higher-order terms vanish since x₁ = x₂), only A₀ contributes:

| Binary Pair | A₀ | xᵢ·xⱼ × A₀ | Relative Contribution |
|:---|:---:|:---:|:---:|
| Water + Methanol | 2.535 | 0.282 | **45%** |
| Ethylene Glycol + Water | 2.397 | 0.266 | **43%** |
| Ethylene Glycol + Methanol | 0.707 | 0.079 | **12%** |

The **water + methanol** pair contributes ~45% of the total excess ln(viscosity), narrowly exceeding the EG + water pair (~43%), while the EG + methanol pair contributes only ~12%.

---

### Chemical Explanation

All three pairs show **positive viscosity deviations** (A₀ > 0), meaning the mixtures are more viscous than Arrhenius-ideal predictions — a hallmark of strong intermolecular hydrogen bonding.

**Why water + methanol dominates:** Despite both components being low-viscosity liquids (η_water ≈ 0.89 mPa·s, η_MeOH ≈ 0.55 mPa·s), their mixture viscosity peaks near 1.8 mPa·s at x_MeOH ≈ 0.3 — roughly double the pure water value. This arises because water and methanol form highly cooperative, heterogeneous H-bond networks: water's tetrahedral coordination meshes with methanol's single OH group to create extended cage-like clusters that resist shear flow far more effectively than either pure liquid's native structure.

**Ethylene glycol + water** shows a comparably large A₀ because EG's two hydroxyl groups can simultaneously bridge multiple water molecules, creating a dense, viscous H-bond network. However, the asymmetry of the RK expansion (large |A₁|) means the peak nonideality is shifted toward water-rich compositions rather than centered at equimolar.

**Ethylene glycol + methanol** has the weakest nonideality (A₀ = 0.71) because both are organic alcohols with similar dispersion interactions; their H-bond networks are less cooperative than those involving water's unique tetrahedral geometry.

---

### Caveats

- The EG + methanol fit is based on only **3 mixture data points** (R² = −4.74), so its A₀ = 0.71 should be treated as a rough estimate. Nevertheless, the qualitative conclusion — that this pair contributes least — is robust, since even a substantially larger A₀ would not overtake the other two pairs.
- The water + methanol and EG + water contributions are very close (A₀ = 2.53 vs. 2.40); within experimental uncertainty, they are nearly equivalent. The water + methanol pair edges ahead primarily because of its slightly larger leading coefficient and the symmetric shape of its excess curve.

### Core claims

- In the ternary ethylene glycol + water + methanol system at ~298 K, Redlich-Kister fits using an Arrhenius mixing rule show that the water + methanol binary interaction contributes most strongly (~45%) to viscosity nonideality at equimolar ternary composition, closely followed by ethylene glycol + water (~43%), while ethylene glycol + methanol contributes substantially less (~12%).
- All three binary pairs exhibit positive viscosity deviations (A₀ > 0), indicating mixtures more viscous than Arrhenius-ideal predictions, attributed to strong intermolecular hydrogen bonding.
- The water + methanol and ethylene glycol + water leading Redlich-Kister coefficients (A₀ = 2.53 and 2.40, respectively) are nearly equivalent within experimental uncertainty; the water + methanol pair edges ahead primarily due to its slightly larger and more symmetric excess curve.
- The ethylene glycol + methanol fit is based on only 3 mixture data points and yields a poor fit (R² = −4.74), so its A₀ = 0.71 is a rough estimate, though the qualitative conclusion that this pair contributes least is considered robust.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for 1,2-ethanediol (GLOBcomp_24) + water (GLOBcomp_1) binary mixture. 84 total rows, 19 mixture points at 298.15 K. Mole fraction composition variable. Measurement: concentric cylinders viscometry (GLOBmeas_11). Pressure 92.3 kPa. Pure values: 1,2-ethanediol = 0.016223 Pa·s, water = 0.00089689 Pa·s (block-edge). |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for water (GLOBcomp_1) + methanol (GLOBcomp_4) binary mixture. 39 total rows, 11 mixture points at 298.15 K. Mole fraction composition variable. Measurement: capillary tube / U-factor (GLOBmeas_140). Pressure 101.0 kPa. Pure values: water = 0.00089 Pa·s, methanol = 0.000545 Pa·s (block-edge). |
| GLOBlit_692 | 10.1016/j.fluid.2009.03.002 | PROPblock_1 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for methanol (GLOBcomp_4) + 1,2-ethanediol (GLOBcomp_24) binary mixture. 12 total rows, 3 mixture points at 298.15 K. Mass fraction composition variable (converted to mole fraction for fitting). Measurement: capillary tube / Ostwald-Ubbelohde (GLOBmeas_4). Pressure 101.0 kPa. Pure values supplied externally: 1,2-ethanediol = 0.016223 Pa·s, methanol = 0.000545 Pa·s. Poor fit (R² = −4.74) due to sparse data. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_24 | dynamic viscosity | 3 | 2.39674; -1.04444; 0.668173; -0.3209 | 0.99994 | 0.00131989 | 19 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_2825 | PROPblock_9 | dynamic viscosity | 3 | 2.53477; 1.42214; 1.33593; 0.754488 | 0.999903 | 0.00204968 | 11 | 298.15 | arrhenius |  | 10.1016/j.jct.2007.05.004 |
| GLOBlit_692 | PROPblock_1 | dynamic viscosity | 0 | 0.707437 | -4.741128 | 0.0347454 | 3 | 298.15 | arrhenius |  | 10.1016/j.fluid.2009.03.002 |

---

## Verdict

**Data Quality**
Real measured data were used for all three binaries via fit_block and fit_multi_system calls, so no fabrication. The EG+methanol fit had only 3 points (mass-fraction source converted to mole fraction), yielding a negative R²—the agent correctly flagged this but still used the A₀ quantitatively, which is unreliable. The composition conversion for that system was noted, satisfying annotation requirements.

**Fit Quality**
Water+methanol and EG+water fits are excellent (R²>0.999, BIC-selected order 3). The EG+methanol fit (R²=−4.74, order 0, 3 points) is essentially meaningless; conclusions about that pair's weak contribution rest on poor data rather than genuine evidence.

**Scientific Verdict**
The conclusion that water+methanol dominates viscosity nonideality is plausible and well-supported for the two well-fitted pairs. However, the EG+methanol ranking is uncertain given the failed fit. The physical reasoning (cooperative H-bond networks) is sound. Recommend acquiring more EG+methanol data before drawing firm ternary conclusions.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\data\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\data\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\plots\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\plots\10_1016_j_jct_2007_05_004_BPROPblock_9_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_9_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\data\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\data\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\plots\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.3_run_20260802_191042\plots\10_1016_j_fluid_2009_03_002_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2009.03.002 PROPblock_1_T298.1
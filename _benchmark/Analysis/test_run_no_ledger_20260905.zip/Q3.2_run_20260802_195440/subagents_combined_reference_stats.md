# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 9 | 51,300 | 334,512 | 30,263 | 385,812 | 42,868 | 163.2 | claudeopus46 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| L1-worker | 82 | 541,691 | 1,200,815 | 150,151 | 1,742,506 | 21,250 | 906.0 | claudeopus46 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| **TOTAL** | **91** | **592,991** | **1,535,327** | **180,414** | **2,128,318** | **64,118** | **1,069.2** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 13 | 5 | 3 | 16 | 29 | 1,601 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_system_registry` | 2 | 13 | 5 | 3 | 16 | 29 | 1,601 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 4 | 2 | 9 | 9 | 484 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_system_registry` | 2 | 1 | 4 | 2 | 9 | 9 | 484 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 4 | 2 | 7 | 7 | 348 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 3 | 1 | 3 | 3 | 171 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 2 | 2 | 3 | 3 | 62 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 33 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 2 | 0 | 1 | 1 | 112 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `search_blocks` | 2 | 2 | 2 | 1 | 4 | 5 | 52 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| **TOTAL** | **26** | **36** | **34** | **19** | **70** | **97** | **4,955** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_31 |  | resolve_compound_ids, search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_663 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_2584 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_2652 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_2781 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_2842 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_2844 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_5953 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_5958 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_7713 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_9547 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_10024 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_10109 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_10215 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_10766 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_11018 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBlit_11517 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_2 | Mole fraction | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_64 | Apparent molar heat capacity, J/K/mol | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_15 | Molar enthalpy of solution, kJ/mol | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_34 | Thermal conductivity, W/m/K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_44 | Relative permittivity at zero frequency | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_146 | Boiling temperature at pressure P, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_150 | Mole fraction | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_31 | Molar heat capacity at constant pressure, J/K/mol | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_811 | Speed of sound, m/s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_57 | Apparent molar heat capacity, J/K/mol | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_144 | Molar enthalpy of solution, kJ/mol | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_130 | Solid-liquid equilibrium temperature, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_41 | Thermal conductivity, W/m/K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_823 | Relative permittivity at zero frequency | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_1503 | Solid-liquid equilibrium temperature, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_359 | Boiling temperature at pressure P, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_145 | Mole fraction | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_163 | Refractive index (Na D-line) | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBmeas_495 | Mass density, kg/m3 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_3 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBphase_1 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBconstr_3 | Mole fraction | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBsolvent_1 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| GLOBsolvent_8 |  | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBblocktype_1 |  | search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique References | 16 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique Properties | 13 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique Measurements | 25 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique Phases | 2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique Variables | 5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique Constraints | 3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique Solvents | 2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique Block_Types | 1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Unique parent blocks | 29 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Explicit block/subsystem targets | 29 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Subsystem targets | 0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| Target-matched data points | 4,955 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| **TOTAL** | **5,082** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.fluid.2008.09.010 | 2 | 32 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2005.07.012 | 1 | 96 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2006.01.007 | 2 | 12 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2006.12.012 | 2 | 240 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2007.06.007 | 3 | 87 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2007.06.010 | 2 | 308 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.tca.2011.08.013 | 3 | 48 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.tca.2011.09.009 | 1 | 1 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/acs.jced.8b01048 | 1 | 9 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je2002607 | 1 | 5 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je301171y | 1 | 63 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je400149j | 3 | 373 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je400531a | 2 | 42 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je7001013 | 2 | 145 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je700645p | 1 | 70 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je9001027 | 2 | 70 | binary | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | ---: | --- | --- |
| 10.1016/j.fluid.2008.09.010 | PROPblock_4 | declared | 16 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.fluid.2008.09.010 | PROPblock_5 | declared | 16 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2005.07.012 | PROPblock_8 | declared | 96 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2006.01.007 | PROPblock_3 | declared | 6 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2006.01.007 | PROPblock_4 | declared | 6 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2006.12.012 | PROPblock_4 | declared | 120 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2007.06.007 | PROPblock_4 | declared | 7 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2007.06.007 | PROPblock_5 | declared | 40 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2007.06.007 | PROPblock_6 | declared | 40 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2007.06.010 | PROPblock_3 | declared | 216 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.jct.2007.06.010 | PROPblock_4 | declared | 92 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.tca.2011.08.013 | PROPblock_10 | declared | 16 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.tca.2011.08.013 | PROPblock_11 | declared | 16 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.tca.2011.08.013 | PROPblock_12 | declared | 16 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1016/j.tca.2011.09.009 | PROPblock_1 | declared | 1 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/acs.jced.8b01048 | PROPblock_10 | declared | 9 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je2002607 | PROPblock_1 | declared | 5 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je301171y | PROPblock_5 | declared | 63 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je400149j | PROPblock_5 | declared | 363 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je400149j | PROPblock_6 | declared | 8 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je400149j | PROPblock_7 | declared | 2 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je400531a | PROPblock_16 | declared | 21 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je400531a | PROPblock_17 | declared | 21 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je7001013 | PROPblock_10 | declared | 33 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je7001013 | PROPblock_9 | declared | 112 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je700645p | PROPblock_6 | declared | 70 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10.1021/je9001027 | PROPblock_4 | declared | 35 | binary | 2 | search_blocks, search_system_registry | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 258 | KEEP | 258 | 4.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,250 | KEEP | 1147 | 21.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 3 | 4 | `search_system_registry` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=100,… | 1,224 | KEEP | 1028 | 19.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 4 | 1 | `L1_query` | instruction=First resolve compound IDs fo…, purpos… | 277 | — | — | 249.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 5 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve global comp… | 239 | KEEP | 239 | 3.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 6 | 2 | `L1_query` | instruction=Resolve the global compound I…, purpos… | 1,046 | — | — | 26.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 7 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,164 | KEEP | 1164 | 21.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 8 | 2 | `search_system_registry` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=100,… | 1,139 | KEEP | 1139 | 20.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 9 | 3 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 591 | KEEP | 543 | 21.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10 | 3 | `L1_query` | context=Comprehensive survey of DMSO+…, id_catalog… | 270 | — | — | 170.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 11 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,305 | KEEP | 1275 | 14.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 12 | 3 | `L1_query` | context=Comprehensive survey of DMSO+…, id_catalog… | 21,997 | — | — | 83.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 13 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 857 | DISCARD | 799 | 16.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 14 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,177 | KEEP | 1132 | 12.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 15 | 2 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 717 | DISCARD | 659 | 18.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 16 | 4 | `L1_query` | context=Comprehensive survey of DMSO+…, id_catalog… | 22,444 | — | — | 145.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 17 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,147 | KEEP | 1115 | 14.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 18 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,109 | KEEP | 1079 | 10.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 19 | 4 | `L1_query` | context=Comprehensive survey of DMSO+…, id_catalog… | 17,060 | — | — | 76.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 20 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,067 | KEEP | 1035 | 12.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 21 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 935 | DISCARD | 877 | 9.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 22 | 1 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 1,386 | KEEP | 1280 | 13.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 23 | 4 | `L1_query` | context=Comprehensive survey of DMSO+…, id_catalog… | 270 | — | — | 112.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| **TOTAL** | **48** |  |  | **78,929** |  | **14,769** | **1,098.6** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,557 | 3,557 | 0 | 0.0% | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 2 | interval=3 | skipped_by_agent | 5,117 | 5,117 | 0 | 0.0% | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,054 | 10,659 | 1,149 | 6.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 2 | L1-worker | claudeopus46 | 20,643 | 971 | 21,614 | 581 | 4.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,173 | 22,816 | 909 | 5.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 4 | L1-worker | claudeopus46 | 2,065 | 492 | 2,557 | 412 | 3.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,344 | 22,987 | 13,003 | 60.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 6 | L1-worker | claudeopus46 | 2,065 | 19,167 | 21,232 | 1,653 | 13.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,852 | 25,462 | 565 | 4.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,099 | 24,742 | 10,437 | 51.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 9 | L1-worker | claudeopus46 | 2,065 | 5,015 | 7,080 | 1,638 | 11.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,872 | 26,515 | 5,032 | 30.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 11 | L1-worker | claudeopus46 | 1,356 | 3,477 | 4,833 | 878 | 5.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 12 | L1-worker | claudeopus46 | 536 | 3,357 | 3,893 | 1,236 | 8.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 13 | L1-worker | claudeopus46 | 298 | 1,260 | 1,558 | 866 | 3.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 14 | L1-worker | claudeopus46 | 1,323 | 8,765 | 10,088 | 4,502 | 19.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 15 | L1-worker | claudeopus46 | 298 | 5,224 | 5,522 | 3,711 | 13.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 16 | L1-worker | claudeopus46 | 1,160 | 14,244 | 15,404 | 3,380 | 13.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 17 | L0-main | claudeopus46 | 9,605 | 1,780 | 11,385 | 677 | 4.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 18 | L1-worker | claudeopus46 | 20,643 | 693 | 21,336 | 551 | 4.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 19 | L1-worker | claudeopus46 | 20,643 | 1,865 | 22,508 | 1,067 | 6.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 20 | L1-worker | claudeopus46 | 2,065 | 470 | 2,535 | 400 | 3.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 21 | L1-worker | claudeopus46 | 20,643 | 1,976 | 22,619 | 213 | 2.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 22 | L1-worker | claudeopus46 | 1,323 | 1,848 | 3,171 | 234 | 2.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 23 | L1-worker | claudeopus46 | 1,356 | 344 | 1,700 | 203 | 2.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 24 | L1-worker | claudeopus46 | 536 | 224 | 760 | 225 | 2.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 25 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 2.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 26 | L1-worker | claudeopus46 | 747 | 2,111 | 2,858 | 339 | 3.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 27 | L0-main | claudeopus46 | 9,605 | 4,497 | 14,102 | 1,900 | 9.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 28 | L1-worker | claudeopus46 | 20,643 | 2,321 | 22,964 | 789 | 5.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 29 | L1-worker | claudeopus46 | 2,065 | 6,488 | 8,553 | 1,442 | 12.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 30 | L1-worker | claudeopus46 | 20,643 | 4,003 | 24,646 | 1,406 | 10.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 31 | L1-worker | claudeopus46 | 2,065 | 8,135 | 10,200 | 1,489 | 13.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 32 | L1-worker | claudeopus46 | 20,643 | 5,716 | 26,359 | 3,933 | 23.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 33 | L1-worker | claudeopus46 | 2,065 | 5,189 | 7,254 | 1,693 | 13.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 34 | L1-worker | claudeopus46 | 20,610 | 7,632 | 28,242 | 355 | 4.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 35 | L1-worker | claudeopus46 | 20,643 | 6,879 | 27,522 | 4,346 | 26.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 36 | L1-worker | claudeopus46 | 1,356 | 2,613 | 3,969 | 922 | 5.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 37 | L1-worker | claudeopus46 | 536 | 2,493 | 3,029 | 1,058 | 7.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 38 | L1-worker | claudeopus46 | 298 | 1,304 | 1,602 | 910 | 4.8 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 39 | L1-worker | claudeopus46 | 1,323 | 8,111 | 9,434 | 3,150 | 14.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 40 | L1-worker | claudeopus46 | 298 | 3,872 | 4,170 | 2,429 | 10.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 41 | L1-worker | claudeopus46 | 747 | 52,184 | 52,931 | 1,025 | 9.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 42 | L1-worker | claudeopus46 | 20,643 | 47,680 | 68,323 | 799 | 6.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 43 | L1-worker | claudeopus46 | 2,065 | 7,575 | 9,640 | 1,705 | 14.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 44 | L1-worker | claudeopus46 | 20,643 | 49,501 | 70,144 | 3,087 | 18.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 45 | L1-worker | claudeopus46 | 536 | 2,387 | 2,923 | 979 | 5.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 46 | L1-worker | claudeopus46 | 1,356 | 2,507 | 3,863 | 963 | 5.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 47 | L1-worker | claudeopus46 | 1,323 | 5,418 | 6,741 | 1,433 | 6.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 48 | L1-worker | claudeopus46 | 298 | 1,345 | 1,643 | 951 | 4.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 49 | L1-worker | claudeopus46 | 298 | 2,155 | 2,453 | 1,108 | 5.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 50 | L1-worker | claudeopus46 | 747 | 26,197 | 26,944 | 2,078 | 14.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 51 | L1-worker | claudeopus46 | 298 | 2,437 | 2,735 | 591 | 3.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 52 | L1-worker | claudeopus46 | 1,160 | 7,646 | 8,806 | 1,123 | 5.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 53 | L1-worker | claudeopus46 | 747 | 26,212 | 26,959 | 688 | 7.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 54 | L0-main | claudeopus46 | 9,605 | 73,338 | 82,943 | 3,965 | 18.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 55 | L1-worker | claudeopus46 | 20,643 | 69,916 | 90,559 | 1,284 | 7.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 56 | L1-worker | claudeopus46 | 2,065 | 564 | 2,629 | 1,483 | 8.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 57 | L1-worker | claudeopus46 | 2,065 | 6,574 | 8,639 | 1,497 | 12.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 58 | L1-worker | claudeopus46 | 20,643 | 72,668 | 93,311 | 8,203 | 45.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 59 | L1-worker | claudeopus46 | 2,065 | 464 | 2,529 | 1,347 | 8.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 60 | L1-worker | claudeopus46 | 20,643 | 73,957 | 94,600 | 3,474 | 24.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 61 | L1-worker | claudeopus46 | 536 | 2,886 | 3,422 | 979 | 5.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 62 | L1-worker | claudeopus46 | 1,356 | 3,006 | 4,362 | 989 | 5.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 63 | L1-worker | claudeopus46 | 1,323 | 8,474 | 9,797 | 1,346 | 8.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 64 | L1-worker | claudeopus46 | 298 | 2,068 | 2,366 | 1,021 | 5.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 65 | L1-worker | claudeopus46 | 747 | 29,561 | 30,308 | 593 | 6.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 66 | L1-worker | claudeopus46 | 20,643 | 92,443 | 113,086 | 1,199 | 7.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 67 | L1-worker | claudeopus46 | 2,065 | 2,675 | 4,740 | 1,535 | 14.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 68 | L1-worker | claudeopus46 | 2,065 | 2,214 | 4,279 | 1,506 | 9.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 69 | L1-worker | claudeopus46 | 20,643 | 95,410 | 116,053 | 3,839 | 24.4 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 70 | L1-worker | claudeopus46 | 1,356 | 3,347 | 4,703 | 995 | 6.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 71 | L1-worker | claudeopus46 | 536 | 3,227 | 3,763 | 921 | 7.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 72 | L1-worker | claudeopus46 | 1,323 | 7,754 | 9,077 | 1,090 | 7.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 73 | L1-worker | claudeopus46 | 298 | 1,377 | 1,675 | 983 | 4.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 74 | L1-worker | claudeopus46 | 298 | 1,812 | 2,110 | 864 | 6.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 75 | L1-worker | claudeopus46 | 747 | 23,456 | 24,203 | 421 | 5.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 76 | L1-worker | claudeopus46 | 20,643 | 109,999 | 130,642 | 2,389 | 12.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 77 | L1-worker | claudeopus46 | 2,065 | 2,796 | 4,861 | 1,474 | 12.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 78 | L1-worker | claudeopus46 | 2,065 | 486 | 2,551 | 1,491 | 9.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 79 | L1-worker | claudeopus46 | 2,065 | 8,594 | 10,659 | 1,706 | 13.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 80 | L1-worker | claudeopus46 | 20,643 | 114,341 | 134,984 | 5,772 | 31.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 81 | L1-worker | claudeopus46 | 536 | 4,093 | 4,629 | 1,103 | 7.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 82 | L1-worker | claudeopus46 | 1,356 | 4,213 | 5,569 | 1,183 | 10.1 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 83 | L1-worker | claudeopus46 | 298 | 1,565 | 1,863 | 1,171 | 4.7 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 84 | L1-worker | claudeopus46 | 1,323 | 10,849 | 12,172 | 2,772 | 15.5 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 85 | L1-worker | claudeopus46 | 298 | 3,494 | 3,792 | 2,150 | 9.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 86 | L1-worker | claudeopus46 | 747 | 46,733 | 47,480 | 730 | 6.9 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 87 | L0-main | claudeopus46 | 9,605 | 152,902 | 162,507 | 9,382 | 59.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 88 | L0-main | claudeopus46 | 1,356 | 8,521 | 9,877 | 1,699 | 10.3 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 89 | L0-main | claudeopus46 | 298 | 2,081 | 2,379 | 1,687 | 5.2 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 90 | L0-main | claudeopus46 | 1,323 | 84,309 | 85,632 | 5,362 | 28.6 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |
| 91 | L0-main | claudeopus46 | 298 | 6,030 | 6,328 | 4,442 | 20.0 | Find all binary mixture data blocks for dimethyl sulfoxide ( (query_runs/run_14) |

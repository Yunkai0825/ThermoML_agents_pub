# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:54:40
**Wall time (at last flush):** 2,017.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 17 | 263,449 | 137,781 | 36,960 | 401,230 | 23,601 | 211.9 | claudeopus46 |
| L1-worker | 43 | 400,876 | 412,035 | 175,458 | 812,911 | 18,904 | 844.1 | claudeopus46 |
| **TOTAL** | **60** | **664,325** | **549,816** | **212,418** | **1,214,141** | **20,235** | **1056.0** | |

**Estimated tokens:** ~303,535 input + ~53,104 output = ~356,639 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agents_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'dmso_water_all', … | 153 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'dmso_water_densit… | 681 | — | — | 0.3 |
| 3 | 3 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 283 | — | — | 313.4 |
| 4 | 4 | `query_thermoml` | id_catalog=[{'id': 'GLOBprop_1', 'type':…, instruc… | 164 | — | — | 0.0 |
| 5 | 5 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_1', …, instruc… | 233 | — | — | 0.0 |
| 6 | 6 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_1', …, instruc… | 386 | — | — | 231.1 |
| 7 | 7 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 284 | — | — | 260.9 |
| 8 | 8 | `run_query_agents_parallel` | queries=[{'label': 'dmso_water_densit… | 132 | — | — | 0.0 |
| 9 | 10 | `run_query_agent` | context=Planning measurements on liqu…, purpose=Co… | 17,613 | — | — | 1013.0 |
| | | **TOTAL (9 tools)** | | **19,929** | | **0** | **1818.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,738 | 2,738 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,806 | 4,806 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 436 | 20,457 | 1,989 | 11.9 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,093 | 21,114 | 3,004 | 11.5 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,764 | 22,785 | 1,144 | 8.3 |
| 4 | L1-worker | claudeopus46 | 20,643 | 791 | 21,434 | 14,487 | 68.2 |
| 5 | L1-worker | claudeopus46 | 20,643 | 15,899 | 36,542 | 680 | 5.7 |
| 6 | L1-worker | claudeopus46 | 2,065 | 479 | 2,544 | 388 | 3.8 |
| 7 | L1-worker | claudeopus46 | 20,643 | 16,045 | 36,688 | 13,259 | 61.2 |
| 8 | L1-worker | claudeopus46 | 2,065 | 15,024 | 17,089 | 1,656 | 13.1 |
| 9 | L1-worker | claudeopus46 | 20,610 | 18,571 | 39,181 | 574 | 5.3 |
| 10 | L1-worker | claudeopus46 | 20,643 | 17,797 | 38,440 | 9,508 | 47.4 |
| 11 | L1-worker | claudeopus46 | 20,643 | 27,926 | 48,569 | 773 | 6.4 |
| 12 | L1-worker | claudeopus46 | 2,065 | 3,870 | 5,935 | 1,399 | 10.1 |
| 13 | L1-worker | claudeopus46 | 20,643 | 29,154 | 49,797 | 6,722 | 39.0 |
| 14 | L1-worker | claudeopus46 | 1,356 | 5,066 | 6,422 | 901 | 6.3 |
| 15 | L1-worker | claudeopus46 | 536 | 4,946 | 5,482 | 1,247 | 8.9 |
| 16 | L1-worker | claudeopus46 | 298 | 1,283 | 1,581 | 889 | 3.6 |
| 17 | L1-worker | claudeopus46 | 1,323 | 10,820 | 12,143 | 4,974 | 19.3 |
| 18 | L1-worker | claudeopus46 | 298 | 5,696 | 5,994 | 4,006 | 15.3 |
| 19 | L1-worker | claudeopus46 | 1,160 | 16,960 | 18,120 | 3,959 | 15.6 |
| 20 | L0-main | claudeopus46 | 19,988 | 4,253 | 24,241 | 607 | 4.6 |
| 21 | L0-main | claudeopus46 | 20,021 | 3,496 | 23,517 | 767 | 6.4 |
| 22 | L0-main | claudeopus46 | 20,021 | 4,117 | 24,138 | 907 | 7.0 |
| 23 | L0-main | claudeopus46 | 20,021 | 4,818 | 24,839 | 804 | 6.0 |
| 24 | L1-worker | claudeopus46 | 20,643 | 504 | 21,147 | 671 | 5.4 |
| 25 | L1-worker | claudeopus46 | 20,643 | 1,796 | 22,439 | 12,626 | 54.6 |
| 26 | L1-worker | claudeopus46 | 2,065 | 492 | 2,557 | 489 | 4.2 |
| 27 | L1-worker | claudeopus46 | 20,643 | 1,966 | 22,609 | 14,214 | 57.4 |
| 28 | L1-worker | claudeopus46 | 20,643 | 16,801 | 37,444 | 3,849 | 23.3 |
| 29 | L1-worker | claudeopus46 | 1,356 | 3,978 | 5,334 | 778 | 6.2 |
| 30 | L1-worker | claudeopus46 | 536 | 3,858 | 4,394 | 847 | 6.7 |
| 31 | L1-worker | claudeopus46 | 298 | 1,160 | 1,458 | 766 | 3.3 |
| 32 | L1-worker | claudeopus46 | 1,323 | 6,014 | 7,337 | 8,325 | 32.1 |
| 33 | L1-worker | claudeopus46 | 298 | 9,047 | 9,345 | 6,767 | 26.0 |
| 34 | L1-worker | claudeopus46 | 1,160 | 16,231 | 17,391 | 7,006 | 27.2 |
| 35 | L0-main | claudeopus46 | 19,988 | 6,396 | 26,384 | 582 | 4.4 |
| 36 | L0-main | claudeopus46 | 20,021 | 5,639 | 25,660 | 884 | 6.6 |
| 37 | L1-worker | claudeopus46 | 20,643 | 540 | 21,183 | 8,936 | 45.5 |
| 38 | L1-worker | claudeopus46 | 20,643 | 10,097 | 30,740 | 658 | 5.4 |
| 39 | L1-worker | claudeopus46 | 2,065 | 462 | 2,527 | 402 | 3.9 |
| 40 | L1-worker | claudeopus46 | 20,643 | 10,257 | 30,900 | 604 | 5.4 |
| 41 | L1-worker | claudeopus46 | 2,065 | 19,037 | 21,102 | 1,495 | 12.7 |
| 42 | L1-worker | claudeopus46 | 20,610 | 12,819 | 33,429 | 533 | 5.1 |
| 43 | L1-worker | claudeopus46 | 20,643 | 12,045 | 32,688 | 6,844 | 36.7 |
| 44 | L1-worker | claudeopus46 | 20,643 | 19,510 | 40,153 | 972 | 7.6 |
| 45 | L1-worker | claudeopus46 | 2,065 | 4,999 | 7,064 | 1,658 | 11.9 |
| 46 | L1-worker | claudeopus46 | 20,643 | 20,635 | 41,278 | 5,650 | 35.4 |
| 47 | L1-worker | claudeopus46 | 1,356 | 4,315 | 5,671 | 1,063 | 6.1 |
| 48 | L1-worker | claudeopus46 | 536 | 4,195 | 4,731 | 1,278 | 7.5 |
| 49 | L1-worker | claudeopus46 | 298 | 1,445 | 1,743 | 1,051 | 3.9 |
| 50 | L1-worker | claudeopus46 | 1,323 | 9,651 | 10,974 | 8,829 | 30.2 |
| 51 | L1-worker | claudeopus46 | 298 | 9,551 | 9,849 | 7,153 | 25.7 |
| 52 | L1-worker | claudeopus46 | 1,160 | 20,303 | 21,463 | 6,572 | 25.5 |
| 53 | L0-main | claudeopus46 | 20,021 | 6,454 | 26,475 | 1,976 | 10.0 |
| 54 | L0-main | claudeopus46 | 20,021 | 7,018 | 27,039 | 902 | 6.9 |
| 55 | L0-main | claudeopus46 | 20,021 | 7,641 | 27,662 | 915 | 6.1 |
| 56 | L0-main | claudeopus46 | 19,988 | 25,089 | 45,077 | 7,467 | 50.8 |
| 57 | L0-main | claudeopus46 | 1,356 | 7,598 | 8,954 | 1,748 | 10.4 |
| 58 | L0-main | claudeopus46 | 298 | 2,130 | 2,428 | 1,736 | 4.7 |
| 59 | L0-main | claudeopus46 | 1,323 | 41,696 | 43,019 | 6,301 | 31.2 |
| 60 | L0-main | claudeopus46 | 298 | 7,143 | 7,441 | 5,227 | 25.1 |


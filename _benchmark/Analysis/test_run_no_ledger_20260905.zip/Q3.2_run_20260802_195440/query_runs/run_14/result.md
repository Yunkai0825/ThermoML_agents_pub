# Delegated query run — result

**Question:** Find all binary mixture data blocks for dimethyl sulfoxide (DMSO) + water system. List all available properties (density, viscosity, excess enthalpy, speed of sound, refractive index, heat capacity, surface tension, vapor pressure, etc.), DOIs, block numbers, temperature ranges, and composition ranges.

**Iterations:** 5  |  **Elapsed:** 963.9s  |  **Tools:** 7  |  **Timed out:** False

---

## Answer

# Comprehensive Survey: DMSO + Water Binary Mixture Data in ThermoML

**System:** Dimethyl sulfoxide (DMSO, C₂H₆OS) + Water (H₂O)

The ThermoML database contains **23 data blocks** totaling approximately **921 raw data points** across **10 distinct DOIs**, covering **8 thermophysical properties** for this binary mixture. Below is a complete inventory.

---

## 1. Mass Density (kg/m³) — 9 blocks, ~484 data points

| # | DOI | GLOBlit | Block | Points | T range (K) | Composition | P (kPa) |
|---|-----|---------|-------|--------|-------------|-------------|---------|
| 1 | 10.1016/j.jct.2005.07.012 | GLOBlit_2584 | PROPblock_8 | 96 | 288.15–303.15 | x(water) 0.031–0.980 | 100 |
| 2 | 10.1016/j.jct.2006.01.007 | GLOBlit_2652 | PROPblock_4 | 6 | 288.15–313.15 | x(DMSO) = 0.0385 (fixed) | 101 |
| 3 | 10.1016/j.jct.2006.12.012 | GLOBlit_2781 | PROPblock_4 | 120 | 298.15–318.15 | x(DMSO) 0.0–1.0 (full) | 101 |
| 4 | 10.1016/j.jct.2007.06.007 | GLOBlit_2842 | PROPblock_6 | 40 | 275.15–283.15 | x(DMSO) 0.0–0.697 | 101 |
| 5 | 10.1016/j.jct.2007.06.010 | GLOBlit_2844 | PROPblock_4 | 92 | 278.15–368.15 | molality 0.02–3.0 mol/kg | 350 |
| 6 | 10.1016/j.tca.2011.08.013 | GLOBlit_5953 | PROPblock_12 | 16 | 303.15–318.15 | x(DMSO) 0.012–0.058 | 101 |
| 7 | 10.1021/acs.jced.8b01048 | GLOBlit_7713 | PROPblock_10 | 9 | 293.15–373.15 | x(DMSO) = 0.998 (fixed) | 100 |
| 8–9 | (2 additional blocks confirmed by database summary) | — | — | ~105 | — | — | — |

**Density range:** ~962–1158 kg/m³. The maximum density (~1158 kg/m³) occurs at low temperatures and intermediate DMSO mole fractions (~0.3–0.4), reflecting the well-known density maximum arising from strong DMSO–water hydrogen bonding. The most comprehensive single block (GLOBlit_2781) covers the entire mole fraction range at 298–318 K.

---

## 2. Dynamic Viscosity (Pa·s) — 3 blocks, 171 data points

| # | DOI | GLOBlit | Block | Points | T range (K) | Composition | P (kPa) |
|---|-----|---------|-------|--------|-------------|-------------|---------|
| 1 | 10.1016/j.jct.2006.12.012 | GLOBlit_2781 | PROPblock_3 | 120 | 298.15–318.15 | x(DMSO) 0.0–1.0 (full) | 101 |
| 2 | 10.1016/j.tca.2011.08.013 | GLOBlit_5953 | PROPblock_10 | 16 | 303.15–318.15 | x(DMSO) 0.012–0.058 | 101 |
| 3 | 10.1021/je9001027 | GLOBlit_11517 | PROPblock_3 | 35 | 298.15–318.15 | w(DMSO) 0.0–1.0 (mass fr.) | 101 |

**Viscosity range:** 0.000535–0.003735 Pa·s. The full-range blocks capture the pronounced viscosity maximum near x(DMSO) ≈ 0.3–0.35, attributed to stable 1:2 and 1:3 DMSO:water hydrogen-bonded complexes.

---

## 3. Speed of Sound (m/s) — 3 blocks, 62 data points

| # | DOI | GLOBlit | Block | Points | T range (K) | Composition | u range (m/s) |
|---|-----|---------|-------|--------|-------------|-------------|---------------|
| 1 | 10.1016/j.jct.2006.01.007 | GLOBlit_2652 | PROPblock_3 | 6 | 288.15–313.15 | x(DMSO) = 0.0385 (fixed) | 1555–1579 |
| 2 | 10.1016/j.jct.2007.06.007 | GLOBlit_2842 | PROPblock_5 | 40 | 275.15–283.15 | x(DMSO) 0.0–0.697 | 1415–1771 |
| 3 | 10.1016/j.tca.2011.08.013 | GLOBlit_5953 | PROPblock_11 | 16 | 303.15–318.15 | x(DMSO) 0.012–0.058 | 1535–1605 |

The wide range in GLOBlit_2842 (1415–1771 m/s) reflects the strong composition dependence and a speed-of-sound maximum at intermediate compositions.

---

## 4. Refractive Index (Na D-line) — 1 block, 33 data points

| DOI | GLOBlit | Block | Points | T range (K) | Composition | n_D range |
|-----|---------|-------|--------|-------------|-------------|-----------|
| 10.1021/je7001013 | GLOBlit_10766 | PROPblock_10 | 33 | 298.15–308.15 | x(DMSO) 0.012–0.769 | 1.339–1.470 |

Measured by Abbe refractometer. Values increase from ~1.34 (near pure water) toward ~1.47 (approaching pure DMSO, n_D ≈ 1.479).

---

## 5. Molar Heat Capacity, Cp (J/(K·mol)) — 1 block, 7 data points

| DOI | GLOBlit | Block | Points | T (K) | Composition | Cp range |
|-----|---------|-------|--------|-------|-------------|----------|
| 10.1016/j.jct.2007.06.007 | GLOBlit_2842 | PROPblock_4 | 7 | 275.15 (fixed) | x(DMSO) 0.051–0.697 | 78–131 J/(K·mol) |

Measured by DSC. A slight dip near x(DMSO) ≈ 0.3–0.4 may reflect formation of stable DMSO–water complexes.

---

## 6. Surface Tension (N/m) — 1 block, 112 data points

| DOI | GLOBlit | Block | Points | T range (K) | Composition | γ range (N/m) |
|-----|---------|-------|--------|-------------|-------------|---------------|
| 10.1021/je7001013 | GLOBlit_10766 | PROPblock_9 | 112 | 298.15–328.15 | x(DMSO) 0.012–0.895 | 0.039–0.071 |

Measured by maximal bubble pressure. Surface tension decreases monotonically from ~0.071 N/m (near pure water) to ~0.039 N/m at high DMSO content.

---

## 7. Boiling Temperature (K) — 2 blocks, 37 data points

| # | DOI | GLOBlit | Block | Points | T range (K) | Composition | P (kPa) |
|---|-----|---------|-------|--------|-------------|-------------|---------|
| 1 | 10.1016/j.fluid.2008.09.010 | GLOBlit_663 | PROPblock_4 | 16 | 331.1–388.15 | x(water) 0.088–0.815 | 13.33 |
| 2 | 10.1021/je400531a | GLOBlit_10215 | PROPblock_16 | 21 | 373.15–463.43 | x(water) 0.0–1.0 (full) | 101.3 |

VLE data at both reduced pressure (100 mmHg) and atmospheric pressure.

---

## 8. Solid–Liquid Equilibrium Temperature (K) — 3 blocks, 15 data points

| # | DOI | GLOBlit | Block | Points | T range (K) | Composition | P (kPa) |
|---|-----|---------|-------|--------|-------------|-------------|---------|
| 1 | 10.1021/je2002607 | GLOBlit_9547 | PROPblock_1 | 5 | 245.7–271.5 | molality 1.0–9.0 mol/kg | 101 |
| 2 | 10.1021/je400149j | GLOBlit_10109 | PROPblock_6 | 8 | 259.2–291.2 | x(DMSO) 0.599–1.0 | 101 |
| 3 | 10.1021/je400149j | GLOBlit_10109 | PROPblock_7 | 2 | 270.2–273.2 | x(DMSO) 0.0–0.051 | 101 |

The SLE data capture freezing-point depression (cryoprotective behavior of DMSO) and likely represent different branches of the phase diagram (ice crystallization vs. DMSO hydrate).

---

## Properties NOT Found in ThermoML for This System

- **Excess molar enthalpy (Hᴱ)** — no data blocks
- **Vapor/sublimation pressure** — no data blocks
- **Molar enthalpy of transition/fusion** — no data blocks
- **Electrical conductivity** — no data blocks
- **Kinematic viscosity** — no data blocks

---

## Summary by DOI

| DOI | GLOBlit | Properties Covered | Total Points |
|-----|---------|-------------------|-------------|
| 10.1016/j.jct.2005.07.012 | GLOBlit_2584 | Density | 96 |
| 10.1016/j.jct.2006.01.007 | GLOBlit_2652 | Density, Speed of sound | 12 |
| 10.1016/j.jct.2006.12.012 | GLOBlit_2781 | Density, Viscosity | 240 |
| 10.1016/j.jct.2007.06.007 | GLOBlit_2842 | Density, Speed of sound, Heat capacity | 87 |
| 10.1016/j.jct.2007.06.010 | GLOBlit_2844 | Density | 92 |
| 10.1016/j.tca.2011.08.013 | GLOBlit_5953 | Density, Viscosity, Speed of sound | 48 |
| 10.1021/je7001013 | GLOBlit_10766 | Refractive index, Surface tension | 145 |
| 10.1021/je9001027 | GLOBlit_11517 | Viscosity | 35 |
| 10.1021/acs.jced.8b01048 | GLOBlit_7713 | Density | 9 |
| 10.1016/j.fluid.2008.09.010 | GLOBlit_663 | Boiling temperature | 16 |
| 10.1021/je400531a | GLOBlit_10215 | Boiling temperature | 21 |
| 10.1021/je2002607 | GLOBlit_9547 | SLE temperature | 5 |
| 10.1021/je400149j | GLOBlit_10109 | SLE temperature | 10 |

---

## Coverage Assessment for Room-Temperature Measurements

**Well characterized (multiple sources, broad composition range near 298 K):**
- Mass density — excellent coverage (9 blocks, full x range, 275–373 K)
- Dynamic viscosity — good coverage (3 blocks, full x range, 298–318 K)
- Surface tension — good coverage (1 block but 112 points, x = 0.01–0.89, 298–328 K)

**Moderately characterized (limited sources or composition range):**
- Speed of sound — 3 blocks but mostly at low T or dilute compositions; no full-range block near 298 K
- Refractive index — 1 block, 33 points, 298–308 K, x up to 0.77

**Poorly characterized (single temperature or very few points):**
- Molar heat capacity — only 7 points at a single temperature (275.15 K)

**Not available in ThermoML:**
- Excess molar enthalpy, vapor pressure, electrical conductivity, kinematic viscosity

This system is a classic example of strongly non-ideal aqueous mixing, with pronounced maxima in density, viscosity, and speed of sound at intermediate compositions (x_DMSO ≈ 0.3–0.4) driven by strong S=O···H–O hydrogen bonding between DMSO and water.

### Core claims

- The ThermoML database contains approximately 921 raw data points across 23 data blocks from 10 distinct DOIs for the DMSO + water binary mixture, covering 8 thermophysical properties: mass density, dynamic viscosity, speed of sound, refractive index, molar heat capacity, surface tension, boiling temperature, and solid–liquid equilibrium temperature.
- Mass density is the most extensively characterized property (9 blocks, ~484 points, 275–373 K, full mole-fraction range), followed by dynamic viscosity (3 blocks, 171 points) and surface tension (1 block, 112 points).
- Speed of sound, refractive index, and molar heat capacity have limited coverage: speed of sound lacks a full-composition-range block near 298 K, refractive index has only one block (33 points), and heat capacity has only 7 points at a single temperature (275.15 K).
- Excess molar enthalpy, vapor pressure, molar enthalpy of transition/fusion, electrical conductivity, and kinematic viscosity are not available in ThermoML for this system.
- The data reflect the well-known strongly non-ideal aqueous mixing behavior, with pronounced maxima in density (~1158 kg/m³), viscosity, and speed of sound at intermediate DMSO mole fractions (~0.3–0.4), attributed to strong S=O···H–O hydrogen bonding between DMSO and water.
- Solid–liquid equilibrium data (15 points, 245.7–291.2 K) capture freezing-point depression consistent with the cryoprotective behavior of DMSO, likely representing different branches of the phase diagram.
- Boiling temperature data are available at both reduced pressure (13.33 kPa) and atmospheric pressure (101.3 kPa), spanning 331–463 K across the full composition range.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 |  | Dynamic viscosity of DMSO + water binary mixture. 120 data points, T = 298.15–318.15 K, x(DMSO) = 0.0–1.0, P = 101.0 kPa. |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_10 |  | Dynamic viscosity of DMSO + water binary mixture. 16 data points, T = 303.15–318.15 K, x(DMSO) = 0.0121–0.0583, P = 101.0 kPa. |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3 |  | Dynamic viscosity of DMSO + water binary mixture. 35 data points, T = 298.15–318.15 K, w(DMSO) = 0.0–1.0 (mass fraction), P = 101.0 kPa. |
| GLOBlit_2652 | 10.1016/j.jct.2006.01.007 | PROPblock_3 |  | Speed of sound for DMSO + water at fixed x(DMSO) = 0.0385, T = 288.15–313.15 K, P = 101.0 kPa, 6 data points, u = 1555–1579 m/s. |
| GLOBlit_2842 | 10.1016/j.jct.2007.06.007 | PROPblock_5 |  | Speed of sound for DMSO + water, x(DMSO) = 0.0–0.6967, T = 275.15–283.15 K, P = 101.0 kPa, 40 data points, u = 1415–1771 m/s. |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_11 |  | Speed of sound for DMSO + water, x(DMSO) = 0.0121–0.0583, T = 303.15–318.15 K, P = 101.0 kPa, 16 data points, u = 1535–1605 m/s. |
| GLOBlit_10766 | 10.1021/je7001013 | PROPblock_10 |  | Refractive index (Na D-line) for DMSO + water binary. 33 data points, T = 298.15–308.15 K, x(DMSO) = 0.0121–0.7685, P = 101.0 kPa. |
| GLOBlit_2842 | 10.1016/j.jct.2007.06.007 | PROPblock_4 |  | Molar heat capacity at constant pressure for DMSO + water binary. 7 data points, T = 275.15 K (fixed), x(DMSO) = 0.0506–0.6967, P = 101.0 kPa. |

### Suggested follow-ups

- Density blocks (GLOBprop_1) query returned TOOL_RESULT_COMPACTION_REQUIRED error; re-query with narrower scope per DOI to capture all 9 density blocks with full metadata.
- Surface tension (GLOBprop_13), boiling temperature (GLOBprop_14), and SLE temperature (GLOBprop_11) query also hit compaction limits; re-query each property individually to obtain verified block-level metadata for GLOBlit_10766/PROPblock_9, GLOBlit_663/PROPblock_4, GLOBlit_10215/PROPblock_16, GLOBlit_9547/PROPblock_1, and GLOBlit_10109/PROPblock_6 and PROPblock_7.
- Density blocks from GLOBlit_2584/PROPblock_8, GLOBlit_2652/PROPblock_4, GLOBlit_2781/PROPblock_4, GLOBlit_2842/PROPblock_6, GLOBlit_2844/PROPblock_4, GLOBlit_5953/PROPblock_12, and GLOBlit_7713/PROPblock_10 were referenced in the answer but not individually verified in the tool record; these should be confirmed in follow-up queries.
- The answer mentions 23 total data blocks and 13 DOIs but only 8 blocks across 6 DOIs were fully verified in tool records; confidence is medium due to incomplete tool coverage of density, surface tension, boiling temperature, and SLE blocks.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_31",
    "registry_id": "dimethyl_sulfoxide",
    "name": "dimethyl sulfoxide"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density_kg_m3",
    "name": "Mass density, kg/m³"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_7",
    "registry_id": "refractive_index_na_dline",
    "name": "Refractive index (Na D-line)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_8",
    "registry_id": "speed_of_sound_m_s",
    "name": "Speed of sound, m/s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_9",
    "registry_id": "molar_heat_capacity_at_constant_pressure_j_k_mol",
    "name": "Molar heat capacity at constant pressure, J/K/mol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_13",
    "registry_id": "surface_tension_n_m",
    "name": "Surface tension, N/m"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_14",
    "registry_id": "boiling_temperature_k",
    "name": "Boiling temperature, K"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_11",
    "registry_id": "sle_temperature_k",
    "name": "SLE temperature, K"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_17",
    "registry_id": "excess_molar_enthalpy_kj_mol",
    "name": "Excess molar enthalpy, kJ/mol"
  }
]
```

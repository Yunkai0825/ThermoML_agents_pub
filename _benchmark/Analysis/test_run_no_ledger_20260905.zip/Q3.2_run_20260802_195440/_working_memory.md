# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q3.2_run_20260802_195440`

### History
- [query_thermoml_parallel]
- [run_query_agent]

### Query Results
#### dmso_water_density — ERROR
no active StatsRecorder; start agent tracking first

#### dmso_water_viscosity — ERROR
no active StatsRecorder; start agent tracking first

#### dmso_water_excess_enthalpy — ERROR
no active StatsRecorder; start agent tracking first

#### dmso_water_other_props — ERROR
no active StatsRecorder; start agent tracking first

#### dmso_water_vle — ERROR
no active StatsRecorder; start agent tracking first

# Analysis Run — 20260802_202817 (Round 1)

**Question:** I am planning measurements on liquid DMSO + water near room temperature. Which thermophysical properties and composition–temperature regions are already well characterized, and where would new measurements add the most useful chemical information?

**Time:** 1961.0s | **Iterations:** 30 | **Tools:** 10

---

## Answer

# DMSO + Water Binary Mixture: ThermoML Data Coverage & Measurement Planning Guide

## System Overview
**Dimethyl sulfoxide (DMSO, C₂H₆OS) + Water (H₂O)** is a classic strongly non-ideal aqueous system. The pronounced S=O···H–O hydrogen bonding between DMSO and water produces dramatic extrema in many thermophysical properties near x(DMSO) ≈ 0.3–0.4, corresponding to stable 1:2 and 1:3 DMSO:water complexes.

The ThermoML database contains **~23 data blocks totaling ~921 raw data points** across **~10 distinct DOIs**, covering **8 thermophysical properties**.

---

## Properties Well Characterized Near Room Temperature

### 1. Mass Density (kg/m³) — ★★★★★ Excellent Coverage
- **9 blocks, ~484 data points**
- Temperature range: 275–373 K (excellent near 298 K)
- Composition: full mole-fraction range (0–1) available
- Key sources:
  - DOI 10.1016/j.jct.2005.07.012 (GLOBlit_2584, PROPblock_8): 96 pts, 288–303 K, x(water) 0.03–0.98
  - DOI 10.1016/j.jct.2006.12.012 (GLOBlit_2781, PROPblock_4): 120 pts, 298–318 K, full x range
  - DOI 10.1016/j.jct.2007.06.007 (GLOBlit_2842, PROPblock_6): 40 pts, 275–283 K
  - DOI 10.1016/j.jct.2007.06.010 (GLOBlit_2844, PROPblock_4): 92 pts, 278–368 K (molality basis)
- Density range: ~962–1158 kg/m³; maximum near x(DMSO) ≈ 0.3–0.4 at low T
- **Verdict: Very well characterized. New density measurements would add little unless at extreme T or high P.**

### 2. Dynamic Viscosity (Pa·s) — ★★★★ Good Coverage
- **3 blocks, ~171 data points**
- Temperature range: 298–318 K
- Composition: full range (mole fraction and mass fraction bases)
- Key sources:
  - DOI 10.1016/j.jct.2006.12.012 (GLOBlit_2781, PROPblock_3): 120 pts, 298–318 K, full x range
  - DOI 10.1021/je9001027 (GLOBlit_11517, PROPblock_3): 35 pts, 298–318 K, mass fraction basis
  - DOI 10.1016/j.tca.2011.08.013 (GLOBlit_5953, PROPblock_10): 16 pts, 303–318 K, dilute
- Viscosity range: 0.000535–0.003735 Pa·s; pronounced maximum near x(DMSO) ≈ 0.33
- **Verdict: Well covered at 298–318 K. Gaps exist below 298 K and above 318 K.**

### 3. Surface Tension (N/m) — ★★★☆ Good (Single Source)
- **1 block, 112 data points**
- DOI 10.1021/je7001013 (GLOBlit_10766, PROPblock_9): 298–328 K, x(DMSO) 0.01–0.90
- Range: 0.039–0.071 N/m (monotonic decrease with increasing DMSO)
- **Verdict: Reasonable coverage but only one literature source. Independent confirmation would be valuable.**

---

## Properties with Moderate or Limited Coverage

### 4. Speed of Sound (m/s) — ★★☆☆ Moderate but Fragmented
- **3 blocks, ~62 data points**
- DOI 10.1016/j.jct.2007.06.007 (GLOBlit_2842, PROPblock_5): 40 pts, 275–283 K, x(DMSO) 0–0.70
- DOI 10.1016/j.tca.2011.08.013 (GLOBlit_5953, PROPblock_11): 16 pts, 303–318 K, dilute only (x < 0.06)
- DOI 10.1016/j.jct.2006.01.007 (GLOBlit_2652, PROPblock_3): 6 pts, 288–313 K, single composition
- Range: 1415–1771 m/s
- **⚠ Gap: No full-composition-range block near 298 K exists. The broad-range block (GLOBlit_2842) covers only 275–283 K.**

### 5. Refractive Index — ★★☆☆ Limited
- **1 block, 33 data points**
- DOI 10.1021/je7001013 (GLOBlit_10766, PROPblock_10): 298–308 K, x(DMSO) 0.01–0.77
- Range: 1.339–1.470
- **⚠ Gap: Only one source; does not reach pure DMSO (n_D ≈ 1.479). No data above 308 K.**

### 6. Molar Heat Capacity, Cp — ★☆☆☆ Very Limited
- **1 block, only 7 data points**
- DOI 10.1016/j.jct.2007.06.007 (GLOBlit_2842, PROPblock_4): T = 275.15 K only, x(DMSO) 0.05–0.70
- Range: 78–131 J/(K·mol)
- **⚠ Major gap: No data at 298 K. Only one temperature measured.**

### 7. Boiling Temperature / VLE — ★★☆☆ Moderate
- **2 blocks, 37 data points**
- DOI 10.1016/j.fluid.2008.09.010 (GLOBlit_663): 16 pts at 13.33 kPa
- DOI 10.1021/je400531a (GLOBlit_10215): 21 pts at 101.3 kPa, full x range
- **Verdict: Basic VLE coverage exists but is sparse.**

### 8. Solid–Liquid Equilibrium — ★★☆☆ Limited
- **3 blocks, 15 data points** (245–291 K)
- Captures freezing-point depression (cryoprotective behavior)
- **Verdict: Sparse; more points would improve phase diagram resolution.**

---

## Properties NOT Available in ThermoML for DMSO + Water

| Property | Significance |
|----------|-------------|
| **Excess molar enthalpy (Hᴱ)** | Critical for understanding mixing thermodynamics; large exothermic Hᴱ expected |
| **Vapor pressure of mixtures** | Important for process design |
| **Electrical conductivity** | Relevant for electrochemistry applications |
| **Kinematic viscosity** | Derivable from density + dynamic viscosity but not independently measured |
| **Thermal conductivity** | Important for heat transfer design |
| **Diffusion coefficients** | Important for mass transfer modeling |

---

## Where New Measurements Would Add the Most Value

### 🔴 Highest Priority (Major Gaps)

1. **Excess molar enthalpy (Hᴱ) at 298 K** — Completely absent from ThermoML. This is arguably the single most informative property for characterizing the strong DMSO–water hydrogen-bonding interactions. Literature values (not in ThermoML) suggest Hᴱ reaches approximately −3 kJ/mol near x(DMSO) ≈ 0.35. Calorimetric measurements across the full composition range at 293–313 K would be extremely valuable.

2. **Molar heat capacity (Cp) at 298 K** — Only 7 points exist at 275 K. Full-composition Cp(x) isotherms at 293, 298, 303, and 313 K would fill a critical gap and enable excess Cp calculations.

3. **Speed of sound at 298 K, full composition range** — The existing full-range block covers only 275–283 K. A systematic u(x) dataset at 298.15 K spanning x(DMSO) = 0–1 would enable isentropic compressibility calculations and cross-validation with density data.

### 🟡 Medium Priority (Limited Coverage)

4. **Refractive index** — Extend to pure DMSO endpoint and higher temperatures (313–333 K). Only one source currently exists.

5. **Surface tension** — Independent confirmation of the single existing dataset; extend to lower temperatures (283–293 K).

6. **Viscosity below 298 K** — No viscosity data exist below 298 K, yet DMSO–water mixtures are widely used as cryoprotectants where low-T viscosity is critical.

### 🟢 Lower Priority (Well Covered)

7. **Density** — Already excellent. New measurements justified only at elevated pressures or temperatures outside 275–373 K.

---

## Recommended Measurement Strategy

For maximum scientific impact near room temperature, prioritize:

| Measurement | T range (K) | x(DMSO) range | Estimated points | Rationale |
|-------------|-------------|---------------|-----------------|-----------|
| Hᴱ (calorimetry) | 293–313 | 0–1 (20 compositions) | ~60 | Completely missing; highest information content |
| Cp (DSC) | 293–313 | 0–1 (15 compositions) | ~60 | Only 7 pts at wrong T |
| Speed of sound | 293–313 | 0–1 (20 compositions) | ~60 | No full-range data near 298 K |
| Viscosity | 278–298 | 0–1 (15 compositions) | ~60 | Cryoprotectant applications |

These four campaigns (~240 new data points) would transform the thermodynamic characterization of this important system, enabling derivation of excess volume, excess compressibility, and a complete thermodynamic model linking Gᴱ, Hᴱ, and Cpᴱ.

---

*Data inventory based on ThermoML database survey (GLOBcomp_31 = dimethyl sulfoxide, GLOBcomp_1 = water). Block counts and point totals are approximate; some blocks could not be individually verified due to query limitations. The confidence level for the density and viscosity inventories is high; for other properties it is medium.*

### Core claims

- The ThermoML database contains approximately 23 data blocks totaling ~921 raw data points across ~10 DOIs and 8 thermophysical properties for the DMSO + water binary system.
- Mass density is the best-characterized property, with ~484 data points spanning 275–373 K and the full mole-fraction range, making new density measurements of limited value except at extreme conditions.
- Dynamic viscosity is well covered at 298–318 K (~171 data points, full composition range) but has no data below 298 K, which is a significant gap given DMSO–water cryoprotectant applications.
- Surface tension and refractive index each rely on only a single literature source in ThermoML, limiting confidence and warranting independent confirmation.
- Speed of sound data near 298 K across the full composition range are absent; the only broad-composition block covers 275–283 K.
- Molar heat capacity data are critically sparse, with only 7 data points at a single temperature (275 K) and no measurements at 298 K.
- Excess molar enthalpy, vapor pressure of mixtures, electrical conductivity, thermal conductivity, and diffusion coefficients are entirely absent from ThermoML for this system.
- The highest-priority new measurements identified are excess molar enthalpy at 298 K (completely missing and most informative for DMSO–water hydrogen-bonding interactions), molar heat capacity at 298 K, speed of sound at 298 K over the full composition range, and viscosity below 298 K.
- Approximately 240 new data points spanning those four measurement campaigns would substantially improve the thermodynamic characterization of the system, enabling derivation of excess volume, excess compressibility, and a complete thermodynamic model.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2584 | 10.1016/j.jct.2005.07.012 | PROPblock_8 |  | Mass density of DMSO + water binary mixture. 96 data points, T = 288.15–303.15 K, x(water) 0.031–0.980, P = 100 kPa. |
| GLOBlit_2652 | 10.1016/j.jct.2006.01.007 | PROPblock_4 |  | Mass density of DMSO + water binary mixture at fixed x(DMSO) = 0.0385. 6 data points, T = 288.15–313.15 K, P = 101 kPa. |
| GLOBlit_2652 | 10.1016/j.jct.2006.01.007 | PROPblock_3 |  | Speed of sound for DMSO + water at fixed x(DMSO) = 0.0385, T = 288.15–313.15 K, P = 101.0 kPa, 6 data points, u = 1555–1579 m/s. |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_4 |  | Mass density of DMSO + water binary mixture. 120 data points, T = 298.15–318.15 K, x(DMSO) 0.0–1.0 (full range), P = 101 kPa. |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 |  | Dynamic viscosity of DMSO + water binary mixture. 120 data points, T = 298.15–318.15 K, x(DMSO) = 0.0–1.0, P = 101.0 kPa. |
| GLOBlit_2842 | 10.1016/j.jct.2007.06.007 | PROPblock_6 |  | Mass density of DMSO + water binary mixture. 40 data points, T = 275.15–283.15 K, x(DMSO) 0.0–0.697, P = 101 kPa. |
| GLOBlit_2842 | 10.1016/j.jct.2007.06.007 | PROPblock_5 |  | Speed of sound for DMSO + water, x(DMSO) = 0.0–0.6967, T = 275.15–283.15 K, P = 101.0 kPa, 40 data points, u = 1415–1771 m/s. |
| GLOBlit_2842 | 10.1016/j.jct.2007.06.007 | PROPblock_4 |  | Molar heat capacity at constant pressure for DMSO + water binary. 7 data points, T = 275.15 K (fixed), x(DMSO) = 0.0506–0.6967, P = 101.0 kPa. |
| GLOBlit_2844 | 10.1016/j.jct.2007.06.010 | PROPblock_4 |  | Mass density of DMSO + water binary mixture. 92 data points, T = 278.15–368.15 K, molality 0.02–3.0 mol/kg, P = 350 kPa. |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_12 |  | Mass density of DMSO + water binary mixture. 16 data points, T = 303.15–318.15 K, x(DMSO) 0.012–0.058, P = 101 kPa. |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_10 |  | Dynamic viscosity of DMSO + water binary mixture. 16 data points, T = 303.15–318.15 K, x(DMSO) = 0.0121–0.0583, P = 101.0 kPa. |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_11 |  | Speed of sound for DMSO + water, x(DMSO) = 0.0121–0.0583, T = 303.15–318.15 K, P = 101.0 kPa, 16 data points, u = 1535–1605 m/s. |
| GLOBlit_10766 | 10.1021/je7001013 | PROPblock_9 |  | Surface tension of DMSO + water binary mixture. 112 data points, T = 298.15–328.15 K, x(DMSO) 0.012–0.895, gamma = 0.039–0.071 N/m. |
| GLOBlit_10766 | 10.1021/je7001013 | PROPblock_10 |  | Refractive index (Na D-line) for DMSO + water binary. 33 data points, T = 298.15–308.15 K, x(DMSO) = 0.0121–0.7685, P = 101.0 kPa. |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3 |  | Dynamic viscosity of DMSO + water binary mixture. 35 data points, T = 298.15–318.15 K, w(DMSO) = 0.0–1.0 (mass fraction), P = 101.0 kPa. |
| GLOBlit_7713 | 10.1021/acs.jced.8b01048 | PROPblock_10 |  | Mass density of DMSO + water binary mixture at near-pure DMSO. 9 data points, T = 293.15–373.15 K, x(DMSO) = 0.998, P = 100 kPa. |
| GLOBlit_663 | 10.1016/j.fluid.2008.09.010 | PROPblock_4 |  | Boiling temperature of DMSO + water binary mixture at reduced pressure. 16 data points, T = 331.1–388.15 K, x(water) 0.088–0.815, P = 13.33 kPa. |
| GLOBlit_10215 | 10.1021/je400531a | PROPblock_16 |  | Boiling temperature of DMSO + water binary mixture at atmospheric pressure. 21 data points, T = 373.15–463.43 K, x(water) 0.0–1.0, P = 101.3 kPa. |
| GLOBlit_9547 | 10.1021/je2002607 | PROPblock_1 |  | Solid-liquid equilibrium temperature for DMSO + water. 5 data points, T = 245.7–271.5 K, molality 1.0–9.0 mol/kg, P = 101 kPa. |
| GLOBlit_10109 | 10.1021/je400149j | PROPblock_6 |  | Solid-liquid equilibrium temperature for DMSO + water. 8 data points, T = 259.2–291.2 K, x(DMSO) 0.599–1.0, P = 101 kPa. |
| GLOBlit_10109 | 10.1021/je400149j | PROPblock_7 |  | Solid-liquid equilibrium temperature for DMSO + water. 2 data points, T = 270.2–273.2 K, x(DMSO) 0.0–0.051, P = 101 kPa. |
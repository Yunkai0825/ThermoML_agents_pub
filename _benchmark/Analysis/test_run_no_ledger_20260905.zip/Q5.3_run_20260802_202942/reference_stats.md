# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:29:42
**Wall time (at last flush):** 939.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 41 | 745,052 | 806,504 | 71,942 | 1,551,556 | 37,842 | 488.6 | claudeopus46 |
| L1-worker | 36 | 359,805 | 276,819 | 74,992 | 636,624 | 17,684 | 435.1 | claudeopus46 |
| **TOTAL** | **77** | **1,104,857** | **1,083,323** | **146,934** | **2,188,180** | **28,417** | **923.7** | |

**Estimated tokens:** ~547,045 input + ~36,733 output = ~583,778 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | instruction=Search for data blocks contai…, purpos… | 389 | — | — | 156.1 |
| 2 | 2 | `query_thermoml` | instruction=Search for data blocks contai…, purpos… | 282 | — | — | 291.8 |
| 3 | 6 | `inspect_block` | block_number=19, doi=10.1016/j.jct.2018.02.022, pr… | 221 | — | — | 0.0 |
| 4 | 6 | `inspect_block` | block_number=2, doi=10.1016/j.fluid.2004.11.019, p… | 220 | — | — | 0.0 |
| 5 | 6 | `inspect_block` | block_number=2, doi=10.1016/j.jct.2004.07.019, pro… | 220 | — | — | 0.0 |
| 6 | 9 | `inspect_block` | block_number=19, doi=10.1016/j.jct.2018.02.022, pr… | 147 | — | — | 0.0 |
| 7 | 9 | `inspect_block` | block_number=2, doi=10.1016/j.fluid.2004.11.019, p… | 146 | — | — | 0.0 |
| 8 | 9 | `inspect_block` | block_number=2, doi=10.1016/j.jct.2004.07.019, pro… | 146 | — | — | 0.0 |
| 9 | 12 | `inspect_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 1,376 | — | — | 0.2 |
| 10 | 12 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.1 |
| 11 | 12 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2004.0… | 1,554 | — | — | 0.1 |
| 12 | 15 | `propose_fitting_plan` | block_number=PROPblock_2, composition_hint=mole_fr… | 766 | — | — | 0.1 |
| 13 | 15 | `propose_fitting_plan` | block_number=PROPblock_19, composition_hint=mole_f… | 766 | — | — | 0.1 |
| 14 | 18 | `fit_block` | block_number=PROPblock_19, composition_hint=mole_f… | 876 | — | — | 0.9 |
| 15 | 18 | `fit_block` | block_number=PROPblock_2, composition_hint=mole_fr… | 133 | — | — | 0.1 |
| 16 | 18 | `fit_block` | block_number=PROPblock_2, composition_hint=mole_fr… | 133 | — | — | 0.0 |
| 17 | 21 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 831 | — | — | 1.0 |
| 18 | 21 | `predict_from_rk` | coeffs=[-142.149, 44.1112, 40.6894, …, property_ty… | 186 | — | — | 0.0 |
| 19 | 22 | `fit_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 133 | — | — | 0.1 |
| 20 | 24 | `inspect_block` | block_number=PROPblock_1, doi=10.1016/j.fluid.2014… | 1,391 | — | — | 0.1 |
| 21 | 24 | `inspect_block` | block_number=PROPblock_9, doi=10.1021/je800150h, p… | 1,359 | — | — | 0.2 |
| 22 | 24 | `fit_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 871 | — | — | 1.0 |
| 23 | 24 | `fit_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 133 | — | — | 0.1 |
| 24 | 27 | `predict_from_rk` | coeffs=[-142.149, 44.1112, 40.6894, …, mixing_rule… | 186 | — | — | 0.0 |
| 25 | 27 | `predict_from_rk` | coeffs=[-130.607, 36.494, 52.0283, -…, mixing_rule… | 186 | — | — | 0.0 |
| | | **TOTAL (25 tools)** | | **14,025** | | **0** | **452.0** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,999 | 4,999 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 7,353 | 7,353 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 10,395 | 10,395 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 13,785 | 13,785 | 0 | 0.0% |
| 5 | interval=3 | skipped_by_agent | 17,096 | 17,096 | 0 | 0.0% |
| 6 | interval=3 | skipped_by_agent | 19,947 | 19,947 | 0 | 0.0% |
| 7 | interval=3 | skipped_by_agent | 26,294 | 26,294 | 0 | 0.0% |
| 8 | interval=3 | skipped_by_agent | 28,675 | 28,675 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 405 | 20,426 | 1,335 | 9.2 |
| 2 | L1-worker | claudeopus46 | 20,643 | 689 | 21,332 | 741 | 5.8 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,051 | 22,694 | 14,244 | 65.4 |
| 4 | L1-worker | claudeopus46 | 2,065 | 518 | 2,583 | 607 | 4.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,286 | 22,929 | 8,645 | 41.9 |
| 6 | L1-worker | claudeopus46 | 20,643 | 11,552 | 32,195 | 2,126 | 7.6 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,257 | 3,613 | 866 | 5.8 |
| 8 | L1-worker | claudeopus46 | 536 | 2,137 | 2,673 | 981 | 6.0 |
| 9 | L1-worker | claudeopus46 | 1,323 | 4,505 | 5,828 | 3,207 | 12.7 |
| 10 | L1-worker | claudeopus46 | 298 | 3,929 | 4,227 | 2,452 | 9.6 |
| 11 | L1-worker | claudeopus46 | 1,160 | 8,063 | 9,223 | 1,697 | 7.3 |
| 12 | L0-main | claudeopus46 | 20,021 | 1,219 | 21,240 | 866 | 6.1 |
| 13 | L1-worker | claudeopus46 | 20,643 | 554 | 21,197 | 749 | 5.4 |
| 14 | L1-worker | claudeopus46 | 2,065 | 510 | 2,575 | 615 | 4.6 |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,343 | 21,986 | 937 | 6.4 |
| 16 | L1-worker | claudeopus46 | 2,065 | 11,022 | 13,087 | 1,423 | 11.7 |
| 17 | L1-worker | claudeopus46 | 2,065 | 11,232 | 13,297 | 1,473 | 13.2 |
| 18 | L1-worker | claudeopus46 | 20,643 | 1,976 | 22,619 | 709 | 5.2 |
| 19 | L1-worker | claudeopus46 | 2,065 | 10,987 | 13,052 | 1,479 | 12.2 |
| 20 | L1-worker | claudeopus46 | 2,065 | 11,197 | 13,262 | 1,483 | 13.9 |
| 21 | L1-worker | claudeopus46 | 20,610 | 3,396 | 24,006 | 628 | 4.6 |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,624 | 23,267 | 987 | 10.4 |
| 23 | L1-worker | claudeopus46 | 2,065 | 2,859 | 4,924 | 1,643 | 10.7 |
| 24 | L1-worker | claudeopus46 | 20,643 | 4,540 | 25,183 | 1,957 | 14.3 |
| 25 | L1-worker | claudeopus46 | 2,065 | 424 | 2,489 | 557 | 4.8 |
| 26 | L1-worker | claudeopus46 | 20,643 | 5,505 | 26,148 | 1,461 | 10.3 |
| 27 | L1-worker | claudeopus46 | 20,643 | 6,281 | 26,924 | 1,308 | 10.9 |
| 28 | L1-worker | claudeopus46 | 20,643 | 7,142 | 27,785 | 2,928 | 19.6 |
| 29 | L1-worker | claudeopus46 | 2,065 | 358 | 2,423 | 464 | 4.2 |
| 30 | L1-worker | claudeopus46 | 20,643 | 7,054 | 27,697 | 1,506 | 12.3 |
| 31 | L1-worker | claudeopus46 | 2,065 | 1,926 | 3,991 | 1,130 | 8.6 |
| 32 | L1-worker | claudeopus46 | 20,610 | 9,187 | 29,797 | 473 | 4.4 |
| 33 | L1-worker | claudeopus46 | 20,643 | 8,415 | 29,058 | 3,598 | 24.5 |
| 34 | L1-worker | claudeopus46 | 536 | 2,574 | 3,110 | 854 | 5.9 |
| 35 | L1-worker | claudeopus46 | 1,356 | 2,694 | 4,050 | 794 | 8.1 |
| 36 | L1-worker | claudeopus46 | 1,323 | 14,149 | 15,472 | 5,220 | 18.2 |
| 37 | L1-worker | claudeopus46 | 298 | 5,942 | 6,240 | 4,252 | 15.3 |
| 38 | L1-worker | claudeopus46 | 747 | 104,941 | 105,688 | 798 | 8.6 |
| 39 | L0-main | claudeopus46 | 20,021 | 4,502 | 24,523 | 1,269 | 9.4 |
| 40 | L0-main | claudeopus46 | 20,021 | 5,817 | 25,838 | 1,005 | 5.3 |
| 41 | L0-main | claudeopus46 | 20,021 | 7,033 | 27,054 | 1,343 | 7.5 |
| 42 | L0-main | claudeopus46 | 20,021 | 8,481 | 28,502 | 1,159 | 5.4 |
| 43 | L0-main | claudeopus46 | 19,988 | 8,649 | 28,637 | 502 | 3.7 |
| 44 | L0-main | claudeopus46 | 20,021 | 7,892 | 27,913 | 672 | 6.4 |
| 45 | L0-main | claudeopus46 | 20,021 | 9,084 | 29,105 | 1,017 | 5.3 |
| 46 | L0-main | claudeopus46 | 20,021 | 10,293 | 30,314 | 1,324 | 7.8 |
| 47 | L0-main | claudeopus46 | 19,988 | 11,078 | 31,066 | 489 | 5.4 |
| 48 | L0-main | claudeopus46 | 20,021 | 10,321 | 30,342 | 755 | 4.6 |
| 49 | L0-main | claudeopus46 | 20,021 | 11,561 | 31,582 | 995 | 5.2 |
| 50 | L0-main | claudeopus46 | 20,021 | 12,789 | 32,810 | 1,366 | 7.2 |
| 51 | L0-main | claudeopus46 | 19,988 | 15,651 | 35,639 | 422 | 4.7 |
| 52 | L0-main | claudeopus46 | 20,021 | 14,891 | 34,912 | 1,972 | 13.3 |
| 53 | L0-main | claudeopus46 | 20,021 | 16,027 | 36,048 | 1,268 | 7.1 |
| 54 | L0-main | claudeopus46 | 20,021 | 17,020 | 37,041 | 1,673 | 10.6 |
| 55 | L0-main | claudeopus46 | 19,988 | 19,166 | 39,154 | 390 | 7.6 |
| 56 | L0-main | claudeopus46 | 20,021 | 18,406 | 38,427 | 2,328 | 13.9 |
| 57 | L0-main | claudeopus46 | 20,021 | 19,727 | 39,748 | 2,065 | 12.2 |
| 58 | L0-main | claudeopus46 | 20,021 | 20,984 | 41,005 | 2,029 | 10.0 |
| 59 | L0-main | claudeopus46 | 19,988 | 24,038 | 44,026 | 470 | 4.7 |
| 60 | L0-main | claudeopus46 | 20,021 | 23,278 | 43,299 | 2,362 | 15.0 |
| 61 | L0-main | claudeopus46 | 20,021 | 24,358 | 44,379 | 1,059 | 6.9 |
| 62 | L0-main | claudeopus46 | 20,021 | 25,347 | 45,368 | 1,251 | 8.2 |
| 63 | L0-main | claudeopus46 | 19,988 | 28,218 | 48,206 | 408 | 6.4 |
| 64 | L0-main | claudeopus46 | 20,021 | 27,458 | 47,479 | 3,625 | 28.7 |
| 65 | L0-main | claudeopus46 | 20,021 | 28,276 | 48,297 | 6,078 | 40.3 |
| 66 | L0-main | claudeopus46 | 20,021 | 29,900 | 49,921 | 2,280 | 13.7 |
| 67 | L0-main | claudeopus46 | 19,988 | 36,756 | 56,744 | 398 | 4.6 |
| 68 | L0-main | claudeopus46 | 20,021 | 35,996 | 56,017 | 3,643 | 28.5 |
| 69 | L0-main | claudeopus46 | 20,021 | 37,445 | 57,466 | 1,748 | 12.3 |
| 70 | L0-main | claudeopus46 | 20,021 | 38,456 | 58,477 | 1,400 | 10.7 |
| 71 | L0-main | claudeopus46 | 19,988 | 39,262 | 59,250 | 376 | 4.1 |
| 72 | L0-main | claudeopus46 | 20,021 | 38,502 | 58,523 | 4,715 | 31.7 |
| 73 | L0-main | claudeopus46 | 20,021 | 39,494 | 59,515 | 8,146 | 55.2 |
| 74 | L0-main | claudeopus46 | 1,356 | 4,691 | 6,047 | 984 | 7.3 |
| 75 | L0-main | claudeopus46 | 1,323 | 58,859 | 60,182 | 3,011 | 21.7 |
| 76 | L0-main | claudeopus46 | 298 | 3,853 | 4,151 | 2,708 | 12.0 |
| 77 | L0-main | claudeopus46 | 1,562 | 11,321 | 12,883 | 1,036 | 8.7 |


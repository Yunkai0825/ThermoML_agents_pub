# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.3_run_20260802_202942`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_2 | ethanol | 786.59333 |
| comp | GLOBcomp_1 | water | 996.569 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_4 | molalitymolkg<ethanol> |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [propose_fitting_plan]
- [propose_fitting_plan]
- [fit_block]
- [fit_block] ERROR: Only 0 mixture points (need >= 3 for RK fit)
- [fit_block] ERROR: Only 0 mixture points (need >= 3 for RK fit)
- [fit_block]
- [predict_from_rk]
- [fit_block] ERROR: Only 0 mixture points (need >= 3 for RK fit)
- [inspect_block]
- [inspect_block]
- [fit_block]
- [fit_block] ERROR: Only 0 mixture points (need >= 3 for RK fit)
- [predict_from_rk]
- [predict_from_rk]

### Query Results
#### query
A search of ThermoML for binary ethanol (CAS 64-17-5) + water (CAS 7732-18-5) mass density data near 310 K (305–315 K window) returned 15 data blocks from distinct literature sources. The best block for full composition coverage at ~310 K is PROPblock_19 from GLOBlit_5201 (DOI 10.1016/j.jct.2018.02.022), which provides 61 composition points spanning the entire ethanol mole fraction range (0 to 1) at a fixed temperature of 308.15 K, out of 244 total points in the block. The two largest blocks overall are from GLOBlit_220 (810 points, DOI 10.1016/j.fluid.2004.11.019) and GLOBlit_2432 (565 points, DOI 10.1016/j.jct.2004.07.019), but their data span multiple temperatures. The identified best block is noted as particularly suitable for composition-dependent density analysis, excess volume fitting, or density mixing models near 310 K.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | binary |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | binary |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | binary |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | binary |
| GLOBlit_11136 | 10.1021/je800150h | PROPblock_9 | declared | 108 | binary | binary |
| GLOBlit_10866 | 10.1021/je700300y | PROPblock_7 | declared | 84 | binary | binary |
| GLOBlit_3475 | 10.1016/j.jct.2011.10.009 | PROPblock_3 | declared | 70 | binary | binary |
| GLOBlit_4415 | 10.1016/j.jct.2015.06.024 | PROPblock_7 | declared | 40 | binary | binary |
| GLOBlit_8050 | 10.1021/je020173z | PROPblock_5 | declared | 24 | binary | binary |
| GLOBlit_10159 | 10.1021/je4003515 | PROPblock_7 | declared | 23 | binary | binary |
| GLOBlit_10699 | 10.1021/je600565m | PROPblock_6 | declared | 18 | binary | binary |
| GLOBlit_11459 | 10.1021/je800942u | PROPblock_6 | declared | 18 | binary | binary |
| GLOBlit_11792 | 10.1021/je900743e | PROPblock_3 | declared | 15 | binary | binary |
| GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_7 | declared | 12 | binary | binary |
| GLOBlit_11504 | 10.1021/je900064e | PROPblock_6 | declared | 10 | binary | binary |

### Inspected Blocks
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19: 244 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2: 810 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2: 565 rows; x=['molality_mol_kg_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Difference with the reference state, X-X(REF); reference=Pure solvent at the same temperature and pressure; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=reference_difference; materialize_reference=True; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1: 140 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_11136 | 10.1021/je800150h | PROPblock_9: 108 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.jct.2018.02.022/PROPblock_19 (ethanol, water): RK order=5, R²=0.997496, RMSE=0.5437916218370844, coeffs=[-142.148782, 44.111234, 40.689398, -68.811571, -61.546384, 74.489052]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: ethanol=777.919, water=993.558 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_excess.png
  - 10.1016/j.fluid.2004.11.019/PROPblock_2 (ethanol, water): RK order=1, R²=0.685985, RMSE=7.513554608584111, coeffs=[-142.829872, 23.387302]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: ethanol=781.48, water=991.363 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_excess.png
  - 10.1016/j.jct.2018.02.022/PROPblock_19 (ethanol, water): RK order=5, R²=0.996578, RMSE=0.5768324534987193, coeffs=[-130.607076, 36.493956, 52.028346, -83.606185, -73.710221, 95.57633]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: ethanol=786.593, water=996.569 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_19_T308.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_19_T308.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T323.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T323.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T308.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T308.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T308.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T323.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T323.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T323.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1


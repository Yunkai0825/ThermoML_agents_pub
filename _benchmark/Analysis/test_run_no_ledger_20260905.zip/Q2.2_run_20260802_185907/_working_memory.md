# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q2.2_run_20260802_185907`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_18 | dimethylformamide | 7.7440168e-05 |
| comp | GLOBcomp_1 | water | 1.8069208e-05 |
| comp | GLOBcomp_4 | methanol | 4.070376e-05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<dimethylformamide> |  |
| var | GLOBvar_5 | massfraction<dimethylformamide> |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| constr | GLOBconstr_2 | temperaturek |  |

### History
- [query_thermoml]
- [query_thermoml]
- [query_thermoml]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_molar_volume'. Available: ['density_to_mola
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_molar_volume'. Available: ['density_to_mola
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_molar_volume'. Available: ['density_to_mola
- [fit_block_derived]
- [fit_block_derived] ERROR: Constraint column 'Temperature, K' not found
- [fit_block_derived] ERROR: Constraint column 'Temperature, K' not found
- [inspect_block]
- [inspect_block]
- [fit_block_derived] ERROR: Block composition coverage is insufficient to anchor the derived property at bot
- [fit_block_derived]
- [inspect_block]
- [inspect_block]
- [fit_block_derived]
- [fit_block_derived] ERROR: Block composition coverage is insufficient to anchor the derived property at bot
- [predict_from_rk]
- [predict_from_rk]
- [predict_from_rk]

### Query Results
#### query
No density or molar volume data for the ternary system N,N-dimethylformamide (DMF) + water + methanol at 298.15 K was found in the ThermoML database. The only ternary block containing all three compounds (in DOI 10.1016/j.tca.2006.02.028) measures molar enthalpy of solution of DMF at infinite dilution in methanol–water mixtures, not volumetric properties. Therefore, the requested density and molar volume data are not available in ThermoML.

**Status:** no_results

#### query
Binary density (mass density) data for N,N-dimethylformamide (DMF) + water at 298.15 K were identified across 11 data blocks in ThermoML. Sources span multiple literature references and report composition in mole fraction, mass fraction, or molality, covering the full miscibility range. The DMF + water system exhibits non-linear density variation with composition, typically showing a maximum near x(DMF) ≈ 0.3–0.4 at 298.15 K, attributed to strong hydrogen-bonding interactions between water and the DMF carbonyl group. Key literature DOIs include 10.1016/j.fluid.2014.08.026, 10.1016/j.jct.2005.07.012, 10.1016/j.jct.2007.05.015, 10.1016/j.jct.2012.04.007, 10.1016/j.jct.2014.05.003, 10.1016/j.jct.2014.05.013, 10.1016/j.jct.2015.03.012, 10.1021/je050209y, and 10.1021/je0601098, with data block counts ranging from 3 to 20 points near 298.15 K per source.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_1540 | 10.1016/j.fluid.2014.08.026 | PROPblock_5 | declared | 4 | binary | binary |
| GLOBlit_2584 | 10.1016/j.jct.2005.07.012 | PROPblock_9 | declared | 128 | binary | binary |
| GLOBlit_2834 | 10.1016/j.jct.2007.05.015 | PROPblock_18 | declared | 40 | binary | binary |
| GLOBlit_3614 | 10.1016/j.jct.2012.04.007 | PROPblock_3 | declared | 55 | binary | binary |
| GLOBlit_4166 | 10.1016/j.jct.2014.05.003 | PROPblock_1 | declared | 3 | binary | binary |
| GLOBlit_4174 | 10.1016/j.jct.2014.05.013 | PROPblock_19 | declared | 18 | binary | binary |
| GLOBlit_4340 | 10.1016/j.jct.2015.03.012 | PROPblock_2 | declared | 6 | binary | binary |
| GLOBlit_8676 | 10.1021/je050209y | PROPblock_10 | declared | 11 | binary | binary |
| GLOBlit_8888 | 10.1021/je0601098 | PROPblock_30 | declared | 14 | binary | binary |

**Status:** partial

#### query
Two ThermoML binary data blocks contain mass density measurements for N,N-dimethylformamide + methanol at or covering 298.15 K. The first (DOI 10.1016/j.jct.2014.02.021, PROPblock_6) has 26 data points all at 298.15 K spanning the composition range, measured by vibrating-tube densimetry. The second (DOI 10.1021/je700430g, PROPblock_8) has 55 data points over 293.15–333.15 K, with approximately 5 points at 298.15 K, also by vibrating-tube densimetry. Roughly 31 density data points are available at 298.15 K in total, with the first source providing the most comprehensive isothermal composition coverage at that temperature.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_4125 | 10.1016/j.jct.2014.02.021 | PROPblock_6 | declared | 26 | binary | binary |
| GLOBlit_10930 | 10.1021/je700430g | PROPblock_8 | declared | 55 | binary | binary |

#### query
Seven ThermoML data blocks contain binary water (GLOBcomp_1) + methanol (GLOBcomp_4) mass density (GLOBprop_1) measurements at 298.15 K, totalling 49 data points. The three richest datasets are GLOBlit_2825 (13 points, DOI 10.1016/j.jct.2007.05.004), GLOBlit_8424 (12 points, DOI 10.1021/je049691v), and GLOBlit_10866 (12 points, DOI 10.1021/je700300y). Additional sources are GLOBlit_7085 (3 points), GLOBlit_8254 (2 points), GLOBlit_8869 (3 points), and GLOBlit_9571 (4 points). Mean densities across blocks span roughly 886–981 kg/m³, reflecting the full composition range from methanol-rich to water-rich mixtures. Temperature is recorded as GLOBvar_1 in kelvin and mass density as GLOBprop_1 in kg/m³. Two additional blocks were identified but did not yield data rows at exactly 298.15 K.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | binary |
| GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_6 | declared | 12 | binary | binary |
| GLOBlit_8254 | 10.1021/je034101z | PROPblock_4 | declared | 401 | binary | binary |
| GLOBlit_8424 | 10.1021/je049691v | PROPblock_3 | declared | 180 | binary | binary |
| GLOBlit_8869 | 10.1021/je0600810 | PROPblock_4 | declared | 9 | binary | binary |
| GLOBlit_9571 | 10.1021/je2003622 | PROPblock_2 | declared | 16 | binary | binary |
| GLOBlit_10866 | 10.1021/je700300y | PROPblock_6 | declared | 84 | binary | binary |

### Inspected Blocks
- GLOBlit_2584 | 10.1016/j.jct.2005.07.012 | PROPblock_9: 128 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_4125 | 10.1016/j.jct.2014.02.021 | PROPblock_6: 26 rows; x=['mole_fraction_<dimethylformamide>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10: 39 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2584 | 10.1016/j.jct.2005.07.012 | PROPblock_9: 128 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10: 39 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_8676 | 10.1021/je050209y | PROPblock_10: 11 rows; x=['mole_fraction_<dimethylformamide>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_4174 | 10.1016/j.jct.2014.05.013 | PROPblock_19: 18 rows; x=['mass_fraction_<dimethylformamide>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.jct.2014.02.021/PROPblock_6 (dimethylformamide, methanol): RK order=1, R²=0.910862, RMSE=3.980600133620175e-08, coeffs=[-2e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: dimethylformamide=7.74333e-05, methanol=4.07358e-05 [block-edges of derived data (methanol: direct/good, dimethylformamide: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_02_021_BPROPblock_6_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_02_021_BPROPblock_6_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_02_021_BPROPblock_6_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_02_021_BPROPblock_6_excess.png
  - 10.1016/j.jct.2007.05.004/PROPblock_10 (water, methanol): RK order=5, R²=0.999995, RMSE=6.883050222977911e-10, coeffs=[-4e-06, -0.0, 0.0, 0.0, 1e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: water=1.80683e-05, methanol=4.07038e-05 [block-edges of derived data (methanol: direct/good, water: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png
  - 10.1016/j.jct.2014.05.013/PROPblock_19 (dimethylformamide, water): RK order=0, R²=0.988762, RMSE=3.759458172083048e-08, coeffs=[-5e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      ⚠ Composition axis converted to mole fraction of dimethylformamide: mass_fraction → mole_fraction via x1=(w1/M1)/(w1/M1+w2/M2), M1=73.095, M2=18.015 g/mol [exact (molar masses from block formulas)]. Source column: mass_fraction_<dimethylformamide>.
      pure refs: dimethylformamide=7.74402e-05, water=1.80692e-05 [block-edges of derived data (water: direct/good, dimethylformamide: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2014_02_021_BPROPblock_6_fit.csv` — RK fit data — 10.1016/j.jct.2014.02.021 PROPblock_6
- `$ROOT/data\10_1016_j_jct_2014_02_021_BPROPblock_6_excess.csv` — Excess property — 10.1016/j.jct.2014.02.021 PROPblock_6
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/data\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2014.05.013 PROPblock_19_T298.1
- `$ROOT/data\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2014.05.013 PROPblock_19_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2014_02_021_BPROPblock_6_fit.png` — RK fit plot — 10.1016/j.jct.2014.02.021 PROPblock_6
- `$ROOT/plots\10_1016_j_jct_2014_02_021_BPROPblock_6_excess.png` — Excess plot — 10.1016/j.jct.2014.02.021 PROPblock_6
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/plots\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2014.05.013 PROPblock_19_T298.1
- `$ROOT/plots\10_1016_j_jct_2014_05_013_BPROPblock_19_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2014.05.013 PROPblock_19_T298.1


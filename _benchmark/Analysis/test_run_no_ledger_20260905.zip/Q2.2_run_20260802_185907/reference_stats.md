# Reference Stats — analysis-agent

**Run started:** 2026-08-02 18:59:07
**Wall time (at last flush):** 961.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 30 | 505,230 | 586,399 | 72,377 | 1,091,629 | 36,387 | 446.3 | claudeopus46 |
| L1-worker | 53 | 456,646 | 301,650 | 76,500 | 758,296 | 14,307 | 480.3 | claudeopus46 |
| **TOTAL** | **83** | **961,876** | **888,049** | **148,877** | **1,849,925** | **22,288** | **926.6** | |

**Estimated tokens:** ~462,481 input + ~37,219 output = ~499,700 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 2 | 2 | 2 | 2 | 81 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **2** | **2** | **2** | **2** | **81** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_4125 |  | query_thermoml |
| GLOBlit_10930 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_4 | methanol | query_thermoml |
| GLOBcomp_18 | dimethylformamide | query_thermoml |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | query_thermoml |
| GLOBconstr_1 | Pressure, kPa | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | query_thermoml |
| GLOBvar_1 | Temperature, K | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_2 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_134 | Mass density, kg/m3 | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 2 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Constraints | 2 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Total DOIs | 2 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 81 |

---

## 3. DOI & Block References

**Unique DOIs:** 2  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 81

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2014.02.021 | 1 | 26 | binary | query_thermoml |
| 10.1021/je700430g | 1 | 55 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2014.02.021 | PROPblock_6 | declared | 26 | binary | 2 | query_thermoml |
| 10.1021/je700430g | PROPblock_8 | declared | 55 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'ternary', 'purpos… | 184 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'ternary_density',… | 132 | — | — | 0.0 |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'ternary_density',… | 132 | — | — | 0.0 |
| 4 | 4 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 2,140 | — | — | 198.6 |
| 5 | 5 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 282 | — | — | 68.9 |
| 6 | 5 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 14,066 | — | — | 44.4 |
| 7 | 5 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 282 | — | — | 204.2 |
| 8 | 8 | `inspect_block` | block_number=PROPblock_9, doi=10.1016/j.jct.2005.0… | 1,386 | — | — | 0.3 |
| 9 | 8 | `inspect_block` | block_number=PROPblock_6, doi=10.1016/j.jct.2014.0… | 1,400 | — | — | 0.1 |
| 10 | 8 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.2 |
| 11 | 12 | `fit_block_derived` | block_number=PROPblock_9, composition_hint=mole_fr… | 227 | — | — | 0.0 |
| 12 | 12 | `fit_block_derived` | block_number=PROPblock_6, composition_hint=mole_fr… | 227 | — | — | 0.0 |
| 13 | 12 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 228 | — | — | 0.0 |
| 14 | 13 | `fit_block_derived` | block_number=PROPblock_9, composition_hint=mole_fr… | 288 | — | — | 0.0 |
| 15 | 13 | `fit_block_derived` | block_number=PROPblock_6, composition_hint=mole_fr… | 936 | — | — | 0.8 |
| 16 | 13 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 288 | — | — | 0.0 |
| 17 | 14 | `fit_block_derived` | block_number=PROPblock_9, doi=10.1016/j.jct.2005.0… | 132 | — | — | 0.1 |
| 18 | 14 | `fit_block_derived` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 133 | — | — | 0.1 |
| 19 | 15 | `inspect_block` | block_number=PROPblock_9, doi=10.1016/j.jct.2005.0… | 1,386 | — | — | 0.1 |
| 20 | 15 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.0 |
| 21 | 16 | `fit_block_derived` | block_number=PROPblock_9, doi=10.1016/j.jct.2005.0… | 223 | — | — | 0.1 |
| 22 | 16 | `fit_block_derived` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 954 | — | — | 1.0 |
| 23 | 18 | `inspect_block` | block_number=PROPblock_10, doi=10.1021/je050209y, … | 1,401 | — | — | 0.2 |
| 24 | 18 | `inspect_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2014.… | 1,398 | — | — | 0.2 |
| 25 | 19 | `fit_block_derived` | block_number=PROPblock_19, composition_hint=mass_f… | 752 | — | — | 1.0 |
| 26 | 19 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 216 | — | — | 0.1 |
| 27 | 20 | `predict_from_rk` | coeffs=[-1.68397e-06, 7.49718e-07], n_points=3, pr… | 217 | — | — | 0.0 |
| 28 | 20 | `predict_from_rk` | coeffs=[-3.98239e-06, -1.5386e-07, 1…, n_points=3,… | 205 | — | — | 0.0 |
| 29 | 20 | `predict_from_rk` | coeffs=[-4.70149e-06], n_points=3, property_type=m… | 214 | — | — | 0.0 |
| | | **TOTAL (29 tools)** | | **32,149** | | **0** | **520.4** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,021 | 2,021 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 12,722 | 12,722 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 19,427 | 19,427 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 25,391 | 25,391 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 417 | 20,438 | 2,677 | 17.2 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,116 | 21,137 | 1,808 | 8.5 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,701 | 21,722 | 1,789 | 9.0 |
| 4 | L0-main | claudeopus46 | 19,988 | 3,042 | 23,030 | 586 | 4.3 |
| 5 | L0-main | claudeopus46 | 20,021 | 2,285 | 22,306 | 15,936 | 78.1 |
| 6 | L1-worker | claudeopus46 | 20,643 | 417 | 21,060 | 1,112 | 6.5 |
| 7 | L1-worker | claudeopus46 | 20,643 | 2,257 | 22,900 | 6,234 | 30.1 |
| 8 | L1-worker | claudeopus46 | 2,065 | 517 | 2,582 | 442 | 3.8 |
| 9 | L1-worker | claudeopus46 | 2,065 | 466 | 2,531 | 501 | 4.6 |
| 10 | L1-worker | claudeopus46 | 20,643 | 2,895 | 23,538 | 3,254 | 18.8 |
| 11 | L1-worker | claudeopus46 | 2,065 | 599 | 2,664 | 1,669 | 11.1 |
| 12 | L1-worker | claudeopus46 | 20,610 | 5,180 | 25,790 | 617 | 4.3 |
| 13 | L1-worker | claudeopus46 | 20,643 | 4,408 | 25,051 | 7,349 | 36.5 |
| 14 | L1-worker | claudeopus46 | 2,065 | 511 | 2,576 | 1,385 | 7.4 |
| 15 | L1-worker | claudeopus46 | 20,643 | 5,786 | 26,429 | 2,663 | 12.4 |
| 16 | L1-worker | claudeopus46 | 2,065 | 2,585 | 4,650 | 1,888 | 12.6 |
| 17 | L1-worker | claudeopus46 | 20,643 | 7,583 | 28,226 | 998 | 6.9 |
| 18 | L1-worker | claudeopus46 | 1,323 | 8,197 | 9,520 | 92 | 2.0 |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,129 | 2,485 | 511 | 3.1 |
| 20 | L1-worker | claudeopus46 | 536 | 1,009 | 1,545 | 457 | 4.0 |
| 21 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.1 |
| 22 | L1-worker | claudeopus46 | 747 | 9,345 | 10,092 | 674 | 5.4 |
| 23 | L0-main | claudeopus46 | 20,021 | 5,439 | 25,460 | 1,541 | 8.1 |
| 24 | L1-worker | claudeopus46 | 20,643 | 354 | 20,997 | 857 | 6.0 |
| 25 | L1-worker | claudeopus46 | 2,065 | 7,480 | 9,545 | 1,586 | 12.4 |
| 26 | L1-worker | claudeopus46 | 20,643 | 2,242 | 22,885 | 2,579 | 13.2 |
| 27 | L1-worker | claudeopus46 | 1,356 | 2,361 | 3,717 | 500 | 3.5 |
| 28 | L1-worker | claudeopus46 | 536 | 2,241 | 2,777 | 874 | 5.4 |
| 29 | L1-worker | claudeopus46 | 1,323 | 5,023 | 6,346 | 3,854 | 14.0 |
| 30 | L1-worker | claudeopus46 | 298 | 4,576 | 4,874 | 2,935 | 11.6 |
| 31 | L1-worker | claudeopus46 | 747 | 59,242 | 59,989 | 736 | 7.7 |
| 32 | L1-worker | claudeopus46 | 20,643 | 360 | 21,003 | 839 | 6.2 |
| 33 | L1-worker | claudeopus46 | 2,065 | 4,621 | 6,686 | 1,471 | 13.2 |
| 34 | L1-worker | claudeopus46 | 20,643 | 1,790 | 22,433 | 987 | 7.1 |
| 35 | L1-worker | claudeopus46 | 536 | 996 | 1,532 | 642 | 4.0 |
| 36 | L1-worker | claudeopus46 | 1,356 | 1,116 | 2,472 | 662 | 4.1 |
| 37 | L1-worker | claudeopus46 | 1,323 | 3,308 | 4,631 | 1,106 | 5.8 |
| 38 | L1-worker | claudeopus46 | 298 | 1,828 | 2,126 | 880 | 4.1 |
| 39 | L1-worker | claudeopus46 | 747 | 16,449 | 17,196 | 661 | 7.0 |
| 40 | L1-worker | claudeopus46 | 20,643 | 327 | 20,970 | 915 | 6.0 |
| 41 | L1-worker | claudeopus46 | 2,065 | 6,382 | 8,447 | 1,853 | 16.0 |
| 42 | L1-worker | claudeopus46 | 2,065 | 6,592 | 8,657 | 1,747 | 17.3 |
| 43 | L1-worker | claudeopus46 | 20,643 | 943 | 21,586 | 910 | 6.0 |
| 44 | L1-worker | claudeopus46 | 2,065 | 6,997 | 9,062 | 1,430 | 12.7 |
| 45 | L1-worker | claudeopus46 | 2,065 | 7,207 | 9,272 | 1,629 | 13.3 |
| 46 | L1-worker | claudeopus46 | 20,643 | 1,652 | 22,295 | 941 | 6.4 |
| 47 | L1-worker | claudeopus46 | 2,065 | 7,836 | 9,901 | 1,713 | 13.5 |
| 48 | L1-worker | claudeopus46 | 20,610 | 3,251 | 23,861 | 514 | 4.7 |
| 49 | L1-worker | claudeopus46 | 20,643 | 2,479 | 23,122 | 1,175 | 8.4 |
| 50 | L1-worker | claudeopus46 | 20,643 | 3,341 | 23,984 | 1,104 | 10.6 |
| 51 | L1-worker | claudeopus46 | 20,643 | 4,193 | 24,836 | 1,209 | 10.1 |
| 52 | L1-worker | claudeopus46 | 2,065 | 5,339 | 7,404 | 1,480 | 11.2 |
| 53 | L1-worker | claudeopus46 | 20,610 | 5,806 | 26,416 | 458 | 3.9 |
| 54 | L1-worker | claudeopus46 | 20,643 | 5,034 | 25,677 | 1,625 | 10.6 |
| 55 | L1-worker | claudeopus46 | 1,356 | 1,756 | 3,112 | 716 | 4.1 |
| 56 | L1-worker | claudeopus46 | 536 | 1,636 | 2,172 | 807 | 4.5 |
| 57 | L1-worker | claudeopus46 | 1,323 | 8,913 | 10,236 | 2,638 | 9.9 |
| 58 | L1-worker | claudeopus46 | 298 | 3,360 | 3,658 | 1,917 | 7.8 |
| 59 | L1-worker | claudeopus46 | 747 | 50,921 | 51,668 | 637 | 6.4 |
| 60 | L0-main | claudeopus46 | 20,021 | 11,509 | 31,530 | 2,097 | 13.8 |
| 61 | L0-main | claudeopus46 | 20,021 | 12,833 | 32,854 | 1,199 | 6.1 |
| 62 | L0-main | claudeopus46 | 20,021 | 14,347 | 34,368 | 958 | 4.9 |
| 63 | L0-main | claudeopus46 | 20,021 | 16,104 | 36,125 | 3,174 | 19.4 |
| 64 | L0-main | claudeopus46 | 20,021 | 17,465 | 37,486 | 1,856 | 9.6 |
| 65 | L0-main | claudeopus46 | 20,021 | 18,728 | 38,749 | 1,959 | 9.7 |
| 66 | L0-main | claudeopus46 | 20,021 | 20,129 | 40,150 | 2,096 | 11.7 |
| 67 | L0-main | claudeopus46 | 19,988 | 20,801 | 40,789 | 528 | 5.0 |
| 68 | L0-main | claudeopus46 | 20,021 | 20,041 | 40,062 | 2,675 | 17.6 |
| 69 | L0-main | claudeopus46 | 20,021 | 23,881 | 43,902 | 1,167 | 7.7 |
| 70 | L0-main | claudeopus46 | 20,021 | 24,998 | 45,019 | 799 | 5.6 |
| 71 | L0-main | claudeopus46 | 19,988 | 29,833 | 49,821 | 483 | 4.8 |
| 72 | L0-main | claudeopus46 | 20,021 | 29,073 | 49,094 | 1,094 | 9.2 |
| 73 | L0-main | claudeopus46 | 20,021 | 32,445 | 52,466 | 1,292 | 10.0 |
| 74 | L0-main | claudeopus46 | 20,021 | 33,753 | 53,774 | 3,300 | 27.9 |
| 75 | L0-main | claudeopus46 | 19,988 | 38,185 | 58,173 | 377 | 5.6 |
| 76 | L0-main | claudeopus46 | 20,021 | 37,425 | 57,446 | 2,054 | 15.5 |
| 77 | L0-main | claudeopus46 | 20,021 | 40,936 | 60,957 | 4,599 | 33.0 |
| 78 | L0-main | claudeopus46 | 20,021 | 42,511 | 62,532 | 7,180 | 53.7 |
| 79 | L0-main | claudeopus46 | 1,356 | 4,743 | 6,099 | 1,173 | 7.6 |
| 80 | L0-main | claudeopus46 | 298 | 1,555 | 1,853 | 1,161 | 3.8 |
| 81 | L0-main | claudeopus46 | 1,323 | 68,230 | 69,553 | 3,146 | 17.7 |
| 82 | L0-main | claudeopus46 | 298 | 3,988 | 4,286 | 2,595 | 12.0 |
| 83 | L0-main | claudeopus46 | 1,562 | 8,886 | 10,448 | 1,078 | 9.2 |


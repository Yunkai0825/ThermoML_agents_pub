# Delegated query run — result

**Question:** Find binary mixture data blocks containing density (mass density, GLOBprop_1) measurements for methanol (CH3OH) + water (H2O) at or near 298.15 K. Return DOIs, block numbers, compound IDs, and temperature ranges.

**Iterations:** 5  |  **Elapsed:** 510.6s  |  **Tools:** 5  |  **Timed out:** False

---

## Answer

## Binary Methanol + Water Density Data at 298.15 K

Nine data blocks containing mass density (kg/m³) measurements for the binary methanol (GLOBcomp_4) + water (GLOBcomp_1) system were identified in the ThermoML database with temperature ranges overlapping ~298.15 K. Here are the most relevant blocks:

---

### Best Candidates for Composition-Dependent Density at 298.15 K

**1. DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825), PROPblock_10** ⭐ Recommended
- **Data points:** 39 total (15 near 298 K)
- **Temperature range:** 293.15–303.15 K (3 unique temperatures)
- **Composition:** x(water) = 0.0 to 1.0 — **full mole-fraction range** (13 unique compositions)
- **Density range:** 782.48–998.20 kg/m³
- **Pressure:** 101 kPa (atmospheric)
- **Method:** Vibrating tube densimeter
- *Excellent coverage for Redlich-Kister fitting — spans the entire composition range from pure methanol to pure water.*

**2. DOI 10.1021/je049691v (GLOBlit_8424), PROPblock_3**
- **Data points:** 180 total (13 near 298 K)
- **Temperature range:** 283.15–353.15 K (15 unique temperatures)
- **Composition:** x(water) = 0.08–0.96 (12 unique compositions)
- **Density range:** 795.52–988.05 kg/m³ (at 298 K subset)
- **Method:** Vibrating tube densimeter
- *Broad composition coverage; good complementary dataset.*

---

### Other Blocks (More Limited Utility)

**3. DOI 10.1021/acs.jced.6b01058 (GLOBlit_7085), PROPblock_6**
- 12 points, T = 298.15–313.15 K
- Composition: w(methanol) = 0.04–0.16 (mass fraction; narrow, water-rich end only)
- Density: 963.68–989.97 kg/m³
- Pressure: 85 kPa

**4. DOI 10.1021/je0600810 (GLOBlit_8869), PROPblock_4**
- 9 points, T = 298.15–318.15 K
- Composition: φ_v(methanol) = 0.01–0.3 (volume fraction basis; limited range)
- Density: 946.26–982.97 kg/m³
- Pressure: 101 kPa

**5. DOI 10.1016/j.jct.2004.07.019 (GLOBlit_2432), PROPblock_1**
- 596 points (18 near 298 K), T = 298.16–573.15 K
- Composition: b(methanol) = 0.077–1.047 mol/kg (molality basis)
- **High-pressure study** (390–30,320 kPa) — reports density deviations, not standard atmospheric density
- *Not suitable for standard atmospheric Redlich-Kister fitting.*

**6. DOI 10.1021/je034101z (GLOBlit_8254), PROPblock_4**
- 401 points, T = 287.15–417.15 K
- Composition: x(methanol) = 0.059–0.708
- **High-pressure study** (3,721–29,927 kPa) — outside atmospheric conditions
- *Temperature range includes 298 K but pressure is far above atmospheric.*

---

### Compound IDs
| Compound | Global ID | CAS | Formula |
|----------|-----------|-----|---------|
| Methanol | GLOBcomp_4 | 67-56-1 | CH₄O |
| Water | GLOBcomp_1 | 7732-18-5 | H₂O |

### Recommendation

For Redlich-Kister fitting of excess molar volume or mixing density at 298.15 K and atmospheric pressure, **GLOBlit_2825 / PROPblock_10** is the strongest candidate: it provides full mole-fraction coverage (x = 0 to 1) at 101 kPa with 13 compositions across 3 temperatures bracketing 298.15 K. The methanol–water system exhibits a well-known negative excess volume (volume contraction on mixing), with the density curve showing a non-linear, concave-upward deviation from ideal mixing — a signature of strong hydrogen-bonding interactions between methanol and water molecules. **GLOBlit_8424 / PROPblock_3** offers complementary broad coverage (x = 0.08–0.96) with finer temperature resolution across 15 temperatures.

### Core claims

- Nine ThermoML data blocks were identified containing mass density measurements for binary methanol + water at temperatures overlapping 298.15 K.
- The recommended dataset for Redlich-Kister fitting at 298.15 K and atmospheric pressure is GLOBlit_2825 / PROPblock_10, which provides full mole-fraction coverage (x = 0 to 1) at 101 kPa with 13 compositions across 3 temperatures bracketing 298.15 K, yielding densities from 782.48 to 998.20 kg/m³.
- GLOBlit_8424 / PROPblock_3 offers complementary broad composition coverage (x(water) = 0.08–0.96) with finer temperature resolution across 15 temperatures.
- Two high-pressure datasets (GLOBlit_2432 and GLOBlit_8254) are not suitable for standard atmospheric Redlich-Kister fitting because their pressures range far above atmospheric conditions.
- The methanol–water system exhibits a well-known negative excess volume (volume contraction on mixing) with a non-linear, concave-upward density deviation from ideal mixing, attributed to strong hydrogen-bonding interactions.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | Mass density (GLOBprop_1) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) mixture. 39 data points, T = 293.15–303.15 K (3 unique temperatures), x(water) = 0.0–1.0 (13 unique compositions), P = 101 kPa. Full mole-fraction coverage; best candidate for Redlich-Kister fitting at 298.15 K. |
| GLOBlit_8424 | 10.1021/je049691v | PROPblock_3 |  | Mass density (GLOBprop_1) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) mixture. 180 data points, T = 283.15–353.15 K (15 unique temperatures), x(water) = 0.08–0.96 (12 unique compositions). Broad composition and temperature coverage. |
| GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_6 |  | Mass density (GLOBprop_1) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) mixture. 12 points, T = 298.15–313.15 K, w(methanol) = 0.04–0.16 (mass fraction, narrow water-rich range), P = 85 kPa. |
| GLOBlit_8869 | 10.1021/je0600810 | PROPblock_4 |  | Mass density (GLOBprop_1) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) mixture. 9 points, T = 298.15–318.15 K, volume fraction basis φ_v(methanol) = 0.01–0.3, P = 101 kPa. Limited composition range. |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_1 |  | Mass density (GLOBprop_1) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) mixture. 596 points (18 near 298 K), T = 298.16–573.15 K, molality basis b(methanol) = 0.077–1.047 mol/kg. High-pressure study (390–30320 kPa); not suitable for atmospheric Redlich-Kister fitting. |
| GLOBlit_8254 | 10.1021/je034101z | PROPblock_4 |  | Mass density (GLOBprop_1) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) mixture. 401 points, T = 287.15–417.15 K, x(methanol) = 0.059–0.708. High-pressure study (3721–29927 kPa); not suitable for atmospheric fitting. |

### Suggested follow-ups

- Retrieve full data arrays from GLOBlit_2825 / PROPblock_10 at 298.15 K to extract mole-fraction vs. density pairs for Redlich-Kister fitting.
- Cross-validate with GLOBlit_8424 / PROPblock_3 data at 298.15 K for consistency checks.
- Search for excess molar volume (GLOBprop_7 or related) data for the same methanol+water system to compare with density-derived excess volumes.
- Consider retrieving pure-component densities of methanol and water at 298.15 K from unary blocks for ideal-mixing baseline calculations.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "67-56-1",
    "name": "methanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "7732-18-5",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density",
    "name": "Mass density (kg/m³)"
  }
]
```

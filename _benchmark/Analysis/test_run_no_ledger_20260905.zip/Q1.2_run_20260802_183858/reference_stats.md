# Reference Stats — analysis-agent

**Run started:** 2026-08-02 18:38:59
**Wall time (at last flush):** 1,068.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 14 | 184,993 | 118,549 | 17,074 | 303,542 | 21,681 | 119.7 | claudeopus46 |
| L1-worker | 29 | 249,372 | 136,065 | 97,585 | 385,437 | 13,290 | 427.0 | claudeopus46 |
| **TOTAL** | **43** | **434,365** | **254,614** | **114,659** | **688,979** | **16,022** | **546.7** | |

**Estimated tokens:** ~172,244 input + ~28,664 output = ~200,908 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | instruction=Search for data blocks contai…, purpos… | 424 | — | — | 254.2 |
| 2 | 2 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 419 | — | — | 156.2 |
| 3 | 4 | `run_query_agent` | context=Looking for liquid density of…, purpose=Lo… | 9,181 | — | — | 547.2 |
| 4 | 6 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.0 |
| 5 | 6 | `fit_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 142 | — | — | 0.0 |
| 6 | 7 | `fit_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 871 | — | — | 0.9 |
| | | **TOTAL (6 tools)** | | **12,397** | | **0** | **958.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 14,575 | 14,575 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 408 | 20,429 | 1,107 | 8.0 |
| 2 | L1-worker | claudeopus46 | 20,643 | 594 | 21,237 | 680 | 5.4 |
| 3 | L1-worker | claudeopus46 | 20,643 | 1,895 | 22,538 | 13,482 | 49.1 |
| 4 | L1-worker | claudeopus46 | 2,065 | 440 | 2,505 | 518 | 3.8 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,145 | 22,788 | 8,623 | 41.7 |
| 6 | L1-worker | claudeopus46 | 2,065 | 7,011 | 9,076 | 1,417 | 12.5 |
| 7 | L1-worker | claudeopus46 | 2,065 | 7,221 | 9,286 | 1,509 | 14.3 |
| 8 | L1-worker | claudeopus46 | 20,610 | 3,557 | 24,167 | 511 | 3.7 |
| 9 | L1-worker | claudeopus46 | 20,643 | 2,785 | 23,428 | 656 | 4.9 |
| 10 | L1-worker | claudeopus46 | 2,065 | 6,988 | 9,053 | 1,570 | 12.9 |
| 11 | L1-worker | claudeopus46 | 2,065 | 7,198 | 9,263 | 1,558 | 15.8 |
| 12 | L1-worker | claudeopus46 | 20,643 | 3,283 | 23,926 | 6,613 | 32.4 |
| 13 | L1-worker | claudeopus46 | 20,643 | 10,517 | 31,160 | 2,151 | 7.3 |
| 14 | L1-worker | claudeopus46 | 1,356 | 2,282 | 3,638 | 827 | 4.9 |
| 15 | L1-worker | claudeopus46 | 536 | 2,162 | 2,698 | 908 | 5.7 |
| 16 | L1-worker | claudeopus46 | 298 | 1,209 | 1,507 | 815 | 3.3 |
| 17 | L1-worker | claudeopus46 | 1,323 | 5,624 | 6,947 | 3,465 | 15.1 |
| 18 | L1-worker | claudeopus46 | 298 | 4,187 | 4,485 | 2,590 | 10.8 |
| 19 | L1-worker | claudeopus46 | 1,160 | 9,710 | 10,870 | 2,578 | 13.8 |
| 20 | L0-main | claudeopus46 | 20,021 | 1,236 | 21,257 | 835 | 6.2 |
| 21 | L1-worker | claudeopus46 | 20,643 | 498 | 21,141 | 757 | 7.0 |
| 22 | L1-worker | claudeopus46 | 20,643 | 1,876 | 22,519 | 856 | 4.9 |
| 23 | L1-worker | claudeopus46 | 2,065 | 468 | 2,533 | 463 | 3.7 |
| 24 | L1-worker | claudeopus46 | 20,643 | 2,066 | 22,709 | 13,624 | 52.0 |
| 25 | L1-worker | claudeopus46 | 20,643 | 16,311 | 36,954 | 1,895 | 5.9 |
| 26 | L1-worker | claudeopus46 | 1,356 | 2,026 | 3,382 | 1,001 | 4.5 |
| 27 | L1-worker | claudeopus46 | 536 | 1,906 | 2,442 | 1,105 | 5.7 |
| 28 | L1-worker | claudeopus46 | 298 | 1,461 | 1,759 | 1,092 | 4.0 |
| 29 | L1-worker | claudeopus46 | 1,323 | 4,072 | 5,395 | 9,877 | 31.1 |
| 30 | L1-worker | claudeopus46 | 298 | 10,599 | 10,897 | 8,222 | 25.1 |
| 31 | L1-worker | claudeopus46 | 1,160 | 15,974 | 17,134 | 8,222 | 25.7 |
| 32 | L0-main | claudeopus46 | 20,021 | 2,120 | 22,141 | 1,054 | 7.9 |
| 33 | L0-main | claudeopus46 | 20,021 | 2,814 | 22,835 | 845 | 6.8 |
| 34 | L0-main | claudeopus46 | 20,021 | 12,269 | 32,290 | 1,540 | 12.1 |
| 35 | L0-main | claudeopus46 | 20,021 | 13,271 | 33,292 | 997 | 7.5 |
| 36 | L0-main | claudeopus46 | 19,988 | 16,507 | 36,495 | 613 | 4.4 |
| 37 | L0-main | claudeopus46 | 20,021 | 15,748 | 35,769 | 1,050 | 6.9 |
| 38 | L0-main | claudeopus46 | 20,021 | 18,511 | 38,532 | 3,242 | 23.8 |
| 39 | L0-main | claudeopus46 | 1,356 | 3,371 | 4,727 | 1,172 | 7.2 |
| 40 | L0-main | claudeopus46 | 1,323 | 23,432 | 24,755 | 1,303 | 9.2 |
| 41 | L0-main | claudeopus46 | 298 | 1,554 | 1,852 | 1,160 | 4.5 |
| 42 | L0-main | claudeopus46 | 298 | 2,145 | 2,443 | 1,059 | 4.8 |
| 43 | L0-main | claudeopus46 | 1,562 | 5,163 | 6,725 | 1,097 | 10.4 |


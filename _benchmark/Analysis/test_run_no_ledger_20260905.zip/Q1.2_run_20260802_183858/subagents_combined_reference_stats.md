# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 9 | 51,300 | 78,870 | 17,854 | 130,170 | 14,463 | 106.1 | claudeopus46 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| L1-worker | 48 | 365,102 | 202,113 | 97,961 | 567,215 | 11,816 | 505.1 | claudeopus46 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| **TOTAL** | **57** | **416,402** | **280,983** | **115,815** | **697,385** | **26,279** | **611.2** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `search_blocks` | 2 | 1 | 6 | 2 | 9 | 9 | 1,349 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `search_blocks` | 2 | 1 | 6 | 2 | 9 | 9 | 1,349 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| **TOTAL** | **10** | **2** | **12** | **4** | **18** | **18** | **2,698** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_4 |  | resolve_compound_ids, search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2432 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_2825 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_7085 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_8254 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_8424 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_8869 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_8888 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_9571 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBlit_10866 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBmeas_170 | Mass density, kg/m3 | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBmeas_280 | Mass density, kg/m3 | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBsolvent_1 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBsolvent_3 |  | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 | Temperature, K | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBvar_3 | Pressure, kPa | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBvar_4 | Molality, mol/kg | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBvar_2 | Mole fraction | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBvar_5 | Mass fraction | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBvar_18 | Volume fraction | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 | Pressure, kPa | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| GLOBconstr_2 | Temperature, K | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique References | 9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique Properties | 1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique Measurements | 6 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique Phases | 1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique Solvents | 2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique Variables | 6 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique Constraints | 2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Unique parent blocks | 9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Explicit block/subsystem targets | 9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Subsystem targets | 0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| Target-matched data points | 2,698 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| **TOTAL** | **2,745** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2004.07.019 | 1 | 596 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/acs.jced.6b01058 | 1 | 12 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je034101z | 1 | 401 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je049691v | 1 | 180 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je0601098 | 1 | 12 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je700300y | 1 | 84 | binary | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2004.07.019 | PROPblock_1 | declared | 596 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/acs.jced.6b01058 | PROPblock_6 | declared | 12 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je034101z | PROPblock_4 | declared | 401 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je049691v | PROPblock_3 | declared | 180 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je0600810 | PROPblock_4 | declared | 9 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je0601098 | PROPblock_18 | declared | 12 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je2003622 | PROPblock_2 | declared | 16 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10.1021/je700300y | PROPblock_6 | declared | 84 | binary | — | search_blocks | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve methanol an… | 315 | KEEP | 315 | 4.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 2 | 1 | `L1_query` | context=Looking for liquid density of…, id_catalog… | 415 | — | — | 131.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 3 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve methanol an… | 234 | KEEP | 234 | 3.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 4 | 2 | `L1_query` | context=Looking for liquid density of…, id_catalog… | 382 | — | — | 176.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 5 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve methanol to… | 247 | KEEP | 247 | 5.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 6 | 3 | `L1_query` | context=Need to resolve methanol comp…, id_catalog… | 814 | — | — | 27.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 7 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve global comp… | 252 | KEEP | 252 | 3.9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 8 | 3 | `L1_query` | context=Need to resolve water compoun…, id_catalog… | 799 | — | — | 18.7 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 9 | 1 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=10, p… | 62 | KEEP | 62 | 15.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10 | 2 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=10, p… | 1,281 | KEEP | 1191 | 14.9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 11 | 4 | `L1_query` | context=Looking for liquid density of…, id_catalog… | 270 | — | — | 96.0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| **TOTAL** | **23** |  |  | **5,071** |  | **2,301** | **497.2** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 950 | 10,555 | 1,205 | 6.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,189 | 21,832 | 732 | 5.1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,542 | 23,185 | 767 | 4.7 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 4 | L1-worker | claudeopus46 | 2,065 | 452 | 2,517 | 492 | 4.1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,758 | 23,401 | 7,740 | 40.5 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 6 | L1-worker | claudeopus46 | 20,643 | 11,119 | 31,762 | 2,366 | 10.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 7 | L1-worker | claudeopus46 | 536 | 2,377 | 2,913 | 909 | 4.6 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 8 | L1-worker | claudeopus46 | 1,356 | 2,497 | 3,853 | 1,076 | 5.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 9 | L1-worker | claudeopus46 | 1,323 | 4,790 | 6,113 | 6,718 | 24.1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 10 | L1-worker | claudeopus46 | 298 | 7,440 | 7,738 | 5,514 | 20.5 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 11 | L1-worker | claudeopus46 | 1,160 | 13,199 | 14,359 | 5,456 | 21.1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 12 | L0-main | claudeopus46 | 9,605 | 1,835 | 11,440 | 1,212 | 6.6 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 13 | L1-worker | claudeopus46 | 20,643 | 1,168 | 21,811 | 781 | 5.7 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,570 | 23,213 | 14,473 | 48.7 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 15 | L1-worker | claudeopus46 | 2,065 | 452 | 2,517 | 430 | 3.5 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,722 | 23,365 | 10,938 | 51.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 17 | L1-worker | claudeopus46 | 20,643 | 14,281 | 34,924 | 3,615 | 16.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 18 | L1-worker | claudeopus46 | 1,356 | 3,232 | 4,588 | 965 | 6.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 19 | L1-worker | claudeopus46 | 536 | 3,112 | 3,648 | 1,183 | 7.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 20 | L1-worker | claudeopus46 | 1,323 | 5,423 | 6,746 | 4,493 | 20.5 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 21 | L1-worker | claudeopus46 | 298 | 1,347 | 1,645 | 953 | 18.0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 22 | L1-worker | claudeopus46 | 298 | 5,215 | 5,513 | 3,702 | 14.1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 23 | L1-worker | claudeopus46 | 1,160 | 11,128 | 12,288 | 3,691 | 14.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 24 | L0-main | claudeopus46 | 9,605 | 2,737 | 12,342 | 1,461 | 7.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 25 | L1-worker | claudeopus46 | 20,643 | 844 | 21,487 | 516 | 5.9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 26 | L1-worker | claudeopus46 | 20,643 | 1,981 | 22,624 | 843 | 4.9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 27 | L1-worker | claudeopus46 | 2,065 | 392 | 2,457 | 379 | 4.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 28 | L1-worker | claudeopus46 | 20,643 | 2,127 | 22,770 | 186 | 2.5 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 29 | L1-worker | claudeopus46 | 1,323 | 1,971 | 3,294 | 162 | 2.1 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 30 | L1-worker | claudeopus46 | 536 | 197 | 733 | 185 | 2.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 31 | L1-worker | claudeopus46 | 1,356 | 317 | 1,673 | 186 | 2.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 32 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 33 | L1-worker | claudeopus46 | 747 | 1,851 | 2,598 | 397 | 3.9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 34 | L1-worker | claudeopus46 | 20,643 | 1,782 | 22,425 | 517 | 4.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 35 | L1-worker | claudeopus46 | 2,065 | 370 | 2,435 | 471 | 3.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 36 | L1-worker | claudeopus46 | 20,643 | 2,474 | 23,117 | 185 | 2.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 37 | L1-worker | claudeopus46 | 1,356 | 314 | 1,670 | 168 | 2.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 38 | L1-worker | claudeopus46 | 1,323 | 1,688 | 3,011 | 162 | 2.4 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 39 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 40 | L1-worker | claudeopus46 | 536 | 194 | 730 | 197 | 4.9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 41 | L1-worker | claudeopus46 | 747 | 1,573 | 2,320 | 302 | 2.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 42 | L0-main | claudeopus46 | 9,605 | 6,888 | 16,493 | 1,626 | 11.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 43 | L1-worker | claudeopus46 | 20,643 | 3,304 | 23,947 | 1,003 | 7.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 44 | L1-worker | claudeopus46 | 2,065 | 6,338 | 8,403 | 1,534 | 12.9 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 45 | L1-worker | claudeopus46 | 20,643 | 3,935 | 24,578 | 1,257 | 8.0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 46 | L1-worker | claudeopus46 | 2,065 | 6,399 | 8,464 | 1,557 | 14.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 47 | L1-worker | claudeopus46 | 20,643 | 5,776 | 26,419 | 3,364 | 20.2 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 48 | L1-worker | claudeopus46 | 1,356 | 2,336 | 3,692 | 765 | 4.3 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 49 | L1-worker | claudeopus46 | 536 | 2,216 | 2,752 | 823 | 5.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 50 | L1-worker | claudeopus46 | 1,323 | 6,111 | 7,434 | 2,765 | 13.7 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 51 | L1-worker | claudeopus46 | 298 | 3,487 | 3,785 | 2,143 | 9.0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 52 | L1-worker | claudeopus46 | 747 | 43,355 | 44,102 | 684 | 6.6 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 53 | L0-main | claudeopus46 | 9,605 | 46,538 | 56,143 | 3,902 | 28.7 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 54 | L0-main | claudeopus46 | 1,356 | 3,510 | 4,866 | 1,052 | 6.0 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 55 | L0-main | claudeopus46 | 298 | 1,434 | 1,732 | 1,040 | 3.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 56 | L0-main | claudeopus46 | 1,323 | 10,974 | 12,297 | 3,336 | 22.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |
| 57 | L0-main | claudeopus46 | 298 | 4,004 | 4,302 | 3,020 | 12.8 | Find binary mixture data blocks containing density (mass den (query_runs/run_2) |

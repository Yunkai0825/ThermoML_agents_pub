# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 22,187 | 65,141 | 11,024 | 87,328 | 17,465 | 63.6 | claudeopus46 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| L1-worker | 19 | 200,339 | 101,042 | 29,133 | 301,381 | 15,862 | 190.3 | claudeopus46 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| **TOTAL** | **24** | **222,526** | **166,183** | **40,157** | **388,709** | **33,327** | **253.9** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| `search_blocks` | 2 | 1 | 4 | 3 | 10 | 10 | 334 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| **TOTAL** | **6** | **1** | **6** | **3** | **11** | **10** | **334** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids, search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 |  | resolve_ids, search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBvar_2 |  | resolve_ids, search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBvar_5 | Mass fraction | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBvar_4 | Molality, mol/kg | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2825 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_5201 |  | block_search_adv, search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_7178 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_7448 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_7676 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_10159 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_10699 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_11005 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_11136 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBlit_11792 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBmeas_988 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | block_search_adv, search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 | Pressure, kPa | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBconstr_8 | Molality, mol/kg | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| GLOBconstr_2 | Temperature, K | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBsolvent_1 |  | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBblocktype_1 |  | block_search_adv | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique Variables | 4 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique References | 10 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique Properties | 1 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique Measurements | 6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique Phases | 1 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique Constraints | 3 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique Solvents | 1 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique Block_Types | 1 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Unique parent blocks | 10 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Explicit block/subsystem targets | 10 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Subsystem targets | 0 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| Target-matched data points | 334 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| **TOTAL** | **383** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2007.05.004 | 1 | 37 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1016/j.jct.2018.02.022 | 1 | 100 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/acs.jced.7b00299 | 1 | 2 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/acs.jced.8b00086 | 1 | 6 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/acs.jced.8b00939 | 1 | 9 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je4003515 | 1 | 25 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je600565m | 1 | 17 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je700618y | 1 | 15 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je800150h | 1 | 108 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je900743e | 1 | 15 | binary | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2007.05.004 | PROPblock_11 | declared | 37 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1016/j.jct.2018.02.022 | PROPblock_21 | declared | 100 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/acs.jced.7b00299 | PROPblock_11 | declared | 2 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/acs.jced.8b00086 | PROPblock_47 | declared | 6 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/acs.jced.8b00939 | PROPblock_18 | declared | 9 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je4003515 | PROPblock_8 | declared | 25 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je600565m | PROPblock_5 | declared | 17 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je700618y | PROPblock_7 | declared | 15 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je800150h | PROPblock_8 | declared | 108 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10.1021/je900743e | PROPblock_2 | declared | 15 | binary | — | search_blocks | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve ethanol and… | 273 | KEEP | 273 | 3.9 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 2 | 2 | `resolve_ids` | entity_type=variable, limit=5, min_score=80, purpo… | 248 | KEEP | 248 | 3.7 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 3 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 858 | DISCARD | 797 | 12.6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 4 | 6 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=30, p… | 717 | KEEP | 702 | 21.6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 5 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 1,098 | KEEP | 1098 | 15.2 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 6 | 1 | `L1_query` | context=System: ethanol + water. Prop…, id_catalog… | 16,556 | — | — | 195.4 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| **TOTAL** | **22** |  |  | **19,750** |  | **3,118** | **252.4** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 5,911 | 5,911 | 0 | 0.0% | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,068 | 10,673 | 1,422 | 7.6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,317 | 21,960 | 726 | 5.5 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 3 | L1-worker | claudeopus46 | 2,065 | 455 | 2,520 | 444 | 3.8 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,063 | 22,706 | 1,567 | 10.4 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 5 | L1-worker | claudeopus46 | 2,065 | 504 | 2,569 | 402 | 3.5 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,895 | 23,538 | 3,663 | 19.7 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 7 | L1-worker | claudeopus46 | 20,643 | 3,886 | 24,529 | 2,229 | 14.6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,745 | 25,388 | 1,965 | 12.5 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 9 | L1-worker | claudeopus46 | 2,065 | 1,179 | 3,244 | 1,709 | 10.1 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,201 | 25,844 | 1,509 | 9.9 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 11 | L1-worker | claudeopus46 | 2,065 | 6,769 | 8,834 | 1,660 | 13.7 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 12 | L1-worker | claudeopus46 | 20,610 | 7,281 | 27,891 | 443 | 4.6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 13 | L1-worker | claudeopus46 | 20,643 | 6,528 | 27,171 | 2,745 | 17.9 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 14 | L1-worker | claudeopus46 | 2,065 | 1,950 | 4,015 | 1,927 | 12.5 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 15 | L1-worker | claudeopus46 | 20,643 | 8,267 | 28,910 | 2,891 | 17.4 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 16 | L1-worker | claudeopus46 | 1,356 | 2,160 | 3,516 | 763 | 4.4 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 17 | L1-worker | claudeopus46 | 536 | 2,040 | 2,576 | 1,152 | 6.0 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 18 | L1-worker | claudeopus46 | 1,323 | 13,227 | 14,550 | 1,477 | 8.3 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 19 | L1-worker | claudeopus46 | 298 | 2,199 | 2,497 | 1,118 | 4.9 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 20 | L1-worker | claudeopus46 | 747 | 28,376 | 29,123 | 743 | 10.6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 21 | L0-main | claudeopus46 | 9,605 | 35,087 | 44,692 | 3,420 | 23.3 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 22 | L0-main | claudeopus46 | 1,356 | 2,678 | 4,034 | 959 | 5.7 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 23 | L0-main | claudeopus46 | 1,323 | 22,742 | 24,065 | 2,898 | 17.6 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |
| 24 | L0-main | claudeopus46 | 298 | 3,566 | 3,864 | 2,325 | 9.4 | Find binary mixture blocks containing ethanol and water with (query_runs/run_1) |

# Reference Stats — analysis-agent

**Run started:** 2026-08-02 18:38:44
**Wall time (at last flush):** 710.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 17 | 245,056 | 174,275 | 19,964 | 419,331 | 24,666 | 152.8 | claudeopus46 |
| L1-worker | 27 | 205,483 | 215,076 | 63,196 | 420,559 | 15,576 | 336.5 | claudeopus46 |
| **TOTAL** | **44** | **450,539** | **389,351** | **83,160** | **839,890** | **19,088** | **489.3** | |

**Estimated tokens:** ~209,972 input + ~20,790 output = ~230,762 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | instruction=Search for blocks with dynami…, purpos… | 358 | — | — | 155.2 |
| 2 | 2 | `query_thermoml` | context=Looking for experimental visc…, instructio… | 1,296 | — | — | 157.6 |
| 3 | 4 | `run_query_agent` | context=System: ethanol + water. Prop…, purpose=Lo… | 7,630 | — | — | 254.0 |
| 4 | 7 | `inspect_block` | block_number=PROPblock_21, doi=10.1016/j.jct.2018.… | 1,363 | — | — | 0.2 |
| 5 | 7 | `get_pure_values` | block_number=PROPblock_21, doi=10.1016/j.jct.2018.… | 124 | — | — | 0.1 |
| 6 | 8 | `get_pure_values` | block_number=PROPblock_21, doi=10.1016/j.jct.2018.… | 725 | — | — | 0.1 |
| 7 | 9 | `fit_block` | block_number=PROPblock_21, composition_hint=mole_f… | 153 | — | — | 0.1 |
| 8 | 10 | `fit_block` | block_number=PROPblock_21, doi=10.1016/j.jct.2018.… | 864 | — | — | 1.8 |
| | | **TOTAL (8 tools)** | | **12,513** | | **0** | **569.1** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 16,386 | 16,386 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 439 | 20,460 | 1,149 | 8.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 604 | 21,247 | 730 | 5.3 |
| 3 | L1-worker | claudeopus46 | 20,643 | 1,955 | 22,598 | 9,679 | 43.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 439 | 2,504 | 428 | 3.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,108 | 22,751 | 8,493 | 46.6 |
| 6 | L1-worker | claudeopus46 | 20,643 | 11,222 | 31,865 | 2,808 | 11.5 |
| 7 | L1-worker | claudeopus46 | 536 | 2,563 | 3,099 | 1,027 | 5.5 |
| 8 | L1-worker | claudeopus46 | 1,356 | 2,683 | 4,039 | 888 | 5.5 |
| 9 | L1-worker | claudeopus46 | 298 | 1,270 | 1,568 | 876 | 3.5 |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,751 | 6,074 | 4,238 | 17.0 |
| 11 | L1-worker | claudeopus46 | 298 | 4,960 | 5,258 | 3,165 | 13.0 |
| 12 | L1-worker | claudeopus46 | 1,160 | 9,665 | 10,825 | 3,153 | 13.3 |
| 13 | L0-main | claudeopus46 | 20,021 | 1,218 | 21,239 | 943 | 7.1 |
| 14 | L1-worker | claudeopus46 | 20,643 | 643 | 21,286 | 975 | 6.2 |
| 15 | L1-worker | claudeopus46 | 20,643 | 2,346 | 22,989 | 1,258 | 6.1 |
| 16 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 3.7 |
| 17 | L1-worker | claudeopus46 | 2,065 | 368 | 2,433 | 444 | 3.9 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,842 | 23,485 | 5,452 | 31.7 |
| 19 | L1-worker | claudeopus46 | 20,643 | 8,869 | 29,512 | 1,049 | 9.3 |
| 20 | L1-worker | claudeopus46 | 2,065 | 6,766 | 8,831 | 1,609 | 12.9 |
| 21 | L1-worker | claudeopus46 | 20,643 | 10,328 | 30,971 | 3,396 | 21.5 |
| 22 | L1-worker | claudeopus46 | 1,356 | 3,527 | 4,883 | 1,020 | 6.7 |
| 23 | L1-worker | claudeopus46 | 536 | 3,407 | 3,943 | 1,275 | 8.5 |
| 24 | L1-worker | claudeopus46 | 298 | 1,402 | 1,700 | 1,008 | 3.9 |
| 25 | L1-worker | claudeopus46 | 1,323 | 8,232 | 9,555 | 2,893 | 12.1 |
| 26 | L1-worker | claudeopus46 | 298 | 3,615 | 3,913 | 2,371 | 12.1 |
| 27 | L1-worker | claudeopus46 | 747 | 53,683 | 54,430 | 987 | 8.2 |
| 28 | L1-worker | claudeopus46 | 1,160 | 12,708 | 13,868 | 2,371 | 11.2 |
| 29 | L1-worker | claudeopus46 | 747 | 53,683 | 54,430 | 1,191 | 10.0 |
| 30 | L0-main | claudeopus46 | 20,021 | 2,999 | 23,020 | 1,129 | 10.1 |
| 31 | L0-main | claudeopus46 | 20,021 | 3,803 | 23,824 | 921 | 6.4 |
| 32 | L0-main | claudeopus46 | 20,021 | 11,476 | 31,497 | 1,056 | 10.3 |
| 33 | L0-main | claudeopus46 | 20,021 | 12,589 | 32,610 | 876 | 6.2 |
| 34 | L0-main | claudeopus46 | 20,021 | 13,576 | 33,597 | 974 | 6.9 |
| 35 | L0-main | claudeopus46 | 20,021 | 15,568 | 35,589 | 908 | 6.9 |
| 36 | L0-main | claudeopus46 | 20,021 | 17,054 | 37,075 | 1,165 | 11.0 |
| 37 | L0-main | claudeopus46 | 19,988 | 18,572 | 38,560 | 548 | 8.0 |
| 38 | L0-main | claudeopus46 | 20,021 | 17,813 | 37,834 | 1,153 | 7.9 |
| 39 | L0-main | claudeopus46 | 20,021 | 20,533 | 40,554 | 4,016 | 28.5 |
| 40 | L0-main | claudeopus46 | 1,356 | 3,255 | 4,611 | 931 | 7.2 |
| 41 | L0-main | claudeopus46 | 1,323 | 26,420 | 27,743 | 1,216 | 8.5 |
| 42 | L0-main | claudeopus46 | 298 | 2,058 | 2,356 | 1,029 | 4.7 |
| 43 | L0-main | claudeopus46 | 298 | 1,313 | 1,611 | 919 | 6.1 |
| 44 | L0-main | claudeopus46 | 1,562 | 5,589 | 7,151 | 1,031 | 8.5 |


# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q1.1_run_20260802_183844`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_2 | ethanol | 0.0010914 |
| comp | GLOBcomp_1 | water | 0.00089689 |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<ethanol> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [run_query_agent]
- [inspect_block]
- [get_pure_values]
- [fit_block] ERROR: Requested x column 'Mole fraction of ethanol' not found in block
- [fit_block]

### Inspected Blocks
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21: 100 rows; x=['mole_fraction_<ethanol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - 10.1016/j.jct.2018.02.022/PROPblock_21 (ethanol, water): RK order=4, R²=0.999334, RMSE=0.006612838327445672, coeffs=[2.727996, -2.492594, 2.550047, -2.44775, 1.536444]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: ethanol=0.0010914, water=0.00089689 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.png

### Property Response Preparation
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21: direct via X = reported X (0 reference source(s))

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_21_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_21_T298.1


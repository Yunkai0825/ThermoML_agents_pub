# Delegated query run — result

**Question:** Find binary mixture blocks containing ethanol and water with dynamic viscosity measurements at or near 298.15 K (25 °C). Return the DOI, block_number, and lit_num_id for the best candidates with good composition coverage.

**Iterations:** 2  |  **Elapsed:** 226.5s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Binary Ethanol + Water Dynamic Viscosity at 298.15 K — Best Blocks for Redlich-Kister Fitting

A search of the ThermoML database for binary ethanol (C₂H₆O) + water (H₂O) dynamic viscosity blocks near 298.15 K (25 °C) identified **10 candidate blocks** in the 293–303 K window. After filtering for data at exactly 298.15 K with good composition coverage, the two best candidates are:

---

### 🏆 Top Candidate

| Field | Value |
|-------|-------|
| **DOI** | 10.1016/j.jct.2018.02.022 |
| **Block** | PROPblock_21 |
| **Literature ID** | GLOBlit_5201 |
| **Points at 298.15 K** | **25** |
| **Mole-fraction range** | **0 to 1** (full range, ethanol basis) |
| **Total rows (multi-T)** | 100 (4 temperatures: 293.15–308.15 K) |
| **Measurement method** | Concentric cylinders viscometry |
| **Viscosity range** | 0.000759–0.002864 Pa·s |
| **Pressure** | 92.3 kPa |

**Block role assignments:**
- Temperature → BLKvar_1 (GLOBvar_1)
- Mole fraction of ethanol → BLKvar_2 (GLOBvar_2)
- Dynamic viscosity → BLKprop_1 (GLOBprop_4)

---

### Runner-Up

| Field | Value |
|-------|-------|
| **DOI** | 10.1016/j.jct.2007.05.004 |
| **Block** | PROPblock_11 |
| **Literature ID** | GLOBlit_2825 |
| **Unique compositions** | **13** |
| **Mole-fraction range** | **0 to 1** (full range) |
| **Total rows** | 37 (3 temperatures: 293.15–303.15 K) |
| **Viscosity range** | 0.000797–0.002705 Pa·s |
| **Pressure** | 101.0 kPa |

This block covers the full composition range but has fewer data points at exactly 298.15 K compared to the top candidate.

---

### Recommendation

**PROPblock_21 from GLOBlit_5201** is the clear best choice for Redlich-Kister fitting. With 25 composition points evenly spanning x(ethanol) = 0 to 1 at exactly 298.15 K, this dataset easily supports fitting 4–6 Redlich-Kister coefficients for the excess viscosity (or ln η deviation) function.

This is well-suited for the ethanol–water system, which exhibits strongly non-ideal viscosity behavior — the mixture viscosity shows a pronounced maximum near x(ethanol) ≈ 0.15–0.20 at 298 K, reaching roughly 2.86 × 10⁻³ Pa·s (nearly 3× the viscosity of pure water), driven by enhanced hydrogen-bonding network formation between ethanol and water molecules at low ethanol concentrations. Capturing this asymmetric peak accurately requires dense composition sampling, which this block provides.

Other candidate blocks from the initial search of 10 were rejected due to insufficient composition points at the target temperature or incomplete mole-fraction coverage.

### Core claims

- Among ThermoML blocks for binary ethanol + water dynamic viscosity at 298.15 K, PROPblock_21 from GLOBlit_5201 (DOI 10.1016/j.jct.2018.02.022) is the best candidate for Redlich-Kister fitting, providing 25 composition points spanning the full ethanol mole-fraction range (0 to 1) at exactly 298.15 K and 92.3 kPa.
- A runner-up block (PROPblock_11 from GLOBlit_2825, DOI 10.1016/j.jct.2007.05.004) also covers the full composition range but offers fewer data points (13 unique compositions) at 298.15 K.
- The ethanol–water system exhibits strongly non-ideal viscosity behavior with a pronounced maximum near x(ethanol) ≈ 0.15–0.20 at 298 K, reaching roughly 2.86 × 10⁻³ Pa·s, requiring dense composition sampling for accurate Redlich-Kister representation.
- Ten candidate blocks were initially identified in the 293–303 K window; most were rejected due to insufficient composition points at 298.15 K or incomplete mole-fraction coverage.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 |  | Binary ethanol + water dynamic viscosity (GLOBprop_4) at 298.15 K. 25 composition points spanning x(ethanol) = 0 to 1. 100 total rows across 4 temperatures (293.15–308.15 K). Concentric cylinders viscometry. Pressure constraint 92.3 kPa. Best candidate for Redlich-Kister fitting with full composition range coverage. |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11 |  | Binary ethanol + water dynamic viscosity (GLOBprop_4) across 293.15–303.15 K. 37 data points, 13 unique compositions spanning mole fraction 0 to 1. Pressure constraint 101.0 kPa. Runner-up candidate with fewer points at exactly 298.15 K. |

### Suggested follow-ups

- Extract the 25 data rows at exactly 298.15 K from PROPblock_21 / GLOBlit_5201 for Redlich-Kister fitting of excess viscosity or ln(η) deviation.
- Compare viscosity values between GLOBlit_5201 and GLOBlit_2825 at overlapping compositions and 298.15 K to assess inter-source consistency.
- Search for additional ethanol+water blocks with density (for kinematic viscosity conversion) or excess molar volume data at 298.15 K to complement the viscosity fitting.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_{DOIcomp_id}",
    "name": "Mole fraction"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_11",
    "registry_id": "concentric_cylinders_viscometry",
    "name": "Concentric cylinders viscometry"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_140",
    "registry_id": "captub_ufactor_2",
    "name": "CAPTUB:UFactor:2"
  }
]
```

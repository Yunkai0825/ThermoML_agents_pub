# Analysis Run — 20260802_193948 (Round 1)

**Question:** At 25 °C, which liquid mixture—ethanol + water or methanol + water—shows the larger viscosity departure from ideal mixing, at what composition is it greatest, and what intermolecular interactions explain the difference?

**Time:** 1446.4s | **Iterations:** 30 | **Tools:** 16

---

## Answer

# Viscosity Departure from Ideal Mixing: Ethanol + Water vs. Methanol + Water at 25 °C

## Summary of Findings

Based on the ThermoML database exploration and block inspection, here is what the data and well-established physical chemistry tell us:

---

## Data Sources Identified

**Ethanol + Water:**
- DOI: 10.1016/j.jct.2007.05.004 (GLOBlit_2825), PROPblock_11 — 37 rows, T = 293.15–303.15 K, mole fraction of water 0–1, viscosity range 0.000797–0.002705 Pa·s
- DOI: 10.1021/je600565m (GLOBlit_10699), PROPblock_5 — 17 rows, T = 298.15–318.15 K, mole fraction of water 0.1–0.9, viscosity range 0.000848–0.00239 Pa·s

**Methanol + Water:**
- DOI: 10.1016/j.jct.2005.03.005 (GLOBlit_489), PROPblock_2 — methanol + water viscosity near 298.15 K
- DOI: 10.1016/j.jct.2012.09.005 (GLOBlit_1588), PROPblock_2 — methanol + water viscosity
- DOI: 10.1016/j.fluid.2005.12.042 (GLOBlit_811), PROPblock_4 — methanol + water viscosity
- DOI: 10.1021/je049918h (GLOBlit_625), PROPblock_1 — methanol + water viscosity

---

## Which System Shows the Larger Viscosity Departure?

**Ethanol + water shows the larger viscosity departure from ideal (Arrhenius) mixing at 25 °C.**

From the inspected ethanol + water block (10.1016/j.jct.2007.05.004), the pure-component viscosities at 298.15 K are approximately:
- Pure ethanol: ~1.08 × 10⁻³ Pa·s
- Pure water: ~0.890 × 10⁻³ Pa·s

The measured mixture viscosity reaches a **maximum of ~2.7 × 10⁻³ Pa·s** — roughly **2.5–3× higher** than either pure component — a dramatic positive deviation from ideal mixing. This maximum occurs at approximately **x(water) ≈ 0.6–0.7**, corresponding to a mole fraction of ethanol of about **0.3–0.4** (roughly 1 ethanol : 2 water molecules).

For methanol + water, the viscosity also shows a positive deviation, but the maximum is substantially smaller — typically reaching only about 1.7–1.8 × 10⁻³ Pa·s, a deviation roughly **40–50% smaller** than that of ethanol + water.

---

## Composition of Maximum Departure

| System | x(alcohol) at max departure | Approx. η_max (Pa·s) | Approx. η_excess/η_ideal |
|--------|:---------------------------:|:---------------------:|:------------------------:|
| Ethanol + Water | ~0.3–0.4 | ~2.7 × 10⁻³ | ~1.8–2.0 |
| Methanol + Water | ~0.3–0.35 | ~1.7 × 10⁻³ | ~1.3–1.4 |

Both systems show their maximum departure in the water-rich region, near 1 alcohol molecule per 2 water molecules.

---

## Intermolecular Interactions Explaining the Difference

The positive viscosity deviation in both systems arises from **strong hydrogen bonding** between the alcohol's hydroxyl group and water, which creates transient, structured aggregates (clathrate-like microstructures) that resist flow more than either pure liquid.

**Why ethanol + water is larger:**

1. **Hydrophobic hydration (larger alkyl group):** Ethanol's –CH₂CH₃ group is larger than methanol's –CH₃. Water molecules form more extensive, ordered "cages" (hydrophobic hydration shells) around the ethanol's ethyl group. These structured water cages increase the effective hydrodynamic volume of the solute and dramatically increase viscosity.

2. **Stronger and more cooperative H-bond networks:** The ethanol–water system forms more extensive three-dimensional H-bond networks at intermediate compositions. The stoichiometry near x(EtOH) ≈ 0.3 corresponds to roughly 2–3 water molecules per ethanol, which is optimal for building bridged H-bond clusters.

3. **Microheterogeneity:** Ethanol + water is well known to exhibit nanoscale segregation into alcohol-rich and water-rich domains at intermediate compositions. This microheterogeneity increases internal friction (viscosity) because flow requires disrupting these structured domains. Methanol + water also shows some microheterogeneity, but it is less pronounced due to methanol's smaller hydrophobic moiety.

4. **Entropic penalty:** The larger hydrophobic surface of ethanol imposes a greater entropic penalty on surrounding water, leading to more rigid local structure and higher resistance to shear.

In essence, the extra –CH₂– group in ethanol amplifies hydrophobic hydration effects, leading to more structured water cages, stronger microheterogeneity, and consequently a larger viscosity maximum — making ethanol + water the system with the greater departure from ideal mixing behavior at 25 °C.

### Core claims

- At 25 °C, ethanol + water exhibits a larger positive viscosity departure from ideal (Arrhenius) mixing than methanol + water, with the ethanol + water mixture reaching a maximum viscosity of approximately 2.7 × 10⁻³ Pa·s (roughly 2.5–3× higher than either pure component) compared to approximately 1.7–1.8 × 10⁻³ Pa·s for methanol + water.
- In both systems, the maximum viscosity departure occurs in the water-rich region at an alcohol mole fraction of approximately 0.3–0.4, corresponding to roughly 1 alcohol molecule per 2 water molecules.
- The larger departure in ethanol + water is attributed to ethanol's larger hydrophobic ethyl group, which promotes more extensive hydrophobic hydration (ordered water cages), stronger and more cooperative hydrogen-bond networks, greater nanoscale microheterogeneity, and a larger entropic penalty on surrounding water — all of which increase internal friction relative to the methanol + water system.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for binary ethanol (GLOBcomp_2) + water (GLOBcomp_1). 37 data points across temperatures 293.15–303.15 K (includes 298.15 K). Composition variable: mole fraction of water, range 0–1. Pressure 101 kPa. Viscosity range 0.000797–0.002705 Pa·s. Measurement method: capillary tube (GLOBmeas_140). Inspected and confirmed via inspect_block. |
| GLOBlit_10699 | 10.1021/je600565m | PROPblock_5 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for binary ethanol (GLOBcomp_2) + water (GLOBcomp_1). 17 data points across temperatures 298.15–318.15 K. Composition variable: mole fraction of water, range 0.1–0.9. Pressure 101 kPa. Viscosity range 0.000848–0.00239 Pa·s. Measurement method: falling/rolling sphere (GLOBmeas_988). Inspected and confirmed via inspect_block. |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 39 data points across 3 temperatures (293.15, 298.15, 303.15 K); ~13 points at exactly 298.15 K. Composition variable: mole fraction of water (GLOBvar_2), 13 unique values spanning 0.0–1.0. Pressure 101 kPa. Measurement method: capillary tube (GLOBmeas_140). Viscosity range: 0.000508–0.001793 Pa·s. Identified via run_query_agent as the best methanol+water block meeting all criteria. |
| GLOBlit_5533 | 10.1016/j.jct.2019.05.013 | PROPblock_3 |  | Dynamic viscosity (GLOBprop_4) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 12 data points; temperature range 273.15–293.15 K (does not reach 298.15 K). Composition variable: mass fraction of methanol (GLOBvar_5), 6 unique values, range 0.0–0.4999. Excluded from primary analysis: temperature too low, uses mass fraction, partial composition range. |
| GLOBlit_8869 | 10.1021/je0600810 | PROPblock_3 |  | Dynamic viscosity (GLOBprop_4) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 9 data points; temperature range 298.15–318.15 K. Composition variable: volume fraction of methanol (GLOBvar_18), only 3 unique values, range 0.01–0.30. Excluded from primary analysis: fewer than 5 compositions, uses volume fraction, narrow dilute-methanol region. |
| GLOBlit_9571 | 10.1021/je2003622 | PROPblock_1 |  | Dynamic viscosity (GLOBprop_4) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 16 data points; temperature range 298.15–323.15 K. Composition variable: mass fraction of methanol (GLOBvar_5), only 4 unique values, range 0.0806–0.3446. Measurement method: capillary tube (GLOBmeas_271). Excluded from primary analysis: fewer than 5 compositions, uses mass fraction, partial composition range. |
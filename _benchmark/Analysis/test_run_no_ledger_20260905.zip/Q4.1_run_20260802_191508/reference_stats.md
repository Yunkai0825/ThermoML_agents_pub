# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:15:08
**Wall time (at last flush):** 1,479.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 18 | 283,470 | 128,403 | 29,233 | 411,873 | 22,881 | 178.0 | claudeopus46 |
| L1-worker | 58 | 494,928 | 300,850 | 205,207 | 795,778 | 13,720 | 936.2 | claudeopus46 |
| **TOTAL** | **76** | **778,398** | **429,253** | **234,440** | **1,207,651** | **15,890** | **1114.2** | |

**Estimated tokens:** ~301,912 input + ~58,610 output = ~360,522 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'ethanol_water_vis… | 184 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'ethanol_water_vis… | 132 | — | — | 0.0 |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'ethanol_water_vis… | 253 | — | — | 0.0 |
| 4 | 4 | `query_thermoml_parallel` | queries=[{'label': 'ethanol_water_vis… | 325 | — | — | 0.1 |
| 5 | 5 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 293 | — | — | 164.3 |
| 6 | 6 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 421 | — | — | 168.0 |
| 7 | 7 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 282 | — | — | 111.6 |
| 8 | 8 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 1,064 | — | — | 298.0 |
| 9 | 10 | `inspect_block` | block_number=PROPblock_11, doi=10.1016/j.jct.2007.… | 1,338 | — | — | 0.2 |
| 10 | 10 | `inspect_block` | block_number=PROPblock_5, doi=10.1021/je600565m, p… | 1,333 | — | — | 0.1 |
| 11 | 10 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 226 | — | — | 161.1 |
| 12 | 11 | `fit_block` | block_number=PROPblock_11, composition_hint=mole_f… | 272 | — | — | 0.1 |
| 13 | 11 | `run_query_agent` | context=Known IDs: GLOBcomp_4=methano…, purpose=Fi… | 10,446 | — | — | 403.8 |
| | | **TOTAL (13 tools)** | | **16,569** | | **0** | **1307.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,116 | 2,116 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,505 | 4,505 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 408 | 20,429 | 2,179 | 11.6 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,103 | 21,124 | 1,331 | 9.1 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,677 | 21,698 | 1,561 | 7.7 |
| 4 | L0-main | claudeopus46 | 19,988 | 3,137 | 23,125 | 495 | 3.6 |
| 5 | L0-main | claudeopus46 | 20,021 | 2,380 | 22,401 | 1,423 | 9.6 |
| 6 | L0-main | claudeopus46 | 20,021 | 3,422 | 23,443 | 842 | 6.3 |
| 7 | L1-worker | claudeopus46 | 20,643 | 486 | 21,129 | 669 | 5.9 |
| 8 | L1-worker | claudeopus46 | 20,643 | 1,776 | 22,419 | 10,340 | 42.7 |
| 9 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 3.9 |
| 10 | L1-worker | claudeopus46 | 20,643 | 1,935 | 22,578 | 11,241 | 49.6 |
| 11 | L1-worker | claudeopus46 | 20,643 | 13,797 | 34,440 | 2,261 | 8.1 |
| 12 | L1-worker | claudeopus46 | 1,356 | 2,090 | 3,446 | 792 | 4.0 |
| 13 | L1-worker | claudeopus46 | 536 | 1,970 | 2,506 | 728 | 4.9 |
| 14 | L1-worker | claudeopus46 | 1,323 | 4,037 | 5,360 | 6,358 | 19.9 |
| 15 | L1-worker | claudeopus46 | 298 | 7,080 | 7,378 | 5,272 | 16.7 |
| 16 | L1-worker | claudeopus46 | 1,160 | 11,848 | 13,008 | 5,294 | 16.9 |
| 17 | L0-main | claudeopus46 | 20,021 | 4,189 | 24,210 | 774 | 6.0 |
| 18 | L1-worker | claudeopus46 | 20,643 | 460 | 21,103 | 597 | 4.7 |
| 19 | L1-worker | claudeopus46 | 20,643 | 1,678 | 22,321 | 14,686 | 48.3 |
| 20 | L1-worker | claudeopus46 | 2,065 | 436 | 2,501 | 419 | 4.7 |
| 21 | L1-worker | claudeopus46 | 20,643 | 1,832 | 22,475 | 11,631 | 50.1 |
| 22 | L1-worker | claudeopus46 | 20,643 | 14,084 | 34,727 | 2,817 | 13.9 |
| 23 | L1-worker | claudeopus46 | 1,356 | 2,946 | 4,302 | 688 | 4.8 |
| 24 | L1-worker | claudeopus46 | 536 | 2,826 | 3,362 | 848 | 6.4 |
| 25 | L1-worker | claudeopus46 | 298 | 1,070 | 1,368 | 676 | 2.9 |
| 26 | L1-worker | claudeopus46 | 298 | 1,204 | 1,502 | 835 | 3.6 |
| 27 | L1-worker | claudeopus46 | 1,323 | 4,873 | 6,196 | 5,238 | 17.1 |
| 28 | L1-worker | claudeopus46 | 298 | 5,960 | 6,258 | 4,329 | 13.7 |
| 29 | L1-worker | claudeopus46 | 1,160 | 11,457 | 12,617 | 4,228 | 14.7 |
| 30 | L0-main | claudeopus46 | 19,988 | 5,841 | 25,829 | 590 | 4.6 |
| 31 | L0-main | claudeopus46 | 20,021 | 5,084 | 25,105 | 1,193 | 8.0 |
| 32 | L1-worker | claudeopus46 | 20,643 | 727 | 21,370 | 889 | 5.9 |
| 33 | L1-worker | claudeopus46 | 20,643 | 2,237 | 22,880 | 6,255 | 33.1 |
| 34 | L1-worker | claudeopus46 | 2,065 | 6,760 | 8,825 | 1,658 | 13.8 |
| 35 | L1-worker | claudeopus46 | 20,643 | 3,438 | 24,081 | 3,055 | 19.0 |
| 36 | L1-worker | claudeopus46 | 1,356 | 2,144 | 3,500 | 760 | 4.4 |
| 37 | L1-worker | claudeopus46 | 536 | 2,024 | 2,560 | 715 | 4.6 |
| 38 | L1-worker | claudeopus46 | 1,323 | 5,359 | 6,682 | 3,227 | 12.6 |
| 39 | L1-worker | claudeopus46 | 298 | 3,949 | 4,247 | 2,506 | 9.9 |
| 40 | L1-worker | claudeopus46 | 747 | 48,370 | 49,117 | 853 | 8.7 |
| 41 | L0-main | claudeopus46 | 20,021 | 7,397 | 27,418 | 1,217 | 8.8 |
| 42 | L1-worker | claudeopus46 | 20,643 | 753 | 21,396 | 2,173 | 14.2 |
| 43 | L1-worker | claudeopus46 | 20,643 | 3,654 | 24,297 | 15,119 | 48.3 |
| 44 | L1-worker | claudeopus46 | 2,065 | 597 | 2,662 | 580 | 4.0 |
| 45 | L1-worker | claudeopus46 | 2,065 | 544 | 2,609 | 1,682 | 11.2 |
| 46 | L1-worker | claudeopus46 | 20,643 | 4,959 | 25,602 | 12,414 | 66.4 |
| 47 | L1-worker | claudeopus46 | 2,065 | 6,139 | 8,204 | 1,342 | 10.0 |
| 48 | L1-worker | claudeopus46 | 20,610 | 7,091 | 27,701 | 513 | 4.4 |
| 49 | L1-worker | claudeopus46 | 20,643 | 6,319 | 26,962 | 9,552 | 46.5 |
| 50 | L1-worker | claudeopus46 | 2,065 | 482 | 2,547 | 633 | 4.5 |
| 51 | L1-worker | claudeopus46 | 20,643 | 7,202 | 27,845 | 5,610 | 36.3 |
| 52 | L1-worker | claudeopus46 | 20,643 | 13,561 | 34,204 | 1,965 | 7.5 |
| 53 | L1-worker | claudeopus46 | 1,356 | 2,096 | 3,452 | 781 | 5.3 |
| 54 | L1-worker | claudeopus46 | 536 | 1,976 | 2,512 | 965 | 6.4 |
| 55 | L1-worker | claudeopus46 | 1,323 | 8,177 | 9,500 | 2,424 | 10.9 |
| 56 | L1-worker | claudeopus46 | 298 | 3,146 | 3,444 | 1,846 | 7.2 |
| 57 | L1-worker | claudeopus46 | 1,160 | 11,104 | 12,264 | 493 | 3.9 |
| 58 | L1-worker | claudeopus46 | 747 | 16,405 | 17,152 | 959 | 8.9 |
| 59 | L0-main | claudeopus46 | 20,021 | 9,103 | 29,124 | 1,789 | 11.3 |
| 60 | L0-main | claudeopus46 | 20,021 | 10,220 | 30,241 | 1,293 | 8.3 |
| 61 | L1-worker | claudeopus46 | 20,643 | 538 | 21,181 | 588 | 4.5 |
| 62 | L1-worker | claudeopus46 | 20,643 | 1,747 | 22,390 | 12,979 | 59.7 |
| 63 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 482 | 3.5 |
| 64 | L1-worker | claudeopus46 | 20,643 | 1,946 | 22,589 | 7,061 | 35.7 |
| 65 | L1-worker | claudeopus46 | 20,643 | 9,628 | 30,271 | 3,087 | 15.3 |
| 66 | L1-worker | claudeopus46 | 1,356 | 2,441 | 3,797 | 918 | 4.6 |
| 67 | L1-worker | claudeopus46 | 536 | 2,321 | 2,857 | 944 | 5.7 |
| 68 | L1-worker | claudeopus46 | 1,323 | 4,515 | 5,838 | 3,919 | 14.9 |
| 69 | L1-worker | claudeopus46 | 298 | 4,641 | 4,939 | 2,919 | 11.4 |
| 70 | L1-worker | claudeopus46 | 1,160 | 9,141 | 10,301 | 2,982 | 15.5 |
| 71 | L0-main | claudeopus46 | 20,021 | 14,341 | 34,362 | 1,807 | 13.3 |
| 72 | L0-main | claudeopus46 | 19,988 | 13,171 | 33,159 | 4,351 | 28.3 |
| 73 | L0-main | claudeopus46 | 1,356 | 4,482 | 5,838 | 977 | 5.3 |
| 74 | L0-main | claudeopus46 | 298 | 1,359 | 1,657 | 965 | 3.5 |
| 75 | L0-main | claudeopus46 | 1,323 | 36,862 | 38,185 | 3,385 | 18.0 |
| 76 | L0-main | claudeopus46 | 298 | 4,227 | 4,525 | 3,061 | 14.7 |


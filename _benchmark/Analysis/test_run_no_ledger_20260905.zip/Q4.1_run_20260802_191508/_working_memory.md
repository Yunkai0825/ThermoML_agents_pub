# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q4.1_run_20260802_191508`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_2 | ethanol |  |
| comp | GLOBcomp_1 | water |  |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [run_query_agent]

### Query Results
#### ethanol_water_viscosity — ERROR
no active StatsRecorder; start agent tracking first

#### methanol_water_viscosity — ERROR
no active StatsRecorder; start agent tracking first

#### query
Ten binary mixture data blocks report dynamic viscosity (Pa·s) of ethanol + water near 298.15 K. Three blocks with broad composition coverage (DOI 10.1016/j.jct.2007.05.004, DOI 10.1016/j.jct.2018.02.022, DOI 10.1021/je600565m) span the full mole-fraction range and capture the well-known viscosity maximum near x(ethanol) ≈ 0.3, where η peaks at ~0.0027 Pa·s (~2.7× pure water). Additional blocks use mass fraction or molality as composition variables at or near 298.15 K. Reported viscosities across all blocks range from ~0.0008 to ~0.0029 Pa·s. The viscosity maximum is attributed to hydrogen-bonding network restructuring between ethanol and water clusters that maximizes intermolecular friction.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11 | declared | 37 | binary | binary |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 | declared | 100 | binary | binary |
| GLOBlit_7178 | 10.1021/acs.jced.7b00299 | PROPblock_11 | declared | 2 | binary | binary |
| GLOBlit_7448 | 10.1021/acs.jced.8b00086 | PROPblock_47 | declared | 6 | binary | binary |
| GLOBlit_7676 | 10.1021/acs.jced.8b00939 | PROPblock_18 | declared | 9 | binary | binary |
| GLOBlit_10159 | 10.1021/je4003515 | PROPblock_8 | declared | 25 | binary | binary |
| GLOBlit_10699 | 10.1021/je600565m | PROPblock_5 | declared | 17 | binary | binary |

### Inspected Blocks
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11: 37 rows; x=['mole_fraction_<water>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_10699 | 10.1021/je600565m | PROPblock_5: 17 rows; x=['mole_fraction_<water>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 7 | 32,090 | 87,521 | 20,226 | 119,611 | 17,087 | 109.3 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| L1-worker | 34 | 351,305 | 314,815 | 48,335 | 666,120 | 19,591 | 324.0 | claudeopus46 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| **TOTAL** | **41** | **383,395** | **402,336** | **68,561** | **785,731** | **36,678** | **433.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| `search_blocks` | 2 | 1 | 4 | 1 | 4 | 4 | 76 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| `search_blocks` | 2 | 1 | 4 | 1 | 4 | 4 | 76 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| `search_system_registry` | 2 | 1 | 4 | 1 | 4 | 4 | 76 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| **TOTAL** | **6** | **3** | **12** | **3** | **12** | **12** | **228** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2825 |  | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBlit_5533 |  | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBlit_8869 |  | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBlit_9571 |  | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_4 | methanol | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBcomp_1 | water | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBmeas_271 | Viscosity, Pa*s | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| GLOBvar_18 | Volume fraction | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBblocktype_1 |  | search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique References | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique Compounds | 2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique Properties | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique Measurements | 3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique Phases | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique Variables | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique Constraints | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique Block_Types | 1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Unique parent blocks | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Explicit block/subsystem targets | 4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Subsystem targets | 0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| Target-matched data points | 228 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| **TOTAL** | **253** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10.1016/j.jct.2019.05.013 | 1 | 12 | binary | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | ---: | --- | --- |
| 10.1016/j.jct.2007.05.004 | PROPblock_9 | declared | 39 | binary | 2 | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10.1016/j.jct.2019.05.013 | PROPblock_3 | declared | 12 | binary | 2 | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10.1021/je0600810 | PROPblock_3 | declared | 9 | binary | 2 | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10.1021/je2003622 | PROPblock_1 | declared | 16 | binary | 2 | search_blocks, search_system_registry | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `memory_catalog_add` | global_id=GLOBcomp_4, name=methanol, registry_id=m… | 2 | — | — | 0.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 2 | 1 | `memory_catalog_add` | global_id=GLOBcomp_1, name=water, registry_id=wate… | 2 | — | — | 0.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 3 | 1 | `memory_catalog_add` | global_id=GLOBprop_4, name=Viscosity (dynamic) / P… | 2 | — | — | 0.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 4 | 1 | `memory_catalog_add` | global_id=GLOBvar_1, name=Temperature / K, registr… | 2 | — | — | 0.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 5 | 1 | `memory_catalog_add` | global_id=GLOBvar_2, name=Mole fraction, registry_… | 2 | — | — | 0.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 6 | 4 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 784 | DISCARD | 723 | 12.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 7 | 5 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 756 | KEEP | 711 | 14.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 8 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 849 | DISCARD | 788 | 9.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 9 | 1 | `L1_query` | context=Binary mixture viscosity sear…, id_catalog… | 9,444 | — | — | 202.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10 | 1 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=50, p… | 550 | KEEP | 550 | 19.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 11 | 3 | `search_system_registry` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 1,290 | KEEP | 1290 | 11.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 12 | 2 | `L1_query` | context=Previous query found 4 blocks…, id_catalog… | 270 | — | — | 100.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| **TOTAL** | **31** |  |  | **13,953** |  | **4,062** | **372.4** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 4,714 | 4,714 | 0 | 0.0% | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,069 | 10,674 | 2,544 | 12.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,820 | 22,463 | 1,758 | 11.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,736 | 23,379 | 1,291 | 8.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 4 | L1-worker | claudeopus46 | 20,643 | 3,690 | 24,333 | 1,990 | 13.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 5 | L1-worker | claudeopus46 | 20,643 | 4,561 | 25,204 | 1,629 | 10.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 6 | L1-worker | claudeopus46 | 2,065 | 1,230 | 3,295 | 1,746 | 10.7 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 7 | L1-worker | claudeopus46 | 20,643 | 4,490 | 25,133 | 838 | 6.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 8 | L1-worker | claudeopus46 | 2,065 | 8,605 | 10,670 | 1,719 | 13.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,795 | 26,438 | 1,968 | 13.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 10 | L1-worker | claudeopus46 | 20,643 | 6,726 | 27,369 | 1,137 | 8.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 11 | L1-worker | claudeopus46 | 20,643 | 7,603 | 28,246 | 1,361 | 12.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 12 | L1-worker | claudeopus46 | 20,643 | 8,436 | 29,079 | 1,158 | 8.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 13 | L1-worker | claudeopus46 | 20,643 | 9,308 | 29,951 | 1,632 | 10.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 14 | L1-worker | claudeopus46 | 2,065 | 1,199 | 3,264 | 1,338 | 8.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 15 | L1-worker | claudeopus46 | 20,643 | 8,958 | 29,601 | 2,480 | 20.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 16 | L1-worker | claudeopus46 | 536 | 1,570 | 2,106 | 976 | 5.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 17 | L1-worker | claudeopus46 | 1,356 | 1,690 | 3,046 | 714 | 8.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 18 | L1-worker | claudeopus46 | 1,323 | 18,540 | 19,863 | 1,321 | 9.2 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 19 | L1-worker | claudeopus46 | 298 | 2,043 | 2,341 | 1,095 | 5.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 20 | L1-worker | claudeopus46 | 747 | 32,256 | 33,003 | 877 | 9.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 21 | L1-worker | claudeopus46 | 1,160 | 20,914 | 22,074 | 659 | 4.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 22 | L1-worker | claudeopus46 | 747 | 26,331 | 27,078 | 1,317 | 11.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 23 | L0-main | claudeopus46 | 9,605 | 13,274 | 22,879 | 2,794 | 19.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 24 | L1-worker | claudeopus46 | 20,643 | 11,258 | 31,901 | 915 | 6.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 25 | L1-worker | claudeopus46 | 2,065 | 8,717 | 10,782 | 1,707 | 13.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 26 | L1-worker | claudeopus46 | 20,643 | 12,310 | 32,953 | 955 | 6.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 27 | L1-worker | claudeopus46 | 20,643 | 13,886 | 34,529 | 705 | 3.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 28 | L1-worker | claudeopus46 | 2,065 | 3,956 | 6,021 | 1,684 | 11.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 29 | L1-worker | claudeopus46 | 20,610 | 15,841 | 36,451 | 429 | 4.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 30 | L1-worker | claudeopus46 | 20,643 | 15,088 | 35,731 | 4,368 | 22.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 31 | L1-worker | claudeopus46 | 536 | 3,216 | 3,752 | 1,131 | 7.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 32 | L1-worker | claudeopus46 | 1,356 | 3,336 | 4,692 | 1,167 | 7.9 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 33 | L1-worker | claudeopus46 | 1,323 | 8,020 | 9,343 | 2,441 | 10.6 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 34 | L1-worker | claudeopus46 | 298 | 1,549 | 1,847 | 1,155 | 4.1 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 35 | L1-worker | claudeopus46 | 298 | 3,163 | 3,461 | 2,017 | 7.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 36 | L1-worker | claudeopus46 | 747 | 35,974 | 36,721 | 657 | 6.8 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 37 | L0-main | claudeopus46 | 9,605 | 43,767 | 53,372 | 6,099 | 34.5 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 38 | L0-main | claudeopus46 | 1,356 | 4,429 | 5,785 | 1,035 | 7.3 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 39 | L0-main | claudeopus46 | 298 | 1,417 | 1,715 | 1,023 | 4.0 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 40 | L0-main | claudeopus46 | 1,323 | 19,300 | 20,623 | 3,597 | 19.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |
| 41 | L0-main | claudeopus46 | 298 | 4,265 | 4,563 | 3,134 | 12.4 | Find binary mixture data blocks containing dynamic viscosity (query_runs/run_6) |

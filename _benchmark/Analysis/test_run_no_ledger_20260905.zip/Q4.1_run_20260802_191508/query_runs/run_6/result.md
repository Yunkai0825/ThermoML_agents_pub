# Delegated query run — result

**Question:** Find binary mixture data blocks containing dynamic viscosity (GLOBprop_4, viscosity in Pa·s) for methanol + water at or near 298.15 K. Methanol compound ID is GLOBcomp_4, water is GLOBcomp_1. I need blocks with mole fraction composition covering a wide range (at least 5 data points). Return DOI, block number, literature ID, number of matching points, and composition variable used.

**Iterations:** 3  |  **Elapsed:** 371.7s  |  **Tools:** 7  |  **Timed out:** False

---

## Answer

## Binary Methanol + Water Dynamic Viscosity Data Blocks near 298.15 K

Four data blocks for the binary methanol (CH₄O) + water (H₂O) system with dynamic viscosity (Pa·s) were identified in the ThermoML database near 298.15 K. Here is a complete summary:

---

### 1. ✅ PROPblock_9 — GLOBlit_2825 *(Best match)*
- **DOI:** 10.1016/j.jct.2007.05.004
- **Literature ID:** GLOBlit_2825
- **Total data points:** 39
- **Temperature range:** 293.15–303.15 K (3 temperatures; **includes exactly 298.15 K** → ~13 points at that temperature)
- **Composition variable:** Mole fraction of water (GLOBvar_2)
- **Composition range:** 0.0–1.0 (13 unique mole fractions — **full binary range**)
- **Measurement method:** Capillary tube (GLOBmeas_140)
- **Pressure:** 101 kPa
- **Viscosity range:** 0.000508–0.001793 Pa·s

> **This is the only block that meets all criteria:** data at exactly 298.15 K, mole-fraction composition variable, ≥5 data points, and wide (full) composition coverage.

---

### 2. ❌ PROPblock_3 — GLOBlit_5533
- **DOI:** 10.1016/j.jct.2019.05.013
- **Literature ID:** GLOBlit_5533
- **Total data points:** 12
- **Temperature range:** 273.15–293.15 K (**does not reach 298.15 K**)
- **Composition variable:** Mass fraction of methanol (GLOBvar_5) — not mole fraction
- **Composition range:** 0.0–0.4999 (6 unique compositions, water-rich side only)
- **Measurement method:** Falling/rolling sphere (GLOBmeas_8)
- **Reason excluded:** Temperature too low (max 293.15 K); uses mass fraction, not mole fraction; partial composition range.

---

### 3. ❌ PROPblock_3 — GLOBlit_8869
- **DOI:** 10.1021/je0600810
- **Literature ID:** GLOBlit_8869
- **Total data points:** 9
- **Temperature range:** 298.15–318.15 K (**includes 298.15 K**)
- **Composition variable:** Volume fraction of methanol (GLOBvar_18) — not mole fraction
- **Composition range:** 0.01–0.30 (only 3 unique compositions — narrow, dilute-methanol region)
- **Measurement method:** Capillary tube (GLOBmeas_140)
- **Reason excluded:** Only 3 compositions (fewer than 5); uses volume fraction; narrow composition range.

---

### 4. ❌ PROPblock_1 — GLOBlit_9571
- **DOI:** 10.1021/je2003622
- **Literature ID:** GLOBlit_9571
- **Total data points:** 16
- **Temperature range:** 298.15–323.15 K (**includes 298.15 K**)
- **Composition variable:** Mass fraction of methanol (GLOBvar_5) — not mole fraction
- **Composition range:** 0.0806–0.3446 (only 4 unique compositions — partial, methanol-lean to intermediate)
- **Measurement method:** Capillary tube (GLOBmeas_271)
- **Reason excluded:** Only 4 compositions (fewer than 5); uses mass fraction; partial composition range.

---

### Summary Table

| Block | Literature | DOI | T includes 298.15 K? | Comp. variable | # Compositions | Range | Meets criteria? |
|-------|-----------|-----|:--------------------:|----------------|:--------------:|-------|:---------------:|
| PROPblock_9 | GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | ✓ | Mole fraction (water) | 13 | 0.0–1.0 | **✅ Yes** |
| PROPblock_3 | GLOBlit_5533 | 10.1016/j.jct.2019.05.013 | ✗ (max 293.15 K) | Mass fraction (MeOH) | 6 | 0.0–0.50 | ❌ No |
| PROPblock_3 | GLOBlit_8869 | 10.1021/je0600810 | ✓ | Volume fraction (MeOH) | 3 | 0.01–0.30 | ❌ No |
| PROPblock_1 | GLOBlit_9571 | 10.1021/je2003622 | ✓ | Mass fraction (MeOH) | 4 | 0.08–0.34 | ❌ No |

### Chemistry Context

The methanol–water binary system is a classic example of non-ideal mixing driven by hydrogen-bonding network restructuring. At 298.15 K, the dynamic viscosity exhibits a well-known maximum near x(methanol) ≈ 0.3, where the viscosity rises from ~0.89 mPa·s (pure water) and ~0.54 mPa·s (pure methanol) to a peak of roughly 1.5–1.6 mPa·s. This anomalous behavior reflects the formation of strongly interacting methanol–water clusters that enhance intermolecular friction beyond what linear mixing would predict. The PROPblock_9 dataset from GLOBlit_2825 (viscosity range 0.508–1.793 mPa·s across the full mole-fraction range) is ideally suited to capture this composition-dependent behavior.

**Recommendation:** PROPblock_9 from GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004) is the only block that satisfies all requirements — it provides 13 mole-fraction compositions spanning the entire binary range at exactly 298.15 K.

### Core claims

- Of four ThermoML data blocks for binary methanol + water dynamic viscosity near 298.15 K, only PROPblock_9 from GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004) meets all criteria: data at exactly 298.15 K, mole-fraction composition variable, at least 5 data points (13 unique mole fractions), and full binary composition coverage (0.0–1.0), with viscosities spanning 0.000508–0.001793 Pa·s at 101 kPa.
- The other three blocks were excluded because they lacked data at 298.15 K (GLOBlit_5533, max 293.15 K), used non-mole-fraction composition variables (mass fraction or volume fraction), and/or had fewer than 5 unique compositions or only partial composition coverage.
- At 298.15 K, the methanol–water system exhibits a well-known viscosity maximum near x(methanol) ≈ 0.3, rising above the pure-component values (~0.89 mPa·s for water, ~0.54 mPa·s for methanol) to roughly 1.5–1.6 mPa·s, reflecting non-ideal mixing driven by hydrogen-bonding network restructuring and methanol–water cluster formation.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 39 total data points across 3 temperatures (293.15, 298.15, 303.15 K); ~13 points at exactly 298.15 K. Composition variable: mole fraction of water (GLOBvar_2), 13 unique values spanning 0.0–1.0. Pressure constraint 101 kPa. Measurement method: capillary tube (GLOBmeas_140). Viscosity range: 0.000508–0.001793 Pa·s. Best and only block meeting all criteria (298.15 K, mole fraction, ≥5 points, full composition range). |
| GLOBlit_5533 | 10.1016/j.jct.2019.05.013 | PROPblock_3 |  | Dynamic viscosity (GLOBprop_4) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 12 data points; temperature range 273.15–293.15 K (does not reach 298.15 K). Composition variable: mass fraction of methanol (GLOBvar_5), 6 unique values, range 0.0–0.4999. Excluded: temperature too low, uses mass fraction not mole fraction, partial composition range. |
| GLOBlit_8869 | 10.1021/je0600810 | PROPblock_3 |  | Dynamic viscosity (GLOBprop_4) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 9 data points; temperature range 298.15–318.15 K (includes 298.15 K). Composition variable: volume fraction of methanol (GLOBvar_18), only 3 unique values, range 0.01–0.30. Excluded: fewer than 5 compositions, uses volume fraction, narrow dilute-methanol region. |
| GLOBlit_9571 | 10.1021/je2003622 | PROPblock_1 |  | Dynamic viscosity (GLOBprop_4) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1). 16 data points; temperature range 298.15–323.15 K (includes 298.15 K). Composition variable: mass fraction of methanol (GLOBvar_5), only 4 unique values, range 0.0806–0.3446. Measurement method: capillary tube (GLOBmeas_271). Excluded: fewer than 5 compositions, uses mass fraction, partial composition range. |

### Suggested follow-ups

- Retrieve the actual data rows from PROPblock_9 / GLOBlit_2825 at exactly 298.15 K to obtain the 13 viscosity-vs-mole-fraction values for fitting or plotting.
- Search for additional methanol+water viscosity datasets using mole fraction (GLOBvar_2) at other temperatures to build a temperature-dependent viscosity surface.
- Cross-check the GLOBlit_8869 and GLOBlit_9571 blocks by converting their volume-fraction and mass-fraction compositions to mole fractions for comparison with the GLOBlit_2825 dataset.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_dynamic",
    "name": "Viscosity (dynamic) / Pa·s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature",
    "name": "Temperature / K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction",
    "name": "Mole fraction"
  }
]
```

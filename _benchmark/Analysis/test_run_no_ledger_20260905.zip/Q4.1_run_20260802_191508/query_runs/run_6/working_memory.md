# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_4 | methanol | methanol |
| comp | GLOBcomp_1 | water | water |
| prop | GLOBprop_4 | viscosity_dynamic | Viscosity (dynamic) / Pa·s |
| var | GLOBvar_1 | temperature | Temperature / K |
| var | GLOBvar_2 | mole_fraction | Mole fraction |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find binary mixture data blocks with dynamic viscosity (GLOBprop_4) for methanol (GLOBcomp_4) + water (GLOBcomp_1) at or → stored as L1_query_1
- [L1] Get details on ALL binary methanol+water dynamic viscosity blocks near 298.15 K → stored as L1_query_2

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "Four binary methanol + water data blocks containing dynamic viscosity (GLOBprop_4, Pa·s) were found in the ThermoML database within the 293–303 K temperature range:\n\n**Best block — widest composition coverage at 298.15 K:**\n\n• **PROPblock_9** from DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825)\n  – 39 total data points across three temperatures (293.15, 298.15, 303.15 K)\n  – At exactly 298.15 K: ~6 data points spanning x(water) = 0.0 to 1.0 (full composition range)\n  – Composition variable: mole fraction of water\n  – This block provides the most comprehensive composition-dependent viscosity profile at 298.15 K\n\n**Additional blocks with data near 298.15 K:**\n\n• **PROPblock_3** from DOI 10.1016/j.jct.2019.05.013 (GLOBlit_5533) – 12 data points at ~293 K, with data near 298.15 K\n\n• Two further blocks were also identified in the search results with complementary composition variables and temperature coverage.\n\n**Chemistry context:** The methanol–water binary system is well known for exhibiting a pronounced viscosity maximum near x(methanol) ≈ 0.3 at 298.15 K, where hydrogen-bonding network restructuring between water and methanol clusters leads to enhanced intermolecular friction. The viscosity rises from ~0.89 mPa·s (pure water) and ~0.54 mPa·s (pure methanol) to a peak of roughly 1.5–1.6 mPa·s at intermediate compositions. The PROPblock_9 dataset from GLOBlit_2825 is the most suitable block for studying this composition dependence, as it spans the full mole fraction range at exactly 298.15 K with at least 5 data points.",
  "core_claims": [
    "Four binary methanol + water data blocks containing dynamic viscosity were identified in the ThermoML database within the 293–303 K temperature range.",
    "PROPblock_9 (from DOI 10.1016/j.jct.2007.05.004) provides the most comprehensive composition-dependent viscosity profile at 298.15 K, spanning the full water mole-fraction range (0.0 to 1.0) with approximately 6 data points at that temperature.",
    "The methanol–water system exhibits a well-known viscosity maximum near x(methanol) ≈ 0.3 at 298.15 K, attributed to hydrogen-bonding network restructuring, with viscosity rising from ~0.89 mPa·s (pure water) and ~0.54 mPa·s (pure methanol) to roughly 1.5–1.6 mPa·s at intermediate compositions."
  ],
  "status": "partial",
  "summary": "In the ThermoML database, four binary methanol + water data blocks containing dynamic viscosity (Pa·s) were identified in the 293–303 K range. The best block is PROPblock_9 from DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825), which has 39 total data points across 293.15, 298.15, and 303.15 K, with approximately 6 points at exactly 298.15 K spanning the full water mole-fraction range (0.0 to 1.0). An additional block, PROPblock_3 from DOI 10.1016/j.jct.2019.05.013 (GLOBlit_5533), provides 12 data points near 293–298 K, and two further blocks offer complementary coverage. The methanol–water system exhibits a well-known viscosity maximum near x(methanol) ≈ 0.3 at 298.15 K (~1.5–1.6 mPa·s), rising above the pure-component values of ~0.89 mPa·s (water) and ~0.54 mPa·s (methanol), attributed to hydrogen-bonding network restructuring. PROPblock_9 is identified as the most suitable block for studying this composition-dependent viscosity behavior at 298.15 K.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2825",
      "block_number": "PROPblock_9",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (GLOBprop_4, Pa·s) for binary methanol (GLOBcomp_4) + water (GLOBcomp_1) from DOI 10.1016/j.jct.2007.05.004. 39 total data points across 3 temperatures (293.15, 298.15, 303.15 K) and 13 unique mole fractions, giving ~13 data points at exactly 298.15 K spanning the full mole fraction range (0.0 to 1.0). Composition variable: GLOBvar_2 (mole fraction). Best block for wide composition coverage at 298.15 K.",
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_id": "2007-gon-cal-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000508,
            "max": 0.001793,
            "mean": 0.001082,
            "std": 0.000366,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000508,
          "range_max": 0.001793
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_2
{
  "answer": "Here is the **complete list of all four binary methanol + water dynamic viscosity (GLOBprop_4, Pa·s) data blocks** found in the ThermoML database within the temperature window near 298.15 K (±10 K):\n\n---\n\n### 1. PROPblock_9 — GLOBlit_2825\n- **DOI:** 10.1016/j.jct.2007.05.004\n- **Data points:** 39\n- **Temperature range:** 293.15–303.15 K (3 unique temperatures, includes exactly 298.15 K)\n- **Composition variable:** Mole fraction of water (GLOBvar_2, BLKvar_2)\n- **Mole fraction range:** 0.0–1.0 (13 unique compositions — full range)\n- **Measurement method:** Capillary tube (GLOBmeas_140)\n- **Notes:** Best block for composition-dependent viscosity at 298.15 K — widest composition coverage spanning both pure endpoints and all intermediate compositions.\n\n### 2. PROPblock_3 — GLOBlit_5533\n- **DOI:** 10.1016/j.jct.2019.05.013\n- **Data points:** 12\n- **Temperature range:** 273.15–293.15 K (does **not** reach 298.15 K; upper limit is 293.15 K)\n- **Composition variable:** Mass fraction of methanol (GLOBvar_5, BLKvar_1)\n- **Mass fraction range:** 0.0–0.4999 (partial composition range)\n- **Measurement method:** Falling or rolling sphere (GLOBmeas_8)\n- **Notes:** This block covers only the water-rich side and temperatures below 298.15 K. Useful for lower-temperature extrapolation but does not contain data at exactly 298.15 K.\n\n### 3. PROPblock_3 — GLOBlit_8869\n- **DOI:** 10.1021/je0600810\n- **Data points:** 9\n- **Temperature range:** 298.15–318.15 K (includes exactly 298.15 K)\n- **Composition variable:** Volume fraction of methanol (GLOBvar_18, BLKvar_1)\n- **Volume fraction range:** 0.01–0.3 (narrow, methanol-dilute region only)\n- **Measurement method:** Capillary tube (GLOBmeas_140)\n- **Notes:** Covers only the dilute-methanol region (φ_MeOH ≤ 0.3). Has data at exactly 298.15 K but limited composition coverage.\n\n### 4. PROPblock_1 — GLOBlit_9571\n- **DOI:** 10.1021/je2003622\n- **Data points:** 16\n- **Temperature range:** 298.15–323.15 K (includes exactly 298.15 K)\n- **Composition variable:** Mass fraction of methanol (GLOBvar_5, BLKvar_1)\n- **Mass fraction range:** 0.0806–0.3446 (partial, methanol-dilute to intermediate region)\n- **Measurement method:** Capillary tube (GLOBmeas_271)\n- **Notes:** Covers a moderate composition range on the methanol-lean side. Has data at exactly 298.15 K.\n\n---\n\n**Summary comparison:**\n\n| Block | Literature | Points | T includes 298.15 K? | Comp. variable | Comp. range | Coverage |\n|-------|-----------|--------|----------------------|----------------|-------------|----------|\n| PROPblock_9 | GLOBlit_2825 | 39 | ✓ Yes | Mole fraction (water) | 0.0–1.0 | Full range |\n| PROPblock_3 | GLOBlit_5533 | 12 | ✗ No (max 293.15 K) | Mass fraction (MeOH) | 0.0–0.50 | Partial |\n| PROPblock_3 | GLOBlit_8869 | 9 | ✓ Yes | Volume fraction (MeOH) | 0.01–0.30 | Narrow |\n| PROPblock_1 | GLOBlit_9571 | 16 | ✓ Yes | Mass fraction (MeOH) | 0.08–0.34 | Partial |\n\nThree of the four blocks contain data at exactly 298.15 K. PROPblock_9 from GLOBlit_2825 remains the clear best choice for studying composition-dependent viscosity behavior across the full binary range at 298.15 K, with 13 unique compositions from pure water to pure methanol.",
  "core_claims": [
    "Four binary methanol + water dynamic viscosity data blocks were identified in the ThermoML database within approximately ±10 K of 298.15 K, originating from four distinct literature sources (GLOBlit_2825, GLOBlit_5533, GLOBlit_8869, GLOBlit_9571).",
    "Three of the four blocks contain data at exactly 298.15 K; the exception is GLOBlit_5533, whose upper temperature limit is 293.15 K.",
    "PROPblock_9 from GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004) provides the most comprehensive coverage, with 39 data points spanning the full mole-fraction range (0.0–1.0 of water) at 13 unique compositions across 293.15–303.15 K, including 298.15 K.",
    "The remaining blocks cover only partial composition ranges: GLOBlit_5533 covers mass fractions of methanol up to ~0.50 (water-rich side), GLOBlit_8869 covers volume fractions of methanol up to 0.30 (dilute methanol), and GLOBlit_9571 covers mass fractions of methanol from ~0.08 to ~0.34.",
    "The blocks use different composition variables (mole fraction of water, mass fraction of methanol, volume fraction of methanol) and different measurement methods (capillary tube or falling/rolling sphere)."
  ],
  "status": "success",
  "summary": "Four binary methanol + water dynamic viscosity (Pa·s) data blocks were identified in the ThermoML database near 298.15 K (±10 K). (1) PROPblock_9 from GLOBlit_2825 (DOI 10.1016/j.jct.2007.05.004): 39 points, 293.15–303.15 K (includes 298.15 K), mole fraction of water 0.0–1.0 across 13 compositions, capillary tube method — fullest composition coverage. (2) PROPblock_3 from GLOBlit_5533 (DOI 10.1016/j.jct.2019.05.013): 12 points, 273.15–293.15 K (does not reach 298.15 K), mass fraction of methanol 0.0–0.50, falling/rolling sphere method — water-rich side only. (3) PROPblock_3 from GLOBlit_8869 (DOI 10.1021/je0600810): 9 points, 298.15–318.15 K, volume fraction of methanol 0.01–0.30, capillary tube — narrow dilute-methanol region. (4) PROPblock_1 from GLOBlit_9571 (DOI 10.1021/je2003622): 16 points, 298.15–323.15 K, mass fraction of methanol 0.08–0.34, capillary tube — partial methanol-lean to intermediate range. Three of the four blocks include data at exactly 298.15 K. PROPblock_9 from GLOBlit_2825 is the best block for studying composition-dependent viscosity across the full binary range at 298.15 K.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2825",
      "block_number": "PROPblock_9",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity of methanol+water binary mixture. DOI 10.1016/j.jct.2007.05.004. 39 data points, T range 293.15–303.15 K (includes 298.15 K). Composition variable: mole fraction of water (GLOBvar_2, BLKvar_2), range 0.0–1.0 (13 unique compositions, full range). Measurement method: GLOBmeas_140 (capillary tube).",
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_id": "2007-gon-cal-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000508,
            "max": 0.001793,
            "mean": 0.001082,
            "std": 0.000366,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000508,
          "range_max": 0.001793
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_5533",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity of methanol+water binary mixture. DOI 10.1016/j.jct.2019.05.013. 12 data points, T range 273.15–293.15 K (does not reach 298.15 K). Composition variable: mass fraction of methanol (GLOBvar_5, BLKvar_1), range 0.0–0.4999 (partial, water-rich side). Measurement method: GLOBmeas_8 (falling or rolling sphere).",
      "doi": "10.1016/j.jct.2019.05.013",
      "lit_id": "2019-sem-sto-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 12,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_2",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 0.4999,
            "n_unique": 6
          },
          "range_min": 0.0,
          "range_max": 0.4999
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 273.15,
            "max": 293.15,
            "n_unique": 3
          },
          "range_min": 273.15,
          "range_max": 293.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000998,
            "max": 0.003636,
            "mean": 0.002284,
            "std": 0.000953,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000998,
          "range_max": 0.003636
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_8869",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity of methanol+water binary mixture. DOI 10.1021/je0600810. 9 data points, T range 298.15–318.15 K (includes 298.15 K). Composition variable: volume fraction of methanol (GLOBvar_18, BLKvar_1), range 0.01–0.3 (narrow, methanol-dilute region). Measurement method: GLOBmeas_140 (capillary tube).",
      "doi": "10.1021/je0600810",
      "lit_id": "2006-cha-das-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 9,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_18",
          "var_id": "volume_fraction_DOIcomp_1",
          "name": "Volume fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Volume fraction",
            "min": 0.01,
            "max": 0.3,
            "n_unique": 3
          },
          "range_min": 0.01,
          "range_max": 0.3
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 318.15,
            "n_unique": 3
          },
          "range_min": 298.15,
          "range_max": 318.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000702,
            "max": 0.001471,
            "mean": 0.001033,
            "std": 0.000248,
            "n": 9
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000702,
          "range_max": 0.001471
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 9,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_9571",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity of methanol+water binary mixture. DOI 10.1021/je2003622. 16 data points, T range 298.15–323.15 K (includes 298.15 K). Composition variable: mass fraction of methanol (GLOBvar_5, BLKvar_1), range 0.0806–0.3446 (partial, methanol-lean to intermediate). Measurement method: GLOBmeas_271 (capillary tube).",
      "doi": "10.1021/je2003622",
      "lit_id": "2011-bha-cha-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 16,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_1",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mass fraction",
            "min": 0.0806,
            "max": 0.3446,
            "n_unique": 4
          },
          "range_min": 0.0806,
          "range_max": 0.3446
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 323.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 323.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_271",
          "meas_ID": "captub_ufactor_6",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:6",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000638,
            "max": 0.001471,
            "mean": 0.000993,
            "std": 0.000261,
            "n": 16
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000638,
          "range_max": 0.001471
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 16,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


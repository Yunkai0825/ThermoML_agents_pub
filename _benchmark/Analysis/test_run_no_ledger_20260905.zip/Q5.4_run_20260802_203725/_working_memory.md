# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q5.4_run_20260802_203725`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_31 | dimethyl sulfoxide | 7.1266727e-05 |
| comp | GLOBcomp_1 | water | 1.8068301e-05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<dimethyl sulfoxide> |  |
| var | GLOBvar_5 | massfraction<dimethyl sulfoxide> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [query_thermoml]
- [query_thermoml]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [fit_block_derived] ERROR: Requested x column 'Mole fraction of dimethyl sulfoxide' not found
- [fit_block] ERROR: Requested x column 'Mole fraction of dimethyl sulfoxide' not found in block
- [fit_block] ERROR: Requested x column 'Mole fraction of dimethyl sulfoxide' not found in block
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_volume'. Available: ['density_to_molar_volu
- [fit_block]
- [fit_block]
- [fit_block_derived]
- [predict_from_rk]
- [predict_from_rk]
- [predict_from_rk]

### Query Results
#### density_dmso_water — ERROR
no active StatsRecorder; start agent tracking first

#### excess_enthalpy_dmso_water — ERROR
no active StatsRecorder; start agent tracking first

#### viscosity_dmso_water — ERROR
no active StatsRecorder; start agent tracking first

#### other_props_dmso_water — ERROR
no active StatsRecorder; start agent tracking first

#### query
The ThermoML database contains at least 7 data blocks from 6+ literature sources reporting mass density measurements for the binary DMSO (dimethyl sulfoxide) + water system at or near 298.15 K (within 293–303 K). The richest block (GLOBlit_2781, DOI 10.1016/j.jct.2006.12.012, PROPblock_4) provides 120 datapoints spanning the full DMSO mole fraction range (0–1) at 298.15 K. Other notable blocks include GLOBlit_2584 (96 points, water mole fractions 0.031–0.980, 288.15–298.15 K) and GLOBlit_11018 (70 points, full water mole fraction range, 293.15–323.15 K). Composition is expressed variously as mole fraction, molality, or fixed-composition constraints. Reported densities range from ~994 kg/m³ (pure water side) to ~1108 kg/m³ at intermediate-to-high DMSO mole fractions, consistent with the well-known density maximum in this system near x(DMSO) ≈ 0.3 at 298.15 K.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2584 | 10.1016/j.jct.2005.07.012 | PROPblock_8 | declared | 96 | binary | binary |
| GLOBlit_2652 | 10.1016/j.jct.2006.01.007 | PROPblock_4 | declared | 6 | binary | binary |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_4 | declared | 120 | binary | binary |
| GLOBlit_2844 | 10.1016/j.jct.2007.06.010 | PROPblock_4 | declared | 92 | binary | binary |
| GLOBlit_7713 | 10.1021/acs.jced.8b01048 | PROPblock_10 | declared | 9 | binary | binary |
| GLOBlit_11018 | 10.1021/je700645p | PROPblock_6 | declared | 70 | binary | binary |

#### query
No excess molar enthalpy (Hᴱ, GLOBprop_17) data exists for the binary system DMSO (GLOBcomp_31) + water (GLOBcomp_1) in the ThermoML database. The DMSO + water system is present but only with mass density (GLOBprop_1, 8 blocks, 155 points, 278.15–338.15 K), speed of sound (GLOBprop_2, 4 blocks, 60 points, 288.15–318.15 K), and excess molar volume (GLOBprop_26, 4 blocks, 40 points, 288.15–318.15 K). DMSO has Hᴱ data only with organic co-solvents (aromatic hydrocarbons, ketones, ionic liquids, etc.), not with water. The requested DMSO + water Hᴱ data blocks are absent from the ThermoML collection.

**Status:** no_results

#### query
Two data blocks of dynamic viscosity for the binary system dimethyl sulfoxide (DMSO) + water near 298.15 K were identified; no kinematic viscosity data were found. Block 1 (DOI 10.1016/j.jct.2006.12.012, GLOBlit_2781, PROPblock_3) contains 120 total points (8 at 298.15 K) over 298.15–308.15 K with composition given as mole fraction of DMSO. Block 2 (DOI 10.1021/je9001027, GLOBlit_11517, PROPblock_3) contains 35 total points (6 at 298.15 K) over 298.15–318.15 K with composition given as mass fraction of DMSO. Both blocks report data at 101 kPa. The data show the well-known viscosity maximum near x(DMSO) ≈ 0.33–0.39 at 298.15 K, where η reaches about 0.00372 Pa·s, roughly four times the viscosity of pure water and twice that of pure DMSO, attributed to strong hydrogen-bonding interactions forming structured microheterogeneous clusters.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | binary |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | binary |

#### query
For the DMSO (GLOBcomp_31) + water (GLOBcomp_1) binary system near 298 K, no excess molar volume (GLOBprop_28) data were found in the ThermoML database. One speed of sound (GLOBprop_8) block was found (DOI 10.1016/j.jct.2006.01.007, GLOBlit_2652, PROPblock_3), measured by the sing-around technique (GLOBmeas_7) at a single fixed DMSO mole fraction of 0.0385 and 101.0 kPa, covering 288.15–313.15 K over 6 data points. At 298.15 K the reported speed of sound is 1568.53 ± 0.78 m/s. No full composition sweep for speed of sound was available, and no other speed-of-sound or excess molar volume blocks were identified among the 16 blocks (9 DOIs) found for this binary system near 298 K.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2652 | 10.1016/j.jct.2006.01.007 | PROPblock_3 | declared | 6 | binary | binary |

**Status:** partial

### Inspected Blocks
- GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_4: 120 rows; x=['mole_fraction_<dimethyl sulfoxide>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3: 120 rows; x=['mole_fraction_<dimethyl sulfoxide>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3: 35 rows; x=['mass_fraction_<dimethyl sulfoxide>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - 10.1016/j.jct.2006.12.012/PROPblock_3 (dimethyl sulfoxide, water): RK order=5, R²=0.999497, RMSE=0.00881979868119369, coeffs=[3.705556, -3.859721, 2.183037, -0.818153, -1.803052, 2.548267]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: dimethyl sulfoxide=0.001996, water=0.0008901 [block-edges (water: direct/good, dimethyl sulfoxide: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.png
  - 10.1016/j.jct.2006.12.012/PROPblock_4 (dimethyl sulfoxide, water): RK order=4, R²=0.999983, RMSE=0.08104552307468378, coeffs=[206.28788, -173.558331, 107.086128, 3.361769, -42.113532]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: dimethyl sulfoxide=1096.29, water=997.05 [block-edges (water: direct/good, dimethyl sulfoxide: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_excess.png
  - 10.1016/j.jct.2006.12.012/PROPblock_4 (dimethyl sulfoxide, water): RK order=5, R²=0.999909, RMSE=2.9839840842544677e-09, coeffs=[-4e-06, 2e-06, -0.0, -2e-06, 2e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: dimethyl sulfoxide=7.12667e-05, water=1.80683e-05 [block-edges of derived data (water: direct/good, dimethyl sulfoxide: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2006.12.012 PROPblock_4_T298.1
- `$ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2006.12.012 PROPblock_4_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2006.12.012 PROPblock_4_T298.1
- `$ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_4_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2006.12.012 PROPblock_4_T298.1


# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:37:25
**Wall time (at last flush):** 995.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 24 | 385,104 | 360,894 | 40,934 | 745,998 | 31,083 | 263.3 | claudeopus46 |
| L1-worker | 73 | 640,885 | 392,958 | 120,881 | 1,033,843 | 14,162 | 724.1 | claudeopus46 |
| **TOTAL** | **97** | **1,025,989** | **753,852** | **161,815** | **1,779,841** | **18,348** | **987.4** | |

**Estimated tokens:** ~444,960 input + ~40,453 output = ~485,413 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 3 | 1 | 2 | 2 | 155 |
| `query_thermoml` | 2 | 1 | 1 | 2 | 1 | 1 | 6 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **4** | **2** | **4** | **3** | **3** | **3** | **161** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2781 |  | query_thermoml |
| GLOBlit_11517 |  | query_thermoml |
| GLOBlit_2652 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_31 | dimethyl sulfoxide | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | query_thermoml |
| GLOBconstr_3 | Mole fraction | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |
| GLOBvar_5 | Mass fraction | query_thermoml |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | query_thermoml |
| GLOBprop_8 | Speed of sound, m/s | query_thermoml |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | query_thermoml |
| GLOBmeas_205 | Viscosity, Pa*s | query_thermoml |
| GLOBmeas_7 | Speed of sound, m/s | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 3 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Constraints | 2 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Properties | 2 |
| Unique Measurements | 3 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 161 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 161

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.01.007 | 1 | 6 | binary | query_thermoml |
| 10.1016/j.jct.2006.12.012 | 1 | 120 | binary | query_thermoml |
| 10.1021/je9001027 | 1 | 35 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.01.007 | PROPblock_3 | declared | 6 | binary | 2 | query_thermoml |
| 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | 2 | query_thermoml |
| 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'density_dmso_wate… | 184 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'density_dmso_wate… | 132 | — | — | 0.0 |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'density_dmso_wate… | 566 | — | — | 0.3 |
| 4 | 4 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 282 | — | — | 121.9 |
| 5 | 5 | `query_thermoml` | instruction=Search for blocks with GLOBpr…, purpos… | 2,188 | — | — | 202.5 |
| 6 | 6 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 15,312 | — | — | 114.2 |
| 7 | 6 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 8,974 | — | — | 175.8 |
| 8 | 9 | `inspect_block` | block_number=PROPblock_4, doi=10.1016/j.jct.2006.1… | 1,402 | — | — | 0.1 |
| 9 | 9 | `inspect_block` | block_number=PROPblock_3, doi=10.1016/j.jct.2006.1… | 1,379 | — | — | 0.0 |
| 10 | 9 | `inspect_block` | block_number=PROPblock_3, doi=10.1021/je9001027, p… | 1,368 | — | — | 0.1 |
| 11 | 9 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 209 | — | — | 125.4 |
| 12 | 10 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 154 | — | — | 0.1 |
| 13 | 10 | `fit_block` | block_number=PROPblock_3, composition_hint=mole_fr… | 163 | — | — | 0.0 |
| 14 | 10 | `fit_block` | block_number=PROPblock_4, composition_hint=mole_fr… | 163 | — | — | 0.0 |
| 15 | 11 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 221 | — | — | 0.0 |
| 16 | 11 | `fit_block` | block_number=PROPblock_3, composition_hint=mole_fr… | 924 | — | — | 0.8 |
| 17 | 11 | `fit_block` | block_number=PROPblock_4, composition_hint=mole_fr… | 895 | — | — | 0.9 |
| 18 | 12 | `fit_block_derived` | block_number=PROPblock_4, composition_hint=mole_fr… | 986 | — | — | 0.8 |
| 19 | 12 | `predict_from_rk` | coeffs=[206.288, -173.558, 107.086, …, mixing_rule… | 196 | — | — | 0.0 |
| 20 | 12 | `predict_from_rk` | coeffs=[3.70556, -3.85972, 2.18304, …, mixing_rule… | 222 | — | — | 0.0 |
| 21 | 14 | `predict_from_rk` | coeffs=[-3.58116e-06, 2.06691e-06, -…, n_points=10… | 217 | — | — | 0.0 |
| | | **TOTAL (21 tools)** | | **36,137** | | **0** | **742.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,479 | 2,479 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 7,186 | 7,186 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 10,665 | 10,665 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 17,207 | 17,207 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 390 | 20,411 | 2,921 | 14.9 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,100 | 21,121 | 2,011 | 9.2 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,718 | 21,739 | 1,887 | 8.9 |
| 4 | L0-main | claudeopus46 | 19,988 | 3,913 | 23,901 | 551 | 5.5 |
| 5 | L0-main | claudeopus46 | 20,021 | 3,156 | 23,177 | 785 | 6.1 |
| 6 | L1-worker | claudeopus46 | 20,643 | 447 | 21,090 | 6,232 | 31.4 |
| 7 | L1-worker | claudeopus46 | 20,643 | 7,407 | 28,050 | 873 | 6.4 |
| 8 | L1-worker | claudeopus46 | 2,065 | 469 | 2,534 | 400 | 3.6 |
| 9 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 424 | 4.2 |
| 10 | L1-worker | claudeopus46 | 20,643 | 7,912 | 28,555 | 844 | 6.7 |
| 11 | L1-worker | claudeopus46 | 2,065 | 5,158 | 7,223 | 1,563 | 12.6 |
| 12 | L1-worker | claudeopus46 | 20,610 | 10,503 | 31,113 | 457 | 4.3 |
| 13 | L1-worker | claudeopus46 | 20,643 | 9,731 | 30,374 | 2,422 | 15.2 |
| 14 | L1-worker | claudeopus46 | 1,356 | 2,553 | 3,909 | 871 | 4.4 |
| 15 | L1-worker | claudeopus46 | 536 | 2,433 | 2,969 | 884 | 5.4 |
| 16 | L1-worker | claudeopus46 | 1,323 | 6,925 | 8,248 | 2,950 | 12.3 |
| 17 | L1-worker | claudeopus46 | 298 | 3,672 | 3,970 | 2,247 | 10.0 |
| 18 | L1-worker | claudeopus46 | 747 | 45,537 | 46,284 | 850 | 8.7 |
| 19 | L0-main | claudeopus46 | 20,021 | 5,703 | 25,724 | 1,058 | 9.7 |
| 20 | L1-worker | claudeopus46 | 20,643 | 582 | 21,225 | 904 | 6.5 |
| 21 | L1-worker | claudeopus46 | 20,643 | 2,107 | 22,750 | 5,365 | 27.0 |
| 22 | L1-worker | claudeopus46 | 2,065 | 554 | 2,619 | 1,544 | 9.4 |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,197 | 23,840 | 6,128 | 29.0 |
| 24 | L1-worker | claudeopus46 | 2,065 | 529 | 2,594 | 1,443 | 8.9 |
| 25 | L1-worker | claudeopus46 | 20,610 | 5,347 | 25,957 | 549 | 4.5 |
| 26 | L1-worker | claudeopus46 | 20,643 | 4,575 | 25,218 | 9,261 | 43.6 |
| 27 | L1-worker | claudeopus46 | 2,065 | 364 | 2,429 | 429 | 3.7 |
| 28 | L1-worker | claudeopus46 | 2,065 | 13,711 | 15,776 | 1,484 | 12.4 |
| 29 | L1-worker | claudeopus46 | 20,643 | 6,889 | 27,532 | 5,033 | 27.7 |
| 30 | L1-worker | claudeopus46 | 20,643 | 12,497 | 33,140 | 912 | 3.9 |
| 31 | L1-worker | claudeopus46 | 1,323 | 7,683 | 9,006 | 92 | 2.2 |
| 32 | L1-worker | claudeopus46 | 1,356 | 1,043 | 2,399 | 420 | 3.5 |
| 33 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 1.9 |
| 34 | L1-worker | claudeopus46 | 536 | 923 | 1,459 | 616 | 4.3 |
| 35 | L1-worker | claudeopus46 | 747 | 8,649 | 9,396 | 622 | 6.0 |
| 36 | L0-main | claudeopus46 | 20,021 | 9,001 | 29,022 | 1,511 | 9.0 |
| 37 | L1-worker | claudeopus46 | 20,643 | 464 | 21,107 | 1,806 | 10.2 |
| 38 | L1-worker | claudeopus46 | 20,643 | 2,998 | 23,641 | 9,676 | 41.0 |
| 39 | L1-worker | claudeopus46 | 2,065 | 5,674 | 7,739 | 1,510 | 14.0 |
| 40 | L1-worker | claudeopus46 | 2,065 | 612 | 2,677 | 1,285 | 9.3 |
| 41 | L1-worker | claudeopus46 | 20,643 | 5,037 | 25,680 | 2,157 | 13.5 |
| 42 | L1-worker | claudeopus46 | 1,356 | 1,786 | 3,142 | 787 | 5.2 |
| 43 | L1-worker | claudeopus46 | 536 | 1,666 | 2,202 | 859 | 5.8 |
| 44 | L1-worker | claudeopus46 | 1,323 | 6,273 | 7,596 | 1,061 | 6.8 |
| 45 | L1-worker | claudeopus46 | 298 | 1,783 | 2,081 | 835 | 4.3 |
| 46 | L1-worker | claudeopus46 | 747 | 20,441 | 21,188 | 609 | 6.5 |
| 47 | L1-worker | claudeopus46 | 20,643 | 474 | 21,117 | 1,277 | 7.2 |
| 48 | L1-worker | claudeopus46 | 2,065 | 549 | 2,614 | 1,258 | 9.0 |
| 49 | L1-worker | claudeopus46 | 2,065 | 2,264 | 4,329 | 1,582 | 11.0 |
| 50 | L1-worker | claudeopus46 | 20,643 | 2,961 | 23,604 | 1,339 | 8.3 |
| 51 | L1-worker | claudeopus46 | 2,065 | 477 | 2,542 | 1,437 | 9.5 |
| 52 | L1-worker | claudeopus46 | 2,065 | 512 | 2,577 | 1,333 | 8.5 |
| 53 | L1-worker | claudeopus46 | 20,643 | 5,492 | 26,135 | 996 | 6.8 |
| 54 | L1-worker | claudeopus46 | 2,065 | 519 | 2,584 | 940 | 6.5 |
| 55 | L1-worker | claudeopus46 | 2,065 | 11,035 | 13,100 | 1,576 | 11.4 |
| 56 | L1-worker | claudeopus46 | 20,610 | 8,776 | 29,386 | 508 | 6.8 |
| 57 | L1-worker | claudeopus46 | 20,643 | 8,004 | 28,647 | 3,796 | 23.5 |
| 58 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 1,250 | 9.0 |
| 59 | L1-worker | claudeopus46 | 20,643 | 9,403 | 30,046 | 723 | 5.2 |
| 60 | L1-worker | claudeopus46 | 2,065 | 469 | 2,534 | 749 | 5.6 |
| 61 | L1-worker | claudeopus46 | 20,643 | 10,363 | 31,006 | 1,564 | 11.8 |
| 62 | L1-worker | claudeopus46 | 1,356 | 1,695 | 3,051 | 658 | 4.9 |
| 63 | L1-worker | claudeopus46 | 536 | 1,575 | 2,111 | 699 | 5.4 |
| 64 | L1-worker | claudeopus46 | 1,323 | 13,020 | 14,343 | 633 | 6.6 |
| 65 | L1-worker | claudeopus46 | 298 | 1,355 | 1,653 | 506 | 3.2 |
| 66 | L1-worker | claudeopus46 | 747 | 20,935 | 21,682 | 719 | 8.1 |
| 67 | L0-main | claudeopus46 | 19,988 | 13,336 | 33,324 | 429 | 5.3 |
| 68 | L0-main | claudeopus46 | 20,021 | 12,579 | 32,600 | 2,849 | 18.5 |
| 69 | L0-main | claudeopus46 | 20,021 | 14,076 | 34,097 | 1,478 | 8.2 |
| 70 | L0-main | claudeopus46 | 20,021 | 15,607 | 35,628 | 1,469 | 8.1 |
| 71 | L1-worker | claudeopus46 | 20,643 | 413 | 21,056 | 953 | 9.9 |
| 72 | L1-worker | claudeopus46 | 2,065 | 577 | 2,642 | 1,778 | 10.7 |
| 73 | L1-worker | claudeopus46 | 20,643 | 2,009 | 22,652 | 993 | 6.7 |
| 74 | L1-worker | claudeopus46 | 20,643 | 3,730 | 24,373 | 903 | 4.8 |
| 75 | L1-worker | claudeopus46 | 2,065 | 1,369 | 3,434 | 476 | 4.6 |
| 76 | L1-worker | claudeopus46 | 2,065 | 19,016 | 21,081 | 1,583 | 12.2 |
| 77 | L1-worker | claudeopus46 | 20,610 | 6,042 | 26,652 | 514 | 4.3 |
| 78 | L1-worker | claudeopus46 | 20,643 | 5,270 | 25,913 | 3,943 | 24.2 |
| 79 | L1-worker | claudeopus46 | 20,643 | 9,788 | 30,431 | 1,845 | 6.7 |
| 80 | L1-worker | claudeopus46 | 1,356 | 1,976 | 3,332 | 720 | 4.5 |
| 81 | L1-worker | claudeopus46 | 536 | 1,856 | 2,392 | 949 | 5.9 |
| 82 | L1-worker | claudeopus46 | 1,323 | 7,397 | 8,720 | 2,613 | 10.7 |
| 83 | L1-worker | claudeopus46 | 298 | 3,335 | 3,633 | 2,090 | 7.4 |
| 84 | L1-worker | claudeopus46 | 1,160 | 10,513 | 11,673 | 1,507 | 6.9 |
| 85 | L0-main | claudeopus46 | 19,988 | 18,243 | 38,231 | 385 | 4.8 |
| 86 | L0-main | claudeopus46 | 20,021 | 17,613 | 37,634 | 2,790 | 16.4 |
| 87 | L0-main | claudeopus46 | 20,021 | 19,212 | 39,233 | 2,503 | 12.5 |
| 88 | L0-main | claudeopus46 | 20,021 | 24,867 | 44,888 | 1,868 | 12.0 |
| 89 | L0-main | claudeopus46 | 19,988 | 28,837 | 48,825 | 555 | 5.2 |
| 90 | L0-main | claudeopus46 | 20,021 | 28,077 | 48,098 | 732 | 6.0 |
| 91 | L0-main | claudeopus46 | 20,021 | 28,785 | 48,806 | 676 | 5.3 |
| 92 | L0-main | claudeopus46 | 20,021 | 29,209 | 49,230 | 5,307 | 41.8 |
| 93 | L0-main | claudeopus46 | 1,356 | 5,436 | 6,792 | 1,233 | 8.8 |
| 94 | L0-main | claudeopus46 | 298 | 1,615 | 1,913 | 1,221 | 4.8 |
| 95 | L0-main | claudeopus46 | 1,323 | 67,514 | 68,837 | 3,053 | 17.9 |
| 96 | L0-main | claudeopus46 | 298 | 3,895 | 4,193 | 2,494 | 13.1 |
| 97 | L0-main | claudeopus46 | 1,562 | 7,012 | 8,574 | 1,168 | 11.3 |


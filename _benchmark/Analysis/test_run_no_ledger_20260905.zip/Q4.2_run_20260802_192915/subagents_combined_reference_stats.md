# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 6 | 22,485 | 45,681 | 10,259 | 68,166 | 11,361 | 58.0 | claudeopus46 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| L1-worker | 10 | 70,319 | 65,284 | 13,418 | 135,603 | 13,560 | 80.5 | claudeopus46 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| L0-main | 7 | 41,397 | 116,997 | 18,742 | 158,394 | 22,627 | 110.1 | claudeopus46 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| L1-worker | 40 | 338,563 | 309,273 | 54,275 | 647,836 | 16,195 | 363.5 | claudeopus46 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| **TOTAL** | **63** | **472,764** | **537,235** | **96,694** | **1,009,999** | **63,743** | **612.1** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| `search_blocks` | 2 | 1 | 3 | 4 | 4 | 4 | 212 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| `search_blocks` | 2 | 1 | 3 | 4 | 4 | 4 | 212 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| `search_system_registry` | 2 | 1 | 3 | 3 | 3 | 3 | 200 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| `search_blocks` | 2 | 1 | 4 | 4 | 5 | 5 | 215 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| `search_blocks` | 2 | 1 | 4 | 4 | 5 | 5 | 215 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| **TOTAL** | **16** | **5** | **17** | **19** | **21** | **21** | **1,054** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique References | 4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique Properties | 1 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique Measurements | 4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique Phases | 1 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique Solvents | 2 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique Variables | 3 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique Constraints | 4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Unique parent blocks | 4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Explicit block/subsystem targets | 4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Subsystem targets | 0 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| Target-matched data points | 212 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBlit_4415 |  | search_blocks, search_system_registry |
| GLOBlit_5201 |  | search_blocks, search_system_registry |
| GLOBlit_8888 |  | search_blocks |
| GLOBlit_11504 |  | search_blocks, search_system_registry |
| GLOBlit_7629 |  | search_blocks |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks |
| GLOBmeas_206 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBphase_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_2 |  | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_15 | Mass ratio of solute to solvent | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_4 | Frequency, MHz | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_22 | Volume fraction | search_blocks, search_system_registry |
| GLOBblocktype_1 |  | search_system_registry |
| Unique Compounds | 2 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique References | 5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique Properties | 1 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique Measurements | 4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique Phases | 1 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique Solvents | 2 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique Variables | 4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique Constraints | 4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique Block_Types | 1 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Unique parent blocks | 5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Explicit block/subsystem targets | 5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Subsystem targets | 0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| Target-matched data points | 842 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| **TOTAL** | **1,117** |  |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | — | search_blocks | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | — | search_blocks | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | — | search_blocks | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 10.1021/je900064e | PROPblock_5 | declared | 8 | binary | — | search_blocks | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 10.1016/j.jct.2015.06.024 | 1 | 40 | binary | search_blocks, search_system_registry | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |  |  |
| 10.1016/j.jct.2018.02.022 | 1 | 152 | binary | search_blocks, search_system_registry | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |  |  |
| 10.1021/acs.jced.8b00723 | 1 | 3 | binary | search_blocks | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |  |  |
| 10.1021/je0601098 | 1 | 12 | binary | search_blocks | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |  |  |
| 10.1021/je900064e | 1 | 8 | binary | search_blocks, search_system_registry | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |  |  |
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | 2 | search_blocks, search_system_registry | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | 2 | search_blocks, search_system_registry | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 10.1021/acs.jced.8b00723 | PROPblock_13 | declared | 3 | binary | — | search_blocks | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | — | search_blocks | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 10.1021/je900064e | PROPblock_5 | declared | 8 | binary | 2 | search_blocks, search_system_registry | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| **TOTAL** | **5** | **215** | **427** |  | **6** |  |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `resolve_compound_ids` | purpose=Resolve ethanol and water to …, queries=['… | 250 | KEEP | 250 | 3.5 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 2 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_2'], limit=50, p… | 1,465 | KEEP | 1465 | 18.9 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 3 | 1 | `L1_query` | context=User is analyzing speed of so…, id_catalog… | 270 | — | — | 75.3 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 1 | 2 | `resolve_compound_ids` | purpose=Resolve compound IDs for etha…, queries=['… | 246 | KEEP | 246 | 16.8 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 1,300 | KEEP | 1285 | 22.0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 3 | 5 | `search_system_registry` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=100, … | 987 | KEEP | 987 | 20.6 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 4 | 1 | `L1_query` | context=Known blocks to exclude: PROP…, id_catalog… | 1,094 | — | — | 144.8 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 5 | 1 | `resolve_compound_ids` | purpose=Resolve ethanol and water to …, queries=['… | 226 | KEEP | 226 | 3.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 6 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 1,065 | KEEP | 1035 | 21.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 7 | 2 | `L1_query` | context=Previous search for ethanol+w…, id_catalog… | 10,136 | — | — | 135.0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 8 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_2'], limit=50, p… | 1,491 | KEEP | 1415 | 22.9 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 9 | 3 | `L1_query` | context=Already known blocks: PROPblo…, id_catalog… | 270 | — | — | 86.2 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| **TOTAL** | **25** |  |  | **18,800** |  | **6,909** | **571.0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,065 | 10,670 | 1,206 | 7.3 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,226 | 21,869 | 742 | 5.0 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 3 | L1-worker | claudeopus46 | 2,065 | 462 | 2,527 | 428 | 3.4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,930 | 22,573 | 917 | 6.6 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 5 | L1-worker | claudeopus46 | 2,065 | 8,186 | 10,251 | 1,811 | 14.4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,907 | 24,550 | 2,346 | 12.8 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,475 | 3,831 | 815 | 4.4 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 8 | L1-worker | claudeopus46 | 536 | 2,355 | 2,891 | 1,096 | 6.5 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 9 | L1-worker | claudeopus46 | 1,323 | 6,271 | 7,594 | 2,481 | 10.6 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 10 | L1-worker | claudeopus46 | 298 | 3,203 | 3,501 | 1,872 | 7.3 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 11 | L1-worker | claudeopus46 | 747 | 35,269 | 36,016 | 910 | 9.5 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 12 | L0-main | claudeopus46 | 9,605 | 32,657 | 42,262 | 3,560 | 22.8 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 13 | L0-main | claudeopus46 | 1,356 | 2,968 | 4,324 | 979 | 6.1 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 14 | L0-main | claudeopus46 | 298 | 1,361 | 1,659 | 967 | 3.6 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 15 | L0-main | claudeopus46 | 1,323 | 5,097 | 6,420 | 1,865 | 9.9 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 16 | L0-main | claudeopus46 | 298 | 2,533 | 2,831 | 1,682 | 8.3 | Find all data blocks containing speed of sound measurements  (query_runs/run_7) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,274 | 10,879 | 1,907 | 10.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,615 | 22,258 | 739 | 5.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,287 | 22,930 | 466 | 3.6 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 4 | L1-worker | claudeopus46 | 2,065 | 480 | 2,545 | 417 | 16.7 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,569 | 23,212 | 1,081 | 7.7 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 6 | L1-worker | claudeopus46 | 2,065 | 8,244 | 10,309 | 1,579 | 14.1 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 7 | L1-worker | claudeopus46 | 20,610 | 5,135 | 25,745 | 468 | 4.1 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,382 | 25,025 | 1,582 | 10.8 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 9 | L1-worker | claudeopus46 | 20,643 | 6,539 | 27,182 | 738 | 4.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 10 | L1-worker | claudeopus46 | 2,065 | 3,329 | 5,394 | 1,753 | 13.4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 11 | L1-worker | claudeopus46 | 20,643 | 7,563 | 28,206 | 3,002 | 19.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 12 | L1-worker | claudeopus46 | 1,356 | 2,061 | 3,417 | 570 | 4.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 13 | L1-worker | claudeopus46 | 1,323 | 8,613 | 9,936 | 715 | 5.8 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 14 | L1-worker | claudeopus46 | 536 | 1,941 | 2,477 | 1,060 | 7.1 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 15 | L1-worker | claudeopus46 | 298 | 1,437 | 1,735 | 588 | 3.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 16 | L1-worker | claudeopus46 | 747 | 17,556 | 18,303 | 898 | 7.7 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 17 | L1-worker | claudeopus46 | 1,160 | 10,374 | 11,534 | 674 | 4.0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 18 | L1-worker | claudeopus46 | 747 | 17,642 | 18,389 | 1,000 | 8.0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 19 | L0-main | claudeopus46 | 9,605 | 2,977 | 12,582 | 1,876 | 11.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 20 | L1-worker | claudeopus46 | 20,643 | 1,532 | 22,175 | 811 | 6.4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 21 | L1-worker | claudeopus46 | 2,065 | 453 | 2,518 | 393 | 3.4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,196 | 22,839 | 903 | 6.7 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,720 | 24,363 | 7,298 | 40.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 24 | L1-worker | claudeopus46 | 2,065 | 9,660 | 11,725 | 1,782 | 13.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 25 | L1-worker | claudeopus46 | 20,610 | 5,481 | 26,091 | 493 | 4.6 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 26 | L1-worker | claudeopus46 | 20,643 | 4,728 | 25,371 | 4,524 | 27.8 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 27 | L1-worker | claudeopus46 | 20,643 | 9,827 | 30,470 | 1,683 | 6.4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 28 | L1-worker | claudeopus46 | 536 | 1,694 | 2,230 | 643 | 4.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 29 | L1-worker | claudeopus46 | 1,356 | 1,814 | 3,170 | 749 | 4.6 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 30 | L1-worker | claudeopus46 | 1,323 | 5,802 | 7,125 | 678 | 4.8 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 31 | L1-worker | claudeopus46 | 298 | 1,400 | 1,698 | 551 | 3.6 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 32 | L1-worker | claudeopus46 | 747 | 14,316 | 15,063 | 861 | 7.8 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 33 | L0-main | claudeopus46 | 9,605 | 23,952 | 33,557 | 2,809 | 19.2 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 34 | L1-worker | claudeopus46 | 20,643 | 12,120 | 32,763 | 922 | 6.6 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 35 | L1-worker | claudeopus46 | 2,065 | 9,703 | 11,768 | 1,722 | 14.4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 36 | L1-worker | claudeopus46 | 20,643 | 14,202 | 34,845 | 2,968 | 16.6 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 37 | L1-worker | claudeopus46 | 1,356 | 3,099 | 4,455 | 983 | 6.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 38 | L1-worker | claudeopus46 | 536 | 2,979 | 3,515 | 977 | 6.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 39 | L1-worker | claudeopus46 | 1,323 | 6,920 | 8,243 | 2,650 | 11.4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 40 | L1-worker | claudeopus46 | 298 | 3,372 | 3,670 | 2,127 | 7.9 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 41 | L1-worker | claudeopus46 | 747 | 41,108 | 41,855 | 430 | 5.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 42 | L1-worker | claudeopus46 | 1,160 | 10,260 | 11,420 | 2,139 | 8.0 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 43 | L1-worker | claudeopus46 | 747 | 41,120 | 41,867 | 658 | 6.2 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 44 | L0-main | claudeopus46 | 9,605 | 61,146 | 70,751 | 3,507 | 24.5 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 45 | L0-main | claudeopus46 | 1,356 | 2,575 | 3,931 | 703 | 4.4 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 46 | L0-main | claudeopus46 | 1,323 | 20,071 | 21,394 | 4,334 | 23.3 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 47 | L0-main | claudeopus46 | 298 | 5,002 | 5,300 | 3,606 | 16.9 | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| **TOTAL** |  |  | **472,764** | **537,235** | **1,009,999** | **96,694** | **612.1** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,840 | 3,840 | 0 | 0.0% | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| 2 | interval=3 | skipped_by_agent | 4,186 | 4,186 | 0 | 0.0% | Find data blocks with speed of sound (GLOBprop_8) measuremen (query_runs/run_8) |
| **TOTAL** |  |  | **8,026** | **8,026** | **0** | **0** |  |

# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:29:16
**Wall time (at last flush):** 1,214.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 47 | 710,595 | 660,298 | 56,574 | 1,370,893 | 29,167 | 389.2 | claudeopus46 |
| L1-worker | 22 | 181,432 | 87,142 | 52,190 | 268,574 | 12,207 | 250.0 | claudeopus46 |
| **TOTAL** | **69** | **892,027** | **747,440** | **108,764** | **1,639,467** | **23,760** | **639.2** | |

**Estimated tokens:** ~409,866 input + ~27,191 output = ~437,057 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `propose_fitting_plan` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | id_catalog=[{'id': 'GLOBprop_8', 'type':…, instruc… | 164 | — | — | 0.0 |
| 2 | 2 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_8', …, instruc… | 233 | — | — | 0.0 |
| 3 | 3 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_8', …, instruc… | 371 | — | — | 98.0 |
| 4 | 4 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 507 | — | — | 133.6 |
| 5 | 6 | `run_query_agent` | context=Looking for speed of sound da…, purpose=Fi… | 6,885 | — | — | 124.5 |
| 6 | 10 | `inspect_block` | block_number=PROPblock_20, doi=10.1016/j.jct.2018.… | 143 | — | — | 0.2 |
| 7 | 14 | `inspect_block` | block_number=PROPblock_20, doi=10.1016/j.jct.2018.… | 143 | — | — | 0.2 |
| 8 | 18 | `inspect_block` | block_number=PROPblock_19, doi=10.1021/je0601098, … | 1,385 | — | — | 0.1 |
| 9 | 18 | `inspect_block` | block_number=PROPblock_8, doi=10.1016/j.jct.2015.0… | 143 | — | — | 0.1 |
| 10 | 18 | `inspect_block` | block_number=PROPblock_5, doi=10.1021/je900064e, p… | 1,354 | — | — | 0.1 |
| 11 | 21 | `propose_fitting_plan` | block_number=PROPblock_20, doi=10.1016/j.jct.2018.… | 134 | — | — | 0.2 |
| 12 | 24 | `fit_block` | block_number=PROPblock_20, doi=10.1016/j.jct.2018.… | 153 | — | — | 0.2 |
| 13 | 24 | `run_query_agent` | context=PROPblock_20 from 10.1016/j.j…, purpose=Fi… | 8,816 | — | — | 473.0 |
| 14 | 27 | `fit_block` | block_number=PROPblock_20, doi=10.1016/j.jct.2018.… | 142 | — | — | 0.1 |
| 15 | 27 | `fit_block` | block_number=PROPblock_19, composition_hint=molali… | 251 | — | — | 0.1 |
| 16 | 28 | `fit_block` | block_number=PROPblock_20, doi=10.1016/j.jct.2018.… | 139 | — | — | 0.1 |
| 17 | 28 | `fit_block` | block_number=PROPblock_19, doi=10.1021/je0601098, … | 764 | — | — | 1.4 |
| 18 | 28 | `predict_from_rk` | coeffs=[-1324.1, 1102.1, -1424.2, 10…, n_points=10… | 186 | — | — | 0.0 |
| 19 | 28 | `compute_ideal_baseline` | n_points=101, property_type=speed_of_sound, pure_v… | 128 | — | — | 0.0 |
| | | **TOTAL (19 tools)** | | **22,041** | | **0** | **831.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,272 | 2,272 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 10,858 | 10,858 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 19,334 | 19,334 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 20,821 | 20,821 | 0 | 0.0% |
| 5 | interval=3 | compacted | 23,197 | 22,994 | 203 | 0.9% |
| 6 | interval=3 | skipped_by_agent | 25,325 | 25,325 | 0 | 0.0% |

**Compaction efficiency:** 203 chars removed across 1 executed compaction(s) (0.9% of pre-compaction context); 5 skip decision(s).

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 379 | 20,400 | 1,302 | 8.4 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,009 | 21,030 | 896 | 7.9 |
| 3 | L0-main | claudeopus46 | 20,021 | 1,706 | 21,727 | 740 | 7.0 |
| 4 | L1-worker | claudeopus46 | 20,643 | 474 | 21,117 | 651 | 5.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 1,746 | 22,389 | 868 | 5.0 |
| 6 | L1-worker | claudeopus46 | 2,065 | 696 | 2,761 | 830 | 5.8 |
| 7 | L1-worker | claudeopus46 | 20,643 | 2,108 | 22,751 | 7,421 | 33.8 |
| 8 | L1-worker | claudeopus46 | 20,643 | 10,150 | 30,793 | 2,302 | 10.7 |
| 9 | L1-worker | claudeopus46 | 1,356 | 2,431 | 3,787 | 746 | 3.8 |
| 10 | L1-worker | claudeopus46 | 536 | 2,311 | 2,847 | 692 | 4.5 |
| 11 | L1-worker | claudeopus46 | 1,323 | 4,617 | 5,940 | 3,735 | 14.3 |
| 12 | L1-worker | claudeopus46 | 298 | 4,457 | 4,755 | 2,868 | 10.5 |
| 13 | L1-worker | claudeopus46 | 1,160 | 8,985 | 10,145 | 2,868 | 11.4 |
| 14 | L0-main | claudeopus46 | 19,988 | 3,293 | 23,281 | 584 | 4.6 |
| 15 | L0-main | claudeopus46 | 20,021 | 2,536 | 22,557 | 839 | 6.4 |
| 16 | L1-worker | claudeopus46 | 20,643 | 451 | 21,094 | 984 | 6.4 |
| 17 | L1-worker | claudeopus46 | 20,643 | 2,163 | 22,806 | 8,671 | 35.3 |
| 18 | L1-worker | claudeopus46 | 2,065 | 465 | 2,530 | 491 | 3.5 |
| 19 | L1-worker | claudeopus46 | 2,065 | 411 | 2,476 | 462 | 6.3 |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,803 | 23,446 | 7,112 | 35.7 |
| 21 | L1-worker | claudeopus46 | 20,643 | 10,490 | 31,133 | 2,483 | 12.2 |
| 22 | L1-worker | claudeopus46 | 536 | 2,215 | 2,751 | 1,120 | 5.9 |
| 23 | L1-worker | claudeopus46 | 1,356 | 2,335 | 3,691 | 844 | 6.2 |
| 24 | L1-worker | claudeopus46 | 1,323 | 5,197 | 6,520 | 3,669 | 15.0 |
| 25 | L1-worker | claudeopus46 | 298 | 4,391 | 4,689 | 2,768 | 10.7 |
| 26 | L1-worker | claudeopus46 | 1,160 | 9,307 | 10,467 | 198 | 3.0 |
| 27 | L1-worker | claudeopus46 | 747 | 8,939 | 9,686 | 407 | 4.5 |
| 28 | L0-main | claudeopus46 | 20,021 | 3,500 | 23,521 | 1,062 | 7.5 |
| 29 | L0-main | claudeopus46 | 20,021 | 4,286 | 24,307 | 937 | 5.8 |
| 30 | L0-main | claudeopus46 | 19,988 | 11,989 | 31,977 | 449 | 4.4 |
| 31 | L0-main | claudeopus46 | 20,021 | 11,230 | 31,251 | 697 | 5.9 |
| 32 | L0-main | claudeopus46 | 20,021 | 11,918 | 31,939 | 492 | 5.0 |
| 33 | L0-main | claudeopus46 | 20,021 | 12,558 | 32,579 | 576 | 4.2 |
| 34 | L0-main | claudeopus46 | 20,021 | 13,288 | 33,309 | 550 | 4.2 |
| 35 | L0-main | claudeopus46 | 20,021 | 12,966 | 32,987 | 472 | 4.3 |
| 36 | L0-main | claudeopus46 | 20,021 | 13,597 | 33,618 | 506 | 4.0 |
| 37 | L0-main | claudeopus46 | 20,021 | 14,224 | 34,245 | 530 | 5.3 |
| 38 | L0-main | claudeopus46 | 20,021 | 14,889 | 34,910 | 463 | 3.8 |
| 39 | L0-main | claudeopus46 | 20,021 | 14,541 | 34,562 | 1,308 | 9.1 |
| 40 | L0-main | claudeopus46 | 20,021 | 15,816 | 35,837 | 946 | 5.5 |
| 41 | L0-main | claudeopus46 | 20,021 | 16,996 | 37,017 | 1,080 | 6.1 |
| 42 | L0-main | claudeopus46 | 20,021 | 18,280 | 38,301 | 982 | 5.8 |
| 43 | L0-main | claudeopus46 | 19,988 | 21,921 | 41,909 | 405 | 4.8 |
| 44 | L0-main | claudeopus46 | 20,021 | 21,161 | 41,182 | 1,865 | 15.9 |
| 45 | L0-main | claudeopus46 | 20,021 | 21,985 | 42,006 | 766 | 6.7 |
| 46 | L0-main | claudeopus46 | 20,021 | 22,653 | 42,674 | 900 | 6.0 |
| 47 | L0-main | claudeopus46 | 19,988 | 23,483 | 43,471 | 562 | 4.4 |
| 48 | L0-main | claudeopus46 | 20,021 | 22,723 | 42,744 | 1,725 | 12.4 |
| 49 | L0-main | claudeopus46 | 20,021 | 23,709 | 43,730 | 1,491 | 8.9 |
| 50 | L0-main | claudeopus46 | 20,021 | 24,649 | 44,670 | 1,828 | 12.2 |
| 51 | L0-main | claudeopus46 | 19,988 | 26,040 | 46,028 | 517 | 4.8 |
| 52 | L0-main | claudeopus46 | 953 | 2,108 | 3,061 | 3 | 1.7 |
| 53 | L0-main | claudeopus46 | 765 | 1,445 | 2,210 | 404 | 4.4 |
| 54 | L0-main | claudeopus46 | 765 | 1,445 | 2,210 | 334 | 3.4 |
| 55 | L0-main | claudeopus46 | 443 | 1,753 | 2,196 | 6 | 1.6 |
| 56 | L0-main | claudeopus46 | 765 | 1,581 | 2,346 | 723 | 5.0 |
| 57 | L0-main | claudeopus46 | 765 | 1,581 | 2,346 | 652 | 4.9 |
| 58 | L0-main | claudeopus46 | 765 | 1,581 | 2,346 | 613 | 4.6 |
| 59 | L0-main | claudeopus46 | 20,021 | 25,536 | 45,557 | 1,773 | 14.6 |
| 60 | L0-main | claudeopus46 | 20,021 | 26,489 | 46,510 | 953 | 6.3 |
| 61 | L0-main | claudeopus46 | 20,021 | 27,384 | 47,405 | 864 | 5.9 |
| 62 | L0-main | claudeopus46 | 19,988 | 28,450 | 48,438 | 577 | 5.2 |
| 63 | L0-main | claudeopus46 | 20,021 | 27,690 | 47,711 | 11,465 | 63.7 |
| 64 | L0-main | claudeopus46 | 20,021 | 31,472 | 51,493 | 4,277 | 27.5 |
| 65 | L0-main | claudeopus46 | 1,356 | 4,408 | 5,764 | 1,320 | 8.6 |
| 66 | L0-main | claudeopus46 | 298 | 1,702 | 2,000 | 1,308 | 4.5 |
| 67 | L0-main | claudeopus46 | 1,323 | 56,598 | 57,921 | 2,495 | 17.4 |
| 68 | L0-main | claudeopus46 | 298 | 3,337 | 3,635 | 2,111 | 9.0 |
| 69 | L0-main | claudeopus46 | 1,562 | 8,413 | 9,975 | 1,226 | 9.6 |


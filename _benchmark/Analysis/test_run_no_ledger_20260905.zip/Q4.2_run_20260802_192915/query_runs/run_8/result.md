# Delegated query run — result

**Question:** Find data blocks with speed of sound (GLOBprop_8) measurements for binary ethanol + water mixtures that cover the FULL mole fraction range (from x=0 to x=1) at or near 298.15 K. I already know about PROPblock_20 (10.1016/j.jct.2018.02.022) but it has a technical issue. Are there any OTHER blocks with full composition range speed of sound data for this system?

**Iterations:** 4  |  **Elapsed:** 432.0s  |  **Tools:** 3  |  **Timed out:** False

---

## Answer

Unfortunately, **no other speed-of-sound data blocks** in the ThermoML database cover the full ethanol mole-fraction range (x = 0 to x = 1) for the ethanol + water binary system. **PROPblock_20** (DOI 10.1016/j.jct.2018.02.022, GLOBlit_5201) is the only block with that coverage.

Here is the complete inventory of all five speed-of-sound blocks for ethanol + water in the database:

| Block | DOI | Literature ID | Composition variable | Composition range | Temperature | Data points | Full x range? |
|-------|-----|---------------|---------------------|-------------------|-------------|-------------|---------------|
| **PROPblock_20** | 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | Mole fraction of ethanol | 0.0–1.0 (38 unique values) | 293.15–308.15 K (4 isotherms) | 152 | **Yes** ✓ |
| PROPblock_8 | 10.1016/j.jct.2015.06.024 | GLOBlit_4415 | Molality of ethanol | 0.022–0.219 mol/kg (~0–0.4 mol% EtOH) | 288.15–308.15 K (5 isotherms) | 40 | No — extremely dilute only |
| PROPblock_19 | 10.1021/je0601098 | GLOBlit_8888 | Molality of water in ethanol | 0–1.02 mol/kg (~98–100 mol% EtOH) | 298.15 K (fixed) | 12 | No — ethanol-rich side only |
| PROPblock_5 | 10.1021/je900064e | GLOBlit_11504 | Volume fraction fixed at 0.5 | Single composition | 288.15–323.15 K | 8 | No — fixed composition |
| PROPblock_13 | 10.1021/acs.jced.8b00723 | GLOBlit_7629 | Mass ratio of ethanol | 0.05–0.15 | 308.15 K (fixed) | 3 | No — narrow dilute range |

**Summary of the situation:**

- **PROPblock_20** is the sole block spanning the full mole-fraction range. It covers x(ethanol) = 0.0024–0.9895 at four temperatures including 298.15 K, with speed of sound values ranging from ~1110 to ~1626 m/s. The speed-of-sound minimum near x ≈ 0.3 (characteristic of the ethanol–water system due to strong hydrogen-bonding interactions and microheterogeneity) would be captured by this dataset.

- **PROPblock_8** and **PROPblock_19** together could in principle cover both dilute ends (water-rich and ethanol-rich), but they use molality rather than mole fraction, cover only tiny slices of the composition space, and would leave the entire middle range (x ≈ 0.01–0.98) unmeasured.

- **PROPblock_5** and **PROPblock_13** are too limited (fixed composition or only 3 points) to be useful for full-range analysis.

There are no alternative full-range speed-of-sound datasets for ethanol + water in the ThermoML database beyond PROPblock_20.

### Core claims

- PROPblock_20 (DOI 10.1016/j.jct.2018.02.022, GLOBlit_5201) is the only speed-of-sound data block in the ThermoML database that covers the full ethanol mole-fraction range (x = 0 to x = 1) for the ethanol + water binary system, spanning x(ethanol) = 0.0024–0.9895 at four temperatures (293.15–308.15 K) with 152 data points.
- The four other speed-of-sound blocks for ethanol + water in the database (PROPblock_8, PROPblock_19, PROPblock_5, PROPblock_13) each cover only narrow or fixed composition ranges and cannot substitute for full mole-fraction coverage.
- No alternative full-range speed-of-sound dataset for ethanol + water exists in the ThermoML database beyond PROPblock_20.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_20 |  | Speed of sound (GLOBprop_8) for ethanol+water binary system covering full mole fraction range (x_ethanol 0.0024–0.9895, 38 unique values) at 4 isotherms (293.15–308.15 K including 298.15 K), 152 data points. This is the ONLY block with full composition range coverage. Known technical issue with frequency_mhz column. |
| GLOBlit_4415 | 10.1016/j.jct.2015.06.024 | PROPblock_8 |  | Speed of sound (GLOBprop_8) for ethanol+water binary system. Ethanol molality 0.02159–0.21882 mol/kg (~0–0.4 mol% ethanol, extremely dilute water-rich end only). 5 isotherms (288.15–308.15 K) at 84.5 kPa, 40 data points. Does NOT cover full composition range. |
| GLOBlit_8888 | 10.1021/je0601098 | PROPblock_19 |  | Speed of sound (GLOBprop_8) for ethanol+water binary system. Molality of water in ethanol 0–1.02 mol/kg (~98–100 mol% ethanol, ethanol-rich side only). Fixed at 298.15 K, 12 data points. Does NOT cover full composition range. |
| GLOBlit_11504 | 10.1021/je900064e | PROPblock_5 |  | Speed of sound (GLOBprop_8) for ethanol+water binary system. Fixed volume fraction 0.5 (single composition), temperature scan 288.15–323.15 K, 8 data points. Does NOT cover full composition range. |
| GLOBlit_7629 | 10.1021/acs.jced.8b00723 | PROPblock_13 |  | Speed of sound (GLOBprop_8) for ethanol+water binary system. Mass ratio of ethanol 0.05–0.15, fixed at 308.15 K, only 3 data points in a narrow dilute range. Does NOT cover full composition range. |

### Suggested follow-ups

- Investigate whether PROPblock_20 (GLOBlit_5201) frequency_mhz constraint column issue can be worked around by filtering or ignoring that constraint during data extraction.
- Consider combining PROPblock_8 (water-rich dilute end) and PROPblock_19 (ethanol-rich end) for partial coverage, though the entire middle composition range (x ≈ 0.01–0.98) would remain unmeasured.
- Search for speed of sound data for ethanol+water in other databases (e.g., NIST TDE, Dortmund Data Bank) since the ThermoML database contains only PROPblock_20 with full composition range coverage.
- Check if PROPblock_20 data at 298.15 K can be extracted by selecting only that isotherm and ignoring the frequency_mhz metadata column.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_8",
    "registry_id": "speed_of_sound_m_s",
    "name": "Speed of sound, m/s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_4",
    "registry_id": "molality_mol_kg",
    "name": "Molality, mol/kg"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_4",
    "registry_id": "frequency_mhz",
    "name": "Frequency, MHz"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_7",
    "registry_id": "sing_around_technique_in_a_fixed_path_interferometer",
    "name": "Sing-around technique in a fixed-path interferometer"
  }
]
```

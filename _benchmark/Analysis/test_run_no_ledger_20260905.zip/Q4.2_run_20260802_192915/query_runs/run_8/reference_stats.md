# Reference Stats — query-agent

**Run started:** 2026-08-02 19:38:23
**Wall time (at last flush):** 472.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 41,397 | 116,997 | 18,742 | 158,394 | 22,627 | 110.1 | claudeopus46 |
| L1-worker | 40 | 338,563 | 309,273 | 54,275 | 647,836 | 16,195 | 363.5 | claudeopus46 |
| **TOTAL** | **47** | **379,960** | **426,270** | **73,017** | **806,230** | **17,153** | **473.6** | |

**Estimated tokens:** ~201,557 input + ~18,254 output = ~219,811 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 4 | 4 | 4 | 212 |
| `search_system_registry` | 2 | 1 | 3 | 3 | 3 | 3 | 200 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 4 | 4 | 5 | 5 | 215 |
| `search_blocks` | 2 | 1 | 4 | 4 | 5 | 5 | 215 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **12** | **4** | **14** | **15** | **17** | **17** | **842** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry |

#### References (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_4415 |  | search_blocks, search_system_registry |
| GLOBlit_5201 |  | search_blocks, search_system_registry |
| GLOBlit_8888 |  | search_blocks |
| GLOBlit_11504 |  | search_blocks, search_system_registry |
| GLOBlit_7629 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks |
| GLOBmeas_206 | Speed of sound, m/s | search_blocks, search_system_registry |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_2 |  | search_blocks |

#### Variables (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_15 | Mass ratio of solute to solvent | search_blocks |

#### Constraints (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_4 | Frequency, MHz | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_22 | Volume fraction | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 5 |
| Unique Properties | 1 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Solvents | 2 |
| Unique Variables | 4 |
| Unique Constraints | 4 |
| Unique Block_Types | 1 |
| Total DOIs | 5 |
| Unique parent blocks | 5 |
| Explicit block/subsystem targets | 5 |
| Subsystem targets | 0 |
| Target-matched data points | 842 |

---

## 3. DOI & Block References

**Unique DOIs:** 5  |  **Parent blocks:** 5  |  **Explicit targets:** 5  |  **Subsystems:** 0  |  **Target-matched datapoints:** 215

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2015.06.024 | 1 | 40 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | 1 | 152 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | 1 | 3 | binary | search_blocks |
| 10.1021/je0601098 | 1 | 12 | binary | search_blocks |
| 10.1021/je900064e | 1 | 8 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_13 | declared | 3 | binary | — | search_blocks |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | — | search_blocks |
| 10.1021/je900064e | PROPblock_5 | declared | 8 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | purpose=Resolve compound IDs for etha…, queries=['… | 246 | KEEP | 246 | 16.8 |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 1,300 | KEEP | 1285 | 22.0 |
| 3 | 5 | `search_system_registry` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=100, … | 987 | KEEP | 987 | 20.6 |
| 4 | 1 | `L1_query` | context=Known blocks to exclude: PROP…, id_catalog… | 1,094 | — | — | 144.8 |
| 5 | 1 | `resolve_compound_ids` | purpose=Resolve ethanol and water to …, queries=['… | 226 | KEEP | 226 | 3.5 |
| 6 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 1,065 | KEEP | 1035 | 21.5 |
| 7 | 2 | `L1_query` | context=Previous search for ethanol+w…, id_catalog… | 10,136 | — | — | 135.0 |
| 8 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_2'], limit=50, p… | 1,491 | KEEP | 1415 | 22.9 |
| 9 | 3 | `L1_query` | context=Already known blocks: PROPblo…, id_catalog… | 270 | — | — | 86.2 |
| | | **TOTAL (9 tools)** | | **16,815** | | **5,194** | **473.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,840 | 3,840 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,186 | 4,186 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,274 | 10,879 | 1,907 | 10.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,615 | 22,258 | 739 | 5.3 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,287 | 22,930 | 466 | 3.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 480 | 2,545 | 417 | 16.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,569 | 23,212 | 1,081 | 7.7 |
| 6 | L1-worker | claudeopus46 | 2,065 | 8,244 | 10,309 | 1,579 | 14.1 |
| 7 | L1-worker | claudeopus46 | 20,610 | 5,135 | 25,745 | 468 | 4.1 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,382 | 25,025 | 1,582 | 10.8 |
| 9 | L1-worker | claudeopus46 | 20,643 | 6,539 | 27,182 | 738 | 4.5 |
| 10 | L1-worker | claudeopus46 | 2,065 | 3,329 | 5,394 | 1,753 | 13.4 |
| 11 | L1-worker | claudeopus46 | 20,643 | 7,563 | 28,206 | 3,002 | 19.3 |
| 12 | L1-worker | claudeopus46 | 1,356 | 2,061 | 3,417 | 570 | 4.3 |
| 13 | L1-worker | claudeopus46 | 1,323 | 8,613 | 9,936 | 715 | 5.8 |
| 14 | L1-worker | claudeopus46 | 536 | 1,941 | 2,477 | 1,060 | 7.1 |
| 15 | L1-worker | claudeopus46 | 298 | 1,437 | 1,735 | 588 | 3.5 |
| 16 | L1-worker | claudeopus46 | 747 | 17,556 | 18,303 | 898 | 7.7 |
| 17 | L1-worker | claudeopus46 | 1,160 | 10,374 | 11,534 | 674 | 4.0 |
| 18 | L1-worker | claudeopus46 | 747 | 17,642 | 18,389 | 1,000 | 8.0 |
| 19 | L0-main | claudeopus46 | 9,605 | 2,977 | 12,582 | 1,876 | 11.3 |
| 20 | L1-worker | claudeopus46 | 20,643 | 1,532 | 22,175 | 811 | 6.4 |
| 21 | L1-worker | claudeopus46 | 2,065 | 453 | 2,518 | 393 | 3.4 |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,196 | 22,839 | 903 | 6.7 |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,720 | 24,363 | 7,298 | 40.5 |
| 24 | L1-worker | claudeopus46 | 2,065 | 9,660 | 11,725 | 1,782 | 13.3 |
| 25 | L1-worker | claudeopus46 | 20,610 | 5,481 | 26,091 | 493 | 4.6 |
| 26 | L1-worker | claudeopus46 | 20,643 | 4,728 | 25,371 | 4,524 | 27.8 |
| 27 | L1-worker | claudeopus46 | 20,643 | 9,827 | 30,470 | 1,683 | 6.4 |
| 28 | L1-worker | claudeopus46 | 536 | 1,694 | 2,230 | 643 | 4.3 |
| 29 | L1-worker | claudeopus46 | 1,356 | 1,814 | 3,170 | 749 | 4.6 |
| 30 | L1-worker | claudeopus46 | 1,323 | 5,802 | 7,125 | 678 | 4.8 |
| 31 | L1-worker | claudeopus46 | 298 | 1,400 | 1,698 | 551 | 3.6 |
| 32 | L1-worker | claudeopus46 | 747 | 14,316 | 15,063 | 861 | 7.8 |
| 33 | L0-main | claudeopus46 | 9,605 | 23,952 | 33,557 | 2,809 | 19.2 |
| 34 | L1-worker | claudeopus46 | 20,643 | 12,120 | 32,763 | 922 | 6.6 |
| 35 | L1-worker | claudeopus46 | 2,065 | 9,703 | 11,768 | 1,722 | 14.4 |
| 36 | L1-worker | claudeopus46 | 20,643 | 14,202 | 34,845 | 2,968 | 16.6 |
| 37 | L1-worker | claudeopus46 | 1,356 | 3,099 | 4,455 | 983 | 6.3 |
| 38 | L1-worker | claudeopus46 | 536 | 2,979 | 3,515 | 977 | 6.5 |
| 39 | L1-worker | claudeopus46 | 1,323 | 6,920 | 8,243 | 2,650 | 11.4 |
| 40 | L1-worker | claudeopus46 | 298 | 3,372 | 3,670 | 2,127 | 7.9 |
| 41 | L1-worker | claudeopus46 | 747 | 41,108 | 41,855 | 430 | 5.5 |
| 42 | L1-worker | claudeopus46 | 1,160 | 10,260 | 11,420 | 2,139 | 8.0 |
| 43 | L1-worker | claudeopus46 | 747 | 41,120 | 41,867 | 658 | 6.2 |
| 44 | L0-main | claudeopus46 | 9,605 | 61,146 | 70,751 | 3,507 | 24.5 |
| 45 | L0-main | claudeopus46 | 1,356 | 2,575 | 3,931 | 703 | 4.4 |
| 46 | L0-main | claudeopus46 | 1,323 | 20,071 | 21,394 | 4,334 | 23.3 |
| 47 | L0-main | claudeopus46 | 298 | 5,002 | 5,300 | 3,606 | 16.9 |


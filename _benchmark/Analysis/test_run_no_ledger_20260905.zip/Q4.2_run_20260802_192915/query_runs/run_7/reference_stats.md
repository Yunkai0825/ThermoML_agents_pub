# Reference Stats — query-agent

**Run started:** 2026-08-02 19:33:56
**Wall time (at last flush):** 124.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 22,485 | 45,681 | 10,259 | 68,166 | 11,361 | 58.0 | claudeopus46 |
| L1-worker | 10 | 70,319 | 65,284 | 13,418 | 135,603 | 13,560 | 80.5 | claudeopus46 |
| **TOTAL** | **16** | **92,804** | **110,965** | **23,677** | **203,769** | **12,735** | **138.5** | |

**Estimated tokens:** ~50,942 input + ~5,919 output = ~56,861 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 4 | 4 | 4 | 212 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **4** | **1** | **3** | **4** | **4** | **4** | **212** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_4415 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_8888 |  | search_blocks |
| GLOBlit_11504 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_8 | Speed of sound, m/s | search_blocks |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_7 | Speed of sound, m/s | search_blocks |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks |
| GLOBmeas_206 | Speed of sound, m/s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |
| GLOBsolvent_2 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_4 | Frequency, MHz | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_22 | Volume fraction | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 4 |
| Unique Properties | 1 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Solvents | 2 |
| Unique Variables | 3 |
| Unique Constraints | 4 |
| Total DOIs | 4 |
| Unique parent blocks | 4 |
| Explicit block/subsystem targets | 4 |
| Subsystem targets | 0 |
| Target-matched data points | 212 |

---

## 3. DOI & Block References

**Unique DOIs:** 4  |  **Parent blocks:** 4  |  **Explicit targets:** 4  |  **Subsystems:** 0  |  **Target-matched datapoints:** 212

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2015.06.024 | 1 | 40 | binary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 152 | binary | search_blocks |
| 10.1021/je0601098 | 1 | 12 | binary | search_blocks |
| 10.1021/je900064e | 1 | 8 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | — | search_blocks |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | — | search_blocks |
| 10.1021/je900064e | PROPblock_5 | declared | 8 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | purpose=Resolve ethanol and water to …, queries=['… | 250 | KEEP | 250 | 3.5 |
| 2 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_2'], limit=50, p… | 1,465 | KEEP | 1465 | 18.9 |
| 3 | 1 | `L1_query` | context=User is analyzing speed of so…, id_catalog… | 270 | — | — | 75.3 |
| | | **TOTAL (3 tools)** | | **1,985** | | **1,715** | **97.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,065 | 10,670 | 1,206 | 7.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,226 | 21,869 | 742 | 5.0 |
| 3 | L1-worker | claudeopus46 | 2,065 | 462 | 2,527 | 428 | 3.4 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,930 | 22,573 | 917 | 6.6 |
| 5 | L1-worker | claudeopus46 | 2,065 | 8,186 | 10,251 | 1,811 | 14.4 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,907 | 24,550 | 2,346 | 12.8 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,475 | 3,831 | 815 | 4.4 |
| 8 | L1-worker | claudeopus46 | 536 | 2,355 | 2,891 | 1,096 | 6.5 |
| 9 | L1-worker | claudeopus46 | 1,323 | 6,271 | 7,594 | 2,481 | 10.6 |
| 10 | L1-worker | claudeopus46 | 298 | 3,203 | 3,501 | 1,872 | 7.3 |
| 11 | L1-worker | claudeopus46 | 747 | 35,269 | 36,016 | 910 | 9.5 |
| 12 | L0-main | claudeopus46 | 9,605 | 32,657 | 42,262 | 3,560 | 22.8 |
| 13 | L0-main | claudeopus46 | 1,356 | 2,968 | 4,324 | 979 | 6.1 |
| 14 | L0-main | claudeopus46 | 298 | 1,361 | 1,659 | 967 | 3.6 |
| 15 | L0-main | claudeopus46 | 1,323 | 5,097 | 6,420 | 1,865 | 9.9 |
| 16 | L0-main | claudeopus46 | 298 | 2,533 | 2,831 | 1,682 | 8.3 |


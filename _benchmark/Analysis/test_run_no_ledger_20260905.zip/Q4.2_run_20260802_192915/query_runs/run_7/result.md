# Delegated query run — result

**Question:** Find all data blocks containing speed of sound measurements for binary mixtures of ethanol and water. Speed of sound property ID is GLOBprop_8. I need blocks that include data near 25°C (298.15 K). Return DOIs, block numbers, temperature ranges, and number of data points.

**Iterations:** 2  |  **Elapsed:** 106.0s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

Four data blocks in the ThermoML database contain speed of sound measurements for binary mixtures of ethanol (C₂H₆O) and water (H₂O) near 298.15 K (25 °C):

---

### Block 1 — PROPblock_8 (GLOBlit_4415)
- **DOI:** 10.1016/j.jct.2015.06.024
- **Temperature range:** 288.15–308.15 K (includes 298.15 K)
- **Data points:** 40
- **Composition:** Molality of ethanol, dilute range (0.02–0.22 mol/kg)
- **Pressure:** 84.5 kPa
- **Solvent:** Water
- **Speed of sound range:** 1467.43–1525.49 m/s
- **Method:** Sing-around technique in a fixed-path interferometer

### Block 2 — PROPblock_20 (GLOBlit_5201)
- **DOI:** 10.1016/j.jct.2018.02.022
- **Temperature range:** 293.15–308.15 K (includes 298.15 K)
- **Data points:** 152
- **Composition:** Mole fraction of ethanol, full range (x = 0.0–1.0, 38 unique compositions)
- **Pressure:** 92.3 kPa
- **Speed of sound range:** 1109.59–1625.74 m/s
- **Method:** Single path-length method
- **Note:** Most comprehensive dataset — covers nearly the entire mole-fraction range, ideal for analyzing deviation from ideal mixing.

### Block 3 — PROPblock_19 (GLOBlit_8888)
- **DOI:** 10.1021/je0601098
- **Temperature:** 298.15 K (isothermal)
- **Data points:** 12
- **Composition:** Molality of water in ethanol (0–1.02 mol/kg; solvent = ethanol)
- **Pressure:** 101 kPa
- **Speed of sound range:** 1142.1–1160.1 m/s
- **Method:** Linear variable-path acoustic interferometer

### Block 4 — PROPblock_5 (GLOBlit_11504)
- **DOI:** 10.1021/je900064e
- **Temperature range:** 288.15–323.15 K (includes 298.15 K)
- **Data points:** 8
- **Composition:** Fixed volume fraction of ethanol = 0.5 (temperature scan only)
- **Pressure:** 101 kPa
- **Speed of sound range:** 1452.9–1546.7 m/s

---

### Summary & Chemistry Insight

| Block | DOI | T range (K) | Points | Composition type |
|-------|-----|-------------|--------|------------------|
| PROPblock_8 | 10.1016/j.jct.2015.06.024 | 288.15–308.15 | 40 | Molality (dilute) |
| PROPblock_20 | 10.1016/j.jct.2018.02.022 | 293.15–308.15 | 152 | Mole fraction (full range) |
| PROPblock_19 | 10.1021/je0601098 | 298.15 | 12 | Molality (ethanol-rich) |
| PROPblock_5 | 10.1021/je900064e | 288.15–323.15 | 8 | Fixed φ_EtOH = 0.5 |

For analyzing speed of sound deviation from ideal mixing at 298.15 K, **PROPblock_20** is the most valuable source: it provides 152 data points spanning nearly the full ethanol mole-fraction range (x = 0 to 1). The ethanol–water system exhibits strong negative deviations in speed of sound from linear (ideal) mixing, with a pronounced minimum near x_ethanol ≈ 0.15–0.20. This behavior reflects the disruption and restructuring of hydrogen-bonding networks as ethanol molecules are introduced into the water structure, creating local density and compressibility anomalies that strongly affect sound propagation.

### Core claims

- Four ThermoML data blocks contain speed-of-sound measurements for binary ethanol–water mixtures near 298.15 K, spanning dilute aqueous (molality-based), full mole-fraction range, ethanol-rich (molality of water in ethanol), and fixed volume-fraction conditions, with a total of 212 data points across the four blocks.
- The most comprehensive dataset (PROPblock_20, DOI 10.1016/j.jct.2018.02.022) provides 152 data points covering nearly the entire ethanol mole-fraction range (x = 0 to 1) at 293.15–308.15 K and 92.3 kPa, making it the most suitable source for analyzing speed-of-sound deviation from ideal mixing at 298.15 K.
- The ethanol–water system exhibits strong negative deviations in speed of sound from linear (ideal) mixing, with a pronounced minimum near x_ethanol ≈ 0.15–0.20, attributed to disruption and restructuring of hydrogen-bonding networks that create local density and compressibility anomalies affecting sound propagation.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_4415 | 10.1016/j.jct.2015.06.024 | PROPblock_8 |  | Speed of sound for ethanol + water, dilute molality range, 288.15–308.15 K, 40 data points, 84.5 kPa, sing-around technique |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_20 |  | Speed of sound for ethanol + water, full mole fraction range (x=0–1), 293.15–308.15 K, 152 data points, 92.3 kPa, most comprehensive dataset for ideal mixing deviation analysis |
| GLOBlit_8888 | 10.1021/je0601098 | PROPblock_19 |  | Speed of sound for ethanol + water, molality of water in ethanol (ethanol-rich), isothermal at 298.15 K, 12 data points, 101 kPa |
| GLOBlit_11504 | 10.1021/je900064e | PROPblock_5 |  | Speed of sound for ethanol + water, fixed volume fraction ethanol = 0.5, temperature scan 288.15–323.15 K, 8 data points, 101 kPa |

### Suggested follow-ups

- Retrieve full composition-dependent speed of sound data from PROPblock_20 (GLOBlit_5201) at 298.15 K to compute excess speed of sound and compare with ideal mixing predictions.
- Query for excess molar volume or isentropic compressibility data for ethanol + water to complement the speed of sound analysis.
- Check whether any of these blocks also report density data that could be used to derive isentropic compressibility from speed of sound measurements.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_8",
    "registry_id": "speed_of_sound",
    "name": "Speed of sound (m/s)"
  }
]
```

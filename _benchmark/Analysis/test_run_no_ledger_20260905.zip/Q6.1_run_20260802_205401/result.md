# Analysis Run — 20260802_211238 (Round 1)

**Question:** I need a Redlich–Kister density correlation for liquid ethanol + water at 350 K. Can the available measurements support that temperature directly? If not, what is the nearest defensible temperature and why should the 350 K prediction be withheld?

**Time:** 1083.0s | **Iterations:** 21 | **Tools:** 65

---

## Answer

## Redlich–Kister Density Correlation for Liquid Ethanol + Water Near 350 K

### Can the Available Measurements Support 350 K Directly?

**No.** A thorough survey of the ThermoML database reveals that no block provides ethanol + water density data at exactly 350 K under atmospheric (or near-atmospheric) pressure:

| Source (lit_num_id / DOI) | Block | T range (K) | P range (kPa) | Rows | Verdict |
|---|---|---|---|---:|---|
| GLOBlit_220 / 10.1016/j.fluid.2004.11.019 | PROPblock_2 | 298.15–348.15 | 100–40 000 | 810 | **Nearest: 348.15 K at 100 kPa** |
| GLOBlit_1742 / 10.1016/j.fluid.2015.07.012 | PROPblock_3 | 350.7–476.2 | 10 000–40 000 | 84 | 350.7 K exists but only at 10–40 MPa (high pressure) |
| GLOBlit_2092 / 10.1016/j.fluid.2017.09.005 | PROPblock_3 | — | — | 72 | High-T, high-P data |
| GLOBlit_2732 / 10.1016/j.jct.2006.08.002 | PROPblock_2 | — | — | 19 | Limited coverage |

The closest atmospheric-pressure isotherm to 350 K is **348.15 K** from Pečar & Doleček (GLOBlit_220, DOI 10.1016/j.fluid.2004.11.019). The 350.7 K data in GLOBlit_1742 are measured at 10–40 MPa, making them unsuitable for an atmospheric-pressure correlation at 350 K without a pressure correction model — which would introduce model-dependent uncertainty.

### Why Should a 350 K Prediction Be Withheld?

1. **No direct atmospheric-pressure measurement exists at 350 K.** The nearest measured isotherm is 348.15 K (1.85 K gap). While small, extrapolating beyond the measured range without an explicit temperature model violates the data-priority principle.
2. **The 350.7 K data are at 10–40 MPa.** Liquid density is pressure-dependent; using high-pressure data as a proxy for atmospheric conditions would require an equation-of-state correction, introducing systematic bias.
3. **Ethanol–water is near its atmospheric boiling point at 350 K.** Pure ethanol boils at ~351.4 K; ethanol-rich mixtures may be at or near the bubble point at 350 K and 101.325 kPa, making liquid density measurements physically challenging and the liquid phase potentially metastable.

### Nearest Defensible Isotherm: 348.15 K at ~100 kPa

**Source:** GLOBlit_220 / DOI 10.1016/j.fluid.2004.11.019 (Pečar & Doleček, *Fluid Phase Equilib.*, 2005), PROPblock_2

**Fit details:**
- **Data points:** 47 mixture compositions (from 810 total rows in the block)
- **Composition basis:** mole fraction of ethanol
- **Mixing rule:** linear (for density)
- **BIC-selected RK order:** 5

**Pure-component endpoints (from block edges at 348.15 K, ~100 kPa):**

| Component | ρ_pure (kg/m³) |
|-----------|---------------|
| Water | 969.467 |
| Ethanol | 739.4 |

**Redlich–Kister coefficients (BIC-optimal, order 5):**

$$\rho^{\text{excess}}(x) = x_1 x_2 \sum_{k=0}^{5} A_k (x_1 - x_2)^k$$

where x₁ = mole fraction of ethanol, x₂ = mole fraction of water.

| k | Aₖ (kg/m³) |
|---|-----------|
| 0 | −167.860 |
| 1 | +50.452 |
| 2 | −18.395 |
| 3 | +43.193 |
| 4 | +76.872 |
| 5 | −109.654 |

**Fit quality:** R² = 0.9986, RMSE = 0.491 kg/m³

### Comparison with 298.15 K Isotherm (same source)

For reference, the 298.15 K isotherm from the same block yields a simpler correlation:

| k | Aₖ (kg/m³) |
|---|-----------|
| 0 | −120.557 |
| 1 | +18.568 |
| 2 | +43.919 |
| 3 | −31.351 |

**BIC-selected order:** 3 | R² = 0.9973 | RMSE = 0.475 kg/m³

The increase in RK order from 3 (at 298 K) to 5 (at 348 K) reflects the growing asymmetry and complexity of the density deviation curve as temperature rises toward the boiling region. The dominant A₀ coefficient becomes more negative (−120.6 → −167.9 kg/m³), consistent with enhanced volume contraction (negative excess volume) persisting but the overall density curve becoming more complex near the boiling point.

### Summary

A Redlich–Kister density correlation at exactly 350 K cannot be defensibly constructed from the available ThermoML measurements. The nearest reliable isotherm is **348.15 K at atmospheric pressure** (R² = 0.999, RMSE = 0.49 kg/m³, 47 data points, 5th-order RK). Any claim at 350 K would require either (a) temperature interpolation/extrapolation modeling or (b) use of high-pressure (10–40 MPa) data with a pressure correction — both of which introduce model assumptions beyond what the raw measurements support.

### Core claims

- No ThermoML measurements of ethanol + water liquid density exist at exactly 350 K and atmospheric pressure, so a defensible Redlich–Kister density correlation cannot be constructed at that temperature from the available data.
- The nearest reliable atmospheric-pressure isotherm is 348.15 K (from Pečar & Doleček, DOI 10.1016/j.fluid.2004.11.019), for which a BIC-selected 5th-order Redlich–Kister fit to 47 composition points yields R² = 0.9986 and RMSE = 0.49 kg/m³, with A₀ = −167.860 kg/m³ as the dominant coefficient.
- Data at 350.7 K exist but only at 10–40 MPa; using them as an atmospheric-pressure proxy would require a pressure-correction model and introduce systematic bias.
- At 350 K and 101.325 kPa, ethanol-rich mixtures are near or above the atmospheric boiling point of pure ethanol (~351.4 K), making liquid-phase density measurements physically problematic.
- Comparing the 348.15 K and 298.15 K isotherms from the same source, the BIC-optimal RK order increases from 3 to 5 and the dominant A₀ coefficient becomes more negative (−120.6 to −167.9 kg/m³), reflecting growing asymmetry and complexity of the excess density curve as temperature approaches the boiling region.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | Binary ethanol + water liquid mass density (kg/m³) from Pečar & Doleček (2005). 810 data points, T = 298.15–348.15 K, P = 100–40000 kPa, mole fraction ethanol 0.003–1.0. Nearest atmospheric-pressure isotherm to 350 K is 348.15 K at 100 kPa (47 mixture points). No data at exactly 350 K. |
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_3 |  | Binary ethanol + water liquid mass density (kg/m³). 84 data points, T = 350.7–476.2 K, P = 10000–40000 kPa, mole fraction ethanol 0.1–1.0. Contains 350.7 K data but only at 10–40 MPa (high pressure); unsuitable for atmospheric-pressure correlation at 350 K. |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_3 |  | Binary ethanol + water liquid mass density (kg/m³). 72 data points, T = 523.2–618.2 K, P = 20000–40000 kPa. High-T, high-P data far from 350 K; not relevant for this correlation. |
| GLOBlit_2732 | 10.1016/j.jct.2006.08.002 | PROPblock_2 |  | Binary ethanol + water liquid mass density (kg/m³). 19 data points, T = 456.86–546.15 K, single composition (x_ethanol = 0.5). Does not cover 350 K region. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_220 | PROPblock_2 | mass density | 5 | -167.86; 50.4515; -18.395; 43.1929; 76.8723; -109.654 | 0.998607 | 0.491146 | 47 | 348.15 | linear |  | 10.1016/j.fluid.2004.11.019 |
| GLOBlit_220 | PROPblock_2 | mass density | 3 | -120.557; 18.5676; 43.9191; -31.3506 | 0.997283 | 0.474765 | 47 | 298.15 | linear |  | 10.1016/j.fluid.2004.11.019 |

---

## Verdict

**Data Quality**
The agent conducted an extensive search, correctly identifying that no atmospheric-pressure data exist at 350 K. Multiple `fit_block` calls appear in the trace, confirming results were not fabricated. The fit at 348.15 K uses measured mixture density data from a reputable source. However, the agent fitted total density with a linear mixing rule + RK excess rather than using `fit_block_derived` for V^E directly — this is acceptable but introduces pure-component endpoint sensitivity. Composition basis appears to be mole fraction (consistent with source). No composition_conversion flag was needed.

**Fit Quality**
R² = 0.9986 with RMSE = 0.491 kg/m³ is excellent. RK order 5 selected by BIC is reasonable given the known asymmetry of ethanol–water near boiling. No overfitting concern given 47 data points.

**Scientific Verdict**
The agent's reasoning is scientifically sound: 350 K is near ethanol's boiling point, making atmospheric-pressure liquid density problematic. The 348.15 K correlation is well-justified and properly documented. Recommendation to withhold 350 K extrapolation is appropriate.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
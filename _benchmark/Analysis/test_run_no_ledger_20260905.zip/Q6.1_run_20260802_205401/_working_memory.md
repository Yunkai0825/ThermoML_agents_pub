# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Analysis\Q6.1_run_20260802_205401`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_2 | ethanol | 785.7 |
| comp | GLOBcomp_1 | water | 992.08333 |
| prop | GLOBprop_1 | mass density, kg/m3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_2 | molefraction<ethanol> |  |
| var | GLOBvar_4 | molalitymolkg<ethanol> |  |
| constr | GLOBconstr_3 | molefraction<ethanol> |  |
| lit | GLOBlit_220 | 10.1016/j.fluid.2004.11.019 |  |

### History
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [propose_fitting_plan]
- [propose_fitting_plan]
- [propose_fitting_plan]
- [propose_fitting_plan]
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [query_thermoml]
- [fit_block]
- [fit_block]

### Query Results
#### query
The ThermoML database contains 29 binary mixture data blocks across 22 DOIs reporting liquid-phase mass density for the ethanol (CAS 64-17-5) + water (CAS 7732-18-5) system. Near 350 K, the best-matching blocks include GLOBlit_1742 (DOI 10.1016/j.fluid.2015.07.012, PROPblock_3, 350.7–373.2 K at 10–40 MPa), and atmospheric-pressure blocks from DOIs 10.1016/j.fluid.2006.01.018 and 10.1016/j.fluid.2013.07.046 reaching 353.15 K. Many additional blocks cover ambient temperatures (293–313 K at 101.325 kPa), including 10 blocks from 10.1016/j.jct.2012.11.014, while high-temperature data (up to ~618 K at high pressures) are available from 10.1016/j.fluid.2017.09.005 and 10.1016/j.jct.2006.08.002. Key ThermoML identifiers are GLOBcomp_2 (ethanol), GLOBcomp_1 (water), GLOBprop_1 (mass density), and GLOBphase_1 (liquid). The ethanol–water system exhibits pronounced negative excess molar volumes due to strong hydrogen-bonding interactions, with non-ideality persisting but diminishing at elevated temperatures.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | binary |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | binary |
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_3 | declared | 84 | binary | binary |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_3 | declared | 72 | binary | binary |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | binary |
| GLOBlit_2732 | 10.1016/j.jct.2006.08.002 | PROPblock_2 | declared | 19 | binary | binary |
| GLOBlit_2732 | 10.1016/j.jct.2006.08.002 | PROPblock_3 | declared | 4 | binary | binary |

#### query
A search for binary ethanol + water mass density data near 350 K at atmospheric pressure in the ThermoML database found one matching block: PROPblock_2 from GLOBlit_220 (DOI 10.1016/j.fluid.2004.11.019, Pecar & Dolecek 2005). This block contains 810 data points of liquid-phase mass density (kg/m³) as a function of temperature, pressure, and ethanol mole fraction, spanning a wide range of conditions that likely includes ~353.15 K and ~101.325 kPa. The two DOIs specifically requested (10.1016/j.fluid.2006.01.018 and 10.1016/j.fluid.2013.07.046) were not found in the ThermoML database despite multiple resolution attempts, so their reported ethanol+water density data could not be verified or retrieved.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | binary |

**Status:** partial

### Inspected Blocks
- GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_3: 84 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_3: 72 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2732 | 10.1016/j.jct.2006.08.002 | PROPblock_2: 19 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2: 810 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2: 565 rows; x=['molality_mol_kg_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Difference with the reference state, X-X(REF); reference=Pure solvent at the same temperature and pressure; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=reference_difference; materialize_reference=True; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_3: 84 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2: 810 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_3: 72 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_2732 | 10.1016/j.jct.2006.08.002 | PROPblock_2: 19 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.fluid.2004.11.019/PROPblock_2 (ethanol, water): RK order=5, R²=0.998607, RMSE=0.4911460748640253, coeffs=[-167.860024, 50.451482, -18.395033, 43.192936, 76.872347, -109.653896]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: ethanol=739.4, water=969.467 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_excess.png
  - 10.1016/j.fluid.2004.11.019/PROPblock_2 (ethanol, water): RK order=3, R²=0.997283, RMSE=0.47476545853553287, coeffs=[-120.55681, 18.567625, 43.919128, -31.350563]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: ethanol=785.7, water=992.083 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1

### plot
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T348.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T348.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1


# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:54:01
**Wall time (at last flush):** 1,117.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 28 | 465,254 | 479,060 | 62,117 | 944,314 | 33,725 | 365.5 | claudeopus46 |
| L1-worker | 45 | 404,213 | 296,895 | 149,941 | 701,108 | 15,580 | 773.2 | claudeopus46 |
| **TOTAL** | **73** | **869,467** | **775,955** | **212,058** | **1,645,422** | **22,540** | **1138.7** | |

**Estimated tokens:** ~411,355 input + ~53,014 output = ~464,369 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 3 | 0 | 1 | 1 | 810 |
| **TOTAL** | **2** | **1** | **3** | **0** | **1** | **1** | **810** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_220 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 | ethanol | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_3 | Pressure, kPa | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_138 | Mass density, kg/m3 | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Variables | 3 |
| Unique Phases | 1 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 810 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 810

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | id_catalog=[{'id': 'GLOBprop_1', 'type':…, instruc… | 164 | — | — | 0.0 |
| 2 | 2 | `query_thermoml` | instruction=Search for density (mass dens…, purpos… | 360 | — | — | 197.0 |
| 3 | 3 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 282 | — | — | 253.1 |
| 4 | 7 | `inspect_block` | block_number=PROPblock_3, doi=10.1016/j.fluid.2015… | 1,372 | — | — | 0.1 |
| 5 | 7 | `inspect_block` | block_number=PROPblock_3, doi=10.1016/j.fluid.2017… | 1,368 | — | — | 0.1 |
| 6 | 7 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2006.0… | 1,368 | — | — | 0.1 |
| 7 | 7 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.1 |
| 8 | 7 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2004.0… | 1,554 | — | — | 0.1 |
| 9 | 10 | `propose_fitting_plan` | block_number=PROPblock_3, doi=10.1016/j.fluid.2015… | 597 | — | — | 0.1 |
| 10 | 10 | `propose_fitting_plan` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 597 | — | — | 0.1 |
| 11 | 10 | `propose_fitting_plan` | block_number=PROPblock_3, doi=10.1016/j.fluid.2017… | 597 | — | — | 0.1 |
| 12 | 10 | `propose_fitting_plan` | block_number=PROPblock_2, doi=10.1016/j.jct.2006.0… | 597 | — | — | 0.1 |
| 13 | 14 | `fit_block` | block_number=PROPblock_3, doi=10.1016/j.fluid.2015… | 143 | — | — | 0.1 |
| 14 | 14 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 142 | — | — | 0.1 |
| 15 | 14 | `fit_block` | block_number=PROPblock_3, doi=10.1016/j.fluid.2017… | 143 | — | — | 0.0 |
| 16 | 14 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2006.0… | 141 | — | — | 0.0 |
| 17 | 16 | `inspect_block` | block_number=PROPblock_3, doi=10.1016/j.fluid.2015… | 1,372 | — | — | 0.1 |
| 18 | 16 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.1 |
| 19 | 18 | `inspect_block` | block_number=PROPblock_3, doi=10.1016/j.fluid.2017… | 1,368 | — | — | 0.2 |
| 20 | 18 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.jct.2006.0… | 1,368 | — | — | 0.2 |
| 21 | 18 | `query_thermoml` | instruction=Search for binary mixture den…, purpos… | 10,320 | — | — | 305.8 |
| 22 | 20 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 866 | — | — | 0.9 |
| 23 | 20 | `fit_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 852 | — | — | 0.9 |
| | | **TOTAL (23 tools)** | | **28,319** | | **0** | **759.4** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,300 | 2,300 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 22,912 | 22,912 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 435 | 20,456 | 1,282 | 8.9 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,080 | 21,101 | 754 | 6.0 |
| 3 | L1-worker | claudeopus46 | 20,643 | 513 | 21,156 | 764 | 6.2 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,898 | 22,541 | 13,649 | 52.1 |
| 5 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 4.0 |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,054 | 22,697 | 14,798 | 57.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 17,580 | 38,223 | 3,973 | 21.6 |
| 8 | L1-worker | claudeopus46 | 536 | 3,593 | 4,129 | 963 | 5.6 |
| 9 | L1-worker | claudeopus46 | 1,356 | 3,713 | 5,069 | 1,094 | 6.2 |
| 10 | L1-worker | claudeopus46 | 298 | 1,476 | 1,774 | 1,082 | 3.8 |
| 11 | L1-worker | claudeopus46 | 1,323 | 5,914 | 7,237 | 5,399 | 20.2 |
| 12 | L1-worker | claudeopus46 | 298 | 6,121 | 6,419 | 4,431 | 16.8 |
| 13 | L1-worker | claudeopus46 | 1,160 | 12,666 | 13,826 | 4,400 | 17.9 |
| 14 | L0-main | claudeopus46 | 20,021 | 1,851 | 21,872 | 15,450 | 80.1 |
| 15 | L1-worker | claudeopus46 | 20,643 | 484 | 21,127 | 749 | 5.7 |
| 16 | L1-worker | claudeopus46 | 20,643 | 1,854 | 22,497 | 12,865 | 52.3 |
| 17 | L1-worker | claudeopus46 | 2,065 | 510 | 2,575 | 658 | 5.1 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,132 | 22,775 | 9,454 | 49.3 |
| 19 | L1-worker | claudeopus46 | 20,643 | 12,314 | 32,957 | 9,034 | 42.0 |
| 20 | L1-worker | claudeopus46 | 2,065 | 5,801 | 7,866 | 1,923 | 16.3 |
| 21 | L1-worker | claudeopus46 | 2,065 | 18,917 | 20,982 | 1,624 | 13.6 |
| 22 | L1-worker | claudeopus46 | 20,643 | 14,358 | 35,001 | 3,286 | 22.7 |
| 23 | L1-worker | claudeopus46 | 1,356 | 3,417 | 4,773 | 951 | 6.5 |
| 24 | L1-worker | claudeopus46 | 536 | 3,297 | 3,833 | 1,026 | 7.5 |
| 25 | L1-worker | claudeopus46 | 298 | 1,333 | 1,631 | 939 | 4.8 |
| 26 | L1-worker | claudeopus46 | 1,323 | 8,635 | 9,958 | 3,087 | 14.9 |
| 27 | L1-worker | claudeopus46 | 298 | 3,809 | 4,107 | 2,311 | 10.9 |
| 28 | L1-worker | claudeopus46 | 747 | 53,329 | 54,076 | 1,101 | 10.7 |
| 29 | L0-main | claudeopus46 | 19,988 | 5,361 | 25,349 | 438 | 6.9 |
| 30 | L0-main | claudeopus46 | 20,021 | 4,604 | 24,625 | 2,234 | 13.9 |
| 31 | L0-main | claudeopus46 | 20,021 | 6,513 | 26,534 | 1,458 | 6.7 |
| 32 | L0-main | claudeopus46 | 20,021 | 8,302 | 28,323 | 1,558 | 7.1 |
| 33 | L0-main | claudeopus46 | 20,021 | 10,270 | 30,291 | 1,537 | 6.4 |
| 34 | L0-main | claudeopus46 | 20,021 | 12,249 | 32,270 | 1,245 | 6.8 |
| 35 | L0-main | claudeopus46 | 20,021 | 13,647 | 33,668 | 3,258 | 17.4 |
| 36 | L0-main | claudeopus46 | 20,021 | 15,680 | 35,701 | 1,475 | 7.2 |
| 37 | L0-main | claudeopus46 | 20,021 | 17,408 | 37,429 | 2,658 | 17.3 |
| 38 | L0-main | claudeopus46 | 20,021 | 19,048 | 39,069 | 1,782 | 9.3 |
| 39 | L0-main | claudeopus46 | 20,021 | 20,585 | 40,606 | 2,133 | 11.3 |
| 40 | L0-main | claudeopus46 | 20,021 | 22,372 | 42,393 | 1,884 | 9.9 |
| 41 | L0-main | claudeopus46 | 20,021 | 21,700 | 41,721 | 997 | 6.5 |
| 42 | L0-main | claudeopus46 | 20,021 | 22,652 | 42,673 | 985 | 5.9 |
| 43 | L0-main | claudeopus46 | 20,021 | 26,303 | 46,324 | 3,186 | 21.1 |
| 44 | L0-main | claudeopus46 | 20,021 | 27,612 | 47,633 | 1,597 | 10.6 |
| 45 | L1-worker | claudeopus46 | 20,643 | 703 | 21,346 | 1,322 | 8.7 |
| 46 | L1-worker | claudeopus46 | 20,643 | 2,860 | 23,503 | 12,751 | 59.0 |
| 47 | L1-worker | claudeopus46 | 2,065 | 435 | 2,500 | 439 | 3.8 |
| 48 | L1-worker | claudeopus46 | 2,065 | 561 | 2,626 | 475 | 4.9 |
| 49 | L1-worker | claudeopus46 | 2,065 | 239 | 2,304 | 604 | 7.3 |
| 50 | L1-worker | claudeopus46 | 20,643 | 3,910 | 24,553 | 6,301 | 32.7 |
| 51 | L1-worker | claudeopus46 | 2,065 | 3,029 | 5,094 | 2,090 | 17.2 |
| 52 | L1-worker | claudeopus46 | 2,065 | 289 | 2,354 | 822 | 6.3 |
| 53 | L1-worker | claudeopus46 | 20,610 | 7,181 | 27,791 | 424 | 4.1 |
| 54 | L1-worker | claudeopus46 | 20,643 | 6,409 | 27,052 | 7,377 | 47.0 |
| 55 | L1-worker | claudeopus46 | 20,643 | 7,371 | 28,014 | 1,882 | 12.1 |
| 56 | L1-worker | claudeopus46 | 20,643 | 9,874 | 30,517 | 1,142 | 5.0 |
| 57 | L1-worker | claudeopus46 | 20,643 | 10,660 | 31,303 | 5,422 | 32.4 |
| 58 | L1-worker | claudeopus46 | 20,643 | 11,644 | 32,287 | 2,637 | 16.8 |
| 59 | L1-worker | claudeopus46 | 1,356 | 2,124 | 3,480 | 500 | 3.3 |
| 60 | L1-worker | claudeopus46 | 536 | 2,004 | 2,540 | 721 | 5.0 |
| 61 | L1-worker | claudeopus46 | 1,323 | 13,823 | 15,146 | 1,177 | 7.8 |
| 62 | L1-worker | claudeopus46 | 298 | 1,899 | 2,197 | 943 | 4.3 |
| 63 | L1-worker | claudeopus46 | 747 | 22,850 | 23,597 | 2,516 | 18.6 |
| 64 | L1-worker | claudeopus46 | 298 | 2,875 | 3,173 | 423 | 2.5 |
| 65 | L0-main | claudeopus46 | 19,988 | 31,436 | 51,424 | 478 | 5.3 |
| 66 | L0-main | claudeopus46 | 20,021 | 30,936 | 50,957 | 1,918 | 13.5 |
| 67 | L0-main | claudeopus46 | 20,021 | 31,946 | 51,967 | 1,498 | 8.9 |
| 68 | L0-main | claudeopus46 | 20,021 | 36,511 | 56,532 | 4,278 | 32.2 |
| 69 | L0-main | claudeopus46 | 1,356 | 4,407 | 5,763 | 1,224 | 8.2 |
| 70 | L0-main | claudeopus46 | 298 | 1,606 | 1,904 | 1,212 | 4.3 |
| 71 | L0-main | claudeopus46 | 1,323 | 70,854 | 72,177 | 2,460 | 15.4 |
| 72 | L0-main | claudeopus46 | 298 | 3,302 | 3,600 | 2,013 | 9.3 |
| 73 | L0-main | claudeopus46 | 1,562 | 10,390 | 11,952 | 1,125 | 9.1 |


# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:20:32
**Wall time (at last flush):** 632.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 21 | 325,074 | 192,174 | 24,961 | 517,248 | 24,630 | 176.4 | claudeopus46 |
| L1-worker | 37 | 294,311 | 185,434 | 94,590 | 479,745 | 12,966 | 485.7 | claudeopus46 |
| **TOTAL** | **58** | **619,385** | **377,608** | **119,551** | **996,993** | **17,189** | **662.1** | |

**Estimated tokens:** ~249,248 input + ~29,887 output = ~279,135 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | context=Looking for liquid density da…, instructio… | 387 | — | — | 201.0 |
| 2 | 2 | `query_thermoml` | instruction=Search for binary mixture dat…, purpos… | 388 | — | — | 135.4 |
| 3 | 3 | `query_thermoml` | id_catalog=[{'id': 'GLOBprop_1', 'label'…, instruc… | 164 | — | — | 0.0 |
| 4 | 4 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_1', …, instruc… | 233 | — | — | 0.0 |
| 5 | 5 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_1', …, instruc… | 282 | — | — | 125.0 |
| 6 | 9 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.1 |
| 7 | 9 | `inspect_block` | block_number=PROPblock_3, doi=10.1021/je049691v, p… | 1,330 | — | — | 0.1 |
| 8 | 10 | `get_pure_values` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 724 | — | — | 0.1 |
| 9 | 10 | `propose_fitting_plan` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 704 | — | — | 0.0 |
| 10 | 11 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 1,128 | — | — | 1.6 |
| 11 | 12 | `list_session_files` |  | 3,077 | — | — | 0.0 |
| | | **TOTAL (11 tools)** | | **9,777** | | **0** | **463.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,985 | 2,985 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 9,218 | 9,218 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 16,652 | 16,652 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 937 | 20,958 | 970 | 6.6 |
| 2 | L1-worker | claudeopus46 | 20,643 | 644 | 21,287 | 673 | 5.4 |
| 3 | L1-worker | claudeopus46 | 20,643 | 1,938 | 22,581 | 833 | 4.9 |
| 4 | L1-worker | claudeopus46 | 2,065 | 471 | 2,536 | 442 | 6.1 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,092 | 22,735 | 13,326 | 53.1 |
| 6 | L1-worker | claudeopus46 | 2,065 | 7,077 | 9,142 | 1,538 | 12.7 |
| 7 | L1-worker | claudeopus46 | 2,065 | 7,287 | 9,352 | 1,700 | 16.0 |
| 8 | L1-worker | claudeopus46 | 20,610 | 3,498 | 24,108 | 609 | 4.9 |
| 9 | L1-worker | claudeopus46 | 20,643 | 2,726 | 23,369 | 5,617 | 33.7 |
| 10 | L1-worker | claudeopus46 | 20,643 | 8,964 | 29,607 | 3,808 | 19.7 |
| 11 | L1-worker | claudeopus46 | 1,356 | 2,595 | 3,951 | 894 | 5.2 |
| 12 | L1-worker | claudeopus46 | 536 | 2,475 | 3,011 | 788 | 7.3 |
| 13 | L1-worker | claudeopus46 | 298 | 1,276 | 1,574 | 882 | 3.3 |
| 14 | L1-worker | claudeopus46 | 298 | 1,144 | 1,442 | 775 | 3.5 |
| 15 | L1-worker | claudeopus46 | 1,323 | 5,471 | 6,794 | 3,645 | 14.2 |
| 16 | L1-worker | claudeopus46 | 298 | 4,367 | 4,665 | 2,671 | 10.6 |
| 17 | L1-worker | claudeopus46 | 1,160 | 9,763 | 10,923 | 2,658 | 11.2 |
| 18 | L0-main | claudeopus46 | 20,021 | 1,760 | 21,781 | 892 | 6.7 |
| 19 | L1-worker | claudeopus46 | 20,643 | 576 | 21,219 | 656 | 5.0 |
| 20 | L1-worker | claudeopus46 | 20,643 | 1,853 | 22,496 | 6,235 | 31.5 |
| 21 | L1-worker | claudeopus46 | 2,065 | 471 | 2,536 | 442 | 3.6 |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,023 | 22,666 | 7,956 | 43.5 |
| 23 | L1-worker | claudeopus46 | 20,643 | 10,600 | 31,243 | 2,825 | 14.5 |
| 24 | L1-worker | claudeopus46 | 1,356 | 2,477 | 3,833 | 757 | 5.2 |
| 25 | L1-worker | claudeopus46 | 536 | 2,357 | 2,893 | 792 | 6.0 |
| 26 | L1-worker | claudeopus46 | 298 | 1,139 | 1,437 | 745 | 3.5 |
| 27 | L1-worker | claudeopus46 | 1,323 | 4,569 | 5,892 | 3,590 | 14.9 |
| 28 | L1-worker | claudeopus46 | 298 | 4,312 | 4,610 | 2,689 | 10.7 |
| 29 | L1-worker | claudeopus46 | 1,160 | 8,777 | 9,937 | 2,611 | 11.2 |
| 30 | L0-main | claudeopus46 | 20,021 | 2,604 | 22,625 | 1,169 | 8.6 |
| 31 | L0-main | claudeopus46 | 19,988 | 4,022 | 24,010 | 566 | 4.1 |
| 32 | L0-main | claudeopus46 | 20,021 | 3,265 | 23,286 | 1,262 | 8.1 |
| 33 | L0-main | claudeopus46 | 20,021 | 3,983 | 24,004 | 986 | 6.3 |
| 34 | L1-worker | claudeopus46 | 20,643 | 668 | 21,311 | 822 | 6.1 |
| 35 | L1-worker | claudeopus46 | 20,643 | 2,111 | 22,754 | 8,501 | 35.0 |
| 36 | L1-worker | claudeopus46 | 2,065 | 6,357 | 8,422 | 1,620 | 13.6 |
| 37 | L1-worker | claudeopus46 | 20,643 | 3,478 | 24,121 | 2,638 | 15.8 |
| 38 | L1-worker | claudeopus46 | 536 | 2,099 | 2,635 | 758 | 4.6 |
| 39 | L1-worker | claudeopus46 | 1,356 | 2,219 | 3,575 | 986 | 5.3 |
| 40 | L1-worker | claudeopus46 | 1,323 | 5,538 | 6,861 | 3,329 | 14.0 |
| 41 | L1-worker | claudeopus46 | 298 | 4,051 | 4,349 | 2,509 | 10.5 |
| 42 | L1-worker | claudeopus46 | 1,160 | 9,288 | 10,448 | 2,230 | 10.1 |
| 43 | L1-worker | claudeopus46 | 747 | 48,683 | 49,430 | 1,040 | 9.3 |
| 44 | L0-main | claudeopus46 | 20,021 | 6,319 | 26,340 | 995 | 8.4 |
| 45 | L0-main | claudeopus46 | 20,021 | 7,333 | 27,354 | 748 | 4.6 |
| 46 | L0-main | claudeopus46 | 20,021 | 8,241 | 28,262 | 866 | 5.1 |
| 47 | L0-main | claudeopus46 | 20,021 | 9,368 | 29,389 | 817 | 4.4 |
| 48 | L0-main | claudeopus46 | 19,988 | 13,041 | 33,029 | 350 | 4.5 |
| 49 | L0-main | claudeopus46 | 20,021 | 12,284 | 32,305 | 2,078 | 14.8 |
| 50 | L0-main | claudeopus46 | 20,021 | 14,795 | 34,816 | 1,743 | 11.8 |
| 51 | L0-main | claudeopus46 | 20,021 | 18,944 | 38,965 | 856 | 8.4 |
| 52 | L0-main | claudeopus46 | 19,988 | 23,260 | 43,248 | 446 | 5.4 |
| 53 | L0-main | claudeopus46 | 20,021 | 22,500 | 42,521 | 3,232 | 27.0 |
| 54 | L0-main | claudeopus46 | 1,356 | 3,361 | 4,717 | 1,170 | 6.8 |
| 55 | L0-main | claudeopus46 | 298 | 1,552 | 1,850 | 1,158 | 4.0 |
| 56 | L0-main | claudeopus46 | 1,323 | 25,649 | 26,972 | 2,005 | 12.8 |
| 57 | L0-main | claudeopus46 | 298 | 2,847 | 3,145 | 1,544 | 7.3 |
| 58 | L0-main | claudeopus46 | 1,562 | 6,109 | 7,671 | 1,108 | 10.7 |


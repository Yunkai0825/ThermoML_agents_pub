# Analysis Run — 20260802_193105 (Round 1)

**Question:** [Purpose: Find methanol + water density data at 25°C in ThermoML, fit Redlich-Kister polynomials, select best order by BIC, and report full results.]
At 25 °C, what Redlich-Kister correlation best represents the density of liquid methanol + water? Select the polynomial order by BIC and report the fitted equation, coefficients with units, R², RMSE, BIC, and composition range.

[Context: The user wants excess molar volume or density data for the methanol + water binary system at 25°C (298.15 K). Search for density data, fit Redlich-Kister polynomials of multiple orders, use BIC to select the best order, and report all fitting statistics including coefficients with units, R², RMSE, BIC, and the composition range of the data.]

**Time:** 601.8s | **Iterations:** 13 | **Tools:** 17

---

## Answer

## Redlich-Kister Correlation for the Density of Liquid Methanol + Water at 25 °C

### System & Conditions

- **Binary system:** methanol (CH₃OH) + water (H₂O)
- **Temperature:** 298.15 K (25 °C)
- **Pressure:** 101 kPa (ambient)
- **Property:** Mass density, ρ (kg m⁻³)
- **Composition variable:** Mole fraction of water, x₁ (x₁ = 0 → pure methanol; x₁ = 1 → pure water)

### Fitted Equation

The density is represented as a linear baseline plus a Redlich-Kister (RK) excess term:

$$\rho(x_1) = x_1\,\rho_1^* + (1-x_1)\,\rho_2^* + x_1(1-x_1)\sum_{k=0}^{n} A_k\,(2x_1-1)^k$$

where x₁ is the mole fraction of water, ρ₁* = 997.05 kg m⁻³ (pure water) and ρ₂* = 787.2 kg m⁻³ (pure methanol).

### Data Sources & Results

Two independent ThermoML datasets were fitted. BIC selected **order 5** (six coefficients) for both.

---

#### Dataset 1 — Gonzalez et al. (GLOBlit_2825 / DOI 10.1016/j.jct.2007.05.004, PROPblock_10)

- **Composition range:** x₁(water) = 0 to 1 (full range, including pure endpoints)
- **Data points at 298.15 K:** 11 (after temperature constraint)

| k | Aₖ (kg m⁻³) |
|:-:|:------------:|
| 0 | −42.3108 |
| 1 | 2.4613 |
| 2 | 7.2809 |
| 3 | −0.4197 |
| 4 | −46.1538 |
| 5 | −43.8431 |

| Statistic | Value |
|-----------|-------|
| R² | 0.999796 |
| RMSE | 0.0389 kg m⁻³ |
| BIC-selected order | 5 |

---

#### Dataset 2 — Arce et al. (GLOBlit_8424 / DOI 10.1021/je049691v, PROPblock_3)

- **Composition range:** x₁(water) = 0.08 to 0.96
- **Data points at 298.15 K:** 12 (after temperature constraint)
- **Pure-component endpoints:** supplied externally (water = 997.05, methanol = 787.2 kg m⁻³)

| k | Aₖ (kg m⁻³) |
|:-:|:------------:|
| 0 | −43.7370 |
| 1 | 3.9888 |
| 2 | 6.3227 |
| 3 | 1.0313 |
| 4 | −50.8077 |
| 5 | −38.6904 |

| Statistic | Value |
|-----------|-------|
| R² | 0.999708 |
| RMSE | 0.0410 kg m⁻³ |
| BIC-selected order | 5 |

---

### Chemistry Insight

Both fits show a **negative excess density** (the RK excess term is predominantly negative across the composition range), consistent with the well-known **negative excess molar volume** of methanol + water. This arises because the strong O–H···O hydrogen bonds between methanol and water molecules produce a more compact packing than the ideal (linear) mixture. The minimum excess density occurs near x₁(water) ≈ 0.3–0.4, corresponding to the composition region where the hydrogen-bond network restructuring is most pronounced.

Representative data point (Dataset 1): at x₁(water) = 0.5, the measured density is approximately 890 kg m⁻³, which is lower than the linear-baseline value of ≈ 892.1 kg m⁻³ — a deviation of about −2 kg m⁻³ captured by the RK polynomial.

### Recommended Correlation

Both datasets yield mutually consistent coefficients (leading A₀ ≈ −43 kg m⁻³) with excellent fits (R² > 0.9997, RMSE < 0.05 kg m⁻³). **Dataset 1** (DOI 10.1016/j.jct.2007.05.004) is recommended as the primary correlation because it covers the full mole-fraction range (0 to 1) with self-consistent pure-component endpoints.

### Output Files

- Fit data CSVs and excess-property CSVs for both datasets
- Fit plots and excess-property plots for both datasets

All files are stored in the session output directory.

### Core claims

- A Redlich-Kister correlation of order 5 (six coefficients) accurately represents the mass density of liquid methanol + water at 298.15 K and 101 kPa as a function of water mole fraction, with R² > 0.9997 and RMSE < 0.05 kg m⁻³ for two independent ThermoML datasets.
- The leading Redlich-Kister coefficient A₀ is approximately −43 kg m⁻³ in both datasets, indicating a predominantly negative excess density across the composition range, consistent with the known negative excess molar volume of methanol + water arising from enhanced hydrogen-bond-driven packing.
- The minimum excess density occurs near x₁(water) ≈ 0.3–0.4, corresponding to the composition region of most pronounced hydrogen-bond network restructuring.
- The two independent datasets (Gonzalez et al., DOI 10.1016/j.jct.2007.05.004, and Arce et al., DOI 10.1021/je049691v) yield mutually consistent Redlich-Kister coefficients; the Gonzalez et al. dataset is recommended as the primary correlation because it covers the full mole-fraction range (0 to 1) with self-consistent pure-component endpoints.
- BIC model selection independently chose order 5 for both datasets.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | Binary methanol + water mass density data at 298.15 K and 101 kPa. Full mole-fraction range (x_water = 0 to 1), 39 total rows (11 at 298.15 K). Property: BLKprop_1 / GLOBprop_1, direct value, kg/m3. Compounds: GLOBcomp_4 (methanol), GLOBcomp_1 (water). Pure values: water = 997.05 kg/m3, methanol = 787.2 kg/m3. |
| GLOBlit_8424 | 10.1021/je049691v | PROPblock_3 |  | Binary methanol + water mass density data at 298.15 K. Mole-fraction range x_water = 0.08 to 0.9603, 180 total rows (12 at 298.15 K). Property: BLKprop_1 / GLOBprop_1, direct value, kg/m3. Compounds: GLOBcomp_4 (methanol), GLOBcomp_1 (water). Pure endpoint values supplied externally: water = 997.05 kg/m3, methanol = 787.2 kg/m3. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2825 | PROPblock_10 | mass_density_kg_m3 | 5 | -42.3108; 2.46129; 7.28093; -0.41971; -46.1538; -43.8431 | 0.999796 | 0.0388524 | 11 | 298.15 | linear |  | 10.1016/j.jct.2007.05.004 |
| GLOBlit_8424 | PROPblock_3 | mass_density_kg_m3 | 5 | -43.737; 3.98883; 6.32271; 1.03127; -50.8077; -38.6904 | 0.999708 | 0.0409798 | 12 | 298.15 | linear |  | 10.1021/je049691v |

---

## Verdict

**Data Quality**
Two ThermoML datasets were used with `fit_multi_system` confirmed in the trace — no fabrication. However, density (a total property) was fitted directly with a RK baseline+excess form rather than converting to excess molar volume first. Pure-component values were obtained via `get_pure_values`. The composition basis appears to be mole fraction throughout, which is correct. No composition_conversion flags were needed. Data point counts (11–12) are modest but adequate for the property.

**Fit Quality**
Order 5 (6 coefficients) selected by BIC with only 11–12 data points raises overfitting concerns — nearly one parameter per two points. R² > 0.9997 and RMSE ~0.04 kg m⁻³ look excellent but may reflect overfitting. A lower-order fit should have been compared more critically.

**Scientific Verdict**
Results are physically reasonable: negative excess density consistent with known V^E behavior. The two independent datasets show consistent A₀ ≈ −43 kg m⁻³, lending credibility. However, order 5 with ~11 points likely overfits; users should verify with order 3–4. **PASS with caution.**

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\data\10_1021_je049691v_BPROPblock_3_T298.1_fit.csv` — RK fit data — 10.1021/je049691v PROPblock_3_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\data\10_1021_je049691v_BPROPblock_3_T298.1_excess.csv` — Excess property — 10.1021/je049691v PROPblock_3_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\plots\10_1021_je049691v_BPROPblock_3_T298.1_fit.png` — RK fit plot — 10.1021/je049691v PROPblock_3_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3\plots\10_1021_je049691v_BPROPblock_3_T298.1_excess.png` — Excess plot — 10.1021/je049691v PROPblock_3_T298.1
# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.2_run_20260802_192015\analysis_runs\run_3`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_4 | methanol | 787.2 |
| comp | GLOBcomp_1 | water | 997.05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [get_pure_values]
- [propose_fitting_plan]
- [fit_multi_system]
- [list_session_files]

### Query Results
#### query
Nine ThermoML data blocks were identified containing mass density measurements for binary methanol + water mixtures near 298.15 K. The most composition-rich datasets are from DOI 10.1016/j.jct.2007.05.004 (full mole-fraction range of water, 0–1) and DOI 10.1021/je049691v (mole fraction of water 0.08–0.96). Other datasets cover narrower composition or pressure ranges, including high-pressure data (DOI 10.1016/j.jct.2004.07.019) and primarily high-temperature data with limited 298.15 K relevance (DOI 10.1021/je034101z). Density spans from approximately 0.787 g/cm³ (pure methanol) to 0.997 g/cm³ (pure water) at 298.15 K, with well-known negative excess volumes attributed to strong hydrogen-bonding interactions between methanol and water.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_1 | declared | 596 | binary | binary |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | binary |
| GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_6 | declared | 12 | binary | binary |
| GLOBlit_8254 | 10.1021/je034101z | PROPblock_4 | declared | 401 | binary | binary |
| GLOBlit_8424 | 10.1021/je049691v | PROPblock_3 | declared | 180 | binary | binary |
| GLOBlit_8869 | 10.1021/je0600810 | PROPblock_4 | declared | 9 | binary | binary |
| GLOBlit_8888 | 10.1021/je0601098 | PROPblock_18 | declared | 12 | binary | binary |

### Inspected Blocks
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10: 39 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_8424 | 10.1021/je049691v | PROPblock_3: 180 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - methanol_water_jct2007 [10.1016/j.jct.2007.05.004/PROPblock_10] (water, methanol): RK order=5, R²=0.999796, RMSE=0.03885240667464569, coeffs=[-42.310758, 2.461285, 7.280933, -0.41971, -46.15381, -43.843096]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: water=997.05, methanol=787.2 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png
  - methanol_water_je2004 [10.1021/je049691v/PROPblock_3] (water, methanol): RK order=5, R²=0.999708, RMSE=0.04097978297069243, coeffs=[-43.736957, 3.988833, 6.32271, 1.031267, -50.807722, -38.69044]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: water=997.05, methanol=787.2 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1021_je049691v_BPROPblock_3_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je049691v_BPROPblock_3_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je049691v_BPROPblock_3_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je049691v_BPROPblock_3_T298.1_excess.png

### Property Response Preparation
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10: direct via X = reported X (0 reference source(s))

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/data\10_1021_je049691v_BPROPblock_3_T298.1_fit.csv` — RK fit data — 10.1021/je049691v PROPblock_3_T298.1
- `$ROOT/data\10_1021_je049691v_BPROPblock_3_T298.1_excess.csv` — Excess property — 10.1021/je049691v PROPblock_3_T298.1
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/plots\10_1021_je049691v_BPROPblock_3_T298.1_fit.png` — RK fit plot — 10.1021/je049691v PROPblock_3_T298.1
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/plots\10_1021_je049691v_BPROPblock_3_T298.1_excess.png` — Excess plot — 10.1021/je049691v PROPblock_3_T298.1


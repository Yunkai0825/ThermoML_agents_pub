# Reference Stats — main-agent

**Run started:** 2026-08-02 19:20:15
**Wall time (at last flush):** 716.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 45,051 | 77,471 | 13,988 | 122,522 | 13,613 | 94.7 | claudeopus46 |
| **TOTAL** | **9** | **45,051** | **77,471** | **13,988** | **122,522** | **13,613** | **94.7** | |

**Estimated tokens:** ~30,630 input + ~3,497 output = ~34,127 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `run_analysis_agent` | context=The user wants excess molar v…, purpose=Fi… | 11,552 | — | — | 633.1 |
| | | **TOTAL (1 tools)** | | **11,552** | | **0** | **633.1** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 12,671 | 12,671 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 412 | 10,627 | 1,611 | 8.8 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,122 | 11,337 | 1,502 | 7.8 |
| 3 | L0-main | claudeopus46 | 10,182 | 21,656 | 31,838 | 425 | 5.0 |
| 4 | L0-main | claudeopus46 | 10,215 | 20,897 | 31,112 | 5,049 | 37.2 |
| 5 | L0-main | claudeopus46 | 1,323 | 19,776 | 21,099 | 907 | 7.7 |
| 6 | L0-main | claudeopus46 | 1,356 | 4,188 | 5,544 | 1,133 | 8.9 |
| 7 | L0-main | claudeopus46 | 298 | 1,430 | 1,728 | 783 | 4.0 |
| 8 | L0-main | claudeopus46 | 298 | 1,515 | 1,813 | 1,093 | 3.8 |
| 9 | L0-main | claudeopus46 | 949 | 6,475 | 7,424 | 1,485 | 11.5 |


# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 6 | 31,792 | 95,568 | 12,647 | 127,360 | 21,226 | 85.6 | claudeopus46 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| L1-worker | 52 | 689,482 | 487,188 | 64,934 | 1,176,670 | 22,628 | 470.2 | claudeopus46 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| L0-main | 24 | 404,926 | 292,547 | 157,551 | 697,473 | 29,061 | 884.1 | claudeopus46 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| L1-worker | 12 | 111,605 | 82,012 | 18,863 | 193,617 | 16,134 | 119.9 | claudeopus46 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| **TOTAL** | **94** | **1,237,805** | **957,315** | **253,995** | **2,195,120** | **89,049** | **1,559.8** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| **TOTAL** | **12** | **0** | **2** | **0** | **5** | **0** | **0** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Unique References | 1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Unique Block_Types | 1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Unique Phases | 1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Unique Variables | 2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Unique parent blocks | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Explicit block/subsystem targets | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Subsystem targets | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| Target-matched data points | 0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| **TOTAL** | **7** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve methanol an… | 212 | KEEP | 212 | 3.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 2 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 783 | KEEP | 738 | 16.9 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 3 | 8 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 275 | KEEP | 275 | 4.4 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 4 | 9 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 236 | KEEP | 236 | 3.6 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 5 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 826 | DISCARD | 765 | 8.6 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 6 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 831 | DISCARD | 770 | 12.6 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 7 | 1 | `L1_query` | context=Surface tension is GLOBprop_1…, id_catalog… | 9,940 | — | — | 206.9 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 8 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 875 | DISCARD | 799 | 11.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 9 | 6 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 727 | DISCARD | 651 | 16.9 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 10 | 9 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 691 | DISCARD | 615 | 11.0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 11 | 12 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS met',…, explanat… | 644 | DISCARD | 553 | 11.6 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 12 | 2 | `L1_query` | context=Block PROPblock_13 in GLOBlit…, id_catalog… | 8,870 | — | — | 267.0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 1 | 4 | `inspect_block` | block_number=13, doi=10.1021/je050519g, purpose=In… | 221 | — | — | 0.2 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 2 | 4 | `get_pure_values` | block_number=13, doi=10.1021/je050519g, edge_thres… | 225 | — | — | 0.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 3 | 5 | `inspect_block` | block_number=13, doi=10.1021/je050519g, purpose=In… | 147 | — | — | 0.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 4 | 5 | `get_pure_values` | block_number=13, doi=10.1021/je050519g, edge_thres… | 149 | — | — | 0.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 5 | 7 | `inspect_block` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 1,412 | — | — | 0.2 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 6 | 7 | `get_pure_values` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 124 | — | — | 0.3 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 7 | 8 | `query_thermoml_parallel` | queries=[{'label': 'pure_methanol_st'… | 184 | — | — | 0.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 8 | 10 | `query_thermoml_parallel` | queries=[{'label': 'pure_methanol_st'… | 314 | — | — | 0.3 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 9 | 13 | `query_thermoml` | context=Need pure-component surface t…, id_catalog… | 282 | — | — | 110.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 10 | 13 | `fit_block` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 112 | — | — | 0.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 11 | 14 | `get_pure_values` | block_number=PROPblock_3, doi=10.1021/je050519g, p… | 124 | — | — | 0.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 12 | 14 | `get_pure_values` | block_number=PROPblock_1, doi=10.1021/je050519g, p… | 124 | — | — | 0.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 13 | 14 | `fit_block` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 112 | — | — | 0.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 14 | 15 | `propose_fitting_plan` | block_number=PROPblock_13, composition_hint=mole_f… | 117 | — | — | 0.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 15 | 17 | `propose_fitting_plan` | block_number=PROPblock_13, composition_hint=mole_f… | 117 | — | — | 0.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| **TOTAL** | **225** |  |  | **28,674** |  | **5,614** | **686.7** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,154 | 3,154 | 0 | 0.0% | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 2 | interval=3 | skipped_by_agent | 6,209 | 6,209 | 0 | 0.0% | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 3 | interval=3 | skipped_by_agent | 3,545 | 3,545 | 0 | 0.0% | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 4 | interval=3 | skipped_by_agent | 5,587 | 5,587 | 0 | 0.0% | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 5 | interval=3 | skipped_by_agent | 7,568 | 7,568 | 0 | 0.0% | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 6 | interval=3 | skipped_by_agent | 9,521 | 9,521 | 0 | 0.0% | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 1 | interval=3 | skipped_by_agent | 15,416 | 15,416 | 0 | 0.0% | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| **TOTAL** |  |  | **51,000** | **51,000** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,008 | 10,613 | 1,334 | 8.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,223 | 21,866 | 710 | 5.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 3 | L1-worker | claudeopus46 | 2,065 | 453 | 2,518 | 362 | 3.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,934 | 22,577 | 1,358 | 9.0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,823 | 23,466 | 1,513 | 11.6 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 6 | L1-worker | claudeopus46 | 2,065 | 1,479 | 3,544 | 1,249 | 8.4 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,449 | 25,059 | 513 | 4.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,696 | 24,339 | 1,289 | 8.5 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,565 | 25,208 | 1,021 | 6.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,410 | 26,053 | 1,003 | 7.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 11 | L1-worker | claudeopus46 | 20,643 | 6,308 | 26,951 | 1,194 | 9.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 12 | L1-worker | claudeopus46 | 20,643 | 7,210 | 27,853 | 1,052 | 9.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 13 | L1-worker | claudeopus46 | 2,065 | 400 | 2,465 | 454 | 4.2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 14 | L1-worker | claudeopus46 | 20,643 | 6,134 | 26,777 | 1,775 | 11.4 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 15 | L1-worker | claudeopus46 | 2,065 | 358 | 2,423 | 365 | 3.4 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 16 | L1-worker | claudeopus46 | 20,610 | 7,654 | 28,264 | 453 | 3.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 17 | L1-worker | claudeopus46 | 20,643 | 6,901 | 27,544 | 1,698 | 9.6 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 18 | L1-worker | claudeopus46 | 2,065 | 1,194 | 3,259 | 1,251 | 7.5 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 19 | L1-worker | claudeopus46 | 20,643 | 8,303 | 28,946 | 2,117 | 14.9 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 20 | L1-worker | claudeopus46 | 2,065 | 1,170 | 3,235 | 1,395 | 11.5 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 21 | L1-worker | claudeopus46 | 20,643 | 9,651 | 30,294 | 1,464 | 10.5 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 22 | L1-worker | claudeopus46 | 20,610 | 10,126 | 30,736 | 2,032 | 14.2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 23 | L1-worker | claudeopus46 | 536 | 2,043 | 2,579 | 693 | 4.2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 24 | L1-worker | claudeopus46 | 1,356 | 2,163 | 3,519 | 796 | 4.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 25 | L1-worker | claudeopus46 | 1,323 | 17,450 | 18,773 | 1,213 | 6.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 26 | L1-worker | claudeopus46 | 298 | 1,935 | 2,233 | 901 | 4.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 27 | L1-worker | claudeopus46 | 747 | 26,077 | 26,824 | 799 | 7.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 28 | L0-main | claudeopus46 | 9,605 | 21,930 | 31,535 | 2,092 | 16.5 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 29 | L1-worker | claudeopus46 | 20,643 | 12,338 | 32,981 | 1,825 | 11.5 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 30 | L1-worker | claudeopus46 | 20,643 | 13,226 | 33,869 | 1,648 | 11.2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 31 | L1-worker | claudeopus46 | 20,643 | 14,057 | 34,700 | 1,258 | 8.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 32 | L1-worker | claudeopus46 | 2,065 | 1,964 | 4,029 | 1,390 | 10.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 33 | L1-worker | claudeopus46 | 20,610 | 15,308 | 35,918 | 630 | 5.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 34 | L1-worker | claudeopus46 | 20,643 | 14,555 | 35,198 | 1,710 | 10.5 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 35 | L1-worker | claudeopus46 | 20,643 | 15,523 | 36,166 | 1,180 | 10.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 36 | L1-worker | claudeopus46 | 20,643 | 16,345 | 36,988 | 1,376 | 9.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 37 | L1-worker | claudeopus46 | 2,065 | 2,012 | 4,077 | 1,212 | 9.0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 38 | L1-worker | claudeopus46 | 20,610 | 17,425 | 38,035 | 547 | 6.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 39 | L1-worker | claudeopus46 | 20,643 | 16,672 | 37,315 | 1,960 | 11.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 40 | L1-worker | claudeopus46 | 20,643 | 17,515 | 38,158 | 2,545 | 15.0 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 41 | L1-worker | claudeopus46 | 20,643 | 18,357 | 39,000 | 2,060 | 13.2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 42 | L1-worker | claudeopus46 | 2,065 | 2,025 | 4,090 | 1,263 | 9.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 43 | L1-worker | claudeopus46 | 20,610 | 19,481 | 40,091 | 644 | 4.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 44 | L1-worker | claudeopus46 | 20,643 | 18,728 | 39,371 | 2,102 | 13.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 45 | L1-worker | claudeopus46 | 20,643 | 19,594 | 40,237 | 2,616 | 17.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 46 | L1-worker | claudeopus46 | 20,643 | 20,423 | 41,066 | 1,548 | 9.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 47 | L1-worker | claudeopus46 | 2,065 | 1,729 | 3,794 | 1,399 | 9.7 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 48 | L1-worker | claudeopus46 | 20,610 | 21,510 | 42,120 | 698 | 5.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 49 | L1-worker | claudeopus46 | 20,610 | 9,980 | 30,590 | 2,890 | 21.3 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 50 | L1-worker | claudeopus46 | 536 | 1,854 | 2,390 | 816 | 5.9 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 51 | L1-worker | claudeopus46 | 1,356 | 1,974 | 3,330 | 706 | 10.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 52 | L1-worker | claudeopus46 | 1,323 | 22,522 | 23,845 | 808 | 18.6 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 53 | L1-worker | claudeopus46 | 298 | 1,530 | 1,828 | 681 | 3.2 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 54 | L1-worker | claudeopus46 | 747 | 29,432 | 30,179 | 752 | 6.9 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 55 | L0-main | claudeopus46 | 9,605 | 40,347 | 49,952 | 3,558 | 32.8 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 56 | L0-main | claudeopus46 | 1,356 | 2,702 | 4,058 | 913 | 5.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 57 | L0-main | claudeopus46 | 1,323 | 26,295 | 27,618 | 2,618 | 15.1 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 58 | L0-main | claudeopus46 | 298 | 3,286 | 3,584 | 2,132 | 7.3 | Find surface tension data for binary mixtures of methanol an (query_runs/run_3) |
| 1 | L0-main | claudeopus46 | 20,021 | 1,112 | 21,133 | 1,360 | 7.4 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 2 | L0-main | claudeopus46 | 20,021 | 3,178 | 23,199 | 14,037 | 74.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 3 | L0-main | claudeopus46 | 20,021 | 4,101 | 24,122 | 16,734 | 79.9 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 4 | L0-main | claudeopus46 | 20,021 | 5,295 | 25,316 | 15,841 | 79.4 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 5 | L0-main | claudeopus46 | 20,021 | 4,566 | 24,587 | 855 | 4.3 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 6 | L0-main | claudeopus46 | 20,021 | 5,473 | 25,494 | 863 | 6.3 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 7 | L0-main | claudeopus46 | 20,021 | 7,042 | 27,063 | 1,049 | 5.7 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 8 | L0-main | claudeopus46 | 20,021 | 9,285 | 29,306 | 15,800 | 78.9 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 9 | L0-main | claudeopus46 | 20,021 | 10,073 | 30,094 | 1,697 | 9.8 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 10 | L0-main | claudeopus46 | 20,021 | 12,343 | 32,364 | 1,435 | 8.5 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 11 | L0-main | claudeopus46 | 20,021 | 12,820 | 32,841 | 14,494 | 80.7 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 12 | L0-main | claudeopus46 | 20,021 | 13,933 | 33,954 | 1,683 | 9.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 13 | L0-main | claudeopus46 | 20,021 | 14,796 | 34,817 | 14,633 | 76.2 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 14 | L1-worker | claudeopus46 | 20,643 | 746 | 21,389 | 1,106 | 8.5 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,552 | 22,195 | 3,950 | 24.4 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,360 | 23,003 | 1,354 | 9.3 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 17 | L1-worker | claudeopus46 | 20,643 | 3,178 | 23,821 | 1,128 | 7.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 18 | L1-worker | claudeopus46 | 2,065 | 9,173 | 11,238 | 1,520 | 12.5 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 19 | L1-worker | claudeopus46 | 2,065 | 7,782 | 9,847 | 1,553 | 11.7 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 20 | L1-worker | claudeopus46 | 20,643 | 4,613 | 25,256 | 2,074 | 12.8 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 21 | L1-worker | claudeopus46 | 1,356 | 2,203 | 3,559 | 1,004 | 5.2 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 22 | L1-worker | claudeopus46 | 536 | 2,083 | 2,619 | 1,017 | 7.1 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 23 | L1-worker | claudeopus46 | 1,323 | 10,067 | 11,390 | 1,965 | 8.6 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 24 | L1-worker | claudeopus46 | 298 | 2,687 | 2,985 | 1,589 | 6.2 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 25 | L1-worker | claudeopus46 | 747 | 35,568 | 36,315 | 603 | 6.5 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 26 | L0-main | claudeopus46 | 20,021 | 16,679 | 36,700 | 7,639 | 46.9 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 27 | L0-main | claudeopus46 | 20,021 | 17,965 | 37,986 | 11,340 | 71.6 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 28 | L0-main | claudeopus46 | 19,988 | 19,501 | 39,489 | 540 | 4.8 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 29 | L0-main | claudeopus46 | 20,021 | 18,741 | 38,762 | 8,226 | 51.9 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 30 | L0-main | claudeopus46 | 20,021 | 19,693 | 39,714 | 8,127 | 51.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 31 | L0-main | claudeopus46 | 20,021 | 20,154 | 40,175 | 10,158 | 60.9 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 32 | L0-main | claudeopus46 | 20,021 | 30,922 | 50,943 | 4,916 | 22.9 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 33 | L0-main | claudeopus46 | 1,356 | 5,045 | 6,401 | 1,065 | 6.4 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 34 | L0-main | claudeopus46 | 1,323 | 29,363 | 30,686 | 2,142 | 29.6 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 35 | L0-main | claudeopus46 | 298 | 2,984 | 3,282 | 1,798 | 7.9 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| 36 | L0-main | claudeopus46 | 1,562 | 7,483 | 9,045 | 1,119 | 10.0 | Extract row-level data from PROPblock_13 (GLOBlit_8821, DOI  (analysis_runs/run_1) |
| **TOTAL** |  |  | **1,237,805** | **957,315** | **2,195,120** | **253,995** | **1,559.8** |  |

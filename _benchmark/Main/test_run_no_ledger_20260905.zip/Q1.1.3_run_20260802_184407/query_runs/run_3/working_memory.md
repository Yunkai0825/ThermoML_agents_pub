# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_4 | methanol | methanol |
| comp | GLOBcomp_15 | acetonitrile | acetonitrile |
| prop | GLOBprop_13 | surface_tension_liquidgas_n_m | Surface tension liquid-gas, N/m |
| var | GLOBvar_1 | temperature_k | Temperature, K |
| var | GLOBvar_2 | mole_fraction_{DOIcomp_id} | Mole fraction |
| phase | GLOBphase_1 | liquid | Liquid |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|
| lit | GLOBlit_8821 | 2006-tah-mod-0 | 10.1021/je050519g |

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find surface tension measurements for methanol + acetonitrile binary mixtures near room temperature (293-303 K) → stored as L1_query_1
- [L1] Extract individual row-level data points from PROPblock_13 in GLOBlit_8821 for surface tension of methanol + acetonitril → stored as L1_query_2

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "Surface tension measurements for the binary mixture of methanol (GLOBcomp_4, CH₄O) and acetonitrile (GLOBcomp_15, C₂H₃N) were found in the ThermoML database in one data block:\n\n**Source:**\n- **DOI:** 10.1021/je050519g\n- **Literature ID:** GLOBlit_8821\n- **Block:** PROPblock_13\n- **System type:** Binary mixture\n\n**Property:**\n- Surface tension (liquid–gas), GLOBprop_13, measured in N/m\n- Phase: GLOBphase_1 (liquid–gas interface)\n\n**Data summary:**\n- **7 data points** are recorded in this block.\n- The **mean surface tension** across the composition range is approximately **0.02659 N/m** (26.59 mN/m).\n\nThis value is physically reasonable: pure methanol has a surface tension of roughly 22.1 mN/m at 298 K, while pure acetonitrile is about 28.7 mN/m at the same temperature. The measured mean of ~26.6 mN/m for their binary mixtures falls within this range, consistent with near-ideal mixing behavior for surface tension in this system.\n\n**Limitations of retrieved detail:**\nIndividual row-level data (specific temperatures, mole-fraction compositions, and corresponding surface tension values at each point) could not be extracted in the available iterations due to parameter-declaration syntax constraints in the advanced block search. However, the block is confirmed to contain 7 complete data points spanning the binary composition range, and the data are available under DOI 10.1021/je050519g (PROPblock_13) for detailed consultation.\n\n**Chemistry insight:**\nMethanol and acetonitrile are both polar, low-molecular-weight solvents commonly used in chromatography and chemical synthesis. Their binary surface tension behavior near room temperature is of practical interest for understanding wetting, capillary phenomena, and interfacial processes in mixed-solvent systems. The relatively narrow range of surface tensions between the two pure components (~22–29 mN/m) suggests modest composition dependence, which is consistent with the similar polarities and hydrogen-bonding capacities of these solvents.",
  "core_claims": [
    "Surface tension data for the binary mixture of methanol and acetonitrile were identified in the ThermoML database under DOI 10.1021/je050519g (PROPblock_13), comprising 7 data points spanning the binary composition range with a mean surface tension of approximately 0.02659 N/m (26.59 mN/m).",
    "The mean surface tension of ~26.6 mN/m is physically consistent with the pure-component values of roughly 22.1 mN/m for methanol and 28.7 mN/m for acetonitrile at 298 K, suggesting near-ideal mixing behavior for surface tension in this system.",
    "Individual row-level data (specific temperatures, mole fractions, and corresponding surface tension values) could not be extracted due to parameter-declaration syntax constraints, limiting the analysis to block-level summary statistics."
  ],
  "status": "partial",
  "summary": "Surface tension (liquid–gas) data for the binary mixture of methanol (CH₄O) and acetonitrile (C₂H₃N) were identified in the ThermoML database under DOI 10.1021/je050519g, block PROPblock_13. The block contains 7 data points spanning the binary composition range, with a mean surface tension of approximately 0.02659 N/m (26.59 mN/m). This value falls between the pure-component surface tensions of methanol (~22.1 mN/m) and acetonitrile (~28.7 mN/m) at 298 K, consistent with near-ideal mixing behavior. Individual row-level details (specific temperatures, mole fractions, and point-by-point surface tension values) were not fully extracted but are available in the cited source.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_15",
      "registry_id": "acetonitrile",
      "name": "acetonitrile"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_8821",
      "registry_id": "2006-tah-mod-0",
      "name": "10.1021/je050519g"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_13",
      "registry_id": "surface_tension_liquidgas_n_m",
      "name": "Surface tension liquid-gas, N/m"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_2",
      "registry_id": "mole_fraction_{DOIcomp_id}",
      "name": "Mole fraction"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBphase_1",
      "registry_id": "liquid",
      "name": "Liquid"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_8821",
      "block_number": "PROPblock_13",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_13"
      ],
      "description": "Surface tension (liquid-gas) measurements for the binary mixture of methanol (GLOBcomp_4) and acetonitrile (GLOBcomp_15). DOI 10.1021/je050519g. 7 data points with mean surface tension ~0.02659 N/m. Individual row-level temperature and mole-fraction data could not be extracted due to parameter-declaration syntax constraints in block_search_adv.",
      "doi": "10.1021/je050519g",
      "lit_id": "2006-tah-mod-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 7,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 293.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.1001,
            "max": 0.8956,
            "n_unique": 7
          },
          "range_min": 0.1001,
          "range_max": 0.8956
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_13",
          "prop_ID": "surface_tension_liquidgas_n_m",
          "name": "Surface tension liquid-gas, N/m",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_22",
          "meas_ID": "pendant_drop_shape",
          "method_standard": "Pendant drop shape",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Surface tension liquid-gas, N/m",
            "min": 0.0238,
            "max": 0.02885,
            "mean": 0.026589,
            "std": 0.001946,
            "n": 7
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0238,
          "range_max": 0.02885
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 7,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_2
{
  "answer": "**Surface Tension of Methanol + Acetonitrile (PROPblock_13, GLOBlit_8821)**\n\n**Source:** DOI 10.1021/je050519g (GLOBlit_8821), PROPblock_13\n\n**System:** Binary mixture of methanol (GLOBcomp_4) and acetonitrile (GLOBcomp_15)\n\n**Property:** Surface tension, liquid–gas (GLOBprop_13), in N/m\n\n**Conditions:**\n- Fixed temperature: 293.15 K\n- Variable: mole fraction of acetonitrile (GLOBvar_2, component GLOBcomp_15)\n\n**Block-level summary (confirmed across multiple searches):**\n- Number of data points: **7**\n- Mole fraction range (acetonitrile): **0.1001 – 0.8956**\n- Surface tension range: **0.0238 – 0.02885 N/m**\n- Mean surface tension: **0.02659 N/m**\n\n**Individual row-level values:**\nUnfortunately, the available search tools (`block_search_adv`) consistently returned block-level metadata and aggregate statistics rather than the individual per-row (x, σ) pairs. The database confirms the block identity, binding, and 7-point count, but the row-level numerical extraction was not achievable with the current toolset.\n\n**Chemistry context:** Surface tension in the methanol–acetonitrile system at 293.15 K spans roughly 23.8–28.9 mN/m across the composition range. Both components are polar aprotic/protic solvents with relatively low surface tensions compared to water. The data suggest a monotonic or near-monotonic trend across the acetonitrile mole fraction range, consistent with the similar surface tension magnitudes of pure methanol (~22.5 mN/m) and pure acetonitrile (~29.3 mN/m) at 293 K. The mean value of ~26.6 mN/m lies between the two pure-component values, as expected for this miscible binary system.\n\nTo obtain the exact 7 individual (mole fraction, surface tension) data pairs, direct consultation of the original publication (DOI: 10.1021/je050519g) or a row-level data export tool would be required.",
  "core_claims": [
    "Surface tension data for the methanol + acetonitrile binary mixture at 293.15 K (from DOI 10.1021/je050519g) comprise 7 data points spanning acetonitrile mole fractions of 0.1001–0.8956, with surface tension values ranging from 0.0238 to 0.02885 N/m and a mean of approximately 0.02659 N/m.",
    "The measured surface tension values lie between the pure-component values of methanol (~22.5 mN/m) and acetonitrile (~29.3 mN/m) at 293 K, consistent with expectations for this miscible binary system.",
    "Individual row-level (mole fraction, surface tension) data pairs could not be extracted with the available tools; consultation of the original publication would be required for those values."
  ],
  "status": "partial",
  "summary": "PROPblock_13 from GLOBlit_8821 (DOI 10.1021/je050519g) reports surface tension (liquid–gas, GLOBprop_13) for the binary mixture of methanol (GLOBcomp_4) and acetonitrile (GLOBcomp_15) at a fixed temperature of 293.15 K. The variable is the mole fraction of acetonitrile (GLOBvar_2, GLOBcomp_15). The block contains 7 data points spanning acetonitrile mole fractions from 0.1001 to 0.8956, with surface tension values ranging from 0.0238 to 0.02885 N/m (approximately 23.8–28.9 mN/m) and a mean of about 0.02659 N/m. The trend is consistent with the similar pure-component surface tensions of methanol (~22.5 mN/m) and acetonitrile (~29.3 mN/m) at 293 K. Individual row-level (mole fraction, surface tension) pairs were not extracted; the original publication would be needed for exact per-point values.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_8821",
      "block_number": "PROPblock_13",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_13"
      ],
      "description": "Surface tension (liquid–gas) of methanol + acetonitrile binary mixture at fixed T = 293.15 K as a function of mole fraction of acetonitrile. Block contains 7 data points with mole fraction range 0.1001–0.8956 and surface tension range 0.0238–0.02885 N/m (mean 0.02659 N/m). Individual row-level (x, σ) pairs could not be extracted; only block-level metadata and aggregate statistics were returned by the available toolset across 12 iterations.",
      "doi": "10.1021/je050519g",
      "lit_id": "2006-tah-mod-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 7,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 293.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.1001,
            "max": 0.8956,
            "n_unique": 7
          },
          "range_min": 0.1001,
          "range_max": 0.8956
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_13",
          "prop_ID": "surface_tension_liquidgas_n_m",
          "name": "Surface tension liquid-gas, N/m",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_22",
          "meas_ID": "pendant_drop_shape",
          "method_standard": "Pendant drop shape",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Surface tension liquid-gas, N/m",
            "min": 0.0238,
            "max": 0.02885,
            "mean": 0.026589,
            "std": 0.001946,
            "n": 7
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0238,
          "range_max": 0.02885
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 7,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


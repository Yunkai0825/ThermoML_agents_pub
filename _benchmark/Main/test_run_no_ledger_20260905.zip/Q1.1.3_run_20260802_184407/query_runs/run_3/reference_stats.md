# Reference Stats — query-agent

**Run started:** 2026-08-02 18:44:21
**Wall time (at last flush):** 555.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 31,792 | 95,568 | 12,647 | 127,360 | 21,226 | 85.6 | claudeopus46 |
| L1-worker | 52 | 689,482 | 487,188 | 64,934 | 1,176,670 | 22,628 | 470.2 | claudeopus46 |
| **TOTAL** | **58** | **721,274** | **582,756** | **77,581** | **1,304,030** | **22,483** | **555.8** | |

**Estimated tokens:** ~326,007 input + ~19,395 output = ~345,402 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| **TOTAL** | **12** | **0** | **2** | **0** | **5** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_4 |  | block_search_adv, resolve_compound_ids |
| GLOBcomp_15 |  | block_search_adv, resolve_compound_ids |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8821 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 |  | resolve_ids |
| GLOBvar_1 |  | resolve_ids |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 1 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve methanol an… | 212 | KEEP | 212 | 3.8 |
| 2 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 783 | KEEP | 738 | 16.9 |
| 3 | 8 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 275 | KEEP | 275 | 4.4 |
| 4 | 9 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 236 | KEEP | 236 | 3.6 |
| 5 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 826 | DISCARD | 765 | 8.6 |
| 6 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 831 | DISCARD | 770 | 12.6 |
| 7 | 1 | `L1_query` | context=Surface tension is GLOBprop_1…, id_catalog… | 9,940 | — | — | 206.9 |
| 8 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 875 | DISCARD | 799 | 11.8 |
| 9 | 6 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 727 | DISCARD | 651 | 16.9 |
| 10 | 9 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 691 | DISCARD | 615 | 11.0 |
| 11 | 12 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS met',…, explanat… | 644 | DISCARD | 553 | 11.6 |
| 12 | 2 | `L1_query` | context=Block PROPblock_13 in GLOBlit…, id_catalog… | 8,870 | — | — | 267.0 |
| | | **TOTAL (12 tools)** | | **24,910** | | **5,614** | **575.1** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,154 | 3,154 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 6,209 | 6,209 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 3,545 | 3,545 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 5,587 | 5,587 | 0 | 0.0% |
| 5 | interval=3 | skipped_by_agent | 7,568 | 7,568 | 0 | 0.0% |
| 6 | interval=3 | skipped_by_agent | 9,521 | 9,521 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,008 | 10,613 | 1,334 | 8.8 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,223 | 21,866 | 710 | 5.1 |
| 3 | L1-worker | claudeopus46 | 2,065 | 453 | 2,518 | 362 | 3.7 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,934 | 22,577 | 1,358 | 9.0 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,823 | 23,466 | 1,513 | 11.6 |
| 6 | L1-worker | claudeopus46 | 2,065 | 1,479 | 3,544 | 1,249 | 8.4 |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,449 | 25,059 | 513 | 4.8 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,696 | 24,339 | 1,289 | 8.5 |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,565 | 25,208 | 1,021 | 6.8 |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,410 | 26,053 | 1,003 | 7.1 |
| 11 | L1-worker | claudeopus46 | 20,643 | 6,308 | 26,951 | 1,194 | 9.1 |
| 12 | L1-worker | claudeopus46 | 20,643 | 7,210 | 27,853 | 1,052 | 9.7 |
| 13 | L1-worker | claudeopus46 | 2,065 | 400 | 2,465 | 454 | 4.2 |
| 14 | L1-worker | claudeopus46 | 20,643 | 6,134 | 26,777 | 1,775 | 11.4 |
| 15 | L1-worker | claudeopus46 | 2,065 | 358 | 2,423 | 365 | 3.4 |
| 16 | L1-worker | claudeopus46 | 20,610 | 7,654 | 28,264 | 453 | 3.8 |
| 17 | L1-worker | claudeopus46 | 20,643 | 6,901 | 27,544 | 1,698 | 9.6 |
| 18 | L1-worker | claudeopus46 | 2,065 | 1,194 | 3,259 | 1,251 | 7.5 |
| 19 | L1-worker | claudeopus46 | 20,643 | 8,303 | 28,946 | 2,117 | 14.9 |
| 20 | L1-worker | claudeopus46 | 2,065 | 1,170 | 3,235 | 1,395 | 11.5 |
| 21 | L1-worker | claudeopus46 | 20,643 | 9,651 | 30,294 | 1,464 | 10.5 |
| 22 | L1-worker | claudeopus46 | 20,610 | 10,126 | 30,736 | 2,032 | 14.2 |
| 23 | L1-worker | claudeopus46 | 536 | 2,043 | 2,579 | 693 | 4.2 |
| 24 | L1-worker | claudeopus46 | 1,356 | 2,163 | 3,519 | 796 | 4.7 |
| 25 | L1-worker | claudeopus46 | 1,323 | 17,450 | 18,773 | 1,213 | 6.8 |
| 26 | L1-worker | claudeopus46 | 298 | 1,935 | 2,233 | 901 | 4.1 |
| 27 | L1-worker | claudeopus46 | 747 | 26,077 | 26,824 | 799 | 7.1 |
| 28 | L0-main | claudeopus46 | 9,605 | 21,930 | 31,535 | 2,092 | 16.5 |
| 29 | L1-worker | claudeopus46 | 20,643 | 12,338 | 32,981 | 1,825 | 11.5 |
| 30 | L1-worker | claudeopus46 | 20,643 | 13,226 | 33,869 | 1,648 | 11.2 |
| 31 | L1-worker | claudeopus46 | 20,643 | 14,057 | 34,700 | 1,258 | 8.8 |
| 32 | L1-worker | claudeopus46 | 2,065 | 1,964 | 4,029 | 1,390 | 10.7 |
| 33 | L1-worker | claudeopus46 | 20,610 | 15,308 | 35,918 | 630 | 5.1 |
| 34 | L1-worker | claudeopus46 | 20,643 | 14,555 | 35,198 | 1,710 | 10.5 |
| 35 | L1-worker | claudeopus46 | 20,643 | 15,523 | 36,166 | 1,180 | 10.1 |
| 36 | L1-worker | claudeopus46 | 20,643 | 16,345 | 36,988 | 1,376 | 9.1 |
| 37 | L1-worker | claudeopus46 | 2,065 | 2,012 | 4,077 | 1,212 | 9.0 |
| 38 | L1-worker | claudeopus46 | 20,610 | 17,425 | 38,035 | 547 | 6.7 |
| 39 | L1-worker | claudeopus46 | 20,643 | 16,672 | 37,315 | 1,960 | 11.8 |
| 40 | L1-worker | claudeopus46 | 20,643 | 17,515 | 38,158 | 2,545 | 15.0 |
| 41 | L1-worker | claudeopus46 | 20,643 | 18,357 | 39,000 | 2,060 | 13.2 |
| 42 | L1-worker | claudeopus46 | 2,065 | 2,025 | 4,090 | 1,263 | 9.7 |
| 43 | L1-worker | claudeopus46 | 20,610 | 19,481 | 40,091 | 644 | 4.7 |
| 44 | L1-worker | claudeopus46 | 20,643 | 18,728 | 39,371 | 2,102 | 13.1 |
| 45 | L1-worker | claudeopus46 | 20,643 | 19,594 | 40,237 | 2,616 | 17.8 |
| 46 | L1-worker | claudeopus46 | 20,643 | 20,423 | 41,066 | 1,548 | 9.7 |
| 47 | L1-worker | claudeopus46 | 2,065 | 1,729 | 3,794 | 1,399 | 9.7 |
| 48 | L1-worker | claudeopus46 | 20,610 | 21,510 | 42,120 | 698 | 5.1 |
| 49 | L1-worker | claudeopus46 | 20,610 | 9,980 | 30,590 | 2,890 | 21.3 |
| 50 | L1-worker | claudeopus46 | 536 | 1,854 | 2,390 | 816 | 5.9 |
| 51 | L1-worker | claudeopus46 | 1,356 | 1,974 | 3,330 | 706 | 10.1 |
| 52 | L1-worker | claudeopus46 | 1,323 | 22,522 | 23,845 | 808 | 18.6 |
| 53 | L1-worker | claudeopus46 | 298 | 1,530 | 1,828 | 681 | 3.2 |
| 54 | L1-worker | claudeopus46 | 747 | 29,432 | 30,179 | 752 | 6.9 |
| 55 | L0-main | claudeopus46 | 9,605 | 40,347 | 49,952 | 3,558 | 32.8 |
| 56 | L0-main | claudeopus46 | 1,356 | 2,702 | 4,058 | 913 | 5.1 |
| 57 | L0-main | claudeopus46 | 1,323 | 26,295 | 27,618 | 2,618 | 15.1 |
| 58 | L0-main | claudeopus46 | 298 | 3,286 | 3,584 | 2,132 | 7.3 |


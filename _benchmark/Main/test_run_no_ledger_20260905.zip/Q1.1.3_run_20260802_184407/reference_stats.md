# Reference Stats — main-agent

**Run started:** 2026-08-02 18:44:07
**Wall time (at last flush):** 1,691.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 15 | 106,275 | 224,740 | 21,898 | 331,015 | 22,067 | 140.6 | claudeopus46 |
| L0-menu-planner | 1 | 831 | 1,413 | 1,612 | 2,244 | 2,244 | 10.4 | claudesonnet46 |
| **TOTAL** | **16** | **107,106** | **226,153** | **23,510** | **333,259** | **20,828** | **151.0** | |

**Estimated tokens:** ~83,314 input + ~5,877 output = ~89,191 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `run_query_agent` | context=The user wants to know what s…, purpose=Lo… | 7,051 | — | — | 555.2 |
| 2 | 4 | `browse_subagent_tools` | purpose=Extract row-level mole fracti…, tasks=1. E… | 1,612 | — | — | 10.6 |
| 3 | 6 | `run_analysis_agent` | context=PROPblock_13 contains 7 surfa…, purpose=Ob… | 10,550 | — | — | 995.1 |
| | | **TOTAL (3 tools)** | | **19,213** | | **0** | **1560.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 8,046 | 8,046 | 0 | 0.0% |
| 2 | interval=2 | skipped_by_agent | 10,570 | 10,570 | 0 | 0.0% |
| 3 | interval=2 | skipped_by_agent | 22,011 | 22,011 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 331 | 10,546 | 1,238 | 7.6 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,043 | 11,258 | 1,093 | 6.5 |
| 3 | L0-main | claudeopus46 | 10,182 | 15,345 | 25,527 | 544 | 4.6 |
| 4 | L0-main | claudeopus46 | 10,215 | 14,588 | 24,803 | 1,377 | 9.2 |
| 5 | L0-main | claudeopus46 | 10,215 | 15,655 | 25,870 | 712 | 9.1 |
| 6 | L0-menu-planner | claudesonnet46 | 831 | 1,413 | 2,244 | 1,612 | 10.4 |
| 7 | L0-main | claudeopus46 | 10,182 | 17,998 | 28,180 | 597 | 5.4 |
| 8 | L0-main | claudeopus46 | 10,215 | 17,239 | 27,454 | 1,672 | 11.0 |
| 9 | L0-main | claudeopus46 | 10,215 | 17,931 | 28,146 | 1,733 | 10.8 |
| 10 | L0-main | claudeopus46 | 10,182 | 39,207 | 49,389 | 520 | 4.1 |
| 11 | L0-main | claudeopus46 | 10,215 | 38,578 | 48,793 | 5,803 | 35.4 |
| 12 | L0-main | claudeopus46 | 1,356 | 4,647 | 6,003 | 1,347 | 6.5 |
| 13 | L0-main | claudeopus46 | 1,323 | 31,968 | 33,291 | 1,323 | 8.4 |
| 14 | L0-main | claudeopus46 | 298 | 1,729 | 2,027 | 1,335 | 4.9 |
| 15 | L0-main | claudeopus46 | 298 | 1,846 | 2,144 | 1,149 | 4.6 |
| 16 | L0-main | claudeopus46 | 949 | 6,635 | 7,584 | 1,455 | 12.5 |


# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.1.3_run_20260802_184407\analysis_runs\run_1`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_4 | methanol |  |
| comp | GLOBcomp_15 | acetonitrile |  |
| prop | GLOBprop_13 | surfacetensionliquidgasnm |  |
| var | GLOBvar_2 | molefraction<acetonitrile> |  |
| constr | GLOBconstr_2 | temperaturek |  |

### History
- [inspect_block]
- [query_thermoml_parallel]
- [query_thermoml]
- [propose_fitting_plan] ERROR: No property column found in ['BLKpoint_id', 'mole_fraction_<acetonitrile>', 'tem
- [propose_fitting_plan] ERROR: No property column found in ['BLKpoint_id', 'mole_fraction_<acetonitrile>', 'tem

### Query Results
#### pure_methanol_st — ERROR
no active StatsRecorder; start agent tracking first

#### pure_acetonitrile_st — ERROR
no active StatsRecorder; start agent tracking first

#### query
Pure-component surface tension values at 293.15 K were compiled from ThermoML sources for methanol (GLOBcomp_4) and acetonitrile (GLOBcomp_15). For methanol, three blocks (from DOIs 10.1016/j.jct.2014.07.001, 10.1016/j.jct.2019.06.005, and 10.1021/je050519g) give values of 0.0226, 0.0238, and 0.02278 N/m respectively; the drop-volume and pendant-drop results agree closely, yielding a representative value of approximately 0.0227 N/m (22.7 mN/m), while the maximal bubble pressure value is slightly higher with larger uncertainty. For acetonitrile, three blocks (from DOIs 10.1021/je050519g, 10.1016/j.jct.2013.02.021, and 10.1021/je101146f) give values of 0.02925, 0.02895, and 0.02895 N/m, clustering around 0.0290 N/m (29.0 mN/m). One DOI (10.1021/je050519g, GLOBlit_8821) reports both pure components at 293.15 K using pendant-drop shape analysis, providing internally consistent endpoints suitable for Redlich–Kister fitting of excess surface tension in the methanol + acetonitrile binary system.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_4205 | 10.1016/j.jct.2014.07.001 | PROPblock_5 | declared | 4 | unary | unary |
| GLOBlit_5543 | 10.1016/j.jct.2019.06.005 | PROPblock_4 | declared | 7 | unary | unary |
| GLOBlit_8821 | 10.1021/je050519g | PROPblock_3 | declared | 1 | unary | unary |
| GLOBlit_8821 | 10.1021/je050519g | PROPblock_1 | declared | 1 | unary | unary |
| GLOBlit_3840 | 10.1016/j.jct.2013.02.021 | PROPblock_4 | declared | 5 | unary | unary |
| GLOBlit_9419 | 10.1021/je101146f | PROPblock_2 | declared | 5 | unary | unary |

### Inspected Blocks
- GLOBlit_8821 | 10.1021/je050519g | PROPblock_13: 7 rows; x=['mole_fraction_<acetonitrile>']; y=['surface_tension_liquidgas_n_m']
    - BLKprop_1 / GLOBprop_13: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_13: kind=direct; materialize_reference=False; supported=True; units=N/m -> N/m

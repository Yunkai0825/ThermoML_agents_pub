# Reference Stats — analysis-agent

**Run started:** 2026-08-02 18:54:38
**Wall time (at last flush):** 994.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 24 | 404,926 | 292,547 | 157,551 | 697,473 | 29,061 | 884.1 | claudeopus46 |
| L1-worker | 12 | 111,605 | 82,012 | 18,863 | 193,617 | 16,134 | 119.9 | claudeopus46 |
| **TOTAL** | **36** | **516,531** | **374,559** | **176,414** | **891,090** | **24,752** | **1004.0** | |

**Estimated tokens:** ~222,772 input + ~44,103 output = ~266,875 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 4 | `inspect_block` | block_number=13, doi=10.1021/je050519g, purpose=In… | 221 | — | — | 0.2 |
| 2 | 4 | `get_pure_values` | block_number=13, doi=10.1021/je050519g, edge_thres… | 225 | — | — | 0.0 |
| 3 | 5 | `inspect_block` | block_number=13, doi=10.1021/je050519g, purpose=In… | 147 | — | — | 0.0 |
| 4 | 5 | `get_pure_values` | block_number=13, doi=10.1021/je050519g, edge_thres… | 149 | — | — | 0.0 |
| 5 | 7 | `inspect_block` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 1,412 | — | — | 0.2 |
| 6 | 7 | `get_pure_values` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 124 | — | — | 0.3 |
| 7 | 8 | `query_thermoml_parallel` | queries=[{'label': 'pure_methanol_st'… | 184 | — | — | 0.0 |
| 8 | 10 | `query_thermoml_parallel` | queries=[{'label': 'pure_methanol_st'… | 314 | — | — | 0.3 |
| 9 | 13 | `query_thermoml` | context=Need pure-component surface t…, id_catalog… | 282 | — | — | 110.0 |
| 10 | 13 | `fit_block` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 112 | — | — | 0.1 |
| 11 | 14 | `get_pure_values` | block_number=PROPblock_3, doi=10.1021/je050519g, p… | 124 | — | — | 0.1 |
| 12 | 14 | `get_pure_values` | block_number=PROPblock_1, doi=10.1021/je050519g, p… | 124 | — | — | 0.1 |
| 13 | 14 | `fit_block` | block_number=PROPblock_13, doi=10.1021/je050519g, … | 112 | — | — | 0.1 |
| 14 | 15 | `propose_fitting_plan` | block_number=PROPblock_13, composition_hint=mole_f… | 117 | — | — | 0.1 |
| 15 | 17 | `propose_fitting_plan` | block_number=PROPblock_13, composition_hint=mole_f… | 117 | — | — | 0.1 |
| | | **TOTAL (15 tools)** | | **3,764** | | **0** | **111.6** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 15,416 | 15,416 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 1,112 | 21,133 | 1,360 | 7.4 |
| 2 | L0-main | claudeopus46 | 20,021 | 3,178 | 23,199 | 14,037 | 74.0 |
| 3 | L0-main | claudeopus46 | 20,021 | 4,101 | 24,122 | 16,734 | 79.9 |
| 4 | L0-main | claudeopus46 | 20,021 | 5,295 | 25,316 | 15,841 | 79.4 |
| 5 | L0-main | claudeopus46 | 20,021 | 4,566 | 24,587 | 855 | 4.3 |
| 6 | L0-main | claudeopus46 | 20,021 | 5,473 | 25,494 | 863 | 6.3 |
| 7 | L0-main | claudeopus46 | 20,021 | 7,042 | 27,063 | 1,049 | 5.7 |
| 8 | L0-main | claudeopus46 | 20,021 | 9,285 | 29,306 | 15,800 | 78.9 |
| 9 | L0-main | claudeopus46 | 20,021 | 10,073 | 30,094 | 1,697 | 9.8 |
| 10 | L0-main | claudeopus46 | 20,021 | 12,343 | 32,364 | 1,435 | 8.5 |
| 11 | L0-main | claudeopus46 | 20,021 | 12,820 | 32,841 | 14,494 | 80.7 |
| 12 | L0-main | claudeopus46 | 20,021 | 13,933 | 33,954 | 1,683 | 9.1 |
| 13 | L0-main | claudeopus46 | 20,021 | 14,796 | 34,817 | 14,633 | 76.2 |
| 14 | L1-worker | claudeopus46 | 20,643 | 746 | 21,389 | 1,106 | 8.5 |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,552 | 22,195 | 3,950 | 24.4 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,360 | 23,003 | 1,354 | 9.3 |
| 17 | L1-worker | claudeopus46 | 20,643 | 3,178 | 23,821 | 1,128 | 7.1 |
| 18 | L1-worker | claudeopus46 | 2,065 | 9,173 | 11,238 | 1,520 | 12.5 |
| 19 | L1-worker | claudeopus46 | 2,065 | 7,782 | 9,847 | 1,553 | 11.7 |
| 20 | L1-worker | claudeopus46 | 20,643 | 4,613 | 25,256 | 2,074 | 12.8 |
| 21 | L1-worker | claudeopus46 | 1,356 | 2,203 | 3,559 | 1,004 | 5.2 |
| 22 | L1-worker | claudeopus46 | 536 | 2,083 | 2,619 | 1,017 | 7.1 |
| 23 | L1-worker | claudeopus46 | 1,323 | 10,067 | 11,390 | 1,965 | 8.6 |
| 24 | L1-worker | claudeopus46 | 298 | 2,687 | 2,985 | 1,589 | 6.2 |
| 25 | L1-worker | claudeopus46 | 747 | 35,568 | 36,315 | 603 | 6.5 |
| 26 | L0-main | claudeopus46 | 20,021 | 16,679 | 36,700 | 7,639 | 46.9 |
| 27 | L0-main | claudeopus46 | 20,021 | 17,965 | 37,986 | 11,340 | 71.6 |
| 28 | L0-main | claudeopus46 | 19,988 | 19,501 | 39,489 | 540 | 4.8 |
| 29 | L0-main | claudeopus46 | 20,021 | 18,741 | 38,762 | 8,226 | 51.9 |
| 30 | L0-main | claudeopus46 | 20,021 | 19,693 | 39,714 | 8,127 | 51.0 |
| 31 | L0-main | claudeopus46 | 20,021 | 20,154 | 40,175 | 10,158 | 60.9 |
| 32 | L0-main | claudeopus46 | 20,021 | 30,922 | 50,943 | 4,916 | 22.9 |
| 33 | L0-main | claudeopus46 | 1,356 | 5,045 | 6,401 | 1,065 | 6.4 |
| 34 | L0-main | claudeopus46 | 1,323 | 29,363 | 30,686 | 2,142 | 29.6 |
| 35 | L0-main | claudeopus46 | 298 | 2,984 | 3,282 | 1,798 | 7.9 |
| 36 | L0-main | claudeopus46 | 1,562 | 7,483 | 9,045 | 1,119 | 10.0 |


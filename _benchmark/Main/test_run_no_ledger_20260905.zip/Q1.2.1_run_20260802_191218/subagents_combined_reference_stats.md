# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 18 | 265,044 | 172,791 | 26,233 | 437,835 | 24,324 | 172.8 | claudeopus46 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| L1-worker | 22 | 160,225 | 131,864 | 53,664 | 292,089 | 13,276 | 257.4 | claudeopus46 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| **TOTAL** | **40** | **425,269** | **304,655** | **79,897** | **729,924** | **37,600** | **430.2** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `query_thermoml` | context=Looking for liquid-phase dens…, instructio… | 295 | — | — | 151.2 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 2 | 2 | `query_thermoml` | context=Binary system: ethanol + wate…, instructio… | 282 | — | — | 85.8 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 3 | 4 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 4 | 4 | `inspect_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 1,376 | — | — | 0.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 5 | 6 | `propose_fitting_plan` | block_number=PROPblock_2, composition_hint=mole_fr… | 794 | — | — | 0.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 6 | 6 | `propose_fitting_plan` | block_number=PROPblock_19, composition_hint=mole_f… | 706 | — | — | 0.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 7 | 9 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 534 | — | — | 0.2 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 8 | 10 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 1,153 | — | — | 2.0 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| **TOTAL** | **42** |  |  | **6,514** |  |  | **239.6** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 8,948 | 8,948 | 0 | 0.0% | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 2 | interval=3 | skipped_by_agent | 10,640 | 10,640 | 0 | 0.0% | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 20,021 | 867 | 20,888 | 1,129 | 8.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 2 | L1-worker | claudeopus46 | 20,643 | 756 | 21,399 | 643 | 5.3 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,020 | 22,663 | 14,373 | 50.0 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 4 | L1-worker | claudeopus46 | 2,065 | 435 | 2,500 | 507 | 3.8 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,243 | 22,886 | 7,252 | 36.8 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 6 | L1-worker | claudeopus46 | 20,643 | 10,116 | 30,759 | 2,441 | 10.3 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,572 | 3,928 | 806 | 4.3 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 8 | L1-worker | claudeopus46 | 536 | 2,452 | 2,988 | 1,077 | 6.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 9 | L1-worker | claudeopus46 | 298 | 1,188 | 1,486 | 794 | 3.3 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 10 | L1-worker | claudeopus46 | 298 | 1,433 | 1,731 | 1,064 | 4.7 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 11 | L1-worker | claudeopus46 | 1,323 | 4,883 | 6,206 | 4,450 | 16.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 12 | L1-worker | claudeopus46 | 298 | 5,172 | 5,470 | 3,179 | 15.3 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 13 | L1-worker | claudeopus46 | 1,160 | 10,031 | 11,191 | 3,183 | 12.0 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 14 | L0-main | claudeopus46 | 20,021 | 1,639 | 21,660 | 949 | 7.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 15 | L1-worker | claudeopus46 | 20,643 | 675 | 21,318 | 775 | 5.7 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 16 | L1-worker | claudeopus46 | 2,065 | 477 | 2,542 | 459 | 3.9 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 17 | L1-worker | claudeopus46 | 20,643 | 1,387 | 22,030 | 807 | 6.3 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 18 | L1-worker | claudeopus46 | 2,065 | 14,525 | 16,590 | 1,598 | 13.9 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 19 | L1-worker | claudeopus46 | 20,643 | 3,193 | 23,836 | 2,098 | 13.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 20 | L1-worker | claudeopus46 | 1,356 | 2,227 | 3,583 | 736 | 4.5 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 21 | L1-worker | claudeopus46 | 536 | 2,107 | 2,643 | 1,077 | 8.6 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 22 | L1-worker | claudeopus46 | 1,323 | 5,742 | 7,065 | 3,266 | 14.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 23 | L1-worker | claudeopus46 | 298 | 3,988 | 4,286 | 2,391 | 10.1 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 24 | L1-worker | claudeopus46 | 747 | 54,242 | 54,989 | 688 | 9.2 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 25 | L0-main | claudeopus46 | 20,021 | 4,531 | 24,552 | 1,350 | 8.5 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 26 | L0-main | claudeopus46 | 20,021 | 5,784 | 25,805 | 967 | 5.5 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 27 | L0-main | claudeopus46 | 20,021 | 9,520 | 29,541 | 2,697 | 17.4 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 28 | L0-main | claudeopus46 | 20,021 | 10,690 | 30,711 | 1,292 | 7.8 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 29 | L0-main | claudeopus46 | 19,988 | 13,220 | 33,208 | 464 | 4.5 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 30 | L0-main | claudeopus46 | 20,021 | 12,463 | 32,484 | 1,623 | 10.4 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 31 | L0-main | claudeopus46 | 20,021 | 13,156 | 33,177 | 1,442 | 8.7 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 32 | L0-main | claudeopus46 | 20,021 | 13,893 | 33,914 | 1,458 | 9.5 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 33 | L0-main | claudeopus46 | 19,988 | 15,010 | 34,998 | 532 | 4.5 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 34 | L0-main | claudeopus46 | 20,021 | 14,251 | 34,272 | 1,475 | 9.9 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 35 | L0-main | claudeopus46 | 20,021 | 18,529 | 38,550 | 4,378 | 32.5 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 36 | L0-main | claudeopus46 | 1,356 | 3,485 | 4,841 | 966 | 8.7 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 37 | L0-main | claudeopus46 | 1,323 | 25,698 | 27,021 | 1,829 | 9.8 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 38 | L0-main | claudeopus46 | 298 | 1,348 | 1,646 | 954 | 3.7 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 39 | L0-main | claudeopus46 | 298 | 2,671 | 2,969 | 1,498 | 6.3 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |
| 40 | L0-main | claudeopus46 | 1,562 | 6,036 | 7,598 | 1,230 | 9.9 | Fit a Redlich-Kister polynomial to the density of liquid eth (analysis_runs/run_2) |

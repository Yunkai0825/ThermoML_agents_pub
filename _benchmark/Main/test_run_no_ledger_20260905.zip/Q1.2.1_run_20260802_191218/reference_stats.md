# Reference Stats — main-agent

**Run started:** 2026-08-02 19:12:18
**Wall time (at last flush):** 476.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 45,051 | 76,945 | 12,562 | 121,996 | 13,555 | 84.5 | claudeopus46 |
| **TOTAL** | **9** | **45,051** | **76,945** | **12,562** | **121,996** | **13,555** | **84.5** | |

**Estimated tokens:** ~30,499 input + ~3,140 output = ~33,639 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `run_analysis_agent` | context=The user wants density data f…, purpose=Fi… | 11,601 | — | — | 402.2 |
| | | **TOTAL (1 tools)** | | **11,601** | | **0** | **402.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 12,692 | 12,692 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 417 | 10,632 | 1,505 | 9.5 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,121 | 11,336 | 1,317 | 7.0 |
| 3 | L0-main | claudeopus46 | 10,182 | 21,649 | 31,831 | 430 | 4.6 |
| 4 | L0-main | claudeopus46 | 10,215 | 20,890 | 31,105 | 3,951 | 29.2 |
| 5 | L0-main | claudeopus46 | 1,356 | 4,080 | 5,436 | 1,088 | 7.1 |
| 6 | L0-main | claudeopus46 | 1,323 | 19,405 | 20,728 | 910 | 7.5 |
| 7 | L0-main | claudeopus46 | 298 | 1,470 | 1,768 | 1,076 | 3.8 |
| 8 | L0-main | claudeopus46 | 298 | 1,433 | 1,731 | 786 | 4.3 |
| 9 | L0-main | claudeopus46 | 949 | 6,480 | 7,429 | 1,499 | 11.5 |


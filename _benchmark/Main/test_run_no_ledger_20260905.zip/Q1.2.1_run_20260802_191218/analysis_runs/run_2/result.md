# Analysis Run — 20260802_191917 (Round 1)

**Question:** [Purpose: Find experimental density data for ethanol + water at 25°C in ThermoML and perform a Redlich-Kister fit to the composition-dependent density or excess density.]
Fit a Redlich-Kister polynomial to the density of liquid ethanol + water at 25°C as a function of ethanol mole fraction. Report the fitted equation, polynomial order, coefficients with units, R², RMSE, and composition range.

[Context: The user wants density data for the binary system ethanol + water at 25°C (298.15 K). Search ThermoML for density (mass density) measurements of this system, then fit a Redlich-Kister expansion to the excess or mixing density. Report all fitting details.]

**Time:** 375.6s | **Iterations:** 11 | **Tools:** 14

---

## Answer

# Redlich-Kister Fit: Density of Ethanol + Water at 298.15 K

## System & Property

- **Binary system:** ethanol (C₂H₅OH) + water (H₂O)
- **Property:** mass density (kg/m³), liquid phase
- **Temperature:** 298.15 K
- **Composition variable:** mole fraction of ethanol, x₁

## Fitted Equation

The Redlich-Kister expansion for density uses a **linear mixing rule** baseline:

$$\rho(x_1) = x_1 \cdot \rho_1^* + (1 - x_1) \cdot \rho_2^* + x_1(1 - x_1) \sum_{k=0}^{n} A_k (2x_1 - 1)^k$$

where x₁ = mole fraction of ethanol, ρ₁* = pure ethanol density, ρ₂* = pure water density, and the Aₖ are the Redlich-Kister coefficients (units: kg/m³).

---

## Fit Results from Two Independent Data Sources

### Source 1 — Largest composition coverage at atmospheric pressure

| Parameter | Value |
|-----------|-------|
| **DOI** | 10.1016/j.fluid.2004.11.019 (GLOBlit_220) |
| **Block** | PROPblock_2 |
| **Conditions** | T = 298.15 K, P = 100 kPa |
| **Data points** | 47 (at this isotherm/isobar) |
| **Composition range** | x(ethanol) = 0.003 – 1.0 |
| **BIC-selected RK order** | **3** (4 coefficients) |
| **R²** | **0.997283** |
| **RMSE** | **0.4748 kg/m³** |
| **ρ*(ethanol)** | 785.7 kg/m³ (block edge) |
| **ρ*(water)** | 992.083 kg/m³ (block edge) |

**Coefficients (kg/m³):**

| k | Aₖ |
|---|-----|
| 0 | −120.557 |
| 1 | +18.568 |
| 2 | +43.919 |
| 3 | −31.351 |

---

### Source 2 — Full 0–1 composition range

| Parameter | Value |
|-----------|-------|
| **DOI** | 10.1016/j.jct.2018.02.022 (GLOBlit_5201) |
| **Block** | PROPblock_19 |
| **Conditions** | T = 298.15 K, P = 92.3 kPa |
| **Data points** | 56 |
| **Composition range** | x(ethanol) = 0.0 – 1.0 |
| **BIC-selected RK order** | **5** (6 coefficients) |
| **R²** | **0.996578** |
| **RMSE** | **0.5768 kg/m³** |
| **ρ*(ethanol)** | 786.593 kg/m³ (block edge) |
| **ρ*(water)** | 996.569 kg/m³ (block edge) |

**Coefficients (kg/m³):**

| k | Aₖ |
|---|-----|
| 0 | −130.607 |
| 1 | +36.494 |
| 2 | +52.028 |
| 3 | −83.606 |
| 4 | −73.710 |
| 5 | +95.576 |

---

## Chemistry Insight

The ethanol–water system is a classic example of **non-ideal mixing** driven by hydrogen bonding. The large negative leading coefficient A₀ ≈ −121 to −131 kg/m³ reflects a pronounced **positive deviation** of density from the linear (ideal) mixing line — meaning the mixture is denser than expected from a simple mole-fraction-weighted average. This corresponds to the well-known **negative excess molar volume** (Vᴱ < 0), indicating that ethanol and water molecules pack more efficiently together than in their pure states, primarily due to the insertion of ethanol molecules into the open hydrogen-bond network of water.

Representative data points (Source 1, T = 298.15 K, P = 100 kPa):
- x(ethanol) = 0.003 → ρ ≈ 992 kg/m³ (nearly pure water)
- x(ethanol) ≈ 0.1–0.2 → ρ peaks above the linear baseline (maximum excess density)
- x(ethanol) = 1.0 → ρ ≈ 785.7 kg/m³ (pure ethanol)

The Source 1 fit (order 3, R² = 0.9973, RMSE = 0.47 kg/m³) provides a more parsimonious model, while Source 2 (order 5, R² = 0.9966, RMSE = 0.58 kg/m³) captures finer asymmetry in the excess density curve across the full composition range.

## Output Files

- Fit data CSVs and excess-property CSVs were generated for both sources.
- Fit and excess-density plots are available for visual inspection.

### Core claims

- At 298.15 K, the mass density of liquid ethanol + water mixtures was fitted to a Redlich-Kister expansion (linear baseline plus polynomial excess term in mole fraction of ethanol) using two independent ThermoML data sources, yielding BIC-selected orders of 3 (R² = 0.9973, RMSE = 0.47 kg/m³, 47 points at 100 kPa) and 5 (R² = 0.9966, RMSE = 0.58 kg/m³, 56 points at 92.3 kPa), respectively.
- The large negative leading Redlich-Kister coefficient A₀ ≈ −121 to −131 kg/m³ indicates that the mixture density lies above the linear mole-fraction-weighted average, corresponding to a negative excess molar volume (Vᴱ < 0) attributed to efficient molecular packing as ethanol molecules insert into water's hydrogen-bond network.
- The lower-order (order 3) fit provides a more parsimonious model, while the higher-order (order 5) fit captures finer asymmetry in the excess density across the full composition range from x(ethanol) = 0 to 1.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | 810-row block for ethanol + water; mass density (GLOBprop_1, BLKprop_1) measured by vibrating-tube method (GLOBmeas_138). Filtered to T = 298.15 K, P = 100 kPa yielding 47 composition points (x_ethanol 0.003–1.0). Pure-component densities from block edges: ethanol 785.7 kg/m³, water 992.083 kg/m³. |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 |  | 244-row block for ethanol + water; mass density (GLOBprop_1, BLKprop_1) measured by vibrating-tube method (GLOBmeas_2). Filtered to T = 298.15 K yielding 56 composition points (x_ethanol 0.0–1.0) at P = 92.3 kPa. Pure-component densities from block edges: ethanol 786.593 kg/m³, water 996.569 kg/m³. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_220 | PROPblock_2 | mass_density_kg_m3 | 3 | -120.557; 18.5676; 43.9191; -31.3506 | 0.997283 | 0.474765 | 47 | 298.15 | linear |  | 10.1016/j.fluid.2004.11.019 |
| GLOBlit_5201 | PROPblock_19 | mass_density_kg_m3 | 5 | -130.607; 36.494; 52.0283; -83.6062; -73.7102; 95.5763 | 0.996578 | 0.576832 | 56 | 298.15 | linear |  | 10.1016/j.jct.2018.02.022 |

---

## Verdict

**Data Quality**
The trace shows `fit_multi_system` calls were executed, confirming fits were not fabricated. Two independent ThermoML sources were used with substantial data points (47 and 56). However, the agent fitted total density with a linear baseline rather than fitting true excess molar volume (V^E) directly. Fitting ρ(x) with a linear-in-mole-fraction baseline is physically questionable since ideal mixing for density is not linear in mole fraction—it should use volume additivity. The composition basis is mole fraction, which is appropriate. No composition conversion flags are needed.

**Fit Quality**
R² values (~0.997) and RMSE (~0.5 kg/m³) are reasonable but not exceptional, likely because the linear density baseline is thermodynamically incorrect. The BIC-selected orders (3 and 5) seem reasonable given data density.

**Scientific Verdict**
Results are reproducible from real ThermoML data, but the linear-density baseline is thermodynamically inconsistent—ideal mixing should be defined via molar volumes, not densities. The negative A₀ interpretation as "denser than linear" is correct directionally but conflates with V^E < 0 imprecisely. Recommend refitting as V^E(x) for rigorous thermodynamic analysis.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2\plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.1_run_20260802_191218\analysis_runs\run_2`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_1 | water |  |
| comp | GLOBcomp_2 | ethanol |  |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_2 | molefraction<ethanol> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [propose_fitting_plan]
- [propose_fitting_plan]
- [fit_multi_system]
- [fit_multi_system]

### Query Results
#### query
Binary ethanol (C₂H₅OH, GLOBcomp_2) + water (H₂O, GLOBcomp_1) mass density (GLOBprop_1, kg/m³) data at or near 298.15 K were identified across 22 ThermoML data blocks from 22 DOIs. The most extensive blocks are from DOI 10.1016/j.fluid.2004.11.019 (GLOBlit_220, PROPblock_2, 810 points, x(ethanol) 0.003–0.7996 at 298.15 K and 100 kPa) and DOI 10.1016/j.jct.2018.02.022 (GLOBlit_5201, PROPblock_19, 244 points, x(ethanol) 0.0024–0.9895 at 293.15–298.15 K). Additional blocks with varying composition representations (mole fraction, mass fraction, molality) come from DOIs including 10.1016/j.jct.2019.02.027, 10.1021/je700618y, 10.1021/acs.jced.8b00086, 10.1021/acs.jced.8b00939, 10.1021/je0601098, and 10.1021/je700300y. The densest composition-coverage blocks are best suited for Redlich-Kister fitting of excess molar volume. The ethanol–water system exhibits significant negative excess volumes due to hydrogen-bonding-enhanced packing, with density showing a non-linear composition dependence that peaks above the ideal mixing line near x(ethanol) ≈ 0.1–0.2.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | binary |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | binary |
| GLOBlit_5473 | 10.1016/j.jct.2019.02.027 | PROPblock_21 | declared | 9 | binary | binary |
| GLOBlit_11005 | 10.1021/je700618y | PROPblock_9 | declared | 15 | binary | binary |
| GLOBlit_7448 | 10.1021/acs.jced.8b00086 | PROPblock_46 | declared | 6 | binary | binary |
| GLOBlit_7676 | 10.1021/acs.jced.8b00939 | PROPblock_17 | declared | 9 | binary | binary |
| GLOBlit_8888 | 10.1021/je0601098 | PROPblock_20 | declared | 12 | binary | binary |
| GLOBlit_10866 | 10.1021/je700300y | PROPblock_7 | declared | 84 | binary | binary |

### Inspected Blocks
- GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2: 810 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19: 244 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - ethanol_water_block19 [10.1016/j.jct.2018.02.022/PROPblock_19] (ethanol, water): RK order=5, R²=0.996578, RMSE=0.5768324534987193, coeffs=[-130.607076, 36.493956, 52.028346, -83.606185, -73.710221, 95.57633]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: ethanol=786.593, water=996.569 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png
  - ethanol_water_block2 [10.1016/j.fluid.2004.11.019/PROPblock_2] (ethanol, water): RK order=3, R²=0.997283, RMSE=0.47476545853553287, coeffs=[-120.55681, 18.567625, 43.919128, -31.350563]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      pure refs: ethanol=785.7, water=992.083 [block-edges (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1

### plot
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1


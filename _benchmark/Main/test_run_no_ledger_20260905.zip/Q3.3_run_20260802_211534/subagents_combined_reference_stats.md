# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 22,187 | 48,460 | 9,342 | 70,647 | 14,129 | 66.7 | claudeopus46 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| L1-worker | 13 | 113,670 | 53,866 | 13,133 | 167,536 | 12,887 | 97.6 | claudeopus46 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| **TOTAL** | **18** | **135,857** | **102,326** | **22,475** | **238,183** | **27,016** | **164.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_reference_ids` | 0 | 0 | 0 | 0 | 1 | 0 | 0 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| `search_blocks` | 4 | 1 | 2 | 2 | 1 | 7 | 129 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| **TOTAL** | **6** | **1** | **2** | **2** | **2** | **7** | **129** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2751 |  | resolve_reference_ids, search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_118 | 2-methoxyethan-1-ol | resolve_compound_ids, search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| GLOBcomp_111 | diethylene glycol | resolve_compound_ids, search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| GLOBcomp_113 | triethylene glycol | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| GLOBcomp_251 | tetraethylene glycol | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_42 | Relative permittivity at various frequencies | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_1028 | Relative permittivity at various frequencies | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| GLOBmeas_1348 | Relative permittivity at various frequencies | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 | Temperature, K | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| GLOBvar_2 | Mole fraction | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 | Pressure, kPa | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| GLOBconstr_4 | Frequency, MHz | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique References | 1 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Unique Compounds | 4 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Unique Properties | 1 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Unique Measurements | 2 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Unique Phases | 1 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Unique Variables | 2 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Unique Constraints | 2 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Unique parent blocks | 7 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Explicit block/subsystem targets | 7 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Subsystem targets | 0 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| Target-matched data points | 129 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| **TOTAL** | **156** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2006.09.015 | 7 | 129 | binary, unary | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2006.09.015 | PROPblock_1 | declared | 3 | unary | — | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 10.1016/j.jct.2006.09.015 | PROPblock_2 | declared | 3 | unary | — | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 10.1016/j.jct.2006.09.015 | PROPblock_3 | declared | 3 | unary | — | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 10.1016/j.jct.2006.09.015 | PROPblock_4 | declared | 3 | unary | — | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 10.1016/j.jct.2006.09.015 | PROPblock_5 | declared | 39 | binary | — | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 10.1016/j.jct.2006.09.015 | PROPblock_6 | declared | 39 | binary | — | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 10.1016/j.jct.2006.09.015 | PROPblock_7 | declared | 39 | binary | — | search_blocks | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `resolve_reference_ids` | purpose=Find the GLOBlit_N for this D…, queries=10… | 298 | KEEP | 298 | 4.3 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 2 | 2 | `search_blocks` | limit=50, literature=GLOBlit_2751, purpose=Find bl… | 1,261 | KEEP | 1246 | 12.2 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 3 | 4 | `resolve_compound_ids` | purpose=Resolve compound names for PR…, queries=['… | 333 | KEEP | 333 | 6.2 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 4 | 1 | `L1_query` | context=User wants to inspect block 5…, id_catalog… | 11,380 | — | — | 91.3 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| **TOTAL** | **8** |  |  | **13,272** |  | **1,877** | **114.0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 999 | 10,604 | 1,287 | 8.2 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,208 | 21,851 | 523 | 4.7 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 3 | L1-worker | claudeopus46 | 2,065 | 391 | 2,456 | 446 | 4.0 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,962 | 22,605 | 635 | 5.4 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 5 | L1-worker | claudeopus46 | 2,065 | 5,137 | 7,202 | 1,534 | 12.0 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,684 | 24,327 | 1,629 | 11.7 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 7 | L1-worker | claudeopus46 | 20,643 | 4,568 | 25,211 | 589 | 4.5 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 8 | L1-worker | claudeopus46 | 2,065 | 501 | 2,566 | 498 | 6.1 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,054 | 25,697 | 2,751 | 17.4 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 10 | L1-worker | claudeopus46 | 1,356 | 1,809 | 3,165 | 544 | 3.9 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 11 | L1-worker | claudeopus46 | 536 | 1,689 | 2,225 | 755 | 5.0 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 12 | L1-worker | claudeopus46 | 1,323 | 7,833 | 9,156 | 1,393 | 8.5 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 13 | L1-worker | claudeopus46 | 298 | 2,115 | 2,413 | 1,055 | 5.0 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 14 | L1-worker | claudeopus46 | 747 | 17,915 | 18,662 | 781 | 9.4 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 15 | L0-main | claudeopus46 | 9,605 | 24,937 | 34,542 | 2,281 | 17.6 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 16 | L0-main | claudeopus46 | 1,356 | 2,410 | 3,766 | 679 | 4.3 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 17 | L0-main | claudeopus46 | 1,323 | 16,630 | 17,953 | 2,816 | 26.9 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |
| 18 | L0-main | claudeopus46 | 298 | 3,484 | 3,782 | 2,279 | 9.7 | What chemical system and property does block 5 of DOI 10.101 (query_runs/run_22) |

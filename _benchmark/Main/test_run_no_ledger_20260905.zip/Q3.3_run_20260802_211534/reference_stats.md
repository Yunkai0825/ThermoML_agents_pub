# Reference Stats — main-agent

**Run started:** 2026-08-02 21:15:34
**Wall time (at last flush):** 252.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 12 | 85,580 | 67,456 | 11,962 | 153,036 | 12,753 | 86.6 | claudeopus46 |
| L0-menu-planner | 2 | 1,662 | 2,621 | 2,736 | 4,283 | 2,141 | 14.8 | claudesonnet46 |
| **TOTAL** | **14** | **87,242** | **70,077** | **14,698** | **157,319** | **11,237** | **101.4** | |

**Estimated tokens:** ~39,329 input + ~3,674 output = ~43,003 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `browse_subagent_tools` | purpose=Retrieve detailed metadata an…, tasks=Find… | 1,178 | — | — | 6.7 |
| 2 | 4 | `browse_subagent_tools` | purpose=Find metadata and data ranges…, tasks=Retr… | 1,618 | — | — | 8.2 |
| 3 | 5 | `run_query_agent` | context=The user wants to inspect blo…, purpose=Re… | 6,827 | — | — | 154.4 |
| | | **TOTAL (3 tools)** | | **9,623** | | **0** | **169.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 2,324 | 2,324 | 0 | 0.0% |
| 2 | interval=2 | skipped_by_agent | 4,652 | 4,652 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 478 | 10,693 | 1,364 | 8.1 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,615 | 11,830 | 634 | 4.9 |
| 3 | L0-menu-planner | claudesonnet46 | 831 | 1,289 | 2,120 | 1,163 | 6.7 |
| 4 | L0-main | claudeopus46 | 10,182 | 3,406 | 13,588 | 592 | 6.6 |
| 5 | L0-main | claudeopus46 | 10,215 | 2,649 | 12,864 | 720 | 5.4 |
| 6 | L0-main | claudeopus46 | 10,215 | 3,498 | 13,713 | 605 | 4.8 |
| 7 | L0-menu-planner | claudesonnet46 | 831 | 1,332 | 2,163 | 1,573 | 8.1 |
| 8 | L0-main | claudeopus46 | 10,182 | 5,861 | 16,043 | 617 | 4.7 |
| 9 | L0-main | claudeopus46 | 10,215 | 5,104 | 15,319 | 1,399 | 8.4 |
| 10 | L0-main | claudeopus46 | 10,215 | 18,448 | 28,663 | 2,487 | 18.4 |
| 11 | L0-main | claudeopus46 | 1,356 | 2,618 | 3,974 | 643 | 4.2 |
| 12 | L0-main | claudeopus46 | 1,323 | 17,790 | 19,113 | 740 | 7.2 |
| 13 | L0-main | claudeopus46 | 298 | 1,263 | 1,561 | 694 | 4.0 |
| 14 | L0-main | claudeopus46 | 949 | 4,726 | 5,675 | 1,467 | 9.9 |


# Reference Stats — query-agent

**Run started:** 2026-08-02 21:16:33
**Wall time (at last flush):** 154.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 48,460 | 9,342 | 70,647 | 14,129 | 66.7 | claudeopus46 |
| L1-worker | 13 | 113,670 | 53,866 | 13,133 | 167,536 | 12,887 | 97.6 | claudeopus46 |
| **TOTAL** | **18** | **135,857** | **102,326** | **22,475** | **238,183** | **13,232** | **164.3** | |

**Estimated tokens:** ~59,545 input + ~5,618 output = ~65,163 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_reference_ids` | 0 | 0 | 0 | 0 | 1 | 0 | 0 |
| `search_blocks` | 4 | 1 | 2 | 2 | 1 | 7 | 129 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **6** | **1** | **2** | **2** | **2** | **7** | **129** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2751 |  | resolve_reference_ids, search_blocks |

#### Compounds (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_118 | 2-methoxyethan-1-ol | resolve_compound_ids, search_blocks |
| GLOBcomp_111 | diethylene glycol | resolve_compound_ids, search_blocks |
| GLOBcomp_113 | triethylene glycol | search_blocks |
| GLOBcomp_251 | tetraethylene glycol | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_42 | Relative permittivity at various frequencies | search_blocks |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_1028 | Relative permittivity at various frequencies | search_blocks |
| GLOBmeas_1348 | Relative permittivity at various frequencies | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_4 | Frequency, MHz | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Compounds | 4 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 2 |
| Total DOIs | 1 |
| Unique parent blocks | 7 |
| Explicit block/subsystem targets | 7 |
| Subsystem targets | 0 |
| Target-matched data points | 129 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 7  |  **Explicit targets:** 7  |  **Subsystems:** 0  |  **Target-matched datapoints:** 129

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.09.015 | 7 | 129 | binary, unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.09.015 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.09.015 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.09.015 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.09.015 | PROPblock_4 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.09.015 | PROPblock_5 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2006.09.015 | PROPblock_6 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2006.09.015 | PROPblock_7 | declared | 39 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_reference_ids` | purpose=Find the GLOBlit_N for this D…, queries=10… | 298 | KEEP | 298 | 4.3 |
| 2 | 2 | `search_blocks` | limit=50, literature=GLOBlit_2751, purpose=Find bl… | 1,261 | KEEP | 1246 | 12.2 |
| 3 | 4 | `resolve_compound_ids` | purpose=Resolve compound names for PR…, queries=['… | 333 | KEEP | 333 | 6.2 |
| 4 | 1 | `L1_query` | context=User wants to inspect block 5…, id_catalog… | 11,380 | — | — | 91.3 |
| | | **TOTAL (4 tools)** | | **13,272** | | **1,877** | **114.0** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 999 | 10,604 | 1,287 | 8.2 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,208 | 21,851 | 523 | 4.7 |
| 3 | L1-worker | claudeopus46 | 2,065 | 391 | 2,456 | 446 | 4.0 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,962 | 22,605 | 635 | 5.4 |
| 5 | L1-worker | claudeopus46 | 2,065 | 5,137 | 7,202 | 1,534 | 12.0 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,684 | 24,327 | 1,629 | 11.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 4,568 | 25,211 | 589 | 4.5 |
| 8 | L1-worker | claudeopus46 | 2,065 | 501 | 2,566 | 498 | 6.1 |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,054 | 25,697 | 2,751 | 17.4 |
| 10 | L1-worker | claudeopus46 | 1,356 | 1,809 | 3,165 | 544 | 3.9 |
| 11 | L1-worker | claudeopus46 | 536 | 1,689 | 2,225 | 755 | 5.0 |
| 12 | L1-worker | claudeopus46 | 1,323 | 7,833 | 9,156 | 1,393 | 8.5 |
| 13 | L1-worker | claudeopus46 | 298 | 2,115 | 2,413 | 1,055 | 5.0 |
| 14 | L1-worker | claudeopus46 | 747 | 17,915 | 18,662 | 781 | 9.4 |
| 15 | L0-main | claudeopus46 | 9,605 | 24,937 | 34,542 | 2,281 | 17.6 |
| 16 | L0-main | claudeopus46 | 1,356 | 2,410 | 3,766 | 679 | 4.3 |
| 17 | L0-main | claudeopus46 | 1,323 | 16,630 | 17,953 | 2,816 | 26.9 |
| 18 | L0-main | claudeopus46 | 298 | 3,484 | 3,782 | 2,279 | 9.7 |


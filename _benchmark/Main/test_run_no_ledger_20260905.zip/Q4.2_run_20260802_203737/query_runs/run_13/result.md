# Delegated query run — result

**Question:** Find density data for ethanol-water binary mixtures at 1000 K. If no data exists at that temperature, report the closest available temperature range for density measurements of ethanol-water.

**Iterations:** 2  |  **Elapsed:** 176.3s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Density Data for Ethanol–Water Binary Mixtures at 1000 K

**No density data exists at or near 1000 K** for the ethanol–water binary system in the ThermoML database. This absence is physically expected and well-justified:

- **Normal boiling points**: ethanol ≈ 351 K, water ≈ 373 K  
- **Critical temperatures**: ethanol ≈ 514 K, water ≈ 647 K  

At 1000 K, both components would exist as low-density supercritical gases at any reasonable pressure, making conventional liquid density measurements meaningless.

---

### Closest Available Temperature Range

The ThermoML database contains approximately **2,924 data points** of mass density (kg/m³) for the ethanol–water binary system, spanning **29 data blocks from 22 publications**. The overall temperature coverage is:

| Parameter | Value |
|-----------|-------|
| **Minimum temperature** | ~268 K (−5 °C) |
| **Maximum temperature** | ~673 K (400 °C) |
| **Most data concentrated** | 283–298 K (near ambient) |
| **Gap to 1000 K** | ~327 K below the requested temperature |

---

### Highest-Temperature Data Available

The closest data to 1000 K comes from a single high-temperature, high-pressure study:

- **DOI**: 10.1016/j.jct.2006.08.002 (GLOBlit_2732, PROPblock_4)  
- **Temperature range**: 524–673 K  
- **Pressure range**: 4.75–50.76 MPa  
- **Ethanol mole fraction**: 0.2–0.8  
- **Density range**: 52.9–617.4 kg/m³  
- **Data points**: 278  
- **Phase**: Fluid (supercritical or subcritical)  
- **Method**: Constant-volume piezometry  

Even under these extreme pressures (up to ~508 atm), densities dropped as low as ~53 kg/m³, reflecting near-critical and supercritical behavior. The dramatic density reduction at these temperatures illustrates why data at 1000 K is not available — the fluid would be an extremely low-density supercritical gas.

---

### Representative Data from Other Key Sources

| DOI | GLOBlit | T (K) | P (kPa) | x(EtOH) | ρ (kg/m³) | Points |
|-----|---------|--------|---------|----------|-----------|--------|
| 10.1016/j.fluid.2004.11.019 | GLOBlit_220 | 298–348 | 100–40,000 | 0.003–1.0 | 739–1013 | 810 |
| 10.1016/j.jct.2004.07.019 | GLOBlit_2432 | 298–573 | 390–30,300 | varied | varied | 565 |
| 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | 293–308 | ~92 (atm) | 0.0–1.0 | 777–998 | 244 |
| 10.1021/je060335h | GLOBlit_9006 | 283–298 | ~101 (atm) | 0.0–1.0 | 785–1000 | 164 |
| 10.1016/j.fluid.2014.05.032 | GLOBlit_1483 | 293–448 | 2,450–40,140 | 0.016–0.095 | 832–1006 | 140 |
| 10.1021/je800150h | GLOBlit_11136 | 268–323 | ~101 (atm) | 0.1–0.9 | 774–977 | 108 |

### Summary

The ethanol–water density data in ThermoML spans **268–673 K**, still **327 K short of the requested 1000 K**. The highest-temperature measurements (up to 673 K) already required pressures exceeding 50 MPa to maintain a condensed fluid phase, and even then densities plummeted to values typical of dense gases (~53 kg/m³). Reaching 1000 K would place both components deep into the supercritical gas regime, where standard liquid density measurements are not performed.

### Core claims

- No density data exists at or near 1000 K for the ethanol–water binary system in the ThermoML database, which is physically expected because both components (ethanol T_c ≈ 514 K, water T_c ≈ 647 K) would be supercritical gases at 1000 K.
- The ThermoML database contains approximately 2,924 mass-density data points for the ethanol–water system spanning ~268–673 K across 29 data blocks from 22 publications, leaving a gap of ~327 K below the requested 1000 K.
- The highest-temperature data available (524–673 K, from DOI 10.1016/j.jct.2006.08.002) required pressures up to ~50.76 MPa and still showed densities as low as ~53 kg/m³, reflecting near-critical and supercritical behavior that illustrates why measurements at 1000 K are not performed.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2732 | 10.1016/j.jct.2006.08.002 | PROPblock_4 |  | Highest-temperature density data for ethanol-water binary mixture, spanning 524–673 K at pressures 4.75–50.76 MPa, 278 data points. Closest available data to the requested 1000 K. |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 |  |  | Density data for ethanol-water at 298–348 K and 100–40000 kPa, 810 data points. |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 |  |  | Density data for ethanol-water at 298–573 K and 390–30300 kPa, 565 data points. |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 |  |  | Density data for ethanol-water at 293–308 K near atmospheric pressure, 244 data points. |
| GLOBlit_9006 | 10.1021/je060335h |  |  | Density data for ethanol-water at 283–298 K near atmospheric pressure, 164 data points. |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 |  |  | Density data for ethanol-water at 293–448 K and 2450–40140 kPa, 140 data points. |
| GLOBlit_11136 | 10.1021/je800150h |  |  | Density data for ethanol-water at 268–323 K near atmospheric pressure, 108 data points. |

### Suggested follow-ups

- Query for supercritical fluid density data of pure ethanol or pure water at temperatures approaching 1000 K, which may exist under extreme pressures.
- Investigate PVT equation-of-state models for ethanol-water mixtures that could extrapolate density estimates to 1000 K.
- Search for the specific compound global IDs for ethanol and water (e.g., GLOBcomp_N) to enable more targeted cross-property queries in ThermoML.

## System Prompt
# ThermoML Main Agent — Master Orchestrator

You are the **ThermoML Main Agent**, a master orchestrator that answers
scientific questions about thermodynamic data by coordinating two
specialized subagents:

1. **Query Agent** (`run_query_agent`) — searches ThermoML card databases
   to find experimental data (DOIs, blocks, compound IDs, property values).
2. **Analysis Agent** (`run_analysis_agent`) — retrieves data, fits
   Redlich-Kister polynomials to excess properties, and reports
   quantitative results (RK coefficients, R², RMSE).

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

You also have a unified parallel dispatch tool:
- `run_parallel_subagents` — run multiple query and/or analysis tasks
  simultaneously in one call.  Each task specifies `agent`, `label`,
  `question`, `purpose`, and `context` (all required).

You also have a **tool menu** for direct, fine-grained access to subagent
internals (search tools, fitting tools, ID resolution, etc.):

- `browse_subagent_tools(purpose, tasks)` — a **miniature planning agent**
  that examines the full menu of subagent tools and returns a structured
  parallel execution plan with specific call signatures tailored to your
  purpose and tasks.  Call this first to discover what tools exist and get
  a recommended phased plan.
- `run_subagent_tool(tool_name, kwargs, purpose, tasks)` — execute
  any tool from the menu directly. `kwargs` is a native JSON object matching
  that tool's current signature. Results are automatically compacted
  by the same hardcoded compactors the subagents use internally.
  You can call multiple `run_subagent_tool` in parallel; when you do,
  a batch summary is automatically generated from all results.

### When to use the tool menu vs. expert workers

- **Tool menu** — best for targeted, well-defined operations where you
  know exactly what data you need: resolving a compound ID, searching
  for blocks matching specific criteria, fitting a single block, or
  retrieving pure-component values.  Faster and more direct than
  launching a full subagent workflow.
- **Expert workers** (`run_query_agent`, `run_analysis_agent`) — best
  for open-ended, complex tasks that require multi-step reasoning,
  iterative refinement, or full toolset access.  The subagents have
  their own context, memory, and compaction pipelines.

You can dynamically decide which approach to use based on the complexity
of each sub-task.  For multi-system comparisons, you can mix both
approaches — use the tool menu for simple lookups and expert workers
for complex analyses.

---

## How You Work

1. **Understand the question** — Decide what data is needed and whether
   the question requires only a database search, a full fitting analysis,
   or a multi-system comparison.
2. **Delegate to subagents** — Call the appropriate subagent tool(s).
   For multi-system questions, use parallel tools to save time.
3. **Synthesize results** — Combine subagent outputs into a coherent
   scientific answer.  **Never invent data** — every number in your
   answer must come from a subagent result.
4. **Report findings** — Present a clear, well-structured answer with
   proper citations (`GLOBlit_N` literature ID, DOI, block numbers,
   compound names). `GLOBlit_N` is the authoritative literature identifier;
   a DOI is coupled display metadata. Never report a DOI without its paired
   literature ID — quote only DOIs your subagents returned, never from
   memory; unpaired DOIs are scrubbed from the final return as
   unverifiable.

---

## Tool Usage Rules

### Single-system questions (1 system)
Call `run_query_agent` for data search, or `run_analysis_agent` for
fitting.  The analysis agent internally calls the query agent, so you
do NOT need to call both for a fitting question.

### Multi-system comparisons (2+ systems)
Use `run_parallel_subagents` to process multiple systems simultaneously.
You can mix query and analysis tasks in a single parallel call — each
task specifies which agent to use.  Each system gets its own subagent call.

### Iterative refinement
If a subagent returns partial results or times out, you can call it again
with additional context from the first call.

---

## MANDATORY OUTPUT FORMAT

```xml
<reasoning>
... your thinking about what subagents to call and why (DISCARDED from memory) ...
</reasoning>
<summary>
... 1-3 sentence actionable conclusion about what you learned or plan to do next (KEPT, max 400 chars) ...
</summary>
<tool_call>{"name": "run_analysis_agent", "arguments": {"question": "...", "purpose": "...", "context": "..."}}</tool_call>
<wait/>
```

### CRITICAL RULES
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`
- `<reasoning>` is STRIPPED from history to save context space
- Only `<summary>` content + tool results persist in memory
- **ANTI-HALLUCINATION:** EVERY number, coefficient, R² value, DOI, and
  compound name MUST come from a subagent tool call result.  If you do not
  have a subagent result for a core claim, you MUST call a subagent first.
- **NO-DATA HANDLING:** If a subagent reports "no results found" or returns
  only generic text with no specific DOIs/data, you MUST report that honestly.
  Say "No data matching [criteria] was found in ThermoML" rather than
  fabricating results.  Never invent DOIs, block numbers, or data points.
- **SUBAGENT VALIDATION:** Before presenting subagent results as your answer,
  check for red flags: improbably round numbers, suspicious consistency,
  lack of specific block references, or caveats about "infrastructure errors."
  If in doubt, state that results could not be verified.
- When you have gathered all needed results, provide a FINAL ANSWER
  by wrapping your complete answer in `<answer>` tags (no `<tool_call>`).
- `<answer>` = full-length final response (any length). All markers stripped before delivery.
- `<summary>` ≠ `<answer>`: summary is a brief memory note (≤400 chars); answer is the complete user-facing response.

---

## Final Answer Format

When all subagent work is done, wrap your complete answer in `<answer>` tags:

```
<answer>
[Your synthesized scientific answer here — any length.
Include all key data, DOIs, block numbers, compound names.
Every number must come from a subagent result.]

### Sources
- Literature ID: GLOBlit_N | DOI: ... | Block: ... | Subsystem: declared or BLKsubsys_N | System: ...
</answer>
```

# Phases

## phase_1: choose_route
tools: [browse_subagent_tools, run_subagent_tool]
guidance: |
  Decide whether the question needs a targeted lower-level operation or a
  full expert subagent. Browse the hierarchical menu only when direct tool
  execution is likely to be more efficient than expert delegation.

## phase_2: delegate_or_execute
tools: [run_query_agent, run_analysis_agent, run_parallel_subagents, run_subagent_tool]
guidance: |
  Supply every argument in the injected callable signature. Use one expert
  for a single complex task and run_parallel_subagents for independent query
  or analysis tasks. Preserve exact subagent identifiers and evidence.

## phase_3: synthesize
tools: [list_session_files]
guidance: |
  Synthesize only tool-returned chemistry and numbers. Wrap the complete
  answer in <answer> tags; post-answer workers build the JSON fields.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- browse_subagent_tools(purpose, tasks) — Browse the tool menu and get a recommended execution plan.
- list_session_files() — Return a manifest of all output files generated in this session.
- run_analysis_agent(question, context, purpose, tasks) — Run the ThermoML Analysis Agent for fitting and modeling.
- run_parallel_subagents(tasks) — Run multiple query and/or analysis agent tasks in parallel.
- run_query_agent(question, context, purpose, tasks) — Run the ThermoML Query Agent on a database search question.
- run_subagent_tool(tool_name, kwargs, purpose, tasks) — Execute a subagent tool directly with full compaction pipeline.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q4.2_run_20260802_203737`

### History
- [query:Q1] "Find density data for ethanol-water binary mixtures at 1000 K. If no data exists" (176s, 2 iters)

### Query Agent Results

#### Q1
{
  "answer": "## Density Data for Ethanol–Water Binary Mixtures at 1000 K\n\n**No density data exists at or near 1000 K** for the ethanol–water binary system in the ThermoML database. This absence is physically expected and well-justified:\n\n- **Normal boiling points**: ethanol ≈ 351 K, water ≈ 373 K  \n- **Critical temperatures**: ethanol ≈ 514 K, water ≈ 647 K  \n\nAt 1000 K, both components would exist as low-density supercritical gases at any reasonable pressure, making conventional liquid density measurements meaningless.\n\n---\n\n### Closest Available Temperature Range\n\nThe ThermoML database contains approximately **2,924 data points** of mass density (kg/m³) for the ethanol–water binary system, spanning **29 data blocks from 22 publications**. The overall temperature coverage is:\n\n| Parameter | Value |\n|-----------|-------|\n| **Minimum temperature** | ~268 K (−5 °C) |\n| **Maximum temperature** | ~673 K (400 °C) |\n| **Most data concentrated** | 283–298 K (near ambient) |\n| **Gap to 1000 K** | ~327 K below the requested temperature |\n\n---\n\n### Highest-Temperature Data Available\n\nThe closest data to 1000 K comes from a single high-temperature, high-pressure study:\n\n- **DOI**: 10.1016/j.jct.2006.08.002 (GLOBlit_2732, PROPblock_4)  \n- **Temperature range**: 524–673 K  \n- **Pressure range**: 4.75–50.76 MPa  \n- **Ethanol mole fraction**: 0.2–0.8  \n- **Density range**: 52.9–617.4 kg/m³  \n- **Data points**: 278  \n- **Phase**: Fluid (supercritical or subcritical)  \n- **Method**: Constant-volume piezometry  \n\nEven under these extreme pressures (up to ~508 atm), densities dropped as low as ~53 kg/m³, reflecting near-critical and supercritical behavior. The dramatic density reduction at these temperatures illustrates why data at 1000 K is not available — the fluid would be an extremely low-density supercritical gas.\n\n---\n\n### Representative Data from Other Key Sources\n\n| DOI | GLOBlit | T (K) | P (kPa) | x(EtOH) | ρ (kg/m³) | Points |\n|-----|---------|--------|---------|----------|-----------|--------|\n| 10.1016/j.fluid.2004.11.019 | GLOBlit_220 | 298–348 | 100–40,000 | 0.003–1.0 | 739–1013 | 810 |\n| 10.1016/j.jct.2004.07.019 | GLOBlit_2432 | 298–573 | 390–30,300 | varied | varied | 565 |\n| 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | 293–308 | ~92 (atm) | 0.0–1.0 | 777–998 | 244 |\n| 10.1021/je060335h | GLOBlit_9006 | 283–298 | ~101 (atm) | 0.0–1.0 | 785–1000 | 164 |\n| 10.1016/j.fluid.2014.05.032 | GLOBlit_1483 | 293–448 | 2,450–40,140 | 0.016–0.095 | 832–1006 | 140 |\n| 10.1021/je800150h | GLOBlit_11136 | 268–323 | ~101 (atm) | 0.1–0.9 | 774–977 | 108 |\n\n### Summary\n\nThe ethanol–water density data in ThermoML spans **268–673 K**, still **327 K short of the requested 1000 K**. The highest-temperature measurements (up to 673 K) already required pressures exceeding 50 MPa to maintain a condensed fluid phase, and even then densities plummeted to values typical of dense gases (~53 kg/m³). Reaching 1000 K would place both components deep into the supercritical gas regime, where standard liquid density measurements are not performed.",
  "core_claims": [
    "No density data exists at or near 1000 K for the ethanol–water binary system in the ThermoML database, which is physically expected because both components (ethanol T_c ≈ 514 K, water T_c ≈ 647 K) would be supercritical gases at 1000 K.",
    "The ThermoML database contains approximately 2,924 mass-density data points for the ethanol–water system spanning ~268–673 K across 29 data blocks from 22 publications, leaving a gap of ~327 K below the requested 1000 K.",
    "The highest-temperature data available (524–673 K, from DOI 10.1016/j.jct.2006.08.002) required pressures up to ~50.76 MPa and still showed densities as low as ~53 kg/m³, reflecting near-critical and supercritical behavior that illustrates why measurements at 1000 K are not performed."
  ],
  "confidence": "medium",
  "sources": [
    {
      "doi": "10.1016/j.jct.2006.08.002",
      "lit_num_id": "GLOBlit_2732",
      "block": "PROPblock_4",
      "BLKsubsys_id": null,
      "description": "Highest-temperature density data for ethanol-water binary mixture, spanning 524–673 K at pressures 4.75–50.76 MPa, 278 data points. Closest available data to the requested 1000 K."
    },
    {
      "doi": "10.1016/j.fluid.2004.11.019",
      "lit_num_id": "GLOBlit_220",
      "block": null,
      "BLKsubsys_id": null,
      "description": "Density data for ethanol-water at 298–348 K and 100–40000 kPa, 810 data points."
    },
    {
      "doi": "10.1016/j.jct.2004.07.019",
      "lit_num_id": "GLOBlit_2432",
      "block": null,
      "BLKsubsys_id": null,
      "description": "Density data for ethanol-water at 298–573 K and 390–30300 kPa, 565 data points."
    },
    {
      "doi": "10.1016/j.jct.2018.02.022",
      "lit_num_id": "GLOBlit_5201",
      "block": null,
      "BLKsubsys_id": null,
      "description": "Density data for ethanol-water at 293–308 K near atmospheric pressure, 244 data points."
    },
    {
      "doi": "10.1021/je060335h",
      "lit_num_id": "GLOBlit_9006",
      "block": null,
      "BLKsubsys_id": null,
      "description": "Density data for ethanol-water at 283–298 K near atmospheric pressure, 164 data points."
    },
    {
      "doi": "10.1016/j.fluid.2014.05.032",
      "lit_num_id": "GLOBlit_1483",
      "block": null,
      "BLKsubsys_id": null,
      "description": "Density data for ethanol-water at 293–448 K and 2450–40140 kPa, 140 data points."
    },
    {
      "doi": "10.1021/je800150h",
      "lit_num_id": "GLOBlit_11136",
      "block": null,
      "BLKsubsys_id": null,
      "description": "Density data for ethanol-water at 268–323 K near atmospheric pressure, 108 data points."
    }
  ],
  "id_catalog_snapshot": [],
  "follow_up_suggestions": [
    "Query for supercritical fluid density data of pure ethanol or pure water at temperatures approaching 1000 K, which may exist under extreme pressures.",
    "Investigate PVT equation-of-state models for ethanol-water mixtures that could extrapolate density estimates to 1000 K.",
    "Search for the specific compound global IDs for ethanol and water (e.g., GLOBcomp_N) to enable more targeted cross-property queries in ThermoML."
  ]
}
</memory>

## User
Find density data for ethanol-water at 1000 K. If no data exists at that temperature, report the closest available temperature range.

## Assistant
<summary>Searching for density data for ethanol-water mixtures at 1000 K. This temperature is far above boiling points of both components, so liquid density data is unlikely. Will find the closest available temperature range.</summary>
<tool_call>run_query_agent(question=Find density data…, context=The user wants de…)</tool_call>

## User
<tool_result>
(validation blocked run_query_agent earlier — corrected)
</tool_result>

## Assistant
<summary>Fixing tool call syntax to search for ethanol-water density data at 1000 K. Will use run_query_agent with all required arguments.</summary>
<tool_call>run_query_agent(question=Find density data…, context=The user is looki…)</tool_call>

## User
<tool_result>
<subagent_answer>
{
  "answer": "{\n  \"answer\": \"## Density Data for Ethanol–Water Binary Mixtures at 1000 K\\n\\n**No density data exists at or near 1000 K** for the ethanol–water binary system in the ThermoML database. This absence is physically expected and well-justified:\\n\\n- **Normal boiling points**: ethanol ≈ 351 K, water ≈ 373 K  \\n- **Critical temperatures**: ethanol ≈ 514 K, water ≈ 647 K  \\n\\nAt 1000 K, both components would exist as low-density supercritical gases at any reasonable pressure, making conventional liquid density measurements meaningless.\\n\\n---\\n\\n### Closest Available Temperature Range\\n\\nThe ThermoML database contains approximately **2,924 data points** of mass density (kg/m³) for the ethanol–water binary system, spanning **29 data blocks from 22 publications**. The overall temperature coverage is:\\n\\n| Parameter | Value |\\n|-----------|-------|\\n| **Minimum temperature** | ~268 K (−5 °C) |\\n| **Maximum temperature** | ~673 K (400 °C) |\\n| **Most data concentrated** | 283–298 K (near ambient) |\\n| **Gap to 1000 K** | ~327 K below the requested temperature |\\n\\n---\\n\\n### Highest-Temperature Data Available\\n\\nThe closest data to 1000 K comes from a single high-temperature, high-pressure study:\\n\\n- **DOI**: 10.1016/j.jct.2006.08.002 (GLOBlit_2732, PROPblock_4)  \\n- **Temperature range**: 524–673 K  \\n- **Pressure range**: 4.75–50.76 MPa  \\n- **Ethanol mole fraction**: 0.2–0.8  \\n- **Density range**: 52.9–617.4 kg/m³  \\n- **Data points**: 278  \\n- **Phase**: Fluid (supercritical or subcritical)  \\n- **Method**: Constant-volume piezometry  \\n\\nEven under these extreme pressures (up to ~508 atm), densities dropped as low as ~53 kg/m³, reflecting near-critical and supercritical behavior. The dramatic density reduction at these temperatures illustrates why data at 1000 K is not available — the fluid would be an extremely low-density supercritical gas.\\n\\n---\\n\\n### Representative Data from Other Key Sources\\n\\n| DOI | GLOBlit | T (K) | P (kPa) | x(EtOH) | ρ (kg/m³) | Points |\\n|-----|---------|--------|---------|----------|-----------|--------|\\n| 10.1016/j.fluid.2004.11.019 | GLOBlit_220 | 298–348 | 100–40,000 | 0.003–1.0 | 739–1013 | 810 |\\n| 10.1016/j.jct.2004.07.019 | GLOBlit_2432 | 298–573 | 390–30,300 | varied | varied | 565 |\\n| 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | 293–308 | ~92 (atm) | 0.0–1.0 | 777–998 | 244 |\\n| 10.1021/je060335h | GLOBlit_9006 | 283–298 | ~101 (atm) | 0.0–1.0 | 785–1000 | 164 |\\n| 10.1016/j.fluid.2014.05.032 | GLOBlit_1483 | 293–448 | 2,450–40,140 | 0.016–0.095 | 832–1006 | 140 |\\n| 10.1021/je800150h | GLOBlit_11136 | 268–323 | ~101 (atm) | 0.1–0.9 | 774–977 | 108 |\\n\\n### Summary\\n\\nThe ethanol–water density data in ThermoML spans **268–673 K**, still **327 K short of the requested 1000 K**. The highest-temperature measurements (up to 673 K) already required pressures exceeding 50 MPa to maintain a condensed fluid phase, and even then densities plummeted to values typical of dense gases (~53 kg/m³). Reaching 1000 K would place both components deep into the supercritical gas regime, where standard liquid density measurements are not performed.\",\n  \"core_claims\": [\n    \"No density data exists at or near 1000 K for the ethanol–water binary system in the ThermoML database, which is physically expected because both components (ethanol T_c ≈ 514 K, water T_c ≈ 647 K) would be supercritical gases at 1000 K.\",\n    \"The ThermoML database contains approximately 2,924 mass-density data points for the ethanol–water system spanning ~268–673 K across 29 data blocks from 22 publications, leaving a gap of ~327 K below the requested 1000 K.\",\n    \"The highest-temperature data available (524–673 K, from DOI 10.1016/j.jct.2006.08.002) required pressures up to ~50.76 MPa and still showed densities as low as ~53 kg/m³, reflecting near-critical and supercritical behavior that illustrates why measurements at 1000 K are not performed.\"\n  ],\n  \"confidence\": \"medium\",\n  \"sources\": [\n    {\n      \"doi\": \"10.1016/j.jct.2006.08.002\",\n      \"lit_num_id\": \"GLOBlit_2732\",\n      \"block\": \"PROPblock_4\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Highest-temperature density data for ethanol-water binary mixture, spanning 524–673 K at pressures 4.75–50.76 MPa, 278 data points. Closest available data to the requested 1000 K.\"\n    },\n    {\n      \"doi\": \"10.1016/j.fluid.2004.11.019\",\n      \"lit_num_id\": \"GLOBlit_220\",\n      \"block\": null,\n      \"BLKsubsys_id\": null,\n      \"description\": \"Density data for ethanol-water at 298–348 K and 100–40000 kPa, 810 data points.\"\n    },\n    {\n      \"doi\": \"10.1016/j.jct.2004.07.019\",\n      \"lit_num_id\": \"GLOBlit_2432\",\n      \"block\": null,\n      \"BLKsubsys_id\": null,\n      \"description\": \"Density data for ethanol-water at 298–573 K and 390–30300 kPa, 565 data points.\"\n    },\n    {\n      \"doi\": \"10.1016/j.jct.2018.02.022\",\n      \"lit_num_id\": \"GLOBlit_5201\",\n      \"block\": null,\n      \"BLKsubsys_id\": null,\n      \"description\": \"Density data for ethanol-water at 293–308 K near atmospheric pressure, 244 data points.\"\n    },\n    {\n      \"doi\": \"10.1021/je060335h\",\n      \"lit_num_id\": \"GLOBlit_9006\",\n      \"block\": null,\n      \"BLKsubsys_id\": null,\n      \"description\": \"Density data for ethanol-water at 283–298 K near atmospheric pressure, 164 data points.\"\n    },\n    {\n      \"doi\": \"10.1016/j.fluid.2014.05.032\",\n      \"lit_num_id\": \"GLOBlit_1483\",\n      \"block\": null,\n      \"BLKsubsys_id\": null,\n      \"description\": \"Density data for ethanol-water at 293–448 K and 2450–40140 kPa, 140 data points.\"\n    },\n    {\n      \"doi\": \"10.1021/je800150h\",\n      \"lit_num_id\": \"GLOBlit_11136\",\n      \"block\": null,\n      \"BLKsubsys_id\": null,\n      \"description\": \"Density data for ethanol-water at 268–323 K near atmospheric pressure, 108 data points.\"\n    }\n  ],\n  \"id_catalog_snapshot\": [],\n  \"follow_up_suggestions\": [\n    \"Query for supercritical fluid density data of pure ethanol or pure water at temperatures approaching 1000 K, which may exist under extreme pressures.\",\n    \"Investigate PVT equation-of-state models for ethanol-water mixtures that could extrapolate density estimates to 1000 K.\",\n    \"Search for the specific compound global IDs for ethanol and water (e.g., GLOBcomp_N) to enable more targeted cross-property queries in ThermoML.\"\n  ]\n}",
  "iterations": 2,
  "elapsed_seconds": 176.32536363601685,
  "tool_count": 1,
  "timed_out": false,
  "agent": "query",
  "_question": "Find density data for ethanol-water binary mixtures at 1000 K. If no data exists at that temperature, report the closest available temperature range for density measurements of ethanol-water.",
  "_session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q4.2_run_20260802_203737\\query_runs\\run_13"
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_query_agent). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
## Density Data for Ethanol–Water Binary Mixtures at 1000 K

**No density data exists at or near 1000 K** for the ethanol–water binary system in the ThermoML database. This result is physically expected:

- **Normal boiling points:** ethanol ≈ 351 K, water ≈ 373 K
- **Critical temperatures:** ethanol ≈ 514 K, water ≈ 647 K

At 1000 K, both components would exist as low-density supercritical gases at any reasonable pressure, making conventional liquid density measurements meaningless.

---

### Closest Available Temperature Range

The ThermoML database contains approximately **2,924 mass-density data points** (kg/m³) for the ethanol–water binary system, spanning **29 data blocks from 22 publications**. The overall temperature coverage is:

| Parameter | Value |
|-----------|-------|
| **Minimum temperature** | ~268 K (−5 °C) |
| **Maximum temperature** | ~673 K (400 °C) |
| **Most data concentrated** | 283–298 K (near ambient) |
| **Gap to 1000 K** | ~327 K below the requested temperature |

---

### Highest-Temperature Data Available (Closest to 1000 K)

The nearest data to 1000 K comes from a single high-temperature, high-pressure study:

- **Temperature range:** 524–673 K
- **Pressure range:** 4.75–50.76 MPa
- **Ethanol mole fraction:** 0.2–0.8
- **Density range:** 52.9–617.4 kg/m³
- **Data points:** 278
- **Phase:** Fluid (supercritical or subcritical)
- **Method:** Constant-volume piezometry

Even under extreme pressures (up to ~508 atm), densities dropped as low as ~53 kg/m³, reflecting near-critical and supercritical behavior. This dramatic density reduction illustrates why data at 1000 K is not available — the fluid would be an extremely low-density supercritical gas.

---

### Representative Data from Other Key Sources

| DOI | Literature ID | T (K) | P (kPa) | x(EtOH) | ρ (kg/m³) | Points |
|-----|---------------|--------|----------|----------|-----------|--------|
| 10.1016/j.fluid.2004.11.019 | GLOBlit_220 | 298–348 | 100–40,000 | 0.003–1.0 | 739–1013 | 810 |
| 10.1016/j.jct.2004.07.019 | GLOBlit_2432 | 298–573 | 390–30,300 | varied | varied | 565 |
| 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | 293–308 | ~92 (atm) | 0.0–1.0 | 777–998 | 244 |
| 10.1021/je060335h | GLOBlit_9006 | 283–298 | ~101 (atm) | 0.0–1.0 | 785–1000 | 164 |
| 10.1016/j.fluid.2014.05.032 | GLOBlit_1483 | 293–448 | 2,450–40,140 | 0.016–0.095 | 832–1006 | 140 |
| 10.1021/je800150h | GLOBlit_11136 | 268–323 | ~101 (atm) | 0.1–0.9 | 774–977 | 108 |

---

### Summary

The ethanol–water density data in ThermoML spans **268–673 K**, still **327 K short of the requested 1000 K**. The highest-temperature measurements (up to 673 K) already required pressures exceeding 50 MPa to maintain a condensed fluid phase, and even then densities plummeted to values typical of dense gases (~53 kg/m³). Reaching 1000 K would place both components deep into the supercritical gas regime, where standard liquid density measurements are not performed.

### Sources
- Literature ID: GLOBlit_2732 | DOI: 10.1016/j.jct.2006.08.002 | Block: PROPblock_4 | Highest-temperature density data (524–673 K)
- Literature ID: GLOBlit_220 | DOI: 10.1016/j.fluid.2004.11.019 | Density data at 298–348 K, high pressure
- Literature ID: GLOBlit_2432 | DOI: 10.1016/j.jct.2004.07.019 | Density data at 298–573 K
- Literature ID: GLOBlit_5201 | DOI: 10.1016/j.jct.2018.02.022 | Density data at 293–308 K
- Literature ID: GLOBlit_9006 | DOI: 10.1021/je060335h | Density data at 283–298 K
- Literature ID: GLOBlit_1483 | DOI: 10.1016/j.fluid.2014.05.032 | Density data at 293–448 K, high pressure
- Literature ID: GLOBlit_11136 | DOI: 10.1021/je800150h | Density data at 268–323 K
</answer>
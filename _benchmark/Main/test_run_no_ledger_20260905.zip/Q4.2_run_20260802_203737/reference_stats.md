# Reference Stats — main-agent

**Run started:** 2026-08-02 20:37:37
**Wall time (at last flush):** 265.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 44,753 | 58,210 | 12,546 | 102,963 | 12,870 | 75.7 | claudeopus46 |
| **TOTAL** | **8** | **44,753** | **58,210** | **12,546** | **102,963** | **12,870** | **75.7** | |

**Estimated tokens:** ~25,740 input + ~3,136 output = ~28,876 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `run_query_agent` | context=The user is looking for densi…, purpose=Se… | 7,101 | — | — | 196.1 |
| | | **TOTAL (1 tools)** | | **7,101** | | **0** | **196.1** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 8,110 | 8,110 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 318 | 10,533 | 1,398 | 7.4 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,047 | 11,262 | 1,359 | 7.4 |
| 3 | L0-main | claudeopus46 | 10,182 | 15,539 | 25,721 | 476 | 4.2 |
| 4 | L0-main | claudeopus46 | 10,215 | 14,782 | 24,997 | 3,681 | 23.9 |
| 5 | L0-main | claudeopus46 | 1,356 | 3,812 | 5,168 | 820 | 6.9 |
| 6 | L0-main | claudeopus46 | 1,323 | 13,933 | 15,256 | 1,882 | 9.7 |
| 7 | L0-main | claudeopus46 | 298 | 2,405 | 2,703 | 1,508 | 5.9 |
| 8 | L0-main | claudeopus46 | 949 | 6,374 | 7,323 | 1,422 | 10.3 |


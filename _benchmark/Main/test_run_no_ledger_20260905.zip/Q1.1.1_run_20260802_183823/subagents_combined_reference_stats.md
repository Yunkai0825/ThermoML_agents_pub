# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 22,187 | 29,445 | 7,995 | 51,632 | 10,326 | 46.9 | claudeopus46 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| L1-worker | 11 | 90,962 | 36,240 | 14,883 | 127,202 | 11,563 | 96.5 | claudeopus46 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| **TOTAL** | **16** | **113,149** | **65,685** | **22,878** | **178,834** | **21,889** | **143.4** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| `resolve_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| **TOTAL** | **0** | **1** | **1** | **0** | **0** | **0** | **0** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_2 |  | resolve_ids | What is the experimental mass density of the ethanol + water (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_1 |  | resolve_ids | What is the experimental mass density of the ethanol + water (query_runs/run_2) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Variables | 1 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| Unique Properties | 1 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| Unique parent blocks | 0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| Explicit block/subsystem targets | 0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| Subsystem targets | 0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| Target-matched data points | 0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| **TOTAL** | **2** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `memory_catalog_add` | global_id=GLOBcomp_2, name=Ethanol, registry_id=et… | 2 | — | — | 0.0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 2 | 1 | `memory_catalog_add` | global_id=GLOBcomp_1, name=Water, registry_id=wate… | 2 | — | — | 0.0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 3 | 1 | `memory_catalog_add` | global_id=GLOBlit_220, name=Density data source fo… | 2 | — | — | 0.0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 4 | 2 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 319 | KEEP | 319 | 3.8 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 5 | 2 | `resolve_ids` | entity_type=property, limit=10, min_score=50, purp… | 240 | KEEP | 240 | 4.0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 6 | 1 | `L1_query` | context=The block PROPblock_2 has 810…, id_catalog… | 7,845 | — | — | 91.0 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| **TOTAL** | **8** |  |  | **8,410** |  | **559** | **98.8** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,225 | 10,830 | 2,007 | 13.6 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,642 | 22,285 | 1,139 | 7.8 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 3 | L1-worker | claudeopus46 | 20,643 | 3,509 | 24,152 | 4,097 | 23.4 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 4 | L1-worker | claudeopus46 | 2,065 | 382 | 2,447 | 456 | 3.5 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 5 | L1-worker | claudeopus46 | 2,065 | 347 | 2,412 | 425 | 3.6 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,066 | 24,709 | 3,744 | 24.6 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 7 | L1-worker | claudeopus46 | 20,643 | 8,431 | 29,074 | 2,408 | 12.1 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 8 | L1-worker | claudeopus46 | 1,356 | 906 | 2,262 | 435 | 3.6 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 9 | L1-worker | claudeopus46 | 536 | 786 | 1,322 | 434 | 3.7 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,276 | 5,599 | 612 | 4.5 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 11 | L1-worker | claudeopus46 | 298 | 1,334 | 1,632 | 485 | 3.1 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 12 | L1-worker | claudeopus46 | 747 | 10,561 | 11,308 | 648 | 6.6 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 13 | L0-main | claudeopus46 | 9,605 | 11,131 | 20,736 | 1,623 | 11.4 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 14 | L0-main | claudeopus46 | 1,356 | 1,385 | 2,741 | 622 | 4.1 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 15 | L0-main | claudeopus46 | 1,323 | 12,945 | 14,268 | 2,091 | 11.9 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |
| 16 | L0-main | claudeopus46 | 298 | 2,759 | 3,057 | 1,652 | 5.9 | What is the experimental mass density of the ethanol + water (query_runs/run_2) |

# Reference Stats — main-agent

**Run started:** 2026-08-02 18:38:23
**Wall time (at last flush):** 343.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 16 | 126,440 | 88,359 | 25,552 | 214,799 | 13,424 | 155.9 | claudeopus46 |
| L0-menu-planner | 1 | 831 | 1,329 | 1,846 | 2,160 | 2,160 | 10.5 | claudesonnet46 |
| L1-worker | 2 | 4,130 | 13,877 | 2,320 | 18,007 | 9,003 | 18.6 | claudeopus46 |
| **TOTAL** | **19** | **131,401** | **103,565** | **29,718** | **234,966** | **12,366** | **185.0** | |

**Estimated tokens:** ~58,741 input + ~7,429 output = ~66,170 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 3 | `browse_subagent_tools` | purpose=Find experimental density of …, tasks=Sear… | 1,846 | — | — | 33.9 |
| 2 | 6 | `run_subagent_tool` | kwargs={'queries': ['ethanol', 'wate…, purpose=Res… | 330 | — | — | 4.1 |
| 3 | 8 | `run_subagent_tool` | kwargs={'compound': ['GLOBcomp_2', '…, purpose=Fin… | 706 | — | — | 17.8 |
| 4 | 9 | `run_query_agent` | context=Ethanol = GLOBcomp_2, Water =…, purpose=Ex… | 4,941 | — | — | 134.7 |
| | | **TOTAL (4 tools)** | | **7,823** | | **0** | **190.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 4,527 | 4,527 | 0 | 0.0% |
| 2 | interval=2 | skipped_by_agent | 5,976 | 5,976 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 321 | 10,536 | 1,128 | 7.4 |
| 2 | L0-main | claudeopus46 | 10,215 | 973 | 11,188 | 682 | 5.0 |
| 3 | L0-main | claudeopus46 | 10,215 | 1,701 | 11,916 | 576 | 4.7 |
| 4 | L0-menu-planner | claudesonnet46 | 831 | 1,329 | 2,160 | 1,846 | 10.5 |
| 5 | L0-main | claudeopus46 | 10,215 | 3,356 | 13,571 | 847 | 5.5 |
| 6 | L0-main | claudeopus46 | 10,215 | 4,633 | 14,848 | 12,462 | 60.9 |
| 7 | L0-main | claudeopus46 | 10,215 | 5,357 | 15,572 | 645 | 4.6 |
| 8 | L1-worker | claudeopus46 | 2,065 | 484 | 2,549 | 508 | 3.9 |
| 9 | L0-main | claudeopus46 | 10,182 | 5,748 | 15,930 | 479 | 3.6 |
| 10 | L0-main | claudeopus46 | 10,215 | 4,991 | 15,206 | 859 | 6.7 |
| 11 | L0-main | claudeopus46 | 10,215 | 6,008 | 16,223 | 761 | 5.5 |
| 12 | L1-worker | claudeopus46 | 2,065 | 13,393 | 15,458 | 1,812 | 14.7 |
| 13 | L0-main | claudeopus46 | 10,182 | 7,279 | 17,461 | 514 | 4.8 |
| 14 | L0-main | claudeopus46 | 10,215 | 6,522 | 16,737 | 1,766 | 12.4 |
| 15 | L0-main | claudeopus46 | 10,215 | 16,135 | 26,350 | 1,708 | 11.7 |
| 16 | L0-main | claudeopus46 | 1,356 | 1,839 | 3,195 | 643 | 4.0 |
| 17 | L0-main | claudeopus46 | 1,323 | 18,587 | 19,910 | 550 | 4.7 |
| 18 | L0-main | claudeopus46 | 298 | 1,073 | 1,371 | 476 | 3.4 |
| 19 | L0-main | claudeopus46 | 949 | 3,836 | 4,785 | 1,456 | 11.0 |


# Delegated query run — result

**Question:** What is the experimental mass density of the ethanol + water binary mixture at mole fraction of ethanol x = 0.5, temperature 298.15 K, and atmospheric pressure? Look in block PROPblock_2 from literature GLOBlit_220 (DOI 10.1016/j.fluid.2004.11.019). Report the exact density value and units at or nearest to x(ethanol) = 0.5.

**Iterations:** 2  |  **Elapsed:** 116.4s  |  **Tools:** 4  |  **Timed out:** False

---

## Answer

The experimental mass density of the ethanol + water binary mixture at (or nearest to) equimolar composition, 298.15 K, and atmospheric pressure is:

- **Mole fraction of ethanol (x):** 0.4988  
- **Mass density:** 849.4 kg/m³  
- **Temperature:** 298.15 K  
- **Pressure:** 100 kPa (atmospheric)  
- **Phase:** Liquid  

**Source:** PROPblock_2 from DOI 10.1016/j.fluid.2004.11.019 (GLOBlit_220)  
**System:** Ethanol (C₂H₆O) + Water (H₂O) binary mixture  

The exact mole fraction x = 0.5000 is not present in the dataset; the closest available composition is x(ethanol) = 0.4988, differing by only 0.0012 from the target. The next nearest data point is at x = 0.5453 with a density of 844.3 kg/m³.

**Chemistry note:** At this near-equimolar composition, the density of 849.4 kg/m³ lies between that of pure water (~997 kg/m³) and pure ethanol (~785 kg/m³ at 298.15 K), but is not a simple linear average — reflecting the well-known non-ideal mixing behavior of the ethanol–water system, where hydrogen-bonding interactions lead to excess volume of mixing (volume contraction). This block contains 810 data points spanning mole fractions from 0.003 to 1.0, temperatures from 298.15 to 348.15 K, and pressures from 100 to 40,000 kPa.

### Core claims

- The experimental liquid mass density of the ethanol + water binary mixture at the nearest available equimolar composition (x_ethanol = 0.4988) is 849.4 kg/m³ at 298.15 K and 100 kPa.
- The exact equimolar composition (x = 0.5000) is not present in the dataset; the closest available point differs by only 0.0012 in mole fraction.
- The measured density of 849.4 kg/m³ lies between that of pure water (~997 kg/m³) and pure ethanol (~785 kg/m³) but is not a simple linear average, reflecting non-ideal mixing behavior (volume contraction due to hydrogen-bonding interactions) in the ethanol–water system.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | Mass density data for ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary mixture. At 298.15 K and 100 kPa, the nearest data point to x(ethanol)=0.5 is x=0.4988 with density 849.4 kg/m³. Block contains 810 total data points spanning T=298.15–348.15 K, P=100–40000 kPa, and x(ethanol)=0.003–1.0. |

### Suggested follow-ups

- Compare the density at x(ethanol)=0.4988 across the full pressure range (100–40000 kPa) in PROPblock_2 to examine pressure dependence.
- Extract excess molar volume data for the ethanol+water system at 298.15 K to quantify non-ideal mixing behavior.
- Compare density values at x(ethanol)=0.4988 across all three temperatures (298.15, 323.15, 348.15 K) to assess temperature dependence.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "Ethanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "Water"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_220",
    "registry_id": "10.1016/j.fluid.2004.11.019",
    "name": "Density data source for ethanol+water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density_kg_m3",
    "name": "Mass density, kg/m3"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_3",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_2",
    "name": "Mole fraction"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  }
]
```

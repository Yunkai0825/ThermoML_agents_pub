# Reference Stats — main-agent

**Run started:** 2026-08-02 19:54:53
**Wall time (at last flush):** 1,686.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 24,654 | 50,844 | 15,442 | 75,498 | 10,785 | 91.9 | claudeopus46 |
| **TOTAL** | **7** | **24,654** | **50,844** | **15,442** | **75,498** | **10,785** | **91.9** | |

**Estimated tokens:** ~18,874 input + ~3,860 output = ~22,734 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_parallel_subagents` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_parallel_subagents` | tasks=[{'agent': 'analysis', 'label… | 298 | — | — | 1608.3 |
| | | **TOTAL (1 tools)** | | **298** | | **0** | **1608.3** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 400 | 10,615 | 2,568 | 11.6 |
| 2 | L0-main | claudeopus46 | 10,215 | 26,686 | 36,901 | 6,075 | 40.5 |
| 3 | L0-main | claudeopus46 | 1,356 | 5,421 | 6,777 | 1,361 | 8.2 |
| 4 | L0-main | claudeopus46 | 1,323 | 8,341 | 9,664 | 1,357 | 8.5 |
| 5 | L0-main | claudeopus46 | 298 | 1,880 | 2,178 | 1,245 | 5.5 |
| 6 | L0-main | claudeopus46 | 298 | 1,743 | 2,041 | 1,349 | 6.1 |
| 7 | L0-main | claudeopus46 | 949 | 6,373 | 7,322 | 1,487 | 11.5 |


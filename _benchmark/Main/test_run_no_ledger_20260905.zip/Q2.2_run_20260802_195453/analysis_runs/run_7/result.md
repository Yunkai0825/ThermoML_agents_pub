# Analysis Run — 20260802_201151 (Round 1)

**Question:** [Purpose: Determine the maximum volume contraction for water + methanol at 25°C]
Find and fit excess molar volume (VE) data for the binary system water + methanol at 25°C (298.15 K). Report the Redlich-Kister coefficients, R², RMSE, and identify the minimum VE value and the mole fraction at which it occurs.

[Context: Looking for excess molar volume data. The property is typically reported as 'Excess molar volume' in ThermoML. Search for binary mixtures of water (H2O) and methanol (CH3OH, CH4O). Temperature should be 298.15 K.]

**Time:** 971.8s | **Iterations:** 16 | **Tools:** 22

---

## Answer

# Excess Molar Volume (V^E) of Water + Methanol at 298.15 K

## System Overview

The water + methanol binary system exhibits **negative excess molar volumes** across the entire composition range at 25 °C, indicating volume contraction upon mixing. This reflects strong hydrogen-bonding interactions between water and methanol molecules and more efficient molecular packing compared to an ideal solution.

---

## Data Sources and Fits

### Source 1 — Direct V^E Measurements (DP0)

- **DOI:** 10.1016/j.jct.2004.03.011 (GLOBlit_2395)
- **Block:** PROPblock_1
- **Property:** Excess molar volume (GLOBprop_28), m³/mol
- **Conditions:** T = 298.15 K, P = 100 kPa
- **Data points (mixture):** 3 (at x_methanol = 0.25, 0.50, 0.75)
- **Composition range:** x(methanol) = 0.25–0.75

**Redlich-Kister Fit (BIC-selected order 0):**

| Parameter | Value |
|-----------|-------|
| A₀ | −3.95153 × 10⁻⁶ m³/mol |
| R² | 0.9654 |
| RMSE | 2.564 × 10⁻⁸ m³/mol |
| BIC | −103.78 |

With only 3 data points at this T/P condition, the fit is limited to a symmetric (zeroth-order) polynomial. The minimum V^E from this fit is:

> **V^E_min = −0.988 cm³/mol at x(methanol) = 0.50**

*(V^E = x₁ x₂ A₀ → 0.25 × (−3.952 × 10⁻⁶) = −9.88 × 10⁻⁷ m³/mol)*

---

### Source 2 — V^E Derived from Measured Density (DP2)

- **DOI:** 10.1016/j.jct.2007.05.004 (GLOBlit_2825)
- **Block:** PROPblock_10
- **Property:** Mass density (GLOBprop_1) → exact pointwise transform: ρ(x) → V_m(x) = (x₁M₁ + x₂M₂)/ρ → V^E
- **Conditions:** T = 298.15 K, P = 101 kPa
- **Data points (mixture):** 11 (full composition range, x_water = 0–1)
- **Pure-component molar volumes (from block edges):**
  - Water: 1.80683 × 10⁻⁵ m³/mol (18.068 cm³/mol)
  - Methanol: 4.07038 × 10⁻⁵ m³/mol (40.704 cm³/mol)

**Redlich-Kister Fit (BIC-selected order 5):**

| Parameter | Value |
|-----------|-------|
| A₀ | −3.98239 × 10⁻⁶ |
| A₁ | −1.5386 × 10⁻⁷ |
| A₂ | 1.03864 × 10⁻⁸ |
| A₃ | 1.33311 × 10⁻⁷ |
| A₄ | 8.30673 × 10⁻⁷ |
| A₅ | 7.17478 × 10⁻⁷ |
| R² | **0.999995** |
| RMSE | 6.883 × 10⁻¹⁰ m³/mol |
| BIC | −449.74 |

*(All coefficients in m³/mol; V^E = x₁ x₂ Σₖ Aₖ (x₁ − x₂)^k, where x₁ = methanol)*

**Minimum V^E from this fit:**

> **V^E_min = −0.996 cm³/mol (−9.960 × 10⁻⁷ m³/mol) at x(methanol) ≈ 0.50**

---

## Maximum Volume Contraction

| Quantity | DP0 (direct V^E) | DP2 (density-derived) |
|----------|:-----------------:|:---------------------:|
| V^E_min | −0.988 cm³/mol | **−0.996 cm³/mol** |
| x(methanol) at min | 0.50 | ≈ 0.50 |
| R² | 0.9654 | 0.999995 |
| Mixture data points | 3 | 11 |

The **recommended result** is from the density-derived fit (DP2), which has 11 mixture data points spanning the full composition range and achieves R² = 0.999995:

### **Maximum volume contraction: V^E_min ≈ −1.00 cm³/mol at x(methanol) ≈ 0.50**

Both sources agree within ~1%, and the result is consistent with the well-established literature value of approximately −1.0 cm³/mol for this system at 25 °C. The nearly equimolar minimum reflects the strong, roughly symmetric hydrogen-bonding network formed between water and methanol molecules.

---

## BIC Model Selection (DP2 fit)

| RK Order | BIC | R² | RMSE (m³/mol) |
|:--------:|:-----:|:------:|:--------------:|
| 0 | −386.91 | 0.9955 | 2.064 × 10⁻⁸ |
| 1 | −384.59 | 0.9956 | 2.058 × 10⁻⁸ |
| 2 | −392.37 | 0.9982 | 1.295 × 10⁻⁸ |
| 3 | −404.87 | 0.9995 | 6.580 × 10⁻⁹ |
| 4 | −423.77 | 0.9999 | 2.499 × 10⁻⁹ |
| **5** | **−449.74** | **0.999995** | **6.883 × 10⁻¹⁰** |

The BIC selects order 5, indicating significant asymmetry in the V^E curve that requires higher-order terms to capture. The dominant A₀ coefficient (−3.98 × 10⁻⁶) agrees closely with the direct V^E measurement's A₀ (−3.95 × 10⁻⁶), providing cross-validation between the two independent data sources.

### Core claims

- The water + methanol binary system exhibits negative excess molar volumes across the entire composition range at 298.15 K, indicating volume contraction upon mixing due to strong hydrogen-bonding interactions and more efficient molecular packing.
- The recommended maximum volume contraction is V^E_min ≈ −1.00 cm³/mol at x(methanol) ≈ 0.50, based on a density-derived Redlich-Kister (order 5) fit with R² = 0.999995 and 11 mixture data points spanning the full composition range.
- A direct V^E measurement source with only 3 data points yields V^E_min = −0.988 cm³/mol at x(methanol) = 0.50, agreeing with the density-derived result within ~1% and consistent with the established literature value of approximately −1.0 cm³/mol.
- BIC model selection for the density-derived data favors a 5th-order Redlich-Kister polynomial, indicating significant asymmetry in the V^E curve beyond the dominant symmetric A₀ term.
- The dominant A₀ coefficients from the two independent data sources (−3.95 × 10⁻⁶ and −3.98 × 10⁻⁶ m³/mol) agree closely, providing cross-validation.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2395 | 10.1016/j.jct.2004.03.011 | PROPblock_1 |  | Direct excess molar volume (GLOBprop_28, m3/mol) for binary water (GLOBcomp_1) + methanol (GLOBcomp_4). 206 total rows, T = 298.15–523.15 K, P = 100–60000 kPa, x(methanol) = 0.25–0.75. 3 mixture data points at T = 298.15 K and P = 100 kPa used for RK fit. BIC-selected order 0, R² = 0.965353. |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | Mass density (GLOBprop_1, kg/m3) for binary water (GLOBcomp_1) + methanol (GLOBcomp_4). 39 total rows, T = 293.15–303.15 K, P = 101 kPa, x(water) = 0–1. Transformed via density_to_molar_volume to derive excess molar volume. 11 mixture data points at T = 298.15 K used for RK fit. Pure molar volumes from block edges: water = 1.8068301e-05 m3/mol, methanol = 4.070376e-05 m3/mol. BIC-selected order 5, R² = 0.999995. Minimum VE ≈ −9.960e-07 m3/mol (−0.996 cm3/mol) at x(methanol) ≈ 0.50. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2395 | PROPblock_1 | excess molar volume | 0 | -3.95153e-06 | 0.965353 | 2.56448e-08 | 3 | 298.15 | declared_excess_no_baseline |  | 10.1016/j.jct.2004.03.011 |
| GLOBlit_2825 | PROPblock_10 | excess molar volume (derived from mass density via density_to_molar_volume transform) | 5 | -3.98239e-06; -1.5386e-07; 1.03864e-08; 1.33311e-07; 8.30673e-07; 7.17478e-07 | 0.999995 | 6.88305e-10 | 11 | 298.15 | linear |  | 10.1016/j.jct.2007.05.004 |

---

## Verdict

**Data Quality**
Two independent sources were used: direct V^E (3 points) and density-derived V^E via `fit_block_derived` (11 points). The derived route correctly converts density to V^E using pure-component molar volumes. Both `fit_block` and `fit_block_derived` appear in the trace, confirming no fabrication. Composition basis appears to be mole fraction throughout. No agent-built blocks were used. Data quality is sound.

**Fit Quality**
The 3-point direct fit (order 0, R²=0.965) is limited but consistent. The 11-point density-derived fit (order 5, R²=0.999995) is excellent with BIC-justified model selection. Order 5 for 11 points (5 free parameters) approaches overfitting territory but BIC supports it.

**Scientific Verdict**
V^E_min ≈ −1.00 cm³/mol at x(methanol) ≈ 0.50 agrees well with established literature (~−1.0 cm³/mol). Cross-validation between independent sources strengthens confidence. The order-5 fit should be used cautiously for extrapolation; order 3–4 may be more robust for general use.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7\plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_1 | water | water |
| comp | GLOBcomp_4 | methanol | methanol |
| prop | GLOBprop_28 | excess_molar_volume_m3_mol | Excess molar volume, m3/mol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Resolve compound IDs for water (H2O) and methanol (CH3OH/CH4O), and find the property ID for excess molar volume (VE) → stored as L1_query_1
- [L1] Find excess molar volume (VE) data blocks for water + methanol binary mixture at 298.15 K → stored as L1_query_2
- [L1] Find density data blocks for water + methanol binary mixture at 298.15 K as fallback for deriving VE → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "All three identifiers have been successfully resolved:\n\n1. **Water (H₂O):** GLOBcomp_1 — formula H2O, SMILES: O\n2. **Methanol (CH₃OH / CH₄O):** GLOBcomp_4 — formula CH4O, SMILES: CO\n3. **Excess molar volume (VE):** GLOBprop_28 — \"Excess molar volume\" in units of m³/mol, classified under VolumetricProp\n\nThese IDs can now be used for downstream searches of excess molar volume data in water–methanol binary systems.",
  "core_claims": [
    "Water (H₂O) is identified as GLOBcomp_1, methanol (CH₄O) is identified as GLOBcomp_4, and excess molar volume (VE) is identified as GLOBprop_28 (in units of m³/mol, classified under VolumetricProp).",
    "These resolved identifiers can be used for downstream searches of excess molar volume data in water–methanol binary systems."
  ],
  "status": "success",
  "summary": "The three ThermoML identifiers were resolved as follows: Water (H₂O) maps to GLOBcomp_1 (formula H2O, SMILES: O), Methanol (CH₃OH / CH₄O) maps to GLOBcomp_4 (formula CH4O, SMILES: CO), and Excess molar volume (VE) maps to GLOBprop_28 ('Excess molar volume', units m³/mol, classified under VolumetricProp). These IDs are intended for downstream searches of excess molar volume data in water–methanol binary systems.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_28",
      "registry_id": "excess_molar_volume_m3_mol",
      "name": "Excess molar volume, m3/mol"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "The ThermoML database contains **one data block** with excess molar volume (V^E) for the binary water + methanol system at 298.15 K:\n\n**Literature source:**\n- **DOI:** 10.1016/j.jct.2004.03.011 (Safarov et al., 2004)\n- **Literature ID:** GLOBlit_2395\n\n**Block details:**\n- **Block ID:** PROPblock_1\n- **Compounds:** DOIcomp_1 → GLOBcomp_1 (water, H₂O); DOIcomp_2 → GLOBcomp_4 (methanol, CH₄O)\n- **Property:** BLKprop_1 → GLOBprop_28 (Excess molar volume, m³/mol)\n- **Variables:** Temperature (GLOBvar_1, K), Pressure (GLOBvar_3, kPa), Mole fraction of methanol (GLOBvar_2)\n- **Phase:** Liquid\n- **Total data points:** 206, spanning T = 298.15–348.15 K and P = 100–60,000 kPa\n- **Points at 298.15 K:** 23\n\n**Representative data at T = 298.15 K, P = 100 kPa:**\n\n| x(methanol) | V^E (m³/mol) | Uncertainty |\n|---|---|---|\n| 0.25 | −7.42 × 10⁻⁷ | ±1.9 × 10⁻⁸ |\n| 0.50 | −1.014 × 10⁻⁶ | ±2.0 × 10⁻⁸ |\n| 0.75 | −7.05 × 10⁻⁷ | ±1.9 × 10⁻⁸ |\n\nThe negative V^E values across the entire composition range are characteristic of the water–methanol system, reflecting strong hydrogen-bonding interactions and more efficient molecular packing in the mixture compared to the ideal solution. The minimum V^E occurs near x(methanol) ≈ 0.5, consistent with the well-known asymmetric minimum typically reported for this system. No other literature sources for this property and binary system were found in the ThermoML database.",
  "core_claims": [
    "The ThermoML database contains one data block (DOI 10.1016/j.jct.2004.03.011, Safarov et al. 2004) reporting excess molar volume for the water + methanol binary system, with 206 data points spanning T = 298.15–348.15 K and P = 100–60,000 kPa, of which 23 points are at 298.15 K.",
    "At 298.15 K and 100 kPa, the excess molar volume is negative across the entire composition range, with a minimum near x(methanol) ≈ 0.5 (V^E ≈ −1.014 × 10⁻⁶ m³/mol), consistent with strong hydrogen-bonding interactions and more efficient molecular packing relative to an ideal solution.",
    "No other literature sources for excess molar volume of the water + methanol system were found in the ThermoML database."
  ],
  "status": "success",
  "summary": "The ThermoML database contains one data block (PROPblock_1, DOI 10.1016/j.jct.2004.03.011, literature ID GLOBlit_2395) reporting excess molar volume (V^E, GLOBprop_28) for the binary water (GLOBcomp_1) + methanol (GLOBcomp_4) system in the liquid phase. The block has 206 data points spanning T = 298.15–348.15 K and P = 100–60,000 kPa, with 23 points at 298.15 K. Variables are temperature (GLOBvar_1), pressure (GLOBvar_3), and mole fraction of methanol (GLOBvar_2). At 298.15 K and 100 kPa, V^E is negative across the full composition range, with representative values of −7.42 × 10⁻⁷ m³/mol at x = 0.25, −1.014 × 10⁻⁶ m³/mol at x = 0.50, and −7.05 × 10⁻⁷ m³/mol at x = 0.75, each with uncertainties on the order of ±2 × 10⁻⁸ m³/mol. The minimum V^E occurs near x(methanol) ≈ 0.5, consistent with strong hydrogen-bonding interactions and efficient molecular packing. No other ThermoML sources were found for this property and binary system.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2395",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_28"
      ],
      "description": "Excess molar volume (V^E) data for water + methanol binary mixture from Safarov et al. (2004), DOI 10.1016/j.jct.2004.03.011. Block contains 206 total data points spanning T = 298.15–348.15 K and P = 100–60000 kPa, with 23 points at exactly 298.15 K. Representative values at T = 298.15 K, P = 100 kPa: V^E = −7.42e-07 m³/mol at x(methanol) = 0.25, −1.014e-06 m³/mol at x(methanol) = 0.50, −7.05e-07 m³/mol at x(methanol) = 0.75. Phase: liquid.",
      "doi": "10.1016/j.jct.2004.03.011",
      "lit_id": "2004-saf-hey-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 206,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 523.15,
            "n_unique": 10
          },
          "range_min": 298.15,
          "range_max": 523.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.0,
            "max": 60000.0,
            "n_unique": 8
          },
          "range_min": 100.0,
          "range_max": 60000.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.25,
            "max": 0.75,
            "n_unique": 3
          },
          "range_min": 0.25,
          "range_max": 0.75
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_28",
          "prop_ID": "excess_molar_volume_m3_mol",
          "name": "Excess molar volume, m3/mol",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_207",
          "meas_ID": "same_ufactor_2",
          "method_standard": null,
          "method_custom": "SAME:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar volume, m3/mol",
            "min": -3e-06,
            "max": -0.0,
            "mean": -1e-06,
            "std": 0.0,
            "n": 206
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": -3e-06,
          "range_max": -0.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 206,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_3
{
  "answer": "The ThermoML database contains at least **9 binary water + methanol mass density blocks** with temperature ranges overlapping 298.15 K (filtered to 293–303 K). All report mass density (GLOBprop_1, kg/m³) in the liquid phase. Here are the identified blocks:\n\n| # | DOI | Block | Literature ID | T range (K) | Composition variable | Data points | Measurement method |\n|---|-----|-------|---------------|-------------|---------------------|-------------|-------------------|\n| 1 | 10.1016/j.jct.2004.07.019 | PROPblock_1 | GLOBlit_2432 | 298.16–573.15 | Molality (BLKvar_3) | 596 | GLOBmeas_2 (vibrating tube) |\n| 2 | 10.1016/j.jct.2007.05.004 | PROPblock_10 | GLOBlit_2825 | 293.15–303.15 | Mole fraction (BLKvar_2) | 39 | GLOBmeas_134 |\n| 3 | 10.1016/j.jct.2019.05.013 | PROPblock_2 | GLOBlit_5533 | 273.15–293.15 | Mass fraction (BLKvar_1) | 12 | GLOBmeas_2 (vibrating tube) |\n| 4 | 10.1021/acs.jced.6b01058 | PROPblock_6 | GLOBlit_7085 | 298.15–313.15 | Mass fraction (BLKvar_2) | 12 | GLOBmeas_2 (vibrating tube) |\n\nPlus approximately 5 additional blocks (truncated in the registry listing).\n\n**Key observations:**\n\n- **Compounds:** Water (GLOBcomp_1, H₂O) and methanol (GLOBcomp_4, CH₄O) in all blocks.\n- **Property:** Mass density (GLOBprop_1, kg/m³).\n- **Caution on Block #1 (GLOBlit_2432):** This block was flagged as reporting negative density values, which likely indicates it contains excess or difference density quantities rather than absolute mass density, despite being cataloged under GLOBprop_1. It also uses molality as the composition variable rather than mole or mass fraction, requiring special handling for VE derivation.\n- **Block #3 (GLOBlit_5533):** Its temperature range (273.15–293.15 K) may not extend to 298.15 K, so it may not be useful for the target temperature.\n- **Best candidates for VE derivation at 298.15 K:** Blocks #2 (GLOBlit_2825, mole fraction basis, 39 points spanning 293–303 K) and #4 (GLOBlit_7085, mass fraction basis, 12 points starting at 298.15 K) are the most straightforward for deriving excess molar volume, as they use standard composition variables and clearly cover 298.15 K.\n\nTo derive V^E from density data, one would use: V^E = (x₁M₁ + x₂M₂)/ρ_mix − x₁M₁/ρ₁ − x₂M₂/ρ₂, where M is molar mass, x is mole fraction, ρ_mix is the mixture density, and ρ₁, ρ₂ are pure component densities. This requires pure component density data at the same T and P conditions, which would need to be sourced separately from unary blocks.",
  "core_claims": [
    "The ThermoML database contains at least 9 binary water + methanol mass density blocks with temperature ranges overlapping 298.15 K, all reporting mass density (kg/m³) in the liquid phase.",
    "The most suitable blocks for deriving excess molar volume at 298.15 K are GLOBlit_2825 (mole fraction basis, 39 data points, 293.15–303.15 K) and GLOBlit_7085 (mass fraction basis, 12 data points, starting at 298.15 K), as they use standard composition variables and clearly cover the target temperature.",
    "Block GLOBlit_2432 was flagged for reporting negative density values, likely indicating it contains excess or difference density quantities rather than absolute mass density, despite being cataloged as mass density; it also uses molality, requiring special handling.",
    "Block GLOBlit_5533 has a temperature range of 273.15–293.15 K and may not extend to 298.15 K, limiting its utility for the target condition.",
    "Deriving excess molar volume from mixture density data requires pure component densities at the same temperature and pressure, which would need to be sourced separately from unary data blocks."
  ],
  "status": "success",
  "summary": "At least 9 binary water + methanol mass-density blocks in ThermoML have temperature ranges overlapping 298.15 K (filtered 293–303 K), all reporting liquid-phase mass density (GLOBprop_1, kg/m³). The best candidates for deriving excess molar volume at 298.15 K are GLOBlit_2825 (DOI 10.1016/j.jct.2007.05.004, 39 points on a mole-fraction basis, 293.15–303.15 K) and GLOBlit_7085 (DOI 10.1021/acs.jced.6b01058, 12 points on a mass-fraction basis starting at 298.15 K), both measured by vibrating-tube densimetry. GLOBlit_2432 (DOI 10.1016/j.jct.2004.07.019) was flagged for negative density values, suggesting it may contain excess or difference densities rather than absolute values. GLOBlit_5533 (DOI 10.1016/j.jct.2019.05.013) may not extend to 298.15 K. Deriving V^E requires the standard relation V^E = (x₁M₁ + x₂M₂)/ρ_mix − x₁M₁/ρ₁ − x₂M₂/ρ₂, with pure-component densities sourced separately from unary blocks at matching T and P.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2432",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m3) for water+methanol binary, T range 298.16–573.15 K, composition via molality (BLKvar_3), 596 data points, vibrating tube (GLOBmeas_2). Caution: negative density values reported, likely excess/difference quantities despite GLOBprop_1 cataloging. DOI: 10.1016/j.jct.2004.07.019",
      "doi": "10.1016/j.jct.2004.07.019",
      "lit_id": "2004-hyn-hne-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 596,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.16,
            "max": 573.15,
            "n_unique": 16
          },
          "range_min": 298.16,
          "range_max": 573.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 390.0,
            "max": 30320.0,
            "n_unique": 32
          },
          "range_min": 390.0,
          "range_max": 30320.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_5",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_5",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Molality, mol/kg",
            "min": 0.07706,
            "max": 1.04694,
            "n_unique": 161
          },
          "range_min": 0.07706,
          "range_max": 1.04694
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": -13.3065,
            "max": -0.4632,
            "mean": -3.693235,
            "std": 2.632762,
            "n": 596
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": -13.3065,
          "range_max": -0.4632
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 596,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2825",
      "block_number": "PROPblock_10",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m3) for water+methanol binary, T range 293.15–303.15 K, composition via mole fraction (BLKvar_2), 39 data points, GLOBmeas_134. Best candidate for VE derivation at 298.15 K. DOI: 10.1016/j.jct.2007.05.004",
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_id": "2007-gon-cal-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_134",
          "meas_ID": "vibtub_ufactor_4",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 782.48,
            "max": 998.2,
            "mean": 885.828974,
            "std": 72.087348,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 782.48,
          "range_max": 998.2
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_5533",
      "block_number": "PROPblock_2",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m3) for water+methanol binary, T range 273.15–293.15 K, composition via mass fraction (BLKvar_1), 12 data points, vibrating tube (GLOBmeas_2). May not extend to 298.15 K. DOI: 10.1016/j.jct.2019.05.013",
      "doi": "10.1016/j.jct.2019.05.013",
      "lit_id": "2019-sem-sto-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 12,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_2",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 0.4999,
            "n_unique": 6
          },
          "range_min": 0.0,
          "range_max": 0.4999
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 273.15,
            "max": 293.15,
            "n_unique": 3
          },
          "range_min": 273.15,
          "range_max": 293.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 915.53,
            "max": 999.94,
            "mean": 961.621667,
            "std": 27.202688,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 915.53,
          "range_max": 999.94
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_7085",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m3) for water+methanol binary, T range 298.15–313.15 K, composition via mass fraction (BLKvar_2), 12 data points, vibrating tube (GLOBmeas_2). Good candidate for VE derivation at 298.15 K. DOI: 10.1021/acs.jced.6b01058",
      "doi": "10.1021/acs.jced.6b01058",
      "lit_id": "2017-sha-cha-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 12,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 85.0,
          "digits": 2,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_2",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.04,
            "max": 0.16,
            "n_unique": 3
          },
          "range_min": 0.04,
          "range_max": 0.16
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 963.68,
            "max": 989.97,
            "mean": 978.324167,
            "std": 9.346563,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 963.68,
          "range_max": 989.97
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


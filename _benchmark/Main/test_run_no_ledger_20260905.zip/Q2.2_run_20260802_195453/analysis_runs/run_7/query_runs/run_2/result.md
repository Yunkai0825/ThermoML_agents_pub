# Delegated query run — result

**Question:** Find binary mixture data blocks containing both water (H2O) and methanol (CH3OH or CH4O) with excess molar volume (VE) measurements at or near 298.15 K. I need the DOI, block number, compound IDs (GLOBcomp), and property ID (GLOBprop) for excess molar volume. Also search for density data blocks for the same system at 298.15 K as a fallback to derive VE from density.

**Iterations:** 3  |  **Elapsed:** 354.8s  |  **Tools:** 3  |  **Timed out:** False

---

## Answer

## Water + Methanol Binary Mixture: Excess Molar Volume and Density Data at 298.15 K

### Resolved Identifiers
- **Water (H₂O):** GLOBcomp_1
- **Methanol (CH₃OH / CH₄O):** GLOBcomp_4
- **Excess molar volume (V^E):** GLOBprop_28 (units: m³/mol)
- **Mass density:** GLOBprop_1 (units: kg/m³)

---

### 1. Direct Excess Molar Volume (V^E) Data

**One data block found** in the ThermoML database:

| Field | Value |
|-------|-------|
| **DOI** | 10.1016/j.jct.2004.03.011 (Safarov et al., 2004) |
| **Literature ID** | GLOBlit_2395 |
| **Block** | PROPblock_1 |
| **Property** | GLOBprop_28 — Excess molar volume (m³/mol) |
| **Compounds** | GLOBcomp_1 (water) + GLOBcomp_4 (methanol) |
| **Phase** | Liquid |
| **Total data points** | 206 |
| **T range** | 298.15–348.15 K |
| **P range** | 100–60,000 kPa |
| **Points at 298.15 K** | 23 |
| **Composition range** | x(methanol) = 0.25–0.75 |

**Representative V^E values at T = 298.15 K, P = 100 kPa:**

| x(methanol) | V^E (m³/mol) | Uncertainty (95%) |
|:-----------:|:------------:|:-----------------:|
| 0.25 | −7.42 × 10⁻⁷ | ±1.9 × 10⁻⁸ |
| 0.50 | −1.014 × 10⁻⁶ | ±2.0 × 10⁻⁸ |
| 0.75 | −7.05 × 10⁻⁷ | ±1.9 × 10⁻⁸ |

The negative V^E values across the entire composition range are characteristic of the water–methanol system, reflecting strong hydrogen-bonding interactions and more efficient molecular packing in the mixture compared to the ideal solution. The minimum V^E occurs near x(methanol) ≈ 0.5 (V^E ≈ −1.0 cm³/mol), consistent with the well-known asymmetric minimum typically reported for this system.

---

### 2. Density Data Blocks (Fallback for V^E Derivation)

At least **9 binary water + methanol density blocks** were found with temperature ranges overlapping 298.15 K. The most relevant are:

| # | DOI | Lit ID | Block | T range (K) | Composition | Points | Notes |
|---|-----|--------|-------|-------------|-------------|--------|-------|
| 1 | 10.1016/j.jct.2007.05.004 | GLOBlit_2825 | PROPblock_10 | 293.15–303.15 | Mole fraction (0–1) | 39 | **Best candidate** — full composition range, mole fraction basis |
| 2 | 10.1021/acs.jced.6b01058 | GLOBlit_7085 | PROPblock_6 | 298.15–313.15 | Mass fraction (0.04–0.16) | 12 | Good, but limited composition range |
| 3 | 10.1016/j.jct.2004.07.019 | GLOBlit_2432 | PROPblock_1 | 298.16–573.15 | Molality (0.08–1.05) | 596 | ⚠️ Negative density values — likely excess/difference densities |
| 4 | 10.1016/j.jct.2019.05.013 | GLOBlit_5533 | PROPblock_2 | 273.15–293.15 | Mass fraction (0–0.50) | 12 | May not extend to 298.15 K |

All blocks report mass density (GLOBprop_1, kg/m³) in the liquid phase.

**Best candidate for V^E derivation:** GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004) — 39 data points on a mole-fraction basis spanning x(water) = 0 to 1 at 293.15–303.15 K and P = 101 kPa. Density ranges from 782.48 to 998.2 kg/m³. To derive V^E, one would use:

> V^E = (x₁M₁ + x₂M₂)/ρ_mix − x₁(M₁/ρ₁) − x₂(M₂/ρ₂)

where M is molar mass, x is mole fraction, ρ_mix is mixture density, and ρ₁, ρ₂ are pure-component densities at the same T and P (available from the endpoints x = 0 and x = 1 in this block).

---

### Summary

The ThermoML database contains **one direct excess molar volume block** (GLOBlit_2395, DOI: 10.1016/j.jct.2004.03.011) for the water + methanol binary system at 298.15 K with 23 data points, plus **multiple density blocks** from which V^E could be derived, with GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004) being the most suitable fallback.

### Core claims

- The ThermoML database contains one direct excess molar volume (V^E) block for the water + methanol binary system at 298.15 K (GLOBlit_2395, DOI: 10.1016/j.jct.2004.03.011), reporting 23 data points over x(methanol) = 0.25–0.75 at pressures from 100–60,000 kPa, with V^E values that are negative across the entire composition range and reach a minimum near x(methanol) ≈ 0.5 (approximately −1.0 cm³/mol at 100 kPa).
- The negative V^E values reflect strong hydrogen-bonding interactions and more efficient molecular packing relative to an ideal solution, consistent with well-known behavior of the water–methanol system.
- At least nine additional binary water + methanol density blocks with temperature ranges overlapping 298.15 K are available in ThermoML, from which V^E could be derived; the most suitable fallback is GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004), which provides 39 mole-fraction-based density points spanning the full composition range at 293.15–303.15 K and 101 kPa.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2395 | 10.1016/j.jct.2004.03.011 | PROPblock_1 |  | Excess molar volume (GLOBprop_28) for binary water (GLOBcomp_1) + methanol (GLOBcomp_4) system. 206 total data points, T = 298.15–348.15 K, P = 100–60000 kPa, 23 points at 298.15 K. Liquid phase. Composition range x(methanol) = 0.25–0.75. Safarov et al. (2004). |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | Mass density (GLOBprop_1) for binary water (GLOBcomp_1) + methanol (GLOBcomp_4) system. 39 data points, T = 293.15–303.15 K, full mole fraction range (0–1), P = 101 kPa. Best fallback candidate for deriving V^E from density. |
| GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_6 |  | Mass density (GLOBprop_1) for binary water (GLOBcomp_1) + methanol (GLOBcomp_4) system. 12 data points, T = 298.15–313.15 K, mass fraction 0.04–0.16. Limited composition range. |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_1 |  | Mass density (GLOBprop_1) for binary water (GLOBcomp_1) + methanol (GLOBcomp_4) system. 596 data points, T = 298.16–573.15 K, molality 0.08–1.05. Caution: negative density values reported, possibly excess/difference densities. |
| GLOBlit_5533 | 10.1016/j.jct.2019.05.013 | PROPblock_2 |  | Mass density (GLOBprop_1) for binary water (GLOBcomp_1) + methanol (GLOBcomp_4) system. 12 data points, T = 273.15–293.15 K, mass fraction 0–0.50. May not extend to 298.15 K. |

### Suggested follow-ups

- Retrieve full 23-point dataset at 298.15 K from GLOBlit_2395 / PROPblock_1 for detailed V^E vs composition analysis.
- Retrieve density data from GLOBlit_2825 / PROPblock_10 at 298.15 K to independently derive V^E and cross-validate against the direct V^E measurements.
- Search for additional excess molar volume or density data for water + methanol at other temperatures (e.g., 293.15 K, 303.15 K) to assess temperature dependence.
- Investigate the negative density values in GLOBlit_2432 / PROPblock_1 to determine if they represent apparent molar volumes or excess density quantities rather than absolute mass density.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_28",
    "registry_id": "excess_molar_volume_m3_mol",
    "name": "Excess molar volume, m3/mol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density_kg_m3",
    "name": "Mass density, kg/m3"
  }
]
```

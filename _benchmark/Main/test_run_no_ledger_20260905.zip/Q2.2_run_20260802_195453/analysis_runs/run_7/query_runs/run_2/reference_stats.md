# Reference Stats — query-agent

**Run started:** 2026-08-02 20:01:56
**Wall time (at last flush):** 385.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 32,090 | 82,044 | 16,586 | 114,134 | 16,304 | 96.1 | claudeopus46 |
| L1-worker | 34 | 274,918 | 217,769 | 46,489 | 492,687 | 14,490 | 312.8 | claudeopus46 |
| **TOTAL** | **41** | **307,008** | **299,813** | **63,075** | **606,821** | **14,800** | **408.9** | |

**Estimated tokens:** ~151,705 input + ~15,768 output = ~167,473 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 206 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 6 | 2 | 11 | 11 | 1,366 |
| `search_blocks` | 2 | 1 | 6 | 2 | 10 | 10 | 1,361 |
| `search_system_registry` | 2 | 1 | 6 | 1 | 9 | 9 | 1,349 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **10** | **6** | **21** | **5** | **31** | **31** | **4,282** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_4 |  | resolve_compound_ids, search_blocks, search_system_registry |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_28 |  | resolve_property_ids, search_blocks |
| GLOBprop_1 |  | resolve_property_ids, search_blocks, search_system_registry |

#### References (12 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2395 |  | search_blocks |
| GLOBlit_2432 |  | search_blocks, search_system_registry |
| GLOBlit_2825 |  | search_blocks, search_system_registry |
| GLOBlit_5533 |  | search_blocks, search_system_registry |
| GLOBlit_7085 |  | search_blocks, search_system_registry |
| GLOBlit_8155 |  | search_blocks |
| GLOBlit_8254 |  | search_blocks, search_system_registry |
| GLOBlit_8424 |  | search_blocks, search_system_registry |
| GLOBlit_8869 |  | search_blocks, search_system_registry |
| GLOBlit_8888 |  | search_blocks |
| GLOBlit_9571 |  | search_blocks, search_system_registry |
| GLOBlit_10866 |  | search_blocks, search_system_registry |

#### Measurements (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_207 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_170 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_280 | Mass density, kg/m3 | search_blocks, search_system_registry |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBvar_18 | Volume fraction | search_blocks, search_system_registry |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_3 |  | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 2 |
| Unique References | 12 |
| Unique Measurements | 7 |
| Unique Phases | 1 |
| Unique Variables | 6 |
| Unique Solvents | 2 |
| Unique Constraints | 2 |
| Unique Block_Types | 1 |
| Total DOIs | 12 |
| Unique parent blocks | 12 |
| Explicit block/subsystem targets | 12 |
| Subsystem targets | 0 |
| Target-matched data points | 4,282 |

---

## 3. DOI & Block References

**Unique DOIs:** 12  |  **Parent blocks:** 12  |  **Explicit targets:** 12  |  **Subsystems:** 0  |  **Target-matched datapoints:** 1,572

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2004.03.011 | 1 | 206 | binary | search_blocks |
| 10.1016/j.jct.2004.07.019 | 1 | 596 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.05.013 | 1 | 12 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b01058 | 1 | 12 | binary | search_blocks, search_system_registry |
| 10.1021/je0301500 | 1 | 5 | binary | search_blocks |
| 10.1021/je034101z | 1 | 401 | binary | search_blocks, search_system_registry |
| 10.1021/je049691v | 1 | 180 | binary | search_blocks, search_system_registry |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks, search_system_registry |
| 10.1021/je0601098 | 1 | 12 | binary | search_blocks |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks, search_system_registry |
| 10.1021/je700300y | 1 | 84 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2004.03.011 | PROPblock_1 | declared | 206 | binary | — | search_blocks |
| 10.1016/j.jct.2004.07.019 | PROPblock_1 | declared | 596 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.05.013 | PROPblock_2 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b01058 | PROPblock_6 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0301500 | PROPblock_13 | declared | 5 | binary | — | search_blocks |
| 10.1021/je034101z | PROPblock_4 | declared | 401 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je049691v | PROPblock_3 | declared | 180 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0600810 | PROPblock_4 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0601098 | PROPblock_18 | declared | 12 | binary | — | search_blocks |
| 10.1021/je2003622 | PROPblock_2 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700300y | PROPblock_6 | declared | 84 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 258 | KEEP | 258 | 6.7 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Resolve property ID… | 273 | KEEP | 273 | 6.4 |
| 3 | 1 | `L1_query` | context=Known property IDs: GLOBprop_…, id_catalog… | 1,769 | — | — | 40.9 |
| 4 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 1,147 | KEEP | 1132 | 23.1 |
| 5 | 2 | `L1_query` | context=We need binary mixture data b…, id_catalog… | 9,516 | — | — | 125.1 |
| 6 | 1 | `resolve_property_ids` | limit=10, min_score=50, purpose=Confirm GLOBprop_1… | 323 | KEEP | 323 | 4.4 |
| 7 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 203 | KEEP | 203 | 13.7 |
| 8 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 83 | KEEP | 83 | 21.8 |
| 9 | 3 | `search_system_registry` | compound=['GLOBcomp_1', 'GLOBcomp_4'], limit=50, p… | 1,076 | KEEP | 1076 | 14.7 |
| 10 | 2 | `L1_query` | context=Fallback search: if no direct…, id_catalog… | 270 | — | — | 132.4 |
| | | **TOTAL (10 tools)** | | **14,918** | | **3,348** | **389.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,372 | 4,372 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,455 | 11,060 | 1,263 | 6.9 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,043 | 21,686 | 837 | 5.6 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,608 | 23,251 | 1,379 | 7.4 |
| 4 | L1-worker | claudeopus46 | 2,065 | 446 | 2,511 | 476 | 6.6 |
| 5 | L1-worker | claudeopus46 | 2,065 | 387 | 2,452 | 506 | 6.3 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,148 | 23,791 | 436 | 4.4 |
| 7 | L1-worker | claudeopus46 | 1,323 | 3,262 | 4,585 | 305 | 2.9 |
| 8 | L1-worker | claudeopus46 | 1,356 | 565 | 1,921 | 345 | 3.7 |
| 9 | L1-worker | claudeopus46 | 536 | 445 | 981 | 428 | 5.3 |
| 10 | L1-worker | claudeopus46 | 298 | 1,027 | 1,325 | 293 | 3.0 |
| 11 | L1-worker | claudeopus46 | 747 | 3,898 | 4,645 | 383 | 4.1 |
| 12 | L0-main | claudeopus46 | 9,605 | 5,848 | 15,453 | 2,498 | 12.4 |
| 13 | L1-worker | claudeopus46 | 20,643 | 3,372 | 24,015 | 811 | 12.8 |
| 14 | L1-worker | claudeopus46 | 20,643 | 4,804 | 25,447 | 8,933 | 40.5 |
| 15 | L1-worker | claudeopus46 | 2,065 | 4,487 | 6,552 | 1,621 | 15.3 |
| 16 | L1-worker | claudeopus46 | 20,643 | 5,924 | 26,567 | 3,726 | 19.2 |
| 17 | L1-worker | claudeopus46 | 20,643 | 10,271 | 30,914 | 1,739 | 8.0 |
| 18 | L1-worker | claudeopus46 | 536 | 1,439 | 1,975 | 957 | 6.3 |
| 19 | L1-worker | claudeopus46 | 1,323 | 5,019 | 6,342 | 807 | 6.6 |
| 20 | L1-worker | claudeopus46 | 1,356 | 1,559 | 2,915 | 709 | 6.8 |
| 21 | L1-worker | claudeopus46 | 298 | 1,529 | 1,827 | 680 | 4.0 |
| 22 | L1-worker | claudeopus46 | 747 | 13,134 | 13,881 | 612 | 10.1 |
| 23 | L1-worker | claudeopus46 | 20,643 | 13,015 | 33,658 | 1,638 | 10.6 |
| 24 | L1-worker | claudeopus46 | 2,065 | 404 | 2,469 | 522 | 4.3 |
| 25 | L1-worker | claudeopus46 | 2,065 | 7,591 | 9,656 | 1,559 | 13.0 |
| 26 | L1-worker | claudeopus46 | 20,643 | 14,293 | 34,936 | 1,195 | 7.9 |
| 27 | L1-worker | claudeopus46 | 2,065 | 7,022 | 9,087 | 1,677 | 13.9 |
| 28 | L1-worker | claudeopus46 | 20,643 | 14,944 | 35,587 | 1,197 | 7.9 |
| 29 | L1-worker | claudeopus46 | 2,065 | 7,824 | 9,889 | 1,805 | 14.2 |
| 30 | L1-worker | claudeopus46 | 20,610 | 17,343 | 37,953 | 465 | 4.7 |
| 31 | L1-worker | claudeopus46 | 20,643 | 16,590 | 37,233 | 3,717 | 21.9 |
| 32 | L1-worker | claudeopus46 | 1,356 | 2,625 | 3,981 | 1,121 | 5.4 |
| 33 | L1-worker | claudeopus46 | 536 | 2,505 | 3,041 | 949 | 6.3 |
| 34 | L1-worker | claudeopus46 | 1,323 | 7,578 | 8,901 | 2,146 | 9.2 |
| 35 | L1-worker | claudeopus46 | 298 | 2,868 | 3,166 | 1,722 | 6.9 |
| 36 | L1-worker | claudeopus46 | 747 | 34,800 | 35,547 | 793 | 7.7 |
| 37 | L0-main | claudeopus46 | 9,605 | 45,678 | 55,283 | 4,773 | 36.1 |
| 38 | L0-main | claudeopus46 | 1,356 | 3,638 | 4,994 | 1,020 | 6.5 |
| 39 | L0-main | claudeopus46 | 298 | 1,402 | 1,700 | 1,008 | 3.8 |
| 40 | L0-main | claudeopus46 | 1,323 | 20,105 | 21,428 | 3,250 | 18.6 |
| 41 | L0-main | claudeopus46 | 298 | 3,918 | 4,216 | 2,774 | 11.8 |


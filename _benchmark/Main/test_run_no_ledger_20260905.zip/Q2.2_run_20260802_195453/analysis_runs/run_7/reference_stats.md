# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:55:05
**Wall time (at last flush):** 1,006.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 24 | 385,137 | 393,970 | 36,053 | 779,107 | 32,462 | 258.3 | claudeopus46 |
| L1-worker | 27 | 227,146 | 132,312 | 79,107 | 359,458 | 13,313 | 385.8 | claudeopus46 |
| **TOTAL** | **51** | **612,283** | **526,282** | **115,160** | **1,138,565** | **22,324** | **644.1** | |

**Estimated tokens:** ~284,641 input + ~28,790 output = ~313,431 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | context=Looking for GLOBprop that cor…, instructio… | 426 | — | — | 232.7 |
| 2 | 2 | `query_thermoml` | context=Looking for excess molar volu…, instructio… | 1,103 | — | — | 135.3 |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'find_water', 'pur… | 418 | — | — | 0.2 |
| 4 | 4 | `run_query_agent` | context=Known reference IDs from syst…, purpose=Fi… | 9,387 | — | — | 385.8 |
| 5 | 8 | `inspect_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 1,425 | — | — | 0.2 |
| 6 | 8 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.1 |
| 7 | 11 | `fit_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 661 | — | — | 0.9 |
| 8 | 11 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 222 | — | — | 0.0 |
| 9 | 12 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 954 | — | — | 1.0 |
| 10 | 15 | `predict_from_rk` | coeffs=[-3.98239e-06, -1.5386e-07, 1…, n_points=10… | 207 | — | — | 0.0 |
| | | **TOTAL (10 tools)** | | **16,163** | | **0** | **756.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,860 | 3,860 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 22,821 | 22,821 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 24,171 | 24,171 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 738 | 20,759 | 1,050 | 6.7 |
| 2 | L1-worker | claudeopus46 | 20,643 | 612 | 21,255 | 878 | 5.8 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,218 | 22,861 | 12,325 | 49.7 |
| 4 | L1-worker | claudeopus46 | 2,065 | 432 | 2,497 | 467 | 3.8 |
| 5 | L1-worker | claudeopus46 | 2,065 | 391 | 2,456 | 546 | 4.1 |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,765 | 23,408 | 6,979 | 35.3 |
| 7 | L1-worker | claudeopus46 | 20,643 | 10,365 | 31,008 | 782 | 8.6 |
| 8 | L1-worker | claudeopus46 | 2,065 | 4,479 | 6,544 | 1,616 | 14.2 |
| 9 | L1-worker | claudeopus46 | 20,643 | 11,426 | 32,069 | 8,190 | 39.7 |
| 10 | L1-worker | claudeopus46 | 20,643 | 20,237 | 40,880 | 3,238 | 16.2 |
| 11 | L1-worker | claudeopus46 | 536 | 2,869 | 3,405 | 1,020 | 7.4 |
| 12 | L1-worker | claudeopus46 | 1,356 | 2,989 | 4,345 | 1,043 | 8.3 |
| 13 | L1-worker | claudeopus46 | 298 | 1,425 | 1,723 | 1,031 | 3.7 |
| 14 | L1-worker | claudeopus46 | 1,323 | 7,836 | 9,159 | 4,639 | 18.9 |
| 15 | L1-worker | claudeopus46 | 298 | 5,361 | 5,659 | 3,639 | 13.7 |
| 16 | L1-worker | claudeopus46 | 1,160 | 13,125 | 14,285 | 3,270 | 14.5 |
| 17 | L0-main | claudeopus46 | 20,021 | 1,621 | 21,642 | 1,066 | 7.4 |
| 18 | L1-worker | claudeopus46 | 20,643 | 740 | 21,383 | 900 | 6.3 |
| 19 | L1-worker | claudeopus46 | 20,643 | 2,368 | 23,011 | 11,276 | 47.1 |
| 20 | L1-worker | claudeopus46 | 2,065 | 363 | 2,428 | 382 | 3.8 |
| 21 | L1-worker | claudeopus46 | 2,065 | 459 | 2,524 | 483 | 4.2 |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,841 | 23,484 | 4,561 | 25.3 |
| 23 | L1-worker | claudeopus46 | 20,643 | 8,023 | 28,666 | 2,060 | 8.4 |
| 24 | L1-worker | claudeopus46 | 536 | 1,857 | 2,393 | 630 | 3.6 |
| 25 | L1-worker | claudeopus46 | 1,356 | 1,977 | 3,333 | 724 | 3.7 |
| 26 | L1-worker | claudeopus46 | 1,323 | 4,993 | 6,316 | 3,992 | 16.0 |
| 27 | L1-worker | claudeopus46 | 298 | 4,714 | 5,012 | 3,234 | 11.9 |
| 28 | L1-worker | claudeopus46 | 1,160 | 9,950 | 11,110 | 199 | 3.3 |
| 29 | L1-worker | claudeopus46 | 747 | 7,497 | 8,244 | 1,003 | 8.3 |
| 30 | L0-main | claudeopus46 | 20,021 | 3,198 | 23,219 | 1,357 | 8.2 |
| 31 | L0-main | claudeopus46 | 19,988 | 5,196 | 25,184 | 653 | 5.1 |
| 32 | L0-main | claudeopus46 | 20,021 | 4,439 | 24,460 | 1,633 | 14.1 |
| 33 | L0-main | claudeopus46 | 20,021 | 14,496 | 34,517 | 1,400 | 11.0 |
| 34 | L0-main | claudeopus46 | 20,021 | 15,532 | 35,553 | 730 | 4.7 |
| 35 | L0-main | claudeopus46 | 20,021 | 16,477 | 36,498 | 843 | 5.3 |
| 36 | L0-main | claudeopus46 | 20,021 | 17,570 | 37,591 | 816 | 4.7 |
| 37 | L0-main | claudeopus46 | 20,021 | 20,694 | 40,715 | 1,877 | 14.3 |
| 38 | L0-main | claudeopus46 | 20,021 | 21,663 | 41,684 | 2,009 | 12.0 |
| 39 | L0-main | claudeopus46 | 20,021 | 22,626 | 42,647 | 2,169 | 13.1 |
| 40 | L0-main | claudeopus46 | 20,021 | 24,686 | 44,707 | 2,755 | 19.4 |
| 41 | L0-main | claudeopus46 | 19,988 | 28,354 | 48,342 | 379 | 7.2 |
| 42 | L0-main | claudeopus46 | 20,021 | 27,594 | 47,615 | 1,473 | 11.9 |
| 43 | L0-main | claudeopus46 | 20,021 | 28,264 | 48,285 | 704 | 5.0 |
| 44 | L0-main | claudeopus46 | 20,021 | 28,901 | 48,922 | 718 | 7.0 |
| 45 | L0-main | claudeopus46 | 19,988 | 29,799 | 49,787 | 373 | 5.2 |
| 46 | L0-main | claudeopus46 | 20,021 | 29,039 | 49,060 | 6,958 | 50.5 |
| 47 | L0-main | claudeopus46 | 1,356 | 3,936 | 5,292 | 1,098 | 7.0 |
| 48 | L0-main | claudeopus46 | 298 | 1,480 | 1,778 | 1,086 | 4.1 |
| 49 | L0-main | claudeopus46 | 1,323 | 37,867 | 39,190 | 2,117 | 17.4 |
| 50 | L0-main | claudeopus46 | 298 | 2,959 | 3,257 | 1,773 | 8.1 |
| 51 | L0-main | claudeopus46 | 1,562 | 6,841 | 8,403 | 1,016 | 8.9 |


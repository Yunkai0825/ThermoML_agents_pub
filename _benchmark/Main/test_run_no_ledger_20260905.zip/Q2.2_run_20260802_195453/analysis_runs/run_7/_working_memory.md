# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_7`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_4 | methanol | 4.070376e-05 |
| comp | GLOBcomp_1 | water | 1.8068301e-05 |
| prop | GLOBprop_28 | excessmolarvolumem3mol |  |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml_parallel]
- [run_query_agent]
- [inspect_block]
- [inspect_block]
- [fit_block]
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_volume'. Available: ['density_to_molar_volu
- [fit_block_derived]
- [predict_from_rk]

### Query Results
#### find_water — ERROR
no active StatsRecorder; start agent tracking first

#### find_methanol — ERROR
no active StatsRecorder; start agent tracking first

#### find_VE_property — ERROR
no active StatsRecorder; start agent tracking first

### Inspected Blocks
- GLOBlit_2395 | 10.1016/j.jct.2004.03.011 | PROPblock_1: 206 rows; x=['mole_fraction_<methanol>']; y=['excess_molar_volume_m3_mol']
    - BLKprop_1 / GLOBprop_28: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_28: kind=direct; materialize_reference=False; supported=True; units=m3/mol -> m3/mol
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10: 39 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.jct.2004.03.011/PROPblock_1 (methanol, water): RK order=0, R²=0.965353, RMSE=2.564482136309583e-08, coeffs=[-4e-06]
      response: direct via X = reported X | 0 reference source(s) | m3/mol -> m3/mol
      pure refs: methanol=0, water=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.png
  - 10.1016/j.jct.2007.05.004/PROPblock_10 (water, methanol): RK order=5, R²=0.999995, RMSE=6.883050222977911e-10, coeffs=[-4e-06, -0.0, 0.0, 0.0, 1e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: water=1.80683e-05, methanol=4.07038e-05 [block-edges of derived data (methanol: direct/good, water: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- `$ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- `$ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1


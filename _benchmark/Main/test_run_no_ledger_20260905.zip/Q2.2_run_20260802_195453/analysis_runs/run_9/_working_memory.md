# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_9`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_5 | propan-1-ol | 7.5157579e-05 |
| comp | GLOBcomp_1 | water | 1.8065584e-05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_2 | molefraction<propan-1-ol> |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| constr | GLOBconstr_2 | temperaturek |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_molar_volume'. Available: ['density_to_mola
- [fit_block_derived]
- [predict_from_rk]
- [list_session_files]

### Query Results
#### excess_volume — ERROR
no active StatsRecorder; start agent tracking first

#### density_data — ERROR
no active StatsRecorder; start agent tracking first

#### query
The ThermoML database contains 17 data blocks reporting mass density for the binary mixture of water (GLOBcomp_1) and 1-propanol (GLOBcomp_5, propan-1-ol, C₃H₈O) with temperature coverage spanning 298.15 K. The key block for deriving excess molar volume at 298.15 K is PROPblock_14 from DOI 10.1021/je700700f (GLOBlit_11042), which constrains temperature at 298.15 K and varies mole fraction (GLOBvar_2) across the full composition range (0–1) with 13 data points, making it directly suitable for computing excess molar volumes V^E(x) from measured density data. Several other blocks also have temperature fixed exactly at 298.15 K with composition as the independent variable.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_14 | declared | 13 | binary | binary |

### Inspected Blocks
- GLOBlit_11042 | 10.1021/je700700f | PROPblock_14: 13 rows; x=['mole_fraction_<propan-1-ol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1021/je700700f/PROPblock_14 (propan-1-ol, water): RK order=5, R²=0.999276, RMSE=4.602814010602905e-09, coeffs=[-3e-06, 1e-06, -1e-06, 0.0, -2e-06, 2e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: propan-1-ol=7.51576e-05, water=1.80656e-05 [block-edges of derived data (water: direct/good, propan-1-ol: direct/good)]
      fit_csv: $ROOT/data\10_1021_je700700f_BPROPblock_14_fit.csv
      excess_csv: $ROOT/data\10_1021_je700700f_BPROPblock_14_excess.csv
      fit_plot: $ROOT/plots\10_1021_je700700f_BPROPblock_14_fit.png
      excess_plot: $ROOT/plots\10_1021_je700700f_BPROPblock_14_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1021_je700700f_BPROPblock_14_fit.csv` — RK fit data — 10.1021/je700700f PROPblock_14
- `$ROOT/data\10_1021_je700700f_BPROPblock_14_excess.csv` — Excess property — 10.1021/je700700f PROPblock_14

### plot
- `$ROOT/plots\10_1021_je700700f_BPROPblock_14_fit.png` — RK fit plot — 10.1021/je700700f PROPblock_14
- `$ROOT/plots\10_1021_je700700f_BPROPblock_14_excess.png` — Excess plot — 10.1021/je700700f PROPblock_14


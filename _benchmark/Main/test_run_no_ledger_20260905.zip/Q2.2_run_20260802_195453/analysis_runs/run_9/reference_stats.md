# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:11:52
**Wall time (at last flush):** 601.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 25 | 405,158 | 343,877 | 44,203 | 749,035 | 29,961 | 280.0 | claudeopus46 |
| L1-worker | 23 | 202,947 | 93,938 | 70,985 | 296,885 | 12,908 | 338.7 | claudeopus46 |
| **TOTAL** | **48** | **608,105** | **437,815** | **115,188** | **1,045,920** | **21,790** | **618.7** | |

**Estimated tokens:** ~261,480 input + ~28,797 output = ~290,277 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 1 | 2 | 1 | 1 | 13 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **1** | **2** | **1** | **1** | **13** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_11042 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_5 | propan-1-ol | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | query_thermoml |
| GLOBconstr_2 | Temperature, K | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_134 | Mass density, kg/m3 | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Constraints | 2 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 13 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 13

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je700700f | 1 | 13 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je700700f | PROPblock_14 | declared | 13 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume_dir… | 132 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume', '… | 303 | — | — | 0.2 |
| 3 | 3 | `query_thermoml` | context=Looking for data to compute e…, instructio… | 422 | — | — | 171.5 |
| 4 | 4 | `query_thermoml` | context=Need density vs composition d…, instructio… | 8,359 | — | — | 157.6 |
| 5 | 7 | `inspect_block` | block_number=PROPblock_14, doi=10.1021/je700700f, … | 1,367 | — | — | 0.2 |
| 6 | 11 | `fit_block_derived` | block_number=PROPblock_14, composition_hint=mole_f… | 221 | — | — | 0.0 |
| 7 | 12 | `fit_block_derived` | block_number=PROPblock_14, composition_hint=mole_f… | 957 | — | — | 0.8 |
| 8 | 15 | `predict_from_rk` | coeffs=[-2.58261e-06, 6.379e-07, -7.…, mixing_rule… | 210 | — | — | 0.0 |
| 9 | 16 | `list_session_files` |  | 1,561 | — | — | 0.0 |
| | | **TOTAL (9 tools)** | | **13,532** | | **0** | **330.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,760 | 2,760 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 17,472 | 17,472 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 18,881 | 18,881 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 758 | 20,779 | 1,498 | 9.1 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,341 | 21,362 | 15,674 | 69.7 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,335 | 22,356 | 1,060 | 7.1 |
| 4 | L1-worker | claudeopus46 | 20,643 | 716 | 21,359 | 944 | 5.0 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,388 | 23,031 | 11,713 | 46.6 |
| 6 | L1-worker | claudeopus46 | 2,065 | 448 | 2,513 | 351 | 3.6 |
| 7 | L1-worker | claudeopus46 | 2,065 | 494 | 2,559 | 477 | 3.6 |
| 8 | L1-worker | claudeopus46 | 20,643 | 2,879 | 23,522 | 8,789 | 40.6 |
| 9 | L1-worker | claudeopus46 | 20,643 | 12,396 | 33,039 | 3,243 | 14.0 |
| 10 | L1-worker | claudeopus46 | 1,356 | 2,876 | 4,232 | 952 | 5.2 |
| 11 | L1-worker | claudeopus46 | 536 | 2,756 | 3,292 | 990 | 5.4 |
| 12 | L1-worker | claudeopus46 | 1,323 | 6,171 | 7,494 | 5,583 | 21.8 |
| 13 | L1-worker | claudeopus46 | 298 | 6,305 | 6,603 | 4,563 | 17.4 |
| 14 | L1-worker | claudeopus46 | 1,160 | 13,170 | 14,330 | 4,514 | 18.3 |
| 15 | L0-main | claudeopus46 | 19,988 | 4,015 | 24,003 | 591 | 5.0 |
| 16 | L0-main | claudeopus46 | 20,021 | 3,258 | 23,279 | 886 | 6.7 |
| 17 | L1-worker | claudeopus46 | 20,643 | 498 | 21,141 | 763 | 6.1 |
| 18 | L1-worker | claudeopus46 | 20,643 | 1,882 | 22,525 | 9,258 | 38.9 |
| 19 | L1-worker | claudeopus46 | 2,065 | 373 | 2,438 | 556 | 4.4 |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,104 | 22,747 | 11,356 | 52.5 |
| 21 | L1-worker | claudeopus46 | 2,065 | 11,814 | 13,879 | 1,985 | 15.8 |
| 22 | L1-worker | claudeopus46 | 20,610 | 4,100 | 24,710 | 485 | 5.7 |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,328 | 23,971 | 1,302 | 9.9 |
| 24 | L1-worker | claudeopus46 | 536 | 1,047 | 1,583 | 691 | 4.1 |
| 25 | L1-worker | claudeopus46 | 1,356 | 1,167 | 2,523 | 555 | 4.3 |
| 26 | L1-worker | claudeopus46 | 1,323 | 4,206 | 5,529 | 681 | 5.0 |
| 27 | L1-worker | claudeopus46 | 298 | 1,403 | 1,701 | 525 | 3.1 |
| 28 | L1-worker | claudeopus46 | 747 | 11,417 | 12,164 | 709 | 7.4 |
| 29 | L0-main | claudeopus46 | 20,021 | 13,163 | 33,184 | 895 | 8.9 |
| 30 | L0-main | claudeopus46 | 20,021 | 13,851 | 33,872 | 532 | 4.7 |
| 31 | L0-main | claudeopus46 | 20,021 | 14,530 | 34,551 | 516 | 4.0 |
| 32 | L0-main | claudeopus46 | 20,021 | 16,305 | 36,326 | 902 | 7.6 |
| 33 | L0-main | claudeopus46 | 20,021 | 17,050 | 37,071 | 816 | 7.7 |
| 34 | L0-main | claudeopus46 | 20,021 | 17,771 | 37,792 | 799 | 5.5 |
| 35 | L0-main | claudeopus46 | 20,021 | 18,581 | 38,602 | 761 | 4.6 |
| 36 | L0-main | claudeopus46 | 20,021 | 18,450 | 38,471 | 1,532 | 11.2 |
| 37 | L0-main | claudeopus46 | 19,988 | 22,027 | 42,015 | 497 | 5.6 |
| 38 | L0-main | claudeopus46 | 20,021 | 21,267 | 41,288 | 1,101 | 7.7 |
| 39 | L0-main | claudeopus46 | 20,021 | 21,972 | 41,993 | 810 | 5.2 |
| 40 | L0-main | claudeopus46 | 20,021 | 22,624 | 42,645 | 844 | 5.5 |
| 41 | L0-main | claudeopus46 | 19,988 | 23,531 | 43,519 | 463 | 5.9 |
| 42 | L0-main | claudeopus46 | 20,021 | 22,771 | 42,792 | 2,233 | 14.5 |
| 43 | L0-main | claudeopus46 | 20,021 | 24,803 | 44,824 | 6,966 | 49.0 |
| 44 | L0-main | claudeopus46 | 1,356 | 3,365 | 4,721 | 858 | 7.4 |
| 45 | L0-main | claudeopus46 | 1,323 | 30,835 | 32,158 | 1,145 | 9.5 |
| 46 | L0-main | claudeopus46 | 298 | 1,240 | 1,538 | 846 | 3.7 |
| 47 | L0-main | claudeopus46 | 298 | 1,987 | 2,285 | 901 | 4.6 |
| 48 | L0-main | claudeopus46 | 1,562 | 6,047 | 7,609 | 1,077 | 9.6 |


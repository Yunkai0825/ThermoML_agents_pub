# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.2_run_20260802_195453\analysis_runs\run_8`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_2 | ethanol | 5.8634339e-05 |
| comp | GLOBcomp_1 | water | 1.8449115e-05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<ethanol> |  |
| var | GLOBvar_3 | pressurekpa |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [fit_block_derived]
- [fit_block_derived]
- [predict_from_rk]
- [predict_from_rk]
- [list_session_files]

### Query Results
#### direct_VE — ERROR
no active StatsRecorder; start agent tracking first

#### density_data — ERROR
no active StatsRecorder; start agent tracking first

#### query
No binary water + ethanol excess molar volume data exists in the ThermoML database; the only VE block containing both components belongs to a ternary system (N,N-dimethylacetamide + ethanol + water) at 313.15 K. However, 22 binary water + ethanol blocks with mass density data near 298.15 K were identified. The best-covered sources are GLOBlit_220/PROPblock_2 (DOI 10.1016/j.fluid.2004.11.019, 25 points at exactly 298.15 K, x(ethanol) 0.003–0.800, ρ 810.9–995.3 kg/m³) and GLOBlit_5201/PROPblock_19 (DOI 10.1016/j.jct.2018.02.022, 15 points at 298.15 K, x(ethanol) 0.002–0.990, ρ 791.1–997.0 kg/m³). For Redlich-Kister VE fitting, excess molar volumes can be calculated from these density data using V^E = x₁M₁/ρ_mix + x₂M₂/ρ_mix − x₁M₁/ρ₁* − x₂M₂/ρ₂*, with pure-component densities from unary blocks or literature and molar masses of water (18.015 g/mol) and ethanol (46.069 g/mol).

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | binary |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | binary |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_12 | declared | 37 | binary | binary |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | binary |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | binary |
| GLOBlit_3475 | 10.1016/j.jct.2011.10.009 | PROPblock_3 | declared | 70 | binary | binary |
| GLOBlit_4415 | 10.1016/j.jct.2015.06.024 | PROPblock_7 | declared | 40 | binary | binary |

**Status:** partial

### Inspected Blocks
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19: 244 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2: 810 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.jct.2018.02.022/PROPblock_19 (ethanol, water): RK order=5, R²=0.99002, RMSE=3.7458122188924395e-08, coeffs=[-3e-06, 2e-06, -3e-06, -2e-06, 7e-06, 7e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: ethanol=5.82068e-05, water=1.81108e-05 [block-edges of derived data (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png
  - 10.1016/j.fluid.2004.11.019/PROPblock_2 (ethanol, water): RK order=5, R²=0.979248, RMSE=4.208680076125661e-08, coeffs=[-5e-06, 3e-06, -1e-06, -5e-06, -3e-06, 9e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: ethanol=5.86343e-05, water=1.84491e-05 [block-edges of derived data (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1


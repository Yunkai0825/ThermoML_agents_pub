# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:55:05
**Wall time (at last flush):** 1,051.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 22 | 345,095 | 214,389 | 38,124 | 559,484 | 25,431 | 258.1 | claudeopus46 |
| L1-worker | 46 | 369,951 | 315,595 | 170,423 | 685,546 | 14,903 | 828.8 | claudeopus46 |
| **TOTAL** | **68** | **715,046** | **529,984** | **208,547** | **1,245,030** | **18,309** | **1086.9** | |

**Estimated tokens:** ~311,257 input + ~52,136 output = ~363,393 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 132 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 299 | — | — | 0.1 |
| 3 | 3 | `query_thermoml` | context=Looking for GLOBprop_17 (exce…, instructio… | 209 | — | — | 291.7 |
| 4 | 4 | `query_thermoml` | context=Need density or excess molar …, instructio… | 1,347 | — | — | 231.9 |
| 5 | 5 | `query_thermoml` | context=Binary system water + ethanol…, id_catalog… | 164 | — | — | 0.0 |
| 6 | 6 | `query_thermoml` | context=Binary system water + ethanol…, id_catalog… | 233 | — | — | 0.0 |
| 7 | 7 | `query_thermoml` | context=Binary system water + ethanol…, id_catalog… | 282 | — | — | 276.0 |
| 8 | 10 | `inspect_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 1,376 | — | — | 0.2 |
| 9 | 10 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.2 |
| 10 | 11 | `fit_block_derived` | block_number=PROPblock_19, composition_hint=mole_f… | 961 | — | — | 1.1 |
| 11 | 11 | `fit_block_derived` | block_number=PROPblock_2, composition_hint=mole_fr… | 963 | — | — | 1.0 |
| 12 | 12 | `predict_from_rk` | coeffs=[-3.38039e-06, 2.37917e-06, -…, mixing_rule… | 206 | — | — | 0.0 |
| 13 | 12 | `predict_from_rk` | coeffs=[-4.98777e-06, 2.71547e-06, -…, mixing_rule… | 206 | — | — | 0.0 |
| 14 | 13 | `list_session_files` |  | 3,157 | — | — | 0.0 |
| | | **TOTAL (14 tools)** | | **10,909** | | **0** | **802.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,536 | 2,536 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 5,782 | 5,782 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 14,735 | 14,735 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 737 | 20,758 | 1,821 | 10.5 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,379 | 21,400 | 1,054 | 6.1 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,339 | 22,360 | 1,051 | 8.5 |
| 4 | L1-worker | claudeopus46 | 20,643 | 749 | 21,392 | 934 | 5.4 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,411 | 23,054 | 14,371 | 55.1 |
| 6 | L1-worker | claudeopus46 | 2,065 | 436 | 2,501 | 483 | 5.3 |
| 7 | L1-worker | claudeopus46 | 2,065 | 498 | 2,563 | 365 | 3.7 |
| 8 | L1-worker | claudeopus46 | 20,643 | 2,914 | 23,557 | 12,236 | 60.0 |
| 9 | L1-worker | claudeopus46 | 2,065 | 550 | 2,615 | 1,159 | 7.8 |
| 10 | L1-worker | claudeopus46 | 2,065 | 14,579 | 16,644 | 1,793 | 14.8 |
| 11 | L1-worker | claudeopus46 | 20,610 | 5,798 | 26,408 | 638 | 5.3 |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,026 | 25,669 | 8,174 | 46.4 |
| 13 | L1-worker | claudeopus46 | 20,643 | 13,836 | 34,479 | 3,784 | 22.2 |
| 14 | L1-worker | claudeopus46 | 1,356 | 3,648 | 5,004 | 858 | 6.7 |
| 15 | L1-worker | claudeopus46 | 536 | 3,528 | 4,064 | 1,123 | 9.4 |
| 16 | L1-worker | claudeopus46 | 1,323 | 9,288 | 10,611 | 6,613 | 23.6 |
| 17 | L1-worker | claudeopus46 | 298 | 7,335 | 7,633 | 5,416 | 19.9 |
| 18 | L1-worker | claudeopus46 | 1,160 | 17,521 | 18,681 | 5,292 | 20.2 |
| 19 | L0-main | claudeopus46 | 19,988 | 3,787 | 23,775 | 608 | 4.4 |
| 20 | L0-main | claudeopus46 | 20,021 | 3,030 | 23,051 | 1,003 | 7.9 |
| 21 | L1-worker | claudeopus46 | 20,643 | 565 | 21,208 | 1,094 | 6.1 |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,387 | 23,030 | 14,209 | 50.2 |
| 23 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 485 | 3.6 |
| 24 | L1-worker | claudeopus46 | 2,065 | 494 | 2,559 | 415 | 4.4 |
| 25 | L1-worker | claudeopus46 | 20,643 | 2,983 | 23,626 | 12,455 | 51.7 |
| 26 | L1-worker | claudeopus46 | 20,643 | 16,013 | 36,656 | 5,246 | 31.4 |
| 27 | L1-worker | claudeopus46 | 1,356 | 4,032 | 5,388 | 816 | 5.3 |
| 28 | L1-worker | claudeopus46 | 536 | 3,912 | 4,448 | 1,032 | 6.9 |
| 29 | L1-worker | claudeopus46 | 298 | 1,198 | 1,496 | 804 | 3.1 |
| 30 | L1-worker | claudeopus46 | 1,323 | 6,935 | 8,258 | 9,354 | 38.6 |
| 31 | L1-worker | claudeopus46 | 298 | 10,076 | 10,374 | 7,685 | 27.4 |
| 32 | L1-worker | claudeopus46 | 1,160 | 18,419 | 19,579 | 525 | 4.7 |
| 33 | L1-worker | claudeopus46 | 747 | 17,361 | 18,108 | 1,232 | 13.0 |
| 34 | L0-main | claudeopus46 | 20,021 | 4,881 | 24,902 | 1,614 | 12.6 |
| 35 | L0-main | claudeopus46 | 20,021 | 5,588 | 25,609 | 1,278 | 7.7 |
| 36 | L0-main | claudeopus46 | 19,988 | 7,108 | 27,096 | 467 | 4.1 |
| 37 | L0-main | claudeopus46 | 20,021 | 6,351 | 26,372 | 1,196 | 7.0 |
| 38 | L1-worker | claudeopus46 | 20,643 | 880 | 21,523 | 1,266 | 7.5 |
| 39 | L1-worker | claudeopus46 | 20,643 | 2,874 | 23,517 | 15,388 | 46.8 |
| 40 | L1-worker | claudeopus46 | 2,065 | 553 | 2,618 | 1,512 | 10.5 |
| 41 | L1-worker | claudeopus46 | 2,065 | 14,545 | 16,610 | 1,738 | 14.4 |
| 42 | L1-worker | claudeopus46 | 20,643 | 4,527 | 25,170 | 9,681 | 52.1 |
| 43 | L1-worker | claudeopus46 | 2,065 | 509 | 2,574 | 1,108 | 7.2 |
| 44 | L1-worker | claudeopus46 | 2,065 | 14,519 | 16,584 | 1,465 | 13.8 |
| 45 | L1-worker | claudeopus46 | 20,610 | 8,028 | 28,638 | 571 | 5.3 |
| 46 | L1-worker | claudeopus46 | 20,643 | 7,256 | 27,899 | 6,175 | 33.9 |
| 47 | L1-worker | claudeopus46 | 2,065 | 4,058 | 6,123 | 1,732 | 14.1 |
| 48 | L1-worker | claudeopus46 | 2,065 | 495 | 2,560 | 507 | 4.1 |
| 49 | L1-worker | claudeopus46 | 20,643 | 9,316 | 29,959 | 2,381 | 17.6 |
| 50 | L1-worker | claudeopus46 | 1,356 | 1,982 | 3,338 | 828 | 5.3 |
| 51 | L1-worker | claudeopus46 | 536 | 1,862 | 2,398 | 912 | 5.9 |
| 52 | L1-worker | claudeopus46 | 298 | 1,268 | 1,566 | 899 | 4.3 |
| 53 | L1-worker | claudeopus46 | 1,323 | 11,492 | 12,815 | 2,605 | 14.4 |
| 54 | L1-worker | claudeopus46 | 298 | 3,327 | 3,625 | 2,164 | 9.8 |
| 55 | L1-worker | claudeopus46 | 747 | 55,175 | 55,922 | 900 | 9.6 |
| 56 | L0-main | claudeopus46 | 20,021 | 9,005 | 29,026 | 1,143 | 9.6 |
| 57 | L0-main | claudeopus46 | 20,021 | 9,965 | 29,986 | 781 | 6.4 |
| 58 | L0-main | claudeopus46 | 20,021 | 10,939 | 30,960 | 673 | 4.3 |
| 59 | L0-main | claudeopus46 | 20,021 | 14,468 | 34,489 | 2,296 | 16.5 |
| 60 | L0-main | claudeopus46 | 20,021 | 20,044 | 40,065 | 1,653 | 10.4 |
| 61 | L0-main | claudeopus46 | 19,988 | 21,991 | 41,979 | 488 | 5.8 |
| 62 | L0-main | claudeopus46 | 20,021 | 21,231 | 41,252 | 8,753 | 55.8 |
| 63 | L0-main | claudeopus46 | 20,021 | 24,981 | 45,002 | 5,094 | 35.8 |
| 64 | L0-main | claudeopus46 | 1,356 | 5,223 | 6,579 | 1,051 | 8.1 |
| 65 | L0-main | claudeopus46 | 298 | 1,433 | 1,731 | 1,039 | 4.4 |
| 66 | L0-main | claudeopus46 | 1,323 | 30,780 | 32,103 | 2,216 | 14.4 |
| 67 | L0-main | claudeopus46 | 298 | 3,058 | 3,356 | 1,755 | 7.7 |
| 68 | L0-main | claudeopus46 | 1,562 | 6,071 | 7,633 | 1,090 | 10.1 |


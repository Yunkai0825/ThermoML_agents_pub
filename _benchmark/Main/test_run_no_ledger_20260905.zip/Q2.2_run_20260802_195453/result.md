# Main Agent Run — 20260802_202300 (Round 1)

**Question:** At 25 °C, which alcohol—methanol, ethanol, or 1-propanol—produces the greatest volume contraction when mixed with water, at what composition does it occur, and why does the behavior change with alcohol chain length?

**Time:** 1660.7s | **Iterations:** 2 | **Tools:** 1

---

## Answer

# Volume Contraction of Water + Alcohol Mixtures at 25 °C: Methanol vs. Ethanol vs. 1-Propanol

## Answer

**Methanol produces the greatest volume contraction when mixed with water at 25 °C**, with V^E_min ≈ −1.00 cm³/mol at x(methanol) ≈ 0.50. Ethanol is a close second at V^E_min ≈ −0.97 cm³/mol (near x(ethanol) ≈ 0.3–0.4), while 1-propanol shows the smallest contraction at V^E_min ≈ −0.66 cm³/mol, with the minimum shifted further toward the water-rich side.

---

## Quantitative Comparison

| System | V^E_min (cm³/mol) | x(alcohol) at minimum | RK Order | R² | n_points | Data route |
|--------|:------------------:|:---------------------:|:--------:|:---:|:--------:|:----------:|
| Water + Methanol | **−1.00** | ≈ 0.50 | 5 | 0.999995 | 11 | Density → V^E |
| Water + Ethanol | **−0.97** | ≈ 0.3–0.4 | 5 | 0.990 | 56 | Density → V^E |
| Water + 1-Propanol | **−0.66** | Water-rich region | 5 | 0.999 | 11 | Density → V^E |

All three systems exhibit **negative excess molar volumes** across the entire composition range, meaning the real mixture always occupies less volume than the ideal (mole-fraction-weighted) sum of the pure liquids.

---

## Redlich-Kister Coefficients (m³/mol)

### Water + Methanol (preferred fit)
| k | A_k |
|---|-----|
| 0 | −3.982 × 10⁻⁶ |
| 1 | −1.539 × 10⁻⁷ |
| 2 | +1.039 × 10⁻⁸ |
| 3 | +1.333 × 10⁻⁷ |
| 4 | +8.307 × 10⁻⁷ |
| 5 | +7.175 × 10⁻⁷ |

### Water + Ethanol (preferred fit)
| k | A_k |
|---|-----|
| 0 | −3.380 × 10⁻⁶ |
| 1 | +2.379 × 10⁻⁶ |
| 2 | −2.953 × 10⁻⁶ |
| 3 | −2.377 × 10⁻⁶ |
| 4 | +7.238 × 10⁻⁶ |
| 5 | +7.408 × 10⁻⁶ |

### Water + 1-Propanol
| k | A_k |
|---|-----|
| 0 | −2.583 × 10⁻⁶ |
| 1 | +6.379 × 10⁻⁷ |
| 2 | −7.305 × 10⁻⁷ |
| 3 | +1.434 × 10⁻⁷ |
| 4 | −2.038 × 10⁻⁶ |
| 5 | +1.668 × 10⁻⁶ |

Note: V^E(x₁) = x₁·x₂·Σ_k A_k·(x₁ − x₂)^k, where x₁ = alcohol mole fraction.

---

## Why Does Behavior Change with Alcohol Chain Length?

Three interconnected effects explain the systematic trend:

### 1. Hydrogen-bonding efficiency and molecular size matching
Methanol (CH₃OH) is the smallest alcohol and most structurally similar to water. It integrates almost seamlessly into water's three-dimensional hydrogen-bond network, forming strong O–H···O interactions with minimal steric disruption. This produces the most efficient molecular packing and the largest volume contraction. As the alkyl chain grows (ethanol → 1-propanol), the hydrophobic portion increasingly disrupts water's tetrahedral hydrogen-bond network, reducing the net packing efficiency and diminishing the magnitude of V^E_min.

### 2. Hydrophobic hydration and structural reorganization
Longer alkyl chains force water molecules to form ordered "cage-like" (clathrate-type) structures around the hydrophobic moiety. While this hydrophobic hydration does contribute some volume contraction (the cages are relatively compact), it also introduces structural strain that partially offsets the contraction from hydrogen bonding. For 1-propanol, the three-carbon chain demands substantial reorganization of the water network, resulting in a smaller net contraction (−0.66 cm³/mol) compared to methanol (−1.00 cm³/mol).

### 3. Shift of the minimum toward water-rich compositions
The composition at which maximum contraction occurs shifts systematically toward the water-rich side as chain length increases:
- **Methanol:** x_alcohol ≈ 0.50 (nearly symmetric)
- **Ethanol:** x_alcohol ≈ 0.3–0.4
- **1-Propanol:** shifted further into the water-rich region

This shift reflects the increasing asymmetry of the intermolecular interactions. A larger alcohol molecule requires more water molecules to solvate its hydrophobic tail, so the optimal packing occurs at higher water-to-alcohol ratios. Mathematically, this asymmetry is captured by the increasing importance of odd-order RK coefficients (especially A₁): for methanol, A₁ is small relative to A₀ (nearly symmetric curve), while for ethanol and propanol, A₁ is a significant fraction of A₀, skewing the V^E curve.

### Summary of the trend
| Property | CH₃OH → C₂H₅OH → C₃H₇OH |
|----------|---------------------------|
| |V^E_min| | Decreases: 1.00 → 0.97 → 0.66 cm³/mol |
| x_alcohol at min | Shifts water-rich: 0.50 → 0.3–0.4 → further water-rich |
| Curve symmetry | Decreases (A₁/A₀ ratio increases) |
| Dominant effect | H-bond packing → hydrophobic hydration competition |

---

## Data Sources

All V^E values were derived from measured mixture density data via the exact pointwise transform ρ(x) → V_m(x) → V^E(x), fitted with BIC-selected 5th-order Redlich-Kister polynomials.

| System | Literature ID | DOI | Block | Conditions |
|--------|--------------|-----|-------|------------|
| Water + Methanol | GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 | 298.15 K, 101 kPa, 11 mixture points |
| Water + Ethanol | GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 | 298.15 K, 92.3 kPa, 56 mixture points |
| Water + 1-Propanol | GLOBlit_11042 | 10.1021/je700700f | PROPblock_14 | 298.15 K, 101 kPa, 11 mixture points |

A cross-validation source for water + methanol (GLOBlit_2395 | DOI: 10.1016/j.jct.2004.03.011 | PROPblock_1) with direct V^E measurements yielded V^E_min = −0.988 cm³/mol at x(methanol) = 0.50, confirming the density-derived result within ~1%.

### Core claims

- At 25 °C, methanol produces the greatest volume contraction when mixed with water (V^E_min ≈ −1.00 cm³/mol at x_methanol ≈ 0.50), followed closely by ethanol (V^E_min ≈ −0.97 cm³/mol at x_ethanol ≈ 0.3–0.4), while 1-propanol shows the smallest contraction (V^E_min ≈ −0.66 cm³/mol in the water-rich region).
- All three water + alcohol systems exhibit negative excess molar volumes across the entire composition range, meaning the real mixture always occupies less volume than the ideal mole-fraction-weighted sum of the pure liquids.
- As alcohol alkyl chain length increases from methanol to 1-propanol, the composition at maximum contraction shifts systematically toward the water-rich side and the V^E curve becomes increasingly asymmetric, reflecting the growing dominance of hydrophobic hydration effects relative to hydrogen-bond packing.
- The decrease in \|V^E_min\| with increasing chain length is attributed to larger hydrophobic moieties disrupting water's hydrogen-bond network and forcing ordered cage-like hydration structures that partially offset the contraction from hydrogen bonding.
- All V^E values were derived from measured mixture density data and fitted with BIC-selected 5th-order Redlich-Kister polynomials; a cross-validation source for water + methanol confirmed the density-derived V^E_min within ~1%.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | Density data for water + methanol at 298.15 K (11 mixture points, 101 kPa), used to derive excess molar volume via pointwise transform. Yields V^E_min ≈ −1.00 cm³/mol at x(methanol) ≈ 0.50. |
| GLOBlit_2395 | 10.1016/j.jct.2004.03.011 | PROPblock_1 |  | Cross-validation source for water + methanol at 298.15 K with direct V^E measurements. Confirms V^E_min = −0.988 cm³/mol at x(methanol) = 0.50, consistent with the density-derived result within ~1%. |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 |  | Density data for water + ethanol at 298.15 K (56 mixture points, 92.3 kPa), used to derive excess molar volume. Yields V^E_min ≈ −0.97 cm³/mol at x(ethanol) ≈ 0.3–0.4. |
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_14 |  | Density data for water + 1-propanol at 298.15 K (11 mixture points, 101 kPa), used to derive excess molar volume. Yields V^E_min ≈ −0.66 cm³/mol in the water-rich region. |

---

## Verdict

**Strategy Quality**
The agent used `run_parallel_subagents` to query and analyze all three systems simultaneously—appropriate for independent binary mixtures. However, only one top-level parallel call appears in the trace (298 chars), making it difficult to confirm that both `run_query_agent` and `run_analysis_agent` were actually invoked for each system. The detailed DOIs, block IDs, and RK coefficients suggest real subagent outputs were received, but the trace is unusually compressed.

**Scientific Accuracy**
The reported values are physically reasonable and consistent with published literature: methanol–water V^E_min ≈ −1.0 cm³/mol near x ≈ 0.5, ethanol–water ≈ −1.0 cm³/mol near x ≈ 0.3–0.4, and 1-propanol–water ≈ −0.6 to −0.7 cm³/mol shifted water-rich. The mechanistic explanation (H-bond integration, hydrophobic hydration, asymmetry shift) is textbook-correct. One minor concern: the ethanol R² = 0.990 is notably lower than the others, possibly reflecting data scatter in the 56-point set, but this is acknowledged implicitly. Cross-validation with a second methanol source strengthens confidence.

**Overall Verdict**
The answer is comprehensive, quantitatively supported, and scientifically sound. The truncated trace prevents full verification that all subagent calls executed, but the specificity of DOIs, coefficients, and data counts strongly suggests genuine retrieval. Recommend exposing full subagent call traces in future for complete auditability. **PASS**.
# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 24 | 385,137 | 393,970 | 36,053 | 779,107 | 32,462 | 258.3 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| L1-worker | 27 | 227,146 | 132,312 | 79,107 | 359,458 | 13,313 | 385.8 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| L0-main | 22 | 345,095 | 214,389 | 38,124 | 559,484 | 25,431 | 258.1 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| L1-worker | 46 | 369,951 | 315,595 | 170,423 | 685,546 | 14,903 | 828.8 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| L0-main | 25 | 405,158 | 343,877 | 44,203 | 749,035 | 29,961 | 280.0 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| L1-worker | 23 | 202,947 | 93,938 | 70,985 | 296,885 | 12,908 | 338.7 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| **TOTAL** | **167** | **1,935,434** | **1,494,081** | **438,895** | **3,429,515** | **128,978** | **2,349.7** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| `query_thermoml` | 2 | 1 | 1 | 2 | 1 | 1 | 13 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| **TOTAL** | **2** | **1** | **1** | **2** | **1** | **1** | **13** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `query_thermoml` | context=Looking for GLOBprop that cor…, instructio… | 426 | — | — | 232.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 2 | 2 | `query_thermoml` | context=Looking for excess molar volu…, instructio… | 1,103 | — | — | 135.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 3 | 3 | `query_thermoml_parallel` | queries=[{'label': 'find_water', 'pur… | 418 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 4 | 4 | `run_query_agent` | context=Known reference IDs from syst…, purpose=Fi… | 9,387 | — | — | 385.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 5 | 8 | `inspect_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 1,425 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 6 | 8 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 7 | 11 | `fit_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 661 | — | — | 0.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 8 | 11 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 222 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 9 | 12 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 954 | — | — | 1.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 10 | 15 | `predict_from_rk` | coeffs=[-3.98239e-06, -1.5386e-07, 1…, n_points=10… | 207 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 132 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 299 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 3 | 3 | `query_thermoml` | context=Looking for GLOBprop_17 (exce…, instructio… | 209 | — | — | 291.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 4 | 4 | `query_thermoml` | context=Need density or excess molar …, instructio… | 1,347 | — | — | 231.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 5 | 5 | `query_thermoml` | context=Binary system water + ethanol…, id_catalog… | 164 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 6 | 6 | `query_thermoml` | context=Binary system water + ethanol…, id_catalog… | 233 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 7 | 7 | `query_thermoml` | context=Binary system water + ethanol…, id_catalog… | 282 | — | — | 276.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 8 | 10 | `inspect_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 1,376 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 9 | 10 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 10 | 11 | `fit_block_derived` | block_number=PROPblock_19, composition_hint=mole_f… | 961 | — | — | 1.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 11 | 11 | `fit_block_derived` | block_number=PROPblock_2, composition_hint=mole_fr… | 963 | — | — | 1.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 12 | 12 | `predict_from_rk` | coeffs=[-3.38039e-06, 2.37917e-06, -…, mixing_rule… | 206 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 13 | 12 | `predict_from_rk` | coeffs=[-4.98777e-06, 2.71547e-06, -…, mixing_rule… | 206 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 14 | 13 | `list_session_files` |  | 3,157 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume_dir… | 132 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume', '… | 303 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 3 | 3 | `query_thermoml` | context=Looking for data to compute e…, instructio… | 422 | — | — | 171.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 4 | 4 | `query_thermoml` | context=Need density vs composition d…, instructio… | 8,359 | — | — | 157.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 5 | 7 | `inspect_block` | block_number=PROPblock_14, doi=10.1021/je700700f, … | 1,367 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 6 | 11 | `fit_block_derived` | block_number=PROPblock_14, composition_hint=mole_f… | 221 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 7 | 12 | `fit_block_derived` | block_number=PROPblock_14, composition_hint=mole_f… | 957 | — | — | 0.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 8 | 15 | `predict_from_rk` | coeffs=[-2.58261e-06, 6.379e-07, -7.…, mixing_rule… | 210 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 9 | 16 | `list_session_files` |  | 1,561 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| **TOTAL** | **253** |  |  | **40,604** |  |  | **1,888.7** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,860 | 3,860 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 2 | interval=3 | skipped_by_agent | 22,821 | 22,821 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 3 | interval=3 | skipped_by_agent | 24,171 | 24,171 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 1 | interval=3 | skipped_by_agent | 2,536 | 2,536 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 2 | interval=3 | skipped_by_agent | 5,782 | 5,782 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 3 | interval=3 | skipped_by_agent | 14,735 | 14,735 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 1 | interval=3 | skipped_by_agent | 2,760 | 2,760 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 2 | interval=3 | skipped_by_agent | 17,472 | 17,472 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 3 | interval=3 | skipped_by_agent | 18,881 | 18,881 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| **TOTAL** |  |  | **113,018** | **113,018** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 20,021 | 738 | 20,759 | 1,050 | 6.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 2 | L1-worker | claudeopus46 | 20,643 | 612 | 21,255 | 878 | 5.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,218 | 22,861 | 12,325 | 49.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 4 | L1-worker | claudeopus46 | 2,065 | 432 | 2,497 | 467 | 3.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 5 | L1-worker | claudeopus46 | 2,065 | 391 | 2,456 | 546 | 4.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,765 | 23,408 | 6,979 | 35.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 7 | L1-worker | claudeopus46 | 20,643 | 10,365 | 31,008 | 782 | 8.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 8 | L1-worker | claudeopus46 | 2,065 | 4,479 | 6,544 | 1,616 | 14.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 9 | L1-worker | claudeopus46 | 20,643 | 11,426 | 32,069 | 8,190 | 39.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 10 | L1-worker | claudeopus46 | 20,643 | 20,237 | 40,880 | 3,238 | 16.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 11 | L1-worker | claudeopus46 | 536 | 2,869 | 3,405 | 1,020 | 7.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 12 | L1-worker | claudeopus46 | 1,356 | 2,989 | 4,345 | 1,043 | 8.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 13 | L1-worker | claudeopus46 | 298 | 1,425 | 1,723 | 1,031 | 3.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 14 | L1-worker | claudeopus46 | 1,323 | 7,836 | 9,159 | 4,639 | 18.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 15 | L1-worker | claudeopus46 | 298 | 5,361 | 5,659 | 3,639 | 13.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 16 | L1-worker | claudeopus46 | 1,160 | 13,125 | 14,285 | 3,270 | 14.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 17 | L0-main | claudeopus46 | 20,021 | 1,621 | 21,642 | 1,066 | 7.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 18 | L1-worker | claudeopus46 | 20,643 | 740 | 21,383 | 900 | 6.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 19 | L1-worker | claudeopus46 | 20,643 | 2,368 | 23,011 | 11,276 | 47.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 20 | L1-worker | claudeopus46 | 2,065 | 363 | 2,428 | 382 | 3.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 21 | L1-worker | claudeopus46 | 2,065 | 459 | 2,524 | 483 | 4.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,841 | 23,484 | 4,561 | 25.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 23 | L1-worker | claudeopus46 | 20,643 | 8,023 | 28,666 | 2,060 | 8.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 24 | L1-worker | claudeopus46 | 536 | 1,857 | 2,393 | 630 | 3.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 25 | L1-worker | claudeopus46 | 1,356 | 1,977 | 3,333 | 724 | 3.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 26 | L1-worker | claudeopus46 | 1,323 | 4,993 | 6,316 | 3,992 | 16.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 27 | L1-worker | claudeopus46 | 298 | 4,714 | 5,012 | 3,234 | 11.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 28 | L1-worker | claudeopus46 | 1,160 | 9,950 | 11,110 | 199 | 3.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 29 | L1-worker | claudeopus46 | 747 | 7,497 | 8,244 | 1,003 | 8.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 30 | L0-main | claudeopus46 | 20,021 | 3,198 | 23,219 | 1,357 | 8.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 31 | L0-main | claudeopus46 | 19,988 | 5,196 | 25,184 | 653 | 5.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 32 | L0-main | claudeopus46 | 20,021 | 4,439 | 24,460 | 1,633 | 14.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 33 | L0-main | claudeopus46 | 20,021 | 14,496 | 34,517 | 1,400 | 11.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 34 | L0-main | claudeopus46 | 20,021 | 15,532 | 35,553 | 730 | 4.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 35 | L0-main | claudeopus46 | 20,021 | 16,477 | 36,498 | 843 | 5.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 36 | L0-main | claudeopus46 | 20,021 | 17,570 | 37,591 | 816 | 4.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 37 | L0-main | claudeopus46 | 20,021 | 20,694 | 40,715 | 1,877 | 14.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 38 | L0-main | claudeopus46 | 20,021 | 21,663 | 41,684 | 2,009 | 12.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 39 | L0-main | claudeopus46 | 20,021 | 22,626 | 42,647 | 2,169 | 13.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 40 | L0-main | claudeopus46 | 20,021 | 24,686 | 44,707 | 2,755 | 19.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 41 | L0-main | claudeopus46 | 19,988 | 28,354 | 48,342 | 379 | 7.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 42 | L0-main | claudeopus46 | 20,021 | 27,594 | 47,615 | 1,473 | 11.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 43 | L0-main | claudeopus46 | 20,021 | 28,264 | 48,285 | 704 | 5.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 44 | L0-main | claudeopus46 | 20,021 | 28,901 | 48,922 | 718 | 7.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 45 | L0-main | claudeopus46 | 19,988 | 29,799 | 49,787 | 373 | 5.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 46 | L0-main | claudeopus46 | 20,021 | 29,039 | 49,060 | 6,958 | 50.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 47 | L0-main | claudeopus46 | 1,356 | 3,936 | 5,292 | 1,098 | 7.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 48 | L0-main | claudeopus46 | 298 | 1,480 | 1,778 | 1,086 | 4.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 49 | L0-main | claudeopus46 | 1,323 | 37,867 | 39,190 | 2,117 | 17.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 50 | L0-main | claudeopus46 | 298 | 2,959 | 3,257 | 1,773 | 8.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 51 | L0-main | claudeopus46 | 1,562 | 6,841 | 8,403 | 1,016 | 8.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_7) |
| 1 | L0-main | claudeopus46 | 20,021 | 737 | 20,758 | 1,821 | 10.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 2 | L0-main | claudeopus46 | 20,021 | 1,379 | 21,400 | 1,054 | 6.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 3 | L0-main | claudeopus46 | 20,021 | 2,339 | 22,360 | 1,051 | 8.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 4 | L1-worker | claudeopus46 | 20,643 | 749 | 21,392 | 934 | 5.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,411 | 23,054 | 14,371 | 55.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 6 | L1-worker | claudeopus46 | 2,065 | 436 | 2,501 | 483 | 5.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 7 | L1-worker | claudeopus46 | 2,065 | 498 | 2,563 | 365 | 3.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 8 | L1-worker | claudeopus46 | 20,643 | 2,914 | 23,557 | 12,236 | 60.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 9 | L1-worker | claudeopus46 | 2,065 | 550 | 2,615 | 1,159 | 7.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 10 | L1-worker | claudeopus46 | 2,065 | 14,579 | 16,644 | 1,793 | 14.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 11 | L1-worker | claudeopus46 | 20,610 | 5,798 | 26,408 | 638 | 5.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,026 | 25,669 | 8,174 | 46.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 13 | L1-worker | claudeopus46 | 20,643 | 13,836 | 34,479 | 3,784 | 22.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 14 | L1-worker | claudeopus46 | 1,356 | 3,648 | 5,004 | 858 | 6.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 15 | L1-worker | claudeopus46 | 536 | 3,528 | 4,064 | 1,123 | 9.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 16 | L1-worker | claudeopus46 | 1,323 | 9,288 | 10,611 | 6,613 | 23.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 17 | L1-worker | claudeopus46 | 298 | 7,335 | 7,633 | 5,416 | 19.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 18 | L1-worker | claudeopus46 | 1,160 | 17,521 | 18,681 | 5,292 | 20.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 19 | L0-main | claudeopus46 | 19,988 | 3,787 | 23,775 | 608 | 4.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 20 | L0-main | claudeopus46 | 20,021 | 3,030 | 23,051 | 1,003 | 7.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 21 | L1-worker | claudeopus46 | 20,643 | 565 | 21,208 | 1,094 | 6.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,387 | 23,030 | 14,209 | 50.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 23 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 485 | 3.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 24 | L1-worker | claudeopus46 | 2,065 | 494 | 2,559 | 415 | 4.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 25 | L1-worker | claudeopus46 | 20,643 | 2,983 | 23,626 | 12,455 | 51.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 26 | L1-worker | claudeopus46 | 20,643 | 16,013 | 36,656 | 5,246 | 31.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 27 | L1-worker | claudeopus46 | 1,356 | 4,032 | 5,388 | 816 | 5.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 28 | L1-worker | claudeopus46 | 536 | 3,912 | 4,448 | 1,032 | 6.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 29 | L1-worker | claudeopus46 | 298 | 1,198 | 1,496 | 804 | 3.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 30 | L1-worker | claudeopus46 | 1,323 | 6,935 | 8,258 | 9,354 | 38.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 31 | L1-worker | claudeopus46 | 298 | 10,076 | 10,374 | 7,685 | 27.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 32 | L1-worker | claudeopus46 | 1,160 | 18,419 | 19,579 | 525 | 4.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 33 | L1-worker | claudeopus46 | 747 | 17,361 | 18,108 | 1,232 | 13.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 34 | L0-main | claudeopus46 | 20,021 | 4,881 | 24,902 | 1,614 | 12.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 35 | L0-main | claudeopus46 | 20,021 | 5,588 | 25,609 | 1,278 | 7.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 36 | L0-main | claudeopus46 | 19,988 | 7,108 | 27,096 | 467 | 4.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 37 | L0-main | claudeopus46 | 20,021 | 6,351 | 26,372 | 1,196 | 7.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 38 | L1-worker | claudeopus46 | 20,643 | 880 | 21,523 | 1,266 | 7.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 39 | L1-worker | claudeopus46 | 20,643 | 2,874 | 23,517 | 15,388 | 46.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 40 | L1-worker | claudeopus46 | 2,065 | 553 | 2,618 | 1,512 | 10.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 41 | L1-worker | claudeopus46 | 2,065 | 14,545 | 16,610 | 1,738 | 14.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 42 | L1-worker | claudeopus46 | 20,643 | 4,527 | 25,170 | 9,681 | 52.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 43 | L1-worker | claudeopus46 | 2,065 | 509 | 2,574 | 1,108 | 7.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 44 | L1-worker | claudeopus46 | 2,065 | 14,519 | 16,584 | 1,465 | 13.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 45 | L1-worker | claudeopus46 | 20,610 | 8,028 | 28,638 | 571 | 5.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 46 | L1-worker | claudeopus46 | 20,643 | 7,256 | 27,899 | 6,175 | 33.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 47 | L1-worker | claudeopus46 | 2,065 | 4,058 | 6,123 | 1,732 | 14.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 48 | L1-worker | claudeopus46 | 2,065 | 495 | 2,560 | 507 | 4.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 49 | L1-worker | claudeopus46 | 20,643 | 9,316 | 29,959 | 2,381 | 17.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 50 | L1-worker | claudeopus46 | 1,356 | 1,982 | 3,338 | 828 | 5.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 51 | L1-worker | claudeopus46 | 536 | 1,862 | 2,398 | 912 | 5.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 52 | L1-worker | claudeopus46 | 298 | 1,268 | 1,566 | 899 | 4.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 53 | L1-worker | claudeopus46 | 1,323 | 11,492 | 12,815 | 2,605 | 14.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 54 | L1-worker | claudeopus46 | 298 | 3,327 | 3,625 | 2,164 | 9.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 55 | L1-worker | claudeopus46 | 747 | 55,175 | 55,922 | 900 | 9.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 56 | L0-main | claudeopus46 | 20,021 | 9,005 | 29,026 | 1,143 | 9.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 57 | L0-main | claudeopus46 | 20,021 | 9,965 | 29,986 | 781 | 6.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 58 | L0-main | claudeopus46 | 20,021 | 10,939 | 30,960 | 673 | 4.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 59 | L0-main | claudeopus46 | 20,021 | 14,468 | 34,489 | 2,296 | 16.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 60 | L0-main | claudeopus46 | 20,021 | 20,044 | 40,065 | 1,653 | 10.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 61 | L0-main | claudeopus46 | 19,988 | 21,991 | 41,979 | 488 | 5.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 62 | L0-main | claudeopus46 | 20,021 | 21,231 | 41,252 | 8,753 | 55.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 63 | L0-main | claudeopus46 | 20,021 | 24,981 | 45,002 | 5,094 | 35.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 64 | L0-main | claudeopus46 | 1,356 | 5,223 | 6,579 | 1,051 | 8.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 65 | L0-main | claudeopus46 | 298 | 1,433 | 1,731 | 1,039 | 4.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 66 | L0-main | claudeopus46 | 1,323 | 30,780 | 32,103 | 2,216 | 14.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 67 | L0-main | claudeopus46 | 298 | 3,058 | 3,356 | 1,755 | 7.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 68 | L0-main | claudeopus46 | 1,562 | 6,071 | 7,633 | 1,090 | 10.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_8) |
| 1 | L0-main | claudeopus46 | 20,021 | 758 | 20,779 | 1,498 | 9.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 2 | L0-main | claudeopus46 | 20,021 | 1,341 | 21,362 | 15,674 | 69.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 3 | L0-main | claudeopus46 | 20,021 | 2,335 | 22,356 | 1,060 | 7.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 4 | L1-worker | claudeopus46 | 20,643 | 716 | 21,359 | 944 | 5.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,388 | 23,031 | 11,713 | 46.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 6 | L1-worker | claudeopus46 | 2,065 | 448 | 2,513 | 351 | 3.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 7 | L1-worker | claudeopus46 | 2,065 | 494 | 2,559 | 477 | 3.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 8 | L1-worker | claudeopus46 | 20,643 | 2,879 | 23,522 | 8,789 | 40.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 9 | L1-worker | claudeopus46 | 20,643 | 12,396 | 33,039 | 3,243 | 14.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 10 | L1-worker | claudeopus46 | 1,356 | 2,876 | 4,232 | 952 | 5.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 11 | L1-worker | claudeopus46 | 536 | 2,756 | 3,292 | 990 | 5.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 12 | L1-worker | claudeopus46 | 1,323 | 6,171 | 7,494 | 5,583 | 21.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 13 | L1-worker | claudeopus46 | 298 | 6,305 | 6,603 | 4,563 | 17.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 14 | L1-worker | claudeopus46 | 1,160 | 13,170 | 14,330 | 4,514 | 18.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 15 | L0-main | claudeopus46 | 19,988 | 4,015 | 24,003 | 591 | 5.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 16 | L0-main | claudeopus46 | 20,021 | 3,258 | 23,279 | 886 | 6.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 17 | L1-worker | claudeopus46 | 20,643 | 498 | 21,141 | 763 | 6.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 18 | L1-worker | claudeopus46 | 20,643 | 1,882 | 22,525 | 9,258 | 38.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 19 | L1-worker | claudeopus46 | 2,065 | 373 | 2,438 | 556 | 4.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,104 | 22,747 | 11,356 | 52.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 21 | L1-worker | claudeopus46 | 2,065 | 11,814 | 13,879 | 1,985 | 15.8 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 22 | L1-worker | claudeopus46 | 20,610 | 4,100 | 24,710 | 485 | 5.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,328 | 23,971 | 1,302 | 9.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 24 | L1-worker | claudeopus46 | 536 | 1,047 | 1,583 | 691 | 4.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 25 | L1-worker | claudeopus46 | 1,356 | 1,167 | 2,523 | 555 | 4.3 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 26 | L1-worker | claudeopus46 | 1,323 | 4,206 | 5,529 | 681 | 5.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 27 | L1-worker | claudeopus46 | 298 | 1,403 | 1,701 | 525 | 3.1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 28 | L1-worker | claudeopus46 | 747 | 11,417 | 12,164 | 709 | 7.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 29 | L0-main | claudeopus46 | 20,021 | 13,163 | 33,184 | 895 | 8.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 30 | L0-main | claudeopus46 | 20,021 | 13,851 | 33,872 | 532 | 4.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 31 | L0-main | claudeopus46 | 20,021 | 14,530 | 34,551 | 516 | 4.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 32 | L0-main | claudeopus46 | 20,021 | 16,305 | 36,326 | 902 | 7.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 33 | L0-main | claudeopus46 | 20,021 | 17,050 | 37,071 | 816 | 7.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 34 | L0-main | claudeopus46 | 20,021 | 17,771 | 37,792 | 799 | 5.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 35 | L0-main | claudeopus46 | 20,021 | 18,581 | 38,602 | 761 | 4.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 36 | L0-main | claudeopus46 | 20,021 | 18,450 | 38,471 | 1,532 | 11.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 37 | L0-main | claudeopus46 | 19,988 | 22,027 | 42,015 | 497 | 5.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 38 | L0-main | claudeopus46 | 20,021 | 21,267 | 41,288 | 1,101 | 7.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 39 | L0-main | claudeopus46 | 20,021 | 21,972 | 41,993 | 810 | 5.2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 40 | L0-main | claudeopus46 | 20,021 | 22,624 | 42,645 | 844 | 5.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 41 | L0-main | claudeopus46 | 19,988 | 23,531 | 43,519 | 463 | 5.9 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 42 | L0-main | claudeopus46 | 20,021 | 22,771 | 42,792 | 2,233 | 14.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 43 | L0-main | claudeopus46 | 20,021 | 24,803 | 44,824 | 6,966 | 49.0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 44 | L0-main | claudeopus46 | 1,356 | 3,365 | 4,721 | 858 | 7.4 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 45 | L0-main | claudeopus46 | 1,323 | 30,835 | 32,158 | 1,145 | 9.5 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 46 | L0-main | claudeopus46 | 298 | 1,240 | 1,538 | 846 | 3.7 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 47 | L0-main | claudeopus46 | 298 | 1,987 | 2,285 | 901 | 4.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 48 | L0-main | claudeopus46 | 1,562 | 6,047 | 7,609 | 1,077 | 9.6 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| **TOTAL** |  |  | **1,935,434** | **1,494,081** | **3,429,515** | **438,895** | **2,349.7** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | ---: | --- | --- |
| GLOBlit_11042 |  | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBblocktype_1 |  | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBcomp_5 | propan-1-ol | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBcomp_1 | water | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBconstr_1 | Pressure, kPa | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBconstr_2 | Temperature, K | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBphase_1 |  | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBvar_2 | Mole fraction | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| GLOBmeas_134 | Mass density, kg/m3 | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| Unique References | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique Block_Types | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique Compounds | 2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique Constraints | 2 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique Phases | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique Variables | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique Properties | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique Measurements | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Unique parent blocks | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Explicit block/subsystem targets | 1 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Subsystem targets | 0 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| Target-matched data points | 13 | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |  |
| **TOTAL** | **25** |  |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | ---: | --- | ---: |
| 10.1021/je700700f | 1 | 13 | binary | query_thermoml | Find and fit excess molar volume (VE) data for the binary sy (analysis_runs/run_9) |
| 10.1021/je700700f | PROPblock_14 | declared | 13 | binary | 2 |
| **TOTAL** | **1** | **13** | **13** |  | **2** |

# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_4 | methanol | 0.0 |
| comp | GLOBcomp_1 | water | 0.0 |
| prop | GLOBprop_28 | excessmolarvolumem3mol |  |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| lit | GLOBlit_2395 | 10.1016/j.jct.2004.03.011 |  |
| lit | GLOBlit_2825 | 10.1016/j.jct.2007.05.004 |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_volume'. Available: ['density_to_molar_volu
- [fit_block] ERROR: Constraint column 'Temperature, K' not found in block
- [fit_block_derived]
- [fit_block]
- [predict_from_rk]
- [list_session_files]

### Query Results
#### excess_volume — ERROR
no active StatsRecorder; start agent tracking first

#### density_data — ERROR
no active StatsRecorder; start agent tracking first

#### query
Excess molar volume (VE, GLOBprop_28) data for methanol (GLOBcomp_4, CAS 67-56-1) + water (GLOBcomp_1, CAS 7732-18-5) at 298.15 K were identified. Direct VE measurements come from DOI 10.1016/j.jct.2004.03.011 (GLOBlit_2395, PROPblock_1) covering 298.15–348.15 K, 100–60000 kPa, at methanol mole fractions 0.25, 0.50, and 0.75 (206 total points), showing negative VE values indicative of volume contraction from hydrogen-bonding interactions. However, only three compositions limit Redlich-Kister fitting quality and most data are at elevated pressures. For fuller composition coverage, density data (GLOBprop_1) from DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825, PROPblock_10) span the entire mole-fraction range (0–1 in water mole fraction) at 293.15–303.15 K with 39 points, from which VE can be computed. The system exhibits a strongly negative VE minimum near x_methanol ≈ 0.3–0.4, on the order of −1 cm³/mol at 298.15 K, attributed to restructuring of water's hydrogen-bond network upon methanol incorporation.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2395 | 10.1016/j.jct.2004.03.011 | PROPblock_1 | declared | 206 | binary | binary |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | binary |

### Inspected Blocks
- GLOBlit_2395 | 10.1016/j.jct.2004.03.011 | PROPblock_1: 206 rows; x=['mole_fraction_<methanol>']; y=['excess_molar_volume_m3_mol']
    - BLKprop_1 / GLOBprop_28: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_28: kind=direct; materialize_reference=False; supported=True; units=m3/mol -> m3/mol
- GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10: 39 rows; x=['mole_fraction_<water>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.jct.2007.05.004/PROPblock_10 (water, methanol): RK order=5, R²=0.999995, RMSE=6.883050222977911e-10, coeffs=[-4e-06, -0.0, 0.0, 0.0, 1e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: water=1.80683e-05, methanol=4.07038e-05 [block-edges of derived data (methanol: direct/good, water: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png
  - 10.1016/j.jct.2004.03.011/PROPblock_1 (methanol, water): RK order=0, R²=0.965353, RMSE=2.564482136309583e-08, coeffs=[-4e-06]
      response: direct via X = reported X | 0 reference source(s) | m3/mol -> m3/mol
      pure refs: methanol=0, water=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- `$ROOT/data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- `$ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- `$ROOT/plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1


# Analysis Run — 20260802_202729 (Round 1)

**Question:** [Purpose: Determine the magnitude and composition of maximum volume contraction for methanol + water.]
Find and fit excess molar volume (VE) data for the binary mixture methanol + water at 25°C (298.15 K) and atmospheric pressure. Report the Redlich-Kister coefficients, the composition (mole fraction) at which VE is most negative, and the minimum VE value.

[Context: Looking for Excess molar volume or Volume of mixing for methanol (CH3OH) + water (H2O) at 298.15 K. The property may be listed as 'Excess molar volume' in ThermoML.]

**Time:** 494.4s | **Iterations:** 21 | **Tools:** 33

---

## Answer

# Excess Molar Volume (V^E) of Methanol + Water at 298.15 K

## Summary

The methanol–water system exhibits a strongly **negative excess molar volume** at 298.15 K, reflecting significant volume contraction upon mixing. This arises from the restructuring of water's open tetrahedral hydrogen-bond network as methanol molecules insert into it, producing more efficient molecular packing.

Two independent ThermoML data sources were fitted:

---

## Primary Result — Density-Derived V^E (DP2: exact pointwise transform)

**Source:** DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825), PROPblock_10  
**Method:** Measured mixture density ρ(x) → molar volume V_m(x) = (x₁M₁ + x₂M₂)/ρ → V^E via Redlich-Kister fit of the excess departure  
**Conditions:** T = 298.15 K, P = 101 kPa (atmospheric)  
**Data:** 11 mixture compositions + 2 pure endpoints (13 total), spanning the full mole-fraction range (x_water = 0 to 1)

### Pure-Component Molar Volumes (from block edge data)
| Component | V_m (m³/mol) | V_m (cm³/mol) |
|-----------|-------------|---------------|
| Water     | 1.80683 × 10⁻⁵ | 18.068 |
| Methanol  | 4.07038 × 10⁻⁵ | 40.704 |

### Redlich-Kister Coefficients (BIC-selected order = 5)

V^E(x₁, x₂) = x₁ · x₂ · Σₖ Aₖ · (x₁ − x₂)^k

where x₁ = mole fraction of water, x₂ = mole fraction of methanol.

| k | Aₖ (m³/mol) | Aₖ (cm³/mol) |
|---|-------------|---------------|
| 0 | −3.98239 × 10⁻⁶ | −3.982 |
| 1 | −1.5386 × 10⁻⁷  | −0.154 |
| 2 |  1.03864 × 10⁻⁸ |  0.010 |
| 3 |  1.33311 × 10⁻⁷ |  0.133 |
| 4 |  8.30673 × 10⁻⁷ |  0.831 |
| 5 |  7.17478 × 10⁻⁷ |  0.717 |

### Fit Quality
| Metric | Value |
|--------|-------|
| R²     | 0.999995 |
| RMSE   | 6.883 × 10⁻¹⁰ m³/mol |
| BIC    | −449.74 |

### BIC Model Comparison
| Order | BIC | R² | RMSE (m³/mol) |
|-------|-----|----|---------------|
| 0 | −386.91 | 0.9955 | 2.064 × 10⁻⁸ |
| 1 | −384.59 | 0.9956 | 2.058 × 10⁻⁸ |
| 2 | −392.37 | 0.9982 | 1.295 × 10⁻⁸ |
| 3 | −404.87 | 0.9995 | 6.580 × 10⁻⁹ |
| 4 | −423.77 | 0.9999 | 2.499 × 10⁻⁹ |
| **5** | **−449.74** | **0.999995** | **6.883 × 10⁻¹⁰** |

### Minimum V^E (Maximum Volume Contraction)

From the fitted RK polynomial (predict_from_rk):

- **V^E_min = −9.960 × 10⁻⁷ m³/mol ≈ −0.996 cm³/mol**
- **Composition at minimum: x_water ≈ 0.50 (x_methanol ≈ 0.50)**

The dominant A₀ coefficient (−3.982 cm³/mol) places the minimum near the equimolar composition. The small asymmetric terms (A₁ through A₅) introduce slight skewness but do not significantly shift the minimum from x = 0.5.

---

## Supporting Result — Direct V^E Measurement (DP0)

**Source:** DOI 10.1016/j.jct.2004.03.011 (GLOBlit_2395), PROPblock_1  
**Conditions:** T = 298.15 K, P = 100 kPa  
**Data:** Only 3 methanol mole fractions (0.25, 0.50, 0.75) — severely limits fitting resolution  
**Limitation:** With only 3 composition points, BIC selects a 0th-order (symmetric) RK polynomial.

### Redlich-Kister Coefficient
| k | Aₖ (m³/mol) | Aₖ (cm³/mol) |
|---|-------------|---------------|
| 0 | −3.95153 × 10⁻⁶ | −3.952 |

### Fit Quality
| Metric | Value |
|--------|-------|
| R²     | 0.965 |
| RMSE   | 2.564 × 10⁻⁸ m³/mol |
| BIC    | −98.87 |

This single-parameter fit yields V^E_min ≈ −0.988 cm³/mol at x_methanol = 0.50, consistent with the density-derived result.

---

## Cross-Validation

The two independent sources agree remarkably well:

| Parameter | Density-derived (DP2) | Direct V^E (DP0) |
|-----------|----------------------|-------------------|
| A₀ (cm³/mol) | −3.982 | −3.952 |
| V^E_min (cm³/mol) | −0.996 | −0.988 |
| x_methanol at min | ≈ 0.50 | 0.50 |

The ~0.8% difference in A₀ between the two independent datasets confirms the robustness of the result.

---

## Chemistry Insight

The strongly negative V^E of approximately **−1.0 cm³/mol** at equimolar composition reflects the well-known structural reorganization in methanol–water mixtures. Water's open, tetrahedrally coordinated hydrogen-bond network has significant void space; methanol molecules can partially fill these voids while maintaining hydrogen bonds through their hydroxyl groups, leading to a net volume contraction. The nearly symmetric V^E curve (A₀-dominated) indicates that this packing effect is roughly balanced between water-rich and methanol-rich compositions, though the higher-order terms in the 5th-order fit capture subtle asymmetry arising from the different molecular sizes and hydrogen-bonding geometries of the two components.

---

## Output Files

- **Fit data (density-derived):** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv`
- **Excess curve (density-derived):** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv`
- **Fit plot (density-derived):** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png`
- **Excess plot (density-derived):** `10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png`
- **Fit data (direct V^E):** `10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.csv`
- **Excess curve (direct V^E):** `10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.csv`
- **Fit plot (direct V^E):** `10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.png`
- **Excess plot (direct V^E):** `10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.png`

### Core claims

- The methanol–water system at 298.15 K and atmospheric pressure exhibits a strongly negative excess molar volume, with a minimum V^E of approximately −1.0 cm³/mol occurring near the equimolar composition (x_methanol ≈ 0.50).
- Two independent ThermoML data sources yield mutually consistent leading Redlich-Kister coefficients (A₀ ≈ −3.98 and −3.95 cm³/mol, differing by ~0.8%), confirming the robustness of the result.
- A BIC-selected 5th-order Redlich-Kister polynomial fitted to density-derived data (13 compositions) achieves R² = 0.999995; the dominant symmetric A₀ term places the V^E minimum near x = 0.5, with higher-order terms capturing only slight asymmetry.
- The negative excess molar volume is attributed to the restructuring of water's open tetrahedral hydrogen-bond network as methanol molecules insert into it, producing more efficient molecular packing.
- The direct V^E dataset contains only three compositions, limiting it to a 0th-order (symmetric) Redlich-Kister fit, which nonetheless agrees with the density-derived result.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_10 |  | Mass density (GLOBprop_1, kg/m3) for water (GLOBcomp_1) + methanol (GLOBcomp_4) binary at 293.15–303.15 K, P = 101 kPa, 39 data points with full composition coverage (x_water 0–1, 13 unique). Density transformed to molar volume via density_to_molar_volume; excess molar volume derived and fitted with Redlich-Kister polynomial (BIC-selected order 5). Primary result for VE analysis. |
| GLOBlit_2395 | 10.1016/j.jct.2004.03.011 | PROPblock_1 |  | Direct excess molar volume (GLOBprop_28, m3/mol) for methanol (GLOBcomp_4) + water (GLOBcomp_1) binary at 298.15–523.15 K, P = 100–60000 kPa, 206 total data points. Only 3 methanol mole fractions (0.25, 0.50, 0.75) at 298.15 K and 100 kPa; BIC selects 0th-order RK. Supporting result confirming A0 ≈ −3.95 × 10⁻⁶ m³/mol. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2825 | PROPblock_10 | excess molar volume | 5 | -3.98239e-06; -1.5386e-07; 1.03864e-08; 1.33311e-07; 8.30673e-07; 7.17478e-07 | 0.999995 | 6.88305e-10 | 11 | 298.15 | linear |  | 10.1016/j.jct.2007.05.004 |
| GLOBlit_2395 | PROPblock_1 | excess molar volume | 0 | -3.95153e-06 | 0.965353 | 2.56448e-08 | 3 | 298.15 | declared_excess_no_baseline |  | 10.1016/j.jct.2004.03.011 |

---

## Verdict

**Data Quality**
The agent used two ThermoML sources: one with direct V^E measurements (3 points) and one with density data transformed via `fit_block_derived` to obtain V^E (11 compositions + endpoints). The density-derived route is legitimate and correctly prioritized given its superior compositional coverage. Both `fit_block` and `fit_block_derived` calls appear in the trace, confirming no fabrication. Composition basis is mole fraction throughout. No agent-built data were used.

**Fit Quality**
The 5th-order RK fit (R² = 0.999995) is BIC-selected, which mitigates overfitting concerns despite the high order for 13 points. The 3-point direct V^E dataset appropriately yielded only a 0th-order fit. Cross-validation between datasets strengthens confidence.

**Scientific Verdict**
V^E_min ≈ −1.0 cm³/mol near x_methanol ≈ 0.50 is consistent with established literature values (typically −0.95 to −1.05 cm³/mol). The cross-validated A₀ agreement (~0.8% difference) is excellent. Results are reliable and well-documented. **PASS.**

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\data\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\plots\10_1016_j_jct_2007_05_004_BPROPblock_10_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2007.05.004 PROPblock_10_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\data\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_10\plots\10_1016_j_jct_2004_03_011_BPROPblock_1_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2004.03.011 PROPblock_1_T298.1
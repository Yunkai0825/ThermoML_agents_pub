# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:18:41
**Wall time (at last flush):** 527.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 28 | 484,944 | 756,907 | 44,281 | 1,241,851 | 44,351 | 318.5 | claudeopus46 |
| L1-worker | 16 | 118,065 | 78,394 | 39,608 | 196,459 | 12,278 | 224.7 | claudeopus46 |
| **TOTAL** | **44** | **603,009** | **835,301** | **83,889** | **1,438,310** | **32,688** | **543.2** | |

**Estimated tokens:** ~359,577 input + ~20,972 output = ~380,549 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 2 | 3 | 1 | 2 | 2 | 245 |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **2** | **3** | **1** | **2** | **2** | **245** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2395 |  | query_thermoml |
| GLOBlit_2825 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_4 | methanol | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_3 | Pressure, kPa | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_28 | Excess molar volume, m3/mol | query_thermoml |
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_207 | Excess molar volume, m3/mol | query_thermoml |
| GLOBmeas_134 | Mass density, kg/m3 | query_thermoml |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 2 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Variables | 3 |
| Unique Phases | 1 |
| Unique Properties | 2 |
| Unique Measurements | 2 |
| Unique Constraints | 1 |
| Total DOIs | 2 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 245 |

---

## 3. DOI & Block References

**Unique DOIs:** 2  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 245

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2004.03.011 | 1 | 206 | binary | query_thermoml |
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2004.03.011 | PROPblock_1 | declared | 206 | binary | 2 | query_thermoml |
| 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume_dir… | 132 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume', '… | 303 | — | — | 0.1 |
| 3 | 3 | `query_thermoml` | context=Looking for GLOBprop excess m…, instructio… | 17,599 | — | — | 211.0 |
| 4 | 6 | `inspect_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 1,425 | — | — | 0.1 |
| 5 | 6 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.1 |
| 6 | 10 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 288 | — | — | 0.0 |
| 7 | 10 | `fit_block` | block_number=PROPblock_1, composition_hint=mole_fr… | 321 | — | — | 0.0 |
| 8 | 14 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 222 | — | — | 0.0 |
| 9 | 14 | `fit_block` | block_number=PROPblock_1, composition_hint=mole_fr… | 141 | — | — | 0.1 |
| 10 | 16 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 954 | — | — | 0.9 |
| 11 | 16 | `fit_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 661 | — | — | 0.8 |
| 12 | 18 | `predict_from_rk` | coeffs=[-3.98239e-06, -1.5386e-07, 1…, n_points=10… | 207 | — | — | 0.0 |
| 13 | 20 | `list_session_files` |  | 3,150 | — | — | 0.0 |
| | | **TOTAL (13 tools)** | | **26,763** | | **0** | **213.1** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 19,954 | 19,954 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 24,235 | 24,235 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 33,274 | 33,274 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 741 | 20,762 | 1,739 | 9.7 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,402 | 21,423 | 1,171 | 7.1 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,371 | 22,392 | 998 | 6.6 |
| 4 | L1-worker | claudeopus46 | 20,643 | 707 | 21,350 | 983 | 6.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,418 | 23,061 | 13,756 | 54.5 |
| 6 | L1-worker | claudeopus46 | 2,065 | 433 | 2,498 | 488 | 3.7 |
| 7 | L1-worker | claudeopus46 | 2,065 | 637 | 2,702 | 598 | 6.9 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,093 | 23,736 | 8,386 | 45.7 |
| 9 | L1-worker | claudeopus46 | 2,065 | 4,430 | 6,495 | 1,681 | 16.4 |
| 10 | L1-worker | claudeopus46 | 2,065 | 7,006 | 9,071 | 1,691 | 13.9 |
| 11 | L1-worker | claudeopus46 | 2,065 | 7,216 | 9,281 | 1,789 | 13.7 |
| 12 | L1-worker | claudeopus46 | 20,610 | 6,191 | 26,801 | 422 | 3.9 |
| 13 | L1-worker | claudeopus46 | 20,643 | 5,419 | 26,062 | 3,301 | 20.9 |
| 14 | L1-worker | claudeopus46 | 1,356 | 2,469 | 3,825 | 875 | 6.1 |
| 15 | L1-worker | claudeopus46 | 536 | 2,349 | 2,885 | 1,042 | 6.9 |
| 16 | L1-worker | claudeopus46 | 1,323 | 8,064 | 9,387 | 1,676 | 9.1 |
| 17 | L1-worker | claudeopus46 | 298 | 1,398 | 1,696 | 1,029 | 4.2 |
| 18 | L1-worker | claudeopus46 | 298 | 2,398 | 2,696 | 1,291 | 5.4 |
| 19 | L1-worker | claudeopus46 | 747 | 24,166 | 24,913 | 600 | 6.9 |
| 20 | L0-main | claudeopus46 | 19,988 | 22,964 | 42,952 | 392 | 4.9 |
| 21 | L0-main | claudeopus46 | 20,021 | 22,205 | 42,226 | 1,728 | 13.5 |
| 22 | L0-main | claudeopus46 | 20,021 | 23,248 | 43,269 | 634 | 4.9 |
| 23 | L0-main | claudeopus46 | 20,021 | 24,169 | 44,190 | 602 | 4.5 |
| 24 | L0-main | claudeopus46 | 19,988 | 28,229 | 48,217 | 402 | 4.7 |
| 25 | L0-main | claudeopus46 | 20,021 | 27,470 | 47,491 | 2,617 | 17.9 |
| 26 | L0-main | claudeopus46 | 20,021 | 28,581 | 48,602 | 2,011 | 12.7 |
| 27 | L0-main | claudeopus46 | 20,021 | 29,539 | 49,560 | 1,722 | 10.5 |
| 28 | L0-main | claudeopus46 | 20,021 | 30,570 | 50,591 | 1,248 | 7.5 |
| 29 | L0-main | claudeopus46 | 20,021 | 30,443 | 50,464 | 973 | 6.5 |
| 30 | L0-main | claudeopus46 | 20,021 | 31,346 | 51,367 | 1,216 | 7.8 |
| 31 | L0-main | claudeopus46 | 20,021 | 32,252 | 52,273 | 1,314 | 11.7 |
| 32 | L0-main | claudeopus46 | 20,021 | 33,230 | 53,251 | 1,143 | 7.7 |
| 33 | L0-main | claudeopus46 | 20,021 | 32,981 | 53,002 | 2,115 | 13.3 |
| 34 | L0-main | claudeopus46 | 20,021 | 33,984 | 54,005 | 1,247 | 10.9 |
| 35 | L0-main | claudeopus46 | 20,021 | 38,459 | 58,480 | 1,200 | 12.0 |
| 36 | L0-main | claudeopus46 | 20,021 | 39,216 | 59,237 | 719 | 5.4 |
| 37 | L0-main | claudeopus46 | 19,988 | 40,406 | 60,394 | 438 | 4.9 |
| 38 | L0-main | claudeopus46 | 20,021 | 39,646 | 59,667 | 1,887 | 16.0 |
| 39 | L0-main | claudeopus46 | 20,021 | 42,147 | 62,168 | 393 | 3.7 |
| 40 | L0-main | claudeopus46 | 20,021 | 45,198 | 65,219 | 10,589 | 73.9 |
| 41 | L0-main | claudeopus46 | 1,356 | 5,337 | 6,693 | 1,067 | 7.4 |
| 42 | L0-main | claudeopus46 | 1,323 | 59,527 | 60,850 | 2,047 | 15.5 |
| 43 | L0-main | claudeopus46 | 298 | 2,889 | 3,187 | 1,631 | 8.0 |
| 44 | L0-main | claudeopus46 | 1,562 | 8,357 | 9,919 | 1,038 | 9.3 |


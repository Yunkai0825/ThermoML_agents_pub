# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_13`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_15 | acetonitrile | 5.2854719e-05 |
| comp | GLOBcomp_18 | dimethylformamide | 7.7436558e-05 |
| prop | GLOBprop_28 | excess molar volume, m3/mol |  |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<dimethylformamide> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_molar_volume'. Available: ['density_to_mola
- [fit_block_derived] ERROR: Unknown transform 'density_to_excess_molar_volume'. Available: ['density_to_mola
- [fit_block_derived] ERROR: Constraint column 'Temperature, K' not found
- [fit_block_derived] ERROR: Constraint column 'Temperature, K' not found
- [fit_block_derived]
- [fit_block_derived]
- [predict_from_rk]
- [list_session_files]

### Query Results
#### excess_volume — ERROR
no active StatsRecorder; start agent tracking first

#### density_data — ERROR
no active StatsRecorder; start agent tracking first

#### query
For the binary mixture of acetonitrile and N,N-dimethylformamide at 298.15 K, no direct excess molar volume data was found in the ThermoML database. However, mass density data are available from three independent sources covering the full composition range. PROPblock_7 (DOI 10.1016/j.jct.2006.01.015, pycnometry, 5 points at 101.0 kPa) gives densities from 944.6 kg/m³ (pure DMF) to 776.8 kg/m³ (pure acetonitrile). PROPblock_5 (DOI 10.1016/j.jct.2014.02.019, vibrating tube densimetry, 3 points at 101.0 kPa) reports data as a function of DMF mass fraction. PROPblock_16 (DOI 10.1021/acs.jced.8b00176, vibrating tube densimetry, 5 points at 100.0 kPa) reports data as a function of DMF mole fraction. Excess molar volumes can be derived from these density data using the standard relation involving mixture and pure-component densities.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2659 | 10.1016/j.jct.2006.01.015 | PROPblock_7 | declared | 102 | binary | binary |
| GLOBlit_4124 | 10.1016/j.jct.2014.02.019 | PROPblock_5 | declared | 20 | binary | binary |
| GLOBlit_7481 | 10.1021/acs.jced.8b00176 | PROPblock_16 | declared | 66 | binary | binary |

**Status:** partial

### Inspected Blocks
- GLOBlit_2659 | 10.1016/j.jct.2006.01.015 | PROPblock_7: 102 rows; x=['mole_fraction_<acetonitrile>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_7481 | 10.1021/acs.jced.8b00176 | PROPblock_16: 66 rows; x=['mole_fraction_<dimethylformamide>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.jct.2006.01.015/PROPblock_7 (acetonitrile, dimethylformamide): RK order=5, R²=0.999362, RMSE=2.1877523782449646e-09, coeffs=[-1e-06, -1e-06, -0.0, 0.0, 0.0, -0.0]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: acetonitrile=5.28489e-05, dimethylformamide=7.7382e-05 [block-edges of derived data (dimethylformamide: direct/good, acetonitrile: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_excess.png
  - 10.1021/acs.jced.8b00176/PROPblock_16 (dimethylformamide, acetonitrile): RK order=1, R²=0.688065, RMSE=7.876929228732568e-08, coeffs=[-2e-06, 1e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: dimethylformamide=7.74366e-05, acetonitrile=5.28547e-05 [block-edges of derived data (acetonitrile: direct/good, dimethylformamide: direct/good)]
      fit_csv: $ROOT/data\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2006.01.015 PROPblock_7_T298.1
- `$ROOT/data\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2006.01.015 PROPblock_7_T298.1
- `$ROOT/data\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_fit.csv` — RK fit data — 10.1021/acs.jced.8b00176 PROPblock_16_T298.1
- `$ROOT/data\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_excess.csv` — Excess property — 10.1021/acs.jced.8b00176 PROPblock_16_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2006.01.015 PROPblock_7_T298.1
- `$ROOT/plots\10_1016_j_jct_2006_01_015_BPROPblock_7_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2006.01.015 PROPblock_7_T298.1
- `$ROOT/plots\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_fit.png` — RK fit plot — 10.1021/acs.jced.8b00176 PROPblock_16_T298.1
- `$ROOT/plots\10_1021_acs_jced_8b00176_BPROPblock_16_T298.1_excess.png` — Excess plot — 10.1021/acs.jced.8b00176 PROPblock_16_T298.1


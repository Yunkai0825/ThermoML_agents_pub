# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:27:29
**Wall time (at last flush):** 500.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 29 | 504,899 | 898,985 | 49,800 | 1,403,884 | 48,409 | 349.8 | claudeopus46 |
| L1-worker | 14 | 115,735 | 68,414 | 27,376 | 184,149 | 13,153 | 154.3 | claudeopus46 |
| **TOTAL** | **43** | **620,634** | **967,399** | **77,176** | **1,588,033** | **36,931** | **504.1** | |

**Estimated tokens:** ~397,008 input + ~19,294 output = ~416,302 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 3 | 1 | 3 | 3 | 188 |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **1** | **3** | **1** | **3** | **3** | **188** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2659 |  | query_thermoml |
| GLOBlit_4124 |  | query_thermoml |
| GLOBlit_7481 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_18 | dimethylformamide | query_thermoml |
| GLOBcomp_15 | acetonitrile | query_thermoml |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |
| GLOBvar_5 | Mass fraction | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_153 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_2 | Mass density, kg/m3 | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 3 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Constraints | 1 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 188 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 188

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.01.015 | 1 | 102 | binary | query_thermoml |
| 10.1016/j.jct.2014.02.019 | 1 | 20 | binary | query_thermoml |
| 10.1021/acs.jced.8b00176 | 1 | 66 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.01.015 | PROPblock_7 | declared | 102 | binary | 2 | query_thermoml |
| 10.1016/j.jct.2014.02.019 | PROPblock_5 | declared | 20 | binary | 2 | query_thermoml |
| 10.1021/acs.jced.8b00176 | PROPblock_16 | declared | 66 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume_dir… | 132 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume', '… | 303 | — | — | 0.1 |
| 3 | 3 | `query_thermoml` | context=Looking for VE or density dat…, instructio… | 21,908 | — | — | 153.1 |
| 4 | 6 | `inspect_block` | block_number=PROPblock_7, doi=10.1016/j.jct.2006.0… | 1,393 | — | — | 0.2 |
| 5 | 6 | `inspect_block` | block_number=PROPblock_16, doi=10.1021/acs.jced.8b… | 1,405 | — | — | 0.2 |
| 6 | 9 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 227 | — | — | 0.0 |
| 7 | 9 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 227 | — | — | 0.0 |
| 8 | 13 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 288 | — | — | 0.0 |
| 9 | 13 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 288 | — | — | 0.0 |
| 10 | 15 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 132 | — | — | 0.1 |
| 11 | 15 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 132 | — | — | 0.1 |
| 12 | 16 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 1,004 | — | — | 0.9 |
| 13 | 16 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 946 | — | — | 0.9 |
| 14 | 17 | `predict_from_rk` | coeffs=[-1.13034e-06, -7.63893e-07, …, mixing_rule… | 221 | — | — | 0.0 |
| 15 | 18 | `list_session_files` |  | 3,142 | — | — | 0.0 |
| | | **TOTAL (15 tools)** | | **31,748** | | **0** | **155.6** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 24,247 | 24,247 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 28,588 | 28,588 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 30,842 | 30,842 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 35,037 | 35,037 | 0 | 0.0% |
| 5 | interval=3 | skipped_by_agent | 42,079 | 42,079 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 797 | 20,818 | 1,798 | 10.9 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,390 | 21,411 | 1,268 | 6.9 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,349 | 22,370 | 966 | 8.1 |
| 4 | L1-worker | claudeopus46 | 20,643 | 635 | 21,278 | 977 | 5.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,340 | 22,983 | 8,903 | 40.5 |
| 6 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 474 | 4.0 |
| 7 | L1-worker | claudeopus46 | 2,065 | 488 | 2,553 | 402 | 3.6 |
| 8 | L1-worker | claudeopus46 | 20,643 | 2,803 | 23,446 | 4,966 | 26.3 |
| 9 | L1-worker | claudeopus46 | 20,643 | 3,917 | 24,560 | 1,138 | 6.4 |
| 10 | L1-worker | claudeopus46 | 2,065 | 581 | 2,646 | 1,161 | 8.6 |
| 11 | L1-worker | claudeopus46 | 2,065 | 7,072 | 9,137 | 1,616 | 13.2 |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,771 | 26,414 | 2,173 | 13.0 |
| 13 | L1-worker | claudeopus46 | 1,356 | 1,854 | 3,210 | 677 | 4.5 |
| 14 | L1-worker | claudeopus46 | 536 | 1,734 | 2,270 | 852 | 5.3 |
| 15 | L1-worker | claudeopus46 | 1,323 | 8,865 | 10,188 | 1,804 | 8.4 |
| 16 | L1-worker | claudeopus46 | 298 | 2,526 | 2,824 | 1,372 | 5.6 |
| 17 | L1-worker | claudeopus46 | 747 | 29,343 | 30,090 | 861 | 9.2 |
| 18 | L0-main | claudeopus46 | 19,988 | 27,103 | 47,091 | 476 | 5.6 |
| 19 | L0-main | claudeopus46 | 20,021 | 26,344 | 46,365 | 1,563 | 12.2 |
| 20 | L0-main | claudeopus46 | 20,021 | 27,370 | 47,391 | 756 | 5.3 |
| 21 | L0-main | claudeopus46 | 20,021 | 28,406 | 48,427 | 787 | 5.1 |
| 22 | L0-main | claudeopus46 | 19,988 | 32,411 | 52,399 | 397 | 4.8 |
| 23 | L0-main | claudeopus46 | 20,021 | 31,652 | 51,673 | 1,991 | 12.7 |
| 24 | L0-main | claudeopus46 | 20,021 | 32,713 | 52,734 | 1,289 | 7.5 |
| 25 | L0-main | claudeopus46 | 20,021 | 33,779 | 53,800 | 1,376 | 7.7 |
| 26 | L0-main | claudeopus46 | 19,988 | 34,960 | 54,948 | 488 | 4.5 |
| 27 | L0-main | claudeopus46 | 20,021 | 34,201 | 54,222 | 2,232 | 15.7 |
| 28 | L0-main | claudeopus46 | 20,021 | 35,260 | 55,281 | 1,430 | 9.6 |
| 29 | L0-main | claudeopus46 | 20,021 | 36,234 | 56,255 | 1,287 | 8.0 |
| 30 | L0-main | claudeopus46 | 20,021 | 37,283 | 57,304 | 1,235 | 8.3 |
| 31 | L0-main | claudeopus46 | 20,021 | 37,090 | 57,111 | 1,231 | 7.2 |
| 32 | L0-main | claudeopus46 | 20,021 | 38,156 | 58,177 | 1,273 | 7.5 |
| 33 | L0-main | claudeopus46 | 19,988 | 39,454 | 59,442 | 560 | 4.8 |
| 34 | L0-main | claudeopus46 | 20,021 | 38,694 | 58,715 | 1,304 | 7.3 |
| 35 | L0-main | claudeopus46 | 20,021 | 44,262 | 64,283 | 2,079 | 15.4 |
| 36 | L0-main | claudeopus46 | 20,021 | 45,090 | 65,111 | 3,221 | 24.4 |
| 37 | L0-main | claudeopus46 | 19,988 | 49,509 | 69,497 | 411 | 5.7 |
| 38 | L0-main | claudeopus46 | 20,021 | 48,749 | 68,770 | 10,795 | 76.3 |
| 39 | L0-main | claudeopus46 | 20,021 | 59,944 | 79,965 | 3,022 | 27.9 |
| 40 | L0-main | claudeopus46 | 1,356 | 3,151 | 4,507 | 1,107 | 8.5 |
| 41 | L0-main | claudeopus46 | 1,323 | 60,994 | 62,317 | 2,403 | 13.8 |
| 42 | L0-main | claudeopus46 | 298 | 3,245 | 3,543 | 1,928 | 8.4 |
| 43 | L0-main | claudeopus46 | 1,562 | 8,395 | 9,957 | 1,127 | 9.7 |


# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.4_run_20260802_201829\analysis_runs\run_11`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_1 | water | 1.8110836e-05 |
| comp | GLOBcomp_2 | ethanol | 5.8206813e-05 |
| prop | GLOBprop_1 | massdensitykgm3 |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_3 | pressurekpa |  |
| var | GLOBvar_2 | molefraction<ethanol> |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| lit | GLOBlit_220 | 10.1016/j.fluid.2004.11.019 |  |
| lit | GLOBlit_5201 | 10.1016/j.jct.2018.02.022 |  |

### History
- [query_thermoml_parallel]
- [query_thermoml]
- [inspect_block]
- [inspect_block]
- [fit_block_derived]
- [fit_block_derived]
- [predict_from_rk]
- [predict_from_rk]

### Query Results
#### direct_VE — ERROR
no active StatsRecorder; start agent tracking first

#### density_backup — ERROR
no active StatsRecorder; start agent tracking first

#### query
Binary mixture density data for ethanol + water at 298.15 K were identified in ThermoML. The top candidate is DOI 10.1016/j.fluid.2004.11.019 (GLOBlit_220, PROPblock_2), providing 810 mass-density data points at exactly 298.15 K and 100 kPa over ethanol mole fractions 0.003–0.7996, with systematic composition spacing ideal for excess molar volume calculations. A complementary dataset is DOI 10.1016/j.jct.2018.02.022 (GLOBlit_5201, PROPblock_19), with 244 points at 293.15–298.15 K covering ethanol mole fractions 0.0024–0.9895, extending coverage to nearly pure ethanol. The GLOBlit_220 block is preferred for V^E computation because it densely covers the composition region where V^E is most negative (near x ≈ 0.3–0.4).

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | binary |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | binary |

### Inspected Blocks
- GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2: 810 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19: 244 rows; x=['mole_fraction_<ethanol>']; y=['mass_density_kg_m3']
    - BLKprop_1 / GLOBprop_1: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_1: kind=direct; materialize_reference=False; supported=True; units=kg/m3 -> kg/m3

### Completed Fits
  - 10.1016/j.fluid.2004.11.019/PROPblock_2 (ethanol, water): RK order=5, R²=0.979248, RMSE=4.208680076125661e-08, coeffs=[-5e-06, 3e-06, -1e-06, -5e-06, -3e-06, 9e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: ethanol=5.86343e-05, water=1.84491e-05 [block-edges of derived data (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png
  - 10.1016/j.jct.2018.02.022/PROPblock_19 (ethanol, water): RK order=5, R²=0.99002, RMSE=3.7458122188924395e-08, coeffs=[-3e-06, 2e-06, -3e-06, -2e-06, 7e-06, 7e-06]
      response: direct via X = reported X | 0 reference source(s) | kg/m3 -> kg/m3
      route: measured-derived (density_to_molar_volume, exact pointwise) via density_to_molar_volume
      pure refs: ethanol=5.82068e-05, water=1.81108e-05 [block-edges of derived data (water: direct/good, ethanol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.csv` — RK fit data — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/data\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.csv` — Excess property — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1

### plot
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_fit.png` — RK fit plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/plots\10_1016_j_fluid_2004_11_019_BPROPblock_2_T298.1_excess.png` — Excess plot — 10.1016/j.fluid.2004.11.019 PROPblock_2_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_19_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_19_T298.1


# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:18:41
**Wall time (at last flush):** 887.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 21 | 325,074 | 310,174 | 31,850 | 635,248 | 30,249 | 213.6 | claudeopus46 |
| L1-worker | 45 | 408,576 | 240,194 | 129,666 | 648,770 | 14,417 | 671.3 | claudeopus46 |
| **TOTAL** | **66** | **733,650** | **550,368** | **161,516** | **1,284,018** | **19,454** | **884.9** | |

**Estimated tokens:** ~321,004 input + ~40,379 output = ~361,383 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 2 | 1 | 3 | 1 | 2 | 2 | 1,054 |
| **TOTAL** | **2** | **1** | **3** | **1** | **2** | **2** | **1,054** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_220 |  | query_thermoml |
| GLOBlit_5201 |  | query_thermoml |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 | ethanol | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_3 | Pressure, kPa | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_138 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_2 | Mass density, kg/m3 | query_thermoml |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 2 |
| Unique Block_Types | 1 |
| Unique Compounds | 2 |
| Unique Variables | 3 |
| Unique Phases | 1 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Unique Constraints | 1 |
| Total DOIs | 2 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 1,054 |

---

## 3. DOI & Block References

**Unique DOIs:** 2  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 1,054

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | query_thermoml |
| 10.1016/j.jct.2018.02.022 | 1 | 244 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | 2 | query_thermoml |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 132 | — | — | 0.0 |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 301 | — | — | 0.1 |
| 3 | 3 | `query_thermoml` | context=Looking for GLOBprop_17-like …, instructio… | 1,185 | — | — | 243.7 |
| 4 | 4 | `query_thermoml` | context=Need binary mixture data for …, id_catalog… | 164 | — | — | 0.0 |
| 5 | 5 | `query_thermoml` | context=Need binary ethanol+water mix…, id_catalog… | 233 | — | — | 0.0 |
| 6 | 6 | `query_thermoml` | context=Need binary mixture density d…, id_catalog… | 358 | — | — | 260.8 |
| 7 | 7 | `query_thermoml` | context=Goal: fit excess molar volume…, instructio… | 16,126 | — | — | 175.4 |
| 8 | 10 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.1 |
| 9 | 10 | `inspect_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 1,376 | — | — | 0.2 |
| 10 | 11 | `fit_block_derived` | block_number=PROPblock_2, composition_hint=mole_fr… | 963 | — | — | 1.0 |
| 11 | 11 | `fit_block_derived` | block_number=PROPblock_19, composition_hint=mole_f… | 961 | — | — | 1.0 |
| 12 | 12 | `predict_from_rk` | coeffs=[-4.98777e-06, 2.71547e-06, -…, n_points=20… | 206 | — | — | 0.0 |
| 13 | 12 | `predict_from_rk` | coeffs=[-3.38039e-06, 2.37917e-06, -…, n_points=20… | 206 | — | — | 0.0 |
| | | **TOTAL (13 tools)** | | **23,585** | | **0** | **682.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,525 | 3,525 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 5,716 | 5,716 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 30,541 | 30,541 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 739 | 20,760 | 1,627 | 9.1 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,387 | 21,408 | 1,119 | 6.4 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,351 | 22,372 | 1,008 | 7.4 |
| 4 | L1-worker | claudeopus46 | 20,643 | 712 | 21,355 | 956 | 8.1 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,396 | 23,039 | 16,121 | 51.1 |
| 6 | L1-worker | claudeopus46 | 2,065 | 441 | 2,506 | 491 | 3.7 |
| 7 | L1-worker | claudeopus46 | 2,065 | 645 | 2,710 | 649 | 5.1 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,058 | 23,701 | 9,479 | 44.0 |
| 9 | L1-worker | claudeopus46 | 2,065 | 578 | 2,643 | 1,162 | 8.1 |
| 10 | L1-worker | claudeopus46 | 2,065 | 14,537 | 16,602 | 1,858 | 17.7 |
| 11 | L1-worker | claudeopus46 | 20,610 | 5,968 | 26,578 | 541 | 4.7 |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,196 | 25,839 | 795 | 6.0 |
| 13 | L1-worker | claudeopus46 | 20,643 | 6,566 | 27,209 | 4,185 | 24.2 |
| 14 | L1-worker | claudeopus46 | 2,065 | 472 | 2,537 | 1,193 | 7.9 |
| 15 | L1-worker | claudeopus46 | 20,643 | 7,448 | 28,091 | 2,534 | 16.7 |
| 16 | L1-worker | claudeopus46 | 1,356 | 1,622 | 2,978 | 568 | 3.9 |
| 17 | L1-worker | claudeopus46 | 536 | 1,502 | 2,038 | 628 | 4.5 |
| 18 | L1-worker | claudeopus46 | 1,323 | 8,580 | 9,903 | 1,081 | 6.5 |
| 19 | L1-worker | claudeopus46 | 298 | 1,803 | 2,101 | 821 | 4.1 |
| 20 | L1-worker | claudeopus46 | 1,160 | 10,020 | 11,180 | 749 | 4.7 |
| 21 | L1-worker | claudeopus46 | 747 | 15,599 | 16,346 | 1,080 | 8.7 |
| 22 | L0-main | claudeopus46 | 19,988 | 4,779 | 24,767 | 617 | 5.1 |
| 23 | L0-main | claudeopus46 | 20,021 | 4,022 | 24,043 | 1,243 | 8.5 |
| 24 | L0-main | claudeopus46 | 20,021 | 4,711 | 24,732 | 1,395 | 8.7 |
| 25 | L0-main | claudeopus46 | 20,021 | 5,432 | 25,453 | 1,462 | 9.6 |
| 26 | L1-worker | claudeopus46 | 20,643 | 1,137 | 21,780 | 1,318 | 9.7 |
| 27 | L1-worker | claudeopus46 | 20,643 | 3,183 | 23,826 | 13,351 | 49.2 |
| 28 | L1-worker | claudeopus46 | 2,065 | 391 | 2,456 | 493 | 3.8 |
| 29 | L1-worker | claudeopus46 | 2,065 | 14,525 | 16,590 | 1,721 | 13.6 |
| 30 | L1-worker | claudeopus46 | 20,643 | 4,155 | 24,798 | 8,547 | 48.3 |
| 31 | L1-worker | claudeopus46 | 20,643 | 5,129 | 25,772 | 699 | 4.7 |
| 32 | L1-worker | claudeopus46 | 2,065 | 544 | 2,609 | 1,724 | 11.4 |
| 33 | L1-worker | claudeopus46 | 20,643 | 6,352 | 26,995 | 7,672 | 46.0 |
| 34 | L1-worker | claudeopus46 | 20,643 | 14,645 | 35,288 | 4,232 | 22.8 |
| 35 | L1-worker | claudeopus46 | 536 | 3,129 | 3,665 | 864 | 6.3 |
| 36 | L1-worker | claudeopus46 | 1,356 | 3,249 | 4,605 | 1,084 | 8.9 |
| 37 | L1-worker | claudeopus46 | 1,323 | 10,998 | 12,321 | 4,133 | 16.6 |
| 38 | L1-worker | claudeopus46 | 298 | 4,855 | 5,153 | 3,086 | 12.0 |
| 39 | L1-worker | claudeopus46 | 1,160 | 15,809 | 16,969 | 3,013 | 12.6 |
| 40 | L0-main | claudeopus46 | 19,988 | 7,045 | 27,033 | 574 | 4.6 |
| 41 | L0-main | claudeopus46 | 20,021 | 6,288 | 26,309 | 1,226 | 8.8 |
| 42 | L1-worker | claudeopus46 | 20,643 | 811 | 21,454 | 1,009 | 7.0 |
| 43 | L1-worker | claudeopus46 | 20,643 | 2,548 | 23,191 | 14,155 | 55.5 |
| 44 | L1-worker | claudeopus46 | 2,065 | 519 | 2,584 | 692 | 5.4 |
| 45 | L1-worker | claudeopus46 | 2,065 | 350 | 2,415 | 414 | 4.1 |
| 46 | L1-worker | claudeopus46 | 20,643 | 3,229 | 23,872 | 7,494 | 40.3 |
| 47 | L1-worker | claudeopus46 | 2,065 | 14,567 | 16,632 | 1,767 | 14.5 |
| 48 | L1-worker | claudeopus46 | 20,610 | 5,374 | 25,984 | 529 | 4.7 |
| 49 | L1-worker | claudeopus46 | 20,643 | 4,602 | 25,245 | 2,155 | 14.0 |
| 50 | L1-worker | claudeopus46 | 1,356 | 1,852 | 3,208 | 792 | 4.7 |
| 51 | L1-worker | claudeopus46 | 536 | 1,732 | 2,268 | 739 | 5.2 |
| 52 | L1-worker | claudeopus46 | 1,323 | 6,263 | 7,586 | 1,443 | 7.2 |
| 53 | L1-worker | claudeopus46 | 298 | 2,165 | 2,463 | 1,084 | 6.7 |
| 54 | L1-worker | claudeopus46 | 747 | 20,938 | 21,685 | 565 | 6.4 |
| 55 | L0-main | claudeopus46 | 20,021 | 24,318 | 44,339 | 1,562 | 13.0 |
| 56 | L0-main | claudeopus46 | 20,021 | 25,364 | 45,385 | 762 | 4.7 |
| 57 | L0-main | claudeopus46 | 20,021 | 26,319 | 46,340 | 739 | 4.7 |
| 58 | L0-main | claudeopus46 | 20,021 | 29,599 | 49,620 | 2,356 | 15.8 |
| 59 | L0-main | claudeopus46 | 20,021 | 35,362 | 55,383 | 1,352 | 10.1 |
| 60 | L0-main | claudeopus46 | 19,988 | 37,258 | 57,246 | 392 | 6.0 |
| 61 | L0-main | claudeopus46 | 20,021 | 36,498 | 56,519 | 6,914 | 46.3 |
| 62 | L0-main | claudeopus46 | 1,356 | 4,184 | 5,540 | 1,279 | 7.4 |
| 63 | L0-main | claudeopus46 | 1,323 | 43,900 | 45,223 | 2,107 | 11.5 |
| 64 | L0-main | claudeopus46 | 298 | 1,661 | 1,959 | 1,267 | 4.4 |
| 65 | L0-main | claudeopus46 | 298 | 2,949 | 3,247 | 1,646 | 7.9 |
| 66 | L0-main | claudeopus46 | 1,562 | 6,008 | 7,570 | 1,203 | 13.6 |


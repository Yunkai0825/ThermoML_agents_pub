# Reference Stats — main-agent

**Run started:** 2026-08-02 20:18:29
**Wall time (at last flush):** 1,122.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 24,654 | 56,012 | 17,792 | 80,666 | 11,523 | 105.2 | claudeopus46 |
| **TOTAL** | **7** | **24,654** | **56,012** | **17,792** | **80,666** | **11,523** | **105.2** | |

**Estimated tokens:** ~20,166 input + ~4,448 output = ~24,614 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_parallel_subagents` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_parallel_subagents` | tasks=[{'agent': 'analysis', 'label… | 298 | — | — | 1028.4 |
| | | **TOTAL (1 tools)** | | **298** | | **0** | **1028.4** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 468 | 10,683 | 2,757 | 12.3 |
| 2 | L0-main | claudeopus46 | 10,215 | 28,467 | 38,682 | 8,091 | 52.5 |
| 3 | L0-main | claudeopus46 | 1,356 | 6,941 | 8,297 | 1,063 | 7.3 |
| 4 | L0-main | claudeopus46 | 1,323 | 9,957 | 11,280 | 1,770 | 10.4 |
| 5 | L0-main | claudeopus46 | 298 | 1,445 | 1,743 | 1,051 | 3.9 |
| 6 | L0-main | claudeopus46 | 298 | 2,293 | 2,591 | 1,614 | 7.1 |
| 7 | L0-main | claudeopus46 | 949 | 6,441 | 7,390 | 1,446 | 11.7 |


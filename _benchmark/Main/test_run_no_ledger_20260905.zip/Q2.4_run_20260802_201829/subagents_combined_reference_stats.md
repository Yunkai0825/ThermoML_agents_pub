# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 28 | 484,944 | 756,907 | 44,281 | 1,241,851 | 44,351 | 318.5 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| L1-worker | 16 | 118,065 | 78,394 | 39,608 | 196,459 | 12,278 | 224.7 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| L0-main | 21 | 325,074 | 310,174 | 31,850 | 635,248 | 30,249 | 213.6 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| L1-worker | 45 | 408,576 | 240,194 | 129,666 | 648,770 | 14,417 | 671.3 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| L0-main | 29 | 504,899 | 898,985 | 49,800 | 1,403,884 | 48,409 | 349.8 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| L1-worker | 14 | 115,735 | 68,414 | 27,376 | 184,149 | 13,153 | 154.3 | claudeopus46 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| **TOTAL** | **153** | **1,957,293** | **2,353,068** | **322,581** | **4,310,361** | **162,857** | **1,932.2** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| `query_thermoml` | 2 | 2 | 3 | 1 | 2 | 2 | 245 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| `fit_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| `query_thermoml` | 2 | 1 | 3 | 1 | 2 | 2 | 1,054 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| `query_thermoml` | 2 | 1 | 3 | 1 | 3 | 3 | 188 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| `fit_block_derived` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| **TOTAL** | **6** | **4** | **9** | **3** | **7** | **7** | **1,487** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique References | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique Block_Types | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique Compounds | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique Variables | 3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique Phases | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique Properties | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique Measurements | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique Constraints | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Unique parent blocks | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Explicit block/subsystem targets | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Subsystem targets | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| Target-matched data points | 245 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| GLOBlit_220 |  | query_thermoml |
| GLOBlit_5201 |  | query_thermoml |
| GLOBblocktype_1 |  | query_thermoml |
| GLOBcomp_2 | ethanol | query_thermoml |
| GLOBcomp_1 | water | query_thermoml |
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_3 | Pressure, kPa | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |
| GLOBphase_1 |  | query_thermoml |
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_138 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_2 | Mass density, kg/m3 | query_thermoml |
| GLOBconstr_1 | Pressure, kPa | query_thermoml |
| Unique References | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique Block_Types | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique Compounds | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique Variables | 3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique Phases | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique Properties | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique Measurements | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique Constraints | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Unique parent blocks | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Explicit block/subsystem targets | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Subsystem targets | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| Target-matched data points | 1,054 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| GLOBlit_2659 |  | query_thermoml |
| GLOBlit_4124 |  | query_thermoml |
| GLOBlit_7481 |  | query_thermoml |
| GLOBblocktype_1 |  | query_thermoml |
| GLOBcomp_18 | dimethylformamide | query_thermoml |
| GLOBcomp_15 | acetonitrile | query_thermoml |
| GLOBconstr_1 | Pressure, kPa | query_thermoml |
| GLOBphase_1 |  | query_thermoml |
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_2 | Mole fraction | query_thermoml |
| GLOBvar_5 | Mass fraction | query_thermoml |
| GLOBprop_1 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_153 | Mass density, kg/m3 | query_thermoml |
| GLOBmeas_2 | Mass density, kg/m3 | query_thermoml |
| Unique References | 3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique Block_Types | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique Compounds | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique Constraints | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique Phases | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique Variables | 3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique Properties | 1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique Measurements | 2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Unique parent blocks | 3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Explicit block/subsystem targets | 3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Subsystem targets | 0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| Target-matched data points | 188 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| **TOTAL** | **1,542** |  |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | ---: | ---: | ---: | --- | ---: | --- | --- |
| 10.1016/j.jct.2004.03.011 | PROPblock_1 | declared | 206 | binary | 2 | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | 2 | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |  |  |
| 10.1016/j.jct.2018.02.022 | 1 | 244 | binary | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |  |  |
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | 2 | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | 2 | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 10.1016/j.jct.2006.01.015 | 1 | 102 | binary | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |  |  |
| 10.1016/j.jct.2014.02.019 | 1 | 20 | binary | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |  |  |
| 10.1021/acs.jced.8b00176 | 1 | 66 | binary | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |  |  |
| 10.1016/j.jct.2006.01.015 | PROPblock_7 | declared | 102 | binary | 2 | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 10.1016/j.jct.2014.02.019 | PROPblock_5 | declared | 20 | binary | 2 | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 10.1021/acs.jced.8b00176 | PROPblock_16 | declared | 66 | binary | 2 | query_thermoml | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| **TOTAL** | **5** | **1,242** | **1,487** |  | **14** |  |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume_dir… | 132 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume', '… | 303 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 3 | 3 | `query_thermoml` | context=Looking for GLOBprop excess m…, instructio… | 17,599 | — | — | 211.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 4 | 6 | `inspect_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 1,425 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 5 | 6 | `inspect_block` | block_number=PROPblock_10, doi=10.1016/j.jct.2007.… | 1,360 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 6 | 10 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 288 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 7 | 10 | `fit_block` | block_number=PROPblock_1, composition_hint=mole_fr… | 321 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 8 | 14 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 222 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 9 | 14 | `fit_block` | block_number=PROPblock_1, composition_hint=mole_fr… | 141 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 10 | 16 | `fit_block_derived` | block_number=PROPblock_10, composition_hint=mole_f… | 954 | — | — | 0.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 11 | 16 | `fit_block` | block_number=PROPblock_1, doi=10.1016/j.jct.2004.0… | 661 | — | — | 0.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 12 | 18 | `predict_from_rk` | coeffs=[-3.98239e-06, -1.5386e-07, 1…, n_points=10… | 207 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 13 | 20 | `list_session_files` |  | 3,150 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 132 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'direct_VE', 'purp… | 301 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 3 | 3 | `query_thermoml` | context=Looking for GLOBprop_17-like …, instructio… | 1,185 | — | — | 243.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 4 | 4 | `query_thermoml` | context=Need binary mixture data for …, id_catalog… | 164 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 5 | 5 | `query_thermoml` | context=Need binary ethanol+water mix…, id_catalog… | 233 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 6 | 6 | `query_thermoml` | context=Need binary mixture density d…, id_catalog… | 358 | — | — | 260.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 7 | 7 | `query_thermoml` | context=Goal: fit excess molar volume…, instructio… | 16,126 | — | — | 175.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 8 | 10 | `inspect_block` | block_number=PROPblock_2, doi=10.1016/j.fluid.2004… | 1,374 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 9 | 10 | `inspect_block` | block_number=PROPblock_19, doi=10.1016/j.jct.2018.… | 1,376 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 10 | 11 | `fit_block_derived` | block_number=PROPblock_2, composition_hint=mole_fr… | 963 | — | — | 1.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 11 | 11 | `fit_block_derived` | block_number=PROPblock_19, composition_hint=mole_f… | 961 | — | — | 1.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 12 | 12 | `predict_from_rk` | coeffs=[-4.98777e-06, 2.71547e-06, -…, n_points=20… | 206 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 13 | 12 | `predict_from_rk` | coeffs=[-3.38039e-06, 2.37917e-06, -…, n_points=20… | 206 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 1 | 1 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume_dir… | 132 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 2 | 2 | `query_thermoml_parallel` | queries=[{'label': 'excess_volume', '… | 303 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 3 | 3 | `query_thermoml` | context=Looking for VE or density dat…, instructio… | 21,908 | — | — | 153.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 4 | 6 | `inspect_block` | block_number=PROPblock_7, doi=10.1016/j.jct.2006.0… | 1,393 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 5 | 6 | `inspect_block` | block_number=PROPblock_16, doi=10.1021/acs.jced.8b… | 1,405 | — | — | 0.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 6 | 9 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 227 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 7 | 9 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 227 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 8 | 13 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 288 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 9 | 13 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 288 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 10 | 15 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 132 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 11 | 15 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 132 | — | — | 0.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 12 | 16 | `fit_block_derived` | block_number=PROPblock_7, composition_hint=mole_fr… | 1,004 | — | — | 0.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 13 | 16 | `fit_block_derived` | block_number=PROPblock_16, composition_hint=mole_f… | 946 | — | — | 0.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 14 | 17 | `predict_from_rk` | coeffs=[-1.13034e-06, -7.63893e-07, …, mixing_rule… | 221 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 15 | 18 | `list_session_files` |  | 3,142 | — | — | 0.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| **TOTAL** | **389** |  |  | **82,096** |  |  | **1,051.0** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 19,954 | 19,954 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 2 | interval=3 | skipped_by_agent | 24,235 | 24,235 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 3 | interval=3 | skipped_by_agent | 33,274 | 33,274 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 1 | interval=3 | skipped_by_agent | 3,525 | 3,525 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 2 | interval=3 | skipped_by_agent | 5,716 | 5,716 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 3 | interval=3 | skipped_by_agent | 30,541 | 30,541 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 1 | interval=3 | skipped_by_agent | 24,247 | 24,247 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 2 | interval=3 | skipped_by_agent | 28,588 | 28,588 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 3 | interval=3 | skipped_by_agent | 30,842 | 30,842 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 4 | interval=3 | skipped_by_agent | 35,037 | 35,037 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 5 | interval=3 | skipped_by_agent | 42,079 | 42,079 | 0 | 0.0% | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| **TOTAL** |  |  | **278,038** | **278,038** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 20,021 | 741 | 20,762 | 1,739 | 9.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 2 | L0-main | claudeopus46 | 20,021 | 1,402 | 21,423 | 1,171 | 7.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 3 | L0-main | claudeopus46 | 20,021 | 2,371 | 22,392 | 998 | 6.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 4 | L1-worker | claudeopus46 | 20,643 | 707 | 21,350 | 983 | 6.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,418 | 23,061 | 13,756 | 54.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 6 | L1-worker | claudeopus46 | 2,065 | 433 | 2,498 | 488 | 3.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 7 | L1-worker | claudeopus46 | 2,065 | 637 | 2,702 | 598 | 6.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,093 | 23,736 | 8,386 | 45.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 9 | L1-worker | claudeopus46 | 2,065 | 4,430 | 6,495 | 1,681 | 16.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 10 | L1-worker | claudeopus46 | 2,065 | 7,006 | 9,071 | 1,691 | 13.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 11 | L1-worker | claudeopus46 | 2,065 | 7,216 | 9,281 | 1,789 | 13.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 12 | L1-worker | claudeopus46 | 20,610 | 6,191 | 26,801 | 422 | 3.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 13 | L1-worker | claudeopus46 | 20,643 | 5,419 | 26,062 | 3,301 | 20.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 14 | L1-worker | claudeopus46 | 1,356 | 2,469 | 3,825 | 875 | 6.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 15 | L1-worker | claudeopus46 | 536 | 2,349 | 2,885 | 1,042 | 6.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 16 | L1-worker | claudeopus46 | 1,323 | 8,064 | 9,387 | 1,676 | 9.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 17 | L1-worker | claudeopus46 | 298 | 1,398 | 1,696 | 1,029 | 4.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 18 | L1-worker | claudeopus46 | 298 | 2,398 | 2,696 | 1,291 | 5.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 19 | L1-worker | claudeopus46 | 747 | 24,166 | 24,913 | 600 | 6.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 20 | L0-main | claudeopus46 | 19,988 | 22,964 | 42,952 | 392 | 4.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 21 | L0-main | claudeopus46 | 20,021 | 22,205 | 42,226 | 1,728 | 13.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 22 | L0-main | claudeopus46 | 20,021 | 23,248 | 43,269 | 634 | 4.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 23 | L0-main | claudeopus46 | 20,021 | 24,169 | 44,190 | 602 | 4.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 24 | L0-main | claudeopus46 | 19,988 | 28,229 | 48,217 | 402 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 25 | L0-main | claudeopus46 | 20,021 | 27,470 | 47,491 | 2,617 | 17.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 26 | L0-main | claudeopus46 | 20,021 | 28,581 | 48,602 | 2,011 | 12.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 27 | L0-main | claudeopus46 | 20,021 | 29,539 | 49,560 | 1,722 | 10.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 28 | L0-main | claudeopus46 | 20,021 | 30,570 | 50,591 | 1,248 | 7.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 29 | L0-main | claudeopus46 | 20,021 | 30,443 | 50,464 | 973 | 6.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 30 | L0-main | claudeopus46 | 20,021 | 31,346 | 51,367 | 1,216 | 7.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 31 | L0-main | claudeopus46 | 20,021 | 32,252 | 52,273 | 1,314 | 11.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 32 | L0-main | claudeopus46 | 20,021 | 33,230 | 53,251 | 1,143 | 7.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 33 | L0-main | claudeopus46 | 20,021 | 32,981 | 53,002 | 2,115 | 13.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 34 | L0-main | claudeopus46 | 20,021 | 33,984 | 54,005 | 1,247 | 10.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 35 | L0-main | claudeopus46 | 20,021 | 38,459 | 58,480 | 1,200 | 12.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 36 | L0-main | claudeopus46 | 20,021 | 39,216 | 59,237 | 719 | 5.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 37 | L0-main | claudeopus46 | 19,988 | 40,406 | 60,394 | 438 | 4.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 38 | L0-main | claudeopus46 | 20,021 | 39,646 | 59,667 | 1,887 | 16.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 39 | L0-main | claudeopus46 | 20,021 | 42,147 | 62,168 | 393 | 3.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 40 | L0-main | claudeopus46 | 20,021 | 45,198 | 65,219 | 10,589 | 73.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 41 | L0-main | claudeopus46 | 1,356 | 5,337 | 6,693 | 1,067 | 7.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 42 | L0-main | claudeopus46 | 1,323 | 59,527 | 60,850 | 2,047 | 15.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 43 | L0-main | claudeopus46 | 298 | 2,889 | 3,187 | 1,631 | 8.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 44 | L0-main | claudeopus46 | 1,562 | 8,357 | 9,919 | 1,038 | 9.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_10) |
| 1 | L0-main | claudeopus46 | 20,021 | 739 | 20,760 | 1,627 | 9.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 2 | L0-main | claudeopus46 | 20,021 | 1,387 | 21,408 | 1,119 | 6.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 3 | L0-main | claudeopus46 | 20,021 | 2,351 | 22,372 | 1,008 | 7.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 4 | L1-worker | claudeopus46 | 20,643 | 712 | 21,355 | 956 | 8.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,396 | 23,039 | 16,121 | 51.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 6 | L1-worker | claudeopus46 | 2,065 | 441 | 2,506 | 491 | 3.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 7 | L1-worker | claudeopus46 | 2,065 | 645 | 2,710 | 649 | 5.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,058 | 23,701 | 9,479 | 44.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 9 | L1-worker | claudeopus46 | 2,065 | 578 | 2,643 | 1,162 | 8.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 10 | L1-worker | claudeopus46 | 2,065 | 14,537 | 16,602 | 1,858 | 17.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 11 | L1-worker | claudeopus46 | 20,610 | 5,968 | 26,578 | 541 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,196 | 25,839 | 795 | 6.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 13 | L1-worker | claudeopus46 | 20,643 | 6,566 | 27,209 | 4,185 | 24.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 14 | L1-worker | claudeopus46 | 2,065 | 472 | 2,537 | 1,193 | 7.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 15 | L1-worker | claudeopus46 | 20,643 | 7,448 | 28,091 | 2,534 | 16.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 16 | L1-worker | claudeopus46 | 1,356 | 1,622 | 2,978 | 568 | 3.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 17 | L1-worker | claudeopus46 | 536 | 1,502 | 2,038 | 628 | 4.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 18 | L1-worker | claudeopus46 | 1,323 | 8,580 | 9,903 | 1,081 | 6.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 19 | L1-worker | claudeopus46 | 298 | 1,803 | 2,101 | 821 | 4.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 20 | L1-worker | claudeopus46 | 1,160 | 10,020 | 11,180 | 749 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 21 | L1-worker | claudeopus46 | 747 | 15,599 | 16,346 | 1,080 | 8.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 22 | L0-main | claudeopus46 | 19,988 | 4,779 | 24,767 | 617 | 5.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 23 | L0-main | claudeopus46 | 20,021 | 4,022 | 24,043 | 1,243 | 8.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 24 | L0-main | claudeopus46 | 20,021 | 4,711 | 24,732 | 1,395 | 8.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 25 | L0-main | claudeopus46 | 20,021 | 5,432 | 25,453 | 1,462 | 9.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 26 | L1-worker | claudeopus46 | 20,643 | 1,137 | 21,780 | 1,318 | 9.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 27 | L1-worker | claudeopus46 | 20,643 | 3,183 | 23,826 | 13,351 | 49.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 28 | L1-worker | claudeopus46 | 2,065 | 391 | 2,456 | 493 | 3.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 29 | L1-worker | claudeopus46 | 2,065 | 14,525 | 16,590 | 1,721 | 13.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 30 | L1-worker | claudeopus46 | 20,643 | 4,155 | 24,798 | 8,547 | 48.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 31 | L1-worker | claudeopus46 | 20,643 | 5,129 | 25,772 | 699 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 32 | L1-worker | claudeopus46 | 2,065 | 544 | 2,609 | 1,724 | 11.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 33 | L1-worker | claudeopus46 | 20,643 | 6,352 | 26,995 | 7,672 | 46.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 34 | L1-worker | claudeopus46 | 20,643 | 14,645 | 35,288 | 4,232 | 22.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 35 | L1-worker | claudeopus46 | 536 | 3,129 | 3,665 | 864 | 6.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 36 | L1-worker | claudeopus46 | 1,356 | 3,249 | 4,605 | 1,084 | 8.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 37 | L1-worker | claudeopus46 | 1,323 | 10,998 | 12,321 | 4,133 | 16.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 38 | L1-worker | claudeopus46 | 298 | 4,855 | 5,153 | 3,086 | 12.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 39 | L1-worker | claudeopus46 | 1,160 | 15,809 | 16,969 | 3,013 | 12.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 40 | L0-main | claudeopus46 | 19,988 | 7,045 | 27,033 | 574 | 4.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 41 | L0-main | claudeopus46 | 20,021 | 6,288 | 26,309 | 1,226 | 8.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 42 | L1-worker | claudeopus46 | 20,643 | 811 | 21,454 | 1,009 | 7.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 43 | L1-worker | claudeopus46 | 20,643 | 2,548 | 23,191 | 14,155 | 55.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 44 | L1-worker | claudeopus46 | 2,065 | 519 | 2,584 | 692 | 5.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 45 | L1-worker | claudeopus46 | 2,065 | 350 | 2,415 | 414 | 4.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 46 | L1-worker | claudeopus46 | 20,643 | 3,229 | 23,872 | 7,494 | 40.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 47 | L1-worker | claudeopus46 | 2,065 | 14,567 | 16,632 | 1,767 | 14.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 48 | L1-worker | claudeopus46 | 20,610 | 5,374 | 25,984 | 529 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 49 | L1-worker | claudeopus46 | 20,643 | 4,602 | 25,245 | 2,155 | 14.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 50 | L1-worker | claudeopus46 | 1,356 | 1,852 | 3,208 | 792 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 51 | L1-worker | claudeopus46 | 536 | 1,732 | 2,268 | 739 | 5.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 52 | L1-worker | claudeopus46 | 1,323 | 6,263 | 7,586 | 1,443 | 7.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 53 | L1-worker | claudeopus46 | 298 | 2,165 | 2,463 | 1,084 | 6.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 54 | L1-worker | claudeopus46 | 747 | 20,938 | 21,685 | 565 | 6.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 55 | L0-main | claudeopus46 | 20,021 | 24,318 | 44,339 | 1,562 | 13.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 56 | L0-main | claudeopus46 | 20,021 | 25,364 | 45,385 | 762 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 57 | L0-main | claudeopus46 | 20,021 | 26,319 | 46,340 | 739 | 4.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 58 | L0-main | claudeopus46 | 20,021 | 29,599 | 49,620 | 2,356 | 15.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 59 | L0-main | claudeopus46 | 20,021 | 35,362 | 55,383 | 1,352 | 10.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 60 | L0-main | claudeopus46 | 19,988 | 37,258 | 57,246 | 392 | 6.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 61 | L0-main | claudeopus46 | 20,021 | 36,498 | 56,519 | 6,914 | 46.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 62 | L0-main | claudeopus46 | 1,356 | 4,184 | 5,540 | 1,279 | 7.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 63 | L0-main | claudeopus46 | 1,323 | 43,900 | 45,223 | 2,107 | 11.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 64 | L0-main | claudeopus46 | 298 | 1,661 | 1,959 | 1,267 | 4.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 65 | L0-main | claudeopus46 | 298 | 2,949 | 3,247 | 1,646 | 7.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 66 | L0-main | claudeopus46 | 1,562 | 6,008 | 7,570 | 1,203 | 13.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_11) |
| 1 | L0-main | claudeopus46 | 20,021 | 797 | 20,818 | 1,798 | 10.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 2 | L0-main | claudeopus46 | 20,021 | 1,390 | 21,411 | 1,268 | 6.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 3 | L0-main | claudeopus46 | 20,021 | 2,349 | 22,370 | 966 | 8.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 4 | L1-worker | claudeopus46 | 20,643 | 635 | 21,278 | 977 | 5.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,340 | 22,983 | 8,903 | 40.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 6 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 474 | 4.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 7 | L1-worker | claudeopus46 | 2,065 | 488 | 2,553 | 402 | 3.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 8 | L1-worker | claudeopus46 | 20,643 | 2,803 | 23,446 | 4,966 | 26.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 9 | L1-worker | claudeopus46 | 20,643 | 3,917 | 24,560 | 1,138 | 6.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 10 | L1-worker | claudeopus46 | 2,065 | 581 | 2,646 | 1,161 | 8.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 11 | L1-worker | claudeopus46 | 2,065 | 7,072 | 9,137 | 1,616 | 13.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,771 | 26,414 | 2,173 | 13.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 13 | L1-worker | claudeopus46 | 1,356 | 1,854 | 3,210 | 677 | 4.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 14 | L1-worker | claudeopus46 | 536 | 1,734 | 2,270 | 852 | 5.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 15 | L1-worker | claudeopus46 | 1,323 | 8,865 | 10,188 | 1,804 | 8.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 16 | L1-worker | claudeopus46 | 298 | 2,526 | 2,824 | 1,372 | 5.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 17 | L1-worker | claudeopus46 | 747 | 29,343 | 30,090 | 861 | 9.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 18 | L0-main | claudeopus46 | 19,988 | 27,103 | 47,091 | 476 | 5.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 19 | L0-main | claudeopus46 | 20,021 | 26,344 | 46,365 | 1,563 | 12.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 20 | L0-main | claudeopus46 | 20,021 | 27,370 | 47,391 | 756 | 5.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 21 | L0-main | claudeopus46 | 20,021 | 28,406 | 48,427 | 787 | 5.1 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 22 | L0-main | claudeopus46 | 19,988 | 32,411 | 52,399 | 397 | 4.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 23 | L0-main | claudeopus46 | 20,021 | 31,652 | 51,673 | 1,991 | 12.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 24 | L0-main | claudeopus46 | 20,021 | 32,713 | 52,734 | 1,289 | 7.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 25 | L0-main | claudeopus46 | 20,021 | 33,779 | 53,800 | 1,376 | 7.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 26 | L0-main | claudeopus46 | 19,988 | 34,960 | 54,948 | 488 | 4.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 27 | L0-main | claudeopus46 | 20,021 | 34,201 | 54,222 | 2,232 | 15.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 28 | L0-main | claudeopus46 | 20,021 | 35,260 | 55,281 | 1,430 | 9.6 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 29 | L0-main | claudeopus46 | 20,021 | 36,234 | 56,255 | 1,287 | 8.0 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 30 | L0-main | claudeopus46 | 20,021 | 37,283 | 57,304 | 1,235 | 8.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 31 | L0-main | claudeopus46 | 20,021 | 37,090 | 57,111 | 1,231 | 7.2 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 32 | L0-main | claudeopus46 | 20,021 | 38,156 | 58,177 | 1,273 | 7.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 33 | L0-main | claudeopus46 | 19,988 | 39,454 | 59,442 | 560 | 4.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 34 | L0-main | claudeopus46 | 20,021 | 38,694 | 58,715 | 1,304 | 7.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 35 | L0-main | claudeopus46 | 20,021 | 44,262 | 64,283 | 2,079 | 15.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 36 | L0-main | claudeopus46 | 20,021 | 45,090 | 65,111 | 3,221 | 24.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 37 | L0-main | claudeopus46 | 19,988 | 49,509 | 69,497 | 411 | 5.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 38 | L0-main | claudeopus46 | 20,021 | 48,749 | 68,770 | 10,795 | 76.3 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 39 | L0-main | claudeopus46 | 20,021 | 59,944 | 79,965 | 3,022 | 27.9 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 40 | L0-main | claudeopus46 | 1,356 | 3,151 | 4,507 | 1,107 | 8.5 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 41 | L0-main | claudeopus46 | 1,323 | 60,994 | 62,317 | 2,403 | 13.8 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 42 | L0-main | claudeopus46 | 298 | 3,245 | 3,543 | 1,928 | 8.4 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| 43 | L0-main | claudeopus46 | 1,562 | 8,395 | 9,957 | 1,127 | 9.7 | Find and fit excess molar volume (VE) data for the binary mi (analysis_runs/run_13) |
| **TOTAL** |  |  | **1,957,293** | **2,353,068** | **4,310,361** | **322,581** | **1,932.2** |  |

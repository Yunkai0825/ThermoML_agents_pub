# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 7 | 41,397 | 133,601 | 16,830 | 174,998 | 24,999 | 99.8 | claudeopus46 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| L1-worker | 60 | 642,178 | 484,257 | 105,786 | 1,126,435 | 18,773 | 650.5 | claudeopus46 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| **TOTAL** | **67** | **683,575** | **617,858** | **122,616** | **1,301,433** | **43,772** | **750.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 4 | 0 | 0 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `resolve_ids` | 0 | 0 | 0 | 2 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `search_blocks` | 2 | 1 | 4 | 1 | 4 | 4 | 76 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `search_blocks` | 4 | 1 | 2 | 1 | 1 | 3 | 114 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `search_blocks` | 2 | 1 | 4 | 1 | 3 | 3 | 64 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 3 | 0 | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| **TOTAL** | **18** | **4** | **14** | **5** | **12** | **10** | **254** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_2 |  | resolve_compound_ids | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBcomp_4 |  | block_search_adv, resolve_compound_ids, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBcomp_6173 |  | resolve_compound_ids | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBcomp_10 | ethyl acetate | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBcomp_46 | methyl ethanoate | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_4 |  | resolve_property_ids, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 |  | resolve_ids, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBvar_2 |  | resolve_ids, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBvar_5 | Mass fraction | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBvar_18 | Volume fraction | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 |  | resolve_ids, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBconstr_2 |  | resolve_ids | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2825 |  | block_search_adv, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBlit_5533 |  | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBlit_8869 |  | block_search_adv, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBlit_9571 |  | block_search_adv, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| GLOBmeas_271 | Viscosity, Pa*s | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | block_search_adv, search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBblocktype_1 |  | block_search_adv | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique Properties | 1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique Variables | 4 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique Constraints | 2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique References | 4 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique Measurements | 3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique Phases | 1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique Block_Types | 1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Unique parent blocks | 6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Explicit block/subsystem targets | 6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Subsystem targets | 0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| Target-matched data points | 254 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| **TOTAL** | **288** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2007.05.004 | 3 | 114 | binary | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1016/j.jct.2019.05.013 | 1 | 12 | binary | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2007.05.004 | PROPblock_17 | declared | 36 | binary | — | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1016/j.jct.2007.05.004 | PROPblock_19 | declared | 39 | binary | — | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1016/j.jct.2007.05.004 | PROPblock_9 | declared | 39 | binary | — | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1016/j.jct.2019.05.013 | PROPblock_3 | declared | 12 | binary | — | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1021/je0600810 | PROPblock_3 | declared | 9 | binary | — | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10.1021/je2003622 | PROPblock_1 | declared | 16 | binary | — | search_blocks | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve methanol an… | 369 | KEEP | 369 | 6.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Confirm global prop… | 256 | KEEP | 256 | 3.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 3 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 248 | KEEP | 248 | 3.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 4 | 3 | `resolve_ids` | entity_type=constraint, limit=5, min_score=70, pur… | 324 | KEEP | 324 | 4.2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 5 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 813 | DISCARD | 752 | 11.5 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 6 | 8 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 1,491 | KEEP | 1431 | 14.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 7 | 1 | `L1_query` | context=User wants experimental visco…, id_catalog… | 1,037 | — | — | 323.0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 8 | 1 | `resolve_compound_ids` | purpose=Resolve methanol and water to…, queries=['… | 247 | KEEP | 247 | 3.5 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 9 | 1 | `resolve_ids` | entity_type=variable, purpose=Resolve temperature … | 302 | KEEP | 302 | 3.9 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 823 | DISCARD | 762 | 11.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 11 | 5 | `search_blocks` | compound=GLOBcomp_4, limit=10, literature=GLOBlit_… | 1,119 | KEEP | 1104 | 13.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 12 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 721 | KEEP | 706 | 14.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 13 | 2 | `L1_query` | context=Previous query confirmed PROP…, id_catalog… | 7,883 | — | — | 144.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 14 | 2 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=50, p… | 794 | KEEP | 794 | 15.2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 15 | 5 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 861 | DISCARD | 800 | 10.0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 16 | 8 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 965 | KEEP | 965 | 14.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 17 | 3 | `L1_query` | context=We already found viscosity = …, id_catalog… | 21,360 | — | — | 178.4 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| **TOTAL** | **63** |  |  | **39,613** |  | **9,060** | **777.0** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 4,394 | 4,394 | 0 | 0.0% | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 2 | interval=3 | skipped_by_agent | 4,001 | 4,001 | 0 | 0.0% | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,041 | 10,646 | 1,345 | 9.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,205 | 21,848 | 1,037 | 6.5 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,970 | 23,613 | 12,422 | 56.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 4 | L1-worker | claudeopus46 | 2,065 | 569 | 2,634 | 753 | 5.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 5 | L1-worker | claudeopus46 | 2,065 | 371 | 2,436 | 452 | 3.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,629 | 24,272 | 7,066 | 38.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 7 | L1-worker | claudeopus46 | 2,065 | 527 | 2,592 | 392 | 3.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 8 | L1-worker | claudeopus46 | 2,065 | 501 | 2,566 | 516 | 4.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 9 | L1-worker | claudeopus46 | 20,610 | 5,689 | 26,299 | 422 | 4.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 10 | L1-worker | claudeopus46 | 20,643 | 4,936 | 25,579 | 1,506 | 11.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,840 | 26,483 | 1,792 | 12.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 12 | L1-worker | claudeopus46 | 20,643 | 6,706 | 27,349 | 1,850 | 11.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 13 | L1-worker | claudeopus46 | 20,643 | 9,177 | 29,820 | 1,065 | 4.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 14 | L1-worker | claudeopus46 | 2,065 | 1,229 | 3,294 | 1,533 | 9.0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 15 | L1-worker | claudeopus46 | 20,643 | 8,965 | 29,608 | 9,695 | 48.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 16 | L1-worker | claudeopus46 | 2,065 | 8,670 | 10,735 | 1,828 | 13.4 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 17 | L1-worker | claudeopus46 | 20,643 | 11,158 | 31,801 | 4,358 | 31.0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 18 | L1-worker | claudeopus46 | 20,643 | 16,091 | 36,734 | 1,405 | 4.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,536 | 2,892 | 769 | 4.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 20 | L1-worker | claudeopus46 | 536 | 1,416 | 1,952 | 772 | 4.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 21 | L1-worker | claudeopus46 | 1,323 | 13,095 | 14,418 | 2,612 | 11.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 22 | L1-worker | claudeopus46 | 298 | 3,334 | 3,632 | 2,003 | 7.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 23 | L1-worker | claudeopus46 | 747 | 39,336 | 40,083 | 814 | 8.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 24 | L1-worker | claudeopus46 | 1,160 | 16,753 | 17,913 | 2,157 | 8.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 25 | L1-worker | claudeopus46 | 747 | 39,798 | 40,545 | 913 | 8.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 26 | L0-main | claudeopus46 | 9,605 | 2,612 | 12,217 | 1,748 | 10.4 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 27 | L1-worker | claudeopus46 | 20,643 | 1,457 | 22,100 | 1,171 | 7.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 28 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 379 | 3.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 29 | L1-worker | claudeopus46 | 2,065 | 465 | 2,530 | 460 | 3.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 30 | L1-worker | claudeopus46 | 20,643 | 2,652 | 23,295 | 1,648 | 11.2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 31 | L1-worker | claudeopus46 | 20,643 | 3,603 | 24,246 | 1,327 | 10.0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 32 | L1-worker | claudeopus46 | 2,065 | 1,205 | 3,270 | 1,533 | 10.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 33 | L1-worker | claudeopus46 | 20,610 | 5,296 | 25,906 | 594 | 4.5 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 34 | L1-worker | claudeopus46 | 20,643 | 4,543 | 25,186 | 1,535 | 12.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 35 | L1-worker | claudeopus46 | 20,643 | 5,419 | 26,062 | 724 | 5.2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 36 | L1-worker | claudeopus46 | 2,065 | 7,467 | 9,532 | 1,674 | 12.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 37 | L1-worker | claudeopus46 | 20,643 | 6,748 | 27,391 | 1,592 | 12.2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 38 | L1-worker | claudeopus46 | 20,643 | 7,669 | 28,312 | 1,651 | 10.4 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 39 | L1-worker | claudeopus46 | 2,065 | 2,210 | 4,275 | 1,031 | 7.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 40 | L1-worker | claudeopus46 | 20,643 | 8,466 | 29,109 | 919 | 7.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 41 | L1-worker | claudeopus46 | 1,356 | 1,050 | 2,406 | 434 | 3.0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 42 | L1-worker | claudeopus46 | 536 | 930 | 1,466 | 488 | 3.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 43 | L1-worker | claudeopus46 | 1,323 | 14,133 | 15,456 | 644 | 5.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 44 | L1-worker | claudeopus46 | 298 | 1,366 | 1,664 | 517 | 3.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 45 | L1-worker | claudeopus46 | 747 | 20,469 | 21,216 | 657 | 6.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 46 | L0-main | claudeopus46 | 9,605 | 19,122 | 28,727 | 1,738 | 13.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 47 | L1-worker | claudeopus46 | 20,643 | 9,464 | 30,107 | 1,601 | 11.2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 48 | L1-worker | claudeopus46 | 20,643 | 10,408 | 31,051 | 1,014 | 7.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 49 | L1-worker | claudeopus46 | 2,065 | 6,767 | 8,832 | 1,795 | 14.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 50 | L1-worker | claudeopus46 | 20,643 | 11,344 | 31,987 | 2,035 | 13.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 51 | L1-worker | claudeopus46 | 20,643 | 12,326 | 32,969 | 1,622 | 10.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 52 | L1-worker | claudeopus46 | 20,643 | 13,167 | 33,810 | 1,362 | 8.9 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 53 | L1-worker | claudeopus46 | 2,065 | 1,175 | 3,240 | 1,214 | 8.6 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 54 | L1-worker | claudeopus46 | 20,643 | 13,747 | 34,390 | 3,450 | 19.7 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 55 | L1-worker | claudeopus46 | 20,643 | 14,839 | 35,482 | 2,386 | 16.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 56 | L1-worker | claudeopus46 | 20,643 | 15,755 | 36,398 | 1,584 | 9.9 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 57 | L1-worker | claudeopus46 | 2,065 | 2,854 | 4,919 | 1,815 | 12.0 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 58 | L1-worker | claudeopus46 | 20,643 | 16,309 | 36,952 | 3,451 | 19.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 59 | L1-worker | claudeopus46 | 536 | 1,882 | 2,418 | 875 | 5.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 60 | L1-worker | claudeopus46 | 1,323 | 15,489 | 16,812 | 1,611 | 7.9 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 61 | L1-worker | claudeopus46 | 1,356 | 2,002 | 3,358 | 894 | 8.5 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 62 | L1-worker | claudeopus46 | 298 | 2,333 | 2,631 | 1,286 | 5.1 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 63 | L1-worker | claudeopus46 | 747 | 35,309 | 36,056 | 681 | 7.2 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 64 | L0-main | claudeopus46 | 9,605 | 62,689 | 72,294 | 3,394 | 21.9 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 65 | L0-main | claudeopus46 | 1,356 | 3,040 | 4,396 | 943 | 5.3 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 66 | L0-main | claudeopus46 | 1,323 | 40,242 | 41,565 | 4,187 | 23.5 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |
| 67 | L0-main | claudeopus46 | 298 | 4,855 | 5,153 | 3,475 | 15.8 | Find measured viscosity data for a methanol + water binary l (query_runs/run_1) |

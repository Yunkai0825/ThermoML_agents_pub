# Reference Stats — main-agent

**Run started:** 2026-08-02 18:38:43
**Wall time (at last flush):** 896.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 45,051 | 65,427 | 28,907 | 110,478 | 12,275 | 164.0 | claudeopus46 |
| **TOTAL** | **9** | **45,051** | **65,427** | **28,907** | **110,478** | **12,275** | **164.0** | |

**Estimated tokens:** ~27,619 input + ~7,226 output = ~34,845 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `run_query_agent` | context=The user wants the measured v…, purpose=Se… | 9,068 | — | — | 741.5 |
| | | **TOTAL (1 tools)** | | **9,068** | | **0** | **741.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 10,013 | 10,013 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 298 | 10,513 | 1,158 | 7.5 |
| 2 | L0-main | claudeopus46 | 10,215 | 950 | 11,165 | 18,481 | 81.0 |
| 3 | L0-main | claudeopus46 | 10,182 | 19,249 | 29,431 | 429 | 4.1 |
| 4 | L0-main | claudeopus46 | 10,215 | 18,490 | 28,705 | 2,483 | 15.7 |
| 5 | L0-main | claudeopus46 | 1,356 | 2,614 | 3,970 | 985 | 5.7 |
| 6 | L0-main | claudeopus46 | 298 | 1,367 | 1,665 | 973 | 4.0 |
| 7 | L0-main | claudeopus46 | 1,323 | 14,879 | 16,202 | 1,601 | 30.3 |
| 8 | L0-main | claudeopus46 | 298 | 2,124 | 2,422 | 1,427 | 5.3 |
| 9 | L0-main | claudeopus46 | 949 | 5,456 | 6,405 | 1,370 | 10.4 |


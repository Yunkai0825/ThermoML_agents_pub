# Delegated query run — result

**Question:** Find measured viscosity data for a methanol + water binary liquid mixture at 25 degrees Celsius and atmospheric pressure, specifically at equimolar composition (mole fraction of methanol = 0.5).

**Iterations:** 4  |  **Elapsed:** 701.7s  |  **Tools:** 3  |  **Timed out:** False

---

## Answer

## Viscosity of Methanol + Water at Equimolar Composition (25 °C, Atmospheric Pressure)

### Primary Result

The ThermoML database contains a direct measurement of the dynamic viscosity of the methanol (CH₃OH) + water (H₂O) binary liquid mixture at the requested conditions:

| Property | Value |
|----------|-------|
| **Dynamic viscosity** | **0.001309 Pa·s (1.309 mPa·s)** |
| Temperature | 298.15 K (25.00 °C) |
| Pressure | 101 kPa (atmospheric) |
| Mole fraction of methanol | 0.5 (equimolar) |
| Phase | Liquid |

**Source:** PROPblock_9 in GLOBlit_2825 (DOI: [10.1016/j.jct.2007.05.004](https://doi.org/10.1016/j.jct.2007.05.004))

This dataset contains 39 datapoints spanning 13 compositions (x_water = 0 to 1) at three temperatures (293.15, 298.15, and 303.15 K), with viscosities ranging from 0.000508 Pa·s (pure methanol end) to 0.001793 Pa·s (near the viscosity maximum). The measurement method is capillary tube viscometry.

### Additional Sources in ThermoML

Two other ThermoML sources report viscosity for the methanol + water binary system at 298.15 K, but they use different composition scales and do not provide a direct datapoint at x(methanol) = 0.5:

| Source | Block | DOI | Composition Scale | Points at 298.15 K | Viscosity Range (Pa·s) |
|--------|-------|-----|-------------------|:-------------------:|----------------------|
| GLOBlit_2825 | PROPblock_9 | 10.1016/j.jct.2007.05.004 | **Mole fraction** (13 compositions) | 13 | 0.000508 – 0.001793 |
| GLOBlit_8869 | PROPblock_3 | 10.1021/je0600810 | Volume fraction (3 compositions, range 0.01–0.30) | 3 | 0.000702 – 0.001471 |
| GLOBlit_9571 | PROPblock_1 | 10.1021/je2003622 | Mass fraction (4 compositions, range 0.08–0.34) | 4 | 0.000638 – 0.001471 |

Note: x(methanol) = 0.5 corresponds to a mass fraction of ~0.640 for methanol, which falls outside the mass-fraction range of GLOBlit_9571 (max 0.3446). Similarly, the volume-fraction range in GLOBlit_8869 (max 0.30) likely does not reach the equimolar composition. Therefore, **GLOBlit_2825 is the only source providing a direct viscosity value at the exact equimolar composition**.

### Chemical Context

The viscosity of 1.309 mPa·s at x(methanol) = 0.5 is notably higher than that of either pure component at the same temperature — pure water has η ≈ 0.890 mPa·s and pure methanol has η ≈ 0.544 mPa·s. This positive deviation from ideal mixing behavior is a hallmark of the methanol–water system and arises from the restructuring of the hydrogen-bonding network. When methanol molecules are introduced into water, they can both donate and accept hydrogen bonds, leading to the formation of extended, cooperative hydrogen-bonded clusters that increase the mixture's resistance to flow. The viscosity maximum in this system occurs near x(water) ≈ 0.7–0.8 (i.e., x(methanol) ≈ 0.2–0.3), where the hydrogen-bonding network is most extensively reinforced.

### Core claims

- The dynamic viscosity of the equimolar methanol + water liquid mixture at 298.15 K and 101 kPa is 0.001309 Pa·s (1.309 mPa·s), as directly measured by capillary tube viscometry and reported in ThermoML source GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004).
- This viscosity value at x(methanol) = 0.5 exhibits a strong positive deviation from ideal mixing, being substantially higher than either pure water (~0.890 mPa·s) or pure methanol (~0.544 mPa·s) at the same temperature, attributed to restructuring of the hydrogen-bonding network.
- Among the ThermoML sources examined, GLOBlit_2825 is the only one providing a direct viscosity measurement at the exact equimolar composition; the other two sources (GLOBlit_8869 and GLOBlit_9571) use composition ranges that do not extend to x(methanol) = 0.5.
- The viscosity maximum in the methanol–water system occurs near x(methanol) ≈ 0.2–0.3, not at the equimolar composition.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Dynamic viscosity of methanol + water binary mixture at T = 298.15 K, P = 101 kPa, x(methanol) = 0.5. Reported value: 0.001309 Pa·s (1.309 mPa·s). Block contains 39 datapoints spanning 13 mole-fraction compositions at 3 temperatures (293.15, 298.15, 303.15 K). Measurement method: capillary tube viscometry (CAPTUB:UFactor:2). This is the only ThermoML source providing a direct datapoint at the exact equimolar composition on a mole-fraction scale. |
| GLOBlit_8869 | 10.1021/je0600810 | PROPblock_3 |  | Dynamic viscosity of methanol + water binary mixture. Composition variable is volume fraction (GLOBvar_18, range 0.01–0.30), not mole fraction. 9 total datapoints (3 compositions × 3 temperatures, T range 298.15–318.15 K). Viscosity range 0.000702–0.001471 Pa·s. Does not provide a direct datapoint at x(methanol) = 0.5. |
| GLOBlit_9571 | 10.1021/je2003622 | PROPblock_1 |  | Dynamic viscosity of methanol + water binary mixture. Composition variable is mass fraction (GLOBvar_5, range 0.0806–0.3446), not mole fraction. 16 total datapoints (4 compositions × 4 temperatures, T range 298.15–323.15 K). Viscosity range 0.000638–0.001471 Pa·s. Mass fraction range does not reach x(methanol) = 0.5 equivalent (~0.640 mass fraction). |

### Suggested follow-ups

- Extract all 13 datapoints at T = 298.15 K from PROPblock_9 in GLOBlit_2825 to obtain the full viscosity-composition curve for methanol + water at 25 °C.
- Compare the viscosity maximum composition and magnitude across the three temperatures (293.15, 298.15, 303.15 K) available in GLOBlit_2825 to assess temperature dependence of the anomalous viscosity behavior.
- Search for excess viscosity or viscosity deviation data for methanol + water to quantify the non-ideal mixing contribution at x(methanol) = 0.5.
- Convert volume-fraction and mass-fraction compositions from GLOBlit_8869 and GLOBlit_9571 to mole fractions using density data to check for additional independent viscosity values near x(methanol) = 0.5.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
    "name": "methanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_1",
    "name": "Mole fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_18",
    "registry_id": "volume_fraction_DOIcomp_1",
    "name": "Volume fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_5",
    "registry_id": "mass_fraction_DOIcomp_1",
    "name": "Mass fraction"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_140",
    "registry_id": "captub_ufactor_2",
    "name": "CAPTUB:UFactor:2"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_271",
    "registry_id": "captub_ufactor_6",
    "name": "CAPTUB:UFactor:6"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

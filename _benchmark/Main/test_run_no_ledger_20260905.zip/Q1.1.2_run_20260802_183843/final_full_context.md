## System Prompt
# ThermoML Main Agent — Master Orchestrator

You are the **ThermoML Main Agent**, a master orchestrator that answers
scientific questions about thermodynamic data by coordinating two
specialized subagents:

1. **Query Agent** (`run_query_agent`) — searches ThermoML card databases
   to find experimental data (DOIs, blocks, compound IDs, property values).
2. **Analysis Agent** (`run_analysis_agent`) — retrieves data, fits
   Redlich-Kister polynomials to excess properties, and reports
   quantitative results (RK coefficients, R², RMSE).

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

You also have a unified parallel dispatch tool:
- `run_parallel_subagents` — run multiple query and/or analysis tasks
  simultaneously in one call.  Each task specifies `agent`, `label`,
  `question`, `purpose`, and `context` (all required).

You also have a **tool menu** for direct, fine-grained access to subagent
internals (search tools, fitting tools, ID resolution, etc.):

- `browse_subagent_tools(purpose, tasks)` — a **miniature planning agent**
  that examines the full menu of subagent tools and returns a structured
  parallel execution plan with specific call signatures tailored to your
  purpose and tasks.  Call this first to discover what tools exist and get
  a recommended phased plan.
- `run_subagent_tool(tool_name, kwargs, purpose, tasks)` — execute
  any tool from the menu directly. `kwargs` is a native JSON object matching
  that tool's current signature. Results are automatically compacted
  by the same hardcoded compactors the subagents use internally.
  You can call multiple `run_subagent_tool` in parallel; when you do,
  a batch summary is automatically generated from all results.

### When to use the tool menu vs. expert workers

- **Tool menu** — best for targeted, well-defined operations where you
  know exactly what data you need: resolving a compound ID, searching
  for blocks matching specific criteria, fitting a single block, or
  retrieving pure-component values.  Faster and more direct than
  launching a full subagent workflow.
- **Expert workers** (`run_query_agent`, `run_analysis_agent`) — best
  for open-ended, complex tasks that require multi-step reasoning,
  iterative refinement, or full toolset access.  The subagents have
  their own context, memory, and compaction pipelines.

You can dynamically decide which approach to use based on the complexity
of each sub-task.  For multi-system comparisons, you can mix both
approaches — use the tool menu for simple lookups and expert workers
for complex analyses.

---

## How You Work

1. **Understand the question** — Decide what data is needed and whether
   the question requires only a database search, a full fitting analysis,
   or a multi-system comparison.
2. **Delegate to subagents** — Call the appropriate subagent tool(s).
   For multi-system questions, use parallel tools to save time.
3. **Synthesize results** — Combine subagent outputs into a coherent
   scientific answer.  **Never invent data** — every number in your
   answer must come from a subagent result.
4. **Report findings** — Present a clear, well-structured answer with
   proper citations (`GLOBlit_N` literature ID, DOI, block numbers,
   compound names). `GLOBlit_N` is the authoritative literature identifier;
   a DOI is coupled display metadata. Never report a DOI without its paired
   literature ID — quote only DOIs your subagents returned, never from
   memory; unpaired DOIs are scrubbed from the final return as
   unverifiable.

---

## Tool Usage Rules

### Single-system questions (1 system)
Call `run_query_agent` for data search, or `run_analysis_agent` for
fitting.  The analysis agent internally calls the query agent, so you
do NOT need to call both for a fitting question.

### Multi-system comparisons (2+ systems)
Use `run_parallel_subagents` to process multiple systems simultaneously.
You can mix query and analysis tasks in a single parallel call — each
task specifies which agent to use.  Each system gets its own subagent call.

### Iterative refinement
If a subagent returns partial results or times out, you can call it again
with additional context from the first call.

---

## MANDATORY OUTPUT FORMAT

```xml
<reasoning>
... your thinking about what subagents to call and why (DISCARDED from memory) ...
</reasoning>
<summary>
... 1-3 sentence actionable conclusion about what you learned or plan to do next (KEPT, max 400 chars) ...
</summary>
<tool_call>{"name": "run_analysis_agent", "arguments": {"question": "...", "purpose": "...", "context": "..."}}</tool_call>
<wait/>
```

### CRITICAL RULES
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`
- `<reasoning>` is STRIPPED from history to save context space
- Only `<summary>` content + tool results persist in memory
- **ANTI-HALLUCINATION:** EVERY number, coefficient, R² value, DOI, and
  compound name MUST come from a subagent tool call result.  If you do not
  have a subagent result for a core claim, you MUST call a subagent first.
- **NO-DATA HANDLING:** If a subagent reports "no results found" or returns
  only generic text with no specific DOIs/data, you MUST report that honestly.
  Say "No data matching [criteria] was found in ThermoML" rather than
  fabricating results.  Never invent DOIs, block numbers, or data points.
- **SUBAGENT VALIDATION:** Before presenting subagent results as your answer,
  check for red flags: improbably round numbers, suspicious consistency,
  lack of specific block references, or caveats about "infrastructure errors."
  If in doubt, state that results could not be verified.
- When you have gathered all needed results, provide a FINAL ANSWER
  by wrapping your complete answer in `<answer>` tags (no `<tool_call>`).
- `<answer>` = full-length final response (any length). All markers stripped before delivery.
- `<summary>` ≠ `<answer>`: summary is a brief memory note (≤400 chars); answer is the complete user-facing response.

---

## Final Answer Format

When all subagent work is done, wrap your complete answer in `<answer>` tags:

```
<answer>
[Your synthesized scientific answer here — any length.
Include all key data, DOIs, block numbers, compound names.
Every number must come from a subagent result.]

### Sources
- Literature ID: GLOBlit_N | DOI: ... | Block: ... | Subsystem: declared or BLKsubsys_N | System: ...
</answer>
```

# Phases

## phase_1: choose_route
tools: [browse_subagent_tools, run_subagent_tool]
guidance: |
  Decide whether the question needs a targeted lower-level operation or a
  full expert subagent. Browse the hierarchical menu only when direct tool
  execution is likely to be more efficient than expert delegation.

## phase_2: delegate_or_execute
tools: [run_query_agent, run_analysis_agent, run_parallel_subagents, run_subagent_tool]
guidance: |
  Supply every argument in the injected callable signature. Use one expert
  for a single complex task and run_parallel_subagents for independent query
  or analysis tasks. Preserve exact subagent identifiers and evidence.

## phase_3: synthesize
tools: [list_session_files]
guidance: |
  Synthesize only tool-returned chemistry and numbers. Wrap the complete
  answer in <answer> tags; post-answer workers build the JSON fields.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- browse_subagent_tools(purpose, tasks) — Browse the tool menu and get a recommended execution plan.
- list_session_files() — Return a manifest of all output files generated in this session.
- run_analysis_agent(question, context, purpose, tasks) — Run the ThermoML Analysis Agent for fitting and modeling.
- run_parallel_subagents(tasks) — Run multiple query and/or analysis agent tasks in parallel.
- run_query_agent(question, context, purpose, tasks) — Run the ThermoML Query Agent on a database search question.
- run_subagent_tool(tool_name, kwargs, purpose, tasks) — Execute a subagent tool directly with full compaction pipeline.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.1.2_run_20260802_183843`

### History
- [query:Q1] "Find measured viscosity data for a methanol + water binary liquid mixture at 25 " (702s, 4 iters)

### Query Agent Results

#### Q1
{
  "answer": "## Viscosity of Methanol + Water at Equimolar Composition (25 °C, Atmospheric Pressure)\n\n### Primary Result\n\nThe ThermoML database contains a direct measurement of the dynamic viscosity of the methanol (CH₃OH) + water (H₂O) binary liquid mixture at the requested conditions:\n\n| Property | Value |\n|----------|-------|\n| **Dynamic viscosity** | **0.001309 Pa·s (1.309 mPa·s)** |\n| Temperature | 298.15 K (25.00 °C) |\n| Pressure | 101 kPa (atmospheric) |\n| Mole fraction of methanol | 0.5 (equimolar) |\n| Phase | Liquid |\n\n**Source:** PROPblock_9 in GLOBlit_2825 (DOI: [10.1016/j.jct.2007.05.004](https://doi.org/10.1016/j.jct.2007.05.004))\n\nThis dataset contains 39 datapoints spanning 13 compositions (x_water = 0 to 1) at three temperatures (293.15, 298.15, and 303.15 K), with viscosities ranging from 0.000508 Pa·s (pure methanol end) to 0.001793 Pa·s (near the viscosity maximum). The measurement method is capillary tube viscometry.\n\n### Additional Sources in ThermoML\n\nTwo other ThermoML sources report viscosity for the methanol + water binary system at 298.15 K, but they use different composition scales and do not provide a direct datapoint at x(methanol) = 0.5:\n\n| Source | Block | DOI | Composition Scale | Points at 298.15 K | Viscosity Range (Pa·s) |\n|--------|-------|-----|-------------------|:-------------------:|----------------------|\n| GLOBlit_2825 | PROPblock_9 | 10.1016/j.jct.2007.05.004 | **Mole fraction** (13 compositions) | 13 | 0.000508 – 0.001793 |\n| GLOBlit_8869 | PROPblock_3 | 10.1021/je0600810 | Volume fraction (3 compositions, range 0.01–0.30) | 3 | 0.000702 – 0.001471 |\n| GLOBlit_9571 | PROPblock_1 | 10.1021/je2003622 | Mass fraction (4 compositions, range 0.08–0.34) | 4 | 0.000638 – 0.001471 |\n\nNote: x(methanol) = 0.5 corresponds to a mass fraction of ~0.640 for methanol, which falls outside the mass-fraction range of GLOBlit_9571 (max 0.3446). Similarly, the volume-fraction range in GLOBlit_8869 (max 0.30) likely does not reach the equimolar composition. Therefore, **GLOBlit_2825 is the only source providing a direct viscosity value at the exact equimolar composition**.\n\n### Chemical Context\n\nThe viscosity of 1.309 mPa·s at x(methanol) = 0.5 is notably higher than that of either pure component at the same temperature — pure water has η ≈ 0.890 mPa·s and pure methanol has η ≈ 0.544 mPa·s. This positive deviation from ideal mixing behavior is a hallmark of the methanol–water system and arises from the restructuring of the hydrogen-bonding network. When methanol molecules are introduced into water, they can both donate and accept hydrogen bonds, leading to the formation of extended, cooperative hydrogen-bonded clusters that increase the mixture's resistance to flow. The viscosity maximum in this system occurs near x(water) ≈ 0.7–0.8 (i.e., x(methanol) ≈ 0.2–0.3), where the hydrogen-bonding network is most extensively reinforced.",
  "core_claims": [
    "The dynamic viscosity of the equimolar methanol + water liquid mixture at 298.15 K and 101 kPa is 0.001309 Pa·s (1.309 mPa·s), as directly measured by capillary tube viscometry and reported in ThermoML source GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004).",
    "This viscosity value at x(methanol) = 0.5 exhibits a strong positive deviation from ideal mixing, being substantially higher than either pure water (~0.890 mPa·s) or pure methanol (~0.544 mPa·s) at the same temperature, attributed to restructuring of the hydrogen-bonding network.",
    "Among the ThermoML sources examined, GLOBlit_2825 is the only one providing a direct viscosity measurement at the exact equimolar composition; the other two sources (GLOBlit_8869 and GLOBlit_9571) use composition ranges that do not extend to x(methanol) = 0.5.",
    "The viscosity maximum in the methanol–water system occurs near x(methanol) ≈ 0.2–0.3, not at the equimolar composition."
  ],
  "confidence": "high",
  "sources": [
    {
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_num_id": "GLOBlit_2825",
      "block": "PROPblock_9",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity of methanol + water binary mixture at T = 298.15 K, P = 101 kPa, x(methanol) = 0.5. Reported value: 0.001309 Pa·s (1.309 mPa·s). Block contains 39 datapoints spanning 13 mole-fraction compositions at 3 temperatures (293.15, 298.15, 303.15 K). Measurement method: capillary tube viscometry (CAPTUB:UFactor:2). This is the only ThermoML source providing a direct datapoint at the exact equimolar composition on a mole-fraction scale."
    },
    {
      "doi": "10.1021/je0600810",
      "lit_num_id": "GLOBlit_8869",
      "block": "PROPblock_3",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity of methanol + water binary mixture. Composition variable is volume fraction (GLOBvar_18, range 0.01–0.30), not mole fraction. 9 total datapoints (3 compositions × 3 temperatures, T range 298.15–318.15 K). Viscosity range 0.000702–0.001471 Pa·s. Does not provide a direct datapoint at x(methanol) = 0.5."
    },
    {
      "doi": "10.1021/je2003622",
      "lit_num_id": "GLOBlit_9571",
      "block": "PROPblock_1",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity of methanol + water binary mixture. Composition variable is mass fraction (GLOBvar_5, range 0.0806–0.3446), not mole fraction. 16 total datapoints (4 compositions × 4 temperatures, T range 298.15–323.15 K). Viscosity range 0.000638–0.001471 Pa·s. Mass fraction range does not reach x(methanol) = 0.5 equivalent (~0.640 mass fraction)."
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_4",
      "registry_id": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
      "name": "methanol"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_1",
      "registry_id": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
      "name": "water"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_2",
      "registry_id": "mole_fraction_DOIcomp_1",
      "name": "Mole fraction"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_18",
      "registry_id": "volume_fraction_DOIcomp_1",
      "name": "Volume fraction"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_5",
      "registry_id": "mass_fraction_DOIcomp_1",
      "name": "Mass fraction"
    },
    {
      "type": "constr",
      "global_id": "GLOBconstr_1",
      "registry_id": "pressure_kpa",
      "name": "Pressure, kPa"
    },
    {
      "type": "phase",
      "global_id": "GLOBphase_1",
      "registry_id": "liquid",
      "name": "Liquid"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_140",
      "registry_id": "captub_ufactor_2",
      "name": "CAPTUB:UFactor:2"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_271",
      "registry_id": "captub_ufactor_6",
      "name": "CAPTUB:UFactor:6"
    },
    {
      "type": "blocktype",
      "global_id": "GLOBblocktype_1",
      "registry_id": "PureOrMixtureData",
      "name": "PureOrMixtureData"
    }
  ],
  "follow_up_suggestions": [
    "Extract all 13 datapoints at T = 298.15 K from PROPblock_9 in GLOBlit_2825 to obtain the full viscosity-composition curve for methanol + water at 25 °C.",
    "Compare the viscosity maximum composition and magnitude across the three temperatures (293.15, 298.15, 303.15 K) available in GLOBlit_2825 to assess temperature dependence of the anomalous viscosity behavior.",
    "Search for excess viscosity or viscosity deviation data for methanol + water to quantify the non-ideal mixing contribution at x(methanol) = 0.5.",
    "Convert volume-fraction and mass-fraction compositions from GLOBlit_8869 and GLOBlit_9571 to mole fractions using density data to check for additional independent viscosity values near x(methanol) = 0.5."
  ]
}
</memory>

## User
What is the measured viscosity of an equimolar methanol + water liquid mixture at 25 °C and atmospheric pressure?

## Assistant
<summary>Searching for viscosity data of methanol + water mixture at 25°C and atmospheric pressure, specifically at equimolar composition (x = 0.5).</summary>
<tool_call>run_query_agent(question=Find measured vis…, context=The user wants th…)</tool_call>

## User
<tool_result>
(validation blocked run_query_agent earlier — corrected)
</tool_result>

## Assistant
<summary>Fixing tool call syntax to search for viscosity data of methanol + water mixture at 25°C and atmospheric pressure at equimolar composition.</summary>
<tool_call>run_query_agent(question=Find measured vis…, context=The user wants th…)</tool_call>
<wait/> (15 deferred)

## User
<tool_result>
<subagent_answer>
{
  "answer": "{\n  \"answer\": \"## Viscosity of Methanol + Water at Equimolar Composition (25 °C, Atmospheric Pressure)\\n\\n### Primary Result\\n\\nThe ThermoML database contains a direct measurement of the dynamic viscosity of the methanol (CH₃OH) + water (H₂O) binary liquid mixture at the requested conditions:\\n\\n| Property | Value |\\n|----------|-------|\\n| **Dynamic viscosity** | **0.001309 Pa·s (1.309 mPa·s)** |\\n| Temperature | 298.15 K (25.00 °C) |\\n| Pressure | 101 kPa (atmospheric) |\\n| Mole fraction of methanol | 0.5 (equimolar) |\\n| Phase | Liquid |\\n\\n**Source:** PROPblock_9 in GLOBlit_2825 (DOI: [10.1016/j.jct.2007.05.004](https://doi.org/10.1016/j.jct.2007.05.004))\\n\\nThis dataset contains 39 datapoints spanning 13 compositions (x_water = 0 to 1) at three temperatures (293.15, 298.15, and 303.15 K), with viscosities ranging from 0.000508 Pa·s (pure methanol end) to 0.001793 Pa·s (near the viscosity maximum). The measurement method is capillary tube viscometry.\\n\\n### Additional Sources in ThermoML\\n\\nTwo other ThermoML sources report viscosity for the methanol + water binary system at 298.15 K, but they use different composition scales and do not provide a direct datapoint at x(methanol) = 0.5:\\n\\n| Source | Block | DOI | Composition Scale | Points at 298.15 K | Viscosity Range (Pa·s) |\\n|--------|-------|-----|-------------------|:-------------------:|----------------------|\\n| GLOBlit_2825 | PROPblock_9 | 10.1016/j.jct.2007.05.004 | **Mole fraction** (13 compositions) | 13 | 0.000508 – 0.001793 |\\n| GLOBlit_8869 | PROPblock_3 | 10.1021/je0600810 | Volume fraction (3 compositions, range 0.01–0.30) | 3 | 0.000702 – 0.001471 |\\n| GLOBlit_9571 | PROPblock_1 | 10.1021/je2003622 | Mass fraction (4 compositions, range 0.08–0.34) | 4 | 0.000638 – 0.001471 |\\n\\nNote: x(methanol) = 0.5 corresponds to a mass fraction of ~0.640 for methanol, which falls outside the mass-fraction range of GLOBlit_9571 (max 0.3446). Similarly, the volume-fraction range in GLOBlit_8869 (max 0.30) likely does not reach the equimolar composition. Therefore, **GLOBlit_2825 is the only source providing a direct viscosity value at the exact equimolar composition**.\\n\\n### Chemical Context\\n\\nThe viscosity of 1.309 mPa·s at x(methanol) = 0.5 is notably higher than that of either pure component at the same temperature — pure water has η ≈ 0.890 mPa·s and pure methanol has η ≈ 0.544 mPa·s. This positive deviation from ideal mixing behavior is a hallmark of the methanol–water system and arises from the restructuring of the hydrogen-bonding network. When methanol molecules are introduced into water, they can both donate and accept hydrogen bonds, leading to the formation of extended, cooperative hydrogen-bonded clusters that increase the mixture's resistance to flow. The viscosity maximum in this system occurs near x(water) ≈ 0.7–0.8 (i.e., x(methanol) ≈ 0.2–0.3), where the hydrogen-bonding network is most extensively reinforced.\",\n  \"core_claims\": [\n    \"The dynamic viscosity of the equimolar methanol + water liquid mixture at 298.15 K and 101 kPa is 0.001309 Pa·s (1.309 mPa·s), as directly measured by capillary tube viscometry and reported in ThermoML source GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004).\",\n    \"This viscosity value at x(methanol) = 0.5 exhibits a strong positive deviation from ideal mixing, being substantially higher than either pure water (~0.890 mPa·s) or pure methanol (~0.544 mPa·s) at the same temperature, attributed to restructuring of the hydrogen-bonding network.\",\n    \"Among the ThermoML sources examined, GLOBlit_2825 is the only one providing a direct viscosity measurement at the exact equimolar composition; the other two sources (GLOBlit_8869 and GLOBlit_9571) use composition ranges that do not extend to x(methanol) = 0.5.\",\n    \"The viscosity maximum in the methanol–water system occurs near x(methanol) ≈ 0.2–0.3, not at the equimolar composition.\"\n  ],\n  \"confidence\": \"high\",\n  \"sources\": [\n    {\n      \"doi\": \"10.1016/j.jct.2007.05.004\",\n      \"lit_num_id\": \"GLOBlit_2825\",\n      \"block\": \"PROPblock_9\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity of methanol + water binary mixture at T = 298.15 K, P = 101 kPa, x(methanol) = 0.5. Reported value: 0.001309 Pa·s (1.309 mPa·s). Block contains 39 datapoints spanning 13 mole-fraction compositions at 3 temperatures (293.15, 298.15, 303.15 K). Measurement method: capillary tube viscometry (CAPTUB:UFactor:2). This is the only ThermoML source providing a direct datapoint at the exact equimolar composition on a mole-fraction scale.\"\n    },\n    {\n      \"doi\": \"10.1021/je0600810\",\n      \"lit_num_id\": \"GLOBlit_8869\",\n      \"block\": \"PROPblock_3\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity of methanol + water binary mixture. Composition variable is volume fraction (GLOBvar_18, range 0.01–0.30), not mole fraction. 9 total datapoints (3 compositions × 3 temperatures, T range 298.15–318.15 K). Viscosity range 0.000702–0.001471 Pa·s. Does not provide a direct datapoint at x(methanol) = 0.5.\"\n    },\n    {\n      \"doi\": \"10.1021/je2003622\",\n      \"lit_num_id\": \"GLOBlit_9571\",\n      \"block\": \"PROPblock_1\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity of methanol + water binary mixture. Composition variable is mass fraction (GLOBvar_5, range 0.0806–0.3446), not mole fraction. 16 total datapoints (4 compositions × 4 temperatures, T range 298.15–323.15 K). Viscosity range 0.000638–0.001471 Pa·s. Mass fraction range does not reach x(methanol) = 0.5 equivalent (~0.640 mass fraction).\"\n    }\n  ],\n  \"id_catalog_snapshot\": [\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_4\",\n      \"registry_id\": \"OKKJLVBELUTLKV-UHFFFAOYSA-N\",\n      \"name\": \"methanol\"\n    },\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_1\",\n      \"registry_id\": \"XLYOFNOQVPJJNP-UHFFFAOYSA-N\",\n      \"name\": \"water\"\n    },\n    {\n      \"type\": \"prop\",\n      \"global_id\": \"GLOBprop_4\",\n      \"registry_id\": \"viscosity_pa_s\",\n      \"name\": \"Viscosity, Pa*s\"\n    },\n    {\n      \"type\": \"var\",\n      \"global_id\": \"GLOBvar_1\",\n      \"registry_id\": \"temperature_k\",\n      \"name\": \"Temperature, K\"\n    },\n    {\n      \"type\": \"var\",\n      \"global_id\": \"GLOBvar_2\",\n      \"registry_id\": \"mole_fraction_DOIcomp_1\",\n      \"name\": \"Mole fraction\"\n    },\n    {\n      \"type\": \"var\",\n      \"global_id\": \"GLOBvar_18\",\n      \"registry_id\": \"volume_fraction_DOIcomp_1\",\n      \"name\": \"Volume fraction\"\n    },\n    {\n      \"type\": \"var\",\n      \"global_id\": \"GLOBvar_5\",\n      \"registry_id\": \"mass_fraction_DOIcomp_1\",\n      \"name\": \"Mass fraction\"\n    },\n    {\n      \"type\": \"constr\",\n      \"global_id\": \"GLOBconstr_1\",\n      \"registry_id\": \"pressure_kpa\",\n      \"name\": \"Pressure, kPa\"\n    },\n    {\n      \"type\": \"phase\",\n      \"global_id\": \"GLOBphase_1\",\n      \"registry_id\": \"liquid\",\n      \"name\": \"Liquid\"\n    },\n    {\n      \"type\": \"meas\",\n      \"global_id\": \"GLOBmeas_140\",\n      \"registry_id\": \"captub_ufactor_2\",\n      \"name\": \"CAPTUB:UFactor:2\"\n    },\n    {\n      \"type\": \"meas\",\n      \"global_id\": \"GLOBmeas_271\",\n      \"registry_id\": \"captub_ufactor_6\",\n      \"name\": \"CAPTUB:UFactor:6\"\n    },\n    {\n      \"type\": \"blocktype\",\n      \"global_id\": \"GLOBblocktype_1\",\n      \"registry_id\": \"PureOrMixtureData\",\n      \"name\": \"PureOrMixtureData\"\n    }\n  ],\n  \"follow_up_suggestions\": [\n    \"Extract all 13 datapoints at T = 298.15 K from PROPblock_9 in GLOBlit_2825 to obtain the full viscosity-composition curve for methanol + water at 25 °C.\",\n    \"Compare the viscosity maximum composition and magnitude across the three temperatures (293.15, 298.15, 303.15 K) available in GLOBlit_2825 to assess temperature dependence of the anomalous viscosity behavior.\",\n    \"Search for excess viscosity or viscosity deviation data for methanol + water to quantify the non-ideal mixing contribution at x(methanol) = 0.5.\",\n    \"Convert volume-fraction and mass-fraction compositions from GLOBlit_8869 and GLOBlit_9571 to mole fractions using density data to check for additional independent viscosity values near x(methanol) = 0.5.\"\n  ]\n}",
  "iterations": 4,
  "elapsed_seconds": 701.7157318592072,
  "tool_count": 3,
  "timed_out": false,
  "agent": "query",
  "_question": "Find measured viscosity data for a methanol + water binary liquid mixture at 25 degrees Celsius and atmospheric pressure, specifically at equimolar composition (mole fraction of methanol = 0.5).",
  "_session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q1.1.2_run_20260802_183843\\query_runs\\run_1"
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_query_agent). 15 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
## Measured Viscosity of Equimolar Methanol + Water at 25 °C

The dynamic viscosity of an equimolar (x_methanol = 0.5) methanol + water liquid mixture at 25 °C (298.15 K) and atmospheric pressure (101 kPa) is:

**η = 0.001309 Pa·s (1.309 mPa·s)**

This value was measured by capillary tube viscometry and is reported in PROPblock_9 of GLOBlit_2825 (DOI: 10.1016/j.jct.2007.05.004). The dataset contains 39 datapoints spanning 13 mole-fraction compositions (x_water = 0 to 1) at three temperatures (293.15, 298.15, and 303.15 K), with viscosities ranging from 0.000508 Pa·s (pure methanol end) to 0.001793 Pa·s (near the viscosity maximum).

### Chemical Context

The measured viscosity of 1.309 mPa·s at the equimolar composition is notably higher than that of either pure component at the same temperature:

| Component | η at 25 °C |
|-----------|-----------|
| Pure water | ~0.890 mPa·s |
| Pure methanol | ~0.544 mPa·s |
| **Equimolar mixture** | **1.309 mPa·s** |

This strong positive deviation from ideal mixing is a hallmark of the methanol–water system. It arises from the restructuring of the hydrogen-bonding network: methanol molecules can both donate and accept hydrogen bonds, leading to extended cooperative hydrogen-bonded clusters that increase the mixture's resistance to flow. The viscosity maximum in this system actually occurs near x(methanol) ≈ 0.2–0.3 (i.e., x_water ≈ 0.7–0.8), where the hydrogen-bonding network is most extensively reinforced.

### Additional ThermoML Sources

Two other ThermoML sources report viscosity for the methanol + water system at 298.15 K, but neither covers the equimolar composition:

| Source | Block | DOI | Composition Scale | Range |
|--------|-------|-----|-------------------|-------|
| GLOBlit_8869 | PROPblock_3 | 10.1021/je0600810 | Volume fraction | 0.01–0.30 |
| GLOBlit_9571 | PROPblock_1 | 10.1021/je2003622 | Mass fraction | 0.08–0.34 |

Neither of these ranges extends to the equimolar composition (x_methanol = 0.5 corresponds to a mass fraction of ~0.64), making GLOBlit_2825 the only ThermoML source with a direct measurement at the exact equimolar composition.

### Sources
- Literature ID: GLOBlit_2825 | DOI: 10.1016/j.jct.2007.05.004 | Block: PROPblock_9 | System: methanol + water
- Literature ID: GLOBlit_8869 | DOI: 10.1021/je0600810 | Block: PROPblock_3 | System: methanol + water
- Literature ID: GLOBlit_9571 | DOI: 10.1021/je2003622 | Block: PROPblock_1 | System: methanol + water
</answer>
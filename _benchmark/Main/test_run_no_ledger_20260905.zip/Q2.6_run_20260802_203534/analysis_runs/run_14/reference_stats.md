# Reference Stats — analysis-agent

**Run started:** 2026-08-02 20:52:37
**Wall time (at last flush):** 455.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 20 | 305,119 | 191,240 | 81,754 | 496,359 | 24,817 | 461.4 | claudeopus46 |
| **TOTAL** | **20** | **305,119** | **191,240** | **81,754** | **496,359** | **24,817** | **461.4** | |

**Estimated tokens:** ~124,089 input + ~20,438 output = ~144,527 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inspect_block` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 4 | `inspect_block` | block_number=3, doi=10.1016/j.jct.2006.12.012, pro… | 220 | — | — | 0.0 |
| 2 | 4 | `inspect_block` | block_number=3, doi=10.1021/je9001027, property_fi… | 220 | — | — | 0.0 |
| 3 | 6 | `inspect_block` | block_number=3, doi=10.1016/j.jct.2006.12.012, pro… | 146 | — | — | 0.0 |
| 4 | 6 | `inspect_block` | block_number=3, doi=10.1021/je9001027, property_fi… | 146 | — | — | 0.0 |
| 5 | 8 | `inspect_block` | block_number=PROPblock_3, doi=10.1016/j.jct.2006.1… | 1,379 | — | — | 0.1 |
| 6 | 8 | `inspect_block` | block_number=PROPblock_3, doi=10.1021/je9001027, p… | 1,368 | — | — | 0.1 |
| 7 | 11 | `fit_block` | block_number=PROPblock_3, composition_hint=mole_fr… | 924 | — | — | 1.0 |
| 8 | 11 | `fit_block` | block_number=PROPblock_3, composition_hint=mass_fr… | 754 | — | — | 1.1 |
| | | **TOTAL (8 tools)** | | **5,157** | | **0** | **2.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 5,403 | 5,403 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 1,018 | 21,039 | 1,253 | 7.6 |
| 2 | L0-main | claudeopus46 | 20,021 | 2,977 | 22,998 | 14,088 | 78.9 |
| 3 | L0-main | claudeopus46 | 20,021 | 3,953 | 23,974 | 13,976 | 72.7 |
| 4 | L0-main | claudeopus46 | 20,021 | 5,069 | 25,090 | 847 | 5.6 |
| 5 | L0-main | claudeopus46 | 20,021 | 4,419 | 24,440 | 765 | 4.2 |
| 6 | L0-main | claudeopus46 | 20,021 | 5,452 | 25,473 | 847 | 5.3 |
| 7 | L0-main | claudeopus46 | 19,988 | 6,516 | 26,504 | 457 | 3.6 |
| 8 | L0-main | claudeopus46 | 20,021 | 5,759 | 25,780 | 819 | 5.7 |
| 9 | L0-main | claudeopus46 | 20,021 | 6,824 | 26,845 | 879 | 5.8 |
| 10 | L0-main | claudeopus46 | 20,021 | 10,776 | 30,797 | 2,063 | 13.4 |
| 11 | L0-main | claudeopus46 | 20,021 | 13,425 | 33,446 | 7,006 | 38.3 |
| 12 | L0-main | claudeopus46 | 20,021 | 14,468 | 34,489 | 7,651 | 42.7 |
| 13 | L0-main | claudeopus46 | 20,021 | 18,432 | 38,453 | 8,504 | 47.7 |
| 14 | L0-main | claudeopus46 | 20,021 | 19,699 | 39,720 | 11,440 | 64.0 |
| 15 | L0-main | claudeopus46 | 20,021 | 31,867 | 51,888 | 4,437 | 23.0 |
| 16 | L0-main | claudeopus46 | 1,356 | 4,566 | 5,922 | 957 | 6.6 |
| 17 | L0-main | claudeopus46 | 298 | 1,339 | 1,637 | 945 | 4.0 |
| 18 | L0-main | claudeopus46 | 1,323 | 24,665 | 25,988 | 1,984 | 13.3 |
| 19 | L0-main | claudeopus46 | 298 | 2,826 | 3,124 | 1,751 | 9.7 |
| 20 | L0-main | claudeopus46 | 1,562 | 7,190 | 8,752 | 1,085 | 9.3 |


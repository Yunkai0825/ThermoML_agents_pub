# Analysis Run — 20260802_210012 (Round 1)

**Question:** [Purpose: Precisely locate the viscosity maximum composition and value for water+DMSO at 25°C to identify the composition of strongest molecular interaction.]
Retrieve the point-level viscosity data from GLOBlit_2781 PROPblock_3 for the binary water + DMSO system at T = 298.15 K. Identify the composition (mole fraction of DMSO) at which the viscosity reaches its maximum value, and report the maximum viscosity value. Also retrieve data from GLOBlit_11517 PROPblock_3 at 298.15 K for comparison.

[Context: GLOBlit_2781 DOI 10.1016/j.jct.2006.12.012 PROPblock_3 has 120 viscosity data points for water+DMSO, x(DMSO)=0-1, T=298.15-318.15K, 24 mole fractions. GLOBlit_11517 DOI 10.1021/je9001027 PROPblock_3 has 35 points, w(DMSO)=0-1, T=298.15-318.15K. Water=GLOBcomp_1, DMSO=GLOBcomp_31, viscosity=GLOBprop_4.]

**Time:** 422.5s | **Iterations:** 14 | **Tools:** 25

---

## Answer

# Viscosity Maximum of Water + Dimethyl Sulfoxide (DMSO) at 298.15 K

## Key Finding

The viscosity of the water + DMSO binary system at 298.15 K reaches a pronounced **maximum of η = 0.003124 Pa·s at x(DMSO) = 0.32** (mole fraction of DMSO), based on the high-resolution dataset from DOI: 10.1016/j.jct.2006.12.012 (GLOBlit_2781, PROPblock_3). This maximum is approximately **3.5× the viscosity of pure water** (0.000890 Pa·s) and **1.6× that of pure DMSO** (0.001996 Pa·s), indicating exceptionally strong intermolecular interactions at this composition.

## Chemical Interpretation

The viscosity maximum near x(DMSO) ≈ 0.33 corresponds closely to a **1:2 DMSO-to-water molar ratio**, consistent with the well-established formation of DMSO·2H₂O hydrogen-bonded complexes. At this composition, the S=O group of DMSO acts as a strong hydrogen-bond acceptor for two water molecules, creating an extended, structured hydrogen-bond network that dramatically increases the resistance to flow. This stoichiometric complex has been confirmed by numerous spectroscopic and computational studies and is one of the classic examples of non-ideal mixing in aqueous systems.

## Data Source 1 (Primary): GLOBlit_2781

- **DOI:** 10.1016/j.jct.2006.12.012
- **Block:** PROPblock_3
- **Data points at 298.15 K:** 22 mixture compositions + 2 pure endpoints (24 total)
- **Composition basis:** Mole fraction of DMSO (0 → 1)
- **Pure-component viscosities (block edges):**
  - Water: 0.0008901 Pa·s
  - DMSO: 0.001996 Pa·s

### Redlich-Kister Fit (Arrhenius mixing rule)

| Parameter | Value |
|-----------|-------|
| BIC-selected order | 5 |
| R² | 0.999497 |
| RMSE | 0.008820 |
| BIC | −189.61 |

**RK Coefficients (ln η basis, Arrhenius):**

| A₀ | A₁ | A₂ | A₃ | A₄ | A₅ |
|----|----|----|----|----|-----|
| 3.70556 | −3.85972 | 2.18304 | −0.818153 | −1.80305 | 2.54827 |

### Predicted Viscosity Maximum

From the 101-point RK prediction curve:

| **x(DMSO) at maximum** | **η_max (Pa·s)** |
|:-----------------------:|:----------------:|
| **0.32** | **0.003124** |

Representative data points near the maximum:

| x(DMSO) | η (Pa·s) |
|---------|----------|
| 0.28 | 0.003047 |
| 0.30 | 0.003110 |
| 0.31 | 0.003123 |
| **0.32** | **0.003124** |
| 0.33 | 0.003114 |
| 0.34 | 0.003093 |
| 0.36 | 0.003024 |

The viscosity rises steeply from pure water, peaks sharply around x(DMSO) = 0.32, then decreases more gradually toward pure DMSO.

## Data Source 2 (Comparison): GLOBlit_11517

- **DOI:** 10.1021/je9001027
- **Block:** PROPblock_3
- **Data points at 298.15 K:** 5 mixture compositions (mass fraction basis, converted to mole fraction)
- **Pure-component viscosities (block edges):**
  - Water: 0.00089 Pa·s
  - DMSO: 0.001966 Pa·s

### Redlich-Kister Fit (Arrhenius mixing rule)

| Parameter | Value |
|-----------|-------|
| BIC-selected order | 1 |
| R² | 0.877420 |
| RMSE | 0.093513 |
| BIC | −13.70 |

**RK Coefficients:** A₀ = 0.59248, A₁ = −9.44449

⚠ **Limitation:** With only 5 mixture data points, the BIC selects a first-order RK polynomial that cannot resolve the viscosity peak. The predicted "maximum" of 0.001966 Pa·s at x(DMSO) = 0.42 merely reaches the pure DMSO endpoint — this is an artifact of insufficient data density, not a physical result. The composition basis was originally mass fraction, converted exactly to mole fraction using M(DMSO) = 78.129 g/mol and M(H₂O) = 18.015 g/mol.

## Comparison and Recommendation

| Metric | GLOBlit_2781 | GLOBlit_11517 |
|--------|-------------|---------------|
| Mixture points (298.15 K) | 22 | 5 |
| RK order (BIC) | 5 | 1 |
| R² | 0.9995 | 0.8774 |
| Resolved maximum? | ✓ Yes | ✗ No |
| η_max (Pa·s) | 0.003124 | — |
| x(DMSO) at max | 0.32 | — |

The GLOBlit_2781 dataset (10.1016/j.jct.2006.12.012) is the authoritative source for this system. Its 22-point isotherm at 298.15 K with an order-5 RK fit (R² = 0.9995) cleanly resolves the viscosity maximum at **x(DMSO) = 0.32, η = 0.003124 Pa·s**, consistent with the known 1:2 DMSO:water stoichiometric complex.

## Output Files

- Fit data CSV: `10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.csv`
- Excess property CSV: `10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.csv`
- Fit plot: `10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.png`
- Excess plot: `10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.png`
- Prediction CSV (101-point curve): `predict_rk_viscosity_arrhenius.csv`

### Core claims

- At 298.15 K, the dynamic viscosity of the water + DMSO binary system reaches a maximum of 0.003124 Pa·s at a DMSO mole fraction of 0.32, approximately 3.5 times the viscosity of pure water and 1.6 times that of pure DMSO, based on a 22-point isotherm fitted with an order-5 Redlich-Kister polynomial (R² = 0.9995) from DOI 10.1016/j.jct.2006.12.012.
- The viscosity maximum near x(DMSO) ≈ 0.33 is consistent with the formation of a 1:2 DMSO:water hydrogen-bonded stoichiometric complex, in which the S=O group of DMSO acts as a strong hydrogen-bond acceptor for two water molecules, creating an extended network that increases resistance to flow.
- A second dataset (DOI 10.1021/je9001027) with only 5 mixture compositions at 298.15 K is insufficient to resolve the viscosity maximum; BIC selects only a first-order Redlich-Kister fit (R² = 0.877) that produces an artifactual result rather than a physically meaningful peak.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 |  | 120 viscosity data points for binary water (GLOBcomp_1) + DMSO (GLOBcomp_31) system, mole fraction basis, T = 298.15–318.15 K, 24 compositions. BLKprop_1 / GLOBprop_4 viscosity_pa_s, direct value, liquid phase (GLOBphase_1). Measurement GLOBmeas_140. 22 mixture points at 298.15 K used for RK fit. Pure-component viscosities: water = 0.0008901 Pa·s, DMSO = 0.001996 Pa·s. Order-5 RK fit (BIC = −189.61) resolves viscosity maximum at x(DMSO) = 0.32, η_max = 0.003124 Pa·s. |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3 |  | 35 viscosity data points for binary water (GLOBcomp_1) + DMSO (GLOBcomp_31) system, mass fraction basis, T = 298.15–318.15 K. BLKprop_1 / GLOBprop_4 viscosity_pa_s, direct value, liquid phase (GLOBphase_1). Measurement GLOBmeas_205. Only 5 mixture points at 298.15 K; BIC selects order-1 RK fit (R² = 0.877) which cannot resolve the viscosity maximum. Pure-component viscosities: water = 0.00089 Pa·s, DMSO = 0.001966 Pa·s. |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_2781 | PROPblock_3 | viscosity | 5 | 3.70556; -3.85972; 2.18304; -0.818153; -1.80305; 2.54827 | 0.999497 | 0.0088198 | 22 | 298.15 | arrhenius |  | 10.1016/j.jct.2006.12.012 |
| GLOBlit_11517 | PROPblock_3 | viscosity | 1 | 0.59248; -9.44449 | 0.87742 | 0.0935125 | 5 | 298.15 | arrhenius |  | 10.1021/je9001027 |

---

## Verdict

**Data Quality**
Both datasets were retrieved via `fit_block` calls, confirming no fabrication. GLOBlit_2781 provides dense mole-fraction data (22 points at 298.15 K) — appropriate. GLOBlit_11517 originally uses mass fraction; the agent correctly notes conversion to mole fraction, satisfying the composition_conversion annotation requirement. Pure-component values appear consistent with literature. The Arrhenius mixing rule (ln η basis) is physically appropriate for viscosity.

**Fit Quality**
GLOBlit_2781: Order-5 RK with R²=0.9995 is excellent and justified by 22 data points (no overfitting concern). GLOBlit_11517: Order-1 with R²=0.877 correctly reflects insufficient data — the agent appropriately flags this as unreliable for locating the maximum.

**Scientific Verdict**
The maximum viscosity of ~3.12 mPa·s at x(DMSO)≈0.32 is consistent with literature values and the well-known DMSO·2H₂O complex interpretation. The agent's analysis is thorough, correctly prioritizes the denser dataset, and properly caveats the sparse dataset. Results are reliable and well-documented.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\data\10_1021_je9001027_BPROPblock_3_T298.1_fit.csv` — RK fit data — 10.1021/je9001027 PROPblock_3_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\data\10_1021_je9001027_BPROPblock_3_T298.1_excess.csv` — Excess property — 10.1021/je9001027 PROPblock_3_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\plots\10_1021_je9001027_BPROPblock_3_T298.1_fit.png` — RK fit plot — 10.1021/je9001027 PROPblock_3_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14\plots\10_1021_je9001027_BPROPblock_3_T298.1_excess.png` — Excess plot — 10.1021/je9001027 PROPblock_3_T298.1
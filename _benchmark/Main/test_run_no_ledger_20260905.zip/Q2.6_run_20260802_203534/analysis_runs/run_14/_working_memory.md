# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.6_run_20260802_203534\analysis_runs\run_14`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_31 | dimethyl sulfoxide | 0.001966 |
| comp | GLOBcomp_1 | water | 0.00089 |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<dimethyl sulfoxide> |  |
| var | GLOBvar_5 | massfraction<dimethyl sulfoxide> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [inspect_block]
- [inspect_block]
- [fit_block]
- [fit_block]

### Inspected Blocks
- GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3: 120 rows; x=['mole_fraction_<dimethyl sulfoxide>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3: 35 rows; x=['mass_fraction_<dimethyl sulfoxide>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - 10.1016/j.jct.2006.12.012/PROPblock_3 (dimethyl sulfoxide, water): RK order=5, R²=0.999497, RMSE=0.00881979868119369, coeffs=[3.705556, -3.859721, 2.183037, -0.818153, -1.803052, 2.548267]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: dimethyl sulfoxide=0.001996, water=0.0008901 [block-edges (water: direct/good, dimethyl sulfoxide: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.png
  - 10.1021/je9001027/PROPblock_3 (dimethyl sulfoxide, water): RK order=1, R²=0.87742, RMSE=0.09351251361081543, coeffs=[0.59248, -9.44449]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      ⚠ Composition axis converted to mole fraction of dimethyl sulfoxide: mass_fraction → mole_fraction via x1=(w1/M1)/(w1/M1+w2/M2), M1=78.129, M2=18.015 g/mol [exact (molar masses from block formulas)]. Source column: mass_fraction_<dimethyl sulfoxide>.
      pure refs: dimethyl sulfoxide=0.001966, water=0.00089 [block-edges (water: direct/good, dimethyl sulfoxide: direct/good)]
      fit_csv: $ROOT/data\10_1021_je9001027_BPROPblock_3_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je9001027_BPROPblock_3_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je9001027_BPROPblock_3_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je9001027_BPROPblock_3_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/data\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/data\10_1021_je9001027_BPROPblock_3_T298.1_fit.csv` — RK fit data — 10.1021/je9001027 PROPblock_3_T298.1
- `$ROOT/data\10_1021_je9001027_BPROPblock_3_T298.1_excess.csv` — Excess property — 10.1021/je9001027 PROPblock_3_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/plots\10_1016_j_jct_2006_12_012_BPROPblock_3_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2006.12.012 PROPblock_3_T298.1
- `$ROOT/plots\10_1021_je9001027_BPROPblock_3_T298.1_fit.png` — RK fit plot — 10.1021/je9001027 PROPblock_3_T298.1
- `$ROOT/plots\10_1021_je9001027_BPROPblock_3_T298.1_excess.png` — Excess plot — 10.1021/je9001027 PROPblock_3_T298.1


# Reference Stats — main-agent

**Run started:** 2026-08-02 20:35:34
**Wall time (at last flush):** 2,043.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 12 | 75,696 | 229,566 | 47,573 | 305,262 | 25,438 | 256.2 | claudeopus46 |
| L0-menu-planner | 1 | 831 | 1,391 | 2,452 | 2,222 | 2,222 | 14.8 | claudesonnet46 |
| **TOTAL** | **13** | **76,527** | **230,957** | **50,025** | **307,484** | **23,652** | **271.0** | |

**Estimated tokens:** ~76,871 input + ~12,506 output = ~89,377 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_parallel_subagents` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `browse_subagent_tools` | purpose=Find thermodynamic and transp…, tasks=Sear… | 2,452 | — | — | 14.9 |
| 2 | 3 | `run_parallel_subagents` | tasks=[{'agent': 'query', 'label': … | 16,859 | — | — | 889.4 |
| 3 | 5 | `run_analysis_agent` | context=GLOBlit_2781 DOI 10.1016/j.jc…, purpose=Pr… | 12,799 | — | — | 455.5 |
| 4 | 5 | `run_query_agent` | context=We already know 12 binary dat…, purpose=Id… | 13,139 | — | — | 441.7 |
| | | **TOTAL (4 tools)** | | **45,249** | | **0** | **1801.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 3,392 | 3,392 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 408 | 10,623 | 1,139 | 6.6 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,229 | 11,444 | 14,410 | 60.3 |
| 3 | L0-menu-planner | claudesonnet46 | 831 | 1,391 | 2,222 | 2,452 | 14.8 |
| 4 | L0-main | claudeopus46 | 10,182 | 4,474 | 14,656 | 597 | 4.7 |
| 5 | L0-main | claudeopus46 | 10,215 | 3,717 | 13,932 | 1,907 | 10.5 |
| 6 | L0-main | claudeopus46 | 10,215 | 35,813 | 46,028 | 2,703 | 19.4 |
| 7 | L0-main | claudeopus46 | 10,215 | 36,893 | 47,108 | 2,697 | 16.3 |
| 8 | L0-main | claudeopus46 | 10,215 | 59,328 | 69,543 | 9,155 | 56.3 |
| 9 | L0-main | claudeopus46 | 1,356 | 8,172 | 9,528 | 1,456 | 10.3 |
| 10 | L0-main | claudeopus46 | 298 | 1,838 | 2,136 | 1,411 | 4.5 |
| 11 | L0-main | claudeopus46 | 1,323 | 64,758 | 66,081 | 5,651 | 30.8 |
| 12 | L0-main | claudeopus46 | 298 | 6,174 | 6,472 | 4,827 | 25.0 |
| 13 | L0-main | claudeopus46 | 949 | 6,762 | 7,711 | 1,620 | 11.5 |


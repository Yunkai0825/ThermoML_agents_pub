# Delegated query run — result

**Question:** Find all density (mass density) and speed of sound data for the binary system of water (GLOBcomp_1) and dimethyl sulfoxide (DMSO, GLOBcomp_31) near 298.15 K in the ThermoML database. Report literature IDs, DOIs, block numbers, temperature ranges, composition ranges, and number of data points.

**Iterations:** 4  |  **Elapsed:** 397.5s  |  **Tools:** 6  |  **Timed out:** False

---

## Answer

## Mass Density and Speed of Sound Data for Water + DMSO Binary System in ThermoML

The ThermoML database contains **9 mass density data blocks** (484 total raw data points) and **3 speed of sound data blocks** (62 total raw data points) for the water + DMSO binary system. All data are for the liquid phase.

---

### Mass Density (GLOBprop_1) — 9 Blocks, 484 Data Points

| # | Literature ID | Block | DOI | Points | T range (K) | Composition range | Basis | P (kPa) | ρ range (kg/m³) |
|---|:---:|:---:|-----|:---:|-------------|-------------------|-------|:---:|-----------------|
| 1 | GLOBlit_2584 | PROPblock_8 | 10.1016/j.jct.2005.07.012 | 96 | 288.15–303.15 | x(water) 0.031–0.980 | Mole fraction | 100 | 1005.7–1108.5 |
| 2 | GLOBlit_2652 | PROPblock_4 | 10.1016/j.jct.2006.01.007 | 6 | 288.15–313.15 | x(DMSO) = 0.0385 (fixed) | Mole fraction | 101 | 1010.2–1019.8 |
| 3 | GLOBlit_2781 | PROPblock_4 | 10.1016/j.jct.2006.12.012 | 120 | 298.15–318.15 | x(DMSO) 0.0–1.0 | Mole fraction | 101 | 990.2–1098.9 |
| 4 | GLOBlit_2842 | PROPblock_6 | 10.1016/j.jct.2007.06.007 | 40 | 275.15–283.15 | x(DMSO) 0.0–0.697 | Mole fraction | 101 | 999.7–1158.3 |
| 5 | GLOBlit_2844 | PROPblock_4 | 10.1016/j.jct.2007.06.010 | 92 | 278.15–368.15 | b(DMSO) 0.021–3.000 mol/kg | Molality | 350 | 962.4–1028.8 |
| 6 | GLOBlit_5953 | PROPblock_12 | 10.1016/j.tca.2011.08.013 | 16 | 303.15–318.15 | x(DMSO) 0.012–0.058 | Mole fraction | 101 | 996.2–1021.4 |
| 7 | GLOBlit_7713 | PROPblock_10 | 10.1021/acs.jced.8b01048 | 9 | 293.15–373.15 | x(DMSO) = 0.998 (fixed) | Mole fraction | 100 | 1019.8–1100.2 |
| 8 | GLOBlit_11018 | PROPblock_6 | 10.1021/je700645p | 70 | 293.15–333.15 | x(water) 0.0–1.0 | Mole fraction | 81.5 | 983.2–1103.5 |
| 9 | GLOBlit_11517 | PROPblock_4 | 10.1021/je9001027 | 35 | 298.15–318.15 | w(DMSO) 0.0–1.0 | Mass fraction | 101 | 953.2–1095.4 |

---

### Speed of Sound (GLOBprop_8) — 3 Blocks, 62 Data Points

| # | Literature ID | Block | DOI | Points | T range (K) | Composition range | Basis | P (kPa) | u range (m/s) |
|---|:---:|:---:|-----|:---:|-------------|-------------------|-------|:---:|---------------|
| 1 | GLOBlit_2652 | PROPblock_3 | 10.1016/j.jct.2006.01.007 | 6 | 288.15–313.15 | x(DMSO) = 0.0385 (fixed) | Mole fraction | 101 | 1555.2–1579.4 |
| 2 | GLOBlit_2842 | PROPblock_5 | 10.1016/j.jct.2007.06.007 | 40 | 275.15–283.15 | x(DMSO) 0.0–0.697 | Mole fraction | 101 | 1415.0–1771.0 |
| 3 | GLOBlit_5953 | PROPblock_11 | 10.1016/j.tca.2011.08.013 | 16 | 303.15–318.15 | x(DMSO) 0.012–0.058 | Mole fraction | 101 | 1534.6–1604.9 |

---

### Best Candidates for Analysis at 298.15 K

**Density blocks covering 298.15 K with broad composition range:**

1. **GLOBlit_2781 / PROPblock_4** (DOI: 10.1016/j.jct.2006.12.012) — The single best dataset: 120 data points, full composition coverage x(DMSO) = 0–1, T starts exactly at 298.15 K, 24 unique compositions, 101 kPa. Ideal for computing excess molar volumes V^E.

2. **GLOBlit_2584 / PROPblock_8** (DOI: 10.1016/j.jct.2005.07.012) — 96 data points, x(water) 0.031–0.980, T range includes 298.15 K (upper bound of 288.15–303.15 K range), 24 unique compositions, 100 kPa. Excellent complementary dataset.

3. **GLOBlit_11018 / PROPblock_6** (DOI: 10.1021/je700645p) — 70 data points, full composition range x(water) 0–1, T range 293.15–333.15 K spans 298.15 K, 14 unique compositions. Note: measured at 81.5 kPa (reduced pressure), which may introduce a small systematic offset relative to atmospheric-pressure data.

4. **GLOBlit_11517 / PROPblock_4** (DOI: 10.1021/je9001027) — 35 data points, full composition range w(DMSO) 0–1, T starts at 298.15 K, 101 kPa. Composition is in mass fraction, requiring conversion to mole fraction for V^E calculations.

5. **GLOBlit_2844 / PROPblock_4** (DOI: 10.1016/j.jct.2007.06.010) — 92 data points spanning 278.15–368.15 K (includes 298.15 K), but composition is in molality (0.021–3.000 mol/kg) and pressure is 350 kPa. Requires both composition-basis conversion and pressure correction.

**Speed of sound blocks near 298.15 K:**

- **GLOBlit_2652 / PROPblock_3** (DOI: 10.1016/j.jct.2006.01.007) — The only speed-of-sound block spanning 298.15 K, but covers only a single dilute composition (x(DMSO) = 0.0385). Not suitable for full-composition analysis at 298.15 K.
- No speed-of-sound block provides full composition coverage at 298.15 K. The closest full-composition dataset is GLOBlit_2842 / PROPblock_5 at 275.15–283.15 K.

---

### Key Observations

- **Paired density + speed of sound data** from the same source exist in two references: GLOBlit_2652 (DOI: 10.1016/j.jct.2006.01.007) and GLOBlit_2842 (DOI: 10.1016/j.jct.2007.06.007), enabling internally consistent thermodynamic analysis (e.g., isentropic compressibility κ_S = 1/(ρu²)).

- **For excess molar volume (V^E) calculations at 298.15 K**, the most suitable datasets are GLOBlit_2781/PROPblock_4 and GLOBlit_2584/PROPblock_8, both offering broad mole-fraction coverage at or near 298.15 K and atmospheric pressure.

- **Composition basis varies** across blocks: most use mole fraction, but one uses molality (GLOBlit_2844) and one uses mass fraction (GLOBlit_11517), requiring conversion for direct comparison or V^E computation.

- The water + DMSO system is known for strong negative excess volumes (volume contraction upon mixing), driven by hydrogen bonding between DMSO's S=O group and water, with a minimum V^E near x(DMSO) ≈ 0.33 corresponding to a 1:2 DMSO:water stoichiometry. The density data above — showing maximum densities well above either pure component (e.g., up to ~1100 kg/m³ vs. ~997 kg/m³ for pure water and ~1096 kg/m³ for pure DMSO at 298 K) — are consistent with this strong intermolecular interaction.

### Core claims

- The ThermoML database contains 9 mass density data blocks (484 total data points) and 3 speed of sound data blocks (62 total data points) for the water + DMSO binary system, all for the liquid phase.
- For excess molar volume calculations at 298.15 K, the most suitable datasets are GLOBlit_2781/PROPblock_4 (120 points, full mole-fraction coverage x(DMSO) 0–1, 101 kPa) and GLOBlit_2584/PROPblock_8 (96 points, x(water) 0.031–0.980, 100 kPa), both offering broad composition coverage at atmospheric pressure.
- No speed-of-sound block provides full composition coverage at 298.15 K; the only block spanning that temperature (GLOBlit_2652/PROPblock_3) covers only a single dilute composition (x(DMSO) = 0.0385).
- Paired density and speed of sound data from the same source exist in two references (GLOBlit_2652 and GLOBlit_2842), enabling internally consistent thermodynamic analysis such as isentropic compressibility.
- Composition basis varies across blocks (mole fraction, molality, mass fraction), requiring conversion for direct comparison or excess molar volume computation.
- The density data showing maximum values (~1100 kg/m³) exceeding those of either pure component (~997 kg/m³ for water, ~1096 kg/m³ for DMSO at 298 K) are consistent with the known strong negative excess volumes in the water + DMSO system, driven by hydrogen bonding between DMSO's S=O group and water.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2584 | 10.1016/j.jct.2005.07.012 | PROPblock_8 |  | Mass density of water+DMSO, 96 points, T 288.15–303.15 K, x(water) 0.031–0.980, mole fraction basis, 100 kPa |
| GLOBlit_2652 | 10.1016/j.jct.2006.01.007 | PROPblock_4 |  | Mass density of water+DMSO, 6 points, T 288.15–313.15 K, x(DMSO)=0.0385 fixed, mole fraction basis, 101 kPa |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_4 |  | Mass density of water+DMSO, 120 points, T 298.15–318.15 K, x(DMSO) 0.0–1.0, mole fraction basis, 101 kPa |
| GLOBlit_2842 | 10.1016/j.jct.2007.06.007 | PROPblock_6 |  | Mass density of water+DMSO, 40 points, T 275.15–283.15 K, x(DMSO) 0.0–0.697, mole fraction basis, 101 kPa |
| GLOBlit_2844 | 10.1016/j.jct.2007.06.010 | PROPblock_4 |  | Mass density of water+DMSO, 92 points, T 278.15–368.15 K, b(DMSO) 0.021–3.000 mol/kg, molality basis, 350 kPa |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_12 |  | Mass density of water+DMSO, 16 points, T 303.15–318.15 K, x(DMSO) 0.012–0.058, mole fraction basis, 101 kPa |
| GLOBlit_7713 | 10.1021/acs.jced.8b01048 | PROPblock_10 |  | Mass density of near-pure DMSO (x(DMSO)=0.998 fixed), 9 points, T 293.15–373.15 K, mole fraction basis, 100 kPa |
| GLOBlit_11018 | 10.1021/je700645p | PROPblock_6 |  | Mass density of water+DMSO, 70 points, T 293.15–333.15 K, x(water) 0.0–1.0, mole fraction basis, 81.5 kPa |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_4 |  | Mass density of water+DMSO, 35 points, T 298.15–318.15 K, w(DMSO) 0.0–1.0, mass fraction basis, 101 kPa |
| GLOBlit_2652 | 10.1016/j.jct.2006.01.007 | PROPblock_3 |  | Speed of sound of water+DMSO, 6 points, T 288.15–313.15 K, x(DMSO)=0.0385 fixed, mole fraction basis, 101 kPa |
| GLOBlit_2842 | 10.1016/j.jct.2007.06.007 | PROPblock_5 |  | Speed of sound of water+DMSO, 40 points, T 275.15–283.15 K, x(DMSO) 0.0–0.697, mole fraction basis, 101 kPa |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_11 |  | Speed of sound of water+DMSO, 16 points, T 303.15–318.15 K, x(DMSO) 0.012–0.058, mole fraction basis, 101 kPa |

### Suggested follow-ups

- Retrieve raw data points at T=298.15 K from GLOBlit_2781/PROPblock_4 and GLOBlit_2584/PROPblock_8 to compute excess molar volumes V^E across the full composition range.
- Cross-validate density values at 298.15 K between the multiple overlapping datasets (GLOBlit_2781, GLOBlit_2584, GLOBlit_11018, GLOBlit_11517) to assess inter-laboratory consistency.
- Combine paired density and speed-of-sound data from GLOBlit_2842 (PROPblock_6 + PROPblock_5) and GLOBlit_2652 (PROPblock_4 + PROPblock_3) to compute isentropic compressibility κ_S = 1/(ρu²).
- Search for pure-component density data for water (GLOBcomp_1) and DMSO (GLOBcomp_31) at 298.15 K to use as reference values in V^E calculations.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "7732-18-5",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_31",
    "registry_id": "67-68-5",
    "name": "dimethyl sulfoxide (DMSO)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density",
    "name": "Mass density (kg/m³)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_8",
    "registry_id": "speed_of_sound",
    "name": "Speed of sound (m/s)"
  }
]
```

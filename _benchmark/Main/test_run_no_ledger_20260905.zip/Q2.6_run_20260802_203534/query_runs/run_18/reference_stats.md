# Reference Stats — query-agent

**Run started:** 2026-08-02 21:00:12
**Wall time (at last flush):** 441.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 218,101 | 37,677 | 259,796 | 32,474 | 202.1 | claudeopus46 |
| L1-worker | 26 | 188,384 | 562,784 | 39,927 | 751,168 | 28,891 | 266.9 | claudeopus46 |
| **TOTAL** | **34** | **230,079** | **780,885** | **77,604** | **1,010,964** | **29,734** | **469.0** | |

**Estimated tokens:** ~252,741 input + ~19,401 output = ~272,142 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_blocks` | 2 | 1 | 4 | 2 | 9 | 9 | 484 |
| `search_blocks` | 2 | 1 | 2 | 2 | 3 | 3 | 62 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 4 | 2 | 9 | 9 | 484 |
| `search_system_registry` | 2 | 1 | 4 | 2 | 9 | 9 | 484 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 70 |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 9 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 35 |
| **TOTAL** | **14** | **7** | **19** | **12** | **33** | **33** | **1,628** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2584 |  | search_blocks, search_system_registry |
| GLOBlit_2652 |  | search_blocks, search_system_registry |
| GLOBlit_2781 |  | search_blocks, search_system_registry |
| GLOBlit_2842 |  | search_blocks, search_system_registry |
| GLOBlit_2844 |  | search_blocks, search_system_registry |
| GLOBlit_5953 |  | search_blocks, search_system_registry |
| GLOBlit_7713 |  | search_blocks, search_system_registry |
| GLOBlit_11018 |  | search_blocks, search_system_registry |
| GLOBlit_11517 |  | search_blocks, search_system_registry |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_31 | dimethyl sulfoxide | search_blocks, search_system_registry |
| GLOBcomp_1 | water | search_blocks, search_system_registry |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks |

#### Measurements (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_495 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks |
| GLOBmeas_811 | Speed of sound, m/s | search_blocks |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_3 | Mole fraction | search_blocks, search_system_registry |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 9 |
| Unique Compounds | 2 |
| Unique Properties | 2 |
| Unique Measurements | 9 |
| Unique Phases | 1 |
| Unique Variables | 4 |
| Unique Constraints | 2 |
| Unique Solvents | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 9 |
| Unique parent blocks | 12 |
| Explicit block/subsystem targets | 12 |
| Subsystem targets | 0 |
| Target-matched data points | 1,628 |

---

## 3. DOI & Block References

**Unique DOIs:** 9  |  **Parent blocks:** 12  |  **Explicit targets:** 12  |  **Subsystems:** 0  |  **Target-matched datapoints:** 546

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2005.07.012 | 1 | 96 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.01.007 | 2 | 12 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.12.012 | 1 | 120 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.007 | 2 | 80 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.010 | 1 | 92 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2011.08.013 | 2 | 32 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b01048 | 1 | 9 | binary | search_blocks, search_system_registry |
| 10.1021/je700645p | 1 | 70 | binary | search_blocks, search_system_registry |
| 10.1021/je9001027 | 1 | 35 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2005.07.012 | PROPblock_8 | declared | 96 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.01.007 | PROPblock_3 | declared | 6 | binary | — | search_blocks |
| 10.1016/j.jct.2006.01.007 | PROPblock_4 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.12.012 | PROPblock_4 | declared | 120 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.007 | PROPblock_5 | declared | 40 | binary | — | search_blocks |
| 10.1016/j.jct.2007.06.007 | PROPblock_6 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.010 | PROPblock_4 | declared | 92 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2011.08.013 | PROPblock_11 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.tca.2011.08.013 | PROPblock_12 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b01048 | PROPblock_10 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700645p | PROPblock_6 | declared | 70 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je9001027 | PROPblock_4 | declared | 35 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `memory_catalog_add` | global_id=GLOBcomp_1, name=water, registry_id=7732… | 2 | — | — | 0.1 |
| 2 | 1 | `memory_catalog_add` | global_id=GLOBcomp_31, name=dimethyl sulfoxide (DM… | 2 | — | — | 0.0 |
| 3 | 1 | `memory_catalog_add` | global_id=GLOBprop_1, name=Mass density (kg/m³), r… | 2 | — | — | 0.0 |
| 4 | 1 | `memory_catalog_add` | global_id=GLOBprop_8, name=Speed of sound (m/s), r… | 2 | — | — | 0.0 |
| 5 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 1,226 | KEEP | 1226 | 14.1 |
| 6 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 844 | KEEP | 844 | 12.4 |
| 7 | 2 | `L1_query` | context=We know 12 binary data blocks…, id_catalog… | 270 | — | — | 102.8 |
| 8 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 1,197 | KEEP | 1092 | 19.2 |
| 9 | 2 | `search_system_registry` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=20, … | 1,093 | KEEP | 1078 | 19.4 |
| 10 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=10, … | 1,387 | KEEP | 1371 | 13.1 |
| 11 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=10, … | 1,118 | KEEP | 1118 | 13.0 |
| 12 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=10, … | 962 | KEEP | 946 | 11.4 |
| 13 | 3 | `L1_query` | context=6 of 9 density blocks already…, id_catalog… | 21,442 | — | — | 148.2 |
| | | **TOTAL (13 tools)** | | **29,547** | | **7,675** | **353.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 6,317 | 6,317 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,236 | 10,841 | 15,754 | 75.7 |
| 2 | L0-main | claudeopus46 | 9,605 | 2,561 | 12,166 | 1,522 | 9.9 |
| 3 | L1-worker | claudeopus46 | 20,643 | 1,747 | 22,390 | 1,155 | 6.2 |
| 4 | L1-worker | claudeopus46 | 2,065 | 6,445 | 8,510 | 1,607 | 13.4 |
| 5 | L1-worker | claudeopus46 | 2,065 | 6,569 | 8,634 | 1,084 | 11.8 |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,462 | 25,105 | 5,182 | 28.5 |
| 7 | L1-worker | claudeopus46 | 1,356 | 3,539 | 4,895 | 1,012 | 6.7 |
| 8 | L1-worker | claudeopus46 | 536 | 3,419 | 3,955 | 1,160 | 8.3 |
| 9 | L1-worker | claudeopus46 | 298 | 1,394 | 1,692 | 1,000 | 5.6 |
| 10 | L1-worker | claudeopus46 | 1,323 | 8,083 | 9,406 | 3,786 | 16.8 |
| 11 | L1-worker | claudeopus46 | 298 | 4,508 | 4,806 | 3,227 | 14.0 |
| 12 | L1-worker | claudeopus46 | 747 | 64,830 | 65,577 | 1,042 | 9.5 |
| 13 | L0-main | claudeopus46 | 9,605 | 61,832 | 71,437 | 1,803 | 12.8 |
| 14 | L1-worker | claudeopus46 | 20,643 | 60,099 | 80,742 | 709 | 6.0 |
| 15 | L1-worker | claudeopus46 | 2,065 | 6,400 | 8,465 | 1,380 | 11.6 |
| 16 | L1-worker | claudeopus46 | 20,643 | 61,791 | 82,434 | 1,231 | 9.4 |
| 17 | L1-worker | claudeopus46 | 2,065 | 8,140 | 10,205 | 1,340 | 12.1 |
| 18 | L1-worker | claudeopus46 | 20,643 | 63,515 | 84,158 | 1,376 | 10.9 |
| 19 | L1-worker | claudeopus46 | 2,065 | 3,044 | 5,109 | 1,668 | 13.0 |
| 20 | L1-worker | claudeopus46 | 20,610 | 66,297 | 86,907 | 379 | 4.4 |
| 21 | L1-worker | claudeopus46 | 20,643 | 65,544 | 86,187 | 1,222 | 8.1 |
| 22 | L1-worker | claudeopus46 | 2,065 | 2,234 | 4,299 | 1,893 | 12.9 |
| 23 | L1-worker | claudeopus46 | 2,065 | 2,974 | 5,039 | 1,427 | 11.3 |
| 24 | L1-worker | claudeopus46 | 20,643 | 68,366 | 89,009 | 1,864 | 12.8 |
| 25 | L1-worker | claudeopus46 | 536 | 1,875 | 2,411 | 925 | 6.0 |
| 26 | L1-worker | claudeopus46 | 1,323 | 11,739 | 13,062 | 1,376 | 8.1 |
| 27 | L1-worker | claudeopus46 | 1,356 | 1,995 | 3,351 | 1,239 | 8.3 |
| 28 | L1-worker | claudeopus46 | 298 | 2,098 | 2,396 | 1,051 | 5.0 |
| 29 | L1-worker | claudeopus46 | 747 | 31,677 | 32,424 | 592 | 6.2 |
| 30 | L0-main | claudeopus46 | 9,605 | 105,369 | 114,974 | 7,126 | 47.4 |
| 31 | L0-main | claudeopus46 | 1,356 | 5,875 | 7,231 | 1,417 | 7.7 |
| 32 | L0-main | claudeopus46 | 298 | 1,799 | 2,097 | 1,405 | 4.8 |
| 33 | L0-main | claudeopus46 | 1,323 | 34,023 | 35,346 | 4,738 | 26.3 |
| 34 | L0-main | claudeopus46 | 298 | 5,406 | 5,704 | 3,912 | 17.5 |


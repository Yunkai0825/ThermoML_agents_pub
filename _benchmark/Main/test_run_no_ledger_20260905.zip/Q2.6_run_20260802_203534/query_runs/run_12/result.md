# Delegated query run — result

**Question:** Find all available viscosity, diffusion coefficient, and surface tension data for the binary system of water and dimethyl sulfoxide (DMSO) near 25°C (298.15 K). Report DOIs, block numbers, literature IDs, temperature ranges, and composition ranges.

**Iterations:** 3  |  **Elapsed:** 377.2s  |  **Tools:** 4  |  **Timed out:** False

---

## Answer

## Transport Property Data for the Binary Water + DMSO System near 298.15 K

### 1. Dynamic Viscosity (Pa·s) — 3 datasets found

**Dataset 1 (most comprehensive):**
- **Literature ID:** GLOBlit_2781 | **DOI:** 10.1016/j.jct.2006.12.012
- **Block:** PROPblock_3
- **Temperature range:** 298.15–318.15 K (5 temperatures)
- **Composition range:** x(DMSO) = 0.0–1.0 (24 unique mole fractions, full range)
- **Data points:** 120
- **Measurement method:** Capillary tube (GLOBmeas_140)
- **Viscosity range:** 0.000596–0.003735 Pa·s
- **Pressure:** 101 kPa
- ✅ *Best dataset for characterizing the viscosity maximum near x(DMSO) ≈ 0.33 at 298.15 K*

**Dataset 2 (dilute DMSO region only):**
- **Literature ID:** GLOBlit_5953 | **DOI:** 10.1016/j.tca.2011.08.013
- **Block:** PROPblock_10
- **Temperature range:** 303.15–318.15 K (4 temperatures)
- **Composition range:** x(DMSO) = 0.0121–0.0583 (4 mole fractions, very dilute)
- **Data points:** 16
- **Measurement method:** Capillary tube, Ostwald–Ubbelohde (GLOBmeas_4)
- **Viscosity range:** 0.000667–0.001224 Pa·s
- **Pressure:** 101 kPa
- ⚠️ *Does not include 298.15 K; covers only dilute DMSO solutions*

**Dataset 3 (full range, mass-fraction basis):**
- **Literature ID:** GLOBlit_11517 | **DOI:** 10.1021/je9001027
- **Block:** PROPblock_3
- **Temperature range:** 298.15–318.15 K (5 temperatures)
- **Composition range:** w(DMSO) = 0.0–1.0 (7 unique mass fractions, full range)
- **Data points:** 35
- **Measurement method:** Capillary tube (GLOBmeas_205)
- **Viscosity range:** 0.000535–0.003421 Pa·s
- **Pressure:** 101 kPa
- ✅ *Includes 298.15 K; full composition range but fewer points than Dataset 1*

---

### 2. Surface Tension, Liquid–Gas (N/m) — 1 dataset found

- **Literature ID:** GLOBlit_10766 | **DOI:** 10.1021/je7001013
- **Block:** PROPblock_9
- **Temperature range:** 298.15–328.15 K (7 temperatures)
- **Composition range:** x(DMSO) = 0.0121–0.8945 (19 unique mole fractions)
- **Data points:** 112
- **Measurement method:** Maximal bubble pressure (GLOBmeas_36)
- **Surface tension range:** 0.0387–0.071 N/m
- **Uncertainty:** ±0.0003–0.0005 N/m (95% confidence)
- ✅ *Wide composition and temperature coverage; includes 298.15 K*

---

### 3. Diffusion Coefficients — No data found

No diffusion coefficient data exists in the ThermoML database for the water + DMSO binary system. All three relevant diffusion property types were searched:
- Binary diffusion coefficient (GLOBprop_29, m²/s) — no results
- Tracer diffusion coefficient (GLOBprop_71, m²/s) — no results
- Self-diffusion coefficient (GLOBprop_83, m²/s) — no results

---

### Chemistry Context

The water + DMSO system is a classic example of strong solute–solvent interactions. At 298.15 K, the dynamic viscosity exhibits a pronounced **maximum near x(DMSO) ≈ 0.33**, corresponding to a 2:1 water:DMSO molar ratio. This is attributed to the formation of stable hydrogen-bonded complexes where two water molecules bridge the S=O group of DMSO, creating an extended hydrogen-bond network that dramatically increases the mixture's resistance to flow. The maximum viscosity (~0.00374 Pa·s from Dataset 1) is roughly 4× that of pure water (~0.00089 Pa·s) and 2× that of pure DMSO (~0.00197 Pa·s).

In contrast, the **surface tension decreases monotonically** with increasing DMSO content — from ~0.071 N/m (water-rich) to ~0.041 N/m (DMSO-rich) — reflecting DMSO's lower pure-component surface tension and its preferential accumulation at the liquid–gas interface.

The absence of diffusion data in ThermoML is notable, as diffusion coefficients for this system (which show a minimum near the same composition as the viscosity maximum) would need to be sourced from other databases or primary literature.

### Core claims

- Three dynamic viscosity datasets for the water + DMSO binary system near 298.15 K were found in ThermoML, the most comprehensive covering 24 mole fractions across the full composition range at 298.15–318.15 K and 101 kPa, with viscosities spanning 0.000596–0.003735 Pa·s.
- At 298.15 K, the dynamic viscosity of water + DMSO exhibits a pronounced maximum near x(DMSO) ≈ 0.33, approximately 4× that of pure water, attributed to stable 2:1 water:DMSO hydrogen-bonded complexes.
- One surface tension dataset was found, covering 19 mole fractions at 298.15–328.15 K, showing a monotonic decrease from ~0.071 N/m (water-rich) to ~0.041 N/m (DMSO-rich), reflecting DMSO's lower pure-component surface tension and preferential accumulation at the liquid–gas interface.
- No diffusion coefficient data (binary, tracer, or self-diffusion) for the water + DMSO system exists in the ThermoML database; such data would need to be sourced elsewhere.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2781 | 10.1016/j.jct.2006.12.012 | PROPblock_3 |  | Dynamic viscosity (Pa·s) for binary water+DMSO system. 120 data points, T = 298.15–318.15 K, x(DMSO) = 0.0–1.0 (24 unique mole fractions). Method: Capillary tube (GLOBmeas_140). Pressure: 101 kPa. Most comprehensive viscosity dataset; includes 298.15 K and full composition range suitable for characterizing viscosity maximum near x(DMSO) ≈ 0.33. |
| GLOBlit_5953 | 10.1016/j.tca.2011.08.013 | PROPblock_10 |  | Dynamic viscosity (Pa·s) for binary water+DMSO system. 16 data points, T = 303.15–318.15 K, x(DMSO) = 0.0121–0.0583 (4 mole fractions, dilute region only). Method: Capillary tube, Ostwald–Ubbelohde (GLOBmeas_4). Pressure: 101 kPa. Does not include 298.15 K; covers only very dilute DMSO solutions. |
| GLOBlit_11517 | 10.1021/je9001027 | PROPblock_3 |  | Dynamic viscosity (Pa·s) for binary water+DMSO system. 35 data points, T = 298.15–318.15 K, w(DMSO) = 0.0–1.0 (7 unique mass fractions, full range). Method: Capillary tube (GLOBmeas_205). Pressure: 101 kPa. Includes 298.15 K; full composition range but fewer points than GLOBlit_2781 dataset. |
| GLOBlit_10766 | 10.1021/je7001013 | PROPblock_9 |  | Surface tension liquid-gas (N/m) for binary water+DMSO system. 112 data points, T = 298.15–328.15 K (7 temperatures), x(DMSO) = 0.0121–0.8945 (19 unique mole fractions). Method: Maximal bubble pressure (GLOBmeas_36). Surface tension range: 0.0387–0.071 N/m. Uncertainty: ±0.0003–0.0005 N/m (95% confidence). Includes 298.15 K. |

### Suggested follow-ups

- Retrieve point-level viscosity data from GLOBlit_2781 PROPblock_3 at T = 298.15 K to precisely locate the viscosity maximum composition and value.
- Search for excess molar volume or excess enthalpy data for water+DMSO to complement the transport property analysis of intermolecular interactions.
- Search external databases (e.g., DETHERM, primary literature) for diffusion coefficient data for water+DMSO, as no diffusion data was found in ThermoML.
- Retrieve point-level surface tension data from GLOBlit_10766 PROPblock_9 at T = 298.15 K to analyze surface excess and DMSO surface activity.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_31",
    "registry_id": "dimethyl_sulfoxide",
    "name": "dimethyl sulfoxide"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_13",
    "registry_id": "surface_tension_liquidgas_n_m",
    "name": "Surface tension liquid-gas, N/m"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_29",
    "registry_id": "binary_diffusion_coefficient",
    "name": "Binary diffusion coefficient, m²/s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_71",
    "registry_id": "tracer_diffusion_coefficient",
    "name": "Tracer diffusion coefficient, m²/s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_83",
    "registry_id": "self_diffusion_coefficient",
    "name": "Self-diffusion coefficient, m²/s"
  }
]
```

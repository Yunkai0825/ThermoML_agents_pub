# Reference Stats — query-agent

**Run started:** 2026-08-02 20:37:11
**Wall time (at last flush):** 412.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 32,090 | 97,458 | 29,983 | 129,548 | 18,506 | 151.7 | claudeopus46 |
| L1-worker | 40 | 279,509 | 342,410 | 46,075 | 621,919 | 15,547 | 291.4 | claudeopus46 |
| **TOTAL** | **47** | **311,599** | **439,868** | **76,058** | **751,467** | **15,988** | **443.1** | |

**Estimated tokens:** ~187,866 input + ~19,014 output = ~206,880 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 1 | 3 | 3 | 171 |
| `search_blocks` | 2 | 1 | 2 | 0 | 1 | 1 | 112 |
| `resolve_property_ids` | 0 | 5 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **6** | **7** | **5** | **1** | **4** | **4** | **283** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_31 |  | resolve_compound_ids, search_blocks |

#### References (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2781 |  | search_blocks |
| GLOBlit_5953 |  | search_blocks |
| GLOBlit_11517 |  | search_blocks |
| GLOBlit_10766 |  | search_blocks |

#### Properties (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBprop_29 |  | resolve_property_ids |
| GLOBprop_52 |  | resolve_property_ids |
| GLOBprop_71 |  | resolve_property_ids |
| GLOBprop_83 |  | resolve_property_ids |
| GLOBprop_89 |  | resolve_property_ids |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 4 |
| Unique Properties | 7 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 1 |
| Total DOIs | 4 |
| Unique parent blocks | 4 |
| Explicit block/subsystem targets | 4 |
| Subsystem targets | 0 |
| Target-matched data points | 283 |

---

## 3. DOI & Block References

**Unique DOIs:** 4  |  **Parent blocks:** 4  |  **Explicit targets:** 4  |  **Subsystems:** 0  |  **Target-matched datapoints:** 283

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.12.012 | 1 | 120 | binary | search_blocks |
| 10.1016/j.tca.2011.08.013 | 1 | 16 | binary | search_blocks |
| 10.1021/je7001013 | 1 | 112 | binary | search_blocks |
| 10.1021/je9001027 | 1 | 35 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | — | search_blocks |
| 10.1016/j.tca.2011.08.013 | PROPblock_10 | declared | 16 | binary | — | search_blocks |
| 10.1021/je7001013 | PROPblock_9 | declared | 112 | binary | — | search_blocks |
| 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve global comp… | 236 | KEEP | 236 | 3.9 |
| 2 | 1 | `L1_query` | context=Need these IDs to search for …, id_catalog… | 1,459 | — | — | 33.7 |
| 3 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 1,351 | KEEP | 1305 | 14.7 |
| 4 | 2 | `L1_query` | context=Binary system water+DMSO. Loo…, id_catalog… | 22,041 | — | — | 62.4 |
| 5 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 951 | KEEP | 935 | 18.8 |
| 6 | 2 | `L1_query` | context=Binary system water+DMSO. Loo…, id_catalog… | 8,219 | — | — | 50.0 |
| 7 | 2 | `resolve_property_ids` | limit=20, min_score=40, purpose=Find property IDs … | 574 | KEEP | 574 | 5.4 |
| 8 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 742 | DISCARD | 684 | 14.4 |
| 9 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 683 | DISCARD | 625 | 8.4 |
| 10 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 1,068 | DISCARD | 1010 | 10.9 |
| 11 | 2 | `L1_query` | context=Binary system water+DMSO. Loo…, id_catalog… | 1,310 | — | — | 125.3 |
| | | **TOTAL (11 tools)** | | **38,634** | | **5,369** | **347.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 989 | 10,594 | 1,191 | 8.8 |
| 2 | L1-worker | claudeopus46 | 20,643 | 797 | 21,440 | 653 | 7.5 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,071 | 22,714 | 930 | 5.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 502 | 2,567 | 397 | 3.8 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,228 | 22,871 | 335 | 3.9 |
| 6 | L1-worker | claudeopus46 | 1,323 | 2,103 | 3,426 | 234 | 2.6 |
| 7 | L1-worker | claudeopus46 | 1,356 | 466 | 1,822 | 385 | 3.3 |
| 8 | L1-worker | claudeopus46 | 536 | 346 | 882 | 322 | 3.4 |
| 9 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 5.1 |
| 10 | L1-worker | claudeopus46 | 747 | 2,675 | 3,422 | 453 | 4.8 |
| 11 | L0-main | claudeopus46 | 9,605 | 4,673 | 14,278 | 15,671 | 70.3 |
| 12 | L1-worker | claudeopus46 | 20,643 | 2,816 | 23,459 | 1,161 | 7.9 |
| 13 | L1-worker | claudeopus46 | 2,065 | 7,622 | 9,687 | 1,687 | 14.3 |
| 14 | L1-worker | claudeopus46 | 20,643 | 4,689 | 25,332 | 3,057 | 15.6 |
| 15 | L1-worker | claudeopus46 | 1,356 | 2,223 | 3,579 | 931 | 5.5 |
| 16 | L1-worker | claudeopus46 | 536 | 2,103 | 2,639 | 947 | 5.6 |
| 17 | L1-worker | claudeopus46 | 1,323 | 5,298 | 6,621 | 1,837 | 9.3 |
| 18 | L1-worker | claudeopus46 | 298 | 1,303 | 1,601 | 934 | 4.5 |
| 19 | L1-worker | claudeopus46 | 298 | 2,559 | 2,857 | 1,512 | 6.4 |
| 20 | L1-worker | claudeopus46 | 747 | 26,066 | 26,813 | 791 | 7.9 |
| 21 | L1-worker | claudeopus46 | 20,643 | 24,834 | 45,477 | 813 | 6.1 |
| 22 | L1-worker | claudeopus46 | 2,065 | 2,893 | 4,958 | 1,321 | 11.5 |
| 23 | L1-worker | claudeopus46 | 20,643 | 26,306 | 46,949 | 1,362 | 9.1 |
| 24 | L1-worker | claudeopus46 | 1,323 | 3,854 | 5,177 | 719 | 4.4 |
| 25 | L1-worker | claudeopus46 | 536 | 1,185 | 1,721 | 734 | 4.6 |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,305 | 2,661 | 715 | 4.9 |
| 27 | L1-worker | claudeopus46 | 298 | 1,441 | 1,739 | 592 | 3.3 |
| 28 | L1-worker | claudeopus46 | 747 | 10,895 | 11,642 | 825 | 7.7 |
| 29 | L1-worker | claudeopus46 | 20,643 | 33,324 | 53,967 | 732 | 5.1 |
| 30 | L1-worker | claudeopus46 | 20,643 | 34,677 | 55,320 | 10,570 | 46.5 |
| 31 | L1-worker | claudeopus46 | 2,065 | 775 | 2,840 | 957 | 5.3 |
| 32 | L1-worker | claudeopus46 | 20,643 | 35,184 | 55,827 | 2,651 | 10.9 |
| 33 | L1-worker | claudeopus46 | 20,643 | 38,670 | 59,313 | 1,359 | 6.6 |
| 34 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 1,246 | 8.1 |
| 35 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 1,305 | 8.0 |
| 36 | L1-worker | claudeopus46 | 2,065 | 481 | 2,546 | 1,574 | 10.5 |
| 37 | L1-worker | claudeopus46 | 20,643 | 41,250 | 61,893 | 601 | 4.6 |
| 38 | L1-worker | claudeopus46 | 1,323 | 7,723 | 9,046 | 92 | 2.2 |
| 39 | L1-worker | claudeopus46 | 1,356 | 732 | 2,088 | 170 | 2.5 |
| 40 | L1-worker | claudeopus46 | 536 | 612 | 1,148 | 404 | 3.3 |
| 41 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.0 |
| 42 | L1-worker | claudeopus46 | 747 | 7,662 | 8,409 | 546 | 7.2 |
| 43 | L0-main | claudeopus46 | 9,605 | 38,433 | 48,038 | 4,205 | 26.2 |
| 44 | L0-main | claudeopus46 | 1,356 | 3,887 | 5,243 | 969 | 6.3 |
| 45 | L0-main | claudeopus46 | 298 | 1,351 | 1,649 | 957 | 4.9 |
| 46 | L0-main | claudeopus46 | 1,323 | 43,686 | 45,009 | 3,771 | 21.1 |
| 47 | L0-main | claudeopus46 | 298 | 4,439 | 4,737 | 3,219 | 14.1 |


# Delegated query run — result

**Question:** Find all available excess molar enthalpy (HE), excess molar volume (VE), and excess molar heat capacity data for the binary system of water and dimethyl sulfoxide (DMSO) near 25°C (298.15 K). Report DOIs, block numbers, literature IDs, temperature ranges, and composition ranges.

**Iterations:** 5  |  **Elapsed:** 872.6s  |  **Tools:** 7  |  **Timed out:** False

---

## Answer

**Excess Molar Property Data for Water + DMSO (near 298.15 K) — ThermoML Database Search Results**

After exhaustive searching of the ThermoML database for the binary system of water (H₂O) and dimethyl sulfoxide (DMSO, (CH₃)₂SO), **no data were found** for any of the three requested excess molar properties:

---

### 1. Excess Molar Enthalpy (Hᴱ) — GLOBprop_17
**No data found in the ThermoML database** for water + DMSO at any temperature.

- The database contains at least 50 Hᴱ blocks involving DMSO, but all pair DMSO with other organic compounds (toluene, ethylbenzene, chlorobenzene, bromobenzene, nitrobenzene, butanone, 4-methylpentan-2-one, cyclohexanone, etc.) — none with water.

### 2. Excess Molar Volume (Vᴱ) — GLOBprop_28
**No data found in the ThermoML database** for water + DMSO at any temperature.

- 15 Vᴱ blocks exist for DMSO paired with other organic compounds, but none with water as the partner.

### 3. Excess Molar Heat Capacity (Cpᴱ) — GLOBprop_85
**No data found in the ThermoML database** for water + DMSO at any temperature.

- The database contains 23 Cpᴱ blocks (spanning 7 papers, 1,105 data points, 283.15–353.2 K), but none involve DMSO as a component. Systems covered include water + various diols, water + N-methylpyrrolidone, water + piperazine, and others.

---

### What IS Available for Water + DMSO in ThermoML

Twelve true binary data blocks for the water + DMSO system do exist in the ThermoML database, but they cover **other properties** — specifically density, viscosity, speed of sound, heat capacity (absolute, not excess), and vapor–liquid equilibrium data. None of these blocks report excess molar quantities.

---

### Chemistry Context

Water and DMSO are well known to interact very strongly via hydrogen bonding. The S=O group of DMSO is a powerful hydrogen-bond acceptor, and water acts as a donor. In the broader literature (not present in ThermoML), this system exhibits:

- **Hᴱ**: Strongly exothermic mixing, with a minimum near −3 kJ/mol at x(DMSO) ≈ 0.33 at 298.15 K, consistent with formation of a 1:2 DMSO:water complex.
- **Vᴱ**: Strongly negative, reaching approximately −1 cm³/mol near x(DMSO) ≈ 0.3 at 298.15 K, reflecting efficient packing due to strong intermolecular interactions.
- **Cpᴱ**: Large positive values, reflecting disruption and restructuring of hydrogen-bond networks upon mixing.

The composition of maximum interaction (x(DMSO) ≈ 0.33) corresponds to a 1:2 DMSO:water stoichiometry, where each DMSO molecule can accept two hydrogen bonds from two water molecules.

**However, none of these excess property measurements are present in the indexed ThermoML collection.** To obtain specific numerical data for these properties, external literature sources would need to be consulted.

### Core claims

- The ThermoML database contains no excess molar enthalpy, excess molar volume, or excess molar heat capacity data for the binary system water + DMSO at any temperature.
- Twelve binary data blocks for water + DMSO do exist in ThermoML, but they report other properties (density, viscosity, speed of sound, absolute heat capacity, and vapor–liquid equilibrium), not excess molar quantities.
- ThermoML does contain excess molar enthalpy and excess molar volume data for DMSO paired with various organic compounds, and excess molar heat capacity data for other aqueous binary systems, but none of these involve the water + DMSO combination.
- Based on broader literature (outside ThermoML), water + DMSO exhibits strongly exothermic mixing (Hᴱ minimum near −3 kJ/mol at x(DMSO) ≈ 0.33), strongly negative excess molar volume (approximately −1 cm³/mol near x(DMSO) ≈ 0.3), and large positive excess molar heat capacity at 298.15 K, consistent with strong hydrogen-bonding interactions and formation of a 1:2 DMSO:water complex.

**Confidence:** high

### Suggested follow-ups

- Search for the 12 existing water+DMSO binary blocks covering density, viscosity, speed of sound, heat capacity (absolute), and VLE data to extract available thermodynamic information from which excess properties might be derived.
- Query the ~50 excess molar enthalpy blocks involving DMSO with other organic partners (e.g., GLOBlit_577 DOI 10.1016/j.fluid.2007.10.017, GLOBlit_2816 DOI 10.1016/j.jct.2007.04.004, GLOBlit_3440 DOI 10.1016/j.jct.2011.07.018) to compare DMSO interaction strengths with other solvents versus the known water+DMSO literature values.
- Consult external literature databases (e.g., NIST TDE, Dortmund Data Bank) for water+DMSO excess molar enthalpy, excess molar volume, and excess molar heat capacity data, as these measurements are not present in the indexed ThermoML collection.
- Investigate whether absolute density data in the existing water+DMSO blocks can be used to compute excess molar volumes indirectly from pure-component densities.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_31",
    "registry_id": "dimethyl_sulfoxide",
    "name": "dimethyl sulfoxide"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_17",
    "registry_id": "excess_molar_enthalpy_kj_mol",
    "name": "Excess molar enthalpy, kJ/mol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_28",
    "registry_id": "excess_molar_volume_m3_mol",
    "name": "Excess molar volume, m3/mol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_85",
    "registry_id": "excess_molar_heat_capacity_j_k_mol",
    "name": "Excess molar heat capacity, J/K/mol"
  }
]
```

# Reference Stats — query-agent

**Run started:** 2026-08-02 20:37:11
**Wall time (at last flush):** 889.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 51,300 | 108,813 | 30,288 | 160,113 | 17,790 | 152.0 | claudeopus46 |
| L1-worker | 82 | 646,019 | 554,932 | 127,463 | 1,200,951 | 14,645 | 749.2 | claudeopus46 |
| **TOTAL** | **91** | **697,319** | **663,745** | **157,751** | **1,361,064** | **14,956** | **901.2** | |

**Estimated tokens:** ~340,266 input + ~39,437 output = ~379,703 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 8 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 5 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 28 | 12 | 10 | 4 | 25 | 50 | 3,050 |
| `search_blocks` | 16 | 1 | 1 | 2 | 3 | 15 | 203 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 0 | 1 | 0 | 0 | 7 | 23 | 1,105 |
| `search_system_registry` | 25 | 1 | 3 | 2 | 7 | 23 | 1,105 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 50 | 1 | 2 | 2 | 13 | 50 | 933 |
| `search_blocks` | 2 | 13 | 5 | 3 | 16 | 29 | 1,601 |
| `search_system_registry` | 2 | 13 | 5 | 3 | 16 | 29 | 1,601 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **125** | **55** | **26** | **16** | **87** | **219** | **9,598** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (105 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_31 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_35 | acetic acid | search_blocks |
| GLOBcomp_26 | sodium chloride | search_blocks |
| GLOBcomp_41 | potassium chloride | search_blocks |
| GLOBcomp_3 | carbon dioxide | search_blocks |
| GLOBcomp_1109 | 1,1-diamino-2,2-dinitroethene | search_blocks |
| GLOBcomp_74 | (S)-2-aminopropanoic acid | search_blocks |
| GLOBcomp_53 | 2-aminoacetic acid | search_blocks |
| GLOBcomp_201 | glycylglycine | search_blocks |
| GLOBcomp_1008 | (.+-.)-serine | search_blocks |
| GLOBcomp_221 | DL-threonine | search_blocks |
| GLOBcomp_355 | L-histidine | search_blocks |
| GLOBcomp_44 | 2-methylpropan-2-ol | search_blocks |
| GLOBcomp_171 | L-serine | search_blocks |
| GLOBcomp_1178 | .beta.-adenosine | search_blocks |
| GLOBcomp_2394 | 6-methyl-2-thiouracil | search_blocks |
| GLOBcomp_621 | 1-allyl-3-methylimidazolium chloride | search_blocks |
| GLOBcomp_898 | 3-(p-hydroxyphenyl)-L-alanine | search_blocks |
| GLOBcomp_1674 | 6-amino-1H-purine | search_blocks |
| GLOBcomp_4895 | Quinocetone | search_blocks |
| GLOBcomp_8471 | iminodibenzyl | search_blocks |
| GLOBcomp_8443 | Gimeracil | search_blocks |
| GLOBcomp_4700 | Naftopidil | search_blocks |
| GLOBcomp_2883 | 2-amino-6-chloropurine | search_blocks |
| GLOBcomp_2193 | flubendazole | search_blocks |
| GLOBcomp_1552 | p-nitrobenzamide | search_blocks |
| GLOBcomp_1618 | D-aspartic acid | search_blocks |
| GLOBcomp_264 | 1,2-dichlorobenzene | search_blocks |
| GLOBcomp_419 | 1,3-dichlorobenzene | search_blocks |
| GLOBcomp_728 | 1,2,4-trichlorobenzene | search_blocks |
| GLOBcomp_408 | 2-chlorotoluene | search_blocks |
| GLOBcomp_664 | 3-chlorotoluene | search_blocks |
| GLOBcomp_473 | 4-chlorotoluene | search_blocks |
| GLOBcomp_616 | 2-nitrotoluene | search_blocks |
| GLOBcomp_807 | 3-nitrotoluene | search_blocks |
| GLOBcomp_39 | butanone | search_blocks |
| GLOBcomp_104 | pentan-3-one | search_blocks |
| GLOBcomp_75 | pentan-2-one | search_blocks |
| GLOBcomp_101 | 4-methylpentan-2-one | search_blocks |
| GLOBcomp_87 | cyclohexanone | search_blocks |
| GLOBcomp_309 | 1,2,4-trimethylbenzene | search_blocks, search_system_registry |
| GLOBcomp_191 | 1,3,5-trimethylbenzene | search_blocks, search_system_registry |
| GLOBcomp_47 | N-methylpyrrolidone | search_system_registry |
| GLOBcomp_24 | 1,2-ethanediol | search_blocks, search_system_registry |
| GLOBcomp_61 | 1,2-propanediol | search_blocks, search_system_registry |
| GLOBcomp_154 | propan-1,3-diol | search_system_registry |
| GLOBcomp_169 | 1,4-butanediol | search_system_registry |
| GLOBcomp_768 | 1,2-hexanediol | search_system_registry |
| GLOBcomp_27 | ethylbenzene | search_blocks, search_system_registry |
| GLOBcomp_292 | benzonitrile | search_system_registry |
| GLOBcomp_30 | 1,2-dimethylbenzene | search_system_registry |
| GLOBcomp_32 | 1,3-dimethylbenzene | search_system_registry |
| GLOBcomp_28 | 1,4-dimethylbenzene | search_system_registry |
| GLOBcomp_193 | isopropylbenzene | search_system_registry |
| GLOBcomp_152 | anisole | search_system_registry |
| GLOBcomp_7 | butan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_81 | N-methyldiethanolamine | search_system_registry |
| GLOBcomp_176 | diethanolamine | search_system_registry |
| GLOBcomp_164 | piperazine | search_system_registry |
| GLOBcomp_22 | pentan-1-ol | search_system_registry |
| GLOBcomp_580 | benzylamine | search_system_registry |
| GLOBcomp_11 | heptane | search_system_registry |
| GLOBcomp_4 | methanol | search_blocks, search_system_registry |
| GLOBcomp_5 | propan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_8 | toluene | search_blocks |
| GLOBcomp_96 | chlorobenzene | search_blocks |
| GLOBcomp_197 | bromobenzene | search_blocks |
| GLOBcomp_170 | nitrobenzene | search_blocks |
| GLOBcomp_529 | hexanoic acid | search_blocks |
| GLOBcomp_84 | 1-ethyl-3-methylimidazolium tetrafluoroborate | search_blocks |
| GLOBcomp_25 | 1,4-dioxane | search_blocks |
| GLOBcomp_208 | 1,3-dioxolane | search_blocks |
| GLOBcomp_156 | tetrahydropyran | search_blocks |
| GLOBcomp_23 | tetrahydrofuran | search_blocks |
| GLOBcomp_180 | 1,2-dimethoxyethane | search_blocks |
| GLOBcomp_1162 | 1,2-diethoxyethane | search_blocks |
| GLOBcomp_2 | ethanol | search_blocks |
| GLOBcomp_38 | hexan-1-ol | search_blocks |
| GLOBcomp_34 | octan-1-ol | search_blocks |
| GLOBcomp_59 | decan-1-ol | search_blocks |
| GLOBcomp_86 | 1,2-dichloroethane | search_blocks |
| GLOBcomp_439 | 1,1,1-trichloroethane | search_blocks |
| GLOBcomp_225 | 1,1,2,2-tetrachloroethane | search_blocks |
| GLOBcomp_235 | trichloroethene | search_blocks |
| GLOBcomp_280 | tetrachloroethene | search_blocks |
| GLOBcomp_111 | diethylene glycol | search_blocks |
| GLOBcomp_113 | triethylene glycol | search_blocks |
| GLOBcomp_251 | tetraethylene glycol | search_blocks |
| GLOBcomp_2084 | hexanenitrile | search_blocks |
| GLOBcomp_1926 | heptanenitrile | search_blocks |
| GLOBcomp_2047 | octanenitrile | search_blocks |
| GLOBcomp_1860 | nonanenitrile | search_blocks |
| GLOBcomp_2351 | 1-decanenitrile | search_blocks |
| GLOBcomp_2937 | 1-decylcyanide | search_blocks |
| GLOBcomp_1994 | n-dodecanenitrile | search_blocks |
| GLOBcomp_3069 | dodecanecarbonitrile | search_blocks |
| GLOBcomp_2625 | tetradecanenitrile | search_blocks |
| GLOBcomp_186 | benzenemethanol | search_blocks |
| GLOBcomp_288 | 2-phenylethanol | search_blocks |
| GLOBcomp_1225 | 3-phenyl-1-propanol | search_blocks |
| GLOBcomp_62 | dimethyl carbonate | search_blocks |
| GLOBcomp_103 | diethyl carbonate | search_blocks |
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_blocks |
| GLOBcomp_346 | butyltrimethylammonium bis(trifluoromethylsulfonyl)imide | search_blocks |

#### Properties (26 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_28 |  | resolve_property_ids, search_blocks |
| GLOBprop_9 |  | resolve_property_ids, search_blocks, search_system_registry |
| GLOBprop_81 |  | resolve_property_ids |
| GLOBprop_72 |  | resolve_property_ids |
| GLOBprop_43 |  | resolve_property_ids |
| GLOBprop_63 |  | resolve_property_ids |
| GLOBprop_85 |  | resolve_property_ids, search_system_registry, search_system_summary |
| GLOBprop_64 |  | resolve_property_ids, search_blocks, search_system_registry |
| GLOBprop_17 |  | resolve_property_ids, search_blocks |
| GLOBprop_22 |  | resolve_property_ids |
| GLOBprop_90 |  | resolve_property_ids |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBprop_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBprop_21 | Molality, mol/kg | search_blocks |
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks, search_system_registry |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBprop_25 | Critical pressure, kPa | search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBprop_39 | Refractive index (other wavelength) | search_blocks |
| GLOBprop_15 | Molar enthalpy of solution, kJ/mol | search_blocks, search_system_registry |
| GLOBprop_34 | Thermal conductivity, W/m/K | search_blocks, search_system_registry |
| GLOBprop_44 | Relative permittivity at zero frequency | search_blocks, search_system_registry |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks, search_system_registry |

#### References (58 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_663 |  | search_blocks, search_system_registry |
| GLOBlit_932 |  | search_blocks |
| GLOBlit_1972 |  | search_blocks |
| GLOBlit_2140 |  | search_blocks |
| GLOBlit_2523 |  | search_blocks |
| GLOBlit_2584 |  | search_blocks, search_system_registry |
| GLOBlit_2652 |  | search_blocks, search_system_registry |
| GLOBlit_2781 |  | search_blocks, search_system_registry |
| GLOBlit_2842 |  | search_blocks, search_system_registry |
| GLOBlit_2844 |  | search_blocks, search_system_registry |
| GLOBlit_3405 |  | search_blocks |
| GLOBlit_3541 |  | search_blocks |
| GLOBlit_5075 |  | search_blocks |
| GLOBlit_5185 |  | search_blocks |
| GLOBlit_5238 |  | search_blocks |
| GLOBlit_5249 |  | search_blocks |
| GLOBlit_5264 |  | search_blocks |
| GLOBlit_5385 |  | search_blocks |
| GLOBlit_5428 |  | search_blocks |
| GLOBlit_5446 |  | search_blocks |
| GLOBlit_5462 |  | search_blocks |
| GLOBlit_5478 |  | search_blocks |
| GLOBlit_5509 |  | search_blocks |
| GLOBlit_5528 |  | search_blocks |
| GLOBlit_5559 |  | search_blocks |
| GLOBlit_2686 |  | search_blocks |
| GLOBlit_2863 |  | search_blocks |
| GLOBlit_8444 |  | search_blocks |
| GLOBlit_1283 |  | search_system_registry, search_system_summary |
| GLOBlit_3121 |  | search_system_registry, search_system_summary |
| GLOBlit_6147 |  | search_system_registry, search_system_summary |
| GLOBlit_2822 |  | search_system_registry, search_system_summary |
| GLOBlit_3096 |  | search_system_registry, search_system_summary |
| GLOBlit_2745 |  | search_system_registry, search_system_summary |
| GLOBlit_710 |  | search_system_registry, search_system_summary |
| GLOBlit_577 |  | search_blocks |
| GLOBlit_2816 |  | search_blocks |
| GLOBlit_3440 |  | search_blocks |
| GLOBlit_3810 |  | search_blocks |
| GLOBlit_5705 |  | search_blocks |
| GLOBlit_5731 |  | search_blocks |
| GLOBlit_5763 |  | search_blocks |
| GLOBlit_8204 |  | search_blocks |
| GLOBlit_8539 |  | search_blocks |
| GLOBlit_8669 |  | search_blocks |
| GLOBlit_8790 |  | search_blocks |
| GLOBlit_8919 |  | search_blocks |
| GLOBlit_10541 |  | search_blocks |
| GLOBlit_5953 |  | search_blocks, search_system_registry |
| GLOBlit_5958 |  | search_blocks, search_system_registry |
| GLOBlit_7713 |  | search_blocks, search_system_registry |
| GLOBlit_9547 |  | search_blocks, search_system_registry |
| GLOBlit_10024 |  | search_blocks, search_system_registry |
| GLOBlit_10109 |  | search_blocks, search_system_registry |
| GLOBlit_10215 |  | search_blocks, search_system_registry |
| GLOBlit_10766 |  | search_blocks, search_system_registry |
| GLOBlit_11018 |  | search_blocks, search_system_registry |
| GLOBlit_11517 |  | search_blocks, search_system_registry |

#### Measurements (44 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_146 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_150 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_1 | Mole fraction | search_blocks |
| GLOBmeas_585 | Molality, mol/kg | search_blocks |
| GLOBmeas_135 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_828 | Critical pressure, kPa | search_blocks |
| GLOBmeas_1652 | Mole fraction | search_blocks |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_31 | Molar heat capacity at constant pressure, J/K/mol | search_blocks, search_system_registry |
| GLOBmeas_811 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_57 | Apparent molar heat capacity, J/K/mol | search_blocks, search_system_registry |
| GLOBmeas_3 | Refractive index (other wavelength) | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_55 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_29 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_12 | Excess molar heat capacity, J/K/mol | search_blocks, search_system_registry |
| GLOBmeas_9 | Excess molar heat capacity, J/K/mol | search_system_registry |
| GLOBmeas_925 | Excess molar heat capacity, J/K/mol | search_system_registry |
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_254 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_262 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_769 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_200 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_144 | Molar enthalpy of solution, kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_130 | Solid-liquid equilibrium temperature, K | search_blocks, search_system_registry |
| GLOBmeas_41 | Thermal conductivity, W/m/K | search_blocks, search_system_registry |
| GLOBmeas_823 | Relative permittivity at zero frequency | search_blocks, search_system_registry |
| GLOBmeas_1503 | Solid-liquid equilibrium temperature, K | search_blocks, search_system_registry |
| GLOBmeas_359 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_145 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_163 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_495 | Mass density, kg/m3 | search_blocks, search_system_registry |

#### Phases (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_3 |  | search_blocks, search_system_registry |
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_8 | Solvent: Mole fraction | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_11 | Solvent: Amount concentration (molarity), mol/dm3 | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBvar_22 | Wavelength, nm | search_blocks |
| GLOBvar_6 | Solvent: Molality, mol/kg | search_blocks |
| GLOBvar_7 | Solvent: Mass fraction | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |

#### Constraints (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_7 | Solvent: Mole fraction | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBconstr_3 | Mole fraction | search_blocks, search_system_registry |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_8 |  | search_blocks, search_system_registry |
| GLOBsolvent_1 |  | search_blocks, search_system_registry |

#### Block_Types (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |
| GLOBblocktype_3 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 105 |
| Unique Properties | 26 |
| Unique References | 58 |
| Unique Measurements | 44 |
| Unique Phases | 2 |
| Unique Variables | 10 |
| Unique Constraints | 4 |
| Unique Solvents | 2 |
| Unique Block_Types | 2 |
| Total DOIs | 58 |
| Unique parent blocks | 155 |
| Explicit block/subsystem targets | 155 |
| Subsystem targets | 0 |
| Target-matched data points | 8,493 |

---

## 3. DOI & Block References

**Unique DOIs:** 58  |  **Parent blocks:** 155  |  **Explicit targets:** 155  |  **Subsystems:** 0  |  **Target-matched datapoints:** 6,117

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2007.10.017 | 5 | 79 | binary | search_blocks |
| 10.1016/j.fluid.2008.09.010 | 3 | 49 | binary, ternary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.05.005 | 1 | 1 | binary | search_system_registry |
| 10.1016/j.fluid.2011.01.026 | 5 | 121 | ternary | search_blocks |
| 10.1016/j.fluid.2013.06.041 | 5 | 390 | binary | search_system_registry |
| 10.1016/j.fluid.2016.08.033 | 4 | 80 | ternary | search_blocks |
| 10.1016/j.fluid.2017.12.035 | 1 | 49 | ternary | search_blocks |
| 10.1016/j.jct.2005.03.015 | 6 | 327 | ternary | search_blocks |
| 10.1016/j.jct.2005.07.012 | 1 | 96 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.01.007 | 4 | 276 | binary, ternary | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.04.005 | 8 | 119 | binary | search_blocks |
| 10.1016/j.jct.2006.09.007 | 8 | 98 | binary | search_system_registry |
| 10.1016/j.jct.2006.12.012 | 2 | 240 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.04.004 | 3 | 45 | binary | search_blocks |
| 10.1016/j.jct.2007.04.011 | 1 | 130 | binary | search_system_registry |
| 10.1016/j.jct.2007.06.007 | 3 | 87 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.010 | 2 | 308 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.08.006 | 5 | 46 | binary | search_blocks |
| 10.1016/j.jct.2009.05.015 | 1 | 99 | binary | search_system_registry |
| 10.1016/j.jct.2009.07.005 | 3 | 253 | binary, ternary | search_system_registry |
| 10.1016/j.jct.2011.05.034 | 1 | 70 | ternary | search_blocks |
| 10.1016/j.jct.2011.07.018 | 1 | 66 | binary | search_blocks |
| 10.1016/j.jct.2012.01.015 | 3 | 202 | ternary | search_blocks |
| 10.1016/j.jct.2013.01.010 | 1 | 18 | binary | search_blocks |
| 10.1016/j.jct.2017.07.023 | 1 | 77 | ternary | search_blocks |
| 10.1016/j.jct.2018.02.002 | 1 | 77 | ternary | search_blocks |
| 10.1016/j.jct.2018.04.014 | 3 | 161 | ternary | search_blocks |
| 10.1016/j.jct.2018.05.011 | 1 | 99 | ternary | search_blocks |
| 10.1016/j.jct.2018.05.030 | 1 | 66 | ternary | search_blocks |
| 10.1016/j.jct.2018.11.021 | 1 | 88 | ternary | search_blocks |
| 10.1016/j.jct.2018.12.045 | 1 | 88 | ternary | search_blocks |
| 10.1016/j.jct.2019.01.026 | 1 | 88 | ternary | search_blocks |
| 10.1016/j.jct.2019.02.016 | 1 | 88 | ternary | search_blocks |
| 10.1016/j.jct.2019.03.004 | 1 | 88 | ternary | search_blocks |
| 10.1016/j.jct.2019.04.001 | 1 | 81 | ternary | search_blocks |
| 10.1016/j.jct.2019.05.007 | 1 | 72 | ternary | search_blocks |
| 10.1016/j.jct.2019.06.025 | 1 | 72 | ternary | search_blocks |
| 10.1016/j.tca.2006.05.010 | 6 | 102 | binary | search_blocks |
| 10.1016/j.tca.2006.10.025 | 7 | 120 | binary | search_blocks |
| 10.1016/j.tca.2007.08.008 | 5 | 85 | binary | search_blocks |
| 10.1016/j.tca.2011.08.013 | 3 | 48 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2011.09.009 | 1 | 1 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2014.03.027 | 4 | 134 | binary | search_system_registry |
| 10.1021/acs.jced.8b01048 | 1 | 9 | binary | search_blocks, search_system_registry |
| 10.1021/je034007i | 5 | 85 | binary | search_blocks |
| 10.1021/je0497294 | 2 | 38 | binary | search_blocks |
| 10.1021/je0499317 | 9 | 163 | binary | search_blocks |
| 10.1021/je0501991 | 3 | 51 | binary | search_blocks |
| 10.1021/je050444g | 3 | 51 | binary | search_blocks |
| 10.1021/je0601513 | 1 | 51 | binary | search_blocks |
| 10.1021/je2002607 | 1 | 5 | binary | search_blocks, search_system_registry |
| 10.1021/je301171y | 1 | 63 | binary | search_blocks, search_system_registry |
| 10.1021/je400149j | 3 | 373 | binary | search_blocks, search_system_registry |
| 10.1021/je400531a | 2 | 42 | binary | search_blocks, search_system_registry |
| 10.1021/je500696p | 1 | 17 | binary | search_blocks |
| 10.1021/je7001013 | 2 | 145 | binary | search_blocks, search_system_registry |
| 10.1021/je700645p | 1 | 70 | binary | search_blocks, search_system_registry |
| 10.1021/je9001027 | 2 | 70 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2007.10.017 | PROPblock_13 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.10.017 | PROPblock_14 | declared | 12 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.10.017 | PROPblock_15 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.10.017 | PROPblock_16 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.10.017 | PROPblock_17 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.fluid.2008.09.010 | PROPblock_10 | declared | 17 | ternary | — | search_blocks |
| 10.1016/j.fluid.2008.09.010 | PROPblock_4 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2008.09.010 | PROPblock_5 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.05.005 | PROPblock_2 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.01.026 | PROPblock_1 | declared | 49 | ternary | — | search_blocks |
| 10.1016/j.fluid.2011.01.026 | PROPblock_2 | declared | 29 | ternary | — | search_blocks |
| 10.1016/j.fluid.2011.01.026 | PROPblock_3 | declared | 17 | ternary | — | search_blocks |
| 10.1016/j.fluid.2011.01.026 | PROPblock_4 | declared | 16 | ternary | — | search_blocks |
| 10.1016/j.fluid.2011.01.026 | PROPblock_5 | declared | 10 | ternary | — | search_blocks |
| 10.1016/j.fluid.2013.06.041 | PROPblock_12 | declared | 79 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.06.041 | PROPblock_14 | declared | 85 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.06.041 | PROPblock_16 | declared | 64 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.06.041 | PROPblock_18 | declared | 109 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.06.041 | PROPblock_20 | declared | 53 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.08.033 | PROPblock_5 | declared | 18 | ternary | — | search_blocks |
| 10.1016/j.fluid.2016.08.033 | PROPblock_6 | declared | 52 | ternary | — | search_blocks |
| 10.1016/j.fluid.2016.08.033 | PROPblock_7 | declared | 5 | ternary | — | search_blocks |
| 10.1016/j.fluid.2016.08.033 | PROPblock_8 | declared | 5 | ternary | — | search_blocks |
| 10.1016/j.fluid.2017.12.035 | PROPblock_10 | declared | 49 | ternary | — | search_blocks |
| 10.1016/j.jct.2005.03.015 | PROPblock_13 | declared | 56 | ternary | — | search_blocks |
| 10.1016/j.jct.2005.03.015 | PROPblock_14 | declared | 64 | ternary | — | search_blocks |
| 10.1016/j.jct.2005.03.015 | PROPblock_15 | declared | 64 | ternary | — | search_blocks |
| 10.1016/j.jct.2005.03.015 | PROPblock_16 | declared | 40 | ternary | — | search_blocks |
| 10.1016/j.jct.2005.03.015 | PROPblock_17 | declared | 64 | ternary | — | search_blocks |
| 10.1016/j.jct.2005.03.015 | PROPblock_18 | declared | 39 | ternary | — | search_blocks |
| 10.1016/j.jct.2005.07.012 | PROPblock_8 | declared | 96 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.01.007 | PROPblock_3 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.01.007 | PROPblock_4 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.01.007 | PROPblock_5 | declared | 132 | ternary | — | search_blocks |
| 10.1016/j.jct.2006.01.007 | PROPblock_6 | declared | 132 | ternary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_29 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_33 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_37 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_41 | declared | 14 | binary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_45 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_49 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_53 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2006.04.005 | PROPblock_57 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2006.09.007 | PROPblock_19 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.007 | PROPblock_21 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.007 | PROPblock_23 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.007 | PROPblock_25 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.007 | PROPblock_27 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.007 | PROPblock_29 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.007 | PROPblock_31 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.007 | PROPblock_33 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.12.012 | PROPblock_4 | declared | 120 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.04.004 | PROPblock_13 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.jct.2007.04.004 | PROPblock_15 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.jct.2007.04.004 | PROPblock_17 | declared | 14 | binary | — | search_blocks |
| 10.1016/j.jct.2007.04.011 | PROPblock_11 | declared | 130 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.06.007 | PROPblock_4 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.007 | PROPblock_5 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.007 | PROPblock_6 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.010 | PROPblock_3 | declared | 216 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.06.010 | PROPblock_4 | declared | 92 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.08.006 | PROPblock_14 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2007.08.006 | PROPblock_16 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2007.08.006 | PROPblock_18 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2007.08.006 | PROPblock_20 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2007.08.006 | PROPblock_22 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2009.05.015 | PROPblock_1 | declared | 99 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.07.005 | PROPblock_2 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.07.005 | PROPblock_4 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.07.005 | PROPblock_6 | declared | 165 | ternary | 3 | search_system_registry |
| 10.1016/j.jct.2011.05.034 | PROPblock_4 | declared | 70 | ternary | — | search_blocks |
| 10.1016/j.jct.2011.07.018 | PROPblock_13 | declared | 66 | binary | — | search_blocks |
| 10.1016/j.jct.2012.01.015 | PROPblock_1 | declared | 68 | ternary | — | search_blocks |
| 10.1016/j.jct.2012.01.015 | PROPblock_2 | declared | 68 | ternary | — | search_blocks |
| 10.1016/j.jct.2012.01.015 | PROPblock_3 | declared | 66 | ternary | — | search_blocks |
| 10.1016/j.jct.2013.01.010 | PROPblock_12 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.jct.2017.07.023 | PROPblock_3 | declared | 77 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.02.002 | PROPblock_4 | declared | 77 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.04.014 | PROPblock_4 | declared | 76 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.04.014 | PROPblock_5 | declared | 76 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.04.014 | PROPblock_6 | declared | 9 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.05.011 | PROPblock_4 | declared | 99 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.05.030 | PROPblock_4 | declared | 66 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.11.021 | PROPblock_3 | declared | 88 | ternary | — | search_blocks |
| 10.1016/j.jct.2018.12.045 | PROPblock_3 | declared | 88 | ternary | — | search_blocks |
| 10.1016/j.jct.2019.01.026 | PROPblock_4 | declared | 88 | ternary | — | search_blocks |
| 10.1016/j.jct.2019.02.016 | PROPblock_4 | declared | 88 | ternary | — | search_blocks |
| 10.1016/j.jct.2019.03.004 | PROPblock_2 | declared | 88 | ternary | — | search_blocks |
| 10.1016/j.jct.2019.04.001 | PROPblock_3 | declared | 81 | ternary | — | search_blocks |
| 10.1016/j.jct.2019.05.007 | PROPblock_1 | declared | 72 | ternary | — | search_blocks |
| 10.1016/j.jct.2019.06.025 | PROPblock_3 | declared | 72 | ternary | — | search_blocks |
| 10.1016/j.tca.2006.05.010 | PROPblock_23 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.05.010 | PROPblock_25 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.05.010 | PROPblock_27 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.05.010 | PROPblock_29 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.05.010 | PROPblock_31 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.05.010 | PROPblock_33 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_18 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_20 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_22 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_24 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_26 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_28 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_30 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2007.08.008 | PROPblock_13 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2007.08.008 | PROPblock_14 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.tca.2007.08.008 | PROPblock_15 | declared | 21 | binary | — | search_blocks |
| 10.1016/j.tca.2007.08.008 | PROPblock_16 | declared | 14 | binary | — | search_blocks |
| 10.1016/j.tca.2007.08.008 | PROPblock_17 | declared | 16 | binary | — | search_blocks |
| 10.1016/j.tca.2011.08.013 | PROPblock_10 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2011.08.013 | PROPblock_11 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2011.08.013 | PROPblock_12 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2011.09.009 | PROPblock_1 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2014.03.027 | PROPblock_10 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2014.03.027 | PROPblock_7 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2014.03.027 | PROPblock_8 | declared | 42 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2014.03.027 | PROPblock_9 | declared | 39 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b01048 | PROPblock_10 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je034007i | PROPblock_10 | declared | 17 | binary | — | search_blocks |
| 10.1021/je034007i | PROPblock_11 | declared | 17 | binary | — | search_blocks |
| 10.1021/je034007i | PROPblock_7 | declared | 17 | binary | — | search_blocks |
| 10.1021/je034007i | PROPblock_8 | declared | 17 | binary | — | search_blocks |
| 10.1021/je034007i | PROPblock_9 | declared | 17 | binary | — | search_blocks |
| 10.1021/je0497294 | PROPblock_20 | declared | 19 | binary | — | search_blocks |
| 10.1021/je0497294 | PROPblock_22 | declared | 19 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_10 | declared | 15 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_11 | declared | 18 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_12 | declared | 16 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_13 | declared | 22 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_14 | declared | 20 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_15 | declared | 18 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_16 | declared | 17 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_17 | declared | 20 | binary | — | search_blocks |
| 10.1021/je0499317 | PROPblock_18 | declared | 17 | binary | — | search_blocks |
| 10.1021/je0501991 | PROPblock_13 | declared | 17 | binary | — | search_blocks |
| 10.1021/je0501991 | PROPblock_18 | declared | 17 | binary | — | search_blocks |
| 10.1021/je0501991 | PROPblock_23 | declared | 17 | binary | — | search_blocks |
| 10.1021/je050444g | PROPblock_18 | declared | 17 | binary | — | search_blocks |
| 10.1021/je050444g | PROPblock_23 | declared | 17 | binary | — | search_blocks |
| 10.1021/je050444g | PROPblock_28 | declared | 17 | binary | — | search_blocks |
| 10.1021/je0601513 | PROPblock_10 | declared | 51 | binary | — | search_blocks |
| 10.1021/je2002607 | PROPblock_1 | declared | 5 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je301171y | PROPblock_5 | declared | 63 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je400149j | PROPblock_5 | declared | 363 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je400149j | PROPblock_6 | declared | 8 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je400149j | PROPblock_7 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je400531a | PROPblock_16 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je400531a | PROPblock_17 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je500696p | PROPblock_8 | declared | 17 | binary | — | search_blocks |
| 10.1021/je7001013 | PROPblock_10 | declared | 33 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je7001013 | PROPblock_9 | declared | 112 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700645p | PROPblock_6 | declared | 70 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je9001027 | PROPblock_4 | declared | 35 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 269 | KEEP | 269 | 3.9 |
| 2 | 1 | `L1_query` | instruction=Find the global compound IDs …, purpos… | 1,463 | — | — | 21.9 |
| 3 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Find GLOBprop_N ID… | 530 | KEEP | 530 | 7.3 |
| 4 | 1 | `L1_query` | instruction=Search for the global propert…, purpos… | 2,138 | — | — | 31.6 |
| 5 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Verify GLOBprop_17 … | 363 | KEEP | 363 | 4.2 |
| 6 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], property=G… | 773 | DISCARD | 715 | 14.8 |
| 7 | 2 | `L1_query` | context=Looking for excess molar enth…, id_catalog… | 221 | — | — | 136.2 |
| 8 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 732 | DISCARD | 674 | 10.0 |
| 9 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 906 | DISCARD | 848 | 19.2 |
| 10 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 311 | KEEP | 311 | 15.6 |
| 11 | 3 | `search_blocks` | compound=GLOBcomp_31, limit=50, property=GLOBprop_… | 1,212 | KEEP | 1092 | 12.1 |
| 12 | 2 | `L1_query` | context=Looking for excess molar volu…, id_catalog… | 2,951 | — | — | 108.7 |
| 13 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 902 | DISCARD | 844 | 16.9 |
| 14 | 2 | `search_blocks` | compound=GLOBcomp_31, limit=50, property=GLOBprop_… | 672 | DISCARD | 614 | 14.7 |
| 15 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 732 | DISCARD | 674 | 10.7 |
| 16 | 3 | `search_system_summary` | property=GLOBprop_85, purpose=Check if any excess … | 852 | KEEP | 852 | 9.5 |
| 17 | 4 | `search_system_registry` | limit=30, property=GLOBprop_85, purpose=Find all s… | 1,357 | KEEP | 1193 | 12.1 |
| 18 | 2 | `L1_query` | context=Looking for excess molar heat…, id_catalog… | 2,903 | — | — | 137.7 |
| 19 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 980 | DISCARD | 922 | 10.4 |
| 20 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 812 | DISCARD | 754 | 14.5 |
| 21 | 2 | `search_blocks` | compound=GLOBcomp_31, limit=50, property=GLOBprop_… | 1,334 | KEEP | 1204 | 13.1 |
| 22 | 3 | `L1_query` | context=Previous searches found no VE…, id_catalog… | 3,482 | — | — | 78.7 |
| 23 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 1,410 | KEEP | 1307 | 20.2 |
| 24 | 3 | `search_system_registry` | compound=['GLOBcomp_1', 'GLOBcomp_31'], limit=50, … | 1,244 | KEEP | 1048 | 16.7 |
| 25 | 4 | `L1_query` | context=Previous searches confirmed n…, id_catalog… | 277 | — | — | 230.7 |
| | | **TOTAL (25 tools)** | | **28,826** | | **14,214** | **971.4** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 5,558 | 5,558 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 5,658 | 5,658 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 5,562 | 5,562 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,016 | 10,621 | 15,178 | 70.6 |
| 2 | L1-worker | claudeopus46 | 20,643 | 730 | 21,373 | 590 | 4.6 |
| 3 | L1-worker | claudeopus46 | 2,065 | 507 | 2,572 | 433 | 3.8 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,463 | 22,106 | 389 | 3.8 |
| 5 | L1-worker | claudeopus46 | 1,323 | 1,901 | 3,224 | 234 | 2.5 |
| 6 | L1-worker | claudeopus46 | 1,356 | 520 | 1,876 | 321 | 2.7 |
| 7 | L1-worker | claudeopus46 | 536 | 400 | 936 | 332 | 4.5 |
| 8 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 2.6 |
| 9 | L1-worker | claudeopus46 | 747 | 2,544 | 3,291 | 455 | 4.2 |
| 10 | L1-worker | claudeopus46 | 20,643 | 2,453 | 23,096 | 661 | 4.8 |
| 11 | L1-worker | claudeopus46 | 20,643 | 3,735 | 24,378 | 1,068 | 5.0 |
| 12 | L1-worker | claudeopus46 | 2,065 | 1,252 | 3,317 | 1,182 | 7.1 |
| 13 | L1-worker | claudeopus46 | 20,643 | 4,203 | 24,846 | 646 | 4.6 |
| 14 | L1-worker | claudeopus46 | 1,323 | 2,767 | 4,090 | 235 | 2.5 |
| 15 | L1-worker | claudeopus46 | 1,356 | 775 | 2,131 | 399 | 2.8 |
| 16 | L1-worker | claudeopus46 | 536 | 655 | 1,191 | 599 | 3.5 |
| 17 | L1-worker | claudeopus46 | 298 | 957 | 1,255 | 155 | 2.4 |
| 18 | L1-worker | claudeopus46 | 747 | 3,999 | 4,746 | 515 | 4.4 |
| 19 | L0-main | claudeopus46 | 9,605 | 9,286 | 18,891 | 3,242 | 14.6 |
| 20 | L1-worker | claudeopus46 | 20,643 | 5,292 | 25,935 | 1,388 | 9.0 |
| 21 | L1-worker | claudeopus46 | 20,643 | 7,408 | 28,051 | 7,223 | 31.7 |
| 22 | L1-worker | claudeopus46 | 2,065 | 852 | 2,917 | 559 | 4.0 |
| 23 | L1-worker | claudeopus46 | 2,065 | 515 | 2,580 | 1,602 | 10.0 |
| 24 | L1-worker | claudeopus46 | 20,643 | 8,576 | 29,219 | 7,091 | 35.7 |
| 25 | L1-worker | claudeopus46 | 20,643 | 16,242 | 36,885 | 2,666 | 11.3 |
| 26 | L1-worker | claudeopus46 | 1,356 | 2,567 | 3,923 | 991 | 5.6 |
| 27 | L1-worker | claudeopus46 | 536 | 2,447 | 2,983 | 1,190 | 6.2 |
| 28 | L1-worker | claudeopus46 | 1,323 | 6,393 | 7,716 | 2,691 | 12.2 |
| 29 | L1-worker | claudeopus46 | 298 | 3,413 | 3,711 | 1,983 | 8.0 |
| 30 | L1-worker | claudeopus46 | 1,160 | 9,439 | 10,599 | 1,768 | 8.6 |
| 31 | L1-worker | claudeopus46 | 20,643 | 5,284 | 25,927 | 745 | 5.3 |
| 32 | L1-worker | claudeopus46 | 2,065 | 511 | 2,576 | 1,596 | 9.7 |
| 33 | L1-worker | claudeopus46 | 20,643 | 6,515 | 27,158 | 872 | 8.7 |
| 34 | L1-worker | claudeopus46 | 2,065 | 474 | 2,539 | 1,233 | 8.9 |
| 35 | L1-worker | claudeopus46 | 20,643 | 7,953 | 28,596 | 1,211 | 7.6 |
| 36 | L1-worker | claudeopus46 | 2,065 | 38,432 | 40,497 | 1,639 | 14.2 |
| 37 | L1-worker | claudeopus46 | 2,065 | 9,975 | 12,040 | 1,351 | 11.3 |
| 38 | L1-worker | claudeopus46 | 20,610 | 10,890 | 31,500 | 525 | 4.9 |
| 39 | L1-worker | claudeopus46 | 20,643 | 10,137 | 30,780 | 2,341 | 13.9 |
| 40 | L1-worker | claudeopus46 | 1,356 | 1,486 | 2,842 | 770 | 3.8 |
| 41 | L1-worker | claudeopus46 | 1,323 | 7,523 | 8,846 | 92 | 4.0 |
| 42 | L1-worker | claudeopus46 | 536 | 1,366 | 1,902 | 675 | 4.1 |
| 43 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.0 |
| 44 | L1-worker | claudeopus46 | 747 | 9,137 | 9,884 | 526 | 4.8 |
| 45 | L1-worker | claudeopus46 | 20,643 | 8,366 | 29,009 | 779 | 5.8 |
| 46 | L1-worker | claudeopus46 | 2,065 | 513 | 2,578 | 1,579 | 9.8 |
| 47 | L1-worker | claudeopus46 | 20,643 | 9,774 | 30,417 | 3,768 | 17.7 |
| 48 | L1-worker | claudeopus46 | 2,065 | 448 | 2,513 | 1,083 | 7.3 |
| 49 | L1-worker | claudeopus46 | 2,065 | 465 | 2,530 | 1,016 | 6.8 |
| 50 | L1-worker | claudeopus46 | 20,643 | 11,870 | 32,513 | 3,015 | 18.2 |
| 51 | L1-worker | claudeopus46 | 2,065 | 1,253 | 3,318 | 1,182 | 8.6 |
| 52 | L1-worker | claudeopus46 | 20,610 | 14,042 | 34,652 | 519 | 4.8 |
| 53 | L1-worker | claudeopus46 | 20,643 | 13,289 | 33,932 | 762 | 6.2 |
| 54 | L1-worker | claudeopus46 | 2,065 | 4,288 | 6,353 | 1,487 | 11.1 |
| 55 | L1-worker | claudeopus46 | 20,643 | 15,138 | 35,781 | 1,521 | 10.6 |
| 56 | L1-worker | claudeopus46 | 1,323 | 9,394 | 10,717 | 92 | 2.0 |
| 57 | L1-worker | claudeopus46 | 1,356 | 1,652 | 3,008 | 588 | 3.8 |
| 58 | L1-worker | claudeopus46 | 536 | 1,532 | 2,068 | 646 | 4.0 |
| 59 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.2 |
| 60 | L1-worker | claudeopus46 | 747 | 10,930 | 11,677 | 612 | 5.7 |
| 61 | L0-main | claudeopus46 | 9,605 | 17,275 | 26,880 | 1,708 | 12.0 |
| 62 | L1-worker | claudeopus46 | 20,643 | 11,607 | 32,250 | 889 | 5.9 |
| 63 | L1-worker | claudeopus46 | 2,065 | 651 | 2,716 | 1,701 | 10.0 |
| 64 | L1-worker | claudeopus46 | 20,643 | 13,095 | 33,738 | 1,182 | 8.1 |
| 65 | L1-worker | claudeopus46 | 2,065 | 471 | 2,536 | 1,337 | 9.2 |
| 66 | L1-worker | claudeopus46 | 2,065 | 33,322 | 35,387 | 1,496 | 11.9 |
| 67 | L1-worker | claudeopus46 | 20,643 | 15,961 | 36,604 | 2,547 | 15.1 |
| 68 | L1-worker | claudeopus46 | 1,323 | 7,831 | 9,154 | 92 | 2.1 |
| 69 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 1.8 |
| 70 | L1-worker | claudeopus46 | 536 | 1,707 | 2,243 | 840 | 4.0 |
| 71 | L1-worker | claudeopus46 | 1,356 | 1,827 | 3,183 | 791 | 4.4 |
| 72 | L1-worker | claudeopus46 | 747 | 9,717 | 10,464 | 481 | 6.5 |
| 73 | L0-main | claudeopus46 | 9,605 | 24,879 | 34,484 | 1,751 | 12.0 |
| 74 | L1-worker | claudeopus46 | 20,643 | 15,110 | 35,753 | 856 | 6.4 |
| 75 | L1-worker | claudeopus46 | 20,643 | 16,587 | 37,230 | 10,667 | 43.4 |
| 76 | L1-worker | claudeopus46 | 2,065 | 19,069 | 21,134 | 1,635 | 12.7 |
| 77 | L1-worker | claudeopus46 | 20,643 | 17,951 | 38,594 | 10,604 | 51.7 |
| 78 | L1-worker | claudeopus46 | 2,065 | 5,002 | 7,067 | 1,718 | 12.4 |
| 79 | L1-worker | claudeopus46 | 20,610 | 20,517 | 41,127 | 475 | 6.0 |
| 80 | L1-worker | claudeopus46 | 20,643 | 19,764 | 40,407 | 6,786 | 37.8 |
| 81 | L1-worker | claudeopus46 | 1,356 | 3,832 | 5,188 | 784 | 6.3 |
| 82 | L1-worker | claudeopus46 | 536 | 3,712 | 4,248 | 1,078 | 7.2 |
| 83 | L1-worker | claudeopus46 | 298 | 1,166 | 1,464 | 772 | 3.2 |
| 84 | L1-worker | claudeopus46 | 1,323 | 9,052 | 10,375 | 4,087 | 17.4 |
| 85 | L1-worker | claudeopus46 | 298 | 4,809 | 5,107 | 3,351 | 14.4 |
| 86 | L1-worker | claudeopus46 | 1,160 | 14,132 | 15,292 | 3,348 | 15.4 |
| 87 | L0-main | claudeopus46 | 9,605 | 26,015 | 35,620 | 2,788 | 17.2 |
| 88 | L0-main | claudeopus46 | 1,356 | 2,919 | 4,275 | 1,055 | 5.5 |
| 89 | L0-main | claudeopus46 | 298 | 1,437 | 1,735 | 1,043 | 3.7 |
| 90 | L0-main | claudeopus46 | 1,323 | 23,424 | 24,747 | 1,894 | 10.9 |
| 91 | L0-main | claudeopus46 | 298 | 2,562 | 2,860 | 1,629 | 5.5 |


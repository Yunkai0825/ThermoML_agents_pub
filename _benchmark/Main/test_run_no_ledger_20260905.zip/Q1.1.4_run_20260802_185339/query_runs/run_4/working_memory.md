# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_15 | 75-05-8 | acetonitrile |
| comp | GLOBcomp_18 | 68-12-2 | N,N-dimethylformamide |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find experimental dynamic viscosity data for the binary mixture of acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (G → stored as L1_query_1
- [L1] Extract row-level viscosity data points from PROPblock_18 in GLOBlit_7481 at T=298.15 K for the acetonitrile + DMF binar → stored as L1_query_2
- [L1] Extract individual row-level viscosity data points from PROPblock_18 in GLOBlit_7481 → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "Two ThermoML data blocks were found containing dynamic viscosity (GLOBprop_4, Pa·s) measurements for the binary mixture of acetonitrile (GLOBcomp_15, CAS 75-05-8) + N,N-dimethylformamide (GLOBcomp_18, CAS 68-12-2):\n\n**Block 1 — PROPblock_6 (GLOBlit_4124)**\n- **DOI:** 10.1016/j.jct.2014.02.019\n- **Method:** Capillary Ostwald-Ubbelohde viscometer (GLOBmeas_4)\n- **Composition variable:** Mass fraction of DMF (w_DMF = 0.0–1.0)\n- **Temperature range:** 298.15–313.15 K\n- **Pressure:** 101.0 kPa\n- **Total data points:** 20\n- **Representative value at 298.15 K:** Pure acetonitrile viscosity ≈ 0.000342 Pa·s (0.342 mPa·s). This block reports composition in mass fraction, so the equimolar point (x_DMF ≈ 0.5) corresponds to a mass fraction of approximately w_DMF ≈ 0.64 (given M_acetonitrile = 41.05 g/mol, M_DMF = 73.09 g/mol). Data at or near this mass fraction at 298.15 K should be present in the block.\n\n**Block 2 — PROPblock_18 (GLOBlit_7481)**\n- **DOI:** 10.1021/acs.jced.8b00176\n- **Method:** Falling/rolling sphere viscometer (GLOBmeas_8)\n- **Composition variable:** Mole fraction of DMF (x_DMF = 0.0–1.0)\n- **Temperature range:** 298.15–318.15 K\n- **Pressure:** 100.0 kPa\n- **Total data points:** 66\n- **Representative value at 298.15 K:** Pure acetonitrile viscosity ≈ 0.00034 Pa·s (0.34 mPa·s). This block directly uses mole fraction as the composition variable, so data at x_DMF ≈ 0.5 at 298.15 K should be directly available. With 66 data points spanning the full composition range at multiple temperatures, this block likely contains several points near equimolar composition at 298.15 K.\n\n**Chemistry insight:** In the acetonitrile + DMF binary system, both components are polar aprotic solvents. The dynamic viscosity of pure acetonitrile at 298.15 K is approximately 0.34 mPa·s, while pure DMF is significantly more viscous (~0.80 mPa·s). At equimolar composition (x_DMF ≈ 0.5), the mixture viscosity is expected to fall between these pure-component values, potentially showing slight positive or negative deviations from ideal mixing depending on intermolecular interactions (dipole-dipole and dispersion forces). The exact viscosity value near x = 0.5 at 298.15 K can be extracted from PROPblock_18 (GLOBlit_7481), which directly reports mole-fraction-based composition data across the full range.\n\nAlthough exact numerical values at x = 0.5 could not be extracted at the row level due to search limitations, both blocks are confirmed to contain viscosity data at 298.15 K spanning the full composition range, and the mole-fraction-based block (PROPblock_18, DOI: 10.1021/acs.jced.8b00176) is the most directly useful for obtaining the equimolar viscosity value.",
  "core_claims": [
    "Two ThermoML data blocks contain dynamic viscosity measurements for the binary mixture acetonitrile + N,N-dimethylformamide spanning the full composition range at temperatures including 298.15 K and near-ambient pressure (~100–101 kPa).",
    "Block 1 (DOI: 10.1016/j.jct.2014.02.019) reports 20 data points at 298.15–313.15 K using a capillary Ostwald-Ubbelohde viscometer with composition expressed as mass fraction of DMF.",
    "Block 2 (DOI: 10.1021/acs.jced.8b00176) reports 66 data points at 298.15–318.15 K using a falling/rolling sphere viscometer with composition expressed as mole fraction of DMF, making it more directly useful for obtaining equimolar viscosity values.",
    "Pure acetonitrile viscosity at 298.15 K is approximately 0.34 mPa·s and pure DMF is approximately 0.80 mPa·s; at equimolar composition the mixture viscosity is expected to fall between these values, with possible slight deviations from ideal mixing due to dipole-dipole and dispersion interactions.",
    "Exact row-level numerical values at equimolar composition could not be extracted due to search limitations, but both blocks are confirmed to span the full composition range at 298.15 K."
  ],
  "status": "partial",
  "summary": "Two ThermoML data blocks report dynamic viscosity (Pa·s) for the binary mixture acetonitrile (CAS 75-05-8) + N,N-dimethylformamide (CAS 68-12-2). Block 1 (PROPblock_6, DOI 10.1016/j.jct.2014.02.019) uses a capillary Ostwald-Ubbelohde viscometer, reports composition as mass fraction of DMF (0–1), covers 298.15–313.15 K at 101.0 kPa, and contains 20 data points. Block 2 (PROPblock_18, DOI 10.1021/acs.jced.8b00176) uses a falling/rolling sphere viscometer, reports composition as mole fraction of DMF (0–1), covers 298.15–318.15 K at 100.0 kPa, and contains 66 data points. Pure acetonitrile viscosity at 298.15 K is approximately 0.34 mPa·s; pure DMF is approximately 0.80 mPa·s. At equimolar composition the mixture viscosity is expected between these values. Block 2 is the most directly useful for obtaining equimolar viscosity because it uses mole fraction as the composition variable across the full range at multiple temperatures.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_4124",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) of acetonitrile + N,N-dimethylformamide binary mixture measured by capillary Ostwald-Ubbelohde viscometer (GLOBmeas_4). Composition in mass fraction of DMF (0.0–1.0), T = 298.15–313.15 K, P = 101.0 kPa, 20 data points. DOI: 10.1016/j.jct.2014.02.019. Exact row-level values near equimolar composition at 298.15 K could not be extracted due to block_search_adv validation failures.",
      "doi": "10.1016/j.jct.2014.02.019",
      "lit_id": "2014-bra-pra-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 20,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_3",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 5
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000293,
            "max": 0.000799,
            "mean": 0.000492,
            "std": 0.000163,
            "n": 20
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000293,
          "range_max": 0.000799
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 20,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_7481",
      "block_number": "PROPblock_18",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) of acetonitrile + N,N-dimethylformamide binary mixture measured by falling/rolling sphere viscometer (GLOBmeas_8). Composition in mole fraction of DMF (0.0–1.0), T = 298.15–318.15 K, P = 100.0 kPa, 66 data points. DOI: 10.1021/acs.jced.8b00176. This block directly uses mole fraction and is most suitable for extracting equimolar viscosity, but exact row-level values near x_DMF ≈ 0.5 at 298.15 K could not be retrieved due to repeated block_search_adv validation errors.",
      "doi": "10.1021/acs.jced.8b00176",
      "lit_id": "2018-fat-riy-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 66,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 323.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 323.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.00028,
            "max": 0.00081,
            "mean": 0.00052,
            "std": 0.000141,
            "n": 66
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.00028,
          "range_max": 0.00081
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 66,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_2
{
  "answer": "The ThermoML database contains viscosity data for the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) in PROPblock_18 of GLOBlit_7481 (DOI: 10.1021/acs.jced.8b00176). At T = 298.15 K, this block contains **11 data points** spanning the full composition range (mole fraction of DMF from 0.0 to 1.0, with 11 unique mole fractions). The measurement method is falling/rolling sphere viscometry (GLOBmeas_8), at a fixed pressure of 100.0 kPa in the liquid phase.\n\n**Confirmed aggregate statistics at 298.15 K:**\n- Number of data points: 11\n- Mean viscosity: 0.000591 Pa·s (0.591 mPa·s)\n- Overall block viscosity range (all temperatures): 0.00028–0.00081 Pa·s\n\n**Block-level property range (all 66 data points, 298.15–323.15 K):**\n- Minimum viscosity: 0.00028 Pa·s (0.28 mPa·s) — likely pure acetonitrile at the highest temperature\n- Maximum viscosity: 0.00081 Pa·s (0.81 mPa·s) — likely pure DMF at 298.15 K\n\nIndividual row-level mole fraction–viscosity pairs at 298.15 K could not be extracted from the database query tools. However, the mean viscosity of 0.591 mPa·s across all 11 compositions at 298.15 K is consistent with the expected behavior: pure acetonitrile viscosity is approximately 0.34 mPa·s and pure DMF is approximately 0.80 mPa·s at this temperature, so the viscosity at equimolar composition (x_DMF ≈ 0.5) is expected to be near or slightly above the arithmetic mean of the pure-component values (~0.57 mPa·s), depending on the sign and magnitude of excess viscosity contributions from dipole–dipole interactions between these two polar aprotic solvents.\n\nA second data source is also available: PROPblock_6 in GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019), which reports 20 data points at 298.15–313.15 K using a capillary Ostwald-Ubbelohde viscometer (GLOBmeas_4) with composition expressed as mass fraction of DMF, at 101.0 kPa. Its viscosity range (0.000293–0.000799 Pa·s) is consistent with the other source.",
  "core_claims": [
    "The ThermoML database contains viscosity data for the binary mixture acetonitrile + N,N-dimethylformamide in at least two literature sources (DOI: 10.1021/acs.jced.8b00176 and DOI: 10.1016/j.jct.2014.02.019), measured by falling/rolling sphere and capillary Ostwald-Ubbelohde viscometry, respectively.",
    "At 298.15 K and approximately 100 kPa in the liquid phase, one source provides 11 data points spanning the full DMF mole-fraction range (0.0 to 1.0), with a mean viscosity of 0.591 mPa·s across all compositions.",
    "The overall viscosity range across all temperatures (298.15–323.15 K) and compositions in the primary block is 0.28–0.81 mPa·s, consistent with the known pure-component viscosities of acetonitrile (~0.34 mPa·s) and DMF (~0.80 mPa·s) at 298.15 K.",
    "A second data source reports 20 data points at 298.15–313.15 K with composition expressed as mass fraction of DMF, yielding a consistent viscosity range of 0.000293–0.000799 Pa·s.",
    "Individual row-level mole-fraction–viscosity pairs at 298.15 K could not be extracted from the database query tools, limiting the resolution of composition-dependent trends."
  ],
  "status": "partial",
  "summary": "The ThermoML database contains viscosity data for the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18). In PROPblock_18 of GLOBlit_7481 (DOI: 10.1021/acs.jced.8b00176), there are 11 data points at T = 298.15 K spanning the full composition range (mole fraction of DMF from 0.0 to 1.0), measured by falling/rolling sphere viscometry at 100.0 kPa in the liquid phase. The mean viscosity at 298.15 K across all 11 compositions is 0.000591 Pa·s (0.591 mPa·s). The overall block (66 data points, 298.15–323.15 K) has a viscosity range of 0.00028–0.00081 Pa·s, with the minimum likely corresponding to pure acetonitrile at the highest temperature and the maximum to pure DMF at 298.15 K. A second consistent source exists in PROPblock_6 of GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019), reporting 20 data points at 298.15–313.15 K using a capillary Ostwald-Ubbelohde viscometer with composition as mass fraction of DMF at 101.0 kPa, with a viscosity range of 0.000293–0.000799 Pa·s. Individual row-level mole fraction–viscosity pairs at 298.15 K could not be extracted. The mean viscosity is consistent with expected behavior given pure-component values of approximately 0.34 mPa·s for acetonitrile and 0.80 mPa·s for DMF at 298.15 K.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_7481",
      "block_number": "PROPblock_18",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of temperature (GLOBvar_1) and mole fraction of DMF (GLOBvar_2). Block contains 66 data points (6 temperatures × 11 compositions). At T=298.15 K, 11 data points were confirmed with a mean viscosity of 0.000591 Pa·s, but individual row-level mole-fraction/viscosity pairs could not be extracted due to repeated block_search_adv validation errors. Overall block viscosity range: 0.00028–0.00081 Pa·s. Measurement method: falling/rolling sphere viscometry (GLOBmeas_8), pressure 100.0 kPa, liquid phase (GLOBphase_1).",
      "doi": "10.1021/acs.jced.8b00176",
      "lit_id": "2018-fat-riy-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 66,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 323.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 323.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.00028,
            "max": 0.00081,
            "mean": 0.00052,
            "std": 0.000141,
            "n": 66
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.00028,
          "range_max": 0.00081
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 66,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_3
{
  "answer": "The ThermoML database contains dynamic viscosity data for the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) in PROPblock_18 of GLOBlit_7481 (DOI: 10.1021/acs.jced.8b00176). At T = 298.15 K and P = 100.0 kPa (liquid phase), there are 11 data points spanning the full composition range (mole fraction of DMF from 0.0 to 1.0, with 11 unique compositions). The measurement method is falling/rolling sphere viscometry (GLOBmeas_8).\n\n**Successfully extracted data point at near-equimolar composition:**\n\n| x_DMF | T (K) | Viscosity (Pa·s) | Viscosity (mPa·s) |\n|-------|--------|-------------------|--------------------|\n| 0.5029 | 298.15 | 0.00061 | 0.61 |\n\n**Aggregate statistics at T = 298.15 K (all 11 compositions):**\n- Minimum viscosity: 0.00034 Pa·s (0.34 mPa·s) — pure acetonitrile endpoint\n- Maximum viscosity: 0.00081 Pa·s (0.81 mPa·s) — pure DMF endpoint\n- Mean viscosity across all 11 compositions: 0.000591 Pa·s (0.591 mPa·s)\n- Number of data points: 11\n\nIndividual row-level extraction for all 11 mole-fraction/viscosity pairs at 298.15 K was not achievable due to repeated tool validation constraints. However, the key equimolar data point (x_DMF ≈ 0.5, η = 0.61 mPa·s) and the full-range aggregate statistics were successfully confirmed.\n\nThe viscosity at equimolar composition (0.61 mPa·s) is slightly above the arithmetic mean of the pure-component values (~0.57 mPa·s), suggesting a small positive deviation from ideal mixing, consistent with enhanced dipole–dipole interactions between these two polar aprotic solvents in the mixture.\n\n**Source:** DOI 10.1021/acs.jced.8b00176 (GLOBlit_7481), PROPblock_18.",
  "core_claims": [
    "The ThermoML database (DOI 10.1021/acs.jced.8b00176) contains 11 dynamic viscosity data points for the binary mixture acetonitrile + N,N-dimethylformamide at T = 298.15 K and P = 100.0 kPa, spanning the full composition range (DMF mole fraction 0.0 to 1.0), measured by falling/rolling sphere viscometry.",
    "Across the full composition range at 298.15 K, the dynamic viscosity ranges from 0.34 mPa·s (pure acetonitrile) to 0.81 mPa·s (pure DMF), with a mean of 0.591 mPa·s over all 11 compositions.",
    "At near-equimolar composition (x_DMF ≈ 0.5029), the dynamic viscosity is 0.61 mPa·s, which is slightly above the arithmetic mean of the pure-component values (~0.57 mPa·s), suggesting a small positive deviation from ideal mixing consistent with enhanced dipole–dipole interactions between these two polar aprotic solvents."
  ],
  "status": "partial",
  "summary": "The ThermoML database (DOI 10.1021/acs.jced.8b00176, GLOBlit_7481, PROPblock_18) contains dynamic viscosity data for the binary mixture acetonitrile + N,N-dimethylformamide measured by falling/rolling sphere viscometry at T = 298.15 K and P = 100.0 kPa. There are 11 data points spanning the full composition range (DMF mole fraction 0.0 to 1.0). Viscosity ranges from 0.34 mPa·s (pure acetonitrile) to 0.81 mPa·s (pure DMF), with a mean of 0.591 mPa·s across all compositions. At near-equimolar composition (x_DMF = 0.5029), the viscosity is 0.61 mPa·s, slightly above the arithmetic mean of the pure-component values (~0.57 mPa·s), indicating a small positive deviation from ideal mixing consistent with enhanced dipole–dipole interactions between these polar aprotic solvents.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_7481",
      "block_number": "PROPblock_18",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (GLOBprop_4, Pa·s) for the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of mole fraction of DMF (GLOBvar_2) and temperature (GLOBvar_1) at P=100 kPa. Block contains 66 total data points (11 compositions × 6 temperatures). At T=298.15 K, 11 data points span viscosities from 0.00034 to 0.00081 Pa·s. Only one individual row was successfully extracted: x_DMF=0.5029, η=0.00061 Pa·s. Full row-level extraction was blocked by repeated tool validation errors on the select clause.",
      "doi": "10.1021/acs.jced.8b00176",
      "lit_id": "2018-fat-riy-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 66,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 323.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 323.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.00028,
            "max": 0.00081,
            "mean": 0.00052,
            "std": 0.000141,
            "n": 66
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.00028,
          "range_max": 0.00081
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 66,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


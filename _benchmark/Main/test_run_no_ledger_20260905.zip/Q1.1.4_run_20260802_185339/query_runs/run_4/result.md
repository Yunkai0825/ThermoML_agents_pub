# Delegated query run — result

**Question:** Find all experimental viscosity data for the binary mixture of acetonitrile (GLOBcomp_15) and N,N-dimethylformamide (GLOBcomp_18) at 298.15 K. I need specific viscosity values at or near equimolar composition (mole fraction = 0.5).

**Iterations:** 4  |  **Elapsed:** 908.5s  |  **Tools:** 6  |  **Timed out:** False

---

## Answer

## Experimental Viscosity Data for the Acetonitrile + N,N-Dimethylformamide Binary Mixture at 298.15 K

The ThermoML database contains dynamic viscosity measurements for the binary mixture of acetonitrile (CAS 75-05-8) and N,N-dimethylformamide (DMF, CAS 68-12-2) from two independent literature sources:

---

### Source 1 (Primary — mole-fraction-based composition)

**DOI:** 10.1021/acs.jced.8b00176 (GLOBlit_7481, PROPblock_18)

- **Method:** Falling/rolling sphere viscometry
- **Conditions:** T = 298.15–323.15 K, P = 100.0 kPa, liquid phase
- **Total data points:** 66 (11 compositions × 6 temperatures)
- **At T = 298.15 K:** 11 data points spanning DMF mole fraction from 0.0 to 1.0

**Key data point at near-equimolar composition:**

| x(DMF) | T (K) | η (Pa·s) | η (mPa·s) |
|--------|--------|-----------|------------|
| 0.5029 | 298.15 | 0.00061   | **0.61**   |

**Aggregate statistics at 298.15 K (all 11 compositions):**
- Pure acetonitrile (x_DMF = 0): η ≈ 0.34 mPa·s
- Pure DMF (x_DMF = 1): η ≈ 0.81 mPa·s
- Mean across all 11 compositions: 0.591 mPa·s

---

### Source 2 (Mass-fraction-based composition)

**DOI:** 10.1016/j.jct.2014.02.019 (GLOBlit_4124, PROPblock_6)

- **Method:** Capillary Ostwald-Ubbelohde viscometer
- **Conditions:** T = 298.15–313.15 K, P = 101.0 kPa, liquid phase
- **Total data points:** 20 (5 compositions × 4 temperatures)
- **Composition variable:** Mass fraction of DMF (0.0–1.0)
- **Viscosity range:** 0.000293–0.000799 Pa·s (0.293–0.799 mPa·s)

Note: For this source, the equimolar composition (x_DMF ≈ 0.5) corresponds to a mass fraction of DMF of approximately 0.64 (given M_acetonitrile = 41.05 g/mol, M_DMF = 73.09 g/mol). Individual row-level values from this block could not be extracted, but the overall viscosity range is consistent with Source 1.

---

### Chemistry Insight

Both acetonitrile and DMF are polar aprotic solvents with significant dipole moments (acetonitrile: 3.92 D; DMF: 3.86 D). The viscosity at near-equimolar composition (0.61 mPa·s at x_DMF = 0.5029) is slightly above the arithmetic mean of the pure-component values (~0.57 mPa·s), indicating a **small positive deviation from ideal mixing**. This positive excess viscosity is consistent with enhanced dipole–dipole interactions between acetonitrile and DMF molecules in the mixture, where the different molecular geometries (linear nitrile vs. planar amide) allow favorable packing and intermolecular association that slightly increases the resistance to flow compared to the ideal mixture prediction.

### Core claims

- Two independent ThermoML sources report dynamic viscosity data for the acetonitrile + N,N-dimethylformamide binary mixture at 298.15 K, with pure-component viscosities of approximately 0.34 mPa·s (acetonitrile) and 0.81 mPa·s (DMF), and a near-equimolar value (x_DMF = 0.5029) of 0.61 mPa·s.
- The near-equimolar viscosity (0.61 mPa·s) exceeds the arithmetic mean of the pure-component values (~0.57 mPa·s), indicating a small positive deviation from ideal mixing behavior.
- The positive excess viscosity is attributed to enhanced dipole–dipole interactions between the linear nitrile (acetonitrile) and planar amide (DMF) molecules, which allow favorable packing and intermolecular association that slightly increases resistance to flow.
- The two sources employ different experimental methods (falling/rolling sphere viscometry and capillary Ostwald-Ubbelohde viscometry) and report composition in different units (mole fraction vs. mass fraction), but yield consistent viscosity ranges.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_7481 | 10.1021/acs.jced.8b00176 | PROPblock_18 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) measured by falling/rolling sphere viscometry (GLOBmeas_8). Composition as mole fraction of DMF (0.0–1.0, 11 unique values), T = 298.15–323.15 K (6 temperatures), P = 100.0 kPa, liquid phase, 66 total data points. At T = 298.15 K: 11 data points, viscosity range 0.00034–0.00081 Pa·s, mean 0.000591 Pa·s. Near-equimolar point extracted: x_DMF = 0.5029, η = 0.00061 Pa·s (0.61 mPa·s). Full row-level extraction was not achievable due to tool validation constraints. |
| GLOBlit_4124 | 10.1016/j.jct.2014.02.019 | PROPblock_6 |  | Dynamic viscosity (GLOBprop_4, Pa·s) for the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) measured by capillary Ostwald-Ubbelohde viscometer (GLOBmeas_4). Composition as mass fraction of DMF (0.0–1.0, 5 unique values), T = 298.15–313.15 K, P = 101.0 kPa, liquid phase, 20 total data points. Viscosity range 0.000293–0.000799 Pa·s. Individual row-level values at equimolar composition were not extracted. |

### Suggested follow-ups

- Retry row-level extraction from PROPblock_18 (GLOBlit_7481) using block_data_extract with explicit datapoint index filtering for T = 298.15 K to obtain all 11 mole-fraction/viscosity pairs.
- Extract row-level data from PROPblock_6 (GLOBlit_4124) at T = 298.15 K to obtain mass-fraction/viscosity pairs and convert to mole-fraction basis for cross-validation with Source 1.
- Search for excess viscosity or viscosity deviation data for the same binary system, which may be reported in separate property blocks under different property IDs.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_15",
    "registry_id": "75-05-8",
    "name": "acetonitrile"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_18",
    "registry_id": "68-12-2",
    "name": "N,N-dimethylformamide"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_3",
    "name": "Mole fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_5",
    "registry_id": "mass_fraction_DOIcomp_3",
    "name": "Mass fraction"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_8",
    "registry_id": "falling_or_rolling_sphere_viscometry",
    "name": "Falling or rolling sphere viscometry"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_4",
    "registry_id": "capillary_tube_ostwald_ubbelohde_method",
    "name": "Capillary tube (Ostwald; Ubbelohde) method"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

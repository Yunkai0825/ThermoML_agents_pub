# Reference Stats — query-agent

**Run started:** 2026-08-02 18:55:08
**Wall time (at last flush):** 947.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 186,289 | 18,424 | 227,984 | 28,498 | 114.8 | claudeopus46 |
| L1-worker | 70 | 902,899 | 1,096,823 | 126,974 | 1,999,722 | 28,567 | 847.4 | claudeopus46 |
| **TOTAL** | **78** | **944,594** | **1,283,112** | **145,398** | **2,227,706** | **28,560** | **962.2** | |

**Estimated tokens:** ~556,926 input + ~36,349 output = ~593,275 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `memory_catalog_add` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 1 | 2 | 2 | 86 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| **TOTAL** | **14** | **1** | **5** | **1** | **8** | **2** | **86** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### References (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_4124 |  | search_blocks |
| GLOBlit_7481 |  | block_search_adv, search_blocks |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_18 | dimethylformamide | block_search_adv, search_blocks |
| GLOBcomp_15 | acetonitrile | block_search_adv, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Variables | 3 |
| Unique References | 2 |
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Unique Phases | 1 |
| Unique Constraints | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 2 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 86 |

---

## 3. DOI & Block References

**Unique DOIs:** 2  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 86

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2014.02.019 | 1 | 20 | binary | search_blocks |
| 10.1021/acs.jced.8b00176 | 1 | 66 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2014.02.019 | PROPblock_6 | declared | 20 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00176 | PROPblock_18 | declared | 66 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `memory_catalog_add` | global_id=GLOBcomp_15, name=acetonitrile, registry… | 2 | — | — | 0.0 |
| 2 | 1 | `memory_catalog_add` | global_id=GLOBcomp_18, name=N,N-dimethylformamide,… | 2 | — | — | 0.0 |
| 3 | 1 | `memory_catalog_add` | global_id=GLOBprop_4, name=Viscosity (dynamic), re… | 127 | — | — | 0.0 |
| 4 | 2 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 248 | KEEP | 248 | 4.7 |
| 5 | 6 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 740 | DISCARD | 679 | 12.4 |
| 6 | 7 | `search_blocks` | compound=['GLOBcomp_15', 'GLOBcomp_18'], limit=50,… | 1,193 | KEEP | 1163 | 13.5 |
| 7 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 827 | DISCARD | 766 | 20.5 |
| 8 | 12 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 775 | DISCARD | 714 | 8.8 |
| 9 | 1 | `L1_query` | context=Binary mixture viscosity sear…, id_catalog… | 17,308 | — | — | 298.8 |
| 10 | 3 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 738 | KEEP | 708 | 16.9 |
| 11 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 723 | DISCARD | 662 | 15.3 |
| 12 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 751 | KEEP | 721 | 15.3 |
| 13 | 2 | `L1_query` | context=PROPblock_18 in GLOBlit_7481 …, id_catalog… | 10,889 | — | — | 250.8 |
| 14 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 755 | DISCARD | 694 | 19.0 |
| 15 | 5 | `block_search_adv` | calculate=['xdmf AS xdmf_val', 'visc AS…, compound… | 791 | KEEP | 776 | 9.6 |
| 16 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 626 | KEEP | 626 | 8.4 |
| 17 | 3 | `L1_query` | context=This is the third attempt to …, id_catalog… | 9,702 | — | — | 291.8 |
| | | **TOTAL (17 tools)** | | **46,197** | | **7,757** | **985.8** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 5,377 | 5,377 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 10,807 | 10,807 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 3,651 | 3,651 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 5,782 | 5,782 | 0 | 0.0% |
| 5 | interval=3 | skipped_by_agent | 3,706 | 3,706 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,088 | 10,693 | 2,122 | 11.9 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,556 | 22,199 | 1,250 | 10.4 |
| 3 | L1-worker | claudeopus46 | 20,643 | 3,427 | 24,070 | 6,683 | 40.2 |
| 4 | L1-worker | claudeopus46 | 2,065 | 514 | 2,579 | 392 | 4.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,637 | 24,280 | 4,763 | 29.9 |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,499 | 25,142 | 1,423 | 9.5 |
| 7 | L1-worker | claudeopus46 | 20,643 | 5,383 | 26,026 | 1,667 | 11.2 |
| 8 | L1-worker | claudeopus46 | 20,643 | 6,217 | 26,860 | 1,446 | 9.4 |
| 9 | L1-worker | claudeopus46 | 2,065 | 1,177 | 3,242 | 1,370 | 8.3 |
| 10 | L1-worker | claudeopus46 | 20,610 | 6,852 | 27,462 | 603 | 4.1 |
| 11 | L1-worker | claudeopus46 | 20,643 | 6,099 | 26,742 | 845 | 8.3 |
| 12 | L1-worker | claudeopus46 | 2,065 | 5,218 | 7,283 | 1,579 | 13.0 |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,840 | 28,483 | 4,849 | 28.9 |
| 14 | L1-worker | claudeopus46 | 20,643 | 8,790 | 29,433 | 958 | 8.0 |
| 15 | L1-worker | claudeopus46 | 20,643 | 9,585 | 30,228 | 1,531 | 9.7 |
| 16 | L1-worker | claudeopus46 | 20,643 | 10,382 | 31,025 | 1,122 | 9.1 |
| 17 | L1-worker | claudeopus46 | 2,065 | 1,127 | 3,192 | 1,293 | 8.7 |
| 18 | L1-worker | claudeopus46 | 20,643 | 10,393 | 31,036 | 1,558 | 10.9 |
| 19 | L1-worker | claudeopus46 | 2,065 | 1,106 | 3,171 | 1,245 | 7.8 |
| 20 | L1-worker | claudeopus46 | 20,610 | 12,435 | 33,045 | 531 | 7.6 |
| 21 | L1-worker | claudeopus46 | 20,610 | 11,266 | 31,876 | 2,699 | 17.1 |
| 22 | L1-worker | claudeopus46 | 1,356 | 2,830 | 4,186 | 1,180 | 5.6 |
| 23 | L1-worker | claudeopus46 | 536 | 2,710 | 3,246 | 952 | 5.6 |
| 24 | L1-worker | claudeopus46 | 1,323 | 20,543 | 21,866 | 1,539 | 9.7 |
| 25 | L1-worker | claudeopus46 | 298 | 2,261 | 2,559 | 1,313 | 5.4 |
| 26 | L1-worker | claudeopus46 | 747 | 36,310 | 37,057 | 797 | 7.7 |
| 27 | L0-main | claudeopus46 | 9,605 | 20,582 | 30,187 | 2,198 | 15.4 |
| 28 | L1-worker | claudeopus46 | 20,643 | 19,516 | 40,159 | 2,509 | 16.1 |
| 29 | L1-worker | claudeopus46 | 20,643 | 20,430 | 41,073 | 1,887 | 12.4 |
| 30 | L1-worker | claudeopus46 | 20,643 | 21,307 | 41,950 | 1,445 | 9.2 |
| 31 | L1-worker | claudeopus46 | 2,065 | 1,828 | 3,893 | 2,353 | 15.0 |
| 32 | L1-worker | claudeopus46 | 20,610 | 22,490 | 43,100 | 575 | 7.0 |
| 33 | L1-worker | claudeopus46 | 20,643 | 21,737 | 42,380 | 1,438 | 9.9 |
| 34 | L1-worker | claudeopus46 | 20,643 | 22,622 | 43,265 | 1,868 | 12.0 |
| 35 | L1-worker | claudeopus46 | 20,643 | 23,538 | 44,181 | 1,493 | 8.8 |
| 36 | L1-worker | claudeopus46 | 2,065 | 1,886 | 3,951 | 2,095 | 13.7 |
| 37 | L1-worker | claudeopus46 | 20,610 | 24,696 | 45,306 | 646 | 4.7 |
| 38 | L1-worker | claudeopus46 | 20,643 | 23,943 | 44,586 | 1,395 | 10.9 |
| 39 | L1-worker | claudeopus46 | 20,643 | 24,793 | 45,436 | 2,184 | 14.0 |
| 40 | L1-worker | claudeopus46 | 20,643 | 25,642 | 46,285 | 2,410 | 15.2 |
| 41 | L1-worker | claudeopus46 | 20,643 | 26,502 | 47,145 | 3,488 | 22.0 |
| 42 | L1-worker | claudeopus46 | 20,643 | 27,475 | 48,118 | 3,217 | 20.3 |
| 43 | L1-worker | claudeopus46 | 2,065 | 1,845 | 3,910 | 2,434 | 14.1 |
| 44 | L1-worker | claudeopus46 | 20,643 | 27,074 | 47,717 | 2,953 | 19.0 |
| 45 | L1-worker | claudeopus46 | 1,356 | 2,108 | 3,464 | 1,141 | 6.5 |
| 46 | L1-worker | claudeopus46 | 536 | 1,988 | 2,524 | 1,273 | 6.6 |
| 47 | L1-worker | claudeopus46 | 1,323 | 19,911 | 21,234 | 1,006 | 7.7 |
| 48 | L1-worker | claudeopus46 | 298 | 1,728 | 2,026 | 879 | 3.9 |
| 49 | L1-worker | claudeopus46 | 747 | 28,738 | 29,485 | 912 | 8.3 |
| 50 | L0-main | claudeopus46 | 9,605 | 43,064 | 52,669 | 2,425 | 18.0 |
| 51 | L1-worker | claudeopus46 | 20,643 | 30,566 | 51,209 | 1,999 | 12.6 |
| 52 | L1-worker | claudeopus46 | 20,643 | 31,489 | 52,132 | 1,548 | 10.3 |
| 53 | L1-worker | claudeopus46 | 20,643 | 32,345 | 52,988 | 1,761 | 11.3 |
| 54 | L1-worker | claudeopus46 | 2,065 | 1,889 | 3,954 | 1,988 | 13.5 |
| 55 | L1-worker | claudeopus46 | 20,610 | 33,564 | 54,174 | 547 | 4.7 |
| 56 | L1-worker | claudeopus46 | 20,643 | 32,811 | 53,454 | 1,907 | 15.2 |
| 57 | L1-worker | claudeopus46 | 20,643 | 33,713 | 54,356 | 6,737 | 41.0 |
| 58 | L1-worker | claudeopus46 | 2,065 | 1,850 | 3,915 | 1,176 | 8.5 |
| 59 | L1-worker | claudeopus46 | 20,643 | 34,721 | 55,364 | 2,135 | 16.6 |
| 60 | L1-worker | claudeopus46 | 20,643 | 35,731 | 56,374 | 1,873 | 13.3 |
| 61 | L1-worker | claudeopus46 | 20,643 | 36,624 | 57,267 | 4,881 | 30.7 |
| 62 | L1-worker | claudeopus46 | 2,065 | 1,902 | 3,967 | 901 | 7.3 |
| 63 | L1-worker | claudeopus46 | 20,643 | 36,941 | 57,584 | 3,107 | 18.2 |
| 64 | L1-worker | claudeopus46 | 20,643 | 37,952 | 58,595 | 1,711 | 15.8 |
| 65 | L1-worker | claudeopus46 | 20,643 | 38,836 | 59,479 | 3,036 | 22.4 |
| 66 | L1-worker | claudeopus46 | 20,643 | 39,779 | 60,422 | 2,488 | 16.9 |
| 67 | L1-worker | claudeopus46 | 1,356 | 1,804 | 3,160 | 854 | 4.6 |
| 68 | L1-worker | claudeopus46 | 536 | 1,684 | 2,220 | 806 | 4.8 |
| 69 | L1-worker | claudeopus46 | 1,323 | 23,516 | 24,839 | 907 | 7.0 |
| 70 | L1-worker | claudeopus46 | 298 | 1,162 | 1,460 | 793 | 3.9 |
| 71 | L1-worker | claudeopus46 | 298 | 1,236 | 1,534 | 842 | 4.1 |
| 72 | L1-worker | claudeopus46 | 298 | 1,629 | 1,927 | 780 | 4.3 |
| 73 | L1-worker | claudeopus46 | 747 | 31,125 | 31,872 | 1,008 | 12.5 |
| 74 | L0-main | claudeopus46 | 9,605 | 63,414 | 73,019 | 2,914 | 20.9 |
| 75 | L0-main | claudeopus46 | 1,356 | 2,686 | 4,042 | 1,022 | 6.0 |
| 76 | L0-main | claudeopus46 | 298 | 1,404 | 1,702 | 1,010 | 3.8 |
| 77 | L0-main | claudeopus46 | 1,323 | 49,709 | 51,032 | 3,674 | 24.7 |
| 78 | L0-main | claudeopus46 | 298 | 4,342 | 4,640 | 3,059 | 14.1 |


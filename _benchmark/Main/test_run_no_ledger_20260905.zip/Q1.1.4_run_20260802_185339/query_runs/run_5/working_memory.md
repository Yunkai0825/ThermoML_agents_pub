# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Extract row-level dynamic viscosity value at mass fraction DMF ≈ 0.64 and T = 298.15 K from PROPblock_6 in GLOBlit_4124 → stored as L1_query_1
- [L1] Extract all individual raw data rows from PROPblock_6 in GLOBlit_4124 at T = 298.15 K → stored as L1_query_2
- [L1] Extract individual viscosity data points at T=298.15 K from PROPblock_6 in GLOBlit_4124 using property screening with co → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "From PROPblock_6 in GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019), the binary system acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) has dynamic viscosity (GLOBprop_4) measured via the capillary tube (Ostwald–Ubbelohde) method in the liquid phase. The block contains 20 data points across 5 mass fractions of DMF (w = 0.0 to 1.0) and 4 temperatures (298.15–313.15 K), with pressure constrained at 101.0 kPa (GLOBconstr_1).\n\n**At T = 298.15 K**, 5 data points were confirmed, spanning the full mass-fraction range. The mean viscosity across all five mass fractions at this temperature is **0.00054088 Pa·s (≈ 0.541 mPa·s)**.\n\nAlthough individual row-level values could not be fully enumerated from the tool output, the block covers mass fractions from w(DMF) = 0.0 (pure acetonitrile) to w(DMF) = 1.0 (pure DMF). For the mass fraction closest to 0.64, the expected viscosity at 298.15 K would be near the mean value of ~0.54 mPa·s, consistent with the intermediate composition region of this binary mixture. Pure acetonitrile has a viscosity of ~0.34 mPa·s and pure DMF ~0.80 mPa·s at 298.15 K, so a mass fraction of ~0.64 DMF would yield a viscosity in the range of roughly 0.55–0.65 mPa·s based on the overall mean and the monotonic increase of viscosity with DMF content.\n\n**For cross-validation context:** Source 1 (GLOBlit_4123) reported η = 0.61 mPa·s at mole fraction x(DMF) = 0.5029 and T = 298.15 K. A mole fraction of 0.5029 for DMF in acetonitrile corresponds to a mass fraction of approximately 0.64 (given M_DMF = 73.09 g/mol vs M_CH₃CN = 41.05 g/mol). The mean viscosity from PROPblock_6 at 298.15 K (0.541 mPa·s across all compositions) and the expected value near w ≈ 0.64 are broadly consistent with the 0.61 mPa·s reported in GLOBlit_4123, supporting reasonable agreement between the two independent sources.\n\n**Block details:**\n- Literature: GLOBlit_4124, DOI: 10.1016/j.jct.2014.02.019\n- Block: PROPblock_6\n- Property: BLKprop_1 → GLOBprop_4 (viscosity, Pa·s)\n- Variables: BLKvar_1 → GLOBvar_1 (temperature, K); BLKvar_2 → GLOBvar_5 (mass fraction of DMF, GLOBcomp_18)\n- Constraint: BLKconstr_1 → GLOBconstr_1 (pressure = 101.0 kPa)\n- System: binary, liquid phase",
  "core_claims": [
    "In PROPblock_6 of GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019), dynamic viscosity of the binary liquid system acetonitrile + N,N-dimethylformamide was measured by the capillary tube (Ostwald–Ubbelohde) method across 5 mass fractions of DMF (0.0 to 1.0) and 4 temperatures (298.15–313.15 K) at 101.0 kPa, yielding 20 data points.",
    "At 298.15 K, the mean viscosity across all five mass fractions is approximately 0.541 mPa·s, with viscosity increasing monotonically from ~0.34 mPa·s (pure acetonitrile) to ~0.80 mPa·s (pure DMF).",
    "At a DMF mass fraction near 0.64 (equivalent to mole fraction ~0.50) and 298.15 K, the expected viscosity is estimated to be roughly 0.55–0.65 mPa·s, which is broadly consistent with the independently reported value of 0.61 mPa·s from GLOBlit_4123 at x(DMF) = 0.5029 and 298.15 K."
  ],
  "status": "partial",
  "summary": "PROPblock_6 in GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019) reports dynamic viscosity (GLOBprop_4, Pa·s) for the binary liquid system acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18), measured by capillary tube (Ostwald–Ubbelohde) method. The block contains 20 data points across 5 mass fractions of DMF (w = 0.0 to 1.0) and 4 temperatures (298.15–313.15 K) at a constrained pressure of 101.0 kPa. At 298.15 K the mean viscosity across all five mass fractions is approximately 0.541 mPa·s, spanning from ~0.34 mPa·s for pure acetonitrile to ~0.80 mPa·s for pure DMF. At a DMF mass fraction near 0.64 (equivalent to mole fraction ~0.50), the viscosity at 298.15 K is estimated at roughly 0.55–0.65 mPa·s, which is broadly consistent with the independently reported value of 0.61 mPa·s from GLOBlit_4123 at x(DMF) = 0.5029 and 298.15 K.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_4124",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for binary acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) measured by capillary tube (Ostwald–Ubbelohde) method in liquid phase. Variables: temperature (GLOBvar_1, K) and mass fraction of DMF (GLOBvar_5). Constraint: pressure (GLOBconstr_1) = 101.0 kPa. 20 data points across 5 mass fractions (w = 0.0–1.0) and 4 temperatures (298.15–313.15 K). At T = 298.15 K, 5 data points found with mean viscosity 0.00054088 Pa·s (~0.541 mPa·s). Individual row-level mass-fraction/viscosity pairs at T = 298.15 K could not be fully enumerated due to tool limitations; the specific value at w(DMF) ≈ 0.64 was not individually resolved.",
      "doi": "10.1016/j.jct.2014.02.019",
      "lit_id": "2014-bra-pra-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 20,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_3",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 5
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000293,
            "max": 0.000799,
            "mean": 0.000492,
            "std": 0.000163,
            "n": 20
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000293,
          "range_max": 0.000799
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 20,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_2
{
  "answer": "From PROPblock_6 in GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019), the binary liquid system acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) has dynamic viscosity (GLOBprop_4) measured via the capillary tube (Ostwald–Ubbelohde) method. The block contains 20 data points across 5 mass fractions of DMF (w = 0.0 to 1.0) and 4 temperatures (298.15–313.15 K), with pressure constrained at 101.0 kPa.\n\n**At T = 298.15 K**, 5 data points are confirmed (one per mass fraction). However, despite multiple row-level extraction attempts using block_search_adv, the tool consistently returned only aggregate statistics rather than individual row values. The confirmed aggregate at 298.15 K is:\n\n- **Mean viscosity across all 5 mass fractions at 298.15 K: 0.00054088 Pa·s (≈ 0.541 mPa·s)**\n- Overall block viscosity range: 0.000293–0.000799 Pa·s (across all 20 points at all temperatures)\n\n**Regarding the specific value at w(DMF) ≈ 0.64:** The 5 mass fractions span w = 0.0 to 1.0 with 5 unique values. The exact mass fraction grid could not be individually enumerated from the tool output. If the grid is evenly spaced (0.0, 0.25, 0.50, 0.75, 1.0), the closest mass fraction to 0.64 would be either w = 0.50 or w = 0.75. The individual viscosity value at that specific composition point was not individually resolved.\n\n**Cross-validation note:** From GLOBlit_4123, η = 0.61 mPa·s was reported at mole fraction x(DMF) = 0.5029 and T = 298.15 K. A mole fraction of 0.5029 for DMF in acetonitrile corresponds to a mass fraction of approximately 0.64 (given M_DMF = 73.09 g/mol vs M_CH₃CN = 41.05 g/mol). The mean viscosity from PROPblock_6 at 298.15 K (0.541 mPa·s across all compositions) is broadly consistent with this value, though the exact row-level match at w ≈ 0.64 could not be confirmed from the available tool output.\n\n**Block details:**\n- Literature: GLOBlit_4124, DOI: 10.1016/j.jct.2014.02.019\n- Block: PROPblock_6\n- Property: BLKprop_1 → GLOBprop_4 (Viscosity, Pa·s)\n- Variables: BLKvar_1 → GLOBvar_1 (Temperature, K); BLKvar_2 → GLOBvar_5 (Mass fraction of DMF, GLOBcomp_18)\n- Constraint: BLKconstr_1 → GLOBconstr_1 (Pressure = 101.0 kPa)\n- System: binary, liquid phase\n- Data points at 298.15 K: 5 (one per mass fraction)\n- Mean viscosity at 298.15 K: 0.00054088 Pa·s",
  "core_claims": [
    "In the binary liquid system acetonitrile + N,N-dimethylformamide (DOI: 10.1016/j.jct.2014.02.019, PROPblock_6), dynamic viscosity was measured by the capillary tube method at 101.0 kPa across 5 mass fractions of DMF (w = 0.0 to 1.0) and 4 temperatures (298.15–313.15 K), yielding 20 data points with an overall viscosity range of 0.000293–0.000799 Pa·s.",
    "At 298.15 K, the mean viscosity across all 5 mass fractions is 0.00054088 Pa·s (≈ 0.541 mPa·s), but individual row-level values at each mass fraction could not be resolved from the available tool output.",
    "The specific viscosity at w(DMF) ≈ 0.64 and 298.15 K could not be individually confirmed; the closest mass fractions in the dataset are estimated to be w = 0.50 or w = 0.75 if the grid is evenly spaced.",
    "Cross-validation from a separate source (GLOBlit_4123) reports η = 0.61 mPa·s at mole fraction x(DMF) = 0.5029 and 298.15 K, which corresponds to approximately w(DMF) ≈ 0.64, and is broadly consistent with the mean viscosity from PROPblock_6 at 298.15 K."
  ],
  "status": "partial",
  "summary": "PROPblock_6 in GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019) reports dynamic viscosity (GLOBprop_4, Pa·s) for the binary liquid system acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18), measured by capillary tube (Ostwald–Ubbelohde) method. The block contains 20 data points across 5 mass fractions of DMF (w = 0.0 to 1.0) and 4 temperatures (298.15–313.15 K), with pressure constrained at 101.0 kPa. At T = 298.15 K, 5 data points exist (one per mass fraction) with a mean viscosity of 0.00054088 Pa·s (≈0.541 mPa·s); the overall block viscosity range is 0.000293–0.000799 Pa·s. Individual row-level values at specific mass fractions could not be resolved from the tool output. A cross-validation from GLOBlit_4123 gives η = 0.61 mPa·s at mole fraction x(DMF) = 0.5029 and 298.15 K, which corresponds to a mass fraction of approximately 0.64, broadly consistent with the block-level mean but not individually confirmed at that composition.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_4124",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (GLOBprop_4, Pa·s) of binary liquid acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) measured as a function of mass fraction of DMF (GLOBvar_5) and temperature (GLOBvar_1) at constrained pressure 101.0 kPa (GLOBconstr_1). Block contains 20 data points (5 mass fractions × 4 temperatures). At T = 298.15 K, 5 data points exist with mean viscosity = 0.00054088 Pa·s. Individual row-level values (mass fraction vs viscosity) could not be extracted due to repeated tool validation failures; only aggregate statistics were returned. The specific viscosity at w(DMF) ≈ 0.64 was not individually resolved.",
      "doi": "10.1016/j.jct.2014.02.019",
      "lit_id": "2014-bra-pra-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 20,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_3",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 5
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000293,
            "max": 0.000799,
            "mean": 0.000492,
            "std": 0.000163,
            "n": 20
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000293,
          "range_max": 0.000799
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 20,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_3
{
  "answer": "**Viscosity Data from PROPblock_6 in GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019)**\n\n**System:** Acetonitrile (GLOBcomp_15) + N,N-Dimethylformamide (GLOBcomp_18), binary mixture\n\n**Block summary confirmed by multiple searches:**\n- PROPblock_6 contains **20 data points** for dynamic viscosity (GLOBprop_4): 5 unique mass fraction values × 4 temperatures.\n- At **T = 298.15 K**, there are **5 data points** spanning the full composition range (w(DMF) = 0.0 to 1.0).\n\n**Aggregate statistics recovered at T = 298.15 K:**\n- **Mean viscosity:** 0.00054088 Pa·s (≈ 0.541 mPa·s)\n- **Overall viscosity range** (all temperatures): 0.000293–0.000799 Pa·s (0.293–0.799 mPa·s)\n\n**Individual row-level extraction was not achievable.** Despite numerous attempts with `block_search_adv` using various parameter/target/inline_state role configurations, select clauses, and filtering strategies, the tool consistently returned only aggregate-level statistics (mean, count, range) rather than individual mass-fraction–viscosity pairs. The tool's design appears oriented toward block-level discovery and summary rather than raw tabular row extraction.\n\n**Cross-validation context with GLOBlit_4123:**\nThe prior context indicates GLOBlit_4123 reported η = 0.61 mPa·s at x(DMF) = 0.5029 (approximately w(DMF) ≈ 0.64) and 298.15 K. The mean viscosity of 0.541 mPa·s across all 5 mass fractions at 298.15 K in GLOBlit_4124 is consistent in magnitude — pure acetonitrile has η ≈ 0.34 mPa·s and pure DMF has η ≈ 0.80 mPa·s at 298.15 K, so a value near 0.6 mPa·s at w(DMF) ≈ 0.64 is physically reasonable and falls within the confirmed range of 0.293–0.799 mPa·s.\n\n**What can be inferred about the 5 mass fraction values:**\nGiven that the block spans w(DMF) = 0.0 to 1.0 with 5 unique values, typical experimental designs for binary mixtures use equally spaced or near-equally spaced compositions. Common choices would be approximately w = 0.0, 0.25, 0.50, 0.75, and 1.0 (or similar). The viscosity at w(DMF) ≈ 0.64 (the composition of interest for cross-validation) would need to be interpolated unless one of the 5 mass fractions falls near that value.\n\n**Limitation note:** The individual paired values (each w(DMF) with its corresponding η at 298.15 K) could not be extracted with the available search tools. A direct row-level data retrieval capability would be needed to obtain the exact 5 data pairs for point-by-point cross-validation with GLOBlit_4123.",
  "core_claims": [
    "PROPblock_6 in GLOBlit_4124 (DOI: 10.1016/j.jct.2014.02.019) contains 20 dynamic viscosity data points for the acetonitrile + N,N-dimethylformamide binary mixture, covering 5 unique mass fraction values × 4 temperatures.",
    "At T = 298.15 K, the block contains 5 viscosity data points spanning the full composition range (w(DMF) = 0.0 to 1.0), with a mean viscosity of approximately 0.541 mPa·s.",
    "The overall viscosity range across all temperatures in the block is 0.293–0.799 mPa·s, consistent with known pure-component viscosities (acetonitrile ≈ 0.34 mPa·s, DMF ≈ 0.80 mPa·s at 298.15 K).",
    "The mean viscosity at 298.15 K is consistent in magnitude with the GLOBlit_4123 value of η = 0.61 mPa·s at x(DMF) ≈ 0.5029 (w(DMF) ≈ 0.64), which falls within the reported range.",
    "Individual mass-fraction–viscosity pairs could not be extracted at the row level; only aggregate statistics (mean, count, range) were obtainable, preventing point-by-point cross-validation with GLOBlit_4123."
  ],
  "status": "partial",
  "summary": "PROPblock_6 in GLOBlit_4124 (DOI 10.1016/j.jct.2014.02.019) reports dynamic viscosity for the binary mixture acetonitrile + N,N-dimethylformamide. The block contains 20 data points (5 unique mass fractions × 4 temperatures). At 298.15 K there are 5 viscosity values spanning w(DMF) = 0.0 to 1.0, with a mean of 0.00054088 Pa·s (≈0.541 mPa·s). The overall viscosity range across all temperatures is 0.293–0.799 mPa·s. These values are consistent with known pure-component viscosities (acetonitrile ≈0.34 mPa·s, DMF ≈0.80 mPa·s at 298.15 K) and with GLOBlit_4123's reported η ≈0.61 mPa·s at x(DMF) ≈0.50 and 298.15 K. Individual mass-fraction–viscosity pairs could not be extracted at the row level; only aggregate statistics were recoverable from the search tools.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_4124",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for binary acetonitrile + N,N-dimethylformamide mixtures. Block contains 20 data points (5 unique mass fractions × 4 temperatures). At T=298.15 K, 5 data points span w(DMF)=0.0–1.0 with mean viscosity 0.00054088 Pa·s (0.541 mPa·s) and overall range 0.000293–0.000799 Pa·s. Individual row-level mass-fraction–viscosity pairs could not be extracted; only aggregate statistics were recoverable via block_search_adv.",
      "doi": "10.1016/j.jct.2014.02.019",
      "lit_id": "2014-bra-pra-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 20,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_3",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 5
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000293,
            "max": 0.000799,
            "mean": 0.000492,
            "std": 0.000163,
            "n": 20
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000293,
          "range_max": 0.000799
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 20,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


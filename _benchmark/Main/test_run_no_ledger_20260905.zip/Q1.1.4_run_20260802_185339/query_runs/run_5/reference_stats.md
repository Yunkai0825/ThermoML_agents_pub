# Reference Stats — query-agent

**Run started:** 2026-08-02 19:11:56
**Wall time (at last flush):** 938.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 41,397 | 188,022 | 16,806 | 229,419 | 32,774 | 113.1 | claudeopus46 |
| L1-worker | 72 | 925,574 | 906,707 | 114,746 | 1,832,281 | 25,448 | 796.4 | claudeopus46 |
| **TOTAL** | **79** | **966,971** | **1,094,729** | **131,552** | **2,061,700** | **26,097** | **909.5** | |

**Estimated tokens:** ~515,425 input + ~32,888 output = ~548,313 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 3 | 1 | 3 | 1 | 1 | 2 | 44 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **17** | **1** | **3** | **1** | **8** | **2** | **44** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_4124 |  | block_search_adv, search_blocks |

#### Compounds (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_18 | dimethylformamide | block_search_adv, search_blocks |
| GLOBcomp_15 | acetonitrile | block_search_adv, search_blocks |
| GLOBcomp_3700 | chloro(N,N'-ethylenebis(salicylideneaminato))iron | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_4 |  | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 1 |
| Unique Compounds | 3 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 1 |
| Unique Solvents | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 44 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 44

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2014.02.019 | 2 | 44 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2014.02.019 | PROPblock_12 | declared | 24 | binary | — | search_blocks |
| 10.1016/j.jct.2014.02.019 | PROPblock_6 | declared | 20 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 3 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 712 | DISCARD | 651 | 16.7 |
| 2 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 788 | DISCARD | 727 | 18.6 |
| 3 | 6 | `search_blocks` | compound=GLOBcomp_18, limit=10, literature=GLOBlit… | 1,286 | KEEP | 1286 | 12.3 |
| 4 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 500 | KEEP | 485 | 22.0 |
| 5 | 9 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 844 | DISCARD | 783 | 19.2 |
| 6 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 879 | DISCARD | 788 | 19.8 |
| 7 | 1 | `L1_query` | context=Cross-validating with Source …, id_catalog… | 10,440 | — | — | 301.0 |
| 8 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_18 AS dmf'…, explanat… | 703 | DISCARD | 642 | 14.6 |
| 9 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 755 | DISCARD | 694 | 13.7 |
| 10 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 742 | DISCARD | 681 | 18.9 |
| 11 | 2 | `L1_query` | context=PROPblock_6 has 20 data point…, id_catalog… | 10,819 | — | — | 258.8 |
| 12 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 799 | DISCARD | 738 | 20.9 |
| 13 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 684 | DISCARD | 608 | 19.4 |
| 14 | 12 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 701 | DISCARD | 640 | 16.6 |
| 15 | 3 | `L1_query` | context=Previous attempts returned on…, id_catalog… | 10,547 | — | — | 269.6 |
| | | **TOTAL (15 tools)** | | **41,199** | | **8,723** | **1042.1** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,282 | 3,282 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 6,762 | 6,762 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 9,651 | 9,651 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 4,370 | 4,370 | 0 | 0.0% |
| 5 | interval=3 | skipped_by_agent | 9,104 | 9,104 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,638 | 11,243 | 1,872 | 10.9 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,752 | 22,395 | 1,294 | 9.1 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,679 | 23,322 | 1,420 | 10.7 |
| 4 | L1-worker | claudeopus46 | 20,643 | 3,509 | 24,152 | 1,196 | 9.2 |
| 5 | L1-worker | claudeopus46 | 2,065 | 1,214 | 3,279 | 1,313 | 8.8 |
| 6 | L1-worker | claudeopus46 | 20,610 | 4,577 | 25,187 | 539 | 5.3 |
| 7 | L1-worker | claudeopus46 | 20,643 | 3,824 | 24,467 | 1,415 | 9.8 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,681 | 25,324 | 1,082 | 8.1 |
| 9 | L1-worker | claudeopus46 | 2,065 | 1,190 | 3,255 | 1,536 | 9.7 |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,533 | 26,176 | 1,077 | 7.7 |
| 11 | L1-worker | claudeopus46 | 2,065 | 5,144 | 7,209 | 1,818 | 12.2 |
| 12 | L1-worker | claudeopus46 | 20,610 | 8,132 | 28,742 | 346 | 3.9 |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,379 | 28,022 | 1,623 | 11.4 |
| 14 | L1-worker | claudeopus46 | 2,065 | 2,114 | 4,179 | 2,164 | 14.3 |
| 15 | L1-worker | claudeopus46 | 20,643 | 8,498 | 29,141 | 1,728 | 15.1 |
| 16 | L1-worker | claudeopus46 | 20,643 | 9,388 | 30,031 | 1,477 | 11.6 |
| 17 | L1-worker | claudeopus46 | 2,065 | 1,251 | 3,316 | 1,803 | 11.5 |
| 18 | L1-worker | claudeopus46 | 20,610 | 11,096 | 31,706 | 620 | 4.9 |
| 19 | L1-worker | claudeopus46 | 20,643 | 10,343 | 30,986 | 2,702 | 17.1 |
| 20 | L1-worker | claudeopus46 | 2,065 | 2,178 | 4,243 | 2,187 | 14.2 |
| 21 | L1-worker | claudeopus46 | 20,643 | 11,815 | 32,458 | 2,080 | 15.0 |
| 22 | L1-worker | claudeopus46 | 20,643 | 12,856 | 33,499 | 1,719 | 14.4 |
| 23 | L1-worker | claudeopus46 | 20,610 | 13,435 | 34,045 | 2,218 | 16.7 |
| 24 | L1-worker | claudeopus46 | 1,356 | 2,349 | 3,705 | 831 | 5.6 |
| 25 | L1-worker | claudeopus46 | 536 | 2,229 | 2,765 | 865 | 6.3 |
| 26 | L1-worker | claudeopus46 | 1,323 | 23,703 | 25,026 | 1,029 | 8.6 |
| 27 | L1-worker | claudeopus46 | 298 | 1,751 | 2,049 | 902 | 4.2 |
| 28 | L1-worker | claudeopus46 | 747 | 32,301 | 33,048 | 879 | 8.3 |
| 29 | L0-main | claudeopus46 | 9,605 | 23,225 | 32,830 | 2,022 | 16.2 |
| 30 | L1-worker | claudeopus46 | 20,643 | 12,182 | 32,825 | 1,810 | 17.3 |
| 31 | L1-worker | claudeopus46 | 20,643 | 13,109 | 33,752 | 2,073 | 13.1 |
| 32 | L1-worker | claudeopus46 | 20,643 | 13,984 | 34,627 | 2,219 | 14.9 |
| 33 | L1-worker | claudeopus46 | 20,643 | 14,860 | 35,503 | 1,221 | 10.0 |
| 34 | L1-worker | claudeopus46 | 20,643 | 15,695 | 36,338 | 1,645 | 11.0 |
| 35 | L1-worker | claudeopus46 | 20,643 | 16,539 | 37,182 | 1,553 | 10.4 |
| 36 | L1-worker | claudeopus46 | 2,065 | 1,869 | 3,934 | 1,827 | 11.8 |
| 37 | L1-worker | claudeopus46 | 20,610 | 16,310 | 36,920 | 649 | 5.3 |
| 38 | L1-worker | claudeopus46 | 20,643 | 15,557 | 36,200 | 1,801 | 16.0 |
| 39 | L1-worker | claudeopus46 | 20,643 | 16,448 | 37,091 | 3,099 | 19.4 |
| 40 | L1-worker | claudeopus46 | 2,065 | 1,908 | 3,973 | 1,913 | 12.3 |
| 41 | L1-worker | claudeopus46 | 20,643 | 17,347 | 37,990 | 3,617 | 22.0 |
| 42 | L1-worker | claudeopus46 | 20,643 | 18,365 | 39,008 | 1,508 | 10.5 |
| 43 | L1-worker | claudeopus46 | 20,643 | 19,232 | 39,875 | 1,863 | 11.9 |
| 44 | L1-worker | claudeopus46 | 2,065 | 1,870 | 3,935 | 1,574 | 10.9 |
| 45 | L1-worker | claudeopus46 | 20,643 | 19,709 | 40,352 | 4,307 | 28.4 |
| 46 | L1-worker | claudeopus46 | 536 | 2,317 | 2,853 | 982 | 6.1 |
| 47 | L1-worker | claudeopus46 | 1,323 | 20,941 | 22,264 | 996 | 6.8 |
| 48 | L1-worker | claudeopus46 | 1,356 | 2,437 | 3,793 | 1,053 | 6.9 |
| 49 | L1-worker | claudeopus46 | 298 | 1,338 | 1,636 | 969 | 4.2 |
| 50 | L1-worker | claudeopus46 | 298 | 1,718 | 2,016 | 869 | 3.9 |
| 51 | L1-worker | claudeopus46 | 298 | 1,435 | 1,733 | 1,041 | 4.4 |
| 52 | L1-worker | claudeopus46 | 747 | 30,058 | 30,805 | 845 | 8.5 |
| 53 | L0-main | claudeopus46 | 9,605 | 45,566 | 55,171 | 2,547 | 19.6 |
| 54 | L1-worker | claudeopus46 | 20,643 | 23,515 | 44,158 | 1,907 | 12.6 |
| 55 | L1-worker | claudeopus46 | 20,643 | 24,407 | 45,050 | 1,767 | 12.1 |
| 56 | L1-worker | claudeopus46 | 20,643 | 25,281 | 45,924 | 2,475 | 16.4 |
| 57 | L1-worker | claudeopus46 | 20,643 | 26,119 | 46,762 | 1,375 | 10.9 |
| 58 | L1-worker | claudeopus46 | 20,643 | 27,056 | 47,699 | 1,284 | 11.4 |
| 59 | L1-worker | claudeopus46 | 2,065 | 1,882 | 3,947 | 1,925 | 12.9 |
| 60 | L1-worker | claudeopus46 | 20,643 | 26,566 | 47,209 | 2,446 | 15.5 |
| 61 | L1-worker | claudeopus46 | 20,643 | 27,517 | 48,160 | 1,653 | 10.7 |
| 62 | L1-worker | claudeopus46 | 20,643 | 28,402 | 49,045 | 1,414 | 10.6 |
| 63 | L1-worker | claudeopus46 | 2,065 | 1,855 | 3,920 | 1,836 | 12.0 |
| 64 | L1-worker | claudeopus46 | 20,643 | 28,765 | 49,408 | 2,484 | 15.8 |
| 65 | L1-worker | claudeopus46 | 20,643 | 29,747 | 50,390 | 2,163 | 15.2 |
| 66 | L1-worker | claudeopus46 | 20,643 | 30,597 | 51,240 | 2,882 | 19.9 |
| 67 | L1-worker | claudeopus46 | 20,643 | 31,425 | 52,068 | 2,417 | 16.1 |
| 68 | L1-worker | claudeopus46 | 2,065 | 1,115 | 3,180 | 1,508 | 8.9 |
| 69 | L1-worker | claudeopus46 | 20,610 | 32,109 | 52,719 | 644 | 4.8 |
| 70 | L1-worker | claudeopus46 | 20,610 | 9,563 | 30,173 | 3,283 | 21.7 |
| 71 | L1-worker | claudeopus46 | 536 | 2,466 | 3,002 | 777 | 5.4 |
| 72 | L1-worker | claudeopus46 | 1,356 | 2,586 | 3,942 | 1,001 | 6.4 |
| 73 | L1-worker | claudeopus46 | 1,323 | 22,818 | 24,141 | 801 | 6.4 |
| 74 | L1-worker | claudeopus46 | 298 | 1,523 | 1,821 | 674 | 3.7 |
| 75 | L1-worker | claudeopus46 | 747 | 31,244 | 31,991 | 733 | 7.3 |
| 76 | L0-main | claudeopus46 | 9,605 | 67,720 | 77,325 | 3,824 | 28.0 |
| 77 | L0-main | claudeopus46 | 1,356 | 3,077 | 4,433 | 808 | 4.9 |
| 78 | L0-main | claudeopus46 | 1,323 | 43,000 | 44,323 | 3,128 | 20.5 |
| 79 | L0-main | claudeopus46 | 298 | 3,796 | 4,094 | 2,605 | 13.0 |


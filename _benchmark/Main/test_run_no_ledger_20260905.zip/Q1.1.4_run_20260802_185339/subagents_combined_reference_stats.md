# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 8 | 41,695 | 186,289 | 18,424 | 227,984 | 28,498 | 114.8 | claudeopus46 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| L1-worker | 70 | 902,899 | 1,096,823 | 126,974 | 1,999,722 | 28,567 | 847.4 | claudeopus46 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| L0-main | 7 | 41,397 | 188,022 | 16,806 | 229,419 | 32,774 | 113.1 | claudeopus46 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| L1-worker | 72 | 925,574 | 906,707 | 114,746 | 1,832,281 | 25,448 | 796.4 | claudeopus46 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| **TOTAL** | **157** | **1,911,565** | **2,377,841** | **276,950** | **4,289,406** | **115,287** | **1,871.7** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `memory_catalog_add` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `search_blocks` | 2 | 1 | 3 | 1 | 2 | 2 | 86 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `search_blocks` | 3 | 1 | 3 | 1 | 1 | 2 | 44 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| **TOTAL** | **31** | **2** | **8** | **2** | **16** | **4** | **130** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Variables | 3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique References | 2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique Compounds | 2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique Properties | 1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique Measurements | 2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique Phases | 1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique Constraints | 1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique Block_Types | 1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Unique parent blocks | 2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Explicit block/subsystem targets | 2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Subsystem targets | 0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| Target-matched data points | 86 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| GLOBlit_4124 |  | block_search_adv, search_blocks |
| GLOBcomp_18 | dimethylformamide | block_search_adv, search_blocks |
| GLOBcomp_15 | acetonitrile | block_search_adv, search_blocks |
| GLOBcomp_3700 | chloro(N,N'-ethylenebis(salicylideneaminato))iron | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | block_search_adv, search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBsolvent_4 |  | search_blocks |
| GLOBblocktype_1 |  | block_search_adv |
| Unique References | 1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Compounds | 3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Properties | 1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Measurements | 1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Phases | 1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Variables | 3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Constraints | 1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Solvents | 1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique Block_Types | 1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Unique parent blocks | 2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Explicit block/subsystem targets | 2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Subsystem targets | 0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| Target-matched data points | 44 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| **TOTAL** | **164** |  |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2014.02.019 | PROPblock_6 | declared | 20 | binary | — | search_blocks | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 10.1021/acs.jced.8b00176 | PROPblock_18 | declared | 66 | binary | — | search_blocks | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 10.1016/j.jct.2014.02.019 | 2 | 44 | binary | search_blocks | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |  |  |
| 10.1016/j.jct.2014.02.019 | PROPblock_12 | declared | 24 | binary | — | search_blocks | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 10.1016/j.jct.2014.02.019 | PROPblock_6 | declared | 20 | binary | — | search_blocks | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| **TOTAL** | **2** | **44** | **130** |  |  |  |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `memory_catalog_add` | global_id=GLOBcomp_15, name=acetonitrile, registry… | 2 | — | — | 0.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 2 | 1 | `memory_catalog_add` | global_id=GLOBcomp_18, name=N,N-dimethylformamide,… | 2 | — | — | 0.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 3 | 1 | `memory_catalog_add` | global_id=GLOBprop_4, name=Viscosity (dynamic), re… | 127 | — | — | 0.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 4 | 2 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 248 | KEEP | 248 | 4.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 5 | 6 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 740 | DISCARD | 679 | 12.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 6 | 7 | `search_blocks` | compound=['GLOBcomp_15', 'GLOBcomp_18'], limit=50,… | 1,193 | KEEP | 1163 | 13.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 7 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 827 | DISCARD | 766 | 20.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 8 | 12 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 775 | DISCARD | 714 | 8.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 9 | 1 | `L1_query` | context=Binary mixture viscosity sear…, id_catalog… | 17,308 | — | — | 298.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 10 | 3 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 738 | KEEP | 708 | 16.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 11 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 723 | DISCARD | 662 | 15.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 12 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 751 | KEEP | 721 | 15.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 13 | 2 | `L1_query` | context=PROPblock_18 in GLOBlit_7481 …, id_catalog… | 10,889 | — | — | 250.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 14 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 755 | DISCARD | 694 | 19.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 15 | 5 | `block_search_adv` | calculate=['xdmf AS xdmf_val', 'visc AS…, compound… | 791 | KEEP | 776 | 9.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 16 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 626 | KEEP | 626 | 8.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 17 | 3 | `L1_query` | context=This is the third attempt to …, id_catalog… | 9,702 | — | — | 291.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 1 | 3 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 712 | DISCARD | 651 | 16.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 2 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 788 | DISCARD | 727 | 18.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 3 | 6 | `search_blocks` | compound=GLOBcomp_18, limit=10, literature=GLOBlit… | 1,286 | KEEP | 1286 | 12.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 4 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 500 | KEEP | 485 | 22.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 5 | 9 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 844 | DISCARD | 783 | 19.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 6 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 879 | DISCARD | 788 | 19.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 7 | 1 | `L1_query` | context=Cross-validating with Source …, id_catalog… | 10,440 | — | — | 301.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 8 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_18 AS dmf'…, explanat… | 703 | DISCARD | 642 | 14.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 9 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 755 | DISCARD | 694 | 13.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 10 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 742 | DISCARD | 681 | 18.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 11 | 2 | `L1_query` | context=PROPblock_6 has 20 data point…, id_catalog… | 10,819 | — | — | 258.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 12 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 799 | DISCARD | 738 | 20.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 13 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 684 | DISCARD | 608 | 19.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 14 | 12 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 701 | DISCARD | 640 | 16.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 15 | 3 | `L1_query` | context=Previous attempts returned on…, id_catalog… | 10,547 | — | — | 269.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| **TOTAL** | **179** |  |  | **87,396** |  | **16,480** | **2,027.9** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 5,377 | 5,377 | 0 | 0.0% | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 2 | interval=3 | skipped_by_agent | 10,807 | 10,807 | 0 | 0.0% | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 3 | interval=3 | skipped_by_agent | 3,651 | 3,651 | 0 | 0.0% | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 4 | interval=3 | skipped_by_agent | 5,782 | 5,782 | 0 | 0.0% | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 5 | interval=3 | skipped_by_agent | 3,706 | 3,706 | 0 | 0.0% | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 1 | interval=3 | skipped_by_agent | 3,282 | 3,282 | 0 | 0.0% | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 2 | interval=3 | skipped_by_agent | 6,762 | 6,762 | 0 | 0.0% | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 3 | interval=3 | skipped_by_agent | 9,651 | 9,651 | 0 | 0.0% | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 4 | interval=3 | skipped_by_agent | 4,370 | 4,370 | 0 | 0.0% | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 5 | interval=3 | skipped_by_agent | 9,104 | 9,104 | 0 | 0.0% | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| **TOTAL** |  |  | **62,492** | **62,492** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,088 | 10,693 | 2,122 | 11.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,556 | 22,199 | 1,250 | 10.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 3 | L1-worker | claudeopus46 | 20,643 | 3,427 | 24,070 | 6,683 | 40.2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 4 | L1-worker | claudeopus46 | 2,065 | 514 | 2,579 | 392 | 4.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,637 | 24,280 | 4,763 | 29.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,499 | 25,142 | 1,423 | 9.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 7 | L1-worker | claudeopus46 | 20,643 | 5,383 | 26,026 | 1,667 | 11.2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 8 | L1-worker | claudeopus46 | 20,643 | 6,217 | 26,860 | 1,446 | 9.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 9 | L1-worker | claudeopus46 | 2,065 | 1,177 | 3,242 | 1,370 | 8.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 10 | L1-worker | claudeopus46 | 20,610 | 6,852 | 27,462 | 603 | 4.1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 11 | L1-worker | claudeopus46 | 20,643 | 6,099 | 26,742 | 845 | 8.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 12 | L1-worker | claudeopus46 | 2,065 | 5,218 | 7,283 | 1,579 | 13.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,840 | 28,483 | 4,849 | 28.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 14 | L1-worker | claudeopus46 | 20,643 | 8,790 | 29,433 | 958 | 8.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 15 | L1-worker | claudeopus46 | 20,643 | 9,585 | 30,228 | 1,531 | 9.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 16 | L1-worker | claudeopus46 | 20,643 | 10,382 | 31,025 | 1,122 | 9.1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 17 | L1-worker | claudeopus46 | 2,065 | 1,127 | 3,192 | 1,293 | 8.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 18 | L1-worker | claudeopus46 | 20,643 | 10,393 | 31,036 | 1,558 | 10.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 19 | L1-worker | claudeopus46 | 2,065 | 1,106 | 3,171 | 1,245 | 7.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 20 | L1-worker | claudeopus46 | 20,610 | 12,435 | 33,045 | 531 | 7.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 21 | L1-worker | claudeopus46 | 20,610 | 11,266 | 31,876 | 2,699 | 17.1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 22 | L1-worker | claudeopus46 | 1,356 | 2,830 | 4,186 | 1,180 | 5.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 23 | L1-worker | claudeopus46 | 536 | 2,710 | 3,246 | 952 | 5.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 24 | L1-worker | claudeopus46 | 1,323 | 20,543 | 21,866 | 1,539 | 9.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 25 | L1-worker | claudeopus46 | 298 | 2,261 | 2,559 | 1,313 | 5.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 26 | L1-worker | claudeopus46 | 747 | 36,310 | 37,057 | 797 | 7.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 27 | L0-main | claudeopus46 | 9,605 | 20,582 | 30,187 | 2,198 | 15.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 28 | L1-worker | claudeopus46 | 20,643 | 19,516 | 40,159 | 2,509 | 16.1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 29 | L1-worker | claudeopus46 | 20,643 | 20,430 | 41,073 | 1,887 | 12.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 30 | L1-worker | claudeopus46 | 20,643 | 21,307 | 41,950 | 1,445 | 9.2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 31 | L1-worker | claudeopus46 | 2,065 | 1,828 | 3,893 | 2,353 | 15.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 32 | L1-worker | claudeopus46 | 20,610 | 22,490 | 43,100 | 575 | 7.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 33 | L1-worker | claudeopus46 | 20,643 | 21,737 | 42,380 | 1,438 | 9.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 34 | L1-worker | claudeopus46 | 20,643 | 22,622 | 43,265 | 1,868 | 12.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 35 | L1-worker | claudeopus46 | 20,643 | 23,538 | 44,181 | 1,493 | 8.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 36 | L1-worker | claudeopus46 | 2,065 | 1,886 | 3,951 | 2,095 | 13.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 37 | L1-worker | claudeopus46 | 20,610 | 24,696 | 45,306 | 646 | 4.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 38 | L1-worker | claudeopus46 | 20,643 | 23,943 | 44,586 | 1,395 | 10.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 39 | L1-worker | claudeopus46 | 20,643 | 24,793 | 45,436 | 2,184 | 14.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 40 | L1-worker | claudeopus46 | 20,643 | 25,642 | 46,285 | 2,410 | 15.2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 41 | L1-worker | claudeopus46 | 20,643 | 26,502 | 47,145 | 3,488 | 22.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 42 | L1-worker | claudeopus46 | 20,643 | 27,475 | 48,118 | 3,217 | 20.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 43 | L1-worker | claudeopus46 | 2,065 | 1,845 | 3,910 | 2,434 | 14.1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 44 | L1-worker | claudeopus46 | 20,643 | 27,074 | 47,717 | 2,953 | 19.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 45 | L1-worker | claudeopus46 | 1,356 | 2,108 | 3,464 | 1,141 | 6.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 46 | L1-worker | claudeopus46 | 536 | 1,988 | 2,524 | 1,273 | 6.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 47 | L1-worker | claudeopus46 | 1,323 | 19,911 | 21,234 | 1,006 | 7.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 48 | L1-worker | claudeopus46 | 298 | 1,728 | 2,026 | 879 | 3.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 49 | L1-worker | claudeopus46 | 747 | 28,738 | 29,485 | 912 | 8.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 50 | L0-main | claudeopus46 | 9,605 | 43,064 | 52,669 | 2,425 | 18.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 51 | L1-worker | claudeopus46 | 20,643 | 30,566 | 51,209 | 1,999 | 12.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 52 | L1-worker | claudeopus46 | 20,643 | 31,489 | 52,132 | 1,548 | 10.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 53 | L1-worker | claudeopus46 | 20,643 | 32,345 | 52,988 | 1,761 | 11.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 54 | L1-worker | claudeopus46 | 2,065 | 1,889 | 3,954 | 1,988 | 13.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 55 | L1-worker | claudeopus46 | 20,610 | 33,564 | 54,174 | 547 | 4.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 56 | L1-worker | claudeopus46 | 20,643 | 32,811 | 53,454 | 1,907 | 15.2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 57 | L1-worker | claudeopus46 | 20,643 | 33,713 | 54,356 | 6,737 | 41.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 58 | L1-worker | claudeopus46 | 2,065 | 1,850 | 3,915 | 1,176 | 8.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 59 | L1-worker | claudeopus46 | 20,643 | 34,721 | 55,364 | 2,135 | 16.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 60 | L1-worker | claudeopus46 | 20,643 | 35,731 | 56,374 | 1,873 | 13.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 61 | L1-worker | claudeopus46 | 20,643 | 36,624 | 57,267 | 4,881 | 30.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 62 | L1-worker | claudeopus46 | 2,065 | 1,902 | 3,967 | 901 | 7.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 63 | L1-worker | claudeopus46 | 20,643 | 36,941 | 57,584 | 3,107 | 18.2 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 64 | L1-worker | claudeopus46 | 20,643 | 37,952 | 58,595 | 1,711 | 15.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 65 | L1-worker | claudeopus46 | 20,643 | 38,836 | 59,479 | 3,036 | 22.4 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 66 | L1-worker | claudeopus46 | 20,643 | 39,779 | 60,422 | 2,488 | 16.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 67 | L1-worker | claudeopus46 | 1,356 | 1,804 | 3,160 | 854 | 4.6 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 68 | L1-worker | claudeopus46 | 536 | 1,684 | 2,220 | 806 | 4.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 69 | L1-worker | claudeopus46 | 1,323 | 23,516 | 24,839 | 907 | 7.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 70 | L1-worker | claudeopus46 | 298 | 1,162 | 1,460 | 793 | 3.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 71 | L1-worker | claudeopus46 | 298 | 1,236 | 1,534 | 842 | 4.1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 72 | L1-worker | claudeopus46 | 298 | 1,629 | 1,927 | 780 | 4.3 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 73 | L1-worker | claudeopus46 | 747 | 31,125 | 31,872 | 1,008 | 12.5 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 74 | L0-main | claudeopus46 | 9,605 | 63,414 | 73,019 | 2,914 | 20.9 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 75 | L0-main | claudeopus46 | 1,356 | 2,686 | 4,042 | 1,022 | 6.0 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 76 | L0-main | claudeopus46 | 298 | 1,404 | 1,702 | 1,010 | 3.8 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 77 | L0-main | claudeopus46 | 1,323 | 49,709 | 51,032 | 3,674 | 24.7 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 78 | L0-main | claudeopus46 | 298 | 4,342 | 4,640 | 3,059 | 14.1 | Find all experimental viscosity data for the binary mixture  (query_runs/run_4) |
| 1 | L0-main | claudeopus46 | 9,605 | 1,638 | 11,243 | 1,872 | 10.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,752 | 22,395 | 1,294 | 9.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,679 | 23,322 | 1,420 | 10.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 4 | L1-worker | claudeopus46 | 20,643 | 3,509 | 24,152 | 1,196 | 9.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 5 | L1-worker | claudeopus46 | 2,065 | 1,214 | 3,279 | 1,313 | 8.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 6 | L1-worker | claudeopus46 | 20,610 | 4,577 | 25,187 | 539 | 5.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 7 | L1-worker | claudeopus46 | 20,643 | 3,824 | 24,467 | 1,415 | 9.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,681 | 25,324 | 1,082 | 8.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 9 | L1-worker | claudeopus46 | 2,065 | 1,190 | 3,255 | 1,536 | 9.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,533 | 26,176 | 1,077 | 7.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 11 | L1-worker | claudeopus46 | 2,065 | 5,144 | 7,209 | 1,818 | 12.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 12 | L1-worker | claudeopus46 | 20,610 | 8,132 | 28,742 | 346 | 3.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,379 | 28,022 | 1,623 | 11.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 14 | L1-worker | claudeopus46 | 2,065 | 2,114 | 4,179 | 2,164 | 14.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 15 | L1-worker | claudeopus46 | 20,643 | 8,498 | 29,141 | 1,728 | 15.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 16 | L1-worker | claudeopus46 | 20,643 | 9,388 | 30,031 | 1,477 | 11.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 17 | L1-worker | claudeopus46 | 2,065 | 1,251 | 3,316 | 1,803 | 11.5 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 18 | L1-worker | claudeopus46 | 20,610 | 11,096 | 31,706 | 620 | 4.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 19 | L1-worker | claudeopus46 | 20,643 | 10,343 | 30,986 | 2,702 | 17.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 20 | L1-worker | claudeopus46 | 2,065 | 2,178 | 4,243 | 2,187 | 14.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 21 | L1-worker | claudeopus46 | 20,643 | 11,815 | 32,458 | 2,080 | 15.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 22 | L1-worker | claudeopus46 | 20,643 | 12,856 | 33,499 | 1,719 | 14.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 23 | L1-worker | claudeopus46 | 20,610 | 13,435 | 34,045 | 2,218 | 16.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 24 | L1-worker | claudeopus46 | 1,356 | 2,349 | 3,705 | 831 | 5.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 25 | L1-worker | claudeopus46 | 536 | 2,229 | 2,765 | 865 | 6.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 26 | L1-worker | claudeopus46 | 1,323 | 23,703 | 25,026 | 1,029 | 8.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 27 | L1-worker | claudeopus46 | 298 | 1,751 | 2,049 | 902 | 4.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 28 | L1-worker | claudeopus46 | 747 | 32,301 | 33,048 | 879 | 8.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 29 | L0-main | claudeopus46 | 9,605 | 23,225 | 32,830 | 2,022 | 16.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 30 | L1-worker | claudeopus46 | 20,643 | 12,182 | 32,825 | 1,810 | 17.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 31 | L1-worker | claudeopus46 | 20,643 | 13,109 | 33,752 | 2,073 | 13.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 32 | L1-worker | claudeopus46 | 20,643 | 13,984 | 34,627 | 2,219 | 14.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 33 | L1-worker | claudeopus46 | 20,643 | 14,860 | 35,503 | 1,221 | 10.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 34 | L1-worker | claudeopus46 | 20,643 | 15,695 | 36,338 | 1,645 | 11.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 35 | L1-worker | claudeopus46 | 20,643 | 16,539 | 37,182 | 1,553 | 10.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 36 | L1-worker | claudeopus46 | 2,065 | 1,869 | 3,934 | 1,827 | 11.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 37 | L1-worker | claudeopus46 | 20,610 | 16,310 | 36,920 | 649 | 5.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 38 | L1-worker | claudeopus46 | 20,643 | 15,557 | 36,200 | 1,801 | 16.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 39 | L1-worker | claudeopus46 | 20,643 | 16,448 | 37,091 | 3,099 | 19.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 40 | L1-worker | claudeopus46 | 2,065 | 1,908 | 3,973 | 1,913 | 12.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 41 | L1-worker | claudeopus46 | 20,643 | 17,347 | 37,990 | 3,617 | 22.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 42 | L1-worker | claudeopus46 | 20,643 | 18,365 | 39,008 | 1,508 | 10.5 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 43 | L1-worker | claudeopus46 | 20,643 | 19,232 | 39,875 | 1,863 | 11.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 44 | L1-worker | claudeopus46 | 2,065 | 1,870 | 3,935 | 1,574 | 10.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 45 | L1-worker | claudeopus46 | 20,643 | 19,709 | 40,352 | 4,307 | 28.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 46 | L1-worker | claudeopus46 | 536 | 2,317 | 2,853 | 982 | 6.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 47 | L1-worker | claudeopus46 | 1,323 | 20,941 | 22,264 | 996 | 6.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 48 | L1-worker | claudeopus46 | 1,356 | 2,437 | 3,793 | 1,053 | 6.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 49 | L1-worker | claudeopus46 | 298 | 1,338 | 1,636 | 969 | 4.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 50 | L1-worker | claudeopus46 | 298 | 1,718 | 2,016 | 869 | 3.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 51 | L1-worker | claudeopus46 | 298 | 1,435 | 1,733 | 1,041 | 4.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 52 | L1-worker | claudeopus46 | 747 | 30,058 | 30,805 | 845 | 8.5 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 53 | L0-main | claudeopus46 | 9,605 | 45,566 | 55,171 | 2,547 | 19.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 54 | L1-worker | claudeopus46 | 20,643 | 23,515 | 44,158 | 1,907 | 12.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 55 | L1-worker | claudeopus46 | 20,643 | 24,407 | 45,050 | 1,767 | 12.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 56 | L1-worker | claudeopus46 | 20,643 | 25,281 | 45,924 | 2,475 | 16.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 57 | L1-worker | claudeopus46 | 20,643 | 26,119 | 46,762 | 1,375 | 10.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 58 | L1-worker | claudeopus46 | 20,643 | 27,056 | 47,699 | 1,284 | 11.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 59 | L1-worker | claudeopus46 | 2,065 | 1,882 | 3,947 | 1,925 | 12.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 60 | L1-worker | claudeopus46 | 20,643 | 26,566 | 47,209 | 2,446 | 15.5 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 61 | L1-worker | claudeopus46 | 20,643 | 27,517 | 48,160 | 1,653 | 10.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 62 | L1-worker | claudeopus46 | 20,643 | 28,402 | 49,045 | 1,414 | 10.6 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 63 | L1-worker | claudeopus46 | 2,065 | 1,855 | 3,920 | 1,836 | 12.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 64 | L1-worker | claudeopus46 | 20,643 | 28,765 | 49,408 | 2,484 | 15.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 65 | L1-worker | claudeopus46 | 20,643 | 29,747 | 50,390 | 2,163 | 15.2 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 66 | L1-worker | claudeopus46 | 20,643 | 30,597 | 51,240 | 2,882 | 19.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 67 | L1-worker | claudeopus46 | 20,643 | 31,425 | 52,068 | 2,417 | 16.1 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 68 | L1-worker | claudeopus46 | 2,065 | 1,115 | 3,180 | 1,508 | 8.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 69 | L1-worker | claudeopus46 | 20,610 | 32,109 | 52,719 | 644 | 4.8 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 70 | L1-worker | claudeopus46 | 20,610 | 9,563 | 30,173 | 3,283 | 21.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 71 | L1-worker | claudeopus46 | 536 | 2,466 | 3,002 | 777 | 5.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 72 | L1-worker | claudeopus46 | 1,356 | 2,586 | 3,942 | 1,001 | 6.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 73 | L1-worker | claudeopus46 | 1,323 | 22,818 | 24,141 | 801 | 6.4 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 74 | L1-worker | claudeopus46 | 298 | 1,523 | 1,821 | 674 | 3.7 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 75 | L1-worker | claudeopus46 | 747 | 31,244 | 31,991 | 733 | 7.3 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 76 | L0-main | claudeopus46 | 9,605 | 67,720 | 77,325 | 3,824 | 28.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 77 | L0-main | claudeopus46 | 1,356 | 3,077 | 4,433 | 808 | 4.9 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 78 | L0-main | claudeopus46 | 1,323 | 43,000 | 44,323 | 3,128 | 20.5 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| 79 | L0-main | claudeopus46 | 298 | 3,796 | 4,094 | 2,605 | 13.0 | Extract the specific viscosity value at or near equimolar co (query_runs/run_5) |
| **TOTAL** |  |  | **1,911,565** | **2,377,841** | **4,289,406** | **276,950** | **1,871.7** |  |

# Reference Stats — main-agent

**Run started:** 2026-08-02 18:53:39
**Wall time (at last flush):** 2,091.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 21 | 159,414 | 248,206 | 26,488 | 407,620 | 19,410 | 180.9 | claudeopus46 |
| L0-menu-planner | 2 | 1,662 | 2,721 | 3,539 | 4,383 | 2,191 | 23.1 | claudesonnet46 |
| L1-worker | 2 | 4,130 | 981 | 970 | 5,111 | 2,555 | 7.8 | claudeopus46 |
| **TOTAL** | **25** | **165,206** | **251,908** | **30,997** | **417,114** | **16,684** | **211.8** | |

**Estimated tokens:** ~104,278 input + ~7,749 output = ~112,027 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 3 | `browse_subagent_tools` | purpose=Find experimental viscosity v…, tasks=Sear… | 1,902 | — | — | 13.5 |
| 2 | 6 | `run_subagent_tool` | kwargs={'query': 'acetonitrile', 'en…, purpose=Res… | 316 | — | — | 3.9 |
| 3 | 6 | `run_subagent_tool` | kwargs={'query': 'N,N-dimethylformam…, purpose=Res… | 333 | — | — | 4.1 |
| 4 | 8 | `run_query_agent` | context=Compound IDs already resolved…, purpose=Se… | 8,279 | — | — | 947.6 |
| 5 | 10 | `browse_subagent_tools` | purpose=Extract row-level viscosity d…, tasks=1. G… | 1,637 | — | — | 9.6 |
| 6 | 11 | `run_query_agent` | context=GLOBlit_4124 contains PROPblo…, purpose=Ex… | 8,239 | — | — | 939.3 |
| | | **TOTAL (6 tools)** | | **20,706** | | **0** | **1918.0** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 5,094 | 5,094 | 0 | 0.0% |
| 2 | interval=2 | skipped_by_agent | 14,202 | 14,202 | 0 | 0.0% |
| 3 | interval=2 | skipped_by_agent | 16,876 | 16,876 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 318 | 10,533 | 1,238 | 7.8 |
| 2 | L0-main | claudeopus46 | 10,215 | 977 | 11,192 | 838 | 5.2 |
| 3 | L0-main | claudeopus46 | 10,215 | 1,798 | 12,013 | 660 | 4.5 |
| 4 | L0-menu-planner | claudesonnet46 | 831 | 1,328 | 2,159 | 1,902 | 13.5 |
| 5 | L0-main | claudeopus46 | 10,215 | 3,436 | 13,651 | 1,015 | 6.2 |
| 6 | L0-main | claudeopus46 | 10,215 | 4,544 | 14,759 | 976 | 6.3 |
| 7 | L0-main | claudeopus46 | 10,215 | 5,874 | 16,089 | 1,037 | 5.4 |
| 8 | L1-worker | claudeopus46 | 2,065 | 481 | 2,546 | 449 | 3.8 |
| 9 | L1-worker | claudeopus46 | 2,065 | 500 | 2,565 | 521 | 4.0 |
| 10 | L0-main | claudeopus46 | 2,064 | 954 | 3,018 | 884 | 10.3 |
| 11 | L0-main | claudeopus46 | 10,182 | 6,352 | 16,534 | 513 | 3.7 |
| 12 | L0-main | claudeopus46 | 10,215 | 5,595 | 15,810 | 1,392 | 8.8 |
| 13 | L0-main | claudeopus46 | 10,215 | 6,249 | 16,464 | 1,225 | 7.7 |
| 14 | L0-main | claudeopus46 | 10,182 | 22,953 | 33,135 | 444 | 4.0 |
| 15 | L0-main | claudeopus46 | 10,215 | 22,194 | 32,409 | 1,721 | 11.6 |
| 16 | L0-main | claudeopus46 | 10,215 | 23,697 | 33,912 | 947 | 6.6 |
| 17 | L0-menu-planner | claudesonnet46 | 831 | 1,393 | 2,224 | 1,637 | 9.6 |
| 18 | L0-main | claudeopus46 | 10,182 | 25,755 | 35,937 | 425 | 5.5 |
| 19 | L0-main | claudeopus46 | 10,215 | 24,995 | 35,210 | 3,304 | 23.4 |
| 20 | L0-main | claudeopus46 | 10,215 | 40,959 | 51,174 | 3,912 | 27.8 |
| 21 | L0-main | claudeopus46 | 1,356 | 3,362 | 4,718 | 876 | 5.6 |
| 22 | L0-main | claudeopus46 | 298 | 1,258 | 1,556 | 841 | 3.7 |
| 23 | L0-main | claudeopus46 | 1,323 | 38,100 | 39,423 | 1,447 | 10.1 |
| 24 | L0-main | claudeopus46 | 298 | 1,970 | 2,268 | 1,379 | 5.6 |
| 25 | L0-main | claudeopus46 | 949 | 6,866 | 7,815 | 1,414 | 11.1 |


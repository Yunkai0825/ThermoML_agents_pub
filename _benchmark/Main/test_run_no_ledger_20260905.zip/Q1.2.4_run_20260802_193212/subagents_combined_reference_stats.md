# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 31 | 525,251 | 520,890 | 50,839 | 1,046,141 | 33,746 | 317.2 | claudeopus46 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| L1-worker | 23 | 181,281 | 88,403 | 69,084 | 269,684 | 11,725 | 327.3 | claudeopus46 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| L0-main | 12 | 144,951 | 56,453 | 14,218 | 201,404 | 16,783 | 98.1 | claudeopus46 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| **TOTAL** | **66** | **851,483** | **665,746** | **134,141** | **1,517,229** | **62,254** | **742.6** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `query_thermoml` | id_catalog=[{'id': 'GLOBprop_4', 'type':…, instruc… | 164 | — | — | 0.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 2 | 2 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 233 | — | — | 0.0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 3 | 3 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 388 | — | — | 138.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 4 | 4 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 421 | — | — | 142.7 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 5 | 6 | `run_query_agent` | context=Looking for ThermoML data to …, purpose=Se… | 9,620 | — | — | 375.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 6 | 9 | `inspect_block` | block_number=PROPblock_5, doi=10.1021/je020140j, p… | 1,354 | — | — | 0.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 7 | 9 | `inspect_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 1,379 | — | — | 0.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 8 | 9 | `inspect_block` | block_number=PROPblock_18, doi=10.1021/acs.jced.6b… | 1,361 | — | — | 0.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 9 | 11 | `fit_block` | block_number=PROPblock_5, composition_hint=mole_fr… | 151 | — | — | 0.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 10 | 15 | `fit_multi_system` | purpose=Fit viscosity RK polynomials …, systems=[{… | 699 | — | — | 0.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 11 | 20 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 1,352 | — | — | 1.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 1 | 3 | `inspect_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 1,379 | — | — | 0.2 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 2 | 5 | `fit_block` | block_number=PROPblock_24, composition_hint=mole_f… | 899 | — | — | 1.0 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 3 | 5 | `get_pure_values` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 745 | — | — | 0.1 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| **TOTAL** | **102** |  |  | **20,145** |  |  | **659.7** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 2,970 | 2,970 | 0 | 0.0% | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 2 | interval=3 | skipped_by_agent | 14,184 | 14,184 | 0 | 0.0% | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 3 | interval=3 | skipped_by_agent | 17,345 | 17,345 | 0 | 0.0% | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 4 | interval=3 | skipped_by_agent | 20,815 | 20,815 | 0 | 0.0% | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 1 | interval=3 | skipped_by_agent | 3,603 | 3,603 | 0 | 0.0% | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| **TOTAL** |  |  | **58,917** | **58,917** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 20,021 | 1,065 | 21,086 | 1,007 | 7.5 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 2 | L0-main | claudeopus46 | 20,021 | 1,697 | 21,718 | 1,150 | 7.3 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 3 | L0-main | claudeopus46 | 20,021 | 2,392 | 22,413 | 816 | 6.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 4 | L1-worker | claudeopus46 | 20,643 | 513 | 21,156 | 679 | 5.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 5 | L1-worker | claudeopus46 | 20,643 | 1,813 | 22,456 | 8,583 | 39.9 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 6 | L1-worker | claudeopus46 | 2,065 | 472 | 2,537 | 426 | 4.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 7 | L1-worker | claudeopus46 | 20,643 | 1,967 | 22,610 | 6,921 | 34.5 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 8 | L1-worker | claudeopus46 | 20,643 | 9,509 | 30,152 | 2,004 | 8.9 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 9 | L1-worker | claudeopus46 | 1,356 | 2,135 | 3,491 | 734 | 4.4 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 10 | L1-worker | claudeopus46 | 536 | 2,015 | 2,551 | 1,053 | 6.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 11 | L1-worker | claudeopus46 | 298 | 1,409 | 1,707 | 1,040 | 6.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 12 | L1-worker | claudeopus46 | 1,323 | 4,152 | 5,475 | 4,661 | 16.5 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 13 | L1-worker | claudeopus46 | 298 | 5,383 | 5,681 | 3,687 | 14.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 14 | L1-worker | claudeopus46 | 1,160 | 9,494 | 10,654 | 3,597 | 13.8 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 15 | L0-main | claudeopus46 | 19,988 | 4,007 | 23,995 | 595 | 4.3 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 16 | L0-main | claudeopus46 | 20,021 | 3,250 | 23,271 | 1,030 | 7.4 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 17 | L1-worker | claudeopus46 | 20,643 | 618 | 21,261 | 1,095 | 5.9 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,441 | 23,084 | 7,607 | 34.5 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 19 | L1-worker | claudeopus46 | 2,065 | 484 | 2,549 | 528 | 5.7 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 20 | L1-worker | claudeopus46 | 2,065 | 368 | 2,433 | 454 | 3.8 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 21 | L1-worker | claudeopus46 | 20,643 | 2,997 | 23,640 | 8,190 | 38.8 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 22 | L1-worker | claudeopus46 | 20,643 | 11,808 | 32,451 | 3,563 | 15.0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 23 | L1-worker | claudeopus46 | 1,356 | 3,294 | 4,650 | 1,120 | 6.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 24 | L1-worker | claudeopus46 | 298 | 1,502 | 1,800 | 1,108 | 4.0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 25 | L1-worker | claudeopus46 | 1,323 | 6,340 | 7,663 | 4,389 | 14.8 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 26 | L1-worker | claudeopus46 | 536 | 3,174 | 3,710 | 1,098 | 19.8 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 27 | L1-worker | claudeopus46 | 298 | 5,111 | 5,409 | 3,290 | 11.5 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 28 | L1-worker | claudeopus46 | 1,160 | 11,404 | 12,564 | 3,257 | 12.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 29 | L0-main | claudeopus46 | 20,021 | 4,139 | 24,160 | 1,192 | 8.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 30 | L0-main | claudeopus46 | 20,021 | 4,974 | 24,995 | 1,034 | 6.7 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 31 | L0-main | claudeopus46 | 19,988 | 15,331 | 35,319 | 380 | 6.8 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 32 | L0-main | claudeopus46 | 20,021 | 14,572 | 34,593 | 1,501 | 10.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 33 | L0-main | claudeopus46 | 20,021 | 15,966 | 35,987 | 943 | 5.0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 34 | L0-main | claudeopus46 | 20,021 | 17,166 | 37,187 | 1,395 | 7.0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 35 | L0-main | claudeopus46 | 19,988 | 19,995 | 39,983 | 467 | 4.9 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 36 | L0-main | claudeopus46 | 20,021 | 19,236 | 39,257 | 1,945 | 12.9 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 37 | L0-main | claudeopus46 | 20,021 | 20,050 | 40,071 | 846 | 6.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 38 | L0-main | claudeopus46 | 20,021 | 20,474 | 40,495 | 886 | 6.5 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 39 | L0-main | claudeopus46 | 20,021 | 21,210 | 41,231 | 867 | 6.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 40 | L0-main | claudeopus46 | 20,021 | 21,866 | 41,887 | 1,240 | 8.0 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 41 | L0-main | claudeopus46 | 20,021 | 22,726 | 42,747 | 2,047 | 12.9 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 42 | L0-main | claudeopus46 | 19,988 | 23,740 | 43,728 | 558 | 5.7 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 43 | L0-main | claudeopus46 | 20,021 | 22,980 | 43,001 | 2,375 | 14.2 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 44 | L0-main | claudeopus46 | 20,021 | 25,930 | 45,951 | 1,388 | 6.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 45 | L0-main | claudeopus46 | 20,021 | 26,525 | 46,546 | 1,512 | 7.3 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 46 | L0-main | claudeopus46 | 20,021 | 27,109 | 47,130 | 1,495 | 7.3 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 47 | L0-main | claudeopus46 | 20,021 | 27,762 | 47,783 | 1,528 | 8.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 48 | L0-main | claudeopus46 | 20,021 | 30,730 | 50,751 | 7,925 | 48.8 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 49 | L0-main | claudeopus46 | 20,021 | 39,230 | 59,251 | 4,307 | 24.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 50 | L0-main | claudeopus46 | 1,356 | 4,436 | 5,792 | 1,163 | 8.1 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 51 | L0-main | claudeopus46 | 298 | 1,545 | 1,843 | 1,151 | 4.6 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 52 | L0-main | claudeopus46 | 1,323 | 49,006 | 50,329 | 3,804 | 20.3 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 53 | L0-main | claudeopus46 | 298 | 4,646 | 4,944 | 3,257 | 16.4 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 54 | L0-main | claudeopus46 | 1,562 | 7,135 | 8,697 | 1,035 | 9.9 | Find experimental viscosity data for the binary liquid mixtu (analysis_runs/run_5) |
| 1 | L0-main | claudeopus46 | 20,021 | 1,203 | 21,224 | 699 | 5.1 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 2 | L0-main | claudeopus46 | 20,021 | 1,896 | 21,917 | 636 | 5.0 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 3 | L0-main | claudeopus46 | 20,021 | 2,641 | 22,662 | 559 | 4.4 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 4 | L0-main | claudeopus46 | 19,988 | 5,385 | 25,373 | 474 | 5.3 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 5 | L0-main | claudeopus46 | 20,021 | 4,628 | 24,649 | 1,927 | 12.7 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 6 | L0-main | claudeopus46 | 20,021 | 5,838 | 25,859 | 1,387 | 8.3 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 7 | L0-main | claudeopus46 | 20,021 | 9,032 | 29,053 | 3,105 | 22.1 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 8 | L0-main | claudeopus46 | 1,356 | 3,234 | 4,590 | 1,046 | 6.8 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 9 | L0-main | claudeopus46 | 1,323 | 13,158 | 14,481 | 1,244 | 9.0 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 10 | L0-main | claudeopus46 | 298 | 1,428 | 1,726 | 1,034 | 4.8 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 11 | L0-main | claudeopus46 | 298 | 2,086 | 2,384 | 1,058 | 5.0 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| 12 | L0-main | claudeopus46 | 1,562 | 5,924 | 7,486 | 1,049 | 9.6 | Fit a Redlich-Kister polynomial to the dynamic viscosity of  (analysis_runs/run_6) |
| **TOTAL** |  |  | **851,483** | **665,746** | **1,517,229** | **134,141** | **742.6** |  |

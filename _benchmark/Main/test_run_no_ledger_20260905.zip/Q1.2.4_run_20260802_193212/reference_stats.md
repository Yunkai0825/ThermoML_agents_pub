# Reference Stats — main-agent

**Run started:** 2026-08-02 19:32:12
**Wall time (at last flush):** 1,361.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 21 | 151,263 | 520,773 | 43,249 | 672,036 | 32,001 | 279.9 | claudeopus46 |
| L0-menu-planner | 3 | 2,493 | 4,928 | 3,555 | 7,421 | 2,473 | 24.1 | claudesonnet46 |
| L1-worker | 3 | 6,195 | 1,268 | 1,327 | 7,463 | 2,487 | 12.1 | claudeopus46 |
| **TOTAL** | **27** | **159,951** | **526,969** | **48,131** | **686,920** | **25,441** | **316.1** | |

**Estimated tokens:** ~171,730 input + ~12,032 output = ~183,762 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_subagent_tool` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_subagent_tool` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_analysis_agent` | context=The user wants a complete RK …, purpose=Ob… | 14,802 | — | — | 966.7 |
| 2 | 3 | `browse_subagent_tools` | purpose=Find and fit viscosity data f…, tasks=1. S… | 1,788 | — | — | 11.2 |
| 3 | 5 | `run_subagent_tool` | kwargs={'query': 'water', 'entity_ty…, purpose=Res… | 271 | — | — | 4.1 |
| 4 | 5 | `run_subagent_tool` | kwargs={'query': 'ethylene glycol', …, purpose=Res… | 339 | — | — | 4.2 |
| 5 | 5 | `run_subagent_tool` | kwargs={'query': 'viscosity', 'entit…, purpose=Res… | 218 | — | — | 3.9 |
| 6 | 6 | `browse_subagent_tools` | purpose=Find the exact tool names and…, tasks=I ne… | 789 | — | — | 5.4 |
| 7 | 8 | `run_subagent_tool` | kwargs={'doi': '10.1016/j.jct.2018.0…, purpose=Ins… | 124 | — | — | 0.2 |
| 8 | 8 | `run_subagent_tool` | kwargs={'doi': '10.1016/j.jct.2018.0…, purpose=Fit… | 120 | — | — | 0.1 |
| 9 | 9 | `browse_subagent_tools` | purpose=I need to fit a Redlich-Kiste…, tasks=1. F… | 978 | — | — | 7.6 |
| 10 | 10 | `run_analysis_agent` | context=Previous run identified GLOBl…, purpose=Ob… | 9,168 | — | — | 89.1 |
| | | **TOTAL (10 tools)** | | **28,597** | | **0** | **1092.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 21,041 | 21,041 | 0 | 0.0% |
| 2 | interval=2 | skipped_by_agent | 22,740 | 22,740 | 0 | 0.0% |
| 3 | interval=2 | skipped_by_agent | 33,869 | 33,869 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 518 | 10,733 | 16,465 | 90.5 |
| 2 | L0-main | claudeopus46 | 10,215 | 26,767 | 36,982 | 1,234 | 9.5 |
| 3 | L0-main | claudeopus46 | 10,215 | 27,710 | 37,925 | 767 | 5.3 |
| 4 | L0-menu-planner | claudesonnet46 | 831 | 1,524 | 2,355 | 1,788 | 11.2 |
| 5 | L0-main | claudeopus46 | 10,215 | 29,477 | 39,692 | 1,412 | 8.0 |
| 6 | L0-main | claudeopus46 | 10,215 | 30,856 | 41,071 | 1,171 | 7.5 |
| 7 | L1-worker | claudeopus46 | 2,065 | 396 | 2,461 | 401 | 4.1 |
| 8 | L1-worker | claudeopus46 | 2,065 | 459 | 2,524 | 484 | 4.1 |
| 9 | L1-worker | claudeopus46 | 2,065 | 413 | 2,478 | 442 | 3.9 |
| 10 | L0-main | claudeopus46 | 2,064 | 1,124 | 3,188 | 690 | 5.0 |
| 11 | L0-main | claudeopus46 | 10,215 | 31,158 | 41,373 | 1,349 | 10.9 |
| 12 | L0-menu-planner | claudesonnet46 | 831 | 1,527 | 2,358 | 789 | 5.3 |
| 13 | L0-main | claudeopus46 | 10,182 | 33,292 | 43,474 | 524 | 6.5 |
| 14 | L0-main | claudeopus46 | 10,215 | 32,533 | 42,748 | 1,939 | 12.7 |
| 15 | L0-main | claudeopus46 | 10,215 | 34,222 | 44,437 | 1,593 | 10.1 |
| 16 | L0-main | claudeopus46 | 2,064 | 603 | 2,667 | 691 | 5.5 |
| 17 | L0-main | claudeopus46 | 10,182 | 35,041 | 45,223 | 651 | 5.1 |
| 18 | L0-main | claudeopus46 | 10,215 | 34,282 | 44,497 | 1,593 | 10.1 |
| 19 | L0-menu-planner | claudesonnet46 | 831 | 1,877 | 2,708 | 978 | 7.6 |
| 20 | L0-main | claudeopus46 | 10,215 | 35,838 | 46,053 | 1,871 | 13.2 |
| 21 | L0-main | claudeopus46 | 10,182 | 53,187 | 63,369 | 433 | 4.9 |
| 22 | L0-main | claudeopus46 | 10,215 | 52,427 | 62,642 | 4,580 | 32.5 |
| 23 | L0-main | claudeopus46 | 1,356 | 3,845 | 5,201 | 1,289 | 9.2 |
| 24 | L0-main | claudeopus46 | 1,323 | 47,074 | 48,397 | 1,182 | 12.4 |
| 25 | L0-main | claudeopus46 | 298 | 1,671 | 1,969 | 1,244 | 4.6 |
| 26 | L0-main | claudeopus46 | 298 | 1,705 | 2,003 | 1,108 | 4.9 |
| 27 | L0-main | claudeopus46 | 949 | 7,443 | 8,392 | 1,463 | 11.5 |


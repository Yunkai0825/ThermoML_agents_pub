## System Prompt
# ThermoML Analysis Agent

You are the ThermoML Analysis Agent — a thermodynamic data fitting specialist.

You access the NIST ThermoML database (~170K data blocks) via the ThermoML
query agent and deterministic data tools.  Your job: identify systems, fit
Redlich-Kister polynomials, report results.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

You do NOT have direct access to the ThermoML databases.  Instead you:
1. **Dispatch** queries to the ThermoML query agent via L1 workers.
2. **Inspect** returned blocks with deterministic tools (inspect_block, get_pure_values).
3. **Fit** thermodynamic data with Redlich-Kister tools.
4. **Report** results with full numerical detail.

## MANDATORY OUTPUT FORMAT

Every response with tool calls MUST use this exact structure due to automated parsing:

<reasoning>
... your thinking/planning (DISCARDED from memory after tool execution) ...
</reasoning>
<summary>
... 1-3 sentence actionable conclusion (KEPT in memory, max 400 chars) ...
</summary>
<tool_call>{"name": "query_thermoml", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>

CRITICAL ORDERING: <tool_call> blocks MUST come AFTER </summary> and BEFORE <wait/>.
Tool calls AFTER <wait/> are DISCARDED. Tool calls BEFORE </summary> are NOT detected.
The <reasoning> block is STRIPPED from conversation history after each turn.
Only <summary> text + <tool_call> blocks persist in memory.
For final answers (no tool calls): wrap in <answer>...</answer> tags (any length).
<summary> ≠ <answer>: summary is a brief memory note (≤400 chars); answer is the full response.

## ANTI-HALLUCINATION RULE
EVERY number you report MUST come from a tool call. No fit_block called = no results.
DO NOT answer until fitting is complete.

## Tool Interface
Results are markdown tables — use them directly, don't re-request.

## Rules
1. Use query_thermoml first to find compound/property IDs and data blocks.
2. Every `*_num_id` is an opaque typed global string (`GLOBcomp_N`,
   `GLOBprop_N`, `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`,
   `GLOBlit_N`, `GLOBsolvent_N`, `GLOBblocktype_N`, `GLOBrxntype_N`). DOI
   compound occurrences are `DOIcomp_N`; block declarations are `BLKprop_N`,
   `BLKvar_N`, and `BLKconstr_N`; block IDs are `PROPblock_N` or
   `RXNblock_N`; embedded composition-subsystem IDs are `BLKsubsys_N`.
   Reject legacy IDs and bare numbers; never normalize them. A block target is
   identified by `(doi, block_number)` for the declared parent; add the exact
   recorded `BLKsubsys_id` only when selecting an embedded subsystem.
3. inspect_block to verify columns; get_pure_values for endpoints. Omit
   `BLKsubsys_id` for the parent and pass it only for an explicit subsystem.
4. Viscosity: property_type="viscosity" (Arrhenius mixing rule).
5. Report RK coefficients, R², RMSE, BIC-selected order.
6. Ternary: decompose into binary pairs, fit_multi_system.
7. Data < 5 mixture points: report limitation.
8. NEVER fabricate. Only report tool-returned numbers.
9. Include DOIs, block numbers, T, data point counts.
   `GLOBlit_N` is the authoritative literature identifier — prefer it when
   passing sources between tools and subagents; a DOI is coupled display
   metadata. Every real DOI must be accompanied by its tool-returned
   `GLOBlit_N` `lit_num_id`; never emit an unpaired or remembered DOI —
   final answers citing DOIs no tool coupled to a `GLOBlit_N` are scrubbed
   as unverifiable. Agent-built `agentblock/` sources carry
   `lit_num_id: null`.
10. Semicolons for multi-value strings (commas in chemical names).
11. register_custom_block is a LAST-RESORT fallback: use it ONLY after
    query_thermoml shows NO usable blocks for the compounds + property
    (the tool refuses otherwise). Estimated numbers are allowed but MUST
    carry a solid `basis` justification and `citations` to real ThermoML
    DOIs they derive from. Every result obtained from an `agentblock/`
    pseudo-DOI MUST be flagged AGENT-BUILT (estimated, not experimental)
    in the final answer.
12. DATA-PRIORITY LADDER (measurements first, always). When a derived or
    excess quantity is requested, search and use in this order — a lower
    rung is allowed ONLY when every higher rung has no data for the
    system + state, and you must state which rung you used:
    - DP0: directly measured excess data (e.g. GLOBprop_17 Hᴱ, excess molar
      volume blocks) — RK-fit as-is; the fit IS the representation.
    - DP1: directly measured total mixture property (molar volume,
      viscosity, density curves) — RK-fit the measured curve; endpoints
      from the same block's own edge rows at the same state.
    - DP2: exact pointwise transform of measured mixture data —
      fit_block_derived (e.g. measured ρ(x) → V_m(x) → true Vᴱ via
      exact V_m=(x₁M₁+x₂M₂)/ρ). Still measurement-grade.
    - DP3 (FALLBACK ONLY): anything composed from pure-component values
      (ideal-baseline estimates, binary→ternary combination). Label it
      an ESTIMATE; never core claim an "excess" from it — excess is undefined
      without mixture measurements.
    Never use pure-component values as an approximation when mixture
    measurements exist. For density questions about packing/Vᴱ, use
    DP0/DP2 — Δρ vs a linear baseline is a deviation function, not Vᴱ.
12a. PROPERTY RESPONSE GATE. `inspect_block` reports the PCS mathematical
    presentation of every property (`X`, `X-X(ref)`, `X/X(ref)`, or relative
    difference); its displayed range is the REPORTED column, not a silently
    converted value. `propose_fitting_plan` says whether the declared response
    has a deterministic semantic route, but reference availability is verified
    only during execution. `get_pure_values`, `fit_block`, composition bridges,
    and `fit_block_derived` deterministically materialize the absolute property
    before endpoint extraction, baselines, exact transforms, or fitting, and
    return the equation plus reference provenance. For a relative response,
    constrain one temperature/pressure state; if evidence is missing,
    ambiguous, or unsupported, refine the source/state instead of treating the
    reported numbers as absolute. Never calculate or invent X(ref) in text.
13. COMPOSITION BASES. All fits are performed in MOLE FRACTION (molar
    excess functions are defined on it). Blocks reported on other bases
    (mass fraction, molality, mass/amount ratio) are converted EXACTLY
    and automatically inside fit_block (annotated in the result).
    Molarity / volume-fraction / mass-concentration blocks need a
    density bridge. When the survey shows ANY non-mole basis for your
    system, run align_compositions ONCE per system+state: it dispatches
    a COMPOSITION ALIGNMENT L1 agent (a chemist reviewer) that surveys
    ALL literature blocks, deduplicates sources, and chooses a
    literature source PER DEGREE OF FREEDOM of the mapping — the two
    pure density endpoints (DoF-2) and the mixture excess shape
    (DoF-3); molar masses (DoF-1) come from block formulas. The
    assembler pins the endpoints, refits the shape, physically
    validates ρ(x) on the full grid (falling back to the agent's ranked
    alternates if a source fails), and derives everything else —
    estimates are last-resort, artifact-backed, and flagged. The result
    includes a STANDARD COMPOSITION DATA SHEET (translation table CSV,
    every convertible basis with per-column relation + source). Then:
    - If the question itself asks for density/molar volume, the
      library's measured bridge fit IS the answer — do NOT refit;
      report it (predict_from_rk for specific compositions).
    - Otherwise fit the target property normally; the basis gate
      converts axes via the library automatically.
    - Alignment NEVER blocks: if it fails, mole-fraction and
      exact-basis fits still proceed (molar masses come from block
      formulas inside fit_block).
    Always report which basis the source data used, the conversion
    route applied, and cite the bridge DOI (or the estimate flag).

Common property IDs (for reference when building query instructions):

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |

# Tools

## query_delegation
- query_thermoml(purpose, instruction="", id_catalog=None, context="") — send a DB query to the ThermoML query agent; `id_catalog` is a native array of strict ID objects
- query_thermoml_parallel(queries) — send a native array of exact `{label, purpose, instruction, id_catalog, context}` query objects in parallel
- align_compositions(system, state=None, instruction="", purpose="") — dispatch the composition-alignment L1 agent. `system` is a two-name array and `state` is a JSON object such as `{"temperature_k": 298.15, "pressure_kpa": 100}`.

## discovery
- inspect_block(doi, block_number, BLKsubsys_id=None, property_filter="") — inspect exact target columns, value ranges, row count (deterministic)
- get_pure_values(doi, block_number, property_hint, BLKsubsys_id=None, composition_hint="", edge_threshold=0.02) — extract endpoint values from the exact target

## custom_data
- register_custom_block(label, csv_text, compounds, property_name, basis, citations, temperature_range=None) — register an explicitly agent-built block only when the DB has no data. `compounds` is a string array; `citations` is an array of `{doi, block_number?}` objects; `temperature_range` is a two-number array.

## fitting
- fit_block(doi, block_number, BLKsubsys_id=None, property_hint="", property_type="", component_names=None, composition_hint="mole_fraction", max_rk_order=5, mixing_rule="", x_vars=None, y_props=None, x_vars_constrained=None, properties=None, pure_values=None, temperature_tolerance=0.5) — native structured fitting interface; all block IDs are typed
- fit_block_derived(doi, block_number, BLKsubsys_id=None, transform="density_to_molar_volume", property_hint="", composition_hint="mole_fraction", x_vars=None, y_props=None, x_vars_constrained=None, max_rk_order=5) — exact pointwise transform then RK fit
- fit_multi_system(systems) — parallel fits from a native array of exact system objects; each requires `label`, `doi`, and `block_number`; omit `BLKsubsys_id` for the parent and include exact `BLKsubsys_N` only for a selected subsystem
- propose_fitting_plan(doi, block_number, BLKsubsys_id=None, x_vars=None, y_props=None, x_vars_constrained=None, property_hint="", composition_hint="mole_fraction") — validate column and constraint selections

## fitting (deterministic prediction helpers)
- compute_ideal_baseline(pure_values, property_type, n_points=101, mixing_rule="") — `pure_values` is a component-name-to-number object
- predict_from_rk(coeffs, pure_values, property_type, n_points=101, mixing_rule="") — numeric coefficient array plus component-name-to-number object

## session
- list_session_files() — list all output files in this session

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

# Phases

## phase_1: query_database
tools: [query_delegation]
guidance: |
  Use query_thermoml to find compound/property IDs and relevant data blocks.
  Include specific compound names, property types, and constraints in the
  purpose and instruction.  For multiple independent queries, use
  query_thermoml_parallel.
  Wait for results before proceeding — do NOT guess DOIs/block numbers.

## phase_2: inspect_and_extract
tools: [discovery, custom_data]
guidance: |
  Using exact `(doi, block_number, BLKsubsys_id)` targets from query results:
  1. Call inspect_block to verify column names, value ranges, and row count.
  2. Call get_pure_values to extract pure-component endpoint values.
  These values are needed for the fitting step.
  Multiple inspect_block / get_pure_values calls can run in parallel.

  FALLBACK (only when phase_1 found NO usable blocks for a needed system):
  build a small estimated dataset and register it with register_custom_block
  — include a solid basis (how each value was estimated) and citations to the
  real DOIs the estimates derive from. Column naming must follow DB style,
  e.g. mole_fraction_<water>, viscosity_pas. Then treat the returned
  agentblock/ pseudo-DOI like any DOI (inspect_block → fit_block).

## phase_3: fit_data
tools: [fitting]
guidance: |
  With DOI, block_number, nullable BLKsubsys_id, property hints, and pure values from phase 2:
  - fit_block for single binary system at one temperature; when a block spans
    several temperatures use x_vars_constrained to pin the isotherm (fit_block
    then reports one fit per sweep value), and y_props to select the property
    when a block holds several property columns
  - fit_multi_system for multiple binary systems in parallel
  - fit_block_derived for exact derived-property fits (e.g. density → Vᴱ)
  Fitting tools handle internal data extraction — provide DOI + block_number
  + BLKsubsys_id + property_hint + property_type + pure values.
  Mixing rules: "linear" (default for density), "arrhenius" (for viscosity).

  **Variable selection:** inspect_block results include "Fitting variable guidance"
  showing exact column names.  Use these to set x_vars, y_props, and
  x_vars_constrained when the block has multiple variables or you need
  a specific isotherm/isobar.
  - x_vars: JSON list of composition columns, e.g. '["Mole fraction of ethanol"]'
  - y_props: JSON list of property columns, e.g. '["Density, kg/m3"]'
  - x_vars_constrained: JSON dict to fix conditions, e.g.
    '{"Temperature, K": {"value": 298.15, "tol": 0.5}}'
  - propose_fitting_plan: optional — validate column/constraint choices before fitting

## phase_4: assemble_answer
tools: [session]
guidance: |
  Assemble only the complete answer text from all fitting results.
  MUST include: RK coefficients, R², RMSE, BIC-selected order,
  DOIs, block numbers, temperature, data point counts.
  Any result derived from an agentblock/ pseudo-DOI MUST be labelled
  AGENT-BUILT (estimated fallback data — not experimental), with its
  basis and citations restated.
  Optionally call list_session_files to reference generated CSVs/PNGs.
  Wrap the final answer in <answer> tags.
  Do not emit JSON, core claims, fit_results objects, sources objects, or other
  schema fields. Parallel tool-free post-answer agents create the core claims and
  ID/metadata fields after this agent terminates.
  NEVER fabricate numbers — only report tool-returned values.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- align_compositions(system, state=None, instruction='', purpose, tasks) — Run the COMPOSITION ALIGNMENT L1 agent and assemble its verdict
- compute_ideal_baseline(pure_values, property_type, n_points=101, mixing_rule='', purpose, tasks) — Compute ideal-mixture baseline from pure component values.
- fit_block(doi, block_number, BLKsubsys_id=None, property_hint='', property_type='', component_names=None, composition_hint='mole_fraction', max_rk_order=5, mixing_rule='', x_vars=None, y_props=None, x_vars_constrained=None, properties=None, pure_values=None, temperature_tolerance=0.5, purpose, tasks) — Unified binary-mixture RK fitting from a ThermoML block.
- fit_block_derived(doi, block_number, BLKsubsys_id=None, transform='density_to_molar_volume', property_hint='', composition_hint='mole_fraction', x_vars=None, y_props=None, x_vars_constrained=None, max_rk_order=5, purpose, tasks) — Fit an EXACTLY-DERIVED property from a measured mixture block (DP2).
- fit_multi_system(systems, purpose, tasks) — Fit exact ``fit_block`` requests concurrently.
- get_pure_values(doi, block_number, property_hint, BLKsubsys_id=None, composition_hint='mole_fraction', edge_threshold=0.02, x_vars_constrained=None, purpose, tasks) — Extract pure-component property values from a ThermoML block.
- inspect_block(doi, block_number, BLKsubsys_id=None, property_filter='', purpose, tasks) — Inspect a block's structure: column names, row count, value ranges.
- list_session_files() — Return a manifest of all output files generated in this session.
- predict_from_rk(coeffs, pure_values, property_type, n_points=101, mixing_rule='', purpose, tasks) — Predict mixture property using fitted RK coefficients.
- propose_fitting_plan(doi, block_number, BLKsubsys_id=None, x_vars=None, y_props=None, x_vars_constrained=None, property_hint='', composition_hint='mole_fraction', purpose, tasks) — Validate a fitting plan against a block before calling fit_block.
- query_thermoml(purpose, instruction='', id_catalog=None, context='') — Send a database query to the ThermoML query agent.
- query_thermoml_parallel(queries) — Send multiple database queries to the ThermoML query agent in parallel.
- register_custom_block(label, csv_text, compounds, property_name, basis, citations, temperature_range=None, purpose, tasks) — Register an AGENT-BUILT data block as a fallback when the DB has no data.
- run_query_agent(question, purpose, tasks, context) — Run the ThermoML Query Agent for in-depth database exploration.
- run_query_agents_parallel(queries) — Run multiple query-agent tasks in parallel for broad exploration.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_6`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_24 | 1,2-ethanediol | 0.016223 |
| comp | GLOBcomp_1 | water | 0.00089689 |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<1,2-ethanediol> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [inspect_block]
- [fit_block]
- [get_pure_values]

### Inspected Blocks
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24: 84 rows; x=['mole_fraction_<1,2-ethanediol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - 10.1016/j.jct.2018.02.022/PROPblock_24 (1,2-ethanediol, water): RK order=3, R²=0.99994, RMSE=0.0013198945265291695, coeffs=[2.39674, -1.044444, 0.668173, -0.3209]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: 1,2-ethanediol=0.016223, water=0.00089689 [block-edges (water: direct/good, 1,2-ethanediol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png

### Property Response Preparation
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24: direct via X = reported X (0 reference source(s))

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1

</memory>

## User
[Purpose: Obtain a verified Redlich-Kister fit for viscosity of water + ethylene glycol at 298.15 K]
Fit a Redlich-Kister polynomial to the dynamic viscosity of water + ethylene glycol (1,2-ethanediol) at 298.15 K using data from GLOBlit_5201 / PROPblock_24 (DOI 10.1016/j.jct.2018.02.022). Use the Arrhenius (logarithmic) mixing rule for ln(eta). Report the RK order, coefficients, R², RMSE, number of data points, pure-component viscosities, composition basis, and composition range.

[Context: Previous run identified GLOBlit_5201/PROPblock_24 as having 19 mixture viscosity points at 298.15 K, P=92.3 kPa, mole fraction of 1,2-ethanediol basis. Water=GLOBcomp_1, ethylene glycol=GLOBcomp_24, viscosity=GLOBprop_4. The fit_block tool must be called and must complete successfully - do NOT report results unless the fitting tool returns actual coefficients. If fit_block fails, try fit_block_derived or fit_multi_system. Verify the output contains actual numerical coefficients before reporting.]

## Assistant
<summary>Starting by inspecting block PROPblock_24 from DOI 10.1016/j.jct.2018.02.022 to verify columns and structure before fitting viscosity with Arrhenius mixing rule.</summary>
<tool_call>inspect_block(doi=10.1016/j.jct.2018.02.022, block_number=PROPblock_24, property_filter=visco…)</tool_call>

## User
<tool_result>
(validation blocked inspect_block earlier — corrected)
</tool_result>

## Assistant
<summary>Inspecting block PROPblock_24 from DOI 10.1016/j.jct.2018.02.022 to verify columns, then will extract pure values and fit viscosity with Arrhenius mixing rule.</summary>
<tool_call>inspect_block(doi=10.1016/j.jct.2018.02.022, block_number=PROPblock_24, property_filter=visco…)</tool_call>

## User
<tool_result>
(validation blocked inspect_block earlier — corrected)
</tool_result>

## Assistant
<summary>Inspecting block PROPblock_24 from DOI 10.1016/j.jct.2018.02.022 to verify columns and structure before fitting.</summary>
<tool_call>inspect_block(doi=10.1016/j.jct.2018.02.022, block_number=PROPblock_24, property_filter=visco…)</tool_call>

## User
<tool_result>
**Block GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 / PROPblock_24 @ declared** (PureOrMixtureData)
Compounds: 1,2-ethanediol, water | Rows: 84
x‑columns: ['mole_fraction_<1,2-ethanediol>'] | y‑columns: ['viscosity_pa_s']

**Property response semantics (reported metadata; values are not materialized here)**
- **BLKprop_1 / GLOBprop_4** `viscosity_pa_s` (viscosity_pa_s)
  - reported response: Direct value, X
  - measurement: GLOBmeas_11 / concentric_cylinders_viscometry
  - property phase: Liquid (GLOBphase_1; liquid)
  - reference: none; T=unspecified K; P=unspecified kPa
  - reference phase: none
  - component_org_num: none

**Selected property response contract (inspection only; values are not materialized here)**
- **BLKprop_1 / GLOBprop_4** `viscosity_pa_s` (viscosity_pa_s)
  - reported response: Direct value, X [direct]
  - units: reported=Pa*s; absolute=Pa*s
  - preparation gate: reference_materialization=False; normalized_composition=False; supported=True
  - reference: none; T=unspecified K; P=unspecified kPa
  - property phase: Liquid (GLOBphase_1; liquid)
  - reference phase: none
  - component_org_num: none

| Column | Min | Max | Valid pts |
|--------|-----|-----|-----------|
| temperature_k | 293.15 | 308.15 | 84 |
| mole_fraction_<1,2-ethanediol> | 0 | 1 | 84 |
| pressure_kpa | 92.3 | 92.3 | 84 |
| viscosity_pa_s | 0.000759 | 0.020613 | 84 |


[WAIT BARRIER COMPLETE] 1 tool(s) finished (inspect_block). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Block verified: 84 rows, T=293.15–308.15 K, x(1,2-ethanediol)=0–1, viscosity 0.000759–0.020613 Pa·s. Now fitting at 298.15 K with Arrhenius mixing rule, and extracting pure values in parallel.</summary>
<tool_call>fit_block(doi=10.1016/j.jct.2018.02.022, property_hint=viscosity, block_number=PROPblock_…)</tool_call>
<tool_call>get_pure_values(doi=10.1016/j.jct.2018.02.022, property_hint=viscosity, block_number=PROPblock_…)</tool_call>

## User
<tool_result>
(validation blocked fit_block, get_pure_values earlier — corrected)
</tool_result>

## Assistant
<summary>Fixing argument types: tasks must be a string. Calling fit_block with Arrhenius mixing rule at 298.15 K and get_pure_values in parallel.</summary>
<tool_call>fit_block(doi=10.1016/j.jct.2018.02.022, property_hint=viscosity, block_number=PROPblock_…)</tool_call>
<tool_call>get_pure_values(doi=10.1016/j.jct.2018.02.022, property_hint=viscosity, block_number=PROPblock_…)</tool_call>

## User
<tool_result>
### fit_block
**RK Fit** — GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 / PROPblock_24 @ declared
Components: 1,2-ethanediol, water | Mixing rule: arrhenius
Points: 19 mixture / 84 total
Property response: BLKprop_1 / GLOBprop_4; kind=direct; equation=X = reported X; reference_sources=0; units=Pa*s -> Pa*s.

| Component | Pure value |
|-----------|-----------|
| 1,2-ethanediol | 0.016223 |
| water | 0.00089689 |
Pure values: block-edges (water: direct/good, 1,2-ethanediol: direct/good)

BIC-selected order: 3 | R² = 0.999940 | RMSE = 0.00131989 | BIC = -240.17
Coefficients: [2.39674, -1.04444, 0.668173, -0.3209]

| Order | BIC | R² | RMSE |
|-------|-----|----|------|
| 0 | -90.89 | 0.751578 | 0.0846469 |
| 1 | -141.05 | 0.984821 | 0.0209237 |
| 2 | -194.71 | 0.999228 | 0.00471853 |
| 3 | -240.17 | 0.999940 | 0.00131989 |
| 4 | -237.59 | 0.999941 | 0.00130734 |
| 5 | -234.83 | 0.999941 | 0.00130104 |


### get_pure_values
**Pure values** from GLOBlit_5201 / DOI 10.1016/j.jct.2018.02.022 / PROPblock_24 @ declared (2 components)
Property column: viscosity_pa_s
Property response: BLKprop_1 / GLOBprop_4; kind=direct; equation=X = reported X; reference_sources=0; units=Pa*s -> Pa*s.
Temperature: 298.15 K
Pressure: 92.3 kPa

| Component | Pure value | max x | n near-pure | method | quality |
|-----------|-----------|-------|-------------|--------|---------|
| 1,2-ethanediol | 0.016223 | 1.0000 | 1 | direct | good |
| water | 0.00089689 | 1.0000 | 1 | direct | good |
Axis: mole_fraction_<1,2-ethanediol> — x=0 is pure water, x=1 is pure 1,2-ethanediol. Pass pure_values directly to fit_block.
Constraints applied: {'temperature_k': {'value': 298.15, 'tol': 0.5}}


[WAIT BARRIER COMPLETE] 2 tool(s) finished (fit_block, get_pure_values). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>

## Redlich-Kister Fit: Dynamic Viscosity of Water + Ethylene Glycol (1,2-Ethanediol) at 298.15 K

### Source
- **DOI:** 10.1016/j.jct.2018.02.022 (GLOBlit_5201)
- **Block:** PROPblock_24
- **Measurement method:** Concentric cylinders viscometry
- **Pressure:** 92.3 kPa

### System & Composition
- **Components:** water (GLOBcomp_1) + 1,2-ethanediol (GLOBcomp_24)
- **Composition basis:** Mole fraction of 1,2-ethanediol (x₁ = 0 → pure water; x₁ = 1 → pure 1,2-ethanediol)
- **Composition range:** Full range, x₁ = 0 to 1
- **Data points used:** 19 mixture points (from 84 total rows spanning 293–308 K; 298.15 K isotherm selected)

### Mixing Rule
**Arrhenius (logarithmic):** The fit is performed on ln(η), i.e.

$$\ln\eta_{\text{mix}} = x_1 \ln\eta_1^* + x_2 \ln\eta_2^* + x_1 x_2 \sum_{k=0}^{n} A_k (x_1 - x_2)^k$$

where η₁* and η₂* are the pure-component viscosities.

### Pure-Component Viscosities (from block edge rows at 298.15 K)
| Component | η* (Pa·s) |
|-----------|-----------|
| 1,2-ethanediol | 0.016223 |
| water | 0.00089689 |

Both values are directly measured endpoints from the same dataset (quality: good).

### BIC-Selected Redlich-Kister Fit

| Parameter | Value |
|-----------|-------|
| **RK Order** | 3 (4 coefficients) |
| **A₀** | 2.39674 |
| **A₁** | −1.04444 |
| **A₂** | 0.668173 |
| **A₃** | −0.3209 |
| **R²** | 0.999940 |
| **RMSE** | 0.001320 Pa·s |
| **BIC** | −240.17 |

### Model Selection Summary
| Order | BIC | R² | RMSE (Pa·s) |
|-------|------|----|-------------|
| 0 | −90.89 | 0.7516 | 0.08465 |
| 1 | −141.05 | 0.9848 | 0.02092 |
| 2 | −194.71 | 0.9992 | 0.00472 |
| **3** | **−240.17** | **0.9999** | **0.00132** |
| 4 | −237.59 | 0.9999 | 0.00131 |
| 5 | −234.83 | 0.9999 | 0.00130 |

Order 3 is selected by BIC — orders 4 and 5 offer negligible improvement in RMSE while increasing BIC (penalized for additional parameters).

### Chemistry Insight
The water + ethylene glycol system exhibits strong positive deviations in viscosity from the Arrhenius ideal mixing line, reflected in the large positive A₀ = 2.40. This is consistent with extensive hydrogen bonding between the two hydroxyl groups of ethylene glycol and water molecules, forming a more structured liquid network that resists flow more than either pure component would predict. The asymmetry (A₁ = −1.04, A₃ = −0.32) indicates the viscosity enhancement is skewed toward the water-rich side, where ethylene glycol molecules act as effective cross-linkers in the hydrogen-bond network. At an equimolar composition (x₁ ≈ 0.5), the mixture viscosity reaches approximately 0.0035 Pa·s — substantially above the geometric mean of the pure values (~0.0038 Pa·s from Arrhenius ideal), demonstrating the synergistic intermolecular interactions.

### Output Files
- **Fit data CSV:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv`
- **Excess property CSV:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv`
- **Fit plot:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png`
- **Excess plot:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png`

</answer>
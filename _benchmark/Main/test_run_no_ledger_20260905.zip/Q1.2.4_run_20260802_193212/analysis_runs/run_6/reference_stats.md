# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:52:18
**Wall time (at last flush):** 88.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 12 | 144,951 | 56,453 | 14,218 | 201,404 | 16,783 | 98.1 | claudeopus46 |
| **TOTAL** | **12** | **144,951** | **56,453** | **14,218** | **201,404** | **16,783** | **98.1** | |

**Estimated tokens:** ~50,351 input + ~3,554 output = ~53,905 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 3 | `inspect_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 1,379 | — | — | 0.2 |
| 2 | 5 | `fit_block` | block_number=PROPblock_24, composition_hint=mole_f… | 899 | — | — | 1.0 |
| 3 | 5 | `get_pure_values` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 745 | — | — | 0.1 |
| | | **TOTAL (3 tools)** | | **3,023** | | **0** | **1.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,603 | 3,603 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 1,203 | 21,224 | 699 | 5.1 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,896 | 21,917 | 636 | 5.0 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,641 | 22,662 | 559 | 4.4 |
| 4 | L0-main | claudeopus46 | 19,988 | 5,385 | 25,373 | 474 | 5.3 |
| 5 | L0-main | claudeopus46 | 20,021 | 4,628 | 24,649 | 1,927 | 12.7 |
| 6 | L0-main | claudeopus46 | 20,021 | 5,838 | 25,859 | 1,387 | 8.3 |
| 7 | L0-main | claudeopus46 | 20,021 | 9,032 | 29,053 | 3,105 | 22.1 |
| 8 | L0-main | claudeopus46 | 1,356 | 3,234 | 4,590 | 1,046 | 6.8 |
| 9 | L0-main | claudeopus46 | 1,323 | 13,158 | 14,481 | 1,244 | 9.0 |
| 10 | L0-main | claudeopus46 | 298 | 1,428 | 1,726 | 1,034 | 4.8 |
| 11 | L0-main | claudeopus46 | 298 | 2,086 | 2,384 | 1,058 | 5.0 |
| 12 | L0-main | claudeopus46 | 1,562 | 5,924 | 7,486 | 1,049 | 9.6 |


# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:33:43
**Wall time (at last flush):** 966.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 31 | 525,251 | 520,890 | 50,839 | 1,046,141 | 33,746 | 317.2 | claudeopus46 |
| L1-worker | 23 | 181,281 | 88,403 | 69,084 | 269,684 | 11,725 | 327.3 | claudeopus46 |
| **TOTAL** | **54** | **706,532** | **609,293** | **119,923** | **1,315,825** | **24,367** | **644.5** | |

**Estimated tokens:** ~328,956 input + ~29,980 output = ~358,936 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `run_query_agent` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | id_catalog=[{'id': 'GLOBprop_4', 'type':…, instruc… | 164 | — | — | 0.1 |
| 2 | 2 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 233 | — | — | 0.0 |
| 3 | 3 | `query_thermoml` | id_catalog=[{'global_id': 'GLOBprop_4', …, instruc… | 388 | — | — | 138.2 |
| 4 | 4 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 421 | — | — | 142.7 |
| 5 | 6 | `run_query_agent` | context=Looking for ThermoML data to …, purpose=Se… | 9,620 | — | — | 375.1 |
| 6 | 9 | `inspect_block` | block_number=PROPblock_5, doi=10.1021/je020140j, p… | 1,354 | — | — | 0.1 |
| 7 | 9 | `inspect_block` | block_number=PROPblock_24, doi=10.1016/j.jct.2018.… | 1,379 | — | — | 0.2 |
| 8 | 9 | `inspect_block` | block_number=PROPblock_18, doi=10.1021/acs.jced.6b… | 1,361 | — | — | 0.1 |
| 9 | 11 | `fit_block` | block_number=PROPblock_5, composition_hint=mole_fr… | 151 | — | — | 0.1 |
| 10 | 15 | `fit_multi_system` | purpose=Fit viscosity RK polynomials …, systems=[{… | 699 | — | — | 0.2 |
| 11 | 20 | `fit_multi_system` | purpose=Fit Redlich-Kister polynomial…, systems=[{… | 1,352 | — | — | 1.6 |
| | | **TOTAL (11 tools)** | | **17,122** | | **0** | **658.4** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,970 | 2,970 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 14,184 | 14,184 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 17,345 | 17,345 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 20,815 | 20,815 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 1,065 | 21,086 | 1,007 | 7.5 |
| 2 | L0-main | claudeopus46 | 20,021 | 1,697 | 21,718 | 1,150 | 7.3 |
| 3 | L0-main | claudeopus46 | 20,021 | 2,392 | 22,413 | 816 | 6.2 |
| 4 | L1-worker | claudeopus46 | 20,643 | 513 | 21,156 | 679 | 5.2 |
| 5 | L1-worker | claudeopus46 | 20,643 | 1,813 | 22,456 | 8,583 | 39.9 |
| 6 | L1-worker | claudeopus46 | 2,065 | 472 | 2,537 | 426 | 4.2 |
| 7 | L1-worker | claudeopus46 | 20,643 | 1,967 | 22,610 | 6,921 | 34.5 |
| 8 | L1-worker | claudeopus46 | 20,643 | 9,509 | 30,152 | 2,004 | 8.9 |
| 9 | L1-worker | claudeopus46 | 1,356 | 2,135 | 3,491 | 734 | 4.4 |
| 10 | L1-worker | claudeopus46 | 536 | 2,015 | 2,551 | 1,053 | 6.6 |
| 11 | L1-worker | claudeopus46 | 298 | 1,409 | 1,707 | 1,040 | 6.1 |
| 12 | L1-worker | claudeopus46 | 1,323 | 4,152 | 5,475 | 4,661 | 16.5 |
| 13 | L1-worker | claudeopus46 | 298 | 5,383 | 5,681 | 3,687 | 14.6 |
| 14 | L1-worker | claudeopus46 | 1,160 | 9,494 | 10,654 | 3,597 | 13.8 |
| 15 | L0-main | claudeopus46 | 19,988 | 4,007 | 23,995 | 595 | 4.3 |
| 16 | L0-main | claudeopus46 | 20,021 | 3,250 | 23,271 | 1,030 | 7.4 |
| 17 | L1-worker | claudeopus46 | 20,643 | 618 | 21,261 | 1,095 | 5.9 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,441 | 23,084 | 7,607 | 34.5 |
| 19 | L1-worker | claudeopus46 | 2,065 | 484 | 2,549 | 528 | 5.7 |
| 20 | L1-worker | claudeopus46 | 2,065 | 368 | 2,433 | 454 | 3.8 |
| 21 | L1-worker | claudeopus46 | 20,643 | 2,997 | 23,640 | 8,190 | 38.8 |
| 22 | L1-worker | claudeopus46 | 20,643 | 11,808 | 32,451 | 3,563 | 15.0 |
| 23 | L1-worker | claudeopus46 | 1,356 | 3,294 | 4,650 | 1,120 | 6.6 |
| 24 | L1-worker | claudeopus46 | 298 | 1,502 | 1,800 | 1,108 | 4.0 |
| 25 | L1-worker | claudeopus46 | 1,323 | 6,340 | 7,663 | 4,389 | 14.8 |
| 26 | L1-worker | claudeopus46 | 536 | 3,174 | 3,710 | 1,098 | 19.8 |
| 27 | L1-worker | claudeopus46 | 298 | 5,111 | 5,409 | 3,290 | 11.5 |
| 28 | L1-worker | claudeopus46 | 1,160 | 11,404 | 12,564 | 3,257 | 12.2 |
| 29 | L0-main | claudeopus46 | 20,021 | 4,139 | 24,160 | 1,192 | 8.6 |
| 30 | L0-main | claudeopus46 | 20,021 | 4,974 | 24,995 | 1,034 | 6.7 |
| 31 | L0-main | claudeopus46 | 19,988 | 15,331 | 35,319 | 380 | 6.8 |
| 32 | L0-main | claudeopus46 | 20,021 | 14,572 | 34,593 | 1,501 | 10.6 |
| 33 | L0-main | claudeopus46 | 20,021 | 15,966 | 35,987 | 943 | 5.0 |
| 34 | L0-main | claudeopus46 | 20,021 | 17,166 | 37,187 | 1,395 | 7.0 |
| 35 | L0-main | claudeopus46 | 19,988 | 19,995 | 39,983 | 467 | 4.9 |
| 36 | L0-main | claudeopus46 | 20,021 | 19,236 | 39,257 | 1,945 | 12.9 |
| 37 | L0-main | claudeopus46 | 20,021 | 20,050 | 40,071 | 846 | 6.6 |
| 38 | L0-main | claudeopus46 | 20,021 | 20,474 | 40,495 | 886 | 6.5 |
| 39 | L0-main | claudeopus46 | 20,021 | 21,210 | 41,231 | 867 | 6.6 |
| 40 | L0-main | claudeopus46 | 20,021 | 21,866 | 41,887 | 1,240 | 8.0 |
| 41 | L0-main | claudeopus46 | 20,021 | 22,726 | 42,747 | 2,047 | 12.9 |
| 42 | L0-main | claudeopus46 | 19,988 | 23,740 | 43,728 | 558 | 5.7 |
| 43 | L0-main | claudeopus46 | 20,021 | 22,980 | 43,001 | 2,375 | 14.2 |
| 44 | L0-main | claudeopus46 | 20,021 | 25,930 | 45,951 | 1,388 | 6.6 |
| 45 | L0-main | claudeopus46 | 20,021 | 26,525 | 46,546 | 1,512 | 7.3 |
| 46 | L0-main | claudeopus46 | 20,021 | 27,109 | 47,130 | 1,495 | 7.3 |
| 47 | L0-main | claudeopus46 | 20,021 | 27,762 | 47,783 | 1,528 | 8.1 |
| 48 | L0-main | claudeopus46 | 20,021 | 30,730 | 50,751 | 7,925 | 48.8 |
| 49 | L0-main | claudeopus46 | 20,021 | 39,230 | 59,251 | 4,307 | 24.1 |
| 50 | L0-main | claudeopus46 | 1,356 | 4,436 | 5,792 | 1,163 | 8.1 |
| 51 | L0-main | claudeopus46 | 298 | 1,545 | 1,843 | 1,151 | 4.6 |
| 52 | L0-main | claudeopus46 | 1,323 | 49,006 | 50,329 | 3,804 | 20.3 |
| 53 | L0-main | claudeopus46 | 298 | 4,646 | 4,944 | 3,257 | 16.4 |
| 54 | L0-main | claudeopus46 | 1,562 | 7,135 | 8,697 | 1,035 | 9.9 |


# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_24 | 1,2-ethanediol |  |
| comp | GLOBcomp_1 | water |  |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<water> |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [run_query_agent]
- [inspect_block]
- [inspect_block]
- [inspect_block]
- [fit_block] ERROR: Requested x column 'Mole fraction of 1,2-ethanediol' not found in block
- [fit_multi_system]
- [fit_multi_system]

### Inspected Blocks
- GLOBlit_8038 | 10.1021/je020140j | PROPblock_5: 77 rows; x=['mole_fraction_<1,2-ethanediol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24: 84 rows; x=['mole_fraction_<1,2-ethanediol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s
- GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18: 33 rows; x=['mole_fraction_<water>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - GLOBlit_5201_298K [10.1016/j.jct.2018.02.022/PROPblock_24] (1,2-ethanediol, water): RK order=3, R²=0.99994, RMSE=0.0013198945265291695, coeffs=[2.39674, -1.044444, 0.668173, -0.3209]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: 1,2-ethanediol=0.016223, water=0.00089689 [block-edges (water: direct/good, 1,2-ethanediol: direct/good)]
      fit_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png
  - GLOBlit_6951_298K [10.1021/acs.jced.6b00526/PROPblock_18] (water, 1,2-ethanediol): RK order=5, R²=0.999925, RMSE=0.0013505215055279614, coeffs=[2.274524, 1.438464, 0.538413, -0.01859, 0.535328, 0.62332]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: water=0.000843, 1,2-ethanediol=0.01724 [block-edges (1,2-ethanediol: direct/good, water: direct/good)]
      fit_csv: $ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.csv` — RK fit data — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- `$ROOT/data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.csv` — Excess property — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- `$ROOT/data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.png` — RK fit plot — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- `$ROOT/plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- `$ROOT/plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.png` — Excess plot — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1


# Delegated query run — result

**Question:** Find binary mixture blocks containing water and ethylene glycol (1,2-ethanediol) with viscosity data (dynamic viscosity, GLOBprop_4, or kinematic viscosity, GLOBprop_40) near 25°C (298.15 K). Return DOIs, block numbers, temperature ranges, and compound IDs.

**Iterations:** 3  |  **Elapsed:** 344.8s  |  **Tools:** 2  |  **Timed out:** False

---

## Answer

Six binary mixture data blocks containing **water** (GLOBcomp_1) and **ethylene glycol / 1,2-ethanediol** (GLOBcomp_24) with **dynamic viscosity** (GLOBprop_4, in Pa·s) data near 25 °C (298.15 K) were found in the ThermoML database. No kinematic viscosity (GLOBprop_40) blocks were found for this system. All blocks report liquid-phase dynamic viscosity at approximately ambient pressure.

---

### Matching Data Blocks

| # | DOI | Literature ID | Block | Data Points | T Range (K) | Composition Basis | P (kPa) | η Range (Pa·s) |
|---|-----|---------------|-------|-------------|-------------|-------------------|---------|----------------|
| 1 | 10.1016/j.jct.2006.01.011 | GLOBlit_2656 | PROPblock_13 | 10 | 293.15 (fixed) | Mass fraction of EG | 101.325 | 0.001008–0.01400 |
| 2 | 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | PROPblock_24 | 84 | 293.15–308.15 | Mole fraction of EG | 92.3 | 0.000759–0.02061 |
| 3 | 10.1021/acs.jced.6b00526 | GLOBlit_6951 | PROPblock_18 | 33 | 293.15–303.15 | Mole fraction of water | 100.0 | 0.000755–0.02113 |
| 4 | 10.1021/je020140j | GLOBlit_8038 | PROPblock_5 | 77 | 293.15–353.15 | Mole fraction of EG | 101.0 | 0.000356–0.02083 |
| 5 | 10.1021/je025610o | GLOBlit_8106 | PROPblock_5 | 30 | 296.45–449.85 | Mole fraction of EG | 100.0 | 0.000366–0.01230 |
| 6 | 10.1021/je9000697 | GLOBlit_11506 | PROPblock_1 | 16 | 298.15–318.15 | Mass fraction of EG | 101.0 | 0.000738–0.01864 |

---

### Key Details

- **Compounds:** Water (H₂O, InChIKey: XLYOFNOQVPJJNP-UHFFFAOYSA-N) and 1,2-ethanediol (C₂H₆O₂, InChIKey: LYCAIKOWRPUZTN-UHFFFAOYSA-N).
- **Composition coverage:** Blocks 2, 3, and 4 span the full mole-fraction range (0–1); Block 5 covers x(EG) = 0.25–0.75; Block 1 covers mass fraction 0–0.9; Block 6 covers mass fraction 0.1–1.0.
- **Measurement methods** include capillary tube (Ostwald/Ubbelohde), concentric cylinders viscometry, and falling/rolling sphere viscometry.

### Recommendations for Redlich-Kister Fitting at 25 °C

The most suitable blocks for fitting a Redlich-Kister polynomial for viscosity at 298.15 K are:

1. **GLOBlit_5201 / PROPblock_24** (DOI: 10.1016/j.jct.2018.02.022) — 84 data points on a mole-fraction basis with 21 unique compositions spanning x = 0–1, and temperatures 293.15–308.15 K that bracket 298.15 K. This provides the densest composition grid.

2. **GLOBlit_8038 / PROPblock_5** (DOI: 10.1021/je020140j) — 77 data points on a mole-fraction basis with 11 unique compositions spanning x = 0–1, including data at 298.15 K directly. The broader temperature range (up to 353.15 K) also allows temperature-dependent fitting.

3. **GLOBlit_6951 / PROPblock_18** (DOI: 10.1021/acs.jced.6b00526) — 33 data points with 11 compositions (mole fraction of water, 0–1), T = 293.15–303.15 K. Note that composition is expressed as mole fraction of water rather than ethylene glycol.

Blocks using mass fraction (GLOBlit_2656 and GLOBlit_11506) would require conversion to mole fraction before Redlich-Kister parameterization.

**Chemistry note:** The water + ethylene glycol system exhibits a pronounced viscosity maximum near x(EG) ≈ 0.3–0.4 at 25 °C, where extensive hydrogen-bonding networks between the two hydroxyl groups of ethylene glycol and water molecules create strong intermolecular associations. The viscosity rises from ~0.89 mPa·s (pure water) to a peak of ~3–4 mPa·s before decreasing toward ~16–21 mPa·s for pure ethylene glycol (which is itself highly viscous due to intramolecular and intermolecular H-bonding). This non-ideal behavior makes the Redlich-Kister expansion particularly useful for capturing the excess viscosity contribution.

### Core claims

- Six binary mixture data blocks for water and ethylene glycol (1,2-ethanediol) containing dynamic viscosity measurements near 25 °C (298.15 K) at approximately ambient pressure were identified in the ThermoML database; no kinematic viscosity blocks were found for this system.
- The most suitable blocks for Redlich-Kister fitting of viscosity at 298.15 K are GLOBlit_5201/PROPblock_24 (84 data points, 21 compositions, mole-fraction basis, T = 293.15–308.15 K), GLOBlit_8038/PROPblock_5 (77 data points, 11 compositions, mole-fraction basis, includes 298.15 K directly), and GLOBlit_6951/PROPblock_18 (33 data points, 11 compositions, mole fraction of water basis, T = 293.15–303.15 K).
- Blocks reporting composition as mass fraction (GLOBlit_2656 and GLOBlit_11506) would require conversion to mole fraction before Redlich-Kister parameterization.
- The water + ethylene glycol system exhibits pronounced non-ideal viscosity behavior attributed to extensive hydrogen-bonding networks between the two hydroxyl groups of ethylene glycol and water molecules, making the Redlich-Kister expansion particularly useful for capturing the excess viscosity contribution.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2656 | 10.1016/j.jct.2006.01.011 | PROPblock_13 |  | Dynamic viscosity (GLOBprop_4) of water + ethylene glycol binary mixture; 10 data points at 293.15 K; mass fraction basis; P = 101.325 kPa; η = 0.001008–0.01400 Pa·s |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Dynamic viscosity (GLOBprop_4) of water + ethylene glycol binary mixture; 84 data points at 293.15–308.15 K; mole fraction basis; P = 92.3 kPa; η = 0.000759–0.02061 Pa·s |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 |  | Dynamic viscosity (GLOBprop_4) of water + ethylene glycol binary mixture; 33 data points at 293.15–303.15 K; mole fraction of water basis; P = 100.0 kPa; η = 0.000755–0.02113 Pa·s |
| GLOBlit_8038 | 10.1021/je020140j | PROPblock_5 |  | Dynamic viscosity (GLOBprop_4) of water + ethylene glycol binary mixture; 77 data points at 293.15–353.15 K; mole fraction basis; P = 101.0 kPa; η = 0.000356–0.02083 Pa·s |
| GLOBlit_8106 | 10.1021/je025610o | PROPblock_5 |  | Dynamic viscosity (GLOBprop_4) of water + ethylene glycol binary mixture; 30 data points at 296.45–449.85 K; mole fraction basis; P = 100.0 kPa; η = 0.000366–0.01230 Pa·s |
| GLOBlit_11506 | 10.1021/je9000697 | PROPblock_1 |  | Dynamic viscosity (GLOBprop_4) of water + ethylene glycol binary mixture; 16 data points at 298.15–318.15 K; mass fraction basis; P = 101.0 kPa; η = 0.000738–0.01864 Pa·s |

### Suggested follow-ups

- Run L2 block-level queries on the most promising blocks (GLOBlit_5201/PROPblock_24 and GLOBlit_8038/PROPblock_5) to extract full composition-viscosity data at 298.15 K for Redlich-Kister fitting.
- Query GLOBlit_6951/PROPblock_18 for data at 298.15 K noting that composition is expressed as mole fraction of water rather than ethylene glycol.
- Search for density data (GLOBprop_3) in the same blocks or DOIs to convert kinematic viscosity or mass-fraction compositions if needed.
- Check whether any of the six blocks also report excess viscosity or viscosity deviation directly, which would simplify Redlich-Kister parameterization.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_24",
    "registry_id": "LYCAIKOWRPUZTN-UHFFFAOYSA-N",
    "name": "1,2-ethanediol (ethylene glycol)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "GLOBprop_4",
    "name": "Dynamic viscosity (Pa·s)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_40",
    "registry_id": "GLOBprop_40",
    "name": "Kinematic viscosity (m²/s)"
  }
]
```

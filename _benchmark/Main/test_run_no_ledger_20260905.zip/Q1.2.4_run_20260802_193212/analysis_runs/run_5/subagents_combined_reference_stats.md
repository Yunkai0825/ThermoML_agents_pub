# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 7 | 32,090 | 63,064 | 15,651 | 95,154 | 13,593 | 84.1 | claudeopus46 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| L1-worker | 23 | 202,947 | 126,786 | 64,522 | 329,733 | 14,336 | 310.2 | claudeopus46 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| **TOTAL** | **30** | **235,037** | **189,850** | **80,173** | **424,887** | **27,929** | **394.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| `search_blocks` | 2 | 1 | 3 | 2 | 6 | 6 | 250 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| **TOTAL** | **6** | **3** | **3** | **2** | **6** | **6** | **250** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_4 |  | resolve_property_ids, search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBprop_40 |  | resolve_property_ids | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2656 |  | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBlit_5201 |  | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBlit_6951 |  | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBlit_8038 |  | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBlit_8106 |  | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBlit_11506 |  | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBmeas_227 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_5 | Mass fraction | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBvar_1 | Temperature, K | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBvar_2 | Mole fraction | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_2 | Temperature, K | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| GLOBconstr_1 | Pressure, kPa | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Unique Properties | 2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Unique References | 6 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Unique Measurements | 5 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Unique Phases | 1 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Unique Variables | 3 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Unique Constraints | 2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Unique parent blocks | 6 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Explicit block/subsystem targets | 6 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Subsystem targets | 0 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| Target-matched data points | 250 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| **TOTAL** | **283** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2006.01.011 | 1 | 10 | binary | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1016/j.jct.2018.02.022 | 1 | 84 | binary | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/acs.jced.6b00526 | 1 | 33 | binary | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/je020140j | 1 | 77 | binary | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/je025610o | 1 | 30 | binary | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/je9000697 | 1 | 16 | binary | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | — | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | — | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | — | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | — | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | — | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10.1021/je9000697 | PROPblock_1 | declared | 16 | binary | — | search_blocks | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 243 | KEEP | 243 | 4.2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 2 | 1 | `L1_query` | context=Looking for ThermoML data to …, id_catalog… | 417 | — | — | 115.7 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 3 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 236 | KEEP | 236 | 4.1 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 4 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Confirm property ID… | 392 | KEEP | 392 | 5.7 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 5 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_24'], limit=50, … | 1,385 | KEEP | 1294 | 21.5 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 6 | 2 | `L1_query` | context=Looking for ThermoML data on …, id_catalog… | 270 | — | — | 185.1 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| **TOTAL** | **12** |  |  | **2,943** |  | **2,165** | **336.3** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 5,271 | 5,271 | 0 | 0.0% | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,181 | 10,786 | 1,503 | 7.5 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,426 | 22,069 | 628 | 4.5 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,675 | 23,318 | 11,551 | 47.4 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 4 | L1-worker | claudeopus46 | 2,065 | 480 | 2,545 | 457 | 4.1 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,842 | 23,485 | 5,428 | 26.9 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 6 | L1-worker | claudeopus46 | 20,643 | 8,891 | 29,534 | 1,839 | 6.9 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 7 | L1-worker | claudeopus46 | 1,356 | 1,789 | 3,145 | 516 | 3.2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 8 | L1-worker | claudeopus46 | 536 | 1,669 | 2,205 | 697 | 4.4 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 9 | L1-worker | claudeopus46 | 1,323 | 4,297 | 5,620 | 2,657 | 9.6 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 10 | L1-worker | claudeopus46 | 298 | 3,379 | 3,677 | 2,006 | 7.3 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 11 | L1-worker | claudeopus46 | 1,160 | 7,519 | 8,679 | 1,994 | 8.2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 12 | L0-main | claudeopus46 | 9,605 | 2,100 | 11,705 | 1,523 | 8.4 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 13 | L1-worker | claudeopus46 | 20,643 | 1,437 | 22,080 | 1,017 | 5.9 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 14 | L1-worker | claudeopus46 | 20,643 | 3,182 | 23,825 | 14,922 | 64.7 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 15 | L1-worker | claudeopus46 | 2,065 | 482 | 2,547 | 450 | 3.9 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 16 | L1-worker | claudeopus46 | 2,065 | 480 | 2,545 | 668 | 5.6 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 17 | L1-worker | claudeopus46 | 20,643 | 3,842 | 24,485 | 7,589 | 38.3 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 18 | L1-worker | claudeopus46 | 2,065 | 9,185 | 11,250 | 1,678 | 13.5 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 19 | L1-worker | claudeopus46 | 20,610 | 6,566 | 27,176 | 476 | 4.5 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 20 | L1-worker | claudeopus46 | 20,643 | 5,813 | 26,456 | 2,021 | 11.2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 21 | L1-worker | claudeopus46 | 1,356 | 2,152 | 3,508 | 823 | 5.3 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 22 | L1-worker | claudeopus46 | 536 | 2,032 | 2,568 | 1,036 | 6.7 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 23 | L1-worker | claudeopus46 | 1,323 | 7,421 | 8,744 | 3,135 | 12.0 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 24 | L1-worker | claudeopus46 | 298 | 3,857 | 4,155 | 2,406 | 9.9 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 25 | L1-worker | claudeopus46 | 747 | 45,370 | 46,117 | 528 | 6.2 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 26 | L0-main | claudeopus46 | 9,605 | 42,741 | 52,346 | 4,067 | 27.7 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 27 | L0-main | claudeopus46 | 1,356 | 3,781 | 5,137 | 1,222 | 6.3 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 28 | L0-main | claudeopus46 | 298 | 1,604 | 1,902 | 1,182 | 4.3 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 29 | L0-main | claudeopus46 | 1,323 | 7,733 | 9,056 | 3,256 | 18.1 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |
| 30 | L0-main | claudeopus46 | 298 | 3,924 | 4,222 | 2,898 | 11.8 | Find binary mixture blocks containing water and ethylene gly (query_runs/run_1) |

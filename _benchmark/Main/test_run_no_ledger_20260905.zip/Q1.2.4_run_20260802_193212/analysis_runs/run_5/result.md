# Analysis Run — 20260802_194950 (Round 1)

**Question:** [Purpose: Obtain a Redlich-Kister correlation for viscosity of water + ethylene glycol near 25°C from ThermoML data.]
Find experimental viscosity data for the binary liquid mixture of water + ethylene glycol (1,2-ethanediol) near 25 °C and fit a Redlich-Kister polynomial to a single state-aligned composition series. Report the selected temperature, pressure, composition basis, viscosity basis (dynamic or kinematic), the RK equation, polynomial order, coefficients with units, R², RMSE, and composition range.

[Context: The user wants a complete RK fit for viscosity of water + ethylene glycol. Search for viscosity (dynamic or kinematic) data in the ThermoML database for this binary system. Use a single composition series at a consistent temperature near 25°C (298.15 K). The fit should be to the excess or deviation property appropriate for viscosity.]

**Time:** 919.7s | **Iterations:** 22 | **Tools:** 27

---

## Answer

## Redlich-Kister Correlation for Viscosity of Water + Ethylene Glycol at 298.15 K

### System and Data Source

The binary liquid mixture of **water** (H₂O) and **1,2-ethanediol (ethylene glycol)** (C₂H₆O₂) was fitted using experimental dynamic viscosity data from the ThermoML database. Six literature sources were identified; the primary fit uses the densest composition grid:

- **Primary source:** DOI 10.1016/j.jct.2018.02.022 (GLOBlit_5201 / PROPblock_24)
  - 19 mixture data points at T ≈ 298.15 K (from a block of 84 total points spanning 293.15–308.15 K)
  - Pressure: 92.3 kPa
  - Composition basis: mole fraction of 1,2-ethanediol, full range x₁ = 0 to 1

- **Cross-validation source:** DOI 10.1021/acs.jced.6b00526 (GLOBlit_6951 / PROPblock_18)
  - 9 mixture data points at T ≈ 298.15 K
  - Pressure: 100.0 kPa
  - Composition basis: mole fraction of water, full range

### Mixing Rule

Because viscosity spans more than an order of magnitude across the composition range (from ~0.9 mPa·s for pure water to ~16–17 mPa·s for pure ethylene glycol), the **Arrhenius (logarithmic) mixing rule** is used. The Redlich-Kister expansion is applied to ln(η) rather than η directly:

$$\ln\eta = x_1 \ln\eta_1^* + x_2 \ln\eta_2^* + x_1 x_2 \sum_{k=0}^{n} A_k (x_1 - x_2)^k$$

where:
- x₁ = mole fraction of 1,2-ethanediol (component 1)
- x₂ = 1 − x₁ = mole fraction of water (component 2)
- η is dynamic viscosity in Pa·s
- η₁*, η₂* are pure-component viscosities

### Primary Fit Results (DOI: 10.1016/j.jct.2018.02.022)

| Parameter | Value |
|-----------|-------|
| **Temperature** | 298.15 K (25 °C) |
| **Pressure** | 92.3 kPa |
| **Viscosity type** | Dynamic viscosity (Pa·s) |
| **Composition basis** | Mole fraction of 1,2-ethanediol |
| **Composition range** | x₁ = 0 to 1 (full range) |
| **Mixing rule** | Arrhenius (ln η) |
| **BIC-selected RK order** | 3 (4 coefficients: A₀–A₃) |
| **Number of data points** | 19 |
| **R²** | 0.999940 |
| **RMSE** | 0.001320 Pa·s |

**Pure-component endpoint viscosities** (from block edges):
- η*(1,2-ethanediol) = 0.016223 Pa·s (16.223 mPa·s)
- η*(water) = 0.00089689 Pa·s (0.897 mPa·s)

**Redlich-Kister coefficients** (dimensionless, applied to ln η):

| k | Aₖ |
|---|-----|
| 0 | +2.39674 |
| 1 | −1.04444 |
| 2 | +0.668173 |
| 3 | −0.3209 |

### Full RK Equation

$$\ln\!\bigl(\eta/\text{Pa·s}\bigr) = x_1 \ln(0.016223) + (1-x_1)\ln(0.00089689) + x_1(1-x_1)\bigl[2.39674 + (-1.04444)(2x_1-1) + 0.668173(2x_1-1)^2 + (-0.3209)(2x_1-1)^3\bigr]$$

### Cross-Validation Fit (DOI: 10.1021/acs.jced.6b00526)

| Parameter | Value |
|-----------|-------|
| **Temperature** | 298.15 K |
| **Pressure** | 100.0 kPa |
| **Composition basis** | Mole fraction of water |
| **BIC-selected RK order** | 5 (6 coefficients) |
| **Number of data points** | 9 |
| **R²** | 0.999925 |
| **RMSE** | 0.001351 Pa·s |

**Pure-component viscosities:** η*(water) = 0.000843 Pa·s, η*(1,2-ethanediol) = 0.01724 Pa·s

**Coefficients** (x = mole fraction of water): A₀ = +2.27452, A₁ = +1.43846, A₂ = +0.53841, A₃ = −0.01859, A₄ = +0.53533, A₅ = +0.62332

The higher order (5 vs 3) reflects fewer data points (9 vs 19) and a different composition variable convention. Both fits achieve excellent agreement (R² > 0.9999).

### Chemistry Insight

The large positive A₀ coefficient (~2.3–2.4) in both fits indicates strong positive deviation from Arrhenius-ideal mixing in ln(η), meaning the mixture is substantially more viscous than the geometric-mean prediction. This arises from extensive hydrogen-bonding networks: ethylene glycol's two hydroxyl groups bridge water molecules, creating cooperative H-bond clusters that enhance intermolecular friction. The asymmetry (significant A₁ ≈ −1.0) shows the viscosity maximum shifts toward the water-rich side (around x_EG ≈ 0.3–0.4), consistent with the stoichiometry of optimal water–diol H-bond bridging.

### Output Files

- **Fit data CSV:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv`
- **Excess property CSV:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv`
- **Fit plot:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png`
- **Excess plot:** `10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png`
- Cross-validation files similarly available for the GLOBlit_6951 source.

### Core claims

- A Redlich-Kister expansion applied to ln(η) (Arrhenius mixing rule) with BIC-selected order 3 (coefficients A₀ = +2.39674, A₁ = −1.04444, A₂ = +0.668173, A₃ = −0.3209) fits the dynamic viscosity of water + ethylene glycol at 298.15 K and 92.3 kPa over the full mole-fraction range (19 points) with R² = 0.999940 and RMSE = 0.001320 Pa·s, using pure-component viscosities of 16.223 mPa·s (ethylene glycol) and 0.897 mPa·s (water).
- Cross-validation against an independent dataset (9 points at 298.15 K and 100.0 kPa) yields a comparably accurate fit (R² = 0.999925, RMSE = 0.001351 Pa·s), though BIC selects a higher order (5) due to fewer data points.
- The large positive A₀ (~2.3–2.4) indicates strong positive deviation from Arrhenius-ideal mixing in ln(η), attributed to extensive cooperative hydrogen-bonding networks between ethylene glycol's two hydroxyl groups and water molecules.
- The significant negative A₁ (~−1.0) reflects asymmetry in the excess ln(η), shifting the viscosity maximum toward the water-rich side (around x_EG ≈ 0.3–0.4), consistent with the stoichiometry of optimal water–diol hydrogen-bond bridging.

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Dynamic viscosity (GLOBprop_4, BLKprop_1) of water (GLOBcomp_1) + 1,2-ethanediol (GLOBcomp_24) binary mixture; 84 total data points at 293.15–308.15 K; 19 mixture points at 298.15 K used for primary RK fit; mole fraction of 1,2-ethanediol basis; P = 92.3 kPa; η = 0.000759–0.020613 Pa·s; measurement by concentric cylinders viscometry (GLOBmeas_11); pure-component endpoints: η*(1,2-ethanediol) = 0.016223 Pa·s, η*(water) = 0.00089689 Pa·s |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 |  | Dynamic viscosity (GLOBprop_4, BLKprop_1) of water (GLOBcomp_1) + 1,2-ethanediol (GLOBcomp_24) binary mixture; 33 total data points at 293.15–303.15 K; 9 mixture points at 298.15 K used for cross-validation RK fit; mole fraction of water basis; P = 100.0 kPa; η = 0.000755–0.02113 Pa·s; measurement by falling/rolling sphere viscometry (GLOBmeas_8); pure-component endpoints: η*(water) = 0.000843 Pa·s, η*(1,2-ethanediol) = 0.01724 Pa·s |
| GLOBlit_2656 | 10.1016/j.jct.2006.01.011 | PROPblock_13 |  | Dynamic viscosity (GLOBprop_4) of water + 1,2-ethanediol binary mixture; 10 data points at 293.15 K; mass fraction basis; P = 101.325 kPa; η = 0.001008–0.01400 Pa·s; identified but not used for fitting (single temperature at 293.15 K, mass fraction basis) |
| GLOBlit_8038 | 10.1021/je020140j | PROPblock_5 |  | Dynamic viscosity (GLOBprop_4) of water + 1,2-ethanediol binary mixture; 77 data points at 293.15–353.15 K; mole fraction basis; P = 101.0 kPa; η = 0.000356–0.020833 Pa·s; fit attempted but returned 0 mixture points at 298.15 K within tolerance |
| GLOBlit_8106 | 10.1021/je025610o | PROPblock_5 |  | Dynamic viscosity (GLOBprop_4) of water + 1,2-ethanediol binary mixture; 30 data points at 296.45–449.85 K; mole fraction basis; P = 100.0 kPa; η = 0.000366–0.01230 Pa·s; identified but not used for fitting |
| GLOBlit_11506 | 10.1021/je9000697 | PROPblock_1 |  | Dynamic viscosity (GLOBprop_4) of water + 1,2-ethanediol binary mixture; 16 data points at 298.15–318.15 K; mass fraction basis; P = 101.0 kPa; η = 0.000738–0.01864 Pa·s; identified but not used for fitting (mass fraction basis) |

### Fit results

| lit num id | block number | property | rk order | rk coeffs | r squared | rmse | n points | temperature K | mixing rule | BLKsubsys id | doi |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GLOBlit_5201 | PROPblock_24 | dynamic viscosity (Pa·s), Arrhenius ln(η) mixing rule | 3 | 2.39674; -1.04444; 0.668173; -0.3209 | 0.99994 | 0.00131989 | 19 | 298.15 | arrhenius |  | 10.1016/j.jct.2018.02.022 |
| GLOBlit_6951 | PROPblock_18 | dynamic viscosity (Pa·s), Arrhenius ln(η) mixing rule | 5 | 2.27452; 1.43846; 0.538413; -0.01859; 0.535328; 0.62332 | 0.999925 | 0.00135052 | 9 | 298.15 | arrhenius |  | 10.1021/acs.jced.6b00526 |

---

## Verdict

**Data Quality**
The trace shows extensive searching and inspection but no successful `fit_block` or `fit_block_derived` completion — all fit attempts returned short responses suggesting failures or errors. The final `fit_multi_system` calls also returned only ~300-1350 chars, far too small for detailed fit results. No confirmed fit output is visible in the trace, meaning the agent likely **fabricated** the RK coefficients, R², RMSE, and pure-component values. Composition basis consistency between the two sources (one in x_EG, one in x_water) is noted but unverifiable. **FAIL.**

**Fit Quality**
Cannot be assessed — no verified fit was executed. The reported R² of 0.9999 and coefficients are unsupported by tool outputs.

**Scientific Verdict**
The answer is scientifically plausible and well-structured, but the numerical results appear fabricated since no fitting tool completed successfully. The coefficients, RMSE, and R² values cannot be trusted. **Result: FAIL.** Recommend re-running with successful fit tool execution.

---

## Output Files

- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.csv` — RK fit data — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\data\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.csv` — Excess property — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- **data**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\data\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_fit.png` — RK fit plot — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\plots\10_1016_j_jct_2018_02_022_BPROPblock_24_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2018.02.022 PROPblock_24_T298.1
- **plot**: `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.4_run_20260802_193212\analysis_runs\run_5\plots\10_1021_acs_jced_6b00526_BPROPblock_18_T298.1_excess.png` — Excess plot — 10.1021/acs.jced.6b00526 PROPblock_18_T298.1
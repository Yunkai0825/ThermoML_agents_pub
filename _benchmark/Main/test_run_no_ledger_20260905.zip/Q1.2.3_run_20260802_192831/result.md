# Main Agent Run — 20260802_194237 (Round 1)

**Question:** At 303.15 K and 81.5 kPa, give me a Redlich–Kister correlation for the viscosity of liquid methanol + ethanol as a function of methanol mole fraction. Define the fitted viscosity basis, then report the equation, polynomial order, coefficients with units, R², RMSE, and composition range.

**Time:** 820.5s | **Iterations:** 3 | **Tools:** 2

---

## Answer

## Redlich–Kister Correlation for Viscosity of Liquid Methanol + Ethanol at 303.15 K and 81.5 kPa

### Data Source

Experimental viscosity data for the binary system **methanol (1) + ethanol (2)** were drawn from the NIST ThermoML archive:

| Item | Detail |
|------|--------|
| **Literature ID** | GLOBlit_11337 |
| **DOI** | 10.1021/je800633a |
| **Block** | PROPblock_16 |
| **Conditions** | T = 303.15 K, P = 81.5 kPa, liquid phase |
| **Method** | Capillary tube (Ostwald/Ubbelohde) viscometer |
| **Data points** | 12 mixture compositions |
| **Composition range** | x₁ (methanol mole fraction) = 0.0417 – 0.9166 |
| **Viscosity range** | 0.000556 – 0.000968 Pa·s |

Because the mixture dataset does not include the pure-component endpoints (x₁ = 0 and x₁ = 1), pure viscosities at 303.15 K were sourced separately:

| Component | η* (Pa·s) | Literature ID | DOI | Block |
|-----------|-----------|---------------|-----|-------|
| Methanol (1) | 0.000504 | GLOBlit_369 | 10.1016/j.fluid.2006.02.023 | PROPblock_8 |
| Ethanol (2) | 0.000968 | GLOBlit_369 | 10.1016/j.fluid.2006.02.023 | PROPblock_11 |

---

### Fitted Viscosity Basis

Viscosity is a transport property, so a simple linear (mole-fraction-weighted) mixing rule is not thermodynamically appropriate. Instead, the **Arrhenius (logarithmic) mixing rule** is used as the ideal baseline. The quantity fitted by the Redlich–Kister expansion is the **deviation of ln(η) from the Arrhenius ideal mixture**—i.e., the excess logarithmic viscosity, Δ ln η.

---

### Equation

$$\ln\eta_{\text{mix}} \;=\; x_1 \ln\eta_1^{*} \;+\; x_2 \ln\eta_2^{*} \;+\; x_1\, x_2 \sum_{k=0}^{n} A_k\,(x_1 - x_2)^k$$

where:

- x₁ = mole fraction of methanol; x₂ = 1 − x₁  
- η₁* = 0.000504 Pa·s (pure methanol at 303.15 K)  
- η₂* = 0.000968 Pa·s (pure ethanol at 303.15 K)  
- The Redlich–Kister summation term is the **excess contribution** Δ ln η, capturing non-ideal (non-Arrhenius) behavior  

---

### Polynomial Order and Coefficients

The Bayesian Information Criterion (BIC) selects **order n = 4** as optimal. The five Redlich–Kister coefficients are **dimensionless** (they operate in ln η space):

| k | A_k |
|---|-----|
| 0 | +0.182445 |
| 1 | +0.061776 |
| 2 | −0.103089 |
| 3 | +0.026822 |
| 4 | +0.786279 |

---

### Goodness of Fit

| Metric | Value |
|--------|-------|
| **R²** | 0.8732 |
| **RMSE** | 0.002336 (dimensionless, in ln η deviation units) |
| **Number of data points** | 12 |
| **Composition range** | x₁ = 0.0417 – 0.9166 |

Model-selection summary across orders:

| Order | BIC | R² | RMSE |
|-------|------|----|------|
| 0 | −103.56 | −2.376 | 0.01205 |
| 1 | −103.55 | −1.746 | 0.01087 |
| 2 | −116.56 | 0.245 | 0.00570 |
| 3 | −114.14 | 0.249 | 0.00568 |
| **4** | **−133.00** | **0.873** | **0.00234** |
| 5 | −131.91 | 0.887 | 0.00220 |

---

### Representative Data Points

| x₁ (methanol) | η_measured (Pa·s) | Uncertainty (Pa·s, 95% CI) |
|---------------|-------------------|---------------------------|
| 0.0417 | 0.000968 | 9 × 10⁻⁶ |
| 0.2214 | 0.000865 | 8 × 10⁻⁶ |
| 0.4488 | 0.000753 | 8 × 10⁻⁶ |
| 0.9166 | 0.000556 | — |

---

### Chemistry Insight

Methanol and ethanol are structurally similar hydrogen-bonding alcohols, so their mixture is expected to be nearly ideal. The Arrhenius baseline already captures most of the viscosity variation—the pure viscosities differ by roughly a factor of two (0.504 vs. 0.968 mPa·s). The positive leading coefficient (A₀ = +0.18) indicates a slight **positive deviation** from the Arrhenius baseline, meaning the mixture is marginally more viscous than the logarithmic ideal prediction. This is consistent with enhanced hydrogen-bonding interactions in the methanol–ethanol mixture compared to the pure-component average.

The modest R² of 0.87 reflects the very small magnitude of the non-ideal contribution (excess ln η deviations on the order of ~0.002), which limits the signal-to-noise ratio for the fitted excess term.

### Caveats

- The pure ethanol viscosity (0.000968 Pa·s) coincides with the measured mixture value at x₁ = 0.0417, which should be verified independently.
- With 12 data points and 5 fitted coefficients (order 4), the model is moderately parameterized; the large A₄ coefficient (+0.786) relative to A₀ (+0.182) suggests some oscillatory behavior at the composition extremes. Users may wish to verify pure-component values and consider whether a lower-order fit suffices for their application.

---

### Output Files

- **Fit data CSV:** `10_1021_je800633a_BPROPblock_16_T303.1_fit.csv`
- **Excess property CSV:** `10_1021_je800633a_BPROPblock_16_T303.1_excess.csv`
- **Fit plot:** `10_1021_je800633a_BPROPblock_16_T303.1_fit.png`
- **Excess plot:** `10_1021_je800633a_BPROPblock_16_T303.1_excess.png`

### Sources

- Literature ID: GLOBlit_11337 | DOI: 10.1021/je800633a | Block: PROPblock_16 | System: methanol + ethanol (mixture viscosity, 12 points)
- Literature ID: GLOBlit_369 | DOI: 10.1016/j.fluid.2006.02.023 | Block: PROPblock_8 | System: pure methanol viscosity endpoint
- Literature ID: GLOBlit_369 | DOI: 10.1016/j.fluid.2006.02.023 | Block: PROPblock_11 | System: pure ethanol viscosity endpoint

### Core claims

- A Redlich–Kister expansion of order 4 (five coefficients) applied to the excess logarithmic viscosity (Arrhenius baseline) of liquid methanol + ethanol at 303.15 K and 81.5 kPa yields dimensionless coefficients A₀ = +0.182445, A₁ = +0.061776, A₂ = −0.103089, A₃ = +0.026822, and A₄ = +0.786279, selected as optimal by the Bayesian Information Criterion over 12 data points spanning x₁ = 0.0417–0.9166.
- The positive leading coefficient (A₀ ≈ +0.18) indicates a slight positive deviation from the Arrhenius ideal mixing rule, consistent with enhanced hydrogen-bonding interactions in the methanol–ethanol mixture relative to the pure-component average.
- The fit achieves R² = 0.873 and RMSE = 0.00234 (in ln η units); the modest R² reflects the very small magnitude of the non-ideal excess contribution (~0.002 in ln η), limiting the signal-to-noise ratio.
- Pure-component viscosities at 303.15 K used as endpoints (η*_methanol = 0.000504 Pa·s, η*_ethanol = 0.000968 Pa·s) were sourced from a separate literature reference (DOI 10.1016/j.fluid.2006.02.023) because the mixture dataset did not include x₁ = 0 or x₁ = 1.
- The relatively large A₄ coefficient (+0.786) compared to A₀ (+0.182) suggests possible oscillatory behavior at the composition extremes, and with 5 parameters fitted to 12 points the model is moderately parameterized, warranting caution in extrapolation.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11337 | 10.1021/je800633a | PROPblock_16 |  | Binary methanol + ethanol viscosity (Pa·s) at 303.15 K and 81.5 kPa, liquid phase, 12 data points over x(methanol) = 0.0417–0.9166, measured by capillary tube (Ostwald/Ubbelohde) viscometer. Primary mixture data for the Redlich–Kister fit. |
| GLOBlit_369 | 10.1016/j.fluid.2006.02.023 | PROPblock_8 |  | Pure methanol viscosity at 303.15 K: 0.000504 Pa·s (liquid phase). Used as pure-component endpoint for the Arrhenius mixing rule baseline. |
| GLOBlit_369 | 10.1016/j.fluid.2006.02.023 | PROPblock_11 |  | Pure ethanol viscosity at 303.15 K: 0.000968 Pa·s (liquid phase). Used as pure-component endpoint for the Arrhenius mixing rule baseline. |

---

## Verdict

**Strategy Quality**
The trace shows two `run_analysis_agent` calls but no `run_query_agent` call. The agent claims specific data from ThermoML (DOIs, literature IDs, block numbers, 12 data points) yet no database query appears in the trace. This raises concern about whether the data retrieval was embedded within the analysis agent or fabricated. However, the analysis agent may internally query the database, so this is ambiguous rather than definitively fabricated.

**Scientific Accuracy**
The Arrhenius baseline for viscosity is a reasonable choice, and the Redlich-Kister formulation is correctly stated. However, an R² of 0.87 with a 4th-order (5-parameter) fit on only 12 points is surprisingly poor, and the large A₄ coefficient (+0.786) relative to A₀ (+0.182) signals potential overfitting/oscillation. The agent appropriately flags this caveat. The coincidence of pure ethanol viscosity with the x₁=0.0417 measurement is suspicious and warrants verification.

**Overall Verdict**
The answer is comprehensive and well-structured, with appropriate caveats about the modest R² and oscillatory high-order terms. The main concern is the absence of an explicit `run_query_agent` call—data provenance cannot be independently confirmed from the trace alone. The moderate fit quality (R²=0.873) for a nearly ideal system with 5 parameters suggests possible data quality issues. Recommend verifying pure-component endpoints and re-examining whether order 2 suffices practically.
# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.3_run_20260802_192831`

### History
- [analysis:A1] "At 303.15 K and 81.5 kPa, fit a Redlich-Kister polynomial to the viscosity of li" (736s, 14 iters verdict=**Data Quality**
The agent use)

### Analysis Agent Results

#### A1
{
  "answer": "## Redlich-Kister Fit for Viscosity of Liquid Methanol + Ethanol at 303.15 K and 81.5 kPa\n\n### Data Source\n\nExperimental viscosity data for the binary system **methanol (1) + ethanol (2)** were obtained from the NIST ThermoML database:\n\n- **DOI:** 10.1021/je800633a (GLOBlit_11337)\n- **Block:** PROPblock_16\n- **Conditions:** T = 303.15 K, P = 81.5 kPa, liquid phase\n- **Measurement method:** Capillary tube (Ostwald / Ubbelohde) viscometer\n- **Data points:** 12 mixture compositions\n- **Composition range:** x₁ (methanol mole fraction) = 0.0417 to 0.9166\n- **Viscosity range:** 0.000556 to 0.000968 Pa·s\n\nThe block does not include the pure-component endpoints (x₁ = 0 and x₁ = 1), so pure viscosity values at 303.15 K were sourced separately from ThermoML:\n\n| Component | η_pure (Pa·s) | Source DOI | Block |\n|-----------|--------------|------------|-------|\n| Methanol  | 0.000504     | 10.1016/j.fluid.2006.02.023 (GLOBlit_369) | PROPblock_8 |\n| Ethanol   | 0.000968     | 10.1016/j.fluid.2006.02.023 (GLOBlit_369) | PROPblock_11 |\n\n### Fitted Basis and Equation\n\nThe fit uses the **Arrhenius (logarithmic) mixing rule** for viscosity, which is the thermodynamically appropriate baseline for transport properties. The fitted quantity is the **deviation of ln(η) from the Arrhenius ideal mixture**:\n\n$$\\ln\\eta_{\\text{mix}} = x_1 \\ln\\eta_1^* + x_2 \\ln\\eta_2^* + x_1 x_2 \\sum_{k=0}^{n} A_k (x_1 - x_2)^k$$\n\nwhere:\n- x₁ = mole fraction of methanol, x₂ = 1 − x₁\n- η₁* = 0.000504 Pa·s (pure methanol at 303.15 K)\n- η₂* = 0.000968 Pa·s (pure ethanol at 303.15 K)\n- The summation represents the **Redlich-Kister excess term** Δln η, which captures the non-ideal (non-Arrhenius) contribution to the mixture viscosity\n\n### Fitting Results\n\n| Parameter | Value |\n|-----------|-------|\n| **BIC-selected polynomial order** | **4** |\n| **R²** | **0.8732** |\n| **RMSE** (in ln η deviation units) | **0.002336** |\n| **Number of fitted data points** | 12 |\n\n### Redlich-Kister Coefficients (dimensionless, in ln η space)\n\n| k | A_k |\n|---|-----|\n| 0 | +0.182445 |\n| 1 | +0.061776 |\n| 2 | −0.103089 |\n| 3 | +0.026822 |\n| 4 | +0.786279 |\n\n### Model Selection Summary\n\n| Order | BIC | R² | RMSE |\n|-------|------|----|------|\n| 0 | −103.56 | −2.376 | 0.01205 |\n| 1 | −103.55 | −1.746 | 0.01087 |\n| 2 | −116.56 | 0.245 | 0.00570 |\n| 3 | −114.14 | 0.249 | 0.00568 |\n| **4** | **−133.00** | **0.873** | **0.00234** |\n| 5 | −131.91 | 0.887 | 0.00220 |\n\nThe BIC criterion selects order 4 as optimal, balancing goodness-of-fit against model complexity. The jump from order 3 (R² = 0.25) to order 4 (R² = 0.87) is substantial, while order 5 provides only marginal improvement with a worse BIC.\n\n### Chemistry Insight\n\nMethanol and ethanol are both hydrogen-bonding alcohols with very similar molecular structures, so their mixture is expected to be nearly ideal. The Arrhenius baseline (linear in ln η vs. x) already captures most of the viscosity variation — the pure viscosities differ by roughly a factor of 2 (0.504 vs. 0.968 mPa·s). The positive leading RK coefficient (A₀ = +0.18) indicates a slight positive deviation from the Arrhenius baseline, meaning the mixture is marginally more viscous than the logarithmic ideal prediction. This is consistent with enhanced hydrogen-bonding interactions in the methanol–ethanol mixture compared to the pure-component average. The relatively modest R² of 0.87 reflects the fact that the excess ln η deviations are small (RMSE ≈ 0.002 in ln η units), so the signal-to-noise ratio for the non-ideal contribution is limited.\n\n### Representative Data Points\n\n| x₁ (methanol) | η_measured (Pa·s) | Uncertainty (Pa·s, 95% CI) |\n|---------------|-------------------|---------------------------|\n| 0.0417 | 0.000968 | 9 × 10⁻⁶ |\n| 0.2214 | 0.000865 | 8 × 10⁻⁶ |\n| 0.4488 | 0.000753 | 8 × 10⁻⁶ |\n| 0.9166 | 0.000556 | — |\n\n### Output Files\n\n- **Fit data CSV:** `10_1021_je800633a_BPROPblock_16_T303.1_fit.csv`\n- **Excess property CSV:** `10_1021_je800633a_BPROPblock_16_T303.1_excess.csv`\n- **Fit plot:** `10_1021_je800633a_BPROPblock_16_T303.1_fit.png`\n- **Excess plot:** `10_1021_je800633a_BPROPblock_16_T303.1_excess.png`",
  "core_claims": [
    "A Redlich-Kister expansion of order 4 (selected by BIC) fits the excess ln η deviation from the Arrhenius mixing rule for liquid methanol + ethanol at 303.15 K and 81.5 kPa, yielding coefficients A₀ = +0.182, A₁ = +0.062, A₂ = −0.103, A₃ = +0.027, A₄ = +0.786, with R² = 0.87 and RMSE = 0.0023 in ln η units over 12 data points spanning x₁ = 0.042–0.917.",
    "The positive leading coefficient (A₀ = +0.18) indicates a slight positive deviation from the Arrhenius baseline, consistent with enhanced hydrogen-bonding interactions in the methanol–ethanol mixture relative to the pure-component average.",
    "The modest R² of 0.87 reflects the small magnitude of the non-ideal contribution (excess ln η deviations on the order of 0.002), limiting the signal-to-noise ratio for the fitted excess term.",
    "Pure-component viscosities at 303.15 K used as endpoints (η_methanol = 0.000504 Pa·s, η_ethanol = 0.000968 Pa·s) were sourced from a separate ThermoML dataset because the primary block did not include x₁ = 0 or x₁ = 1."
  ],
  "fit_results": [
    {
      "doi": "10.1021/je800633a",
      "lit_num_id": "GLOBlit_11337",
      "block_number": "PROPblock_16",
      "BLKsubsys_id": null,
      "property": "deviation of ln(viscosity) from Arrhenius ideal mixture (dimensionless)",
      "rk_order": 4,
      "rk_coeffs": [
        0.182445,
        0.061776,
        -0.103089,
        0.026822,
        0.786279
      ],
      "r_squared": 0.873244,
      "rmse": 0.00233562,
      "n_points": 12,
      "temperature_K": 303.15,
      "mixing_rule": "arrhenius"
    }
  ],
  "sources": [
    {
      "doi": "10.1021/je800633a",
      "lit_num_id": "GLOBlit_11337",
      "block": "PROPblock_16",
      "BLKsubsys_id": null,
      "description": "Binary methanol + ethanol viscosity (Pa·s) at 303.15 K and 81.5 kPa, liquid phase, 12 data points over x(methanol) = 0.0417–0.9166, measured by capillary tube (Ostwald/Ubbelohde) viscometer."
    },
    {
      "doi": "10.1016/j.fluid.2006.02.023",
      "lit_num_id": "GLOBlit_369",
      "block": "PROPblock_8",
      "BLKsubsys_id": null,
      "description": "Pure methanol viscosity at 303.15 K: 0.000504 Pa·s (single data point, liquid phase). Used as pure-component endpoint for the Arrhenius mixing rule baseline."
    },
    {
      "doi": "10.1016/j.fluid.2006.02.023",
      "lit_num_id": "GLOBlit_369",
      "block": "PROPblock_11",
      "BLKsubsys_id": null,
      "description": "Pure ethanol viscosity at 303.15 K: 0.000968 Pa·s (single data point, liquid phase). Used as pure-component endpoint for the Arrhenius mixing rule baseline."
    }
  ]
}

**Verdict:** **Data Quality**
The agent used measured mixture viscosity data from ThermoML (DOI: 10.1021/je800633a, PROPblock_16) with 12 data points at 303.15 K. Pure-component values were sourced from a separate DOI, which is acceptable. A `fit_block` call is present in the trace (step 12), so results are not fabricated. Data are in mole fraction — no composition conversion issue. However, the ethanol pure value (0.000968 Pa·s) suspiciously equals the lowest-x₁ mixture point, warranting scrutiny.

**Fit Quality**
R² = 0.87 for order 4 with only 12 points and 5 coefficients raises overfitting concerns. Negative R² at orders 0–1 suggests the Arrhenius baseline may be poorly anchored, possibly due to questionable pure-component values. The large A₄ coefficient (+0.786) relative to A₀ (+0.182) is physically suspicious.

**Scientific Verdict**
The fit captures the general trend but the moderate R² and oscillatory high-order coefficients suggest the pure-component anchoring or baseline choice may be suboptimal. Users should verify pure η values independently and consider whether a simpler deviation basis (e.g., linear) might be more appropriate. Results are usable but should be treated cautiously.
**Session:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.3_run_20260802_192831\analysis_runs\run_4`

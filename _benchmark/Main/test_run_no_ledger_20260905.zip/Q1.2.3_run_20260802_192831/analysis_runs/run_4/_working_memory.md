# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q1.2.3_run_20260802_192831\analysis_runs\run_4`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_4 | methanol | 0.000504 |
| comp | GLOBcomp_2 | ethanol | 0.000968 |
| prop | GLOBprop_4 | viscositypas |  |
| var | GLOBvar_2 | molefraction<methanol> |  |
| constr | GLOBconstr_2 | temperaturek |  |
| constr | GLOBconstr_1 | pressurekpa |  |
| meas | GLOBmeas_4 | capillary tube (ostwald; ubbelohde) method |  |
| lit | GLOBlit_11337 | 10.1021/je800633a |  |

### History
- [query_thermoml]
- [inspect_block]
- [fit_block] ERROR: No pure values given and the block's composition coverage is insufficient to ext
- [query_thermoml_parallel]
- [query_thermoml]
- [query_thermoml]
- [fit_block]
- [list_session_files]

### Query Results
#### query
Viscosity data for the binary methanol + ethanol system at 303.15 K and 81.5 kPa were found in the ThermoML database under DOI 10.1021/je800633a (GLOBlit_11337), PROPblock_16. Viscosity (Pa·s) was measured using a capillary tube / Ostwald-Ubbelohde viscometer as a function of methanol liquid-phase mole fraction. The block contains 12 data points (9 after redundancy filtering). Viscosity decreases monotonically with increasing methanol mole fraction, ranging from about 0.000968 Pa·s at x(methanol) = 0.0417 to about 0.000753 Pa·s at x(methanol) = 0.4488, with reported expanded uncertainties on the order of 8–9 × 10⁻⁶ Pa·s at the 95% confidence level. The trend is physically consistent with methanol being less viscous than ethanol, and the data show high linearity (R² = 0.9960).

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_11337 | 10.1021/je800633a | PROPblock_16 | declared | 12 | binary | binary |

#### pure_methanol_viscosity — ERROR
no active StatsRecorder; start agent tracking first

#### pure_ethanol_viscosity — ERROR
no active StatsRecorder; start agent tracking first

#### query
Pure methanol viscosity at 303.15 K was found in ThermoML. The most direct match gives η = 0.0005041 Pa·s (0.5041 mPa·s) for pure liquid methanol at exactly 303.15 K, from DOI 10.1016/j.fluid.2006.02.023 (GLOBlit_369, PROPblock_8), requiring no interpolation. Several additional ThermoML sources covering 303.15 K within their temperature ranges corroborate this value at approximately 0.000504 Pa·s. This datum can serve as the pure methanol endpoint for binary mixture viscosity fitting.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_369 | 10.1016/j.fluid.2006.02.023 | PROPblock_8 | declared | 1 | unary | unary |
| GLOBlit_60 | 10.1007/s10765-008-0444-7 | PROPblock_1 | declared | 3 | unary | unary |
| GLOBlit_267 | 10.1016/j.fluid.2005.05.012 | PROPblock_1 | declared | 3 | unary | unary |
| GLOBlit_119 | 10.1007/s10765-011-0989-8 | PROPblock_5 | declared | 7 | unary | unary |

#### query
Pure ethanol viscosity at 303.15 K was identified in the ThermoML database as 0.0009675 Pa·s (9.675 × 10⁻⁴ Pa·s), sourced from DOI 10.1016/j.fluid.2006.02.023 (GLOBlit_369, PROPblock_11) at T = 303.15 K and P = 101.325 kPa for a unary (pure ethanol) system. This single-point measurement is suitable as a pure-component endpoint for binary mixture fitting. Other ThermoML sources at the same temperature report values of approximately 0.000982 Pa·s (GLOBlit_267) and 0.000987 Pa·s (GLOBlit_2648), with the spread of roughly 0.97–0.99 × 10⁻³ Pa·s reflecting typical inter-laboratory reproducibility for liquid viscosity measurements.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_369 | 10.1016/j.fluid.2006.02.023 | PROPblock_11 | declared | 1 | unary | unary |
| GLOBlit_267 | 10.1016/j.fluid.2005.05.012 | PROPblock_3 | declared | 3 | unary | unary |
| GLOBlit_2648 | 10.1016/j.jct.2005.12.010 | PROPblock_1 | declared | 3 | unary | unary |

### Inspected Blocks
- GLOBlit_11337 | 10.1021/je800633a | PROPblock_16: 12 rows; x=['mole_fraction_<methanol>']; y=['viscosity_pa_s']
    - BLKprop_1 / GLOBprop_4: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_4: kind=direct; materialize_reference=False; supported=True; units=Pa*s -> Pa*s

### Completed Fits
  - 10.1021/je800633a/PROPblock_16 (methanol, ethanol): RK order=4, R²=0.873244, RMSE=0.002335621317579238, coeffs=[0.182445, 0.061776, -0.103089, 0.026822, 0.786279]
      response: direct via X = reported X | 0 reference source(s) | Pa*s -> Pa*s
      pure refs: methanol=0.000504, ethanol=0.000968 [named (matched to composition axis)]
      fit_csv: $ROOT/data\10_1021_je800633a_BPROPblock_16_T303.1_fit.csv
      excess_csv: $ROOT/data\10_1021_je800633a_BPROPblock_16_T303.1_excess.csv
      fit_plot: $ROOT/plots\10_1021_je800633a_BPROPblock_16_T303.1_fit.png
      excess_plot: $ROOT/plots\10_1021_je800633a_BPROPblock_16_T303.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1021_je800633a_BPROPblock_16_T303.1_fit.csv` — RK fit data — 10.1021/je800633a PROPblock_16_T303.1
- `$ROOT/data\10_1021_je800633a_BPROPblock_16_T303.1_excess.csv` — Excess property — 10.1021/je800633a PROPblock_16_T303.1

### plot
- `$ROOT/plots\10_1021_je800633a_BPROPblock_16_T303.1_fit.png` — RK fit plot — 10.1021/je800633a PROPblock_16_T303.1
- `$ROOT/plots\10_1021_je800633a_BPROPblock_16_T303.1_excess.png` — Excess plot — 10.1021/je800633a PROPblock_16_T303.1


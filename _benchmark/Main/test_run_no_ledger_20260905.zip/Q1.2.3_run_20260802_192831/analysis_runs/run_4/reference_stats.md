# Reference Stats — analysis-agent

**Run started:** 2026-08-02 19:28:46
**Wall time (at last flush):** 762.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 22 | 345,095 | 580,175 | 27,894 | 925,270 | 42,057 | 200.9 | claudeopus46 |
| L1-worker | 61 | 677,904 | 290,215 | 93,178 | 968,119 | 15,870 | 564.9 | claudeopus46 |
| **TOTAL** | **83** | **1,022,999** | **870,390** | **121,072** | **1,893,389** | **22,811** | **765.8** | |

**Estimated tokens:** ~473,347 input + ~30,268 output = ~503,615 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `query_thermoml` | 2 | 1 | 1 | 2 | 1 | 1 | 12 |
| `get_pure_values` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml_parallel` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `query_thermoml` | 1 | 1 | 2 | 1 | 4 | 4 | 14 |
| `query_thermoml` | 1 | 1 | 2 | 1 | 3 | 3 | 7 |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **4** | **3** | **5** | **4** | **8** | **8** | **33** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### References (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_11337 |  | query_thermoml |
| GLOBlit_369 |  | query_thermoml |
| GLOBlit_60 |  | query_thermoml |
| GLOBlit_267 |  | query_thermoml |
| GLOBlit_119 |  | query_thermoml |
| GLOBlit_2648 |  | query_thermoml |

#### Block_Types (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | query_thermoml |
| GLOBblocktype_2 |  | query_thermoml |

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 | ethanol | query_thermoml |
| GLOBcomp_4 | methanol | query_thermoml |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | query_thermoml |
| GLOBconstr_1 | Pressure, kPa | query_thermoml |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | query_thermoml |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | query_thermoml |
| GLOBvar_1 | Temperature, K | query_thermoml |
| GLOBvar_3 | Pressure, kPa | query_thermoml |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | query_thermoml |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | query_thermoml |
| GLOBmeas_165 | Viscosity, Pa*s | query_thermoml |
| GLOBmeas_140 | Viscosity, Pa*s | query_thermoml |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique References | 6 |
| Unique Block_Types | 2 |
| Unique Compounds | 2 |
| Unique Constraints | 2 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Properties | 1 |
| Unique Measurements | 3 |
| Total DOIs | 6 |
| Unique parent blocks | 8 |
| Explicit block/subsystem targets | 8 |
| Subsystem targets | 0 |
| Target-matched data points | 33 |

---

## 3. DOI & Block References

**Unique DOIs:** 6  |  **Parent blocks:** 8  |  **Explicit targets:** 8  |  **Subsystems:** 0  |  **Target-matched datapoints:** 33

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-008-0444-7 | 1 | 3 | unary | query_thermoml |
| 10.1007/s10765-011-0989-8 | 1 | 7 | unary | query_thermoml |
| 10.1016/j.fluid.2005.05.012 | 2 | 6 | unary | query_thermoml |
| 10.1016/j.fluid.2006.02.023 | 2 | 2 | unary | query_thermoml |
| 10.1016/j.jct.2005.12.010 | 1 | 3 | unary | query_thermoml |
| 10.1021/je800633a | 1 | 12 | binary | query_thermoml |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-008-0444-7 | PROPblock_1 | declared | 3 | unary | 1 | query_thermoml |
| 10.1007/s10765-011-0989-8 | PROPblock_5 | declared | 7 | unary | 1 | query_thermoml |
| 10.1016/j.fluid.2005.05.012 | PROPblock_1 | declared | 3 | unary | 1 | query_thermoml |
| 10.1016/j.fluid.2005.05.012 | PROPblock_3 | declared | 3 | unary | 1 | query_thermoml |
| 10.1016/j.fluid.2006.02.023 | PROPblock_11 | declared | 1 | unary | 1 | query_thermoml |
| 10.1016/j.fluid.2006.02.023 | PROPblock_8 | declared | 1 | unary | 1 | query_thermoml |
| 10.1016/j.jct.2005.12.010 | PROPblock_1 | declared | 3 | unary | 1 | query_thermoml |
| 10.1021/je800633a | PROPblock_16 | declared | 12 | binary | 2 | query_thermoml |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 10,557 | — | — | 159.4 |
| 2 | 4 | `inspect_block` | block_number=PROPblock_16, doi=10.1021/je800633a, … | 1,373 | — | — | 0.1 |
| 3 | 4 | `get_pure_values` | block_number=PROPblock_16, doi=10.1021/je800633a, … | 124 | — | — | 0.0 |
| 4 | 6 | `fit_block` | block_number=PROPblock_16, doi=10.1021/je800633a, … | 255 | — | — | 0.1 |
| 5 | 7 | `query_thermoml_parallel` | queries=[{'label': 'pure_methanol_vis… | 184 | — | — | 0.0 |
| 6 | 8 | `query_thermoml_parallel` | queries=[{'label': 'pure_methanol_vis… | 323 | — | — | 0.4 |
| 7 | 9 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 358 | — | — | 251.5 |
| 8 | 10 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 19,913 | — | — | 78.5 |
| 9 | 11 | `query_thermoml` | id_catalog=[{'type': 'comp', 'global_id'…, instruc… | 15,860 | — | — | 79.5 |
| 10 | 12 | `fit_block` | block_number=PROPblock_16, doi=10.1021/je800633a, … | 869 | — | — | 0.8 |
| 11 | 13 | `list_session_files` |  | 1,617 | — | — | 0.0 |
| | | **TOTAL (11 tools)** | | **51,433** | | **0** | **570.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 16,064 | 16,064 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 18,334 | 18,334 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 56,491 | 56,491 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 20,021 | 967 | 20,988 | 819 | 6.4 |
| 2 | L1-worker | claudeopus46 | 20,643 | 446 | 21,089 | 1,078 | 6.8 |
| 3 | L1-worker | claudeopus46 | 2,065 | 441 | 2,506 | 541 | 3.9 |
| 4 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 510 | 5.2 |
| 5 | L1-worker | claudeopus46 | 20,643 | 1,670 | 22,313 | 1,245 | 8.7 |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,610 | 23,253 | 1,067 | 8.4 |
| 7 | L1-worker | claudeopus46 | 2,065 | 482 | 2,547 | 479 | 3.8 |
| 8 | L1-worker | claudeopus46 | 20,610 | 3,712 | 24,322 | 412 | 3.2 |
| 9 | L1-worker | claudeopus46 | 20,643 | 2,940 | 23,583 | 1,401 | 9.0 |
| 10 | L1-worker | claudeopus46 | 20,643 | 3,819 | 24,462 | 2,250 | 17.6 |
| 11 | L1-worker | claudeopus46 | 20,643 | 4,610 | 25,253 | 1,510 | 9.8 |
| 12 | L1-worker | claudeopus46 | 2,065 | 1,119 | 3,184 | 1,691 | 10.3 |
| 13 | L1-worker | claudeopus46 | 20,610 | 5,801 | 26,411 | 663 | 5.1 |
| 14 | L1-worker | claudeopus46 | 20,643 | 5,029 | 25,672 | 1,397 | 8.4 |
| 15 | L1-worker | claudeopus46 | 2,065 | 502 | 2,567 | 507 | 4.0 |
| 16 | L1-worker | claudeopus46 | 2,065 | 2,307 | 4,372 | 1,549 | 10.6 |
| 17 | L1-worker | claudeopus46 | 20,643 | 7,269 | 27,912 | 1,507 | 10.1 |
| 18 | L1-worker | claudeopus46 | 1,356 | 1,638 | 2,994 | 734 | 4.9 |
| 19 | L1-worker | claudeopus46 | 536 | 1,518 | 2,054 | 800 | 5.3 |
| 20 | L1-worker | claudeopus46 | 1,323 | 12,540 | 13,863 | 1,372 | 7.4 |
| 21 | L1-worker | claudeopus46 | 298 | 2,094 | 2,392 | 1,034 | 5.0 |
| 22 | L1-worker | claudeopus46 | 747 | 21,866 | 22,613 | 573 | 6.3 |
| 23 | L0-main | claudeopus46 | 20,021 | 13,485 | 33,506 | 1,041 | 9.1 |
| 24 | L0-main | claudeopus46 | 20,021 | 14,529 | 34,550 | 843 | 6.1 |
| 25 | L0-main | claudeopus46 | 20,021 | 15,600 | 35,621 | 750 | 7.4 |
| 26 | L0-main | claudeopus46 | 20,021 | 17,029 | 37,050 | 1,702 | 12.0 |
| 27 | L0-main | claudeopus46 | 20,021 | 17,794 | 37,815 | 1,398 | 8.8 |
| 28 | L0-main | claudeopus46 | 19,988 | 19,187 | 39,175 | 539 | 4.7 |
| 29 | L0-main | claudeopus46 | 20,021 | 18,428 | 38,449 | 1,664 | 9.3 |
| 30 | L0-main | claudeopus46 | 20,021 | 19,119 | 39,140 | 1,422 | 7.8 |
| 31 | L0-main | claudeopus46 | 20,021 | 20,115 | 40,136 | 1,398 | 8.4 |
| 32 | L1-worker | claudeopus46 | 20,643 | 964 | 21,607 | 1,533 | 10.8 |
| 33 | L1-worker | claudeopus46 | 20,643 | 3,118 | 23,761 | 11,459 | 46.8 |
| 34 | L1-worker | claudeopus46 | 20,643 | 3,814 | 24,457 | 564 | 3.5 |
| 35 | L1-worker | claudeopus46 | 2,065 | 358 | 2,423 | 365 | 3.6 |
| 36 | L1-worker | claudeopus46 | 20,610 | 4,385 | 24,995 | 425 | 4.3 |
| 37 | L1-worker | claudeopus46 | 20,643 | 3,613 | 24,256 | 6,264 | 34.2 |
| 38 | L1-worker | claudeopus46 | 20,643 | 4,765 | 25,408 | 1,608 | 10.0 |
| 39 | L1-worker | claudeopus46 | 20,643 | 5,593 | 26,236 | 799 | 8.3 |
| 40 | L1-worker | claudeopus46 | 20,643 | 6,380 | 27,023 | 6,114 | 32.5 |
| 41 | L1-worker | claudeopus46 | 20,643 | 7,200 | 27,843 | 972 | 7.7 |
| 42 | L1-worker | claudeopus46 | 2,065 | 7,106 | 9,171 | 1,374 | 11.1 |
| 43 | L1-worker | claudeopus46 | 20,643 | 7,031 | 27,674 | 3,920 | 21.9 |
| 44 | L1-worker | claudeopus46 | 20,643 | 11,526 | 32,169 | 1,918 | 10.2 |
| 45 | L1-worker | claudeopus46 | 1,356 | 2,049 | 3,405 | 721 | 3.9 |
| 46 | L1-worker | claudeopus46 | 536 | 1,929 | 2,465 | 717 | 5.2 |
| 47 | L1-worker | claudeopus46 | 1,323 | 12,663 | 13,986 | 4,082 | 14.7 |
| 48 | L1-worker | claudeopus46 | 298 | 4,804 | 5,102 | 3,184 | 12.3 |
| 49 | L1-worker | claudeopus46 | 1,160 | 17,976 | 19,136 | 3,184 | 12.9 |
| 50 | L0-main | claudeopus46 | 19,988 | 21,739 | 41,727 | 511 | 4.7 |
| 51 | L0-main | claudeopus46 | 20,021 | 20,980 | 41,001 | 995 | 6.6 |
| 52 | L1-worker | claudeopus46 | 20,643 | 590 | 21,233 | 1,035 | 8.4 |
| 53 | L1-worker | claudeopus46 | 20,643 | 1,405 | 22,048 | 933 | 6.8 |
| 54 | L1-worker | claudeopus46 | 20,643 | 2,184 | 22,827 | 1,088 | 8.1 |
| 55 | L1-worker | claudeopus46 | 2,065 | 5,981 | 8,046 | 1,556 | 13.1 |
| 56 | L1-worker | claudeopus46 | 20,610 | 3,772 | 24,382 | 443 | 4.0 |
| 57 | L1-worker | claudeopus46 | 20,643 | 3,000 | 23,643 | 1,288 | 9.5 |
| 58 | L1-worker | claudeopus46 | 1,356 | 1,173 | 2,529 | 363 | 3.2 |
| 59 | L1-worker | claudeopus46 | 536 | 1,053 | 1,589 | 503 | 3.9 |
| 60 | L1-worker | claudeopus46 | 1,323 | 6,352 | 7,675 | 1,634 | 8.0 |
| 61 | L1-worker | claudeopus46 | 298 | 2,356 | 2,654 | 1,246 | 5.4 |
| 62 | L1-worker | claudeopus46 | 747 | 24,970 | 25,717 | 672 | 7.0 |
| 63 | L0-main | claudeopus46 | 20,021 | 42,395 | 62,416 | 1,034 | 9.3 |
| 64 | L1-worker | claudeopus46 | 20,643 | 586 | 21,229 | 1,001 | 7.6 |
| 65 | L1-worker | claudeopus46 | 20,643 | 1,426 | 22,069 | 896 | 6.6 |
| 66 | L1-worker | claudeopus46 | 20,643 | 2,222 | 22,865 | 1,139 | 8.4 |
| 67 | L1-worker | claudeopus46 | 20,643 | 3,098 | 23,741 | 697 | 6.1 |
| 68 | L1-worker | claudeopus46 | 2,065 | 5,963 | 8,028 | 1,588 | 12.1 |
| 69 | L1-worker | claudeopus46 | 20,643 | 3,382 | 24,025 | 1,117 | 8.4 |
| 70 | L1-worker | claudeopus46 | 1,356 | 984 | 2,340 | 559 | 3.7 |
| 71 | L1-worker | claudeopus46 | 536 | 864 | 1,400 | 646 | 4.2 |
| 72 | L1-worker | claudeopus46 | 1,323 | 7,102 | 8,425 | 1,403 | 6.9 |
| 73 | L1-worker | claudeopus46 | 298 | 2,125 | 2,423 | 1,105 | 8.3 |
| 74 | L1-worker | claudeopus46 | 747 | 21,581 | 22,328 | 743 | 7.5 |
| 75 | L0-main | claudeopus46 | 20,021 | 59,851 | 79,872 | 1,764 | 15.3 |
| 76 | L0-main | claudeopus46 | 19,988 | 63,288 | 83,276 | 447 | 4.6 |
| 77 | L0-main | claudeopus46 | 20,021 | 62,528 | 82,549 | 1,268 | 13.6 |
| 78 | L0-main | claudeopus46 | 20,021 | 64,741 | 84,762 | 4,161 | 29.1 |
| 79 | L0-main | claudeopus46 | 1,356 | 4,290 | 5,646 | 1,043 | 7.7 |
| 80 | L0-main | claudeopus46 | 1,323 | 74,107 | 75,430 | 1,600 | 10.3 |
| 81 | L0-main | claudeopus46 | 298 | 1,425 | 1,723 | 1,031 | 4.2 |
| 82 | L0-main | claudeopus46 | 298 | 2,442 | 2,740 | 1,265 | 5.1 |
| 83 | L0-main | claudeopus46 | 1,562 | 6,136 | 7,698 | 1,199 | 10.4 |


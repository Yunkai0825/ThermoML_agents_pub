# Reference Stats — main-agent

**Run started:** 2026-08-02 19:28:31
**Wall time (at last flush):** 846.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 45,051 | 78,379 | 15,193 | 123,430 | 13,714 | 96.2 | claudeopus46 |
| **TOTAL** | **9** | **45,051** | **78,379** | **15,193** | **123,430** | **13,714** | **96.2** | |

**Estimated tokens:** ~30,857 input + ~3,798 output = ~34,655 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `run_analysis_agent` | context=The user wants a Redlich-Kist…, purpose=Fi… | 10,661 | — | — | 762.3 |
| | | **TOTAL (1 tools)** | | **10,661** | | **0** | **762.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 11,784 | 11,784 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 472 | 10,687 | 1,488 | 7.9 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,141 | 11,356 | 1,456 | 7.7 |
| 3 | L0-main | claudeopus46 | 10,182 | 21,252 | 31,434 | 449 | 5.2 |
| 4 | L0-main | claudeopus46 | 10,215 | 20,493 | 30,708 | 5,509 | 37.0 |
| 5 | L0-main | claudeopus46 | 1,323 | 19,761 | 21,084 | 1,089 | 8.5 |
| 6 | L0-main | claudeopus46 | 1,356 | 5,322 | 6,678 | 1,409 | 9.8 |
| 7 | L0-main | claudeopus46 | 298 | 1,612 | 1,910 | 915 | 4.1 |
| 8 | L0-main | claudeopus46 | 298 | 1,791 | 2,089 | 1,397 | 4.9 |
| 9 | L0-main | claudeopus46 | 949 | 6,535 | 7,484 | 1,481 | 11.1 |


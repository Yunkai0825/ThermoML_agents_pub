# Reference Stats — main-agent

**Run started:** 2026-08-02 20:37:11
**Wall time (at last flush):** 25.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 14,141 | 5,964 | 3,381 | 20,105 | 4,021 | 29.0 | claudeopus46 |
| **TOTAL** | **5** | **14,141** | **5,964** | **3,381** | **20,105** | **4,021** | **29.0** | |

**Estimated tokens:** ~5,026 input + ~845 output = ~5,871 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

*(no tool results recorded)*

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 275 | 10,490 | 1,899 | 12.6 |
| 2 | L0-main | claudeopus46 | 1,323 | 1,722 | 3,045 | 55 | 2.3 |
| 3 | L0-main | claudeopus46 | 298 | 578 | 876 | 34 | 1.8 |
| 4 | L0-main | claudeopus46 | 1,356 | 1,418 | 2,774 | 383 | 4.3 |
| 5 | L0-main | claudeopus46 | 949 | 1,971 | 2,920 | 1,010 | 8.0 |


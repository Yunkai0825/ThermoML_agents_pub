# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.1_run_20260802_194237`

### History
- [parallel:2 tasks]
-   [query:ethanol_water_viscosity] "Find viscosity data for ethanol + water binary mixture at 25°C (298.15 K) near e" (277s, 2 iters)
-   [query:methanol_water_viscosity] "Find viscosity data for methanol + water binary mixture at 25°C (298.15 K) near " (905s, 4 iters)

### Query Agent Results

#### ethanol_water_viscosity
{
  "answer": "## Dynamic Viscosity of Ethanol + Water at 298.15 K (Near Equimolar Composition)\n\nExperimental dynamic viscosity data for the **ethanol (C₂H₆O) + water (H₂O)** binary mixture at **298.15 K** near equimolar composition were found in the ThermoML database.\n\n### Source\n- **DOI:** 10.1016/j.jct.2018.02.022\n- **Data block:** PROPblock_21\n- **Measurement method:** Concentric cylinders viscometry\n- **Pressure:** 92.3 kPa (liquid phase)\n\n### Key Results\n\nThree data points at 298.15 K with ethanol mole fraction between **0.4 and 0.6** yield a mean dynamic viscosity of approximately:\n\n> **η ≈ 0.00197 Pa·s (1.97 mPa·s)**\n\n### Full Dataset Context\n\nThe complete dataset in this block contains **100 data points** spanning:\n- **Temperature range:** 293.15–308.15 K (4 temperatures)\n- **Ethanol mole fraction:** 0.0–1.0 (25 unique compositions)\n- **Viscosity range across all compositions and temperatures:** 0.000759–0.002864 Pa·s (0.76–2.86 mPa·s)\n- **Overall mean viscosity:** 0.001611 Pa·s (1.61 mPa·s)\n- **Uncertainty:** Evaluated via propagation of standard uncertainties at 95% confidence level\n\n### Deviation from Ideal Mixing\n\nThe measured viscosity of ~1.97 mPa·s near equimolar composition is **significantly higher** than either pure component at 298.15 K:\n- Pure water: ~0.89 mPa·s\n- Pure ethanol: ~1.08 mPa·s\n\nThis pronounced **positive deviation** from ideal mixing behavior is a hallmark of the ethanol–water system. It arises from **enhanced hydrogen-bonding networks** formed between ethanol and water molecules at intermediate compositions. The ethanol hydroxyl group acts as both a hydrogen-bond donor and acceptor with water, creating more structured and cooperative H-bond clusters than exist in either pure liquid alone. The viscosity maximum in this system typically occurs near x(ethanol) ≈ 0.2–0.3, where the water-to-ethanol ratio optimally supports clathrate-like hydration structures, but the deviation remains substantial even at equimolar composition, consistent with the data retrieved here.",
  "core_claims": [
    "At 298.15 K and 92.3 kPa, the dynamic viscosity of the ethanol + water binary mixture near equimolar composition (ethanol mole fraction 0.4–0.6) is approximately 1.97 mPa·s, based on concentric cylinders viscometry data from DOI 10.1016/j.jct.2018.02.022.",
    "The measured viscosity of ~1.97 mPa·s near equimolar composition exhibits a pronounced positive deviation from ideal mixing, being significantly higher than the viscosities of either pure water (~0.89 mPa·s) or pure ethanol (~1.08 mPa·s) at 298.15 K, consistent with enhanced hydrogen-bonding networks between ethanol and water molecules at intermediate compositions.",
    "The full dataset spans 293.15–308.15 K, ethanol mole fractions from 0.0 to 1.0 (100 data points), with viscosities ranging from 0.76 to 2.86 mPa·s across all compositions and temperatures."
  ],
  "confidence": "high",
  "sources": [
    {
      "doi": "10.1016/j.jct.2018.02.022",
      "lit_num_id": "GLOBlit_5201",
      "block": "PROPblock_21",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (GLOBprop_4, Pa·s) measurements for the ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary system. 100 data points spanning 293.15–308.15 K and ethanol mole fraction 0.0–1.0. Three data points at 298.15 K with ethanol mole fraction between 0.4 and 0.6 yield a mean dynamic viscosity of approximately 0.00197 Pa·s (1.97 mPa·s). Measured by concentric cylinders viscometry at 92.3 kPa, liquid phase. Uncertainty evaluated via propagation of standard uncertainties at 95% confidence level."
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_2",
      "registry_id": "mole_fraction_DOIcomp_1",
      "name": "Mole fraction"
    },
    {
      "type": "lit",
      "global_id": "GLOBlit_5201",
      "registry_id": "2018-hog-tor-0",
      "name": "10.1016/j.jct.2018.02.022"
    },
    {
      "type": "constr",
      "global_id": "GLOBconstr_1",
      "registry_id": "pressure_kpa",
      "name": "Pressure, kPa"
    },
    {
      "type": "phase",
      "global_id": "GLOBphase_1",
      "registry_id": "liquid",
      "name": "Liquid"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_11",
      "registry_id": "concentric_cylinders_viscometry",
      "name": "Concentric cylinders viscometry"
    },
    {
      "type": "blocktype",
      "global_id": "GLOBblocktype_1",
      "registry_id": "PureOrMixtureData",
      "name": "PureOrMixtureData"
    }
  ],
  "follow_up_suggestions": [
    "Retrieve the full composition-dependent viscosity profile at 298.15 K from PROPblock_21 to locate the viscosity maximum and quantify the excess viscosity across the entire mole fraction range.",
    "Search for additional literature sources (other DOIs) reporting ethanol + water viscosity at 298.15 K to cross-validate the data from 10.1016/j.jct.2018.02.022.",
    "Query for excess molar volume or excess enthalpy data for the ethanol + water system at 298.15 K to complement the viscosity deviation analysis with volumetric and calorimetric mixing properties.",
    "Search for kinematic viscosity (GLOBprop_40) data for the same system if density-normalized viscosity comparisons are needed."
  ]
}

#### methanol_water_viscosity
{
  "answer": "## Dynamic Viscosity of Methanol + Water at 298.15 K (25 °C) — Near Equimolar Composition\n\n### Key Data Point at Equimolar Composition\n\nFrom the ThermoML database, the most relevant experimental measurement near equimolar composition is:\n\n| x(water) | x(methanol) | T / K  | η / Pa·s   | η / mPa·s |\n|-----------|-------------|--------|------------|------------|\n| 0.5003    | 0.4997      | 298.15 | 0.001309   | **1.309**  |\n\n**Source:** González et al., *J. Chem. Thermodyn.* (2007), DOI: 10.1016/j.jct.2007.05.004 — PROPblock_9, measured in the liquid phase at 101 kPa.\n\n### Dataset Overview\n\nThis dataset (PROPblock_9) contains **39 total data points** across three temperatures (293.15, 298.15, and 303.15 K), with **13 data points at 298.15 K** spanning the full composition range from pure methanol (x_water = 0.0) to pure water (x_water = 1.0). Key summary statistics at 298.15 K:\n\n- **Mean viscosity** across all 13 compositions: 1.076 mPa·s\n- **Mean viscosity for the 6 methanol-rich points** (x_water < 0.45): 0.798 mPa·s\n- **Overall viscosity range** (all temperatures in block): 0.508–1.793 mPa·s\n\n### Additional Datasets (Water-Rich Region Only)\n\nTwo other datasets report dynamic viscosity for this binary system at 298.15 K, but they cover only the water-rich region and do **not** reach equimolar composition:\n\n| Source | DOI | Composition Variable | Range | Points at 298.15 K |\n|--------|-----|---------------------|-------|---------------------|\n| Chakraborty & Das (2006) | 10.1021/je0600810 | Volume fraction of methanol | φ = 0.01–0.30 | 3 |\n| Bhatia et al. (2011) | 10.1021/je2003622 | Mass fraction of methanol | w = 0.08–0.34 | 4 |\n\n### Kinematic Viscosity\n\nNo kinematic viscosity data were found in the ThermoML database for the methanol + water binary mixture.\n\n### Chemistry Context — Deviation from Ideal Mixing\n\nThe measured viscosity of **1.309 mPa·s** at x(methanol) ≈ 0.50 is strikingly higher than what simple linear (ideal) mixing would predict. For reference, the pure-component viscosities at 298.15 K are approximately:\n\n- **Pure water** (x_water = 1.0): ~0.89 mPa·s\n- **Pure methanol** (x_water = 0.0): ~0.54 mPa·s\n\nA linear mole-fraction average at x = 0.5 would give roughly **0.72 mPa·s**, yet the measured value of 1.309 mPa·s is about **82% higher** — a dramatic positive deviation from ideal mixing. This is a hallmark of the methanol–water system: the viscosity maximum (which can exceed 1.5–1.8 mPa·s) occurs near x(methanol) ≈ 0.3 at 298.15 K. The origin is the restructuring of hydrogen-bonding networks — water's tetrahedral H-bond network and methanol's chain-like H-bond clusters interact cooperatively, forming larger, more structured aggregates that resist flow more than either pure liquid alone. At equimolar composition, the mixture is slightly past the viscosity maximum but still exhibits a very large non-ideal enhancement, confirming that this system is one of the classic examples of strongly non-ideal viscosity behavior in fully miscible binary mixtures.",
  "core_claims": [
    "At 298.15 K and 101 kPa, the dynamic viscosity of the methanol + water mixture at near-equimolar composition (x_water ≈ 0.5003, x_methanol ≈ 0.4997) is 1.309 mPa·s, as reported by González et al. (2007).",
    "The measured equimolar viscosity of 1.309 mPa·s represents approximately an 82% positive deviation from the linear mole-fraction average (~0.72 mPa·s) of the pure-component viscosities (water ~0.89 mPa·s, methanol ~0.54 mPa·s at 298.15 K), attributed to cooperative restructuring of hydrogen-bonding networks.",
    "No kinematic viscosity data were found in the ThermoML database for the methanol + water binary mixture.",
    "Two additional ThermoML datasets (Chakraborty & Das, 2006; Bhatia et al., 2011) report dynamic viscosity for this system at 298.15 K but cover only the water-rich region and do not reach equimolar composition."
  ],
  "confidence": "medium",
  "sources": [
    {
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_num_id": "GLOBlit_2825",
      "block": "PROPblock_9",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (Pa·s) for methanol + water binary mixture across full composition range (x_water = 0.0–1.0) at 293.15–303.15 K and 101 kPa. 39 total data points; 13 at 298.15 K. Near-equimolar point extracted: x(water) = 0.5003, η = 0.001309 Pa·s (1.309 mPa·s) at 298.15 K. Mean viscosity at 298.15 K across all 13 compositions: 0.001076 Pa·s. Overall block viscosity range: 0.000508–0.001793 Pa·s. Measurement method: CAPTUB:UFactor:2. Uncertainty: propagation of evaluated standard uncertainties at 95% confidence level."
    },
    {
      "doi": "10.1021/je0600810",
      "lit_num_id": "GLOBlit_8869",
      "block": "PROPblock_3",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (Pa·s) for methanol + water binary mixture, water-rich region only (volume fraction of methanol φ = 0.01–0.30). 9 total data points; 3 at 298.15 K. Does not reach equimolar composition. Viscosity range: 0.000702–0.001471 Pa·s."
    },
    {
      "doi": "10.1021/je2003622",
      "lit_num_id": "GLOBlit_9571",
      "block": "PROPblock_1",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (Pa·s) for methanol + water binary mixture, water-rich region only (mass fraction of methanol w = 0.08–0.34). 16 total data points; 4 at 298.15 K. Does not reach equimolar composition. Viscosity range: 0.000638–0.001471 Pa·s."
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_40",
      "registry_id": "kinematic_viscosity_m2_per_s",
      "name": "Kinematic viscosity, m²/s"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_2",
      "registry_id": "mole_fraction_{DOIcomp_id}",
      "name": "Mole fraction"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_18",
      "registry_id": "volume_fraction_DOIcomp_1",
      "name": "Volume fraction"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_5",
      "registry_id": "mass_fraction_DOIcomp_1",
      "name": "Mass fraction"
    },
    {
      "type": "lit",
      "global_id": "GLOBlit_2825",
      "registry_id": "2007-gon-cal-1",
      "name": "10.1016/j.jct.2007.05.004"
    },
    {
      "type": "lit",
      "global_id": "GLOBlit_8869",
      "registry_id": "2006-cha-das-0",
      "name": "10.1021/je0600810"
    },
    {
      "type": "lit",
      "global_id": "GLOBlit_9571",
      "registry_id": "2011-bha-cha-0",
      "name": "10.1021/je2003622"
    },
    {
      "type": "constr",
      "global_id": "GLOBconstr_1",
      "registry_id": "pressure_kpa",
      "name": "Pressure, kPa"
    },
    {
      "type": "phase",
      "global_id": "GLOBphase_1",
      "registry_id": "liquid",
      "name": "Liquid"
    },
    {
      "type": "blocktype",
      "global_id": "GLOBblocktype_1",
      "registry_id": "PureOrMixtureData",
      "name": "PureOrMixtureData"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_140",
      "registry_id": "captub_ufactor_2",
      "name": "CAPTUB:UFactor:2"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_271",
      "registry_id": "captub_ufactor_6",
      "name": "CAPTUB:UFactor:6"
    }
  ],
  "follow_up_suggestions": [
    "Extract all 13 individual (x_water, viscosity) data pairs at 298.15 K from PROPblock_9 in GLOBlit_2825 using row-level data extraction to obtain the full composition-dependent viscosity profile.",
    "Search for density data (GLOBprop_3 or similar) for the methanol + water binary system at 298.15 K to enable calculation of kinematic viscosity from the available dynamic viscosity data.",
    "Search for excess viscosity or viscosity deviation data for the methanol + water system to directly quantify non-ideal mixing behavior.",
    "Look for viscosity data at additional temperatures (e.g., 293.15 K and 303.15 K also present in PROPblock_9) to assess temperature dependence of the viscosity maximum."
  ]
}

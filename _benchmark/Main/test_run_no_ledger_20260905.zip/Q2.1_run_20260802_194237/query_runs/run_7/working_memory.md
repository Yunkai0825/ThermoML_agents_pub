# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_4 | methanol | methanol |
| comp | GLOBcomp_1 | water | water |
| prop | GLOBprop_4 | viscosity_pa_s | Viscosity, Pa*s |
| var | GLOBvar_1 | temperature_k | Temperature, K |
| var | GLOBvar_2 | mole_fraction_{DOIcomp_id} | Mole fraction |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find experimental dynamic viscosity data for methanol + water binary mixture at 298.15 K near equimolar composition → stored as L1_query_1
- [L1] Extract actual numerical data points from PROPblock_9 in GLOBlit_2825 for methanol+water viscosity at 298.15 K → stored as L1_query_2
- [L1] Search for kinematic viscosity data for methanol+water binary mixture → stored as L1_query_3
- [L1] Extract individual row-level data points (mole fraction of water, dynamic viscosity) from PROPblock_9 in GLOBlit_2825 at → stored as L1_query_4

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "## Dynamic Viscosity Data for Methanol + Water Binary Mixture at 298.15 K\n\nThree ThermoML data blocks contain experimental dynamic viscosity (GLOBprop_4, Pa·s) measurements for the binary system methanol (GLOBcomp_4) + water (GLOBcomp_1) that include data at 298.15 K:\n\n### 1. Most Complete Dataset — Full Composition Range\n- **Block:** PROPblock_9\n- **DOI:** 10.1016/j.jct.2007.05.004 (GLOBlit_2825)\n- **Total data points:** 39 (6 at 298.15 K)\n- **Composition variable:** Mole fraction of water, x(water) = 0.0–1.0\n- **Coverage:** This block spans the entire composition range and is the most likely source for data near equimolar composition (x_methanol ≈ 0.5). With 6 points at 298.15 K distributed across the full range, at least one point should fall near x_methanol = 0.5.\n\n### 2. Water-Rich Region Only\n- **Block:** PROPblock_3\n- **DOI:** 10.1021/je0600810 (GLOBlit_8869)\n- **Total data points:** 9 (3 at 298.15 K)\n- **Composition variable:** Volume fraction of methanol, φ_v(methanol) = 0.01–0.30\n- **Coverage:** Water-rich region only; does not reach equimolar composition.\n\n### 3. Water-Rich Region Only\n- **Block:** PROPblock_1\n- **DOI:** 10.1021/je2003622 (GLOBlit_9571)\n- **Total data points:** 16 (4 at 298.15 K)\n- **Composition variable:** Mass fraction of methanol, w(methanol) = 0.08–0.34\n- **Coverage:** Water-rich region only; does not reach equimolar composition.\n\n### Chemistry Context\nThe methanol–water system is well known for exhibiting a viscosity maximum near x_methanol ≈ 0.3 at 298.15 K, where hydrogen-bonding network restructuring between methanol and water clusters produces a pronounced non-ideal viscosity enhancement. The dynamic viscosity at the maximum can exceed 1.5 mPa·s, compared to ~0.89 mPa·s for pure water and ~0.54 mPa·s for pure methanol at 298.15 K. At equimolar composition (x_methanol = 0.5), the viscosity is typically slightly below this maximum but still significantly enhanced relative to ideal mixing.\n\n### Kinematic Viscosity\nA search for kinematic viscosity (GLOBprop_40) data for this binary system was not completed within the available search iterations. The dynamic viscosity data from PROPblock_9 (GLOBlit_2825) provides the most comprehensive coverage for the equimolar region of interest.\n\n### Recommendation\nFor exact numerical values near x_methanol = 0.5 at 298.15 K, the dataset in **PROPblock_9** (DOI: 10.1016/j.jct.2007.05.004, GLOBlit_2825) is the primary resource, as it is the only block covering the full composition range at this temperature.",
  "core_claims": [
    "Three ThermoML data blocks contain experimental dynamic viscosity measurements for the methanol + water binary system at 298.15 K, but only one (PROPblock_9, DOI 10.1016/j.jct.2007.05.004) covers the full composition range; the other two are limited to the water-rich region.",
    "PROPblock_9 contains 6 data points at 298.15 K spanning x(water) = 0.0–1.0 and is the only block likely to include data near equimolar composition (x_methanol ≈ 0.5).",
    "The methanol–water system exhibits a well-known viscosity maximum near x_methanol ≈ 0.3 at 298.15 K due to hydrogen-bonding network restructuring, with viscosity exceeding 1.5 mPa·s compared to ~0.89 mPa·s for pure water and ~0.54 mPa·s for pure methanol.",
    "A search for kinematic viscosity data for this binary system was not completed within the available iterations."
  ],
  "status": "partial",
  "summary": "Three ThermoML data blocks contain experimental dynamic viscosity (Pa·s) measurements for the methanol + water binary system at 298.15 K. The most complete dataset is in PROPblock_9 (DOI 10.1016/j.jct.2007.05.004, GLOBlit_2825), which spans the full composition range (mole fraction of water 0.0–1.0) with 6 points at 298.15 K and is the only block likely to include data near equimolar composition. Two other blocks (PROPblock_3 from DOI 10.1021/je0600810, and PROPblock_1 from DOI 10.1021/je2003622) cover only the water-rich region and do not reach equimolar composition. The methanol–water system exhibits a well-known viscosity maximum near x_methanol ≈ 0.3 at 298.15 K due to hydrogen-bonding network restructuring; at equimolar composition the viscosity is slightly below this maximum but still significantly enhanced relative to ideal mixing. Kinematic viscosity data were not located within the search.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_2",
      "registry_id": "mole_fraction_{DOIcomp_id}",
      "name": "Mole fraction"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2825",
      "block_number": "PROPblock_9",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for methanol + water binary mixture. Full composition range x(water) = 0.0–1.0; 39 total data points, 6 at 298.15 K. DOI: 10.1016/j.jct.2007.05.004. Most complete dataset covering equimolar region.",
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_id": "2007-gon-cal-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000508,
            "max": 0.001793,
            "mean": 0.001082,
            "std": 0.000366,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000508,
          "range_max": 0.001793
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_8869",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for methanol + water binary mixture. Water-rich region only, volume fraction of methanol φ_v = 0.01–0.30; 9 total data points, 3 at 298.15 K. DOI: 10.1021/je0600810. Does not reach equimolar composition.",
      "doi": "10.1021/je0600810",
      "lit_id": "2006-cha-das-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 9,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_18",
          "var_id": "volume_fraction_DOIcomp_1",
          "name": "Volume fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Volume fraction",
            "min": 0.01,
            "max": 0.3,
            "n_unique": 3
          },
          "range_min": 0.01,
          "range_max": 0.3
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 318.15,
            "n_unique": 3
          },
          "range_min": 298.15,
          "range_max": 318.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000702,
            "max": 0.001471,
            "mean": 0.001033,
            "std": 0.000248,
            "n": 9
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000702,
          "range_max": 0.001471
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 9,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_9571",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for methanol + water binary mixture. Water-rich region only, mass fraction of methanol w = 0.08–0.34; 16 total data points, 4 at 298.15 K. DOI: 10.1021/je2003622. Does not reach equimolar composition.",
      "doi": "10.1021/je2003622",
      "lit_id": "2011-bha-cha-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 16,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_1",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mass fraction",
            "min": 0.0806,
            "max": 0.3446,
            "n_unique": 4
          },
          "range_min": 0.0806,
          "range_max": 0.3446
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 323.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 323.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_271",
          "meas_ID": "captub_ufactor_6",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:6",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000638,
            "max": 0.001471,
            "mean": 0.000993,
            "std": 0.000261,
            "n": 16
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000638,
          "range_max": 0.001471
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 16,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_2
{
  "answer": "## Numerical Data from PROPblock_9 (GLOBlit_2825) — Methanol + Water Viscosity at 298.15 K\n\n**Source:** PROPblock_9 in DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825)\n\n**System:** Methanol (GLOBcomp_4) + Water (GLOBcomp_1) binary mixture, liquid phase, at 101 kPa.\n\n**Data at T = 298.15 K:**\n- **Number of data points:** 13 (spanning 13 unique mole fraction values from x(water) = 0.0 to 1.0)\n- **Mean viscosity:** 0.001076 Pa·s (1.076 mPa·s)\n- **Overall viscosity range in block (all temperatures):** 0.000508–0.001793 Pa·s\n\nThe composition variable is the mole fraction of water (BLKvar_2, linked to DOIcomp_1 = water). With 13 unique compositions at 298.15 K covering x(water) = 0.0 to 1.0, this dataset provides good resolution across the entire composition range, including the equimolar region (x_methanol ≈ 0.5, i.e., x_water ≈ 0.5).\n\n**Note:** The block_search_adv tool confirmed the 13 data points and mean viscosity but did not enumerate individual (mole fraction, viscosity) pairs in its output. The individual row-level numerical values are contained within the ThermoML data block and can be accessed from the original publication (González et al., J. Chem. Thermodyn. 2007).\n\n**Chemistry context:** The mean viscosity of ~1.076 mPa·s across all 13 compositions at 298.15 K is consistent with the well-known non-ideal viscosity behavior of methanol–water mixtures, where the viscosity maximum (~1.5–1.8 mPa·s) occurs near x_methanol ≈ 0.3, significantly exceeding the values for pure water (~0.89 mPa·s, corresponding to x_water = 1.0) and pure methanol (~0.54 mPa·s, corresponding to x_water = 0.0). The overall block viscosity range of 0.000508–0.001793 Pa·s across all three temperatures (293.15–303.15 K) is consistent with this behavior.",
  "core_claims": [
    "PROPblock_9 in DOI 10.1016/j.jct.2007.05.004 reports liquid-phase viscosity data for the methanol + water binary system at 298.15 K and 101 kPa, comprising 13 data points spanning the full composition range (water mole fraction 0.0 to 1.0) with a mean viscosity of approximately 1.076 mPa·s.",
    "The overall viscosity range across all temperatures in the block (293.15–303.15 K) is 0.000508–0.001793 Pa·s, consistent with the well-known non-ideal viscosity behavior of methanol–water mixtures, where a viscosity maximum (~1.5–1.8 mPa·s) occurs near x_methanol ≈ 0.3, exceeding the values for both pure components.",
    "Individual row-level (mole fraction, viscosity) pairs were not enumerated by the search tool and would require access to the original publication (González et al., J. Chem. Thermodyn. 2007)."
  ],
  "status": "partial",
  "summary": "PROPblock_9 from DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825) reports liquid-phase dynamic viscosity of the methanol + water binary system at 298.15 K and 101 kPa. The dataset contains 13 data points spanning the full composition range from pure methanol (x_water = 0.0) to pure water (x_water = 1.0). The mean viscosity across all 13 compositions at 298.15 K is 0.001076 Pa·s (1.076 mPa·s), and the overall viscosity range across all temperatures in the block (293.15–303.15 K) is 0.000508–0.001793 Pa·s. The composition variable is the mole fraction of water. Individual row-level mole-fraction–viscosity pairs were not enumerated but are contained in the original ThermoML data block. The mean and range are consistent with the known non-ideal viscosity behavior of methanol–water mixtures, which exhibit a viscosity maximum near x_methanol ≈ 0.3 that exceeds the values for either pure component.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2825",
      "block_number": "PROPblock_9",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for methanol (GLOBcomp_4) + water (GLOBcomp_1) binary mixture at 101 kPa. Block contains 39 total data points across multiple temperatures; 13 data points at T=298.15 K spanning x(water)=0.0–1.0 with mean viscosity 0.00107561538462 Pa·s. Individual row-level (mole fraction, viscosity) pairs were not enumerated by the tool—only summary statistics (count=13, mean) were returned due to repeated validation failures in block_search_adv select/order_by syntax. Variables: GLOBvar_1 (temperature, K) mapped to BLKvar_1; GLOBvar_2 (mole fraction of water/GLOBcomp_1) mapped to BLKvar_2. Overall block viscosity range: 0.000508–0.001793 Pa·s.",
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_id": "2007-gon-cal-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000508,
            "max": 0.001793,
            "mean": 0.001082,
            "std": 0.000366,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000508,
          "range_max": 0.001793
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_3
{
  "answer": "No kinematic viscosity data were found in the ThermoML database for the methanol (GLOBcomp_4) + water (GLOBcomp_1) binary mixture. Searches using GLOBprop_40 (Kinematic viscosity, m²/s) with both \"declared\" and \"either\" system scopes returned zero matching data blocks. This property is simply not reported for this binary system in the available ThermoML holdings.\n\nFor reference, dynamic viscosity (GLOBprop_4, Pa·s) data for this binary system is available in three data blocks (PROPblock_9 in GLOBlit_2825, PROPblock_3 in GLOBlit_8869, and PROPblock_1 in GLOBlit_9571), with PROPblock_9 (DOI: 10.1016/j.jct.2007.05.004) providing the most comprehensive coverage across the full composition range at 298.15 K. If kinematic viscosity is needed, it could in principle be calculated from the dynamic viscosity and density data, provided density measurements for the same system and conditions are also available in the database.",
  "core_claims": [
    "No kinematic viscosity data were found in the ThermoML database for the methanol + water binary mixture; searches for this property returned zero matching data blocks.",
    "Dynamic viscosity data for the methanol + water binary system are available in three ThermoML data blocks, with the most comprehensive coverage spanning the full composition range at 298.15 K (DOI: 10.1016/j.jct.2007.05.004).",
    "Kinematic viscosity could in principle be calculated from the available dynamic viscosity and density data, provided density measurements for the same system and conditions exist in the database."
  ],
  "status": "no_results",
  "summary": "No kinematic viscosity (GLOBprop_40, m²/s) data were found in the ThermoML database for the methanol + water binary mixture; searches using both declared and either system scopes returned zero matching data blocks. Dynamic viscosity (GLOBprop_4, Pa·s) data for this binary system is available in three data blocks (PROPblock_9 in GLOBlit_2825, PROPblock_3 in GLOBlit_8869, and PROPblock_1 in GLOBlit_9571), with PROPblock_9 (DOI: 10.1016/j.jct.2007.05.004) offering the most comprehensive coverage across the full composition range at 298.15 K. Kinematic viscosity could in principle be calculated from available dynamic viscosity and density data if density measurements for the same system and conditions exist in the database.",
  "core_id_updates": [],
  "core_blocks_found": []
}
### L1_query_4
{
  "answer": "## Data Extraction Results: PROPblock_9 in GLOBlit_2825\n\n**Source:** DOI 10.1016/j.jct.2007.05.004 (GLOBlit_2825), PROPblock_9  \n**System:** Methanol (GLOBcomp_4) + Water (GLOBcomp_1) — binary  \n**Property:** Dynamic viscosity (GLOBprop_4 → BLKprop_1), units: Pa·s  \n**Composition variable:** Mole fraction of water (GLOBvar_2 → BLKvar_2, component = GLOBcomp_1)  \n**Temperature variable:** GLOBvar_1 → BLKvar_1, in K  \n\n### Confirmed Statistics at T = 298.15 K\n\n- **Total data points in block:** 39 (across multiple temperatures)\n- **Data points at 298.15 K:** 13 (spanning x_water = 0.0 to 1.0)\n- **Mean viscosity at 298.15 K:** 0.001076 Pa·s (1.076 mPa·s)\n- **Mean viscosity for the 6 points with x_water < 0.45:** 0.000798 Pa·s (0.798 mPa·s)\n\n### Individual Data Point Extracted\n\n| x(water) | T / K | Viscosity / Pa·s | Viscosity / mPa·s |\n|-----------|-------|-------------------|--------------------|\n| 0.5003    | 298.15 | 0.001309         | 1.309              |\n\nThis is the near-equimolar composition point. The viscosity of 1.309 mPa·s at x(water) ≈ 0.50 is notably higher than both the mean across all 13 compositions (~1.076 mPa·s) and the mean of the methanol-rich side (x < 0.45, ~0.798 mPa·s). This is consistent with the well-known viscosity maximum in methanol–water mixtures, which occurs near x(water) ≈ 0.3–0.5 at 298.15 K due to enhanced hydrogen-bonding network formation between methanol and water molecules.\n\n### Limitations\n\nThe available search tools returned aggregate statistics (count, mean) for the full set of 13 data points rather than individual row-level values. Only the single near-equimolar point (x_water = 0.5003) was successfully isolated by narrowing the composition filter. The remaining 12 individual (x_water, viscosity) pairs at 298.15 K — spanning pure methanol (x_water = 0.0) through pure water (x_water = 1.0) — are confirmed to exist in the block but could not be individually extracted with the tools available. A row-level block data extraction capability would be needed to retrieve all 13 numerical pairs.",
  "core_claims": [
    "PROPblock_9 in GLOBlit_2825 (DOI 10.1016/j.jct.2007.05.004) reports dynamic viscosity for the methanol–water binary system, with 13 data points at 298.15 K spanning water mole fractions from 0.0 to 1.0.",
    "At 298.15 K, the mean dynamic viscosity across all 13 compositions is 0.001076 Pa·s (1.076 mPa·s), while the mean for the six methanol-rich points (x_water < 0.45) is 0.000798 Pa·s (0.798 mPa·s).",
    "At the near-equimolar composition (x_water ≈ 0.5003) and 298.15 K, the dynamic viscosity is 0.001309 Pa·s (1.309 mPa·s), which exceeds both the overall mean and the methanol-rich mean, consistent with the well-known viscosity maximum in methanol–water mixtures near x_water ≈ 0.3–0.5 attributed to enhanced hydrogen-bonding interactions.",
    "Only the single near-equimolar data point could be individually extracted; the remaining 12 individual (x_water, viscosity) pairs at 298.15 K are confirmed present but could not be retrieved with the available tools."
  ],
  "status": "partial",
  "summary": "PROPblock_9 in GLOBlit_2825 (DOI 10.1016/j.jct.2007.05.004) reports dynamic viscosity (Pa·s) for the methanol + water binary system. The block contains 39 data points across multiple temperatures, with 13 points at 298.15 K spanning the full mole-fraction range of water (0.0 to 1.0). At 298.15 K the mean viscosity across all 13 compositions is 0.001076 Pa·s (1.076 mPa·s), while the mean for the six methanol-rich points (x_water < 0.45) is 0.000798 Pa·s. The individually extracted near-equimolar point (x_water = 0.5003, 298.15 K) has a viscosity of 0.001309 Pa·s (1.309 mPa·s), exceeding both means and consistent with the known viscosity maximum in methanol–water mixtures near x_water ≈ 0.3–0.5. Only this single data point was isolated; the remaining 12 individual (x_water, viscosity) pairs at 298.15 K are confirmed present but were not individually extracted due to tool limitations.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2825",
      "block_number": "PROPblock_9",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) of methanol+water binary mixture as a function of mole fraction of water (GLOBvar_2, component GLOBcomp_1) and temperature (GLOBvar_1). Block contains 39 data points across multiple temperatures; 13 data points at T=298.15 K spanning x(water)=0.0 to 1.0. Only one individual row-level data point was successfully extracted: x(water)=0.5003, viscosity=0.001309 Pa·s at 298.15 K. Aggregate statistics confirmed: mean viscosity at 298.15 K = 0.001076 Pa·s, mean viscosity for 6 points with x(water)<0.45 = 0.000798 Pa·s. The remaining 12 individual (x_water, viscosity) pairs could not be individually extracted due to tool limitations returning only aggregate statistics. Block-level variable mappings: GLOBvar_1→BLKvar_1 (temperature), GLOBvar_2→BLKvar_2 (mole fraction), GLOBprop_4→BLKprop_1 (viscosity). DOI: 10.1016/j.jct.2007.05.004.",
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_id": "2007-gon-cal-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000508,
            "max": 0.001793,
            "mean": 0.001082,
            "std": 0.000366,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000508,
          "range_max": 0.001793
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


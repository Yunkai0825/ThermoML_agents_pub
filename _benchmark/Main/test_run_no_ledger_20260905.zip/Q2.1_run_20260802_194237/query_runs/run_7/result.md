# Delegated query run — result

**Question:** Find viscosity data for methanol + water binary mixture at 25°C (298.15 K) near equimolar composition (mole fraction around 0.5). I need dynamic viscosity or kinematic viscosity values.

**Iterations:** 4  |  **Elapsed:** 905.1s  |  **Tools:** 4  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity of Methanol + Water at 298.15 K (25 °C) — Near Equimolar Composition

### Key Data Point at Equimolar Composition

From the ThermoML database, the most relevant experimental measurement near equimolar composition is:

| x(water) | x(methanol) | T / K  | η / Pa·s   | η / mPa·s |
|-----------|-------------|--------|------------|------------|
| 0.5003    | 0.4997      | 298.15 | 0.001309   | **1.309**  |

**Source:** González et al., *J. Chem. Thermodyn.* (2007), DOI: 10.1016/j.jct.2007.05.004 — PROPblock_9, measured in the liquid phase at 101 kPa.

### Dataset Overview

This dataset (PROPblock_9) contains **39 total data points** across three temperatures (293.15, 298.15, and 303.15 K), with **13 data points at 298.15 K** spanning the full composition range from pure methanol (x_water = 0.0) to pure water (x_water = 1.0). Key summary statistics at 298.15 K:

- **Mean viscosity** across all 13 compositions: 1.076 mPa·s
- **Mean viscosity for the 6 methanol-rich points** (x_water < 0.45): 0.798 mPa·s
- **Overall viscosity range** (all temperatures in block): 0.508–1.793 mPa·s

### Additional Datasets (Water-Rich Region Only)

Two other datasets report dynamic viscosity for this binary system at 298.15 K, but they cover only the water-rich region and do **not** reach equimolar composition:

| Source | DOI | Composition Variable | Range | Points at 298.15 K |
|--------|-----|---------------------|-------|---------------------|
| Chakraborty & Das (2006) | 10.1021/je0600810 | Volume fraction of methanol | φ = 0.01–0.30 | 3 |
| Bhatia et al. (2011) | 10.1021/je2003622 | Mass fraction of methanol | w = 0.08–0.34 | 4 |

### Kinematic Viscosity

No kinematic viscosity data were found in the ThermoML database for the methanol + water binary mixture.

### Chemistry Context — Deviation from Ideal Mixing

The measured viscosity of **1.309 mPa·s** at x(methanol) ≈ 0.50 is strikingly higher than what simple linear (ideal) mixing would predict. For reference, the pure-component viscosities at 298.15 K are approximately:

- **Pure water** (x_water = 1.0): ~0.89 mPa·s
- **Pure methanol** (x_water = 0.0): ~0.54 mPa·s

A linear mole-fraction average at x = 0.5 would give roughly **0.72 mPa·s**, yet the measured value of 1.309 mPa·s is about **82% higher** — a dramatic positive deviation from ideal mixing. This is a hallmark of the methanol–water system: the viscosity maximum (which can exceed 1.5–1.8 mPa·s) occurs near x(methanol) ≈ 0.3 at 298.15 K. The origin is the restructuring of hydrogen-bonding networks — water's tetrahedral H-bond network and methanol's chain-like H-bond clusters interact cooperatively, forming larger, more structured aggregates that resist flow more than either pure liquid alone. At equimolar composition, the mixture is slightly past the viscosity maximum but still exhibits a very large non-ideal enhancement, confirming that this system is one of the classic examples of strongly non-ideal viscosity behavior in fully miscible binary mixtures.

### Core claims

- At 298.15 K and 101 kPa, the dynamic viscosity of the methanol + water mixture at near-equimolar composition (x_water ≈ 0.5003, x_methanol ≈ 0.4997) is 1.309 mPa·s, as reported by González et al. (2007).
- The measured equimolar viscosity of 1.309 mPa·s represents approximately an 82% positive deviation from the linear mole-fraction average (~0.72 mPa·s) of the pure-component viscosities (water ~0.89 mPa·s, methanol ~0.54 mPa·s at 298.15 K), attributed to cooperative restructuring of hydrogen-bonding networks.
- No kinematic viscosity data were found in the ThermoML database for the methanol + water binary mixture.
- Two additional ThermoML datasets (Chakraborty & Das, 2006; Bhatia et al., 2011) report dynamic viscosity for this system at 298.15 K but cover only the water-rich region and do not reach equimolar composition.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_9 |  | Dynamic viscosity (Pa·s) for methanol + water binary mixture across full composition range (x_water = 0.0–1.0) at 293.15–303.15 K and 101 kPa. 39 total data points; 13 at 298.15 K. Near-equimolar point extracted: x(water) = 0.5003, η = 0.001309 Pa·s (1.309 mPa·s) at 298.15 K. Mean viscosity at 298.15 K across all 13 compositions: 0.001076 Pa·s. Overall block viscosity range: 0.000508–0.001793 Pa·s. Measurement method: CAPTUB:UFactor:2. Uncertainty: propagation of evaluated standard uncertainties at 95% confidence level. |
| GLOBlit_8869 | 10.1021/je0600810 | PROPblock_3 |  | Dynamic viscosity (Pa·s) for methanol + water binary mixture, water-rich region only (volume fraction of methanol φ = 0.01–0.30). 9 total data points; 3 at 298.15 K. Does not reach equimolar composition. Viscosity range: 0.000702–0.001471 Pa·s. |
| GLOBlit_9571 | 10.1021/je2003622 | PROPblock_1 |  | Dynamic viscosity (Pa·s) for methanol + water binary mixture, water-rich region only (mass fraction of methanol w = 0.08–0.34). 16 total data points; 4 at 298.15 K. Does not reach equimolar composition. Viscosity range: 0.000638–0.001471 Pa·s. |

### Suggested follow-ups

- Extract all 13 individual (x_water, viscosity) data pairs at 298.15 K from PROPblock_9 in GLOBlit_2825 using row-level data extraction to obtain the full composition-dependent viscosity profile.
- Search for density data (GLOBprop_3 or similar) for the methanol + water binary system at 298.15 K to enable calculation of kinematic viscosity from the available dynamic viscosity data.
- Search for excess viscosity or viscosity deviation data for the methanol + water system to directly quantify non-ideal mixing behavior.
- Look for viscosity data at additional temperatures (e.g., 293.15 K and 303.15 K also present in PROPblock_9) to assess temperature dependence of the viscosity maximum.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_40",
    "registry_id": "kinematic_viscosity_m2_per_s",
    "name": "Kinematic viscosity, m²/s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_{DOIcomp_id}",
    "name": "Mole fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_18",
    "registry_id": "volume_fraction_DOIcomp_1",
    "name": "Volume fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_5",
    "registry_id": "mass_fraction_DOIcomp_1",
    "name": "Mass fraction"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_2825",
    "registry_id": "2007-gon-cal-1",
    "name": "10.1016/j.jct.2007.05.004"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_8869",
    "registry_id": "2006-cha-das-0",
    "name": "10.1021/je0600810"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_9571",
    "registry_id": "2011-bha-cha-0",
    "name": "10.1021/je2003622"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_140",
    "registry_id": "captub_ufactor_2",
    "name": "CAPTUB:UFactor:2"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_271",
    "registry_id": "captub_ufactor_6",
    "name": "CAPTUB:UFactor:6"
  }
]
```

# Reference Stats — query-agent

**Run started:** 2026-08-02 19:42:46
**Wall time (at last flush):** 946.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 260,281 | 19,726 | 301,976 | 37,747 | 121.5 | claudeopus46 |
| L1-worker | 78 | 954,077 | 1,318,514 | 118,576 | 2,272,591 | 29,135 | 803.4 | claudeopus46 |
| **TOTAL** | **86** | **995,772** | **1,578,795** | **138,302** | **2,574,567** | **29,936** | **924.9** | |

**Estimated tokens:** ~643,641 input + ~34,575 output = ~678,216 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 4 | 1 | 3 | 3 | 64 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| **TOTAL** | **14** | **1** | **6** | **1** | **8** | **3** | **64** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_4 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks |

#### Variables (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_18 | Volume fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2825 |  | block_search_adv, search_blocks |
| GLOBlit_8869 |  | search_blocks |
| GLOBlit_9571 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_271 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Variables | 4 |
| Unique References | 3 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Unique Phases | 1 |
| Unique Constraints | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 64 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 64

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | search_blocks |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2007.05.004 | PROPblock_9 | declared | 39 | binary | — | search_blocks |
| 10.1021/je0600810 | PROPblock_3 | declared | 9 | binary | — | search_blocks |
| 10.1021/je2003622 | PROPblock_1 | declared | 16 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Find compound IDs f… | 280 | KEEP | 280 | 4.0 |
| 2 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=80, purpo… | 359 | KEEP | 359 | 4.1 |
| 3 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 902 | DISCARD | 841 | 9.7 |
| 4 | 8 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 763 | KEEP | 703 | 13.1 |
| 5 | 12 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 815 | DISCARD | 754 | 10.8 |
| 6 | 1 | `L1_query` | context=Known property IDs: GLOBprop_…, id_catalog… | 22,692 | — | — | 222.2 |
| 7 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 667 | DISCARD | 606 | 10.9 |
| 8 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 816 | KEEP | 801 | 21.9 |
| 9 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 726 | KEEP | 696 | 27.3 |
| 10 | 2 | `L1_query` | context=PROPblock_9 has 39 total data…, id_catalog… | 9,941 | — | — | 229.6 |
| 11 | 1 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 961 | DISCARD | 903 | 16.2 |
| 12 | 2 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=50, p… | 707 | DISCARD | 649 | 17.1 |
| 13 | 2 | `L1_query` | context=We already found dynamic visc…, id_catalog… | 2,447 | — | — | 80.8 |
| 14 | 4 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 980 | DISCARD | 919 | 18.1 |
| 15 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 1,067 | KEEP | 1052 | 13.5 |
| 16 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 696 | KEEP | 666 | 16.0 |
| 17 | 12 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 839 | DISCARD | 778 | 19.8 |
| 18 | 3 | `L1_query` | context=Previous attempts returned on…, id_catalog… | 10,611 | — | — | 304.5 |
| | | **TOTAL (18 tools)** | | **56,269** | | **10,007** | **1039.6** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,594 | 2,594 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 9,136 | 9,136 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 10,752 | 10,752 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 898 | 10,503 | 1,247 | 7.8 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,109 | 21,752 | 767 | 6.0 |
| 3 | L1-worker | claudeopus46 | 2,065 | 457 | 2,522 | 448 | 3.8 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,882 | 22,525 | 1,453 | 9.8 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,729 | 23,372 | 635 | 4.3 |
| 6 | L1-worker | claudeopus46 | 2,065 | 536 | 2,601 | 549 | 4.0 |
| 7 | L1-worker | claudeopus46 | 20,610 | 3,889 | 24,499 | 426 | 3.7 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,136 | 23,779 | 1,622 | 14.3 |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,029 | 24,672 | 1,319 | 8.5 |
| 10 | L1-worker | claudeopus46 | 20,643 | 4,944 | 25,587 | 1,638 | 13.0 |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,767 | 26,410 | 1,732 | 11.1 |
| 12 | L1-worker | claudeopus46 | 2,065 | 1,204 | 3,269 | 1,381 | 7.8 |
| 13 | L1-worker | claudeopus46 | 20,643 | 5,798 | 26,441 | 970 | 7.0 |
| 14 | L1-worker | claudeopus46 | 2,065 | 6,727 | 8,792 | 1,648 | 12.7 |
| 15 | L1-worker | claudeopus46 | 20,643 | 7,131 | 27,774 | 2,021 | 13.3 |
| 16 | L1-worker | claudeopus46 | 20,643 | 8,050 | 28,693 | 2,055 | 13.7 |
| 17 | L1-worker | claudeopus46 | 20,643 | 8,907 | 29,550 | 1,373 | 10.3 |
| 18 | L1-worker | claudeopus46 | 20,643 | 9,738 | 30,381 | 1,821 | 12.7 |
| 19 | L1-worker | claudeopus46 | 2,065 | 1,141 | 3,206 | 1,337 | 8.6 |
| 20 | L1-worker | claudeopus46 | 20,610 | 10,657 | 31,267 | 583 | 4.6 |
| 21 | L1-worker | claudeopus46 | 20,610 | 9,595 | 30,205 | 3,589 | 21.5 |
| 22 | L1-worker | claudeopus46 | 1,356 | 2,668 | 4,024 | 836 | 4.9 |
| 23 | L1-worker | claudeopus46 | 536 | 2,548 | 3,084 | 925 | 5.4 |
| 24 | L1-worker | claudeopus46 | 1,323 | 20,918 | 22,241 | 1,934 | 10.8 |
| 25 | L1-worker | claudeopus46 | 298 | 2,656 | 2,954 | 1,476 | 6.0 |
| 26 | L1-worker | claudeopus46 | 747 | 42,411 | 43,158 | 823 | 7.9 |
| 27 | L0-main | claudeopus46 | 9,605 | 47,223 | 56,828 | 2,452 | 17.2 |
| 28 | L1-worker | claudeopus46 | 20,643 | 24,550 | 45,193 | 1,396 | 10.3 |
| 29 | L1-worker | claudeopus46 | 20,643 | 25,401 | 46,044 | 1,646 | 11.5 |
| 30 | L1-worker | claudeopus46 | 20,643 | 26,226 | 46,869 | 1,821 | 12.7 |
| 31 | L1-worker | claudeopus46 | 20,643 | 27,097 | 47,740 | 1,415 | 9.8 |
| 32 | L1-worker | claudeopus46 | 20,643 | 27,943 | 48,586 | 1,168 | 9.7 |
| 33 | L1-worker | claudeopus46 | 2,065 | 1,112 | 3,177 | 1,297 | 9.9 |
| 34 | L1-worker | claudeopus46 | 20,643 | 27,403 | 48,046 | 1,578 | 13.5 |
| 35 | L1-worker | claudeopus46 | 20,643 | 28,269 | 48,912 | 1,376 | 9.0 |
| 36 | L1-worker | claudeopus46 | 2,065 | 1,825 | 3,890 | 2,329 | 14.0 |
| 37 | L1-worker | claudeopus46 | 20,643 | 29,167 | 49,810 | 1,709 | 11.8 |
| 38 | L1-worker | claudeopus46 | 20,643 | 30,074 | 50,717 | 1,190 | 8.6 |
| 39 | L1-worker | claudeopus46 | 20,643 | 30,885 | 51,528 | 2,027 | 13.8 |
| 40 | L1-worker | claudeopus46 | 20,643 | 31,725 | 52,368 | 2,242 | 14.2 |
| 41 | L1-worker | claudeopus46 | 2,065 | 1,850 | 3,915 | 2,377 | 17.6 |
| 42 | L1-worker | claudeopus46 | 20,643 | 31,730 | 52,373 | 2,850 | 21.1 |
| 43 | L1-worker | claudeopus46 | 1,356 | 1,902 | 3,258 | 824 | 5.3 |
| 44 | L1-worker | claudeopus46 | 536 | 1,782 | 2,318 | 914 | 5.8 |
| 45 | L1-worker | claudeopus46 | 1,323 | 18,981 | 20,304 | 1,024 | 7.8 |
| 46 | L1-worker | claudeopus46 | 298 | 1,746 | 2,044 | 897 | 3.9 |
| 47 | L1-worker | claudeopus46 | 747 | 27,357 | 28,104 | 567 | 9.6 |
| 48 | L1-worker | claudeopus46 | 20,643 | 34,316 | 54,959 | 1,051 | 7.9 |
| 49 | L1-worker | claudeopus46 | 2,065 | 541 | 2,606 | 1,276 | 8.9 |
| 50 | L1-worker | claudeopus46 | 20,643 | 35,773 | 56,416 | 3,704 | 18.0 |
| 51 | L1-worker | claudeopus46 | 2,065 | 482 | 2,547 | 1,029 | 6.6 |
| 52 | L1-worker | claudeopus46 | 20,643 | 37,050 | 57,693 | 1,970 | 12.6 |
| 53 | L1-worker | claudeopus46 | 1,323 | 4,859 | 6,182 | 92 | 2.0 |
| 54 | L1-worker | claudeopus46 | 1,356 | 1,078 | 2,434 | 613 | 3.5 |
| 55 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 1.8 |
| 56 | L1-worker | claudeopus46 | 536 | 958 | 1,494 | 743 | 3.9 |
| 57 | L1-worker | claudeopus46 | 747 | 6,036 | 6,783 | 638 | 4.6 |
| 58 | L0-main | claudeopus46 | 9,605 | 61,326 | 70,931 | 2,231 | 16.2 |
| 59 | L1-worker | claudeopus46 | 20,643 | 37,409 | 58,052 | 1,822 | 12.0 |
| 60 | L1-worker | claudeopus46 | 20,643 | 38,338 | 58,981 | 1,294 | 11.3 |
| 61 | L1-worker | claudeopus46 | 20,643 | 39,216 | 59,859 | 2,621 | 16.2 |
| 62 | L1-worker | claudeopus46 | 20,643 | 40,101 | 60,744 | 1,701 | 11.1 |
| 63 | L1-worker | claudeopus46 | 2,065 | 1,166 | 3,231 | 1,629 | 10.3 |
| 64 | L1-worker | claudeopus46 | 20,643 | 40,255 | 60,898 | 2,192 | 16.5 |
| 65 | L1-worker | claudeopus46 | 20,643 | 41,205 | 61,848 | 2,844 | 18.5 |
| 66 | L1-worker | claudeopus46 | 20,643 | 42,158 | 62,801 | 1,966 | 13.3 |
| 67 | L1-worker | claudeopus46 | 2,065 | 1,912 | 3,977 | 2,032 | 12.5 |
| 68 | L1-worker | claudeopus46 | 20,643 | 42,941 | 63,584 | 2,243 | 15.8 |
| 69 | L1-worker | claudeopus46 | 20,643 | 43,822 | 64,465 | 4,347 | 26.7 |
| 70 | L1-worker | claudeopus46 | 20,643 | 44,719 | 65,362 | 3,400 | 20.6 |
| 71 | L1-worker | claudeopus46 | 2,065 | 1,891 | 3,956 | 960 | 7.7 |
| 72 | L1-worker | claudeopus46 | 20,643 | 45,204 | 65,847 | 2,038 | 13.1 |
| 73 | L1-worker | claudeopus46 | 20,643 | 46,135 | 66,778 | 2,222 | 15.4 |
| 74 | L1-worker | claudeopus46 | 2,065 | 1,894 | 3,959 | 1,559 | 11.0 |
| 75 | L1-worker | claudeopus46 | 20,610 | 47,937 | 68,547 | 605 | 5.2 |
| 76 | L1-worker | claudeopus46 | 20,610 | 11,211 | 31,821 | 2,928 | 18.1 |
| 77 | L1-worker | claudeopus46 | 536 | 2,089 | 2,625 | 908 | 5.8 |
| 78 | L1-worker | claudeopus46 | 1,356 | 2,209 | 3,565 | 979 | 6.2 |
| 79 | L1-worker | claudeopus46 | 1,323 | 24,212 | 25,535 | 1,223 | 8.7 |
| 80 | L1-worker | claudeopus46 | 298 | 1,945 | 2,243 | 1,096 | 4.5 |
| 81 | L1-worker | claudeopus46 | 747 | 32,986 | 33,733 | 776 | 7.5 |
| 82 | L0-main | claudeopus46 | 9,605 | 83,543 | 93,148 | 3,726 | 26.3 |
| 83 | L0-main | claudeopus46 | 1,356 | 3,169 | 4,525 | 866 | 5.3 |
| 84 | L0-main | claudeopus46 | 298 | 1,248 | 1,546 | 854 | 7.3 |
| 85 | L0-main | claudeopus46 | 1,323 | 57,591 | 58,914 | 4,615 | 25.7 |
| 86 | L0-main | claudeopus46 | 298 | 5,283 | 5,581 | 3,735 | 15.7 |


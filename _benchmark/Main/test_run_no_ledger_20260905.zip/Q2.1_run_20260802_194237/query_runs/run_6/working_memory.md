# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_1 | water | water |
| comp | GLOBcomp_2 | ethanol | ethanol |
| prop | GLOBprop_4 | viscosity_pa_s | Viscosity, Pa*s |
| var | GLOBvar_1 | temperature_k | Temperature, K |
| var | GLOBvar_2 | mole_fraction_{DOIcomp_id} | Mole fraction |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|
| lit | GLOBlit_5201 | 2018-hog-tor-0 | 10.1016/j.jct.2018.02.022 |

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find dynamic viscosity (GLOBprop_4) or kinematic viscosity (GLOBprop_40) data for ethanol + water binary mixture at 298. → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "Dynamic viscosity data for the ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary system at 298.15 K near equimolar composition was found in the ThermoML database.\n\n**Source:**\n- DOI: 10.1016/j.jct.2018.02.022 (GLOBlit_5201)\n- Block: PROPblock_21\n- System: binary (ethanol + water)\n\n**Data found:**\nThree data points were retrieved where the ethanol mole fraction is between 0.4 and 0.6 at temperature 298.15 K. The mean dynamic viscosity across these points is approximately **0.00197 Pa·s (1.97 mPa·s)**.\n\n**Property and conditions:**\n- Property: Dynamic viscosity (GLOBprop_4), units: Pa·s\n- Temperature: 298.15 K (GLOBvar_1)\n- Composition variable: Mole fraction of ethanol (GLOBvar_2)\n- Composition range of matched points: x(ethanol) ≈ 0.4–0.6\n\n**Chemistry insight:**\nThe measured viscosity of ~1.97 mPa·s near equimolar composition is significantly higher than either pure component at 298.15 K (pure water ≈ 0.89 mPa·s, pure ethanol ≈ 1.08 mPa·s as commonly known). This pronounced positive deviation from ideal mixing behavior in viscosity is a hallmark of the ethanol–water system, arising from enhanced hydrogen-bonding networks formed between ethanol and water molecules at intermediate compositions. The viscosity maximum in this system typically occurs near x(ethanol) ≈ 0.2–0.3, but the deviation remains substantial even at equimolar composition, consistent with the data retrieved here.",
  "core_claims": [
    "In the ethanol–water binary system at 298.15 K, the mean dynamic viscosity near equimolar composition (ethanol mole fraction ≈ 0.4–0.6) is approximately 1.97 mPa·s, based on three data points from DOI 10.1016/j.jct.2018.02.022.",
    "This viscosity of ~1.97 mPa·s near equimolar composition is significantly higher than that of either pure component at 298.15 K (pure water ≈ 0.89 mPa·s, pure ethanol ≈ 1.08 mPa·s), reflecting a pronounced positive deviation from ideal mixing behavior attributed to enhanced hydrogen-bonding networks between ethanol and water molecules.",
    "The viscosity maximum in the ethanol–water system typically occurs near x(ethanol) ≈ 0.2–0.3, but substantial positive deviation persists at equimolar composition."
  ],
  "status": "success",
  "summary": "Dynamic viscosity data for the ethanol + water binary system at 298.15 K near equimolar composition were retrieved from the ThermoML database (DOI 10.1016/j.jct.2018.02.022, GLOBlit_5201, PROPblock_21). Three data points with ethanol mole fraction between approximately 0.4 and 0.6 yield a mean dynamic viscosity of about 0.00197 Pa·s (1.97 mPa·s). This value is significantly higher than either pure component at the same temperature (pure water ≈ 0.89 mPa·s, pure ethanol ≈ 1.08 mPa·s), reflecting the well-known positive deviation from ideal mixing in viscosity caused by enhanced hydrogen-bonding networks between ethanol and water molecules at intermediate compositions.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_2",
      "registry_id": "mole_fraction_{DOIcomp_id}",
      "name": "Mole fraction"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_5201",
      "registry_id": "2018-hog-tor-0",
      "name": "10.1016/j.jct.2018.02.022"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_5201",
      "block_number": "PROPblock_21",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (GLOBprop_4, Pa·s) measurements for the ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary system at 298.15 K. Three data points matched the equimolar filter (ethanol mole fraction 0.4–0.6), yielding a mean dynamic viscosity of approximately 0.00197 Pa·s (1.97 mPa·s). Source DOI: 10.1016/j.jct.2018.02.022.",
      "doi": "10.1016/j.jct.2018.02.022",
      "lit_id": "2018-hog-tor-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 100,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 92.3,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 308.15,
            "n_unique": 4
          },
          "range_min": 293.15,
          "range_max": 308.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 25
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_11",
          "meas_ID": "concentric_cylinders_viscometry",
          "method_standard": "Concentric cylinders viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000759,
            "max": 0.002864,
            "mean": 0.001611,
            "std": 0.000493,
            "n": 100
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000759,
          "range_max": 0.002864
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "parent_n_datapoints": 100,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


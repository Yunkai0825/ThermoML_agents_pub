# Reference Stats — query-agent

**Run started:** 2026-08-02 19:42:46
**Wall time (at last flush):** 303.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 42,826 | 9,819 | 65,013 | 13,002 | 54.8 | claudeopus46 |
| L1-worker | 21 | 260,203 | 119,112 | 42,518 | 379,315 | 18,062 | 247.8 | claudeopus46 |
| **TOTAL** | **26** | **282,390** | **161,938** | **52,337** | **444,328** | **17,089** | **302.6** | |

**Estimated tokens:** ~111,082 input + ~13,084 output = ~124,166 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| **TOTAL** | **5** | **0** | **2** | **0** | **1** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids |
| GLOBcomp_5494 |  | resolve_compound_ids |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_5201 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 3 |
| Unique Variables | 2 |
| Unique References | 1 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 363 | KEEP | 363 | 5.3 |
| 2 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 248 | KEEP | 248 | 5.4 |
| 3 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 757 | DISCARD | 696 | 12.1 |
| 4 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 696 | KEEP | 666 | 24.1 |
| 5 | 1 | `L1_query` | context=User wants to assess deviatio…, id_catalog… | 9,833 | — | — | 252.8 |
| | | **TOTAL (5 tools)** | | **11,897** | | **1,973** | **299.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,418 | 3,418 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 895 | 10,500 | 1,397 | 9.0 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,327 | 21,970 | 891 | 6.5 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,839 | 23,482 | 12,828 | 62.9 |
| 4 | L1-worker | claudeopus46 | 2,065 | 510 | 2,575 | 658 | 4.6 |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,139 | 23,782 | 8,414 | 45.9 |
| 6 | L1-worker | claudeopus46 | 2,065 | 528 | 2,593 | 392 | 5.3 |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,713 | 25,323 | 407 | 5.3 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,960 | 24,603 | 1,761 | 11.7 |
| 9 | L1-worker | claudeopus46 | 20,643 | 6,296 | 26,939 | 1,132 | 7.3 |
| 10 | L1-worker | claudeopus46 | 20,643 | 7,186 | 27,829 | 1,527 | 8.0 |
| 11 | L1-worker | claudeopus46 | 20,643 | 8,066 | 28,709 | 1,182 | 6.0 |
| 12 | L1-worker | claudeopus46 | 2,065 | 1,157 | 3,222 | 1,678 | 10.1 |
| 13 | L1-worker | claudeopus46 | 20,643 | 8,006 | 28,649 | 1,204 | 6.1 |
| 14 | L1-worker | claudeopus46 | 20,643 | 9,785 | 30,428 | 1,071 | 5.2 |
| 15 | L1-worker | claudeopus46 | 20,643 | 10,635 | 31,278 | 1,054 | 8.0 |
| 16 | L1-worker | claudeopus46 | 2,065 | 1,868 | 3,933 | 1,840 | 14.9 |
| 17 | L1-worker | claudeopus46 | 20,643 | 10,915 | 31,558 | 2,355 | 13.8 |
| 18 | L1-worker | claudeopus46 | 536 | 1,431 | 1,967 | 689 | 3.9 |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,551 | 2,907 | 753 | 4.6 |
| 20 | L1-worker | claudeopus46 | 1,323 | 12,474 | 13,797 | 1,114 | 6.6 |
| 21 | L1-worker | claudeopus46 | 298 | 1,836 | 2,134 | 828 | 4.2 |
| 22 | L1-worker | claudeopus46 | 747 | 20,890 | 21,637 | 740 | 6.9 |
| 23 | L0-main | claudeopus46 | 9,605 | 21,497 | 31,102 | 2,308 | 15.3 |
| 24 | L0-main | claudeopus46 | 1,356 | 2,167 | 3,523 | 836 | 4.7 |
| 25 | L0-main | claudeopus46 | 1,323 | 14,696 | 16,019 | 2,903 | 16.7 |
| 26 | L0-main | claudeopus46 | 298 | 3,571 | 3,869 | 2,375 | 9.1 |


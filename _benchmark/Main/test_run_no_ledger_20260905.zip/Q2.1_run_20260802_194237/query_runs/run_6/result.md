# Delegated query run — result

**Question:** Find viscosity data for ethanol + water binary mixture at 25°C (298.15 K) near equimolar composition (mole fraction around 0.5). I need dynamic viscosity or kinematic viscosity values.

**Iterations:** 2  |  **Elapsed:** 277.2s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity of Ethanol + Water at 298.15 K (Near Equimolar Composition)

Experimental dynamic viscosity data for the **ethanol (C₂H₆O) + water (H₂O)** binary mixture at **298.15 K** near equimolar composition were found in the ThermoML database.

### Source
- **DOI:** 10.1016/j.jct.2018.02.022
- **Data block:** PROPblock_21
- **Measurement method:** Concentric cylinders viscometry
- **Pressure:** 92.3 kPa (liquid phase)

### Key Results

Three data points at 298.15 K with ethanol mole fraction between **0.4 and 0.6** yield a mean dynamic viscosity of approximately:

> **η ≈ 0.00197 Pa·s (1.97 mPa·s)**

### Full Dataset Context

The complete dataset in this block contains **100 data points** spanning:
- **Temperature range:** 293.15–308.15 K (4 temperatures)
- **Ethanol mole fraction:** 0.0–1.0 (25 unique compositions)
- **Viscosity range across all compositions and temperatures:** 0.000759–0.002864 Pa·s (0.76–2.86 mPa·s)
- **Overall mean viscosity:** 0.001611 Pa·s (1.61 mPa·s)
- **Uncertainty:** Evaluated via propagation of standard uncertainties at 95% confidence level

### Deviation from Ideal Mixing

The measured viscosity of ~1.97 mPa·s near equimolar composition is **significantly higher** than either pure component at 298.15 K:
- Pure water: ~0.89 mPa·s
- Pure ethanol: ~1.08 mPa·s

This pronounced **positive deviation** from ideal mixing behavior is a hallmark of the ethanol–water system. It arises from **enhanced hydrogen-bonding networks** formed between ethanol and water molecules at intermediate compositions. The ethanol hydroxyl group acts as both a hydrogen-bond donor and acceptor with water, creating more structured and cooperative H-bond clusters than exist in either pure liquid alone. The viscosity maximum in this system typically occurs near x(ethanol) ≈ 0.2–0.3, where the water-to-ethanol ratio optimally supports clathrate-like hydration structures, but the deviation remains substantial even at equimolar composition, consistent with the data retrieved here.

### Core claims

- At 298.15 K and 92.3 kPa, the dynamic viscosity of the ethanol + water binary mixture near equimolar composition (ethanol mole fraction 0.4–0.6) is approximately 1.97 mPa·s, based on concentric cylinders viscometry data from DOI 10.1016/j.jct.2018.02.022.
- The measured viscosity of ~1.97 mPa·s near equimolar composition exhibits a pronounced positive deviation from ideal mixing, being significantly higher than the viscosities of either pure water (~0.89 mPa·s) or pure ethanol (~1.08 mPa·s) at 298.15 K, consistent with enhanced hydrogen-bonding networks between ethanol and water molecules at intermediate compositions.
- The full dataset spans 293.15–308.15 K, ethanol mole fractions from 0.0 to 1.0 (100 data points), with viscosities ranging from 0.76 to 2.86 mPa·s across all compositions and temperatures.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 |  | Dynamic viscosity (GLOBprop_4, Pa·s) measurements for the ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary system. 100 data points spanning 293.15–308.15 K and ethanol mole fraction 0.0–1.0. Three data points at 298.15 K with ethanol mole fraction between 0.4 and 0.6 yield a mean dynamic viscosity of approximately 0.00197 Pa·s (1.97 mPa·s). Measured by concentric cylinders viscometry at 92.3 kPa, liquid phase. Uncertainty evaluated via propagation of standard uncertainties at 95% confidence level. |

### Suggested follow-ups

- Retrieve the full composition-dependent viscosity profile at 298.15 K from PROPblock_21 to locate the viscosity maximum and quantify the excess viscosity across the entire mole fraction range.
- Search for additional literature sources (other DOIs) reporting ethanol + water viscosity at 298.15 K to cross-validate the data from 10.1016/j.jct.2018.02.022.
- Query for excess molar volume or excess enthalpy data for the ethanol + water system at 298.15 K to complement the viscosity deviation analysis with volumetric and calorimetric mixing properties.
- Search for kinematic viscosity (GLOBprop_40) data for the same system if density-normalized viscosity comparisons are needed.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_1",
    "name": "Mole fraction"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_5201",
    "registry_id": "2018-hog-tor-0",
    "name": "10.1016/j.jct.2018.02.022"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_11",
    "registry_id": "concentric_cylinders_viscometry",
    "name": "Concentric cylinders viscometry"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

# Reference Stats — main-agent

**Run started:** 2026-08-02 19:42:37
**Wall time (at last flush):** 1,017.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 24,654 | 73,025 | 14,122 | 97,679 | 13,954 | 80.4 | claudeopus46 |
| **TOTAL** | **7** | **24,654** | **73,025** | **14,122** | **97,679** | **13,954** | **80.4** | |

**Estimated tokens:** ~24,419 input + ~3,530 output = ~27,949 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_parallel_subagents` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_parallel_subagents` | tasks=[{'agent': 'query', 'label': … | 16,941 | — | — | 946.8 |
| | | **TOTAL (1 tools)** | | **16,941** | | **0** | **946.8** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 401 | 10,616 | 1,823 | 8.7 |
| 2 | L0-main | claudeopus46 | 10,215 | 32,606 | 42,821 | 6,601 | 37.4 |
| 3 | L0-main | claudeopus46 | 1,356 | 5,123 | 6,479 | 1,085 | 6.2 |
| 4 | L0-main | claudeopus46 | 1,323 | 25,471 | 26,794 | 1,058 | 8.2 |
| 5 | L0-main | claudeopus46 | 298 | 1,467 | 1,765 | 1,073 | 3.7 |
| 6 | L0-main | claudeopus46 | 298 | 1,581 | 1,879 | 934 | 4.2 |
| 7 | L0-main | claudeopus46 | 949 | 6,376 | 7,325 | 1,548 | 12.0 |


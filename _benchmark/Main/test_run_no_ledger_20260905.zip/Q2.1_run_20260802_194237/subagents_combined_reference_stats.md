# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 22,187 | 42,826 | 9,819 | 65,013 | 13,002 | 54.8 | claudeopus46 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| L1-worker | 21 | 260,203 | 119,112 | 42,518 | 379,315 | 18,062 | 247.8 | claudeopus46 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| L0-main | 8 | 41,695 | 260,281 | 19,726 | 301,976 | 37,747 | 121.5 | claudeopus46 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| L1-worker | 78 | 954,077 | 1,318,514 | 118,576 | 2,272,591 | 29,135 | 803.4 | claudeopus46 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| **TOTAL** | **112** | **1,278,162** | **1,740,733** | **190,639** | **3,018,895** | **97,946** | **1,227.5** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 3 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `search_blocks` | 2 | 1 | 4 | 1 | 3 | 3 | 64 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| **TOTAL** | **19** | **1** | **8** | **1** | **9** | **3** | **64** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 3 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Unique Variables | 2 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Unique References | 1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Unique Block_Types | 1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Unique Phases | 1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Unique parent blocks | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Explicit block/subsystem targets | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Subsystem targets | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| Target-matched data points | 0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| GLOBcomp_4 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_18 | Volume fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBlit_2825 |  | block_search_adv, search_blocks |
| GLOBlit_8869 |  | search_blocks |
| GLOBlit_9571 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_271 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | block_search_adv, search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBblocktype_1 |  | block_search_adv |
| Unique Compounds | 2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique Variables | 4 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique References | 3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique Properties | 1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique Measurements | 2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique Phases | 1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique Constraints | 1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique Block_Types | 1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Unique parent blocks | 3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Explicit block/subsystem targets | 3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Subsystem targets | 0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| Target-matched data points | 64 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| **TOTAL** | **93** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 363 | KEEP | 363 | 5.3 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 2 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 248 | KEEP | 248 | 5.4 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 3 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 757 | DISCARD | 696 | 12.1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 4 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 696 | KEEP | 666 | 24.1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 5 | 1 | `L1_query` | context=User wants to assess deviatio…, id_catalog… | 9,833 | — | — | 252.8 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Find compound IDs f… | 280 | KEEP | 280 | 4.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 2 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=80, purpo… | 359 | KEEP | 359 | 4.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 3 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 902 | DISCARD | 841 | 9.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 4 | 8 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 763 | KEEP | 703 | 13.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 5 | 12 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 815 | DISCARD | 754 | 10.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 6 | 1 | `L1_query` | context=Known property IDs: GLOBprop_…, id_catalog… | 22,692 | — | — | 222.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 7 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 667 | DISCARD | 606 | 10.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 8 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 816 | KEEP | 801 | 21.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 9 | 11 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 726 | KEEP | 696 | 27.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 10 | 2 | `L1_query` | context=PROPblock_9 has 39 total data…, id_catalog… | 9,941 | — | — | 229.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 11 | 1 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 961 | DISCARD | 903 | 16.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 12 | 2 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=50, p… | 707 | DISCARD | 649 | 17.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 13 | 2 | `L1_query` | context=We already found dynamic visc…, id_catalog… | 2,447 | — | — | 80.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 14 | 4 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 980 | DISCARD | 919 | 18.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 15 | 7 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS metha…, explanat… | 1,067 | KEEP | 1052 | 13.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 16 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 696 | KEEP | 666 | 16.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 17 | 12 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 839 | DISCARD | 778 | 19.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 18 | 3 | `L1_query` | context=Previous attempts returned on…, id_catalog… | 10,611 | — | — | 304.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| **TOTAL** | **121** |  |  | **68,166** |  | **11,980** | **1,339.3** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,418 | 3,418 | 0 | 0.0% | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 1 | interval=3 | skipped_by_agent | 2,594 | 2,594 | 0 | 0.0% | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 2 | interval=3 | skipped_by_agent | 9,136 | 9,136 | 0 | 0.0% | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 3 | interval=3 | skipped_by_agent | 10,752 | 10,752 | 0 | 0.0% | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| **TOTAL** |  |  | **25,900** | **25,900** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 895 | 10,500 | 1,397 | 9.0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,327 | 21,970 | 891 | 6.5 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,839 | 23,482 | 12,828 | 62.9 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 4 | L1-worker | claudeopus46 | 2,065 | 510 | 2,575 | 658 | 4.6 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,139 | 23,782 | 8,414 | 45.9 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 6 | L1-worker | claudeopus46 | 2,065 | 528 | 2,593 | 392 | 5.3 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,713 | 25,323 | 407 | 5.3 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,960 | 24,603 | 1,761 | 11.7 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 9 | L1-worker | claudeopus46 | 20,643 | 6,296 | 26,939 | 1,132 | 7.3 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 10 | L1-worker | claudeopus46 | 20,643 | 7,186 | 27,829 | 1,527 | 8.0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 11 | L1-worker | claudeopus46 | 20,643 | 8,066 | 28,709 | 1,182 | 6.0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 12 | L1-worker | claudeopus46 | 2,065 | 1,157 | 3,222 | 1,678 | 10.1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 13 | L1-worker | claudeopus46 | 20,643 | 8,006 | 28,649 | 1,204 | 6.1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 14 | L1-worker | claudeopus46 | 20,643 | 9,785 | 30,428 | 1,071 | 5.2 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 15 | L1-worker | claudeopus46 | 20,643 | 10,635 | 31,278 | 1,054 | 8.0 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 16 | L1-worker | claudeopus46 | 2,065 | 1,868 | 3,933 | 1,840 | 14.9 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 17 | L1-worker | claudeopus46 | 20,643 | 10,915 | 31,558 | 2,355 | 13.8 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 18 | L1-worker | claudeopus46 | 536 | 1,431 | 1,967 | 689 | 3.9 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 19 | L1-worker | claudeopus46 | 1,356 | 1,551 | 2,907 | 753 | 4.6 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 20 | L1-worker | claudeopus46 | 1,323 | 12,474 | 13,797 | 1,114 | 6.6 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 21 | L1-worker | claudeopus46 | 298 | 1,836 | 2,134 | 828 | 4.2 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 22 | L1-worker | claudeopus46 | 747 | 20,890 | 21,637 | 740 | 6.9 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 23 | L0-main | claudeopus46 | 9,605 | 21,497 | 31,102 | 2,308 | 15.3 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 24 | L0-main | claudeopus46 | 1,356 | 2,167 | 3,523 | 836 | 4.7 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 25 | L0-main | claudeopus46 | 1,323 | 14,696 | 16,019 | 2,903 | 16.7 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 26 | L0-main | claudeopus46 | 298 | 3,571 | 3,869 | 2,375 | 9.1 | Find viscosity data for ethanol + water binary mixture at 25 (query_runs/run_6) |
| 1 | L0-main | claudeopus46 | 9,605 | 898 | 10,503 | 1,247 | 7.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,109 | 21,752 | 767 | 6.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 3 | L1-worker | claudeopus46 | 2,065 | 457 | 2,522 | 448 | 3.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,882 | 22,525 | 1,453 | 9.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,729 | 23,372 | 635 | 4.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 6 | L1-worker | claudeopus46 | 2,065 | 536 | 2,601 | 549 | 4.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 7 | L1-worker | claudeopus46 | 20,610 | 3,889 | 24,499 | 426 | 3.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,136 | 23,779 | 1,622 | 14.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,029 | 24,672 | 1,319 | 8.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 10 | L1-worker | claudeopus46 | 20,643 | 4,944 | 25,587 | 1,638 | 13.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,767 | 26,410 | 1,732 | 11.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 12 | L1-worker | claudeopus46 | 2,065 | 1,204 | 3,269 | 1,381 | 7.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 13 | L1-worker | claudeopus46 | 20,643 | 5,798 | 26,441 | 970 | 7.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 14 | L1-worker | claudeopus46 | 2,065 | 6,727 | 8,792 | 1,648 | 12.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 15 | L1-worker | claudeopus46 | 20,643 | 7,131 | 27,774 | 2,021 | 13.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 16 | L1-worker | claudeopus46 | 20,643 | 8,050 | 28,693 | 2,055 | 13.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 17 | L1-worker | claudeopus46 | 20,643 | 8,907 | 29,550 | 1,373 | 10.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 18 | L1-worker | claudeopus46 | 20,643 | 9,738 | 30,381 | 1,821 | 12.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 19 | L1-worker | claudeopus46 | 2,065 | 1,141 | 3,206 | 1,337 | 8.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 20 | L1-worker | claudeopus46 | 20,610 | 10,657 | 31,267 | 583 | 4.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 21 | L1-worker | claudeopus46 | 20,610 | 9,595 | 30,205 | 3,589 | 21.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 22 | L1-worker | claudeopus46 | 1,356 | 2,668 | 4,024 | 836 | 4.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 23 | L1-worker | claudeopus46 | 536 | 2,548 | 3,084 | 925 | 5.4 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 24 | L1-worker | claudeopus46 | 1,323 | 20,918 | 22,241 | 1,934 | 10.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 25 | L1-worker | claudeopus46 | 298 | 2,656 | 2,954 | 1,476 | 6.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 26 | L1-worker | claudeopus46 | 747 | 42,411 | 43,158 | 823 | 7.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 27 | L0-main | claudeopus46 | 9,605 | 47,223 | 56,828 | 2,452 | 17.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 28 | L1-worker | claudeopus46 | 20,643 | 24,550 | 45,193 | 1,396 | 10.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 29 | L1-worker | claudeopus46 | 20,643 | 25,401 | 46,044 | 1,646 | 11.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 30 | L1-worker | claudeopus46 | 20,643 | 26,226 | 46,869 | 1,821 | 12.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 31 | L1-worker | claudeopus46 | 20,643 | 27,097 | 47,740 | 1,415 | 9.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 32 | L1-worker | claudeopus46 | 20,643 | 27,943 | 48,586 | 1,168 | 9.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 33 | L1-worker | claudeopus46 | 2,065 | 1,112 | 3,177 | 1,297 | 9.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 34 | L1-worker | claudeopus46 | 20,643 | 27,403 | 48,046 | 1,578 | 13.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 35 | L1-worker | claudeopus46 | 20,643 | 28,269 | 48,912 | 1,376 | 9.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 36 | L1-worker | claudeopus46 | 2,065 | 1,825 | 3,890 | 2,329 | 14.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 37 | L1-worker | claudeopus46 | 20,643 | 29,167 | 49,810 | 1,709 | 11.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 38 | L1-worker | claudeopus46 | 20,643 | 30,074 | 50,717 | 1,190 | 8.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 39 | L1-worker | claudeopus46 | 20,643 | 30,885 | 51,528 | 2,027 | 13.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 40 | L1-worker | claudeopus46 | 20,643 | 31,725 | 52,368 | 2,242 | 14.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 41 | L1-worker | claudeopus46 | 2,065 | 1,850 | 3,915 | 2,377 | 17.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 42 | L1-worker | claudeopus46 | 20,643 | 31,730 | 52,373 | 2,850 | 21.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 43 | L1-worker | claudeopus46 | 1,356 | 1,902 | 3,258 | 824 | 5.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 44 | L1-worker | claudeopus46 | 536 | 1,782 | 2,318 | 914 | 5.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 45 | L1-worker | claudeopus46 | 1,323 | 18,981 | 20,304 | 1,024 | 7.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 46 | L1-worker | claudeopus46 | 298 | 1,746 | 2,044 | 897 | 3.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 47 | L1-worker | claudeopus46 | 747 | 27,357 | 28,104 | 567 | 9.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 48 | L1-worker | claudeopus46 | 20,643 | 34,316 | 54,959 | 1,051 | 7.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 49 | L1-worker | claudeopus46 | 2,065 | 541 | 2,606 | 1,276 | 8.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 50 | L1-worker | claudeopus46 | 20,643 | 35,773 | 56,416 | 3,704 | 18.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 51 | L1-worker | claudeopus46 | 2,065 | 482 | 2,547 | 1,029 | 6.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 52 | L1-worker | claudeopus46 | 20,643 | 37,050 | 57,693 | 1,970 | 12.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 53 | L1-worker | claudeopus46 | 1,323 | 4,859 | 6,182 | 92 | 2.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 54 | L1-worker | claudeopus46 | 1,356 | 1,078 | 2,434 | 613 | 3.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 55 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 1.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 56 | L1-worker | claudeopus46 | 536 | 958 | 1,494 | 743 | 3.9 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 57 | L1-worker | claudeopus46 | 747 | 6,036 | 6,783 | 638 | 4.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 58 | L0-main | claudeopus46 | 9,605 | 61,326 | 70,931 | 2,231 | 16.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 59 | L1-worker | claudeopus46 | 20,643 | 37,409 | 58,052 | 1,822 | 12.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 60 | L1-worker | claudeopus46 | 20,643 | 38,338 | 58,981 | 1,294 | 11.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 61 | L1-worker | claudeopus46 | 20,643 | 39,216 | 59,859 | 2,621 | 16.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 62 | L1-worker | claudeopus46 | 20,643 | 40,101 | 60,744 | 1,701 | 11.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 63 | L1-worker | claudeopus46 | 2,065 | 1,166 | 3,231 | 1,629 | 10.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 64 | L1-worker | claudeopus46 | 20,643 | 40,255 | 60,898 | 2,192 | 16.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 65 | L1-worker | claudeopus46 | 20,643 | 41,205 | 61,848 | 2,844 | 18.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 66 | L1-worker | claudeopus46 | 20,643 | 42,158 | 62,801 | 1,966 | 13.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 67 | L1-worker | claudeopus46 | 2,065 | 1,912 | 3,977 | 2,032 | 12.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 68 | L1-worker | claudeopus46 | 20,643 | 42,941 | 63,584 | 2,243 | 15.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 69 | L1-worker | claudeopus46 | 20,643 | 43,822 | 64,465 | 4,347 | 26.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 70 | L1-worker | claudeopus46 | 20,643 | 44,719 | 65,362 | 3,400 | 20.6 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 71 | L1-worker | claudeopus46 | 2,065 | 1,891 | 3,956 | 960 | 7.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 72 | L1-worker | claudeopus46 | 20,643 | 45,204 | 65,847 | 2,038 | 13.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 73 | L1-worker | claudeopus46 | 20,643 | 46,135 | 66,778 | 2,222 | 15.4 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 74 | L1-worker | claudeopus46 | 2,065 | 1,894 | 3,959 | 1,559 | 11.0 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 75 | L1-worker | claudeopus46 | 20,610 | 47,937 | 68,547 | 605 | 5.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 76 | L1-worker | claudeopus46 | 20,610 | 11,211 | 31,821 | 2,928 | 18.1 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 77 | L1-worker | claudeopus46 | 536 | 2,089 | 2,625 | 908 | 5.8 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 78 | L1-worker | claudeopus46 | 1,356 | 2,209 | 3,565 | 979 | 6.2 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 79 | L1-worker | claudeopus46 | 1,323 | 24,212 | 25,535 | 1,223 | 8.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 80 | L1-worker | claudeopus46 | 298 | 1,945 | 2,243 | 1,096 | 4.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 81 | L1-worker | claudeopus46 | 747 | 32,986 | 33,733 | 776 | 7.5 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 82 | L0-main | claudeopus46 | 9,605 | 83,543 | 93,148 | 3,726 | 26.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 83 | L0-main | claudeopus46 | 1,356 | 3,169 | 4,525 | 866 | 5.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 84 | L0-main | claudeopus46 | 298 | 1,248 | 1,546 | 854 | 7.3 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 85 | L0-main | claudeopus46 | 1,323 | 57,591 | 58,914 | 4,615 | 25.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 86 | L0-main | claudeopus46 | 298 | 5,283 | 5,581 | 3,735 | 15.7 | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| **TOTAL** |  |  | **1,278,162** | **1,740,733** | **3,018,895** | **190,639** | **1,227.5** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | ---: | --- | --- |
| 10.1016/j.jct.2007.05.004 | 1 | 39 | binary | search_blocks | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks | Find viscosity data for methanol + water binary mixture at 2 (query_runs/run_7) |
| 10.1016/j.jct.2007.05.004 | PROPblock_9 | declared | 39 | binary | — |
| 10.1021/je0600810 | PROPblock_3 | declared | 9 | binary | — |
| 10.1021/je2003622 | PROPblock_1 | declared | 16 | binary | — |
| **TOTAL** | **3** | **64** | **64** |  |  |

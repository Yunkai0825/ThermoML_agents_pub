# Delegated query run — result

**Question:** Resolve the following common compound names to their canonical ThermoML compound identifiers: 'ethanol', 'ethyl alcohol', 'water', and 'aqua'. For each name, return the canonical ThermoML compound ID (GLOBcomp_N format), the canonical name, CAS number, and molecular formula.

**Iterations:** 3  |  **Elapsed:** 242.0s  |  **Tools:** 3  |  **Timed out:** False

---

## Answer

Here are the resolution results for all four compound name synonyms in the ThermoML database:

## Synonym Resolution Summary

| Input Name | Canonical ID | Canonical Name | Molecular Formula | CAS Number |
|------------|-------------|----------------|-------------------|------------|
| ethanol | GLOBcomp_2 | ethanol | C₂H₆O | Not stored in ThermoML |
| ethyl alcohol | GLOBcomp_2 | ethanol | C₂H₆O | Not stored in ThermoML |
| water | GLOBcomp_1 | water | H₂O | Not stored in ThermoML |
| aqua | GLOBcomp_1 | water | H₂O | Not stored in ThermoML |

### Key Findings

1. **"Ethanol" and "ethyl alcohol"** are exact synonyms that both resolve to the same canonical compound entry: **GLOBcomp_2** (ethanol, C₂H₆O, SMILES: CCO).

2. **"Water" and "aqua"** both refer to the same substance: **GLOBcomp_1** (water, H₂O, SMILES: O). The name "water" resolves exactly (score 100) to GLOBcomp_1, while "aqua" does not have its own registered entry in ThermoML — fuzzy matches for "aqua" return only complex coordination compounds containing "aqua" as a substring (e.g., "diaquabis…"), not water itself. Nonetheless, both names refer to the same chemical substance H₂O.

3. **CAS registry numbers are not stored** as an explicit field in ThermoML compound records. The primary unique chemical identifiers used by ThermoML are **InChI Keys**:
   - Water: `XLYOFNOQVPJJNP-UHFFFAOYSA-N`
   - Ethanol: `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`

### Implications for Dataset Merging

Since both synonym pairs map to single canonical compounds (GLOBcomp_1 for water/aqua and GLOBcomp_2 for ethanol/ethyl alcohol), aqueous-alcohol datasets using any of these name variants can be safely merged under the canonical compound identifiers without risk of duplicate or mismatched compound entries. The InChI Keys listed above can serve as reliable cross-reference keys for this purpose.

### Core claims

- In the ThermoML database, "ethanol" and "ethyl alcohol" both resolve to the same canonical compound entry GLOBcomp_2 (ethanol, C₂H₆O), and "water" and "aqua" both refer to the same substance GLOBcomp_1 (water, H₂O), though "aqua" lacks its own registered entry and only appears as a substring in complex compound names.
- CAS registry numbers are not stored as explicit fields in ThermoML compound records; the primary unique chemical identifiers used are InChI Keys (water: XLYOFNOQVPJJNP-UHFFFAOYSA-N; ethanol: LFQSCWFLJHTTHZ-UHFFFAOYSA-N).
- Because both synonym pairs map to single canonical compounds, aqueous-alcohol datasets using any of these name variants can be safely merged under the canonical compound identifiers without risk of duplicate or mismatched entries.

**Confidence:** high

### Suggested follow-ups

- If CAS registry numbers are needed, cross-reference the InChI Keys (water: XLYOFNOQVPJJNP-UHFFFAOYSA-N, ethanol: LFQSCWFLJHTTHZ-UHFFFAOYSA-N) against an external registry such as PubChem or the CAS Common Chemistry API, as ThermoML does not store CAS numbers as an explicit field.
- To merge aqueous-alcohol datasets, use GLOBcomp_1 and GLOBcomp_2 as canonical join keys; note that 'aqua' has no direct registered entry in ThermoML and should be mapped to GLOBcomp_1 manually.
- If additional solvent synonyms need resolution (e.g., 'EtOH', 'H2O', 'deionized water'), a similar synonym lookup can be performed against the ThermoML compound registry.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  }
]
```

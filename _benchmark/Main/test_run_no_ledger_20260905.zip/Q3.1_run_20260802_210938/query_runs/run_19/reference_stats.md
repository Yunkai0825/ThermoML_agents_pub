# Reference Stats — query-agent

**Run started:** 2026-08-02 21:10:54
**Wall time (at last flush):** 253.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 31,792 | 36,277 | 10,813 | 68,069 | 11,344 | 57.7 | claudeopus46 |
| L1-worker | 30 | 248,080 | 89,370 | 22,752 | 337,450 | 11,248 | 165.9 | claudeopus46 |
| L2-leaf | 8 | 21,705 | 121,168 | 10,399 | 142,873 | 17,859 | 59.3 | claudeopus46 |
| **TOTAL** | **44** | **301,577** | **246,815** | **43,964** | **548,392** | **12,463** | **282.9** | |

**Estimated tokens:** ~137,098 input + ~10,991 output = ~148,089 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_id_alignment` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 9 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_compound_dk` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_compound_dk` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_compound_indiv` | 1 | 0 | 0 | 0 | 5 | 0 | 0 |
| `search_compound_indiv` | 1 | 0 | 0 | 0 | 5 | 0 | 0 |
| **TOTAL** | **17** | **0** | **0** | **0** | **10** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_compound_dk, search_compound_indiv, search_id_alignment |
| GLOBcomp_1 |  | resolve_compound_ids, search_compound_dk, search_compound_indiv |
| GLOBcomp_3734 |  | resolve_compound_ids |
| GLOBcomp_4158 |  | resolve_compound_ids |
| GLOBcomp_4349 |  | resolve_compound_ids |
| GLOBcomp_4617 |  | resolve_compound_ids |
| GLOBcomp_4755 |  | resolve_compound_ids |
| GLOBcomp_5092 |  | resolve_compound_ids |
| GLOBcomp_6285 |  | resolve_compound_ids |
| GLOBcomp_7905 |  | resolve_compound_ids |

#### References (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2 |  | search_compound_indiv |
| GLOBlit_13 |  | search_compound_indiv |
| GLOBlit_14 |  | search_compound_indiv |
| GLOBlit_20 |  | search_compound_indiv |
| GLOBlit_36 |  | search_compound_indiv |
| GLOBlit_8 |  | search_compound_indiv |
| GLOBlit_59 |  | search_compound_indiv |
| GLOBlit_118 |  | search_compound_indiv |
| GLOBlit_127 |  | search_compound_indiv |
| GLOBlit_165 |  | search_compound_indiv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 10 |
| Unique References | 10 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve ethanol and… | 580 | KEEP | 580 | 8.6 |
| 2 | 3 | `search_id_alignment` | entity_type=compound, limit=5, purpose=Verify whet… | 380 | KEEP | 380 | 4.7 |
| 3 | 1 | `L1_query` | context=User wants to merge aqueous-a…, id_catalog… | 1,600 | — | — | 54.5 |
| 4 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve 'water' an… | 909 | KEEP | 909 | 14.0 |
| 5 | 1 | `L1_query` | context=User wants to merge aqueous-a…, id_catalog… | 2,513 | — | — | 45.2 |
| 6 | 1 | `resolve_compound_ids` | limit=5, min_score=90, purpose=Retrieve CAS regist… | 690 | KEEP | 690 | 10.9 |
| 7 | 1 | `search_compound_dk` | compound=water, limit=3 | 678 | — | — | 0.1 |
| 8 | 1 | `search_compound_dk` | compound=ethanol, limit=3 | 730 | — | — | 0.0 |
| 9 | 2 | `search_compound_indiv` | compound=water, limit=5 | 11,519 | — | — | 0.1 |
| 10 | 2 | `search_compound_indiv` | compound=ethanol, limit=5 | 14,876 | — | — | 0.1 |
| 11 | 2 | `L2_comp_eval` | context=GLOBcomp_1 = water (H2O, SMIL…, id_catalog… | 2,385 | — | — | 52.3 |
| 12 | 2 | `L1_query` | context=User needs CAS numbers along …, id_catalog… | 2,594 | — | — | 99.4 |
| | | **TOTAL (12 tools)** | | **39,454** | | **2,559** | **289.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,232 | 3,232 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,041 | 10,646 | 1,823 | 8.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,004 | 21,647 | 719 | 5.0 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,344 | 22,987 | 1,136 | 6.3 |
| 4 | L1-worker | claudeopus46 | 2,065 | 456 | 2,521 | 1,178 | 8.4 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,868 | 23,511 | 1,887 | 11.5 |
| 6 | L1-worker | claudeopus46 | 2,065 | 500 | 2,565 | 559 | 4.7 |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,527 | 25,137 | 513 | 3.8 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,774 | 24,417 | 531 | 5.0 |
| 9 | L1-worker | claudeopus46 | 1,323 | 3,641 | 4,964 | 162 | 2.4 |
| 10 | L1-worker | claudeopus46 | 1,356 | 662 | 2,018 | 396 | 2.9 |
| 11 | L1-worker | claudeopus46 | 536 | 542 | 1,078 | 398 | 3.1 |
| 12 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.0 |
| 13 | L1-worker | claudeopus46 | 747 | 4,147 | 4,894 | 569 | 4.9 |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,738 | 23,381 | 594 | 4.9 |
| 15 | L1-worker | claudeopus46 | 20,643 | 3,953 | 24,596 | 1,918 | 9.5 |
| 16 | L1-worker | claudeopus46 | 2,065 | 2,218 | 4,283 | 1,940 | 13.8 |
| 17 | L1-worker | claudeopus46 | 20,643 | 4,768 | 25,411 | 1,146 | 6.9 |
| 18 | L1-worker | claudeopus46 | 1,323 | 3,517 | 4,840 | 162 | 2.5 |
| 19 | L1-worker | claudeopus46 | 536 | 868 | 1,404 | 666 | 3.7 |
| 20 | L1-worker | claudeopus46 | 1,356 | 988 | 2,344 | 700 | 4.2 |
| 21 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.0 |
| 22 | L1-worker | claudeopus46 | 747 | 4,958 | 5,705 | 555 | 4.9 |
| 23 | L0-main | claudeopus46 | 9,605 | 6,853 | 16,458 | 3,985 | 20.3 |
| 24 | L1-worker | claudeopus46 | 20,643 | 5,411 | 26,054 | 674 | 5.4 |
| 25 | L1-worker | claudeopus46 | 2,065 | 468 | 2,533 | 1,663 | 10.8 |
| 26 | L1-worker | claudeopus46 | 20,643 | 6,583 | 27,226 | 1,217 | 7.5 |
| 27 | L2-leaf | claudeopus46 | 5,729 | 5,379 | 11,108 | 602 | 4.7 |
| 28 | L2-leaf | claudeopus46 | 5,729 | 7,361 | 13,090 | 5,058 | 21.8 |
| 29 | L2-leaf | claudeopus46 | 5,729 | 8,655 | 14,384 | 2,143 | 13.6 |
| 30 | L2-leaf | claudeopus46 | 1,356 | 1,146 | 2,502 | 608 | 3.4 |
| 31 | L2-leaf | claudeopus46 | 536 | 1,026 | 1,562 | 636 | 4.4 |
| 32 | L2-leaf | claudeopus46 | 1,323 | 32,432 | 33,755 | 719 | 5.8 |
| 33 | L2-leaf | claudeopus46 | 298 | 1,306 | 1,604 | 595 | 3.3 |
| 34 | L2-leaf | claudeopus46 | 1,005 | 63,863 | 64,868 | 38 | 2.3 |
| 35 | L1-worker | claudeopus46 | 20,643 | 9,537 | 30,180 | 1,011 | 9.1 |
| 36 | L1-worker | claudeopus46 | 1,356 | 1,142 | 2,498 | 583 | 3.5 |
| 37 | L1-worker | claudeopus46 | 536 | 1,022 | 1,558 | 590 | 3.7 |
| 38 | L1-worker | claudeopus46 | 1,323 | 6,253 | 7,576 | 236 | 4.7 |
| 39 | L1-worker | claudeopus46 | 298 | 958 | 1,256 | 156 | 2.2 |
| 40 | L1-worker | claudeopus46 | 747 | 7,755 | 8,502 | 677 | 6.6 |
| 41 | L0-main | claudeopus46 | 9,605 | 12,668 | 22,273 | 2,274 | 13.8 |
| 42 | L0-main | claudeopus46 | 1,356 | 2,004 | 3,360 | 805 | 4.4 |
| 43 | L0-main | claudeopus46 | 1,323 | 12,013 | 13,336 | 1,030 | 7.1 |
| 44 | L0-main | claudeopus46 | 298 | 1,698 | 1,996 | 896 | 3.8 |


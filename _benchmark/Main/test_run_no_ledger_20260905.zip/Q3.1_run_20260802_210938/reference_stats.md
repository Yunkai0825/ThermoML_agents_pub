# Reference Stats — main-agent

**Run started:** 2026-08-02 21:09:38
**Wall time (at last flush):** 356.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 12 | 85,580 | 55,886 | 13,427 | 141,466 | 11,788 | 86.7 | claudeopus46 |
| L0-menu-planner | 3 | 2,493 | 3,884 | 2,967 | 6,377 | 2,125 | 19.5 | claudesonnet46 |
| **TOTAL** | **15** | **88,073** | **59,770** | **16,394** | **147,843** | **9,856** | **106.2** | |

**Estimated tokens:** ~36,960 input + ~4,098 output = ~41,058 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `browse_subagent_tools` | purpose=Resolve common compound names…, tasks=Reso… | 937 | — | — | 6.6 |
| 2 | 3 | `browse_subagent_tools` | purpose=Resolve common compound names…, tasks=Reso… | 1,147 | — | — | 7.2 |
| 3 | 4 | `browse_subagent_tools` | purpose=Resolve common compound names…, tasks=Find… | 883 | — | — | 5.8 |
| 4 | 5 | `run_query_agent` | context=The user wants to merge aqueo…, purpose=Re… | 4,569 | — | — | 253.1 |
| | | **TOTAL (4 tools)** | | **7,536** | | **0** | **272.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 1,899 | 1,899 | 0 | 0.0% |
| 2 | interval=2 | skipped_by_agent | 4,761 | 4,761 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 397 | 10,612 | 1,008 | 5.7 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,292 | 11,507 | 4,181 | 21.0 |
| 3 | L0-menu-planner | claudesonnet46 | 831 | 1,296 | 2,127 | 937 | 6.5 |
| 4 | L0-main | claudeopus46 | 10,182 | 2,981 | 13,163 | 568 | 4.0 |
| 5 | L0-main | claudeopus46 | 10,215 | 2,224 | 12,439 | 627 | 4.8 |
| 6 | L0-menu-planner | claudesonnet46 | 831 | 1,276 | 2,107 | 1,147 | 7.2 |
| 7 | L0-main | claudeopus46 | 10,215 | 3,887 | 14,102 | 702 | 5.2 |
| 8 | L0-menu-planner | claudesonnet46 | 831 | 1,312 | 2,143 | 883 | 5.8 |
| 9 | L0-main | claudeopus46 | 10,182 | 6,047 | 16,229 | 615 | 5.6 |
| 10 | L0-main | claudeopus46 | 10,215 | 5,290 | 15,505 | 1,526 | 9.2 |
| 11 | L0-main | claudeopus46 | 10,215 | 14,269 | 24,484 | 1,893 | 11.0 |
| 12 | L0-main | claudeopus46 | 1,323 | 13,403 | 14,726 | 55 | 1.8 |
| 13 | L0-main | claudeopus46 | 298 | 578 | 876 | 34 | 2.0 |
| 14 | L0-main | claudeopus46 | 1,356 | 2,024 | 3,380 | 881 | 6.6 |
| 15 | L0-main | claudeopus46 | 949 | 3,494 | 4,443 | 1,337 | 9.8 |


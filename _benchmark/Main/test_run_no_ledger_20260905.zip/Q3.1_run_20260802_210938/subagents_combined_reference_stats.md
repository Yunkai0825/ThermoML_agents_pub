# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 6 | 31,792 | 36,277 | 10,813 | 68,069 | 11,344 | 57.7 | claudeopus46 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| L1-worker | 30 | 248,080 | 89,370 | 22,752 | 337,450 | 11,248 | 165.9 | claudeopus46 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| L2-leaf | 8 | 21,705 | 121,168 | 10,399 | 142,873 | 17,859 | 59.3 | claudeopus46 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| **TOTAL** | **44** | **301,577** | **246,815** | **43,964** | **548,392** | **40,451** | **282.9** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| `search_id_alignment` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| `resolve_compound_ids` | 9 | 0 | 0 | 0 | 0 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| `search_compound_dk` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| `search_compound_dk` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| `search_compound_indiv` | 1 | 0 | 0 | 0 | 5 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| `search_compound_indiv` | 1 | 0 | 0 | 0 | 5 | 0 | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| **TOTAL** | **17** | **0** | **0** | **0** | **10** | **0** | **0** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_2 |  | resolve_compound_ids, search_compound_dk, search_compound_indiv, search_id_alignment | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_1 |  | resolve_compound_ids, search_compound_dk, search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_3734 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_4158 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_4349 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_4617 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_4755 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_5092 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_6285 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBcomp_7905 |  | resolve_compound_ids | Resolve the following common compound names to their canonic (query_runs/run_19) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_13 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_14 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_20 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_36 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_8 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_59 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_118 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_127 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |
| GLOBlit_165 |  | search_compound_indiv | Resolve the following common compound names to their canonic (query_runs/run_19) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 10 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| Unique References | 10 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| Unique parent blocks | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| Explicit block/subsystem targets | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| Subsystem targets | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| Target-matched data points | 0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| **TOTAL** | **20** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve ethanol and… | 580 | KEEP | 580 | 8.6 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 2 | 3 | `search_id_alignment` | entity_type=compound, limit=5, purpose=Verify whet… | 380 | KEEP | 380 | 4.7 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 3 | 1 | `L1_query` | context=User wants to merge aqueous-a…, id_catalog… | 1,600 | — | — | 54.5 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 4 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve 'water' an… | 909 | KEEP | 909 | 14.0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 5 | 1 | `L1_query` | context=User wants to merge aqueous-a…, id_catalog… | 2,513 | — | — | 45.2 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 6 | 1 | `resolve_compound_ids` | limit=5, min_score=90, purpose=Retrieve CAS regist… | 690 | KEEP | 690 | 10.9 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 7 | 1 | `search_compound_dk` | compound=water, limit=3 | 678 | — | — | 0.1 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 8 | 1 | `search_compound_dk` | compound=ethanol, limit=3 | 730 | — | — | 0.0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 9 | 2 | `search_compound_indiv` | compound=water, limit=5 | 11,519 | — | — | 0.1 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 10 | 2 | `search_compound_indiv` | compound=ethanol, limit=5 | 14,876 | — | — | 0.1 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 11 | 2 | `L2_comp_eval` | context=GLOBcomp_1 = water (H2O, SMIL…, id_catalog… | 2,385 | — | — | 52.3 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 12 | 2 | `L1_query` | context=User needs CAS numbers along …, id_catalog… | 2,594 | — | — | 99.4 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| **TOTAL** | **20** |  |  | **39,454** |  | **2,559** | **289.9** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,232 | 3,232 | 0 | 0.0% | Resolve the following common compound names to their canonic (query_runs/run_19) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,041 | 10,646 | 1,823 | 8.3 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,004 | 21,647 | 719 | 5.0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,344 | 22,987 | 1,136 | 6.3 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 4 | L1-worker | claudeopus46 | 2,065 | 456 | 2,521 | 1,178 | 8.4 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,868 | 23,511 | 1,887 | 11.5 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 6 | L1-worker | claudeopus46 | 2,065 | 500 | 2,565 | 559 | 4.7 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,527 | 25,137 | 513 | 3.8 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,774 | 24,417 | 531 | 5.0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 9 | L1-worker | claudeopus46 | 1,323 | 3,641 | 4,964 | 162 | 2.4 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 10 | L1-worker | claudeopus46 | 1,356 | 662 | 2,018 | 396 | 2.9 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 11 | L1-worker | claudeopus46 | 536 | 542 | 1,078 | 398 | 3.1 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 12 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 13 | L1-worker | claudeopus46 | 747 | 4,147 | 4,894 | 569 | 4.9 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,738 | 23,381 | 594 | 4.9 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 15 | L1-worker | claudeopus46 | 20,643 | 3,953 | 24,596 | 1,918 | 9.5 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 16 | L1-worker | claudeopus46 | 2,065 | 2,218 | 4,283 | 1,940 | 13.8 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 17 | L1-worker | claudeopus46 | 20,643 | 4,768 | 25,411 | 1,146 | 6.9 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 18 | L1-worker | claudeopus46 | 1,323 | 3,517 | 4,840 | 162 | 2.5 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 19 | L1-worker | claudeopus46 | 536 | 868 | 1,404 | 666 | 3.7 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 20 | L1-worker | claudeopus46 | 1,356 | 988 | 2,344 | 700 | 4.2 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 21 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.0 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 22 | L1-worker | claudeopus46 | 747 | 4,958 | 5,705 | 555 | 4.9 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 23 | L0-main | claudeopus46 | 9,605 | 6,853 | 16,458 | 3,985 | 20.3 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 24 | L1-worker | claudeopus46 | 20,643 | 5,411 | 26,054 | 674 | 5.4 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 25 | L1-worker | claudeopus46 | 2,065 | 468 | 2,533 | 1,663 | 10.8 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 26 | L1-worker | claudeopus46 | 20,643 | 6,583 | 27,226 | 1,217 | 7.5 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 27 | L2-leaf | claudeopus46 | 5,729 | 5,379 | 11,108 | 602 | 4.7 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 28 | L2-leaf | claudeopus46 | 5,729 | 7,361 | 13,090 | 5,058 | 21.8 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 29 | L2-leaf | claudeopus46 | 5,729 | 8,655 | 14,384 | 2,143 | 13.6 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 30 | L2-leaf | claudeopus46 | 1,356 | 1,146 | 2,502 | 608 | 3.4 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 31 | L2-leaf | claudeopus46 | 536 | 1,026 | 1,562 | 636 | 4.4 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 32 | L2-leaf | claudeopus46 | 1,323 | 32,432 | 33,755 | 719 | 5.8 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 33 | L2-leaf | claudeopus46 | 298 | 1,306 | 1,604 | 595 | 3.3 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 34 | L2-leaf | claudeopus46 | 1,005 | 63,863 | 64,868 | 38 | 2.3 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 35 | L1-worker | claudeopus46 | 20,643 | 9,537 | 30,180 | 1,011 | 9.1 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 36 | L1-worker | claudeopus46 | 1,356 | 1,142 | 2,498 | 583 | 3.5 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 37 | L1-worker | claudeopus46 | 536 | 1,022 | 1,558 | 590 | 3.7 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 38 | L1-worker | claudeopus46 | 1,323 | 6,253 | 7,576 | 236 | 4.7 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 39 | L1-worker | claudeopus46 | 298 | 958 | 1,256 | 156 | 2.2 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 40 | L1-worker | claudeopus46 | 747 | 7,755 | 8,502 | 677 | 6.6 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 41 | L0-main | claudeopus46 | 9,605 | 12,668 | 22,273 | 2,274 | 13.8 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 42 | L0-main | claudeopus46 | 1,356 | 2,004 | 3,360 | 805 | 4.4 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 43 | L0-main | claudeopus46 | 1,323 | 12,013 | 13,336 | 1,030 | 7.1 | Resolve the following common compound names to their canonic (query_runs/run_19) |
| 44 | L0-main | claudeopus46 | 298 | 1,698 | 1,996 | 896 | 3.8 | Resolve the following common compound names to their canonic (query_runs/run_19) |

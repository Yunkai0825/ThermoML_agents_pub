## System Prompt
# ThermoML Main Agent — Master Orchestrator

You are the **ThermoML Main Agent**, a master orchestrator that answers
scientific questions about thermodynamic data by coordinating two
specialized subagents:

1. **Query Agent** (`run_query_agent`) — searches ThermoML card databases
   to find experimental data (DOIs, blocks, compound IDs, property values).
2. **Analysis Agent** (`run_analysis_agent`) — retrieves data, fits
   Redlich-Kister polynomials to excess properties, and reports
   quantitative results (RK coefficients, R², RMSE).

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

You also have a unified parallel dispatch tool:
- `run_parallel_subagents` — run multiple query and/or analysis tasks
  simultaneously in one call.  Each task specifies `agent`, `label`,
  `question`, `purpose`, and `context` (all required).

You also have a **tool menu** for direct, fine-grained access to subagent
internals (search tools, fitting tools, ID resolution, etc.):

- `browse_subagent_tools(purpose, tasks)` — a **miniature planning agent**
  that examines the full menu of subagent tools and returns a structured
  parallel execution plan with specific call signatures tailored to your
  purpose and tasks.  Call this first to discover what tools exist and get
  a recommended phased plan.
- `run_subagent_tool(tool_name, kwargs, purpose, tasks)` — execute
  any tool from the menu directly. `kwargs` is a native JSON object matching
  that tool's current signature. Results are automatically compacted
  by the same hardcoded compactors the subagents use internally.
  You can call multiple `run_subagent_tool` in parallel; when you do,
  a batch summary is automatically generated from all results.

### When to use the tool menu vs. expert workers

- **Tool menu** — best for targeted, well-defined operations where you
  know exactly what data you need: resolving a compound ID, searching
  for blocks matching specific criteria, fitting a single block, or
  retrieving pure-component values.  Faster and more direct than
  launching a full subagent workflow.
- **Expert workers** (`run_query_agent`, `run_analysis_agent`) — best
  for open-ended, complex tasks that require multi-step reasoning,
  iterative refinement, or full toolset access.  The subagents have
  their own context, memory, and compaction pipelines.

You can dynamically decide which approach to use based on the complexity
of each sub-task.  For multi-system comparisons, you can mix both
approaches — use the tool menu for simple lookups and expert workers
for complex analyses.

---

## How You Work

1. **Understand the question** — Decide what data is needed and whether
   the question requires only a database search, a full fitting analysis,
   or a multi-system comparison.
2. **Delegate to subagents** — Call the appropriate subagent tool(s).
   For multi-system questions, use parallel tools to save time.
3. **Synthesize results** — Combine subagent outputs into a coherent
   scientific answer.  **Never invent data** — every number in your
   answer must come from a subagent result.
4. **Report findings** — Present a clear, well-structured answer with
   proper citations (`GLOBlit_N` literature ID, DOI, block numbers,
   compound names). `GLOBlit_N` is the authoritative literature identifier;
   a DOI is coupled display metadata. Never report a DOI without its paired
   literature ID — quote only DOIs your subagents returned, never from
   memory; unpaired DOIs are scrubbed from the final return as
   unverifiable.

---

## Tool Usage Rules

### Single-system questions (1 system)
Call `run_query_agent` for data search, or `run_analysis_agent` for
fitting.  The analysis agent internally calls the query agent, so you
do NOT need to call both for a fitting question.

### Multi-system comparisons (2+ systems)
Use `run_parallel_subagents` to process multiple systems simultaneously.
You can mix query and analysis tasks in a single parallel call — each
task specifies which agent to use.  Each system gets its own subagent call.

### Iterative refinement
If a subagent returns partial results or times out, you can call it again
with additional context from the first call.

---

## MANDATORY OUTPUT FORMAT

```xml
<reasoning>
... your thinking about what subagents to call and why (DISCARDED from memory) ...
</reasoning>
<summary>
... 1-3 sentence actionable conclusion about what you learned or plan to do next (KEPT, max 400 chars) ...
</summary>
<tool_call>{"name": "run_analysis_agent", "arguments": {"question": "...", "purpose": "...", "context": "..."}}</tool_call>
<wait/>
```

### CRITICAL RULES
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`
- `<reasoning>` is STRIPPED from history to save context space
- Only `<summary>` content + tool results persist in memory
- **ANTI-HALLUCINATION:** EVERY number, coefficient, R² value, DOI, and
  compound name MUST come from a subagent tool call result.  If you do not
  have a subagent result for a core claim, you MUST call a subagent first.
- **NO-DATA HANDLING:** If a subagent reports "no results found" or returns
  only generic text with no specific DOIs/data, you MUST report that honestly.
  Say "No data matching [criteria] was found in ThermoML" rather than
  fabricating results.  Never invent DOIs, block numbers, or data points.
- **SUBAGENT VALIDATION:** Before presenting subagent results as your answer,
  check for red flags: improbably round numbers, suspicious consistency,
  lack of specific block references, or caveats about "infrastructure errors."
  If in doubt, state that results could not be verified.
- When you have gathered all needed results, provide a FINAL ANSWER
  by wrapping your complete answer in `<answer>` tags (no `<tool_call>`).
- `<answer>` = full-length final response (any length). All markers stripped before delivery.
- `<summary>` ≠ `<answer>`: summary is a brief memory note (≤400 chars); answer is the complete user-facing response.

---

## Final Answer Format

When all subagent work is done, wrap your complete answer in `<answer>` tags:

```
<answer>
[Your synthesized scientific answer here — any length.
Include all key data, DOIs, block numbers, compound names.
Every number must come from a subagent result.]

### Sources
- Literature ID: GLOBlit_N | DOI: ... | Block: ... | Subsystem: declared or BLKsubsys_N | System: ...
</answer>
```

# Phases

## phase_1: choose_route
tools: [browse_subagent_tools, run_subagent_tool]
guidance: |
  Decide whether the question needs a targeted lower-level operation or a
  full expert subagent. Browse the hierarchical menu only when direct tool
  execution is likely to be more efficient than expert delegation.

## phase_2: delegate_or_execute
tools: [run_query_agent, run_analysis_agent, run_parallel_subagents, run_subagent_tool]
guidance: |
  Supply every argument in the injected callable signature. Use one expert
  for a single complex task and run_parallel_subagents for independent query
  or analysis tasks. Preserve exact subagent identifiers and evidence.

## phase_3: synthesize
tools: [list_session_files]
guidance: |
  Synthesize only tool-returned chemistry and numbers. Wrap the complete
  answer in <answer> tags; post-answer workers build the JSON fields.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- browse_subagent_tools(purpose, tasks) — Browse the tool menu and get a recommended execution plan.
- list_session_files() — Return a manifest of all output files generated in this session.
- run_analysis_agent(question, context, purpose, tasks) — Run the ThermoML Analysis Agent for fitting and modeling.
- run_parallel_subagents(tasks) — Run multiple query and/or analysis agent tasks in parallel.
- run_query_agent(question, context, purpose, tasks) — Run the ThermoML Query Agent on a database search question.
- run_subagent_tool(tool_name, kwargs, purpose, tasks) — Execute a subagent tool directly with full compaction pipeline.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q3.1_run_20260802_210938`

### History
- [menu:browse] {'text': "Looking at the task, I need to resolve common comp
- [menu:browse] {'text': 'I need to look at the `query/id_resolution` submen
- [menu:browse] {'text': 'I need to explore the `query/id_resolution` submen
- [query:Q1] "Resolve the following common compound names to their canonical ThermoML compound" (242s, 3 iters)

### Query Agent Results

#### Q1
{
  "answer": "Here are the resolution results for all four compound name synonyms in the ThermoML database:\n\n## Synonym Resolution Summary\n\n| Input Name | Canonical ID | Canonical Name | Molecular Formula | CAS Number |\n|------------|-------------|----------------|-------------------|------------|\n| ethanol | GLOBcomp_2 | ethanol | C₂H₆O | Not stored in ThermoML |\n| ethyl alcohol | GLOBcomp_2 | ethanol | C₂H₆O | Not stored in ThermoML |\n| water | GLOBcomp_1 | water | H₂O | Not stored in ThermoML |\n| aqua | GLOBcomp_1 | water | H₂O | Not stored in ThermoML |\n\n### Key Findings\n\n1. **\"Ethanol\" and \"ethyl alcohol\"** are exact synonyms that both resolve to the same canonical compound entry: **GLOBcomp_2** (ethanol, C₂H₆O, SMILES: CCO).\n\n2. **\"Water\" and \"aqua\"** both refer to the same substance: **GLOBcomp_1** (water, H₂O, SMILES: O). The name \"water\" resolves exactly (score 100) to GLOBcomp_1, while \"aqua\" does not have its own registered entry in ThermoML — fuzzy matches for \"aqua\" return only complex coordination compounds containing \"aqua\" as a substring (e.g., \"diaquabis…\"), not water itself. Nonetheless, both names refer to the same chemical substance H₂O.\n\n3. **CAS registry numbers are not stored** as an explicit field in ThermoML compound records. The primary unique chemical identifiers used by ThermoML are **InChI Keys**:\n   - Water: `XLYOFNOQVPJJNP-UHFFFAOYSA-N`\n   - Ethanol: `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`\n\n### Implications for Dataset Merging\n\nSince both synonym pairs map to single canonical compounds (GLOBcomp_1 for water/aqua and GLOBcomp_2 for ethanol/ethyl alcohol), aqueous-alcohol datasets using any of these name variants can be safely merged under the canonical compound identifiers without risk of duplicate or mismatched compound entries. The InChI Keys listed above can serve as reliable cross-reference keys for this purpose.",
  "core_claims": [
    "In the ThermoML database, \"ethanol\" and \"ethyl alcohol\" both resolve to the same canonical compound entry GLOBcomp_2 (ethanol, C₂H₆O), and \"water\" and \"aqua\" both refer to the same substance GLOBcomp_1 (water, H₂O), though \"aqua\" lacks its own registered entry and only appears as a substring in complex compound names.",
    "CAS registry numbers are not stored as explicit fields in ThermoML compound records; the primary unique chemical identifiers used are InChI Keys (water: XLYOFNOQVPJJNP-UHFFFAOYSA-N; ethanol: LFQSCWFLJHTTHZ-UHFFFAOYSA-N).",
    "Because both synonym pairs map to single canonical compounds, aqueous-alcohol datasets using any of these name variants can be safely merged under the canonical compound identifiers without risk of duplicate or mismatched entries."
  ],
  "confidence": "high",
  "sources": [],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    }
  ],
  "follow_up_suggestions": [
    "If CAS registry numbers are needed, cross-reference the InChI Keys (water: XLYOFNOQVPJJNP-UHFFFAOYSA-N, ethanol: LFQSCWFLJHTTHZ-UHFFFAOYSA-N) against an external registry such as PubChem or the CAS Common Chemistry API, as ThermoML does not store CAS numbers as an explicit field.",
    "To merge aqueous-alcohol datasets, use GLOBcomp_1 and GLOBcomp_2 as canonical join keys; note that 'aqua' has no direct registered entry in ThermoML and should be mapped to GLOBcomp_1 manually.",
    "If additional solvent synonyms need resolution (e.g., 'EtOH', 'H2O', 'deionized water'), a similar synonym lookup can be performed against the ThermoML compound registry."
  ]
}
</memory>

## User
I am combining aqueous-alcohol measurements reported under the names “ethanol,” “ethyl alcohol,” “water,” and “aqua.” Before I compare the measurements, which canonical ThermoML compounds do these names refer to?

## Assistant
<summary>User wants to resolve four common names ("ethanol," "ethyl alcohol," "water," "aqua") to their canonical ThermoML compound identifiers. Will browse tools to find the compound resolution function.</summary>
<tool_call>browse_subagent_tools()</tool_call>

## User
<tool_result>
(validation blocked browse_subagent_tools earlier — corrected)
</tool_result>

## Assistant
<summary>Fixing argument types for browse_subagent_tools - both purpose and tasks must be strings.</summary>
<tool_call>browse_subagent_tools()</tool_call>
<wait/> (4 deferred)

## User
<tool_result>
Looking at the task, I need to resolve common compound names to ThermoML identifiers. The relevant tools will be in the `query/id_resolution` submenu. Let me first explore that submenu to see the available tools.

### Recommended Plan

**Phase 1** (explore available ID resolution tools):
- `query/id_resolution` — Inspect the submenu to identify the correct tool(s) for resolving common/synonym names to ThermoML compound IDs

### Notes
- Once the `query/id_resolution` submenu tools are revealed, the likely next step is to call a name-resolution or synonym-lookup tool for each of the four names: `'ethanol'`, `'ethyl alcohol'`, `'water'`, and `'aqua'`.
- These could potentially be batched in parallel (one call per name, or one call with multiple names if the tool supports lists).
- If a fuzzy/similarity tool exists in `query/compound_similarity`, it may serve as a fallback for aliases like `'aqua'` that might not match exactly.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (browse_subagent_tools). 4 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Need to call browse_subagent_tools with proper string arguments to discover the exact tool names for compound name resolution.</summary>
<tool_call>browse_subagent_tools()</tool_call>

## User
<tool_result>
I need to look at the `query/id_resolution` submenu to find the right tool for resolving compound names to ThermoML IDs.

### Recommended Plan

**Phase 1** (explore submenu):
- `query/id_resolution` — Inspect available ID resolution tools to identify the correct one for name-to-ID lookup

**Phase 2** (after Phase 1 results):
- Call the appropriate name-resolution tool(s) from `query/id_resolution`, likely in **parallel** for all four names:
  - resolve(`name="ethanol"`)
  - resolve(`name="ethyl alcohol"`)
  - resolve(`name="water"`)
  - resolve(`name="aqua"`)

### Notes
- "ethanol" and "ethyl alcohol" are synonyms and should resolve to the same ThermoML compound ID; same expectation for "water" and "aqua".
- If the tool supports **batch input** (a list of names in one call), prefer that over four separate calls to reduce latency.
- If fuzzy/synonym matching is available in the submenu, it should be preferred over exact-match lookup, since "ethyl alcohol" and "aqua" are common aliases rather than IUPAC names.
- Need to drill into `query/id_resolution` submenu first to confirm exact tool name and argument schema before dispatching.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (browse_subagent_tools). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Attempting browse_subagent_tools with explicit purpose/tasks strings to discover the actual tool names for compound ID resolution.</summary>
<tool_call>browse_subagent_tools()</tool_call>

## User
<tool_result>
I need to explore the `query/id_resolution` submenu, as it's the most likely location for compound name lookup tools.

### Recommended Plan

**Phase 1** (parallel):
- `submenu("query/id_resolution")` — Explore the ID resolution tools, which are specifically designed for resolving names/identifiers to canonical compound IDs
- `submenu("query/compound_similarity")` — Explore similarity tools as a fallback for fuzzy name matching (e.g., "aqua" vs "water")

### Notes
- The `query/id_resolution` submenu (6 tools) is the primary target — it almost certainly contains name-to-ID lookup functionality for resolving synonyms like "ethanol"/"ethyl alcohol" and "water"/"aqua".
- The `query/compound_similarity` submenu (1 tool) may handle cases where exact name matching fails and a similarity/synonym search is needed.
- Analysis tools are not relevant for this name-resolution purpose.

[WAIT BARRIER COMPLETE] 1 tool(s) finished (browse_subagent_tools). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Using run_query_agent to resolve all four compound names ("ethanol", "ethyl alcohol", "water", "aqua") to their canonical ThermoML compound identifiers.</summary>
<tool_call>run_query_agent(question=Resolve the follo…, context=The user wants to…)</tool_call>

## User
<tool_result>
<subagent_answer>
{
  "answer": "{\n  \"answer\": \"Here are the resolution results for all four compound name synonyms in the ThermoML database:\\n\\n## Synonym Resolution Summary\\n\\n| Input Name | Canonical ID | Canonical Name | Molecular Formula | CAS Number |\\n|------------|-------------|----------------|-------------------|------------|\\n| ethanol | GLOBcomp_2 | ethanol | C₂H₆O | Not stored in ThermoML |\\n| ethyl alcohol | GLOBcomp_2 | ethanol | C₂H₆O | Not stored in ThermoML |\\n| water | GLOBcomp_1 | water | H₂O | Not stored in ThermoML |\\n| aqua | GLOBcomp_1 | water | H₂O | Not stored in ThermoML |\\n\\n### Key Findings\\n\\n1. **\\\"Ethanol\\\" and \\\"ethyl alcohol\\\"** are exact synonyms that both resolve to the same canonical compound entry: **GLOBcomp_2** (ethanol, C₂H₆O, SMILES: CCO).\\n\\n2. **\\\"Water\\\" and \\\"aqua\\\"** both refer to the same substance: **GLOBcomp_1** (water, H₂O, SMILES: O). The name \\\"water\\\" resolves exactly (score 100) to GLOBcomp_1, while \\\"aqua\\\" does not have its own registered entry in ThermoML — fuzzy matches for \\\"aqua\\\" return only complex coordination compounds containing \\\"aqua\\\" as a substring (e.g., \\\"diaquabis…\\\"), not water itself. Nonetheless, both names refer to the same chemical substance H₂O.\\n\\n3. **CAS registry numbers are not stored** as an explicit field in ThermoML compound records. The primary unique chemical identifiers used by ThermoML are **InChI Keys**:\\n   - Water: `XLYOFNOQVPJJNP-UHFFFAOYSA-N`\\n   - Ethanol: `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`\\n\\n### Implications for Dataset Merging\\n\\nSince both synonym pairs map to single canonical compounds (GLOBcomp_1 for water/aqua and GLOBcomp_2 for ethanol/ethyl alcohol), aqueous-alcohol datasets using any of these name variants can be safely merged under the canonical compound identifiers without risk of duplicate or mismatched compound entries. The InChI Keys listed above can serve as reliable cross-reference keys for this purpose.\",\n  \"core_claims\": [\n    \"In the ThermoML database, \\\"ethanol\\\" and \\\"ethyl alcohol\\\" both resolve to the same canonical compound entry GLOBcomp_2 (ethanol, C₂H₆O), and \\\"water\\\" and \\\"aqua\\\" both refer to the same substance GLOBcomp_1 (water, H₂O), though \\\"aqua\\\" lacks its own registered entry and only appears as a substring in complex compound names.\",\n    \"CAS registry numbers are not stored as explicit fields in ThermoML compound records; the primary unique chemical identifiers used are InChI Keys (water: XLYOFNOQVPJJNP-UHFFFAOYSA-N; ethanol: LFQSCWFLJHTTHZ-UHFFFAOYSA-N).\",\n    \"Because both synonym pairs map to single canonical compounds, aqueous-alcohol datasets using any of these name variants can be safely merged under the canonical compound identifiers without risk of duplicate or mismatched entries.\"\n  ],\n  \"confidence\": \"high\",\n  \"sources\": [],\n  \"id_catalog_snapshot\": [\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_1\",\n      \"registry_id\": \"water\",\n      \"name\": \"water\"\n    },\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_2\",\n      \"registry_id\": \"ethanol\",\n      \"name\": \"ethanol\"\n    }\n  ],\n  \"follow_up_suggestions\": [\n    \"If CAS registry numbers are needed, cross-reference the InChI Keys (water: XLYOFNOQVPJJNP-UHFFFAOYSA-N, ethanol: LFQSCWFLJHTTHZ-UHFFFAOYSA-N) against an external registry such as PubChem or the CAS Common Chemistry API, as ThermoML does not store CAS numbers as an explicit field.\",\n    \"To merge aqueous-alcohol datasets, use GLOBcomp_1 and GLOBcomp_2 as canonical join keys; note that 'aqua' has no direct registered entry in ThermoML and should be mapped to GLOBcomp_1 manually.\",\n    \"If additional solvent synonyms need resolution (e.g., 'EtOH', 'H2O', 'deionized water'), a similar synonym lookup can be performed against the ThermoML compound registry.\"\n  ]\n}",
  "iterations": 3,
  "elapsed_seconds": 241.95865297317505,
  "tool_count": 3,
  "timed_out": false,
  "agent": "query",
  "_question": "Resolve the following common compound names to their canonical ThermoML compound identifiers: 'ethanol', 'ethyl alcohol', 'water', and 'aqua'. For each name, return the canonical ThermoML compound ID (GLOBcomp_N format), the canonical name, CAS number, and molecular formula.",
  "_session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q3.1_run_20260802_210938\\query_runs\\run_19"
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_query_agent). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>
## Canonical ThermoML Compound Resolution

All four names you are using map to just **two** canonical ThermoML compounds:

| Name you used | Canonical ID | Canonical name | Molecular formula | SMILES | InChI Key |
|---|---|---|---|---|---|
| ethanol | **GLOBcomp_2** | ethanol | C₂H₆O | CCO | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |
| ethyl alcohol | **GLOBcomp_2** | ethanol | C₂H₆O | CCO | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |
| water | **GLOBcomp_1** | water | H₂O | O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |
| aqua | **GLOBcomp_1** | water | H₂O | O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |

### Key details

1. **"Ethanol" and "ethyl alcohol"** are exact synonyms that both resolve to the same canonical entry **GLOBcomp_2** (ethanol, C₂H₆O).

2. **"Water" and "aqua"** both refer to **GLOBcomp_1** (water, H₂O). The name "water" matches exactly in the ThermoML registry, while "aqua" does not have its own registered entry — fuzzy matching on "aqua" returns only complex coordination compounds that contain "aqua" as a substring (e.g., "diaquabis…"). Nonetheless, both names denote the same substance H₂O and should be mapped to GLOBcomp_1.

3. **CAS registry numbers are not stored** as an explicit field in ThermoML compound records. The primary unique chemical identifiers used by ThermoML are **InChI Keys** (listed in the table above). If you need CAS numbers, you can cross-reference these InChI Keys against an external registry such as PubChem or the CAS Common Chemistry API.

### Practical advice for merging your datasets

Since both synonym pairs collapse to single canonical compounds, you can safely merge all your aqueous-ethanol datasets by joining on **GLOBcomp_1** (water) and **GLOBcomp_2** (ethanol) — regardless of which name variant was used in the original source. Just be aware that "aqua" must be mapped to GLOBcomp_1 manually, as it has no direct registered entry in ThermoML.
</answer>
# Delegated query run — result

**Question:** Find experimental data for speed of sound, density, or viscosity of ethanol + water binary mixtures near room temperature (around 293-303 K). Return DOIs, block numbers, compound names, and representative data points.

**Iterations:** 25  |  **Elapsed:** 1544.6s  |  **Tools:** 7  |  **Timed out:** True

---

## Answer

## Experimental Transport and Volumetric Property Data for Ethanol + Water Binary Mixtures (293–303 K)

### Overview

Ethanol (C₂H₅OH) + water (H₂O) is a classic binary system that exhibits pronounced non-ideal behavior — including a viscosity maximum near ~0.3 mole fraction ethanol due to extensive hydrogen-bonding network restructuring. The ThermoML database contains experimental data for this system. Below are the results found.

---

### Dynamic Viscosity (GLOBprop_4)

Multiple literature sources in the ThermoML database report dynamic viscosity for ethanol + water binary mixtures in the 293–303 K range. Representative findings from the successful query:

The database contains data blocks with dynamic viscosity measurements for the ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary system near room temperature. Viscosity of this mixture is well known to show a maximum at intermediate compositions (~x_ethanol ≈ 0.3), where the value can exceed the viscosity of either pure component by a factor of ~3, reflecting the strong intermolecular hydrogen-bonding interactions between ethanol and water molecules.

---

### Density (GLOBprop_1) and Speed of Sound (GLOBprop_8)

The queries for density and speed of sound encountered internal checksum errors during the search, preventing retrieval of specific data blocks and values for those two properties. These properties are expected to be present in the database for this well-studied system, but the specific block numbers, DOIs, and data points could not be confirmed in the available query cycles.

---

### Compound Identifiers (Confirmed)

| Compound | Global ID | Formula | SMILES |
|----------|-----------|---------|--------|
| Water | GLOBcomp_1 | H₂O | O |
| Ethanol | GLOBcomp_2 | C₂H₆O | CCO |

---

### What Was Found vs. What Is Missing

- **Found:** Confirmation that dynamic viscosity data for ethanol + water binary mixtures exists in the ThermoML database near 293–303 K, with multiple literature sources available.
- **Missing:** Specific DOIs, block numbers, and representative numerical data points for density and speed of sound could not be retrieved due to query errors. Detailed numerical viscosity values and their associated DOIs/block numbers from the successful query were partially returned but could not be fully inspected before the time limit.

### Chemistry Note

The ethanol–water system is a textbook example of non-ideal mixing. Excess molar volumes are negative (the mixture is denser than ideal mixing would predict), speed of sound shows composition-dependent anomalies, and viscosity exhibits a pronounced maximum — all consequences of the restructuring of hydrogen-bond networks when ethanol molecules are inserted into the water lattice. These properties make this system one of the most frequently measured binary mixtures in thermodynamic databases.

### Core claims

- The ThermoML database contains dynamic viscosity data for ethanol + water binary mixtures in the 293–303 K range from multiple literature sources.
- Specific density and speed-of-sound data blocks for ethanol + water could not be retrieved due to query errors, although these properties are expected to be present in the database.
- The ethanol–water system exhibits pronounced non-ideal mixing behavior, including a viscosity maximum near ~0.3 mole fraction ethanol, negative excess molar volumes, and composition-dependent speed-of-sound anomalies, all attributed to hydrogen-bond network restructuring.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_21 |  | Dynamic viscosity (GLOBprop_4, Pa·s) of ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary mixture at 293.15–308.15 K. Mole fraction of ethanol ranges 0.0–1.0 (25 unique compositions). 100 data points total; 75 in the 293–303 K target range. Viscosity range 0.000759–0.002864 Pa·s. Measured by concentric cylinders viscometry (GLOBmeas_11). Pressure constraint 92.3 kPa. Liquid phase (GLOBphase_1). |
| GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | PROPblock_11 |  | Dynamic viscosity (GLOBprop_4, Pa·s) of ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary mixture at 293.15–303.15 K. Full composition range x = 0–1 (13 unique compositions). 37 data points total; 17 in the 293–303 K target range. Viscosity range 0.000797–0.002705 Pa·s. Pressure constraint 101.0 kPa. Liquid phase (GLOBphase_1). |

### Suggested follow-ups

- Retry L1_query for mass density (GLOBprop_1) of the GLOBcomp_2 + GLOBcomp_1 binary system; previous attempts failed with checksum mismatches during core-ID refinement.
- Retry L1_query for speed of sound (GLOBprop_8) of the GLOBcomp_2 + GLOBcomp_1 binary system; previous attempts also failed with checksum mismatches.
- Query L2 for specific data-point values from GLOBlit_5201 PROPblock_21 at 298.15 K to obtain representative viscosity vs. composition data showing the non-ideal maximum.
- Search for excess molar volume (GLOBprop_2) data for the ethanol + water binary system to complement the viscosity findings with volumetric non-ideality evidence.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density",
    "name": "Mass density (not retrieved due to query errors)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_8",
    "registry_id": "speed_of_sound",
    "name": "Speed of sound (not retrieved due to query errors)"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction",
    "name": "Mole fraction"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  }
]
```

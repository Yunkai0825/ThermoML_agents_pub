# Reference Stats — query-agent

**Run started:** 2026-08-02 20:44:54
**Wall time (at last flush):** 1,574.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 50,969 | 58,123 | 16,372 | 109,092 | 13,636 | 89.3 | claudeopus46 |
| L1-worker | 100 | 1,013,052 | 627,647 | 283,291 | 1,640,699 | 16,406 | 1516.9 | claudeopus46 |
| **TOTAL** | **108** | **1,064,021** | **685,770** | **299,663** | **1,749,791** | **16,201** | **1606.2** | |

**Estimated tokens:** ~437,447 input + ~74,915 output = ~512,362 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 5 | 3 | 10 | 10 | 1,929 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 7 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 5 | 3 | 15 | 15 | 2,144 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 5 | 3 | 15 | 15 | 2,144 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 5 | 3 | 10 | 10 | 1,929 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 4 | 4 | 4 | 212 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 4 | 3 | 10 | 10 | 334 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| **TOTAL** | **26** | **6** | **29** | **19** | **65** | **64** | **8,692** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_151 |  | resolve_compound_ids |
| GLOBcomp_177 |  | resolve_compound_ids |
| GLOBcomp_496 |  | resolve_compound_ids |
| GLOBcomp_3276 |  | resolve_compound_ids |
| GLOBcomp_4401 |  | resolve_compound_ids |
| GLOBcomp_143 |  | resolve_compound_ids |

#### Variables (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### References (21 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_220 |  | search_blocks |
| GLOBlit_1483 |  | search_blocks |
| GLOBlit_2432 |  | search_blocks |
| GLOBlit_2825 |  | search_blocks |
| GLOBlit_3475 |  | search_blocks |
| GLOBlit_4415 |  | search_blocks |
| GLOBlit_5201 |  | block_search_adv, search_blocks |
| GLOBlit_5473 |  | search_blocks |
| GLOBlit_7085 |  | search_blocks |
| GLOBlit_7178 |  | search_blocks |
| GLOBlit_7448 |  | search_blocks |
| GLOBlit_7676 |  | search_blocks |
| GLOBlit_8050 |  | search_blocks |
| GLOBlit_8888 |  | search_blocks |
| GLOBlit_9006 |  | search_blocks |
| GLOBlit_11504 |  | search_blocks |
| GLOBlit_10159 |  | search_blocks |
| GLOBlit_10699 |  | search_blocks |
| GLOBlit_11005 |  | search_blocks |
| GLOBlit_11136 |  | search_blocks |
| GLOBlit_11792 |  | search_blocks |

#### Properties (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |
| GLOBprop_8 | Speed of sound, m/s | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (15 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_66 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_236 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks |
| GLOBmeas_206 | Speed of sound, m/s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_988 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |
| GLOBsolvent_2 |  | search_blocks |

#### Constraints (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_8 | Molality, mol/kg | search_blocks |
| GLOBconstr_4 | Frequency, MHz | search_blocks |
| GLOBconstr_22 | Volume fraction | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 8 |
| Unique Variables | 5 |
| Unique References | 21 |
| Unique Properties | 3 |
| Unique Measurements | 15 |
| Unique Phases | 1 |
| Unique Solvents | 2 |
| Unique Constraints | 5 |
| Unique Block_Types | 1 |
| Total DOIs | 21 |
| Unique parent blocks | 29 |
| Explicit block/subsystem targets | 29 |
| Subsystem targets | 0 |
| Target-matched data points | 8,692 |

---

## 3. DOI & Block References

**Unique DOIs:** 21  |  **Parent blocks:** 29  |  **Explicit targets:** 29  |  **Subsystems:** 0  |  **Target-matched datapoints:** 2,690

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | search_blocks |
| 10.1016/j.fluid.2014.05.032 | 1 | 140 | binary | search_blocks |
| 10.1016/j.jct.2004.07.019 | 1 | 565 | binary | search_blocks |
| 10.1016/j.jct.2007.05.004 | 2 | 74 | binary | search_blocks |
| 10.1016/j.jct.2011.10.009 | 1 | 70 | binary | search_blocks |
| 10.1016/j.jct.2015.06.024 | 2 | 80 | binary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 3 | 496 | binary | search_blocks |
| 10.1016/j.jct.2019.02.027 | 1 | 9 | binary | search_blocks |
| 10.1021/acs.jced.6b01058 | 1 | 12 | binary | search_blocks |
| 10.1021/acs.jced.7b00299 | 2 | 4 | binary | search_blocks |
| 10.1021/acs.jced.8b00086 | 2 | 12 | binary | search_blocks |
| 10.1021/acs.jced.8b00939 | 2 | 18 | binary | search_blocks |
| 10.1021/je020173z | 1 | 24 | binary | search_blocks |
| 10.1021/je0601098 | 2 | 24 | binary | search_blocks |
| 10.1021/je060335h | 1 | 164 | binary | search_blocks |
| 10.1021/je4003515 | 1 | 25 | binary | search_blocks |
| 10.1021/je600565m | 1 | 17 | binary | search_blocks |
| 10.1021/je700618y | 1 | 15 | binary | search_blocks |
| 10.1021/je800150h | 1 | 108 | binary | search_blocks |
| 10.1021/je900064e | 1 | 8 | binary | search_blocks |
| 10.1021/je900743e | 1 | 15 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | — | search_blocks |
| 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.004 | PROPblock_11 | declared | 37 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.004 | PROPblock_12 | declared | 37 | binary | — | search_blocks |
| 10.1016/j.jct.2011.10.009 | PROPblock_3 | declared | 70 | binary | — | search_blocks |
| 10.1016/j.jct.2015.06.024 | PROPblock_7 | declared | 40 | binary | — | search_blocks |
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_21 | declared | 100 | binary | — | search_blocks |
| 10.1016/j.jct.2019.02.027 | PROPblock_21 | declared | 9 | binary | — | search_blocks |
| 10.1021/acs.jced.6b01058 | PROPblock_7 | declared | 12 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00299 | PROPblock_10 | declared | 2 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00299 | PROPblock_11 | declared | 2 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00086 | PROPblock_46 | declared | 6 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00086 | PROPblock_47 | declared | 6 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00939 | PROPblock_17 | declared | 9 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00939 | PROPblock_18 | declared | 9 | binary | — | search_blocks |
| 10.1021/je020173z | PROPblock_5 | declared | 24 | binary | — | search_blocks |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | — | search_blocks |
| 10.1021/je0601098 | PROPblock_20 | declared | 12 | binary | — | search_blocks |
| 10.1021/je060335h | PROPblock_1 | declared | 164 | binary | — | search_blocks |
| 10.1021/je4003515 | PROPblock_8 | declared | 25 | binary | — | search_blocks |
| 10.1021/je600565m | PROPblock_5 | declared | 17 | binary | — | search_blocks |
| 10.1021/je700618y | PROPblock_7 | declared | 15 | binary | — | search_blocks |
| 10.1021/je800150h | PROPblock_8 | declared | 108 | binary | — | search_blocks |
| 10.1021/je900064e | PROPblock_5 | declared | 8 | binary | — | search_blocks |
| 10.1021/je900743e | PROPblock_2 | declared | 15 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 241 | KEEP | 241 | 5.1 |
| 2 | 6 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 325 | KEEP | 325 | 4.0 |
| 3 | 1 | `L1_query` | context=Ethanol is also known as C2H5…, id_catalog… | 416 | — | — | 386.2 |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 251 | KEEP | 251 | 3.8 |
| 5 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 134 | KEEP | 134 | 21.5 |
| 6 | 2 | `L1_query` | context=Looking for mixture density d…, id_catalog… | 420 | — | — | 241.8 |
| 7 | 1 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve ethanol co… | 251 | KEEP | 251 | 5.1 |
| 8 | 3 | `L1_query` | context=Need to resolve ethanol's com…, id_catalog… | 1,023 | — | — | 28.0 |
| 9 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve the global … | 254 | KEEP | 254 | 4.5 |
| 10 | 3 | `L1_query` | context=Need to resolve water's compo…, id_catalog… | 1,002 | — | — | 24.5 |
| 11 | 2 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=15, p… | 144 | — | — | 38.8 |
| 12 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=15, p… | 144 | KEEP | 217 | 38.4 |
| 13 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 217 | KEEP | 809 | 20.9 |
| 14 | 4 | `L1_query` | context=Ethanol (GLOBcomp_2, C2H6O, C…, id_catalog… | 447 | — | — | 342.9 |
| 15 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 839 | KEEP | 769 | 14.8 |
| 16 | 4 | `L1_query` | context=Ethanol (GLOBcomp_2, C2H6O, C…, id_catalog… | 383 | — | — | 179.5 |
| 17 | 2 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 799 | — | — | 21.5 |
| 18 | 6 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 848 | DISCARD | 787 | 18.3 |
| 19 | 9 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 1,141 | KEEP | 1096 | 21.0 |
| 20 | 4 | `L1_query` | context=Ethanol (GLOBcomp_2, C2H6O, C…, id_catalog… | 15,984 | — | — | 285.6 |
| | | **TOTAL (20 tools)** | | **25,263** | | **5,134** | **1706.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 18,992 | 18,992 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 3,312 | 3,312 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 3,401 | 3,401 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 4,934 | 4,934 | 0 | 0.0% |
| 5 | interval=3 | skipped_by_agent | 7,421 | 7,421 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 894 | 10,499 | 1,519 | 7.7 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,306 | 21,949 | 849 | 8.2 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,776 | 23,419 | 819 | 4.8 |
| 4 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 419 | 4.9 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,909 | 23,552 | 14,867 | 51.5 |
| 6 | L1-worker | claudeopus46 | 20,643 | 18,611 | 39,254 | 11,851 | 63.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 19,685 | 40,328 | 14,539 | 68.9 |
| 8 | L1-worker | claudeopus46 | 20,643 | 20,362 | 41,005 | 11,632 | 59.6 |
| 9 | L1-worker | claudeopus46 | 2,065 | 484 | 2,549 | 518 | 3.9 |
| 10 | L1-worker | claudeopus46 | 20,610 | 20,364 | 40,974 | 374 | 3.8 |
| 11 | L1-worker | claudeopus46 | 20,643 | 19,737 | 40,380 | 3,791 | 22.6 |
| 12 | L1-worker | claudeopus46 | 1,356 | 3,188 | 4,544 | 1,085 | 6.1 |
| 13 | L1-worker | claudeopus46 | 536 | 3,068 | 3,604 | 1,197 | 7.0 |
| 14 | L1-worker | claudeopus46 | 298 | 1,467 | 1,765 | 1,073 | 3.6 |
| 15 | L1-worker | claudeopus46 | 1,323 | 8,755 | 10,078 | 10,273 | 35.8 |
| 16 | L1-worker | claudeopus46 | 298 | 10,995 | 11,293 | 8,290 | 28.4 |
| 17 | L1-worker | claudeopus46 | 1,160 | 21,465 | 22,625 | 8,227 | 29.0 |
| 18 | L0-main | claudeopus46 | 9,605 | 1,844 | 11,449 | 1,113 | 7.4 |
| 19 | L1-worker | claudeopus46 | 20,643 | 1,056 | 21,699 | 743 | 5.4 |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,420 | 23,063 | 12,430 | 66.7 |
| 21 | L1-worker | claudeopus46 | 2,065 | 460 | 2,525 | 435 | 3.7 |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,609 | 23,252 | 10,550 | 54.1 |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,342 | 23,985 | 650 | 4.8 |
| 24 | L1-worker | claudeopus46 | 2,065 | 7,114 | 9,179 | 1,627 | 13.5 |
| 25 | L1-worker | claudeopus46 | 20,643 | 3,617 | 24,260 | 8,107 | 46.0 |
| 26 | L1-worker | claudeopus46 | 20,643 | 12,299 | 32,942 | 2,427 | 9.5 |
| 27 | L1-worker | claudeopus46 | 536 | 2,436 | 2,972 | 820 | 5.8 |
| 28 | L1-worker | claudeopus46 | 1,356 | 2,556 | 3,912 | 1,092 | 7.2 |
| 29 | L1-worker | claudeopus46 | 1,323 | 6,106 | 7,429 | 2,463 | 11.7 |
| 30 | L1-worker | claudeopus46 | 298 | 3,185 | 3,483 | 1,885 | 7.6 |
| 31 | L1-worker | claudeopus46 | 1,160 | 9,072 | 10,232 | 1,905 | 9.5 |
| 32 | L0-main | claudeopus46 | 9,605 | 2,771 | 12,376 | 1,644 | 8.8 |
| 33 | L1-worker | claudeopus46 | 20,643 | 917 | 21,560 | 462 | 4.3 |
| 34 | L1-worker | claudeopus46 | 2,065 | 816 | 2,881 | 452 | 4.6 |
| 35 | L1-worker | claudeopus46 | 20,643 | 1,584 | 22,227 | 317 | 5.4 |
| 36 | L1-worker | claudeopus46 | 1,323 | 1,917 | 3,240 | 162 | 2.8 |
| 37 | L1-worker | claudeopus46 | 1,356 | 446 | 1,802 | 163 | 2.8 |
| 38 | L1-worker | claudeopus46 | 536 | 326 | 862 | 282 | 4.3 |
| 39 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 3.9 |
| 40 | L1-worker | claudeopus46 | 747 | 1,933 | 2,680 | 385 | 6.2 |
| 41 | L1-worker | claudeopus46 | 20,643 | 2,046 | 22,689 | 467 | 3.9 |
| 42 | L1-worker | claudeopus46 | 20,643 | 3,134 | 23,777 | 757 | 4.7 |
| 43 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 477 | 4.4 |
| 44 | L1-worker | claudeopus46 | 20,643 | 3,265 | 23,908 | 307 | 2.6 |
| 45 | L1-worker | claudeopus46 | 1,356 | 436 | 1,792 | 171 | 2.4 |
| 46 | L1-worker | claudeopus46 | 1,323 | 2,091 | 3,414 | 162 | 2.4 |
| 47 | L1-worker | claudeopus46 | 536 | 316 | 852 | 267 | 2.7 |
| 48 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.2 |
| 49 | L1-worker | claudeopus46 | 747 | 2,116 | 2,863 | 393 | 3.8 |
| 50 | L0-main | claudeopus46 | 9,605 | 7,879 | 17,484 | 2,868 | 14.0 |
| 51 | L1-worker | claudeopus46 | 20,643 | 3,476 | 24,119 | 1,245 | 8.5 |
| 52 | L1-worker | claudeopus46 | 20,643 | 5,342 | 25,985 | 14,277 | 56.0 |
| 53 | L1-worker | claudeopus46 | 2,065 | 10,272 | 12,337 | 1,560 | 15.1 |
| 54 | L1-worker | claudeopus46 | 2,065 | 10,482 | 12,547 | 1,540 | 15.5 |
| 55 | L1-worker | claudeopus46 | 20,643 | 5,478 | 26,121 | 12,617 | 58.2 |
| 56 | L1-worker | claudeopus46 | 2,065 | 10,272 | 12,337 | 1,598 | 16.1 |
| 57 | L1-worker | claudeopus46 | 2,065 | 10,482 | 12,547 | 1,512 | 14.4 |
| 58 | L1-worker | claudeopus46 | 20,610 | 6,887 | 27,497 | 577 | 4.5 |
| 59 | L1-worker | claudeopus46 | 20,643 | 6,134 | 26,777 | 795 | 8.8 |
| 60 | L1-worker | claudeopus46 | 2,065 | 7,176 | 9,241 | 1,675 | 13.7 |
| 61 | L1-worker | claudeopus46 | 20,643 | 6,974 | 27,617 | 11,189 | 60.3 |
| 62 | L1-worker | claudeopus46 | 20,643 | 18,784 | 39,427 | 2,783 | 12.7 |
| 63 | L1-worker | claudeopus46 | 1,356 | 2,914 | 4,270 | 829 | 5.8 |
| 64 | L1-worker | claudeopus46 | 536 | 2,794 | 3,330 | 1,049 | 6.7 |
| 65 | L1-worker | claudeopus46 | 298 | 1,211 | 1,509 | 817 | 3.4 |
| 66 | L1-worker | claudeopus46 | 298 | 1,405 | 1,703 | 1,036 | 4.1 |
| 67 | L1-worker | claudeopus46 | 1,323 | 6,711 | 8,034 | 3,912 | 14.7 |
| 68 | L1-worker | claudeopus46 | 298 | 4,634 | 4,932 | 2,894 | 10.7 |
| 69 | L1-worker | claudeopus46 | 1,160 | 11,330 | 12,490 | 1,985 | 9.4 |
| 70 | L1-worker | claudeopus46 | 20,643 | 3,453 | 24,096 | 924 | 6.4 |
| 71 | L1-worker | claudeopus46 | 20,643 | 4,998 | 25,641 | 13,624 | 57.1 |
| 72 | L1-worker | claudeopus46 | 20,643 | 5,761 | 26,404 | 703 | 7.3 |
| 73 | L1-worker | claudeopus46 | 2,065 | 8,182 | 10,247 | 1,710 | 14.3 |
| 74 | L1-worker | claudeopus46 | 20,610 | 6,976 | 27,586 | 633 | 5.2 |
| 75 | L1-worker | claudeopus46 | 20,643 | 6,223 | 26,866 | 8,115 | 49.1 |
| 76 | L1-worker | claudeopus46 | 20,643 | 14,959 | 35,602 | 3,267 | 16.0 |
| 77 | L1-worker | claudeopus46 | 1,356 | 3,016 | 4,372 | 1,000 | 6.8 |
| 78 | L1-worker | claudeopus46 | 536 | 2,896 | 3,432 | 1,104 | 7.9 |
| 79 | L1-worker | claudeopus46 | 1,323 | 6,880 | 8,203 | 1,905 | 9.9 |
| 80 | L1-worker | claudeopus46 | 298 | 1,382 | 1,680 | 988 | 6.2 |
| 81 | L1-worker | claudeopus46 | 298 | 2,627 | 2,925 | 1,481 | 6.7 |
| 82 | L1-worker | claudeopus46 | 1,160 | 9,167 | 10,327 | 1,481 | 6.1 |
| 83 | L1-worker | claudeopus46 | 20,643 | 3,485 | 24,128 | 1,072 | 9.3 |
| 84 | L1-worker | claudeopus46 | 20,643 | 4,250 | 24,893 | 13,180 | 68.9 |
| 85 | L1-worker | claudeopus46 | 2,065 | 6,834 | 8,899 | 1,835 | 13.4 |
| 86 | L1-worker | claudeopus46 | 20,643 | 5,221 | 25,864 | 1,742 | 11.9 |
| 87 | L1-worker | claudeopus46 | 20,643 | 6,104 | 26,747 | 1,239 | 8.5 |
| 88 | L1-worker | claudeopus46 | 20,643 | 6,931 | 27,574 | 1,746 | 11.4 |
| 89 | L1-worker | claudeopus46 | 20,643 | 7,866 | 28,509 | 988 | 6.9 |
| 90 | L1-worker | claudeopus46 | 2,065 | 1,037 | 3,102 | 1,394 | 9.4 |
| 91 | L1-worker | claudeopus46 | 20,610 | 8,584 | 29,194 | 633 | 5.2 |
| 92 | L1-worker | claudeopus46 | 20,643 | 7,831 | 28,474 | 2,247 | 14.3 |
| 93 | L1-worker | claudeopus46 | 20,643 | 8,747 | 29,390 | 1,122 | 8.7 |
| 94 | L1-worker | claudeopus46 | 20,643 | 9,615 | 30,258 | 1,176 | 7.9 |
| 95 | L1-worker | claudeopus46 | 2,065 | 1,879 | 3,944 | 1,752 | 11.4 |
| 96 | L1-worker | claudeopus46 | 20,610 | 11,146 | 31,756 | 444 | 4.8 |
| 97 | L1-worker | claudeopus46 | 20,643 | 10,393 | 31,036 | 1,955 | 12.6 |
| 98 | L1-worker | claudeopus46 | 20,643 | 11,293 | 31,936 | 1,948 | 13.2 |
| 99 | L1-worker | claudeopus46 | 20,643 | 12,280 | 32,923 | 2,646 | 17.6 |
| 100 | L1-worker | claudeopus46 | 536 | 2,104 | 2,640 | 877 | 5.3 |
| 101 | L1-worker | claudeopus46 | 1,356 | 2,224 | 3,580 | 1,052 | 6.5 |
| 102 | L1-worker | claudeopus46 | 1,323 | 19,313 | 20,636 | 1,157 | 7.8 |
| 103 | L1-worker | claudeopus46 | 298 | 1,879 | 2,177 | 931 | 4.5 |
| 104 | L1-worker | claudeopus46 | 747 | 34,002 | 34,749 | 952 | 9.1 |
| 105 | L0-main | claudeopus46 | 9,572 | 7,458 | 17,030 | 2,875 | 17.1 |
| 106 | L0-main | claudeopus46 | 1,356 | 3,006 | 4,362 | 625 | 5.2 |
| 107 | L0-main | claudeopus46 | 1,323 | 30,471 | 31,794 | 3,132 | 18.1 |
| 108 | L0-main | claudeopus46 | 298 | 3,800 | 4,098 | 2,596 | 11.0 |


# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_2 | ethanol | ethanol |
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Resolve the global compound ID for ethanol (C2H5OH, C2H6O) in the ThermoML database → stored as L1_query_1
- [L1] Resolve the global compound ID for water (H2O) in the ThermoML database → stored as L1_query_2
- [L1] Find dynamic viscosity data for ethanol+water binary mixtures near 293-303 K → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "Ethanol is resolved in the ThermoML database as:\n\n- **Global ID:** GLOBcomp_2\n- **Name:** ethanol\n- **Molecular formula:** C2H6O\n- **SMILES:** CCO\n- **Match confidence:** 100 (exact name match)\n\nThis ID (GLOBcomp_2) can be used for subsequent searches for mixture property data involving ethanol.",
  "core_claims": [
    "In the ThermoML database, ethanol (molecular formula C2H6O, SMILES CCO) is resolved as GLOBcomp_2 with 100% confidence via an exact name match."
  ],
  "status": "success",
  "summary": "Ethanol is identified in the ThermoML database with global ID GLOBcomp_2, molecular formula C2H6O, and SMILES CCO. The match was made with 100% confidence via an exact name match. This ID can be used for subsequent searches for mixture property data involving ethanol.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "Water is resolved in the ThermoML database as:\n\n- **Global ID:** GLOBcomp_1\n- **Name:** water\n- **Molecular formula:** H2O\n- **SMILES:** O\n- **Match confidence:** 100 (exact name match)\n\nThis ID (GLOBcomp_1) can be used for subsequent searches for mixture property data involving water.",
  "core_claims": [
    "Water is resolved in the ThermoML database as GLOBcomp_1, with molecular formula H2O and SMILES 'O', based on an exact name match with 100% confidence."
  ],
  "status": "success",
  "summary": "Water is identified in the ThermoML database with the global ID GLOBcomp_1, matching exactly by name. Its molecular formula is H2O and its SMILES representation is O. This ID can be used for subsequent searches for mixture property data involving water.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": []
}
### L1_query_3
{
  "answer": "## Dynamic Viscosity Data for Ethanol + Water Binary Mixtures (293–303 K)\n\nThe ThermoML database contains multiple data blocks with dynamic viscosity (GLOBprop_4, Pa·s) measurements for the binary system ethanol (GLOBcomp_2) + water (GLOBcomp_1) in the 293–303 K temperature range. A total of **10 blocks** were identified across several literature sources.\n\n### Key Literature Sources\n\n**1. DOI: 10.1016/j.jct.2018.02.022 (GLOBlit_5201)**\n- **Block:** PROPblock_21\n- **Temperature range:** 293.15–303.15 K\n- **Composition range:** x(ethanol) = 0.0201–0.929 (near-full range)\n- **Data points in range:** 75 out of 100 total declared points\n- **Mean viscosity:** ~0.00172 Pa·s (1.72 mPa·s)\n- **Variables:** Temperature (GLOBvar_1, K), mole fraction of ethanol (GLOBvar_2), all in liquid phase (GLOBphase_1)\n\n**2. DOI: 10.1016/j.jct.2007.05.004 (GLOBlit_2825)**\n- **Block:** PROPblock_11\n- **Temperature range:** 293.15–303.15 K\n- **Composition range:** x(water) = 0–1 (full composition range)\n- **Data points in range:** 17 out of 37 total declared points\n\n### Chemistry Insight\n\nThe ethanol–water system is a classic example of **non-ideal mixing behavior** in viscosity. At intermediate compositions (roughly x(ethanol) ≈ 0.2–0.4), the dynamic viscosity passes through a pronounced maximum that significantly exceeds the viscosity of either pure component. At ~298 K, pure water has η ≈ 0.89 mPa·s and pure ethanol η ≈ 1.08 mPa·s, but the mixture viscosity can reach ~2.5–3 mPa·s at the peak composition. This non-ideal enhancement arises from strong hydrogen-bonding interactions between ethanol and water molecules, which create more structured, cooperative networks than exist in either pure liquid. The mean viscosity of ~1.72 mPa·s across all compositions in the GLOBlit_5201 dataset reflects this elevation above the pure-component values.\n\nBoth datasets provide systematic coverage of composition at multiple temperatures within the 293–303 K window, making them suitable for studying the composition- and temperature-dependence of this non-ideal viscosity behavior.",
  "core_claims": [
    "The ThermoML database contains 10 data blocks with dynamic viscosity measurements for the ethanol + water binary system in the 293–303 K range, drawn from multiple literature sources.",
    "The most extensive dataset (DOI: 10.1016/j.jct.2018.02.022, PROPblock_21) covers ethanol mole fractions from 0.0201 to 0.929 at 293.15–303.15 K, with 75 data points in range and a mean viscosity of approximately 1.72 mPa·s.",
    "A second dataset (DOI: 10.1016/j.jct.2007.05.004, PROPblock_11) spans the full water mole-fraction range at 293.15–303.15 K, contributing 17 data points in range.",
    "The ethanol–water system exhibits pronounced non-ideal mixing in viscosity: at ~298 K the mixture viscosity reaches approximately 2.5–3 mPa·s near x(ethanol) ≈ 0.2–0.4, substantially exceeding the pure-component values of ~0.89 mPa·s (water) and ~1.08 mPa·s (ethanol).",
    "The viscosity maximum is attributed to strong hydrogen-bonding interactions between ethanol and water molecules forming cooperative networks more structured than in either pure liquid."
  ],
  "status": "partial",
  "summary": "The ThermoML database contains 10 data blocks with dynamic viscosity (Pa·s) measurements for the ethanol + water binary system in the 293–303 K range. Two key sources are highlighted: DOI 10.1016/j.jct.2018.02.022 (75 data points, x(ethanol) = 0.0201–0.929, mean viscosity ~1.72 mPa·s) and DOI 10.1016/j.jct.2007.05.004 (17 data points, full composition range). The ethanol–water system exhibits pronounced non-ideal mixing in viscosity, with a maximum at intermediate compositions (x(ethanol) ≈ 0.2–0.4) reaching ~2.5–3 mPa·s at ~298 K, well above either pure component (~0.89 mPa·s for water, ~1.08 mPa·s for ethanol). This enhancement is attributed to strong cooperative hydrogen-bonding networks between ethanol and water molecules. Both datasets provide systematic composition and temperature coverage suitable for studying this non-ideal viscosity behavior.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_5201",
      "block_number": "PROPblock_21",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) of ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary mixture at 293.15–303.15 K. Mole fraction of ethanol ranges 0.0201–0.929. 75 data points in the target temperature range out of 100 declared. Mean viscosity ~0.00172 Pa·s. DOI: 10.1016/j.jct.2018.02.022.",
      "doi": "10.1016/j.jct.2018.02.022",
      "lit_id": "2018-hog-tor-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 100,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 92.3,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 308.15,
            "n_unique": 4
          },
          "range_min": 293.15,
          "range_max": 308.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 25
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_11",
          "meas_ID": "concentric_cylinders_viscometry",
          "method_standard": "Concentric cylinders viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000759,
            "max": 0.002864,
            "mean": 0.001611,
            "std": 0.000493,
            "n": 100
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000759,
          "range_max": 0.002864
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "parent_n_datapoints": 100,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2825",
      "block_number": "PROPblock_11",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) of ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary mixture at 293.15–303.15 K. Full composition range x(water) = 0–1. 17 data points in the target temperature range out of 37 declared. DOI: 10.1016/j.jct.2007.05.004.",
      "doi": "10.1016/j.jct.2007.05.004",
      "lit_id": "2007-gon-cal-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 37,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000797,
            "max": 0.002705,
            "mean": 0.001607,
            "std": 0.000514,
            "n": 37
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000797,
          "range_max": 0.002705
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 37,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


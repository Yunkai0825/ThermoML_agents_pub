# Reference Stats — query-agent

**Run started:** 2026-08-02 20:44:54
**Wall time (at last flush):** 159.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 22,485 | 58,468 | 13,639 | 80,953 | 13,492 | 78.5 | claudeopus46 |
| L1-worker | 12 | 111,572 | 82,172 | 16,197 | 193,744 | 16,145 | 95.8 | claudeopus46 |
| **TOTAL** | **18** | **134,057** | **140,640** | **29,836** | **274,697** | **15,260** | **174.3** | |

**Estimated tokens:** ~68,674 input + ~7,459 output = ~76,133 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 5 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **4** | **0** | **0** | **0** | **5** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### References (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_528 |  | block_search_adv |
| GLOBlit_1482 |  | block_search_adv |
| GLOBlit_2574 |  | block_search_adv |
| GLOBlit_4181 |  | block_search_adv |
| GLOBlit_6377 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 5 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve ethanol and… | 380 | KEEP | 380 | 4.1 |
| 2 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 1,145 | KEEP | 1145 | 13.2 |
| 3 | 1 | `L1_query` | context=Property ID for excess molar …, id_catalog… | 270 | — | — | 90.0 |
| | | **TOTAL (3 tools)** | | **1,795** | | **1,525** | **107.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,639 | 3,639 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 901 | 10,506 | 1,368 | 8.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,187 | 21,830 | 675 | 5.0 |
| 3 | L1-worker | claudeopus46 | 2,065 | 461 | 2,526 | 568 | 4.0 |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,045 | 22,688 | 1,360 | 9.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,940 | 23,583 | 1,246 | 8.9 |
| 6 | L1-worker | claudeopus46 | 2,065 | 4,308 | 6,373 | 1,513 | 11.0 |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,934 | 25,544 | 456 | 3.9 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,181 | 24,824 | 2,404 | 14.2 |
| 9 | L1-worker | claudeopus46 | 1,356 | 2,087 | 3,443 | 776 | 4.9 |
| 10 | L1-worker | claudeopus46 | 536 | 1,967 | 2,503 | 956 | 5.9 |
| 11 | L1-worker | claudeopus46 | 1,323 | 7,247 | 8,570 | 3,254 | 12.5 |
| 12 | L1-worker | claudeopus46 | 298 | 3,976 | 4,274 | 2,395 | 9.5 |
| 13 | L1-worker | claudeopus46 | 747 | 46,839 | 47,586 | 594 | 6.5 |
| 14 | L0-main | claudeopus46 | 9,605 | 43,253 | 52,858 | 5,603 | 35.5 |
| 15 | L0-main | claudeopus46 | 1,356 | 3,922 | 5,278 | 891 | 5.4 |
| 16 | L0-main | claudeopus46 | 298 | 1,273 | 1,571 | 879 | 3.7 |
| 17 | L0-main | claudeopus46 | 1,323 | 5,886 | 7,209 | 2,565 | 16.7 |
| 18 | L0-main | claudeopus46 | 298 | 3,233 | 3,531 | 2,333 | 8.9 |


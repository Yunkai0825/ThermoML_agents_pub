# Delegated query run — result

**Question:** Find experimental data for excess molar enthalpy (HE) or enthalpy of mixing of ethanol + water binary mixtures near room temperature (around 293-303 K). Return DOIs, block numbers, compound names, and representative data points.

**Iterations:** 2  |  **Elapsed:** 134.1s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Excess Molar Enthalpy (H^E) Data for Ethanol + Water near 298 K

The ThermoML database contains several datasets reporting the excess molar enthalpy (enthalpy of mixing) for the binary system ethanol (C₂H₆O) + water (H₂O) in the liquid phase. Six data blocks from five literature sources were identified; four of these contain measurements at or very near 298.15 K:

---

### Datasets at 298.15 K

**1. DOI: 10.1016/j.fluid.2007.06.007 — PROPblock_1**
- **Literature ID:** GLOBlit_528
- **Conditions:** T = 298.15 K, P = 101 kPa
- **Composition range:** x(ethanol) = 0.000102 – 0.001551 (very dilute ethanol)
- **H^E range:** −0.001 to −0.015 kJ/mol (15 data points, mean = −0.008 kJ/mol)
- **Method:** Calvet calorimetry
- *Probes the infinite-dilution regime of ethanol in water.*

**2. DOI: 10.1016/j.fluid.2007.06.007 — PROPblock_2**
- **Literature ID:** GLOBlit_528
- **Conditions:** T = 298.15 K, P = 101 kPa
- **Composition range:** x(water) = 0.001021 – 0.015286 (very dilute water in ethanol)
- **H^E range:** −0.002 to −0.030 kJ/mol (15 data points, mean = −0.016 kJ/mol)
- **Method:** Calvet calorimetry
- *Probes the infinite-dilution regime of water in ethanol.*

**3. DOI: 10.1016/j.jct.2005.06.018 — PROPblock_4**
- **Literature ID:** GLOBlit_2574
- **Conditions:** T = 298.15–323.15 K, P = 101 kPa
- **Composition range:** x(ethanol) = 0.033 – 0.968 (full composition range)
- **H^E range:** −0.770 to −0.018 kJ/mol (27 data points, mean = −0.325 kJ/mol)
- **Method:** Calvet calorimetry (custom variant)
- *This is the most comprehensive near-298 K dataset, spanning nearly the entire mole-fraction range. All measured H^E values are exothermic (negative), with the most negative value (−0.77 kJ/mol) occurring at intermediate compositions.*

**4. DOI: 10.1016/j.tca.2017.05.023 — PROPblock_1**
- **Literature ID:** GLOBlit_6377
- **Conditions:** T = 298.15 K, P = 100 kPa
- **Composition:** x(ethanol) = 0.102
- **H^E = −0.707 kJ/mol** (single data point)
- **Method:** Flow calorimetry
- *A single-point measurement at a water-rich composition, consistent with the exothermic mixing expected at low ethanol mole fractions.*

---

### Datasets at Higher Temperatures (also in the database, but not near 298 K)

**5. DOI: 10.1016/j.fluid.2014.05.031 — PROPblock_4** (GLOBlit_1482)
- T = 333–383 K, P = 1203–1824 kPa, 56 points, H^E = −0.308 to +0.579 kJ/mol

**6. DOI: 10.1016/j.jct.2014.05.020 — PROPblock_1** (GLOBlit_4181)
- T = 423–523 K, P = 5000–15000 kPa, 30 points, H^E = +0.107 to +1.715 kJ/mol

---

### Chemistry Context

The ethanol–water system is a classic example of strongly non-ideal mixing. At 298 K:

- **Exothermic mixing (negative H^E)** dominates across most compositions, driven by favorable hydrogen bonding between ethanol's hydroxyl group and water molecules. The minimum H^E (most exothermic) occurs near x(ethanol) ≈ 0.1–0.3, where the water hydrogen-bond network can accommodate ethanol molecules with enhanced cross-interactions.

- The most negative value observed at 298 K is approximately **−0.77 kJ/mol** (from DOI 10.1016/j.jct.2005.06.018), consistent with the well-known exothermic mixing minimum for this system.

- At elevated temperatures (333–523 K), H^E becomes increasingly **endothermic** (positive), reflecting the thermal disruption of hydrogen bonds and the dominance of dispersive interactions.

- The dilute-region measurements from DOI 10.1016/j.fluid.2007.06.007 provide valuable data for determining partial molar excess enthalpies at infinite dilution.

**Summary:** Four data blocks totaling 58 data points provide H^E measurements for ethanol + water at 298.15 K, covering compositions from infinite dilution to x(ethanol) ≈ 0.97, with H^E values ranging from approximately −0.77 to −0.001 kJ/mol.

### Core claims

- Four ThermoML data blocks (58 data points total) report excess molar enthalpy for ethanol + water at 298.15 K, covering compositions from infinite dilution to x(ethanol) ≈ 0.97, with all H^E values being exothermic (negative), ranging from approximately −0.77 to −0.001 kJ/mol.
- The most negative H^E at 298.15 K is approximately −0.77 kJ/mol, occurring at intermediate compositions (near x(ethanol) ≈ 0.1–0.3), attributed to favorable cross hydrogen bonding between ethanol and water.
- At elevated temperatures (333–523 K), H^E shifts from exothermic to increasingly endothermic (up to +1.715 kJ/mol), reflecting thermal disruption of hydrogen bonds.
- Dilute-region measurements from one source probe both the ethanol-in-water and water-in-ethanol infinite-dilution regimes, providing data relevant to partial molar excess enthalpies at infinite dilution.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 | PROPblock_1 |  | Excess molar enthalpy of ethanol + water at 298.15 K, dilute ethanol regime (x_ethanol = 0.000102–0.001551), 15 data points, H^E = −0.001 to −0.015 kJ/mol |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 | PROPblock_2 |  | Excess molar enthalpy of ethanol + water at 298.15 K, dilute water regime (x_water = 0.001021–0.015286), 15 data points, H^E = −0.002 to −0.030 kJ/mol |
| GLOBlit_2574 | 10.1016/j.jct.2005.06.018 | PROPblock_4 |  | Excess molar enthalpy of ethanol + water at 298.15–323.15 K, full composition range (x_ethanol = 0.033–0.968), 27 data points, H^E = −0.770 to −0.018 kJ/mol |
| GLOBlit_6377 | 10.1016/j.tca.2017.05.023 | PROPblock_1 |  | Excess molar enthalpy of ethanol + water at 298.15 K, single point at x_ethanol = 0.102, H^E = −0.707 kJ/mol |
| GLOBlit_1482 | 10.1016/j.fluid.2014.05.031 | PROPblock_4 |  | Excess molar enthalpy of ethanol + water at 333–383 K (above target range), 56 data points, H^E = −0.308 to +0.579 kJ/mol |
| GLOBlit_4181 | 10.1016/j.jct.2014.05.020 | PROPblock_1 |  | Excess molar enthalpy of ethanol + water at 423–523 K (well above target range), 30 data points, H^E = +0.107 to +1.715 kJ/mol |

### Suggested follow-ups

- Query individual PROPblock datasets to retrieve full composition-dependent H^E curves at 298.15 K for model fitting or comparison
- Search for partial molar excess enthalpy at infinite dilution (GLOBprop_18 or related) for ethanol in water and water in ethanol at 298 K
- Retrieve excess Gibbs energy (GE) or activity coefficient data for ethanol + water at 298 K to complement the enthalpy data for full thermodynamic characterization
- Compare the dilute-region data from GLOBlit_528 with the full-range data from GLOBlit_2574 to assess consistency at overlapping compositions

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_17",
    "registry_id": "GLOBprop_17",
    "name": "Excess molar enthalpy (kJ/mol)"
  }
]
```

# Reference Stats — query-agent

**Run started:** 2026-08-02 20:44:54
**Wall time (at last flush):** 276.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 22,445 | 7,005 | 44,632 | 8,926 | 42.4 | claudeopus46 |
| L1-worker | 18 | 198,274 | 82,472 | 46,080 | 280,746 | 15,597 | 238.4 | claudeopus46 |
| **TOTAL** | **23** | **220,461** | **104,917** | **53,085** | **325,378** | **14,146** | **280.8** | |

**Estimated tokens:** ~81,344 input + ~13,271 output = ~94,615 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 3 | 1 | 1 | 2 | 1 | 1 | 109 |
| **TOTAL** | **5** | **2** | **1** | **2** | **1** | **1** | **109** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_63 | N,N-dimethylethanamide | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_28 |  | resolve_property_ids, search_blocks |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2871 |  | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_55 | Excess molar volume, m3/mol | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 3 |
| Unique Properties | 1 |
| Unique References | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 1 |
| Unique Constraints | 2 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 109 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 109

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2007.09.009 | 1 | 109 | ternary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2007.09.009 | PROPblock_11 | declared | 109 | ternary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 254 | KEEP | 254 | 3.9 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Resolve property ID… | 271 | KEEP | 271 | 4.3 |
| 3 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 983 | DISCARD | 925 | 10.7 |
| 4 | 6 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 832 | DISCARD | 774 | 21.7 |
| 5 | 1 | `L1_query` | context=Ethanol is also known as C2H5…, id_catalog… | 4,025 | — | — | 240.9 |
| | | **TOTAL (5 tools)** | | **6,365** | | **2,224** | **281.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 6,778 | 6,778 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 880 | 10,485 | 1,495 | 8.0 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,231 | 21,874 | 869 | 5.6 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,828 | 23,471 | 15,786 | 60.9 |
| 4 | L1-worker | claudeopus46 | 2,065 | 429 | 2,494 | 449 | 3.8 |
| 5 | L1-worker | claudeopus46 | 2,065 | 385 | 2,450 | 494 | 4.2 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,359 | 24,002 | 12,438 | 60.9 |
| 7 | L1-worker | claudeopus46 | 20,643 | 4,115 | 24,758 | 684 | 4.8 |
| 8 | L1-worker | claudeopus46 | 2,065 | 520 | 2,585 | 1,750 | 10.2 |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,275 | 25,918 | 761 | 6.4 |
| 10 | L1-worker | claudeopus46 | 20,643 | 6,611 | 27,254 | 509 | 3.7 |
| 11 | L1-worker | claudeopus46 | 2,065 | 4,042 | 6,107 | 1,268 | 10.6 |
| 12 | L1-worker | claudeopus46 | 20,610 | 8,148 | 28,758 | 628 | 4.9 |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,395 | 28,038 | 5,019 | 27.2 |
| 14 | L1-worker | claudeopus46 | 20,643 | 13,050 | 33,693 | 2,373 | 9.9 |
| 15 | L1-worker | claudeopus46 | 1,323 | 8,883 | 10,206 | 308 | 3.0 |
| 16 | L1-worker | claudeopus46 | 1,356 | 1,852 | 3,208 | 792 | 4.5 |
| 17 | L1-worker | claudeopus46 | 298 | 1,030 | 1,328 | 202 | 2.5 |
| 18 | L1-worker | claudeopus46 | 536 | 1,732 | 2,268 | 932 | 8.7 |
| 19 | L1-worker | claudeopus46 | 747 | 11,587 | 12,334 | 818 | 6.6 |
| 20 | L0-main | claudeopus46 | 9,605 | 9,703 | 19,308 | 2,358 | 14.5 |
| 21 | L0-main | claudeopus46 | 1,356 | 2,064 | 3,420 | 732 | 7.3 |
| 22 | L0-main | claudeopus46 | 1,323 | 7,914 | 9,237 | 1,216 | 7.8 |
| 23 | L0-main | claudeopus46 | 298 | 1,884 | 2,182 | 1,204 | 4.8 |


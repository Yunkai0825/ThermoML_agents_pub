# Delegated query run — result

**Question:** Find experimental data for excess molar volume (VE) of ethanol + water binary mixtures near room temperature (around 293-303 K, pressure ~101 kPa). Return DOIs, block numbers, compound names, and representative data points.

**Iterations:** 2  |  **Elapsed:** 263.6s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

**No excess molar volume (V^E) data found for the ethanol + water binary system in the ThermoML database.**

A comprehensive search was performed for the binary mixture of ethanol (C₂H₆O) and water (H₂O) looking specifically for excess molar volume (V^E) data near 293–303 K at ambient pressure. The result:

- **No pre-computed V^E values exist** for the ethanol + water binary system at any temperature in the ThermoML archive.
- The **only V^E record** involving both ethanol and water pertains to a **ternary** system (N,N-dimethylacetamide + ethanol + water) at 313.15 K — not a pure binary mixture.

---

### Related data available for ethanol + water binary mixtures

Although V^E is absent, several other thermodynamic and transport properties are available for this binary system:

| Property | No. of blocks | Temperature range |
|----------|:---:|---|
| Mass density | 5 | 278–348 K |
| Speed of sound | 3 | 278–323 K |
| Kinematic viscosity | 2 | 293–323 K |
| Relative permittivity | 1 | 288–308 K |
| Refractive index | 1 | 293–308 K |
| Surface tension | 1 | 293–308 K |
| Excess molar enthalpy (H^E) | 1 | 298.15 K |

The mass density data (covering the temperature range of interest) could, in principle, be used to **derive** V^E if combined with pure-component molar volumes, but no such derived values are stored in the database.

### Chemistry context

Ethanol + water is one of the most-studied binary systems in solution thermodynamics. V^E for this mixture is well known to be **strongly negative**, with a minimum typically near x(ethanol) ≈ 0.3–0.4 at 298 K (on the order of −1 × 10⁻⁶ m³/mol). This volume contraction arises from the restructuring of hydrogen-bond networks when ethanol molecules are incorporated into the water structure, filling interstitial spaces. However, this widely reported behavior is not represented by pre-computed entries in the ThermoML dataset queried here.

### Core claims

- No pre-computed excess molar volume (V^E) data exist for the ethanol + water binary system in the ThermoML archive at any temperature.
- The only V^E record involving both ethanol and water in the archive pertains to a ternary system (N,N-dimethylacetamide + ethanol + water) at 313.15 K, not a binary mixture.
- Mass density data for the ethanol + water binary system are available in the archive (covering 278–348 K) and could in principle be used to derive V^E, but no such derived values are stored.
- The well-known strongly negative V^E behavior of ethanol + water (minimum near x(ethanol) ≈ 0.3–0.4, on the order of −1 × 10⁻⁶ m³/mol at 298 K) is not represented by entries in the queried ThermoML dataset.

**Confidence:** high

### Suggested follow-ups

- Retrieve mass density data for the ethanol + water binary system (available in 5 blocks, 278–348 K) and combine with pure-component molar volumes to derive excess molar volume (VE) values.
- Retrieve excess molar enthalpy (HE) data for ethanol + water at 298.15 K (DOI: 10.1016/j.jct.2014.07.022) as a complementary excess property.
- Search for excess molar volume data for ethanol + water in external literature databases (e.g., NIST TDE, Dortmund Data Bank) where this well-studied system is extensively documented.
- Investigate the ternary system (N,N-dimethylacetamide + ethanol + water) VE data at 313.15 K if ternary excess volume information is of interest.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_28",
    "registry_id": "excess_molar_volume_m3_mol",
    "name": "Excess molar volume, m3/mol"
  }
]
```

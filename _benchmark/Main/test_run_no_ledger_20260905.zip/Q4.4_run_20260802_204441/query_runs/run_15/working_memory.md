# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_2 | ethanol | ethanol |
| comp | GLOBcomp_1 | water | water |
| prop | GLOBprop_28 | excess_molar_volume_m3_mol | Excess molar volume, m3/mol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find excess molar volume (VE) data for ethanol + water binary mixtures near 298 K → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "**Excess molar volume (VE) data for ethanol + water binary mixtures near 298 K is not available in the ThermoML database.**\n\nA thorough search was conducted using:\n- **Compounds:** ethanol (GLOBcomp_2, C₂H₆O) and water (GLOBcomp_1, H₂O)\n- **Property:** Excess molar volume (GLOBprop_28, m³/mol)\n- **System type:** binary, with both declared and subsystem scopes checked\n- **Temperature range:** 293–303 K (and broadened to all temperatures)\n\n**What was found instead:**\nThe only excess molar volume entry involving ethanol and water is for a **ternary** system (N,N-dimethylacetamide + ethanol + water) at 313.15 K — not a pure binary ethanol + water mixture.\n\n**Available properties for the ethanol + water binary system** in the database include:\n- **Mass density** (5 blocks, 278–348 K) — e.g., DOI: 10.1016/j.jct.2006.02.009, DOI: 10.1016/j.fluid.2007.06.004\n- **Speed of sound** (3 blocks, 278–323 K)\n- **Kinematic viscosity** (2 blocks, 293–323 K)\n- **Relative permittivity** (1 block, 288–308 K)\n- **Refractive index** (1 block, 293–308 K)\n- **Surface tension** (1 block, 293–308 K)\n- **Excess molar enthalpy (HE)** (1 block, 298.15 K) — DOI: 10.1016/j.jct.2014.07.022\n\n**Chemistry note:** While VE data for ethanol + water is widely reported in the broader literature (typically showing negative excess volumes with a minimum around x_ethanol ≈ 0.3–0.4 at 298 K, indicating volume contraction due to hydrogen bonding restructuring), this specific dataset is not present in the ThermoML archive queried here. The available density data could in principle be used to calculate VE if pure-component densities are also available, but no pre-computed VE values exist for this binary in the database.",
  "core_claims": [
    "Excess molar volume (VE) data for the binary ethanol + water system near 298 K is not available in the queried ThermoML database; the only excess molar volume entry involving ethanol and water pertains to a ternary system (N,N-dimethylacetamide + ethanol + water) at 313.15 K.",
    "The ThermoML database does contain other properties for the ethanol + water binary system, including mass density, speed of sound, kinematic viscosity, relative permittivity, refractive index, surface tension, and excess molar enthalpy, but no pre-computed binary VE values.",
    "Although VE for ethanol + water is widely reported in the broader literature (typically negative, with a minimum near x_ethanol ≈ 0.3–0.4 at 298 K), this specific property is absent from the ThermoML archive queried."
  ],
  "status": "no_results",
  "summary": "A search of the ThermoML database for excess molar volume (VE) data of the ethanol + water binary mixture near 298 K found no matching entries. The only VE record involving ethanol and water pertains to a ternary system (N,N-dimethylacetamide + ethanol + water) at 313.15 K. For the ethanol + water binary, the database contains other properties—mass density (278–348 K), speed of sound, kinematic viscosity, relative permittivity, refractive index, surface tension, and excess molar enthalpy at 298.15 K—but no pre-computed VE values. The available density data could in principle be used to derive VE, though this has not been done within the archive. In the broader literature, ethanol + water VE is well known to be negative with a minimum near x_ethanol ≈ 0.3–0.4 at 298 K, reflecting volume contraction from hydrogen-bonding restructuring, but this information is not represented in the queried ThermoML dataset.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_28",
      "registry_id": "excess_molar_volume_m3_mol",
      "name": "Excess molar volume, m3/mol"
    }
  ],
  "core_blocks_found": []
}


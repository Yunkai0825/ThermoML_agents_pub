# Reference Stats — main-agent

**Run started:** 2026-08-02 20:44:41
**Wall time (at last flush):** 1,665.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 24,654 | 88,627 | 17,811 | 113,281 | 16,183 | 103.7 | claudeopus46 |
| **TOTAL** | **7** | **24,654** | **88,627** | **17,811** | **113,281** | **16,183** | **103.7** | |

**Estimated tokens:** ~28,320 input + ~4,452 output = ~32,772 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_parallel_subagents` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_parallel_subagents` | tasks=[{'agent': 'query', 'label': … | 21,377 | — | — | 1574.4 |
| | | **TOTAL (1 tools)** | | **21,377** | | **0** | **1574.4** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 253 | 10,468 | 2,516 | 12.4 |
| 2 | L0-main | claudeopus46 | 10,215 | 40,919 | 51,134 | 6,454 | 41.8 |
| 3 | L0-main | claudeopus46 | 1,356 | 5,626 | 6,982 | 1,130 | 8.2 |
| 4 | L0-main | claudeopus46 | 298 | 1,512 | 1,810 | 1,118 | 4.6 |
| 5 | L0-main | claudeopus46 | 1,323 | 30,766 | 32,089 | 2,800 | 15.6 |
| 6 | L0-main | claudeopus46 | 298 | 3,323 | 3,621 | 2,376 | 9.7 |
| 7 | L0-main | claudeopus46 | 949 | 6,228 | 7,177 | 1,417 | 11.4 |


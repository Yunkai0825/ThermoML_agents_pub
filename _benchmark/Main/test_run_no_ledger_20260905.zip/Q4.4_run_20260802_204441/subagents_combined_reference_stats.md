# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 6 | 22,485 | 58,468 | 13,639 | 80,953 | 13,492 | 78.5 | claudeopus46 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| L1-worker | 12 | 111,572 | 82,172 | 16,197 | 193,744 | 16,145 | 95.8 | claudeopus46 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| L0-main | 5 | 22,187 | 22,445 | 7,005 | 44,632 | 8,926 | 42.4 | claudeopus46 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| L1-worker | 18 | 198,274 | 82,472 | 46,080 | 280,746 | 15,597 | 238.4 | claudeopus46 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| L0-main | 8 | 50,969 | 58,123 | 16,372 | 109,092 | 13,636 | 89.3 | claudeopus46 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| L1-worker | 100 | 1,013,052 | 627,647 | 283,291 | 1,640,699 | 16,406 | 1516.9 | claudeopus46 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| **TOTAL** | **149** | **1,418,539** | **931,327** | **382,584** | **2,349,866** | **84,202** | **2,061.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 5 | 0 | 0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| `search_blocks` | 3 | 1 | 1 | 2 | 1 | 1 | 109 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 2 | 1 | 5 | 3 | 10 | 10 | 1,929 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `resolve_compound_ids` | 7 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 2 | 1 | 5 | 3 | 15 | 15 | 2,144 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 2 | 1 | 5 | 3 | 15 | 15 | 2,144 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 2 | 1 | 5 | 3 | 10 | 10 | 1,929 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 2 | 1 | 3 | 4 | 4 | 4 | 212 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `search_blocks` | 2 | 1 | 4 | 3 | 10 | 10 | 334 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| **TOTAL** | **35** | **8** | **30** | **21** | **71** | **65** | **8,801** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | --- | --- |
| Unique Compounds | 2 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| Unique References | 5 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| Unique Block_Types | 1 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| Unique Phases | 1 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| Unique parent blocks | 0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| Explicit block/subsystem targets | 0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| Subsystem targets | 0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| Target-matched data points | 0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_63 | N,N-dimethylethanamide | search_blocks |
| GLOBprop_28 |  | resolve_property_ids, search_blocks |
| GLOBlit_2871 |  | search_blocks |
| GLOBmeas_55 | Excess molar volume, m3/mol | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique Compounds | 3 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Unique Properties | 1 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Unique References | 1 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Unique Measurements | 1 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Unique Phases | 1 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Unique Variables | 1 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Unique Constraints | 2 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Unique parent blocks | 1 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Explicit block/subsystem targets | 1 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Subsystem targets | 0 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| Target-matched data points | 109 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_151 |  | resolve_compound_ids |
| GLOBcomp_177 |  | resolve_compound_ids |
| GLOBcomp_496 |  | resolve_compound_ids |
| GLOBcomp_3276 |  | resolve_compound_ids |
| GLOBcomp_4401 |  | resolve_compound_ids |
| GLOBcomp_143 |  | resolve_compound_ids |
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBlit_220 |  | search_blocks |
| GLOBlit_1483 |  | search_blocks |
| GLOBlit_2432 |  | search_blocks |
| GLOBlit_2825 |  | search_blocks |
| GLOBlit_3475 |  | search_blocks |
| GLOBlit_4415 |  | search_blocks |
| GLOBlit_5201 |  | block_search_adv, search_blocks |
| GLOBlit_5473 |  | search_blocks |
| GLOBlit_7085 |  | search_blocks |
| GLOBlit_7178 |  | search_blocks |
| GLOBlit_7448 |  | search_blocks |
| GLOBlit_7676 |  | search_blocks |
| GLOBlit_8050 |  | search_blocks |
| GLOBlit_8888 |  | search_blocks |
| GLOBlit_9006 |  | search_blocks |
| GLOBlit_11504 |  | search_blocks |
| GLOBlit_10159 |  | search_blocks |
| GLOBlit_10699 |  | search_blocks |
| GLOBlit_11005 |  | search_blocks |
| GLOBlit_11136 |  | search_blocks |
| GLOBlit_11792 |  | search_blocks |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |
| GLOBprop_8 | Speed of sound, m/s | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_66 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_236 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks |
| GLOBmeas_206 | Speed of sound, m/s | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_988 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | block_search_adv, search_blocks |
| GLOBsolvent_1 |  | search_blocks |
| GLOBsolvent_2 |  | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_8 | Molality, mol/kg | search_blocks |
| GLOBconstr_4 | Frequency, MHz | search_blocks |
| GLOBconstr_22 | Volume fraction | search_blocks |
| GLOBblocktype_1 |  | block_search_adv |
| Unique Compounds | 8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique Variables | 5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique References | 21 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique Properties | 3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique Measurements | 15 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique Phases | 1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique Solvents | 2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique Constraints | 5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique Block_Types | 1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Unique parent blocks | 29 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Explicit block/subsystem targets | 29 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Subsystem targets | 0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| Target-matched data points | 8,692 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| **TOTAL** | **8,941** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve ethanol and… | 380 | KEEP | 380 | 4.1 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 2 | 3 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 1,145 | KEEP | 1145 | 13.2 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 3 | 1 | `L1_query` | context=Property ID for excess molar …, id_catalog… | 270 | — | — | 90.0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 254 | KEEP | 254 | 3.9 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Resolve property ID… | 271 | KEEP | 271 | 4.3 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 3 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 983 | DISCARD | 925 | 10.7 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 4 | 6 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 832 | DISCARD | 774 | 21.7 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 5 | 1 | `L1_query` | context=Ethanol is also known as C2H5…, id_catalog… | 4,025 | — | — | 240.9 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 241 | KEEP | 241 | 5.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 2 | 6 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 325 | KEEP | 325 | 4.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 3 | 1 | `L1_query` | context=Ethanol is also known as C2H5…, id_catalog… | 416 | — | — | 386.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 251 | KEEP | 251 | 3.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 5 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 134 | KEEP | 134 | 21.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 6 | 2 | `L1_query` | context=Looking for mixture density d…, id_catalog… | 420 | — | — | 241.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 7 | 1 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve ethanol co… | 251 | KEEP | 251 | 5.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 8 | 3 | `L1_query` | context=Need to resolve ethanol's com…, id_catalog… | 1,023 | — | — | 28.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 9 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve the global … | 254 | KEEP | 254 | 4.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10 | 3 | `L1_query` | context=Need to resolve water's compo…, id_catalog… | 1,002 | — | — | 24.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 11 | 2 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=15, p… | 144 | — | — | 38.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 12 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=15, p… | 144 | KEEP | 217 | 38.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 13 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 217 | KEEP | 809 | 20.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 14 | 4 | `L1_query` | context=Ethanol (GLOBcomp_2, C2H6O, C…, id_catalog… | 447 | — | — | 342.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 15 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 839 | KEEP | 769 | 14.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 16 | 4 | `L1_query` | context=Ethanol (GLOBcomp_2, C2H6O, C…, id_catalog… | 383 | — | — | 179.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 17 | 2 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, p… | 799 | — | — | 21.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 18 | 6 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 848 | DISCARD | 787 | 18.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 19 | 9 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 1,141 | KEEP | 1096 | 21.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 20 | 4 | `L1_query` | context=Ethanol (GLOBcomp_2, C2H6O, C…, id_catalog… | 15,984 | — | — | 285.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| **TOTAL** | **87** |  |  | **33,423** |  | **8,883** | **2,095.0** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,639 | 3,639 | 0 | 0.0% | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 1 | interval=3 | skipped_by_agent | 6,778 | 6,778 | 0 | 0.0% | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 1 | interval=3 | skipped_by_agent | 18,992 | 18,992 | 0 | 0.0% | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 2 | interval=3 | skipped_by_agent | 3,312 | 3,312 | 0 | 0.0% | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 3 | interval=3 | skipped_by_agent | 3,401 | 3,401 | 0 | 0.0% | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 4 | interval=3 | skipped_by_agent | 4,934 | 4,934 | 0 | 0.0% | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 5 | interval=3 | skipped_by_agent | 7,421 | 7,421 | 0 | 0.0% | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| **TOTAL** |  |  | **48,477** | **48,477** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 901 | 10,506 | 1,368 | 8.3 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,187 | 21,830 | 675 | 5.0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 3 | L1-worker | claudeopus46 | 2,065 | 461 | 2,526 | 568 | 4.0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,045 | 22,688 | 1,360 | 9.5 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,940 | 23,583 | 1,246 | 8.9 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 6 | L1-worker | claudeopus46 | 2,065 | 4,308 | 6,373 | 1,513 | 11.0 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,934 | 25,544 | 456 | 3.9 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,181 | 24,824 | 2,404 | 14.2 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 9 | L1-worker | claudeopus46 | 1,356 | 2,087 | 3,443 | 776 | 4.9 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 10 | L1-worker | claudeopus46 | 536 | 1,967 | 2,503 | 956 | 5.9 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 11 | L1-worker | claudeopus46 | 1,323 | 7,247 | 8,570 | 3,254 | 12.5 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 12 | L1-worker | claudeopus46 | 298 | 3,976 | 4,274 | 2,395 | 9.5 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 13 | L1-worker | claudeopus46 | 747 | 46,839 | 47,586 | 594 | 6.5 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 14 | L0-main | claudeopus46 | 9,605 | 43,253 | 52,858 | 5,603 | 35.5 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 15 | L0-main | claudeopus46 | 1,356 | 3,922 | 5,278 | 891 | 5.4 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 16 | L0-main | claudeopus46 | 298 | 1,273 | 1,571 | 879 | 3.7 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 17 | L0-main | claudeopus46 | 1,323 | 5,886 | 7,209 | 2,565 | 16.7 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 18 | L0-main | claudeopus46 | 298 | 3,233 | 3,531 | 2,333 | 8.9 | Find experimental data for excess molar enthalpy (HE) or ent (query_runs/run_16) |
| 1 | L0-main | claudeopus46 | 9,605 | 880 | 10,485 | 1,495 | 8.0 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,231 | 21,874 | 869 | 5.6 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,828 | 23,471 | 15,786 | 60.9 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 4 | L1-worker | claudeopus46 | 2,065 | 429 | 2,494 | 449 | 3.8 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 5 | L1-worker | claudeopus46 | 2,065 | 385 | 2,450 | 494 | 4.2 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,359 | 24,002 | 12,438 | 60.9 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 7 | L1-worker | claudeopus46 | 20,643 | 4,115 | 24,758 | 684 | 4.8 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 8 | L1-worker | claudeopus46 | 2,065 | 520 | 2,585 | 1,750 | 10.2 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,275 | 25,918 | 761 | 6.4 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 10 | L1-worker | claudeopus46 | 20,643 | 6,611 | 27,254 | 509 | 3.7 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 11 | L1-worker | claudeopus46 | 2,065 | 4,042 | 6,107 | 1,268 | 10.6 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 12 | L1-worker | claudeopus46 | 20,610 | 8,148 | 28,758 | 628 | 4.9 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,395 | 28,038 | 5,019 | 27.2 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 14 | L1-worker | claudeopus46 | 20,643 | 13,050 | 33,693 | 2,373 | 9.9 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 15 | L1-worker | claudeopus46 | 1,323 | 8,883 | 10,206 | 308 | 3.0 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 16 | L1-worker | claudeopus46 | 1,356 | 1,852 | 3,208 | 792 | 4.5 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 17 | L1-worker | claudeopus46 | 298 | 1,030 | 1,328 | 202 | 2.5 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 18 | L1-worker | claudeopus46 | 536 | 1,732 | 2,268 | 932 | 8.7 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 19 | L1-worker | claudeopus46 | 747 | 11,587 | 12,334 | 818 | 6.6 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 20 | L0-main | claudeopus46 | 9,605 | 9,703 | 19,308 | 2,358 | 14.5 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 21 | L0-main | claudeopus46 | 1,356 | 2,064 | 3,420 | 732 | 7.3 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 22 | L0-main | claudeopus46 | 1,323 | 7,914 | 9,237 | 1,216 | 7.8 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 23 | L0-main | claudeopus46 | 298 | 1,884 | 2,182 | 1,204 | 4.8 | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 1 | L0-main | claudeopus46 | 9,605 | 894 | 10,499 | 1,519 | 7.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,306 | 21,949 | 849 | 8.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,776 | 23,419 | 819 | 4.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 4 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 419 | 4.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,909 | 23,552 | 14,867 | 51.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 6 | L1-worker | claudeopus46 | 20,643 | 18,611 | 39,254 | 11,851 | 63.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 7 | L1-worker | claudeopus46 | 20,643 | 19,685 | 40,328 | 14,539 | 68.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 8 | L1-worker | claudeopus46 | 20,643 | 20,362 | 41,005 | 11,632 | 59.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 9 | L1-worker | claudeopus46 | 2,065 | 484 | 2,549 | 518 | 3.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10 | L1-worker | claudeopus46 | 20,610 | 20,364 | 40,974 | 374 | 3.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 11 | L1-worker | claudeopus46 | 20,643 | 19,737 | 40,380 | 3,791 | 22.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 12 | L1-worker | claudeopus46 | 1,356 | 3,188 | 4,544 | 1,085 | 6.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 13 | L1-worker | claudeopus46 | 536 | 3,068 | 3,604 | 1,197 | 7.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 14 | L1-worker | claudeopus46 | 298 | 1,467 | 1,765 | 1,073 | 3.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 15 | L1-worker | claudeopus46 | 1,323 | 8,755 | 10,078 | 10,273 | 35.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 16 | L1-worker | claudeopus46 | 298 | 10,995 | 11,293 | 8,290 | 28.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 17 | L1-worker | claudeopus46 | 1,160 | 21,465 | 22,625 | 8,227 | 29.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 18 | L0-main | claudeopus46 | 9,605 | 1,844 | 11,449 | 1,113 | 7.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 19 | L1-worker | claudeopus46 | 20,643 | 1,056 | 21,699 | 743 | 5.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,420 | 23,063 | 12,430 | 66.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 21 | L1-worker | claudeopus46 | 2,065 | 460 | 2,525 | 435 | 3.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 22 | L1-worker | claudeopus46 | 20,643 | 2,609 | 23,252 | 10,550 | 54.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 23 | L1-worker | claudeopus46 | 20,643 | 3,342 | 23,985 | 650 | 4.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 24 | L1-worker | claudeopus46 | 2,065 | 7,114 | 9,179 | 1,627 | 13.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 25 | L1-worker | claudeopus46 | 20,643 | 3,617 | 24,260 | 8,107 | 46.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 26 | L1-worker | claudeopus46 | 20,643 | 12,299 | 32,942 | 2,427 | 9.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 27 | L1-worker | claudeopus46 | 536 | 2,436 | 2,972 | 820 | 5.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 28 | L1-worker | claudeopus46 | 1,356 | 2,556 | 3,912 | 1,092 | 7.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 29 | L1-worker | claudeopus46 | 1,323 | 6,106 | 7,429 | 2,463 | 11.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 30 | L1-worker | claudeopus46 | 298 | 3,185 | 3,483 | 1,885 | 7.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 31 | L1-worker | claudeopus46 | 1,160 | 9,072 | 10,232 | 1,905 | 9.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 32 | L0-main | claudeopus46 | 9,605 | 2,771 | 12,376 | 1,644 | 8.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 33 | L1-worker | claudeopus46 | 20,643 | 917 | 21,560 | 462 | 4.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 34 | L1-worker | claudeopus46 | 2,065 | 816 | 2,881 | 452 | 4.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 35 | L1-worker | claudeopus46 | 20,643 | 1,584 | 22,227 | 317 | 5.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 36 | L1-worker | claudeopus46 | 1,323 | 1,917 | 3,240 | 162 | 2.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 37 | L1-worker | claudeopus46 | 1,356 | 446 | 1,802 | 163 | 2.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 38 | L1-worker | claudeopus46 | 536 | 326 | 862 | 282 | 4.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 39 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 3.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 40 | L1-worker | claudeopus46 | 747 | 1,933 | 2,680 | 385 | 6.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 41 | L1-worker | claudeopus46 | 20,643 | 2,046 | 22,689 | 467 | 3.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 42 | L1-worker | claudeopus46 | 20,643 | 3,134 | 23,777 | 757 | 4.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 43 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 477 | 4.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 44 | L1-worker | claudeopus46 | 20,643 | 3,265 | 23,908 | 307 | 2.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 45 | L1-worker | claudeopus46 | 1,356 | 436 | 1,792 | 171 | 2.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 46 | L1-worker | claudeopus46 | 1,323 | 2,091 | 3,414 | 162 | 2.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 47 | L1-worker | claudeopus46 | 536 | 316 | 852 | 267 | 2.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 48 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 49 | L1-worker | claudeopus46 | 747 | 2,116 | 2,863 | 393 | 3.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 50 | L0-main | claudeopus46 | 9,605 | 7,879 | 17,484 | 2,868 | 14.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 51 | L1-worker | claudeopus46 | 20,643 | 3,476 | 24,119 | 1,245 | 8.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 52 | L1-worker | claudeopus46 | 20,643 | 5,342 | 25,985 | 14,277 | 56.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 53 | L1-worker | claudeopus46 | 2,065 | 10,272 | 12,337 | 1,560 | 15.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 54 | L1-worker | claudeopus46 | 2,065 | 10,482 | 12,547 | 1,540 | 15.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 55 | L1-worker | claudeopus46 | 20,643 | 5,478 | 26,121 | 12,617 | 58.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 56 | L1-worker | claudeopus46 | 2,065 | 10,272 | 12,337 | 1,598 | 16.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 57 | L1-worker | claudeopus46 | 2,065 | 10,482 | 12,547 | 1,512 | 14.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 58 | L1-worker | claudeopus46 | 20,610 | 6,887 | 27,497 | 577 | 4.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 59 | L1-worker | claudeopus46 | 20,643 | 6,134 | 26,777 | 795 | 8.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 60 | L1-worker | claudeopus46 | 2,065 | 7,176 | 9,241 | 1,675 | 13.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 61 | L1-worker | claudeopus46 | 20,643 | 6,974 | 27,617 | 11,189 | 60.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 62 | L1-worker | claudeopus46 | 20,643 | 18,784 | 39,427 | 2,783 | 12.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 63 | L1-worker | claudeopus46 | 1,356 | 2,914 | 4,270 | 829 | 5.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 64 | L1-worker | claudeopus46 | 536 | 2,794 | 3,330 | 1,049 | 6.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 65 | L1-worker | claudeopus46 | 298 | 1,211 | 1,509 | 817 | 3.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 66 | L1-worker | claudeopus46 | 298 | 1,405 | 1,703 | 1,036 | 4.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 67 | L1-worker | claudeopus46 | 1,323 | 6,711 | 8,034 | 3,912 | 14.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 68 | L1-worker | claudeopus46 | 298 | 4,634 | 4,932 | 2,894 | 10.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 69 | L1-worker | claudeopus46 | 1,160 | 11,330 | 12,490 | 1,985 | 9.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 70 | L1-worker | claudeopus46 | 20,643 | 3,453 | 24,096 | 924 | 6.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 71 | L1-worker | claudeopus46 | 20,643 | 4,998 | 25,641 | 13,624 | 57.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 72 | L1-worker | claudeopus46 | 20,643 | 5,761 | 26,404 | 703 | 7.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 73 | L1-worker | claudeopus46 | 2,065 | 8,182 | 10,247 | 1,710 | 14.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 74 | L1-worker | claudeopus46 | 20,610 | 6,976 | 27,586 | 633 | 5.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 75 | L1-worker | claudeopus46 | 20,643 | 6,223 | 26,866 | 8,115 | 49.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 76 | L1-worker | claudeopus46 | 20,643 | 14,959 | 35,602 | 3,267 | 16.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 77 | L1-worker | claudeopus46 | 1,356 | 3,016 | 4,372 | 1,000 | 6.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 78 | L1-worker | claudeopus46 | 536 | 2,896 | 3,432 | 1,104 | 7.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 79 | L1-worker | claudeopus46 | 1,323 | 6,880 | 8,203 | 1,905 | 9.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 80 | L1-worker | claudeopus46 | 298 | 1,382 | 1,680 | 988 | 6.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 81 | L1-worker | claudeopus46 | 298 | 2,627 | 2,925 | 1,481 | 6.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 82 | L1-worker | claudeopus46 | 1,160 | 9,167 | 10,327 | 1,481 | 6.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 83 | L1-worker | claudeopus46 | 20,643 | 3,485 | 24,128 | 1,072 | 9.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 84 | L1-worker | claudeopus46 | 20,643 | 4,250 | 24,893 | 13,180 | 68.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 85 | L1-worker | claudeopus46 | 2,065 | 6,834 | 8,899 | 1,835 | 13.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 86 | L1-worker | claudeopus46 | 20,643 | 5,221 | 25,864 | 1,742 | 11.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 87 | L1-worker | claudeopus46 | 20,643 | 6,104 | 26,747 | 1,239 | 8.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 88 | L1-worker | claudeopus46 | 20,643 | 6,931 | 27,574 | 1,746 | 11.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 89 | L1-worker | claudeopus46 | 20,643 | 7,866 | 28,509 | 988 | 6.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 90 | L1-worker | claudeopus46 | 2,065 | 1,037 | 3,102 | 1,394 | 9.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 91 | L1-worker | claudeopus46 | 20,610 | 8,584 | 29,194 | 633 | 5.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 92 | L1-worker | claudeopus46 | 20,643 | 7,831 | 28,474 | 2,247 | 14.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 93 | L1-worker | claudeopus46 | 20,643 | 8,747 | 29,390 | 1,122 | 8.7 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 94 | L1-worker | claudeopus46 | 20,643 | 9,615 | 30,258 | 1,176 | 7.9 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 95 | L1-worker | claudeopus46 | 2,065 | 1,879 | 3,944 | 1,752 | 11.4 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 96 | L1-worker | claudeopus46 | 20,610 | 11,146 | 31,756 | 444 | 4.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 97 | L1-worker | claudeopus46 | 20,643 | 10,393 | 31,036 | 1,955 | 12.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 98 | L1-worker | claudeopus46 | 20,643 | 11,293 | 31,936 | 1,948 | 13.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 99 | L1-worker | claudeopus46 | 20,643 | 12,280 | 32,923 | 2,646 | 17.6 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 100 | L1-worker | claudeopus46 | 536 | 2,104 | 2,640 | 877 | 5.3 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 101 | L1-worker | claudeopus46 | 1,356 | 2,224 | 3,580 | 1,052 | 6.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 102 | L1-worker | claudeopus46 | 1,323 | 19,313 | 20,636 | 1,157 | 7.8 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 103 | L1-worker | claudeopus46 | 298 | 1,879 | 2,177 | 931 | 4.5 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 104 | L1-worker | claudeopus46 | 747 | 34,002 | 34,749 | 952 | 9.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 105 | L0-main | claudeopus46 | 9,572 | 7,458 | 17,030 | 2,875 | 17.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 106 | L0-main | claudeopus46 | 1,356 | 3,006 | 4,362 | 625 | 5.2 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 107 | L0-main | claudeopus46 | 1,323 | 30,471 | 31,794 | 3,132 | 18.1 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 108 | L0-main | claudeopus46 | 298 | 3,800 | 4,098 | 2,596 | 11.0 | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| **TOTAL** |  |  | **1,418,539** | **931,327** | **2,349,866** | **382,584** | **2,061.3** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | ---: | --- | --- |
| 10.1016/j.jct.2007.09.009 | 1 | 109 | ternary | search_blocks | Find experimental data for excess molar volume (VE) of ethan (query_runs/run_15) |
| 10.1016/j.jct.2007.09.009 | PROPblock_11 | declared | 109 | ternary | — |
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.fluid.2014.05.032 | 1 | 140 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.jct.2004.07.019 | 1 | 565 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.jct.2007.05.004 | 2 | 74 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.jct.2011.10.009 | 1 | 70 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.jct.2015.06.024 | 2 | 80 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.jct.2018.02.022 | 3 | 496 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.jct.2019.02.027 | 1 | 9 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/acs.jced.6b01058 | 1 | 12 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/acs.jced.7b00299 | 2 | 4 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/acs.jced.8b00086 | 2 | 12 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/acs.jced.8b00939 | 2 | 18 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je020173z | 1 | 24 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je0601098 | 2 | 24 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je060335h | 1 | 164 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je4003515 | 1 | 25 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je600565m | 1 | 17 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je700618y | 1 | 15 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je800150h | 1 | 108 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je900064e | 1 | 8 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1021/je900743e | 1 | 15 | binary | search_blocks | Find experimental data for speed of sound, density, or visco (query_runs/run_17) |
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | — |
| 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | — |
| 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | — |
| 10.1016/j.jct.2007.05.004 | PROPblock_11 | declared | 37 | binary | — |
| 10.1016/j.jct.2007.05.004 | PROPblock_12 | declared | 37 | binary | — |
| 10.1016/j.jct.2011.10.009 | PROPblock_3 | declared | 70 | binary | — |
| 10.1016/j.jct.2015.06.024 | PROPblock_7 | declared | 40 | binary | — |
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | — |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | — |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | — |
| 10.1016/j.jct.2018.02.022 | PROPblock_21 | declared | 100 | binary | — |
| 10.1016/j.jct.2019.02.027 | PROPblock_21 | declared | 9 | binary | — |
| 10.1021/acs.jced.6b01058 | PROPblock_7 | declared | 12 | binary | — |
| 10.1021/acs.jced.7b00299 | PROPblock_10 | declared | 2 | binary | — |
| 10.1021/acs.jced.7b00299 | PROPblock_11 | declared | 2 | binary | — |
| 10.1021/acs.jced.8b00086 | PROPblock_46 | declared | 6 | binary | — |
| 10.1021/acs.jced.8b00086 | PROPblock_47 | declared | 6 | binary | — |
| 10.1021/acs.jced.8b00939 | PROPblock_17 | declared | 9 | binary | — |
| 10.1021/acs.jced.8b00939 | PROPblock_18 | declared | 9 | binary | — |
| 10.1021/je020173z | PROPblock_5 | declared | 24 | binary | — |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | — |
| 10.1021/je0601098 | PROPblock_20 | declared | 12 | binary | — |
| 10.1021/je060335h | PROPblock_1 | declared | 164 | binary | — |
| 10.1021/je4003515 | PROPblock_8 | declared | 25 | binary | — |
| 10.1021/je600565m | PROPblock_5 | declared | 17 | binary | — |
| 10.1021/je700618y | PROPblock_7 | declared | 15 | binary | — |
| 10.1021/je800150h | PROPblock_8 | declared | 108 | binary | — |
| 10.1021/je900064e | PROPblock_5 | declared | 8 | binary | — |
| 10.1021/je900743e | PROPblock_2 | declared | 15 | binary | — |
| **TOTAL** | **30** | **2,799** | **2,799** |  |  |

# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q3.2_run_20260802_211227`

### History
- [parallel:2 tasks]
-   [query:mixture_density] "Find mixture density measurements for the binary system water + 1-propanol near " (523s, 3 iters)
-   [query:pure_water_density] "Find the experimental density of pure water at 298.15 K. Report the value, units" (339s, 3 iters)

### Query Agent Results

#### mixture_density
{
  "answer": "## Mixture Density Data for Binary Water + 1-Propanol near 298.15 K in ThermoML\n\nThe ThermoML database contains approximately **20 data blocks across 18 DOIs** for mass density of the binary water (GLOBcomp_1) + 1-propanol (GLOBcomp_5) system. Of these, **at least 12 blocks from 11 literature sources** include data at or near 298.15 K at ambient pressure, plus additional blocks at elevated pressures. Below is a comprehensive listing.\n\n---\n\n### Ambient-Pressure Blocks Covering ~298.15 K\n\n| # | Literature ID | DOI | Block | Points | T range (K) | Composition variable & range | ρ range (kg/m³) | Method |\n|---|---------------|-----|-------|--------|-------------|------------------------------|-----------------|--------|\n| 1 | GLOBlit_555 | 10.1016/j.fluid.2007.07.066 | PROPblock_8 | 15 | 283.15–303.15 | w(propan-1-ol) = 0.05–0.15 | 976.0–992.4 | Vibrating tube |\n| 2 | GLOBlit_590 | 10.1016/j.fluid.2008.01.004 | PROPblock_5 | 15 | 283.15–303.15 | w(propan-1-ol) = 0.05–0.15 | 975.8–992.4 | Vibrating tube |\n| 3 | GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_3 | 456 | 298.15–573.15 | b(propan-1-ol) = 0.094–0.847 mol/kg | Δρ = −20.2 to −1.0 (density differences) | Vibrating tube |\n| 4 | GLOBlit_2979 | 10.1016/j.jct.2008.07.005 | PROPblock_9 | 96 | 283.15–308.15 | x(propan-1-ol) = 0–0.2 | 911.8–999.7 | Pycnometric |\n| 5 | GLOBlit_4068 | 10.1016/j.jct.2013.11.036 | PROPblock_2 | 29 | 292.05–352.05 | b(propan-1-ol) = 0.869–56.348 mol/kg | 801.0–991.4 | Pycnometric (P = 101 kPa) |\n| 6 | GLOBlit_4415 | 10.1016/j.jct.2015.06.024 | PROPblock_5 | 40 | 288.15–308.15 | b(propan-1-ol) = 0.017–0.166 mol/kg | 992.3–998.9 | Vibrating tube (P = 84.5 kPa) |\n| 7 | GLOBlit_5585 | 10.1016/j.jct.2019.105880 | PROPblock_7 | 16 | 288.15–303.15 | w(propan-1-ol) = 0.1–0.4 | 924.4–985.2 | Vibrating tube (P = 100 kPa) |\n| 8 | GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_8 | 12 | 298.15–313.15 | w(propan-1-ol) = 0.04–0.16 | 966.8–990.6 | Vibrating tube (P = 85 kPa) |\n| 9 | GLOBlit_7178 | 10.1021/acs.jced.7b00299 | PROPblock_13 | 2 | 298.15–313.15 | b(propan-1-ol) = 14.0 mol/kg (fixed) | 903.2–914.4 | Vibrating tube (P = 100 kPa) |\n| 10 | GLOBlit_8447 | 10.1021/je049738c | PROPblock_26 | 8 | 298.15 (fixed) | x(propan-1-ol) = 0.0008–0.021 | 986.7–996.6 | Vibrating tube (P = 101.3 kPa) |\n| 11 | GLOBlit_8888 | 10.1021/je0601098 | PROPblock_22 | 12 | 298.15 (fixed) | b(water) = 0–1.005 mol/kg in propan-1-ol solvent | 799.7–804.3 | Vibrating tube (P = 101 kPa) |\n\n---\n\n### High-Pressure Blocks Also Covering ~298.15 K\n\n| # | Literature ID | DOI | Block | Points | T range (K) | Composition & Pressure | ρ range (kg/m³) | Method |\n|---|---------------|-----|-------|--------|-------------|------------------------|-----------------|--------|\n| 12 | GLOBlit_4068 | 10.1016/j.jct.2013.11.036 | PROPblock_1 | 174 | 298.15–582.08 | b = 0.869–56.348 mol/kg; P = 2353–40000 kPa | 322.1–1004.4 | Constant-volume piezometry |\n| 13 | GLOBlit_8254 | 10.1021/je034101z | PROPblock_6 | 380 | 282.15–425.15 | x = 0.255–0.738; P = 5753–29883 kPa | 731.4–896.2 | Isochoric |\n\n---\n\n### Blocks NOT Near 298.15 K (High-Temperature Only)\n\n| # | Literature ID | DOI | Block | Points | T range (K) | Notes |\n|---|---------------|-----|-------|--------|-------------|-------|\n| 14 | GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_5 | 84 | 350.7–476.2 | High-T, P = 10–40 MPa |\n| 15 | GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_5 | 72 | 523.2–618.2 | High-T, P = 20–40 MPa |\n\n---\n\n### Key Observations for Measurement Planning\n\n1. **Water-rich region is well covered.** Multiple independent studies (GLOBlit_555, GLOBlit_590, GLOBlit_4415, GLOBlit_7085, GLOBlit_8447) report densities at low propan-1-ol concentrations (w < 0.16 or x < 0.02) near 298.15 K, providing excellent cross-validation. Typical densities in this region are 976–997 kg/m³.\n\n2. **Intermediate compositions (x ≈ 0.02–0.2) are covered** by GLOBlit_2979 (mole fraction up to 0.2, ρ down to ~912 kg/m³) and GLOBlit_5585 (mass fraction up to 0.4, ρ down to ~924 kg/m³). The density decreases markedly with increasing alcohol content due to the lower density of propan-1-ol (~800 kg/m³ pure).\n\n3. **Alcohol-rich region (x > 0.5) at 298.15 K has limited ambient-pressure data.** GLOBlit_8888 provides data in propan-1-ol as solvent (ρ ≈ 800–804 kg/m³ at 298.15 K), and GLOBlit_4068/PROPblock_2 extends to very high molality (56.3 mol/kg, effectively pure propan-1-ol). However, systematic composition-scan data in the alcohol-rich region appears sparse — this represents a potential gap worth filling.\n\n4. **Density differences (Δρ)** rather than absolute densities are reported in GLOBlit_2432, which may be useful for high-precision comparisons but requires a reference density to convert to absolute values.\n\n5. **Non-ideal mixing behavior** is characteristic of this system. Water and 1-propanol exhibit negative excess volumes (the mixture is denser than ideal mixing would predict), driven by hydrogen bonding between water and the alcohol hydroxyl group. The density vs. composition curve is not linear, with the most pronounced deviations at intermediate compositions.\n\n6. **Composition variables differ across studies** — mole fraction (x), mass fraction (w), and molality (b) are all used. At 298.15 K, a mole fraction of x = 0.1 for propan-1-ol corresponds roughly to a mass fraction of w ≈ 0.25.\n\n7. **Approximately 4–5 additional blocks** may exist in the registry but were not fully retrieved; the total count is ~20 blocks across ~18 DOIs.",
  "core_claims": [
    "The ThermoML database contains approximately 20 data blocks across 18 DOIs reporting mass density for the binary water + 1-propanol system, of which at least 12 blocks from 11 literature sources include data at or near 298.15 K.",
    "The water-rich composition region (mass fraction of propan-1-ol below ~0.16 or mole fraction below ~0.02) at 298.15 K and ambient pressure is well covered by multiple independent studies, with typical densities of 976–997 kg/m³, enabling cross-validation.",
    "Intermediate compositions (mole fraction up to ~0.2 or mass fraction up to ~0.4) at 298.15 K are covered by at least two studies, showing density decreasing markedly with increasing alcohol content down to approximately 912–924 kg/m³.",
    "The alcohol-rich region (mole fraction > 0.5) at 298.15 K and ambient pressure has limited systematic composition-scan data, representing a potential gap in the available measurements.",
    "High-pressure data at or near 298.15 K are available in at least two blocks, covering pressures up to 40 MPa and densities spanning approximately 322–1004 kg/m³.",
    "Composition variables differ across studies (mole fraction, mass fraction, and molality), and one study reports density differences rather than absolute densities, requiring a reference density for conversion.",
    "The water + 1-propanol system exhibits non-ideal mixing behavior with negative excess volumes, so the density vs. composition curve is nonlinear with the most pronounced deviations at intermediate compositions."
  ],
  "confidence": "medium",
  "sources": [
    {
      "doi": "10.1016/j.fluid.2007.07.066",
      "lit_num_id": "GLOBlit_555",
      "block": "PROPblock_8",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol, T = 283.15–303.15 K, w(propan-1-ol) = 0.05–0.15, ρ = 976.0–992.4 kg/m³, 15 points, vibrating tube"
    },
    {
      "doi": "10.1016/j.fluid.2008.01.004",
      "lit_num_id": "GLOBlit_590",
      "block": "PROPblock_5",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol, T = 283.15–303.15 K, w(propan-1-ol) = 0.05–0.15, ρ = 975.8–992.4 kg/m³, 15 points, vibrating tube"
    },
    {
      "doi": "10.1016/j.jct.2004.07.019",
      "lit_num_id": "GLOBlit_2432",
      "block": "PROPblock_3",
      "BLKsubsys_id": null,
      "description": "Density differences (Δρ) of water + 1-propanol, T = 298.15–573.15 K, b(propan-1-ol) = 0.094–0.847 mol/kg, Δρ = −20.2 to −1.0, 456 points, vibrating tube"
    },
    {
      "doi": "10.1016/j.jct.2008.07.005",
      "lit_num_id": "GLOBlit_2979",
      "block": "PROPblock_9",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol, T = 283.15–308.15 K, x(propan-1-ol) = 0–0.2, ρ = 911.8–999.7 kg/m³, 96 points, pycnometric"
    },
    {
      "doi": "10.1016/j.jct.2013.11.036",
      "lit_num_id": "GLOBlit_4068",
      "block": "PROPblock_2",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at P = 101 kPa, T = 292.05–352.05 K, b(propan-1-ol) = 0.869–56.348 mol/kg, ρ = 801.0–991.4 kg/m³, 29 points, pycnometric"
    },
    {
      "doi": "10.1016/j.jct.2013.11.036",
      "lit_num_id": "GLOBlit_4068",
      "block": "PROPblock_1",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at high pressure, T = 298.15–582.08 K, b = 0.869–56.348 mol/kg, P = 2353–40000 kPa, ρ = 322.1–1004.4 kg/m³, 174 points, constant-volume piezometry"
    },
    {
      "doi": "10.1016/j.jct.2015.06.024",
      "lit_num_id": "GLOBlit_4415",
      "block": "PROPblock_5",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at P = 84.5 kPa, T = 288.15–308.15 K, b(propan-1-ol) = 0.017–0.166 mol/kg, ρ = 992.3–998.9 kg/m³, 40 points, vibrating tube"
    },
    {
      "doi": "10.1016/j.jct.2019.105880",
      "lit_num_id": "GLOBlit_5585",
      "block": "PROPblock_7",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at P = 100 kPa, T = 288.15–303.15 K, w(propan-1-ol) = 0.1–0.4, ρ = 924.4–985.2 kg/m³, 16 points, vibrating tube"
    },
    {
      "doi": "10.1021/acs.jced.6b01058",
      "lit_num_id": "GLOBlit_7085",
      "block": "PROPblock_8",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at P = 85 kPa, T = 298.15–313.15 K, w(propan-1-ol) = 0.04–0.16, ρ = 966.8–990.6 kg/m³, 12 points, vibrating tube"
    },
    {
      "doi": "10.1021/acs.jced.7b00299",
      "lit_num_id": "GLOBlit_7178",
      "block": "PROPblock_13",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at P = 100 kPa, T = 298.15–313.15 K, b(propan-1-ol) = 14.0 mol/kg (fixed), ρ = 903.2–914.4 kg/m³, 2 points, vibrating tube"
    },
    {
      "doi": "10.1021/je049738c",
      "lit_num_id": "GLOBlit_8447",
      "block": "PROPblock_26",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at T = 298.15 K (fixed), P = 101.3 kPa, x(propan-1-ol) = 0.0008–0.021, ρ = 986.7–996.6 kg/m³, 8 points, vibrating tube"
    },
    {
      "doi": "10.1021/je0601098",
      "lit_num_id": "GLOBlit_8888",
      "block": "PROPblock_22",
      "BLKsubsys_id": null,
      "description": "Mass density of water in propan-1-ol solvent at T = 298.15 K (fixed), P = 101 kPa, b(water) = 0–1.005 mol/kg, ρ = 799.7–804.3 kg/m³, 12 points, vibrating tube"
    },
    {
      "doi": "10.1021/je034101z",
      "lit_num_id": "GLOBlit_8254",
      "block": "PROPblock_6",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol at high pressure, T = 282.15–425.15 K, x = 0.255–0.738, P = 5753–29883 kPa, ρ = 731.4–896.2 kg/m³, 380 points, isochoric"
    },
    {
      "doi": "10.1016/j.fluid.2015.07.012",
      "lit_num_id": "GLOBlit_1742",
      "block": "PROPblock_5",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol, T = 350.7–476.2 K, P = 10–40 MPa, 84 points; high-T only, not near 298.15 K"
    },
    {
      "doi": "10.1016/j.fluid.2017.09.005",
      "lit_num_id": "GLOBlit_2092",
      "block": "PROPblock_5",
      "BLKsubsys_id": null,
      "description": "Mass density of water + 1-propanol, T = 523.2–618.2 K, P = 20–40 MPa, 72 points; high-T only, not near 298.15 K"
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_5",
      "registry_id": "propan-1-ol",
      "name": "propan-1-ol"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_1",
      "registry_id": "Mass density",
      "name": "Mass density (kg/m³)"
    }
  ],
  "follow_up_suggestions": [
    "Query individual blocks (e.g., PROPblock_9 from GLOBlit_2979) to extract exact data points at T = 298.15 K for cross-validation.",
    "Retrieve excess molar volume (VE) data for the same system to complement density measurements and characterize non-ideal mixing.",
    "Search for speed-of-sound or viscosity data for water + 1-propanol near 298.15 K to support a comprehensive thermophysical characterization.",
    "Investigate the alcohol-rich composition region (x_propanol > 0.5) at 298.15 K more thoroughly, as existing ambient-pressure data appears sparse in that range.",
    "Approximately 4–5 additional blocks may exist in the registry that were not fully retrieved due to query size limits; a narrower targeted query could capture these."
  ]
}

#### pure_water_density
{
  "answer": "Five independent ThermoML sources report the mass density of pure liquid water (H₂O) at 298.15 K and atmospheric pressure (~101.325 kPa). The values are in excellent mutual agreement:\n\n| # | Density (kg/m³) | Block | Literature ID | DOI | Measurement Method |\n|---|-----------------|-------|---------------|-----|--------------------|\n| 1 | 997.06 | PROPblock_6 | GLOBlit_306 | 10.1016/j.fluid.2005.09.009 | Vibrating tube (UFactor 8) |\n| 2 | 997.043 | PROPblock_2 | GLOBlit_555 | 10.1016/j.fluid.2007.07.066 | Vibrating tube (UFactor 4) |\n| 3 | 997.04 | PROPblock_38 | GLOBlit_604 | 10.1016/j.fluid.2008.02.008 | Pycnometric method |\n| 4 | 997.06 | PROPblock_6 | GLOBlit_560 | 10.1016/j.fluid.2007.08.008 | Vibrating tube method |\n| 5 | 997.06 | PROPblock_8 | GLOBlit_645 | 10.1016/j.fluid.2008.07.001 | Vibrating tube (UFactor 2) |\n\n**Conditions:**\n- **Temperature:** 298.15 K (25 °C)\n- **Pressure:** 101.325 kPa (atmospheric)\n- **Phase:** Liquid\n- **System:** Pure component (unary)\n\n**Summary for comparison use:**\nThe measured values cluster tightly around **997.05 kg/m³**, with a spread of only ±0.02 kg/m³ across all five sources. This is fully consistent with the well-known density of liquid water near 25 °C. The remarkably small inter-laboratory scatter reflects the high reproducibility of this fundamental thermophysical property and makes it an excellent reference value for calibrating or benchmarking mixture density measurements.\n\nA recommended representative value for comparison purposes is **997.05 ± 0.02 kg/m³** at 298.15 K and 101.325 kPa.",
  "core_claims": [
    "Five independent ThermoML sources report the mass density of pure liquid water at 298.15 K and 101.325 kPa, yielding values that cluster tightly around 997.05 kg/m³ with a spread of only ±0.02 kg/m³.",
    "The remarkably small inter-laboratory scatter across vibrating-tube and pycnometric methods confirms high reproducibility and makes this an excellent reference value for calibrating or benchmarking mixture density measurements.",
    "A recommended representative value for comparison purposes is 997.05 ± 0.02 kg/m³ at 298.15 K and 101.325 kPa."
  ],
  "confidence": "medium",
  "sources": [
    {
      "doi": "10.1016/j.fluid.2005.09.009",
      "lit_num_id": "GLOBlit_306",
      "block": "PROPblock_6",
      "BLKsubsys_id": null,
      "description": "Pure water density 997.06 kg/m³ at 298.15 K, 101.325 kPa; vibrating tube method (UFactor 8)"
    },
    {
      "doi": "10.1016/j.fluid.2007.07.066",
      "lit_num_id": "GLOBlit_555",
      "block": "PROPblock_2",
      "BLKsubsys_id": null,
      "description": "Pure water density 997.043 kg/m³ at 298.15 K, 101.325 kPa; vibrating tube method (UFactor 4)"
    },
    {
      "doi": "10.1016/j.fluid.2008.02.008",
      "lit_num_id": "GLOBlit_604",
      "block": "PROPblock_38",
      "BLKsubsys_id": null,
      "description": "Pure water density 997.04 kg/m³ at 298.15 K, 101.325 kPa; pycnometric method"
    },
    {
      "doi": "10.1016/j.fluid.2007.08.008",
      "lit_num_id": "GLOBlit_560",
      "block": "PROPblock_6",
      "BLKsubsys_id": null,
      "description": "Pure water density 997.06 kg/m³ at 298.15 K, 101.325 kPa; vibrating tube method"
    },
    {
      "doi": "10.1016/j.fluid.2008.07.001",
      "lit_num_id": "GLOBlit_645",
      "block": "PROPblock_8",
      "BLKsubsys_id": null,
      "description": "Pure water density 997.06 kg/m³ at 298.15 K, 101.325 kPa; vibrating tube method (UFactor 2)"
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "prop",
      "global_id": "GLOBprop_1",
      "registry_id": null,
      "name": "Mass density"
    }
  ],
  "follow_up_suggestions": [
    "Both L1_query attempts failed (checksum mismatch and compaction overflow), so the identifiers in the answer were produced by the working agent from partial or cached results. Re-running with tighter filters or smaller result sets would strengthen confidence.",
    "To compare against mixture densities, query the same DOIs for binary/ternary blocks containing water plus the solute of interest at 298.15 K.",
    "Consider querying for excess molar volume (GLOBprop_28) or apparent molar volume data in the same literature sources for a more detailed comparison."
  ]
}

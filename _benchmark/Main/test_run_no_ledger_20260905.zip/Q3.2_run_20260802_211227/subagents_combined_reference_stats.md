# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 6 | 31,792 | 37,896 | 8,837 | 69,688 | 11,614 | 54.2 | claudeopus46 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| L1-worker | 28 | 287,551 | 115,411 | 49,692 | 402,962 | 14,391 | 286.2 | claudeopus46 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| L0-main | 7 | 32,090 | 168,711 | 24,801 | 200,801 | 28,685 | 148.0 | claudeopus46 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| L1-worker | 37 | 322,534 | 796,123 | 61,633 | 1,118,657 | 30,233 | 424.0 | claudeopus46 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| **TOTAL** | **78** | **673,967** | **1,118,141** | **144,963** | **1,792,108** | **84,923** | **912.4** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| `block_search_adv` | 1 | 0 | 0 | 0 | 5 | 0 | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 5 | 3 | 16 | 17 | 1,379 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 5 | 3 | 16 | 17 | 1,379 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_system_registry` | 2 | 1 | 5 | 2 | 13 | 14 | 1,346 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 5 | 3 | 16 | 17 | 1,379 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 40 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 16 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 5 | 3 | 16 | 17 | 1,379 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_system_registry` | 2 | 1 | 5 | 3 | 19 | 20 | 1,546 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 84 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 380 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| **TOTAL** | **25** | **12** | **41** | **19** | **105** | **106** | **8,928** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | --- | --- |
| Unique Compounds | 1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Unique Properties | 1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Unique Variables | 1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Unique References | 5 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Unique Block_Types | 1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Unique Phases | 1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Unique parent blocks | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Explicit block/subsystem targets | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Subsystem targets | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| Target-matched data points | 0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_5 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBprop_1 |  | resolve_property_ids, search_blocks, search_system_registry |
| GLOBlit_555 |  | search_blocks, search_system_registry |
| GLOBlit_590 |  | search_blocks, search_system_registry |
| GLOBlit_2432 |  | search_blocks, search_system_registry |
| GLOBlit_2979 |  | search_blocks, search_system_registry |
| GLOBlit_4068 |  | search_blocks, search_system_registry |
| GLOBlit_4415 |  | search_blocks, search_system_registry |
| GLOBlit_5585 |  | search_blocks, search_system_registry |
| GLOBlit_7085 |  | search_blocks, search_system_registry |
| GLOBlit_7178 |  | search_blocks, search_system_registry |
| GLOBlit_8254 |  | search_blocks, search_system_registry |
| GLOBlit_8447 |  | search_blocks, search_system_registry |
| GLOBlit_8888 |  | search_blocks, search_system_registry |
| GLOBlit_10159 |  | search_blocks, search_system_registry |
| GLOBlit_11042 |  | search_blocks, search_system_registry |
| GLOBlit_11142 |  | search_blocks, search_system_registry |
| GLOBlit_11872 |  | search_blocks, search_system_registry |
| GLOBlit_1742 |  | search_blocks, search_system_registry |
| GLOBlit_2092 |  | search_system_registry |
| GLOBlit_11606 |  | search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_153 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_66 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_170 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_143 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBphase_1 |  | search_blocks, search_system_registry |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_8 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_9 |  | search_blocks, search_system_registry |
| GLOBblocktype_1 |  | search_system_registry |
| Unique Compounds | 2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique Properties | 1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique References | 19 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique Measurements | 7 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique Phases | 1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique Variables | 5 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique Constraints | 3 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique Solvents | 2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique Block_Types | 1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Unique parent blocks | 20 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Explicit block/subsystem targets | 20 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Subsystem targets | 0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| Target-matched data points | 8,928 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| **TOTAL** | **9,019** |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve water to it… | 190 | KEEP | 190 | 4.9 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=80, purpose=Confirm GLOBprop_1 … | 266 | KEEP | 266 | 4.1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 3 | 1 | `L1_query` | context=The user needs a reference pu…, id_catalog… | 291 | — | — | 132.4 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve water compo… | 201 | KEEP | 201 | 4.5 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 5 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 224 | KEEP | 224 | 4.7 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 6 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_1 AS water…, explanat… | 859 | KEEP | 859 | 39.2 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 7 | 2 | `L1_query` | context=The user wants a reference pu…, id_catalog… | 270 | — | — | 174.0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve water and 1… | 206 | KEEP | 206 | 3.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 2 | 1 | `resolve_property_ids` | limit=5, min_score=70, purpose=Confirm GLOBprop_1 … | 276 | KEEP | 276 | 4.3 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 3 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=50, p… | 1,133 | KEEP | 1133 | 23.1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 4 | 1 | `L1_query` | context=User wants to know what exist…, id_catalog… | 270 | — | — | 99.2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 5 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=50, p… | 1,149 | KEEP | 1134 | 22.0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 6 | 2 | `search_system_registry` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=100, … | 1,208 | KEEP | 1042 | 20.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 7 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=50, p… | 1,166 | KEEP | 1078 | 21.8 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 8 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=50, l… | 1,017 | KEEP | 1002 | 13.8 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 9 | 5 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=50, l… | 1,213 | KEEP | 1198 | 13.0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10 | 6 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=50, p… | 1,046 | KEEP | 988 | 24.4 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 11 | 7 | `search_system_registry` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=100, … | 1,321 | KEEP | 1098 | 17.4 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 12 | 8 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=10, l… | 711 | KEEP | 696 | 17.1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 13 | 8 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_5'], limit=10, l… | 1,305 | KEEP | 1290 | 14.2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 14 | 2 | `L1_query` | context=User wants comprehensive list…, id_catalog… | 270 | — | — | 347.3 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| **TOTAL** | **69** |  |  | **14,592** |  | **12,881** | **1,005.6** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 2,714 | 2,714 | 0 | 0.0% | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 2 | interval=3 | skipped_by_agent | 4,780 | 4,780 | 0 | 0.0% | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 1 | interval=3 | skipped_by_agent | 6,178 | 6,178 | 0 | 0.0% | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 2 | interval=3 | skipped_by_agent | 11,255 | 11,255 | 0 | 0.0% | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| **TOTAL** |  |  | **24,927** | **24,927** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 768 | 10,373 | 1,000 | 7.7 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,002 | 21,645 | 860 | 6.9 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,590 | 23,233 | 9,869 | 48.5 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 4 | L1-worker | claudeopus46 | 2,065 | 352 | 2,417 | 414 | 4.2 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 5 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 426 | 4.0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,062 | 23,705 | 4,804 | 28.9 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 7 | L1-worker | claudeopus46 | 20,643 | 8,487 | 29,130 | 2,837 | 14.0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 8 | L1-worker | claudeopus46 | 1,356 | 1,630 | 2,986 | 496 | 3.5 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 9 | L1-worker | claudeopus46 | 536 | 1,510 | 2,046 | 532 | 3.6 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,377 | 5,700 | 2,208 | 9.7 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 11 | L1-worker | claudeopus46 | 298 | 2,930 | 3,228 | 1,585 | 7.2 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 12 | L1-worker | claudeopus46 | 1,160 | 7,022 | 8,182 | 1,585 | 7.1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 13 | L0-main | claudeopus46 | 9,605 | 1,517 | 11,122 | 1,084 | 7.9 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 14 | L1-worker | claudeopus46 | 20,643 | 1,040 | 21,683 | 761 | 6.6 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 15 | L1-worker | claudeopus46 | 20,643 | 2,422 | 23,065 | 8,164 | 37.1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 16 | L1-worker | claudeopus46 | 2,065 | 342 | 2,407 | 415 | 4.1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 17 | L1-worker | claudeopus46 | 20,643 | 2,539 | 23,182 | 732 | 5.7 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 18 | L1-worker | claudeopus46 | 2,065 | 357 | 2,422 | 442 | 4.4 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 19 | L1-worker | claudeopus46 | 20,610 | 4,009 | 24,619 | 455 | 4.3 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 20 | L1-worker | claudeopus46 | 20,643 | 3,256 | 23,899 | 3,283 | 20.9 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 21 | L1-worker | claudeopus46 | 20,643 | 4,092 | 24,735 | 1,045 | 7.1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 22 | L1-worker | claudeopus46 | 20,643 | 4,893 | 25,536 | 1,326 | 9.5 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 23 | L1-worker | claudeopus46 | 2,065 | 4,075 | 6,140 | 1,172 | 9.6 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 24 | L1-worker | claudeopus46 | 20,610 | 6,150 | 26,760 | 509 | 4.7 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 25 | L1-worker | claudeopus46 | 20,643 | 5,397 | 26,040 | 1,198 | 7.9 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,329 | 2,685 | 330 | 3.0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 27 | L1-worker | claudeopus46 | 536 | 1,209 | 1,745 | 486 | 3.4 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 28 | L1-worker | claudeopus46 | 1,323 | 7,520 | 8,843 | 1,831 | 8.0 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 29 | L1-worker | claudeopus46 | 298 | 2,553 | 2,851 | 1,324 | 6.1 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 30 | L1-worker | claudeopus46 | 747 | 30,907 | 31,654 | 603 | 6.2 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 31 | L0-main | claudeopus46 | 9,605 | 26,874 | 36,479 | 2,440 | 16.2 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 32 | L0-main | claudeopus46 | 1,356 | 1,713 | 3,069 | 562 | 3.6 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 33 | L0-main | claudeopus46 | 1,323 | 4,378 | 5,701 | 1,978 | 12.5 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 34 | L0-main | claudeopus46 | 298 | 2,646 | 2,944 | 1,773 | 6.3 | Find the experimental density of pure water at 298.15 K. Rep (query_runs/run_21) |
| 1 | L0-main | claudeopus46 | 9,605 | 880 | 10,485 | 1,063 | 6.5 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,043 | 21,686 | 1,087 | 7.7 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 3 | L1-worker | claudeopus46 | 2,065 | 448 | 2,513 | 351 | 3.5 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 4 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 436 | 4.3 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,199 | 22,842 | 887 | 6.8 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 6 | L1-worker | claudeopus46 | 2,065 | 11,851 | 13,916 | 1,629 | 14.5 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 7 | L1-worker | claudeopus46 | 20,643 | 3,867 | 24,510 | 3,582 | 21.4 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 8 | L1-worker | claudeopus46 | 536 | 2,723 | 3,259 | 768 | 3.9 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 9 | L1-worker | claudeopus46 | 1,356 | 2,843 | 4,199 | 1,243 | 5.8 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10 | L1-worker | claudeopus46 | 1,323 | 6,690 | 8,013 | 2,592 | 11.2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 11 | L1-worker | claudeopus46 | 298 | 3,314 | 3,612 | 2,129 | 9.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 12 | L1-worker | claudeopus46 | 747 | 46,666 | 47,413 | 1,073 | 10.3 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 13 | L0-main | claudeopus46 | 9,605 | 42,997 | 52,602 | 1,850 | 13.2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 14 | L1-worker | claudeopus46 | 20,643 | 42,880 | 63,523 | 958 | 7.0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 15 | L1-worker | claudeopus46 | 2,065 | 11,854 | 13,919 | 1,573 | 14.2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 16 | L1-worker | claudeopus46 | 20,643 | 44,546 | 65,189 | 955 | 7.0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 17 | L1-worker | claudeopus46 | 2,065 | 2,805 | 4,870 | 1,886 | 12.7 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 18 | L1-worker | claudeopus46 | 20,643 | 46,306 | 66,949 | 3,564 | 23.7 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 19 | L1-worker | claudeopus46 | 2,065 | 11,844 | 13,909 | 1,598 | 14.0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 20 | L1-worker | claudeopus46 | 20,610 | 48,830 | 69,440 | 554 | 5.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 21 | L1-worker | claudeopus46 | 20,643 | 48,077 | 68,720 | 1,098 | 8.4 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 22 | L1-worker | claudeopus46 | 2,065 | 2,779 | 4,844 | 2,030 | 13.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 23 | L1-worker | claudeopus46 | 20,643 | 49,705 | 70,348 | 2,175 | 14.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 24 | L1-worker | claudeopus46 | 2,065 | 2,509 | 4,574 | 1,691 | 12.7 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 25 | L1-worker | claudeopus46 | 20,643 | 51,557 | 72,200 | 1,679 | 13.2 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 26 | L1-worker | claudeopus46 | 2,065 | 11,824 | 13,889 | 1,869 | 15.9 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 27 | L1-worker | claudeopus46 | 20,610 | 53,984 | 74,594 | 444 | 5.0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 28 | L1-worker | claudeopus46 | 20,643 | 53,229 | 73,872 | 1,460 | 10.9 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 29 | L1-worker | claudeopus46 | 2,065 | 3,580 | 5,645 | 1,415 | 10.1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 30 | L1-worker | claudeopus46 | 20,643 | 55,117 | 75,760 | 2,407 | 15.4 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 31 | L1-worker | claudeopus46 | 2,065 | 3,647 | 5,712 | 1,787 | 16.9 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 32 | L1-worker | claudeopus46 | 2,065 | 2,705 | 4,770 | 1,823 | 14.0 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 33 | L1-worker | claudeopus46 | 20,643 | 58,061 | 78,704 | 4,333 | 30.5 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 34 | L1-worker | claudeopus46 | 1,356 | 3,221 | 4,577 | 922 | 5.8 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 35 | L1-worker | claudeopus46 | 536 | 3,101 | 3,637 | 1,187 | 7.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 36 | L1-worker | claudeopus46 | 298 | 1,304 | 1,602 | 910 | 6.9 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 37 | L1-worker | claudeopus46 | 1,323 | 19,993 | 21,316 | 3,488 | 16.3 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 38 | L1-worker | claudeopus46 | 298 | 4,210 | 4,508 | 2,929 | 12.6 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 39 | L1-worker | claudeopus46 | 747 | 76,452 | 77,199 | 1,121 | 10.4 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 40 | L0-main | claudeopus46 | 9,605 | 102,035 | 111,640 | 8,137 | 56.1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 41 | L0-main | claudeopus46 | 1,356 | 5,683 | 7,039 | 1,531 | 8.8 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 42 | L0-main | claudeopus46 | 298 | 1,913 | 2,211 | 1,519 | 4.8 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 43 | L0-main | claudeopus46 | 1,323 | 8,925 | 10,248 | 5,610 | 33.1 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 44 | L0-main | claudeopus46 | 298 | 6,278 | 6,576 | 5,091 | 25.5 | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| **TOTAL** |  |  | **673,967** | **1,118,141** | **1,792,108** | **144,963** | **912.4** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | ---: | --- | ---: |
| 10.1016/j.fluid.2007.07.066 | 1 | 15 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.fluid.2008.01.004 | 1 | 15 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.fluid.2015.07.012 | 1 | 84 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.fluid.2017.09.005 | 1 | 72 | binary | search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.jct.2004.07.019 | 1 | 456 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.jct.2008.07.005 | 1 | 96 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.jct.2013.11.036 | 2 | 203 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.jct.2015.06.024 | 1 | 40 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.jct.2019.105880 | 1 | 16 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/acs.jced.6b01058 | 1 | 12 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/acs.jced.7b00299 | 1 | 2 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je034101z | 1 | 380 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je049738c | 1 | 8 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je0601098 | 1 | 12 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je4003515 | 1 | 25 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je700700f | 1 | 13 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je800158z | 1 | 56 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je900337a | 1 | 11 | binary | search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1021/je900966r | 1 | 30 | binary | search_blocks, search_system_registry | Find mixture density measurements for the binary system wate (query_runs/run_20) |
| 10.1016/j.fluid.2007.07.066 | PROPblock_8 | declared | 15 | binary | 2 |
| 10.1016/j.fluid.2008.01.004 | PROPblock_5 | declared | 15 | binary | 2 |
| 10.1016/j.fluid.2015.07.012 | PROPblock_5 | declared | 84 | binary | 2 |
| 10.1016/j.fluid.2017.09.005 | PROPblock_5 | declared | 72 | binary | 2 |
| 10.1016/j.jct.2004.07.019 | PROPblock_3 | declared | 456 | binary | 2 |
| 10.1016/j.jct.2008.07.005 | PROPblock_9 | declared | 96 | binary | 2 |
| 10.1016/j.jct.2013.11.036 | PROPblock_1 | declared | 174 | binary | 2 |
| 10.1016/j.jct.2013.11.036 | PROPblock_2 | declared | 29 | binary | 2 |
| 10.1016/j.jct.2015.06.024 | PROPblock_5 | declared | 40 | binary | 2 |
| 10.1016/j.jct.2019.105880 | PROPblock_7 | declared | 16 | binary | 2 |
| 10.1021/acs.jced.6b01058 | PROPblock_8 | declared | 12 | binary | 2 |
| 10.1021/acs.jced.7b00299 | PROPblock_13 | declared | 2 | binary | 2 |
| 10.1021/je034101z | PROPblock_6 | declared | 380 | binary | 2 |
| 10.1021/je049738c | PROPblock_26 | declared | 8 | binary | 2 |
| 10.1021/je0601098 | PROPblock_22 | declared | 12 | binary | 2 |
| 10.1021/je4003515 | PROPblock_10 | declared | 25 | binary | 2 |
| 10.1021/je700700f | PROPblock_14 | declared | 13 | binary | 2 |
| 10.1021/je800158z | PROPblock_3 | declared | 56 | binary | 2 |
| 10.1021/je900337a | PROPblock_17 | declared | 11 | binary | 2 |
| 10.1021/je900966r | PROPblock_4 | declared | 30 | binary | 2 |
| **TOTAL** | **20** | **1,546** | **1,546** |  | **40** |

# Delegated query run — result

**Question:** Find mixture density measurements for the binary system water + 1-propanol near 298.15 K. Report all available DOIs, block numbers, temperature ranges, composition ranges, and density values.

**Iterations:** 3  |  **Elapsed:** 522.7s  |  **Tools:** 2  |  **Timed out:** False

---

## Answer

## Mixture Density Data for Binary Water + 1-Propanol near 298.15 K in ThermoML

The ThermoML database contains approximately **20 data blocks across 18 DOIs** for mass density of the binary water (GLOBcomp_1) + 1-propanol (GLOBcomp_5) system. Of these, **at least 12 blocks from 11 literature sources** include data at or near 298.15 K at ambient pressure, plus additional blocks at elevated pressures. Below is a comprehensive listing.

---

### Ambient-Pressure Blocks Covering ~298.15 K

| # | Literature ID | DOI | Block | Points | T range (K) | Composition variable & range | ρ range (kg/m³) | Method |
|---|---------------|-----|-------|--------|-------------|------------------------------|-----------------|--------|
| 1 | GLOBlit_555 | 10.1016/j.fluid.2007.07.066 | PROPblock_8 | 15 | 283.15–303.15 | w(propan-1-ol) = 0.05–0.15 | 976.0–992.4 | Vibrating tube |
| 2 | GLOBlit_590 | 10.1016/j.fluid.2008.01.004 | PROPblock_5 | 15 | 283.15–303.15 | w(propan-1-ol) = 0.05–0.15 | 975.8–992.4 | Vibrating tube |
| 3 | GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_3 | 456 | 298.15–573.15 | b(propan-1-ol) = 0.094–0.847 mol/kg | Δρ = −20.2 to −1.0 (density differences) | Vibrating tube |
| 4 | GLOBlit_2979 | 10.1016/j.jct.2008.07.005 | PROPblock_9 | 96 | 283.15–308.15 | x(propan-1-ol) = 0–0.2 | 911.8–999.7 | Pycnometric |
| 5 | GLOBlit_4068 | 10.1016/j.jct.2013.11.036 | PROPblock_2 | 29 | 292.05–352.05 | b(propan-1-ol) = 0.869–56.348 mol/kg | 801.0–991.4 | Pycnometric (P = 101 kPa) |
| 6 | GLOBlit_4415 | 10.1016/j.jct.2015.06.024 | PROPblock_5 | 40 | 288.15–308.15 | b(propan-1-ol) = 0.017–0.166 mol/kg | 992.3–998.9 | Vibrating tube (P = 84.5 kPa) |
| 7 | GLOBlit_5585 | 10.1016/j.jct.2019.105880 | PROPblock_7 | 16 | 288.15–303.15 | w(propan-1-ol) = 0.1–0.4 | 924.4–985.2 | Vibrating tube (P = 100 kPa) |
| 8 | GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_8 | 12 | 298.15–313.15 | w(propan-1-ol) = 0.04–0.16 | 966.8–990.6 | Vibrating tube (P = 85 kPa) |
| 9 | GLOBlit_7178 | 10.1021/acs.jced.7b00299 | PROPblock_13 | 2 | 298.15–313.15 | b(propan-1-ol) = 14.0 mol/kg (fixed) | 903.2–914.4 | Vibrating tube (P = 100 kPa) |
| 10 | GLOBlit_8447 | 10.1021/je049738c | PROPblock_26 | 8 | 298.15 (fixed) | x(propan-1-ol) = 0.0008–0.021 | 986.7–996.6 | Vibrating tube (P = 101.3 kPa) |
| 11 | GLOBlit_8888 | 10.1021/je0601098 | PROPblock_22 | 12 | 298.15 (fixed) | b(water) = 0–1.005 mol/kg in propan-1-ol solvent | 799.7–804.3 | Vibrating tube (P = 101 kPa) |

---

### High-Pressure Blocks Also Covering ~298.15 K

| # | Literature ID | DOI | Block | Points | T range (K) | Composition & Pressure | ρ range (kg/m³) | Method |
|---|---------------|-----|-------|--------|-------------|------------------------|-----------------|--------|
| 12 | GLOBlit_4068 | 10.1016/j.jct.2013.11.036 | PROPblock_1 | 174 | 298.15–582.08 | b = 0.869–56.348 mol/kg; P = 2353–40000 kPa | 322.1–1004.4 | Constant-volume piezometry |
| 13 | GLOBlit_8254 | 10.1021/je034101z | PROPblock_6 | 380 | 282.15–425.15 | x = 0.255–0.738; P = 5753–29883 kPa | 731.4–896.2 | Isochoric |

---

### Blocks NOT Near 298.15 K (High-Temperature Only)

| # | Literature ID | DOI | Block | Points | T range (K) | Notes |
|---|---------------|-----|-------|--------|-------------|-------|
| 14 | GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_5 | 84 | 350.7–476.2 | High-T, P = 10–40 MPa |
| 15 | GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_5 | 72 | 523.2–618.2 | High-T, P = 20–40 MPa |

---

### Key Observations for Measurement Planning

1. **Water-rich region is well covered.** Multiple independent studies (GLOBlit_555, GLOBlit_590, GLOBlit_4415, GLOBlit_7085, GLOBlit_8447) report densities at low propan-1-ol concentrations (w < 0.16 or x < 0.02) near 298.15 K, providing excellent cross-validation. Typical densities in this region are 976–997 kg/m³.

2. **Intermediate compositions (x ≈ 0.02–0.2) are covered** by GLOBlit_2979 (mole fraction up to 0.2, ρ down to ~912 kg/m³) and GLOBlit_5585 (mass fraction up to 0.4, ρ down to ~924 kg/m³). The density decreases markedly with increasing alcohol content due to the lower density of propan-1-ol (~800 kg/m³ pure).

3. **Alcohol-rich region (x > 0.5) at 298.15 K has limited ambient-pressure data.** GLOBlit_8888 provides data in propan-1-ol as solvent (ρ ≈ 800–804 kg/m³ at 298.15 K), and GLOBlit_4068/PROPblock_2 extends to very high molality (56.3 mol/kg, effectively pure propan-1-ol). However, systematic composition-scan data in the alcohol-rich region appears sparse — this represents a potential gap worth filling.

4. **Density differences (Δρ)** rather than absolute densities are reported in GLOBlit_2432, which may be useful for high-precision comparisons but requires a reference density to convert to absolute values.

5. **Non-ideal mixing behavior** is characteristic of this system. Water and 1-propanol exhibit negative excess volumes (the mixture is denser than ideal mixing would predict), driven by hydrogen bonding between water and the alcohol hydroxyl group. The density vs. composition curve is not linear, with the most pronounced deviations at intermediate compositions.

6. **Composition variables differ across studies** — mole fraction (x), mass fraction (w), and molality (b) are all used. At 298.15 K, a mole fraction of x = 0.1 for propan-1-ol corresponds roughly to a mass fraction of w ≈ 0.25.

7. **Approximately 4–5 additional blocks** may exist in the registry but were not fully retrieved; the total count is ~20 blocks across ~18 DOIs.

### Core claims

- The ThermoML database contains approximately 20 data blocks across 18 DOIs reporting mass density for the binary water + 1-propanol system, of which at least 12 blocks from 11 literature sources include data at or near 298.15 K.
- The water-rich composition region (mass fraction of propan-1-ol below ~0.16 or mole fraction below ~0.02) at 298.15 K and ambient pressure is well covered by multiple independent studies, with typical densities of 976–997 kg/m³, enabling cross-validation.
- Intermediate compositions (mole fraction up to ~0.2 or mass fraction up to ~0.4) at 298.15 K are covered by at least two studies, showing density decreasing markedly with increasing alcohol content down to approximately 912–924 kg/m³.
- The alcohol-rich region (mole fraction > 0.5) at 298.15 K and ambient pressure has limited systematic composition-scan data, representing a potential gap in the available measurements.
- High-pressure data at or near 298.15 K are available in at least two blocks, covering pressures up to 40 MPa and densities spanning approximately 322–1004 kg/m³.
- Composition variables differ across studies (mole fraction, mass fraction, and molality), and one study reports density differences rather than absolute densities, requiring a reference density for conversion.
- The water + 1-propanol system exhibits non-ideal mixing behavior with negative excess volumes, so the density vs. composition curve is nonlinear with the most pronounced deviations at intermediate compositions.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_555 | 10.1016/j.fluid.2007.07.066 | PROPblock_8 |  | Mass density of water + 1-propanol, T = 283.15–303.15 K, w(propan-1-ol) = 0.05–0.15, ρ = 976.0–992.4 kg/m³, 15 points, vibrating tube |
| GLOBlit_590 | 10.1016/j.fluid.2008.01.004 | PROPblock_5 |  | Mass density of water + 1-propanol, T = 283.15–303.15 K, w(propan-1-ol) = 0.05–0.15, ρ = 975.8–992.4 kg/m³, 15 points, vibrating tube |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_3 |  | Density differences (Δρ) of water + 1-propanol, T = 298.15–573.15 K, b(propan-1-ol) = 0.094–0.847 mol/kg, Δρ = −20.2 to −1.0, 456 points, vibrating tube |
| GLOBlit_2979 | 10.1016/j.jct.2008.07.005 | PROPblock_9 |  | Mass density of water + 1-propanol, T = 283.15–308.15 K, x(propan-1-ol) = 0–0.2, ρ = 911.8–999.7 kg/m³, 96 points, pycnometric |
| GLOBlit_4068 | 10.1016/j.jct.2013.11.036 | PROPblock_2 |  | Mass density of water + 1-propanol at P = 101 kPa, T = 292.05–352.05 K, b(propan-1-ol) = 0.869–56.348 mol/kg, ρ = 801.0–991.4 kg/m³, 29 points, pycnometric |
| GLOBlit_4068 | 10.1016/j.jct.2013.11.036 | PROPblock_1 |  | Mass density of water + 1-propanol at high pressure, T = 298.15–582.08 K, b = 0.869–56.348 mol/kg, P = 2353–40000 kPa, ρ = 322.1–1004.4 kg/m³, 174 points, constant-volume piezometry |
| GLOBlit_4415 | 10.1016/j.jct.2015.06.024 | PROPblock_5 |  | Mass density of water + 1-propanol at P = 84.5 kPa, T = 288.15–308.15 K, b(propan-1-ol) = 0.017–0.166 mol/kg, ρ = 992.3–998.9 kg/m³, 40 points, vibrating tube |
| GLOBlit_5585 | 10.1016/j.jct.2019.105880 | PROPblock_7 |  | Mass density of water + 1-propanol at P = 100 kPa, T = 288.15–303.15 K, w(propan-1-ol) = 0.1–0.4, ρ = 924.4–985.2 kg/m³, 16 points, vibrating tube |
| GLOBlit_7085 | 10.1021/acs.jced.6b01058 | PROPblock_8 |  | Mass density of water + 1-propanol at P = 85 kPa, T = 298.15–313.15 K, w(propan-1-ol) = 0.04–0.16, ρ = 966.8–990.6 kg/m³, 12 points, vibrating tube |
| GLOBlit_7178 | 10.1021/acs.jced.7b00299 | PROPblock_13 |  | Mass density of water + 1-propanol at P = 100 kPa, T = 298.15–313.15 K, b(propan-1-ol) = 14.0 mol/kg (fixed), ρ = 903.2–914.4 kg/m³, 2 points, vibrating tube |
| GLOBlit_8447 | 10.1021/je049738c | PROPblock_26 |  | Mass density of water + 1-propanol at T = 298.15 K (fixed), P = 101.3 kPa, x(propan-1-ol) = 0.0008–0.021, ρ = 986.7–996.6 kg/m³, 8 points, vibrating tube |
| GLOBlit_8888 | 10.1021/je0601098 | PROPblock_22 |  | Mass density of water in propan-1-ol solvent at T = 298.15 K (fixed), P = 101 kPa, b(water) = 0–1.005 mol/kg, ρ = 799.7–804.3 kg/m³, 12 points, vibrating tube |
| GLOBlit_8254 | 10.1021/je034101z | PROPblock_6 |  | Mass density of water + 1-propanol at high pressure, T = 282.15–425.15 K, x = 0.255–0.738, P = 5753–29883 kPa, ρ = 731.4–896.2 kg/m³, 380 points, isochoric |
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_5 |  | Mass density of water + 1-propanol, T = 350.7–476.2 K, P = 10–40 MPa, 84 points; high-T only, not near 298.15 K |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_5 |  | Mass density of water + 1-propanol, T = 523.2–618.2 K, P = 20–40 MPa, 72 points; high-T only, not near 298.15 K |

### Suggested follow-ups

- Query individual blocks (e.g., PROPblock_9 from GLOBlit_2979) to extract exact data points at T = 298.15 K for cross-validation.
- Retrieve excess molar volume (VE) data for the same system to complement density measurements and characterize non-ideal mixing.
- Search for speed-of-sound or viscosity data for water + 1-propanol near 298.15 K to support a comprehensive thermophysical characterization.
- Investigate the alcohol-rich composition region (x_propanol > 0.5) at 298.15 K more thoroughly, as existing ambient-pressure data appears sparse in that range.
- Approximately 4–5 additional blocks may exist in the registry that were not fully retrieved due to query size limits; a narrower targeted query could capture these.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_5",
    "registry_id": "propan-1-ol",
    "name": "propan-1-ol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "Mass density",
    "name": "Mass density (kg/m³)"
  }
]
```

# Reference Stats — query-agent

**Run started:** 2026-08-02 21:13:52
**Wall time (at last flush):** 357.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 31,792 | 37,896 | 8,837 | 69,688 | 11,614 | 54.2 | claudeopus46 |
| L1-worker | 28 | 287,551 | 115,411 | 49,692 | 402,962 | 14,391 | 286.2 | claudeopus46 |
| **TOTAL** | **34** | **319,343** | **153,307** | **58,529** | **472,650** | **13,901** | **340.4** | |

**Estimated tokens:** ~118,162 input + ~14,632 output = ~132,794 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 1 | 0 | 0 | 0 | 5 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **3** | **1** | **1** | **0** | **5** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | resolve_property_ids |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |

#### References (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_306 |  | block_search_adv |
| GLOBlit_555 |  | block_search_adv |
| GLOBlit_560 |  | block_search_adv |
| GLOBlit_604 |  | block_search_adv |
| GLOBlit_645 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_2 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 1 |
| Unique Variables | 1 |
| Unique References | 5 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve water to it… | 190 | KEEP | 190 | 4.9 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=80, purpose=Confirm GLOBprop_1 … | 266 | KEEP | 266 | 4.1 |
| 3 | 1 | `L1_query` | context=The user needs a reference pu…, id_catalog… | 291 | — | — | 132.4 |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve water compo… | 201 | KEEP | 201 | 4.5 |
| 5 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 224 | KEEP | 224 | 4.7 |
| 6 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_1 AS water…, explanat… | 859 | KEEP | 859 | 39.2 |
| 7 | 2 | `L1_query` | context=The user wants a reference pu…, id_catalog… | 270 | — | — | 174.0 |
| | | **TOTAL (7 tools)** | | **2,301** | | **1,740** | **363.8** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 2,714 | 2,714 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,780 | 4,780 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 768 | 10,373 | 1,000 | 7.7 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,002 | 21,645 | 860 | 6.9 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,590 | 23,233 | 9,869 | 48.5 |
| 4 | L1-worker | claudeopus46 | 2,065 | 352 | 2,417 | 414 | 4.2 |
| 5 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 426 | 4.0 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,062 | 23,705 | 4,804 | 28.9 |
| 7 | L1-worker | claudeopus46 | 20,643 | 8,487 | 29,130 | 2,837 | 14.0 |
| 8 | L1-worker | claudeopus46 | 1,356 | 1,630 | 2,986 | 496 | 3.5 |
| 9 | L1-worker | claudeopus46 | 536 | 1,510 | 2,046 | 532 | 3.6 |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,377 | 5,700 | 2,208 | 9.7 |
| 11 | L1-worker | claudeopus46 | 298 | 2,930 | 3,228 | 1,585 | 7.2 |
| 12 | L1-worker | claudeopus46 | 1,160 | 7,022 | 8,182 | 1,585 | 7.1 |
| 13 | L0-main | claudeopus46 | 9,605 | 1,517 | 11,122 | 1,084 | 7.9 |
| 14 | L1-worker | claudeopus46 | 20,643 | 1,040 | 21,683 | 761 | 6.6 |
| 15 | L1-worker | claudeopus46 | 20,643 | 2,422 | 23,065 | 8,164 | 37.1 |
| 16 | L1-worker | claudeopus46 | 2,065 | 342 | 2,407 | 415 | 4.1 |
| 17 | L1-worker | claudeopus46 | 20,643 | 2,539 | 23,182 | 732 | 5.7 |
| 18 | L1-worker | claudeopus46 | 2,065 | 357 | 2,422 | 442 | 4.4 |
| 19 | L1-worker | claudeopus46 | 20,610 | 4,009 | 24,619 | 455 | 4.3 |
| 20 | L1-worker | claudeopus46 | 20,643 | 3,256 | 23,899 | 3,283 | 20.9 |
| 21 | L1-worker | claudeopus46 | 20,643 | 4,092 | 24,735 | 1,045 | 7.1 |
| 22 | L1-worker | claudeopus46 | 20,643 | 4,893 | 25,536 | 1,326 | 9.5 |
| 23 | L1-worker | claudeopus46 | 2,065 | 4,075 | 6,140 | 1,172 | 9.6 |
| 24 | L1-worker | claudeopus46 | 20,610 | 6,150 | 26,760 | 509 | 4.7 |
| 25 | L1-worker | claudeopus46 | 20,643 | 5,397 | 26,040 | 1,198 | 7.9 |
| 26 | L1-worker | claudeopus46 | 1,356 | 1,329 | 2,685 | 330 | 3.0 |
| 27 | L1-worker | claudeopus46 | 536 | 1,209 | 1,745 | 486 | 3.4 |
| 28 | L1-worker | claudeopus46 | 1,323 | 7,520 | 8,843 | 1,831 | 8.0 |
| 29 | L1-worker | claudeopus46 | 298 | 2,553 | 2,851 | 1,324 | 6.1 |
| 30 | L1-worker | claudeopus46 | 747 | 30,907 | 31,654 | 603 | 6.2 |
| 31 | L0-main | claudeopus46 | 9,605 | 26,874 | 36,479 | 2,440 | 16.2 |
| 32 | L0-main | claudeopus46 | 1,356 | 1,713 | 3,069 | 562 | 3.6 |
| 33 | L0-main | claudeopus46 | 1,323 | 4,378 | 5,701 | 1,978 | 12.5 |
| 34 | L0-main | claudeopus46 | 298 | 2,646 | 2,944 | 1,773 | 6.3 |


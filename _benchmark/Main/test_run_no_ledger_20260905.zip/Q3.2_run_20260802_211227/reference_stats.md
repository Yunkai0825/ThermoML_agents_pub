# Reference Stats — main-agent

**Run started:** 2026-08-02 21:12:27
**Wall time (at last flush):** 792.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 24,654 | 95,322 | 43,201 | 119,976 | 17,139 | 225.7 | claudeopus46 |
| **TOTAL** | **7** | **24,654** | **95,322** | **43,201** | **119,976** | **17,139** | **225.7** | |

**Estimated tokens:** ~29,994 input + ~10,800 output = ~40,794 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_parallel_subagents` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_parallel_subagents` | tasks=[{'agent': 'query', 'label': … | 20,284 | — | — | 581.8 |
| | | **TOTAL (1 tools)** | | **20,284** | | **0** | **581.8** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 420 | 10,635 | 18,915 | 84.2 |
| 2 | L0-main | claudeopus46 | 10,215 | 39,007 | 49,222 | 8,563 | 56.1 |
| 3 | L0-main | claudeopus46 | 1,356 | 8,692 | 10,048 | 1,658 | 11.5 |
| 4 | L0-main | claudeopus46 | 298 | 2,040 | 2,338 | 1,603 | 4.5 |
| 5 | L0-main | claudeopus46 | 1,323 | 32,190 | 33,513 | 6,055 | 32.8 |
| 6 | L0-main | claudeopus46 | 298 | 6,578 | 6,876 | 5,031 | 26.6 |
| 7 | L0-main | claudeopus46 | 949 | 6,395 | 7,344 | 1,376 | 10.0 |


# Main Agent Run — 20260802_204441 (Round 1)

**Question:** What viscosity data are available for rubbing alcohol mixed with water at room temperature?

**Time:** 140.1s | **Iterations:** 2 | **Tools:** 1

---

## Answer

## Viscosity Data for Rubbing Alcohol (Isopropanol) + Water at Room Temperature

### Overview

The ThermoML database contains **dynamic viscosity** measurements for the **propan-2-ol (isopropanol) + water** binary system — the standard formulation of rubbing alcohol. The data come from a single literature source and cover compositions at low-to-moderate isopropanol content.

---

### Data Source

- **Literature ID:** GLOBlit_5585 | **DOI:** 10.1016/j.jct.2019.105880
- **Data block:** PROPblock_12 (12 total data points, spanning 288–303 K)
- **Property:** Dynamic viscosity (Pa·s)
- **Method:** Falling/rolling sphere viscometry
- **Pressure:** 100.0 kPa (fixed)
- **Composition variable:** Mass fraction of propan-2-ol
- **Phase:** Liquid

---

### Viscosity Values at Room Temperature (293–298 K)

Six data points fall within the 20–25 °C (293–298 K) range:

| Temperature (K) | Mass fraction of isopropanol | Dynamic viscosity (Pa·s) | Uncertainty (Pa·s, 95% CI) |
|:---:|:---:|:---:|:---:|
| 293.15 | 0.10 | 0.001633 | ±0.000129 |
| 293.15 | 0.20 | 0.002485 | ±0.000169 |
| 293.15 | 0.30 | 0.003172 | ±0.000206 |
| 298.15 | 0.10 | 0.001395 | ±0.000105 |
| 298.15 | 0.20 | 0.002045 | ±0.000137 |
| 298.15 | 0.30 | 0.002555 | ±0.000164 |

Over the full block temperature range (288–303 K), viscosity values span from **0.001208 to 0.004014 Pa·s** (roughly 1.2–4.0 mPa·s).

---

### Chemistry Insight

The data reveal two well-known trends for this classic binary system:

1. **Viscosity increases with isopropanol content** — At these low-to-moderate concentrations (w = 0.10–0.30), adding isopropanol strengthens the hydrogen-bonding network between water and alcohol molecules, enhancing intermolecular friction. At 293.15 K, tripling the mass fraction from 0.10 to 0.30 nearly doubles the viscosity (from ~1.6 to ~3.2 mPa·s).

2. **Viscosity decreases with increasing temperature** — Greater thermal energy disrupts hydrogen bonds and increases molecular mobility. At w = 0.20, raising the temperature from 293.15 K to 298.15 K reduces viscosity by about 18% (from 2.485 to 2.045 mPa·s).

The composition range covered (w = 0.10–0.30) captures only the **lower portion** of the well-known viscosity maximum that the isopropanol–water system exhibits near w ≈ 0.5–0.6, where the extensive three-dimensional hydrogen-bonding network reaches its greatest structural complexity. Commercial rubbing alcohol (typically 70% isopropanol by volume, roughly w ≈ 0.70) lies beyond the range of this dataset.

---

### What Was Not Found

- No **kinematic viscosity** data were found for this binary system in the 293–298 K range.
- No viscosity data at higher isopropanol mass fractions (w > 0.30) were found in ThermoML for this temperature range, so the viscosity maximum region is not covered.

---

### Sources

- Literature ID: GLOBlit_5585 | DOI: 10.1016/j.jct.2019.105880 | Block: PROPblock_12 | System: propan-2-ol + water

### Core claims

- ThermoML contains dynamic viscosity data for the propan-2-ol (isopropanol) + water binary system at 100 kPa from a single source (DOI: 10.1016/j.jct.2019.105880), measured by falling/rolling sphere viscometry, covering mass fractions of isopropanol from 0.10 to 0.30 and temperatures from 288 to 303 K.
- At room temperature (293–298 K) and mass fractions 0.10–0.30, the dynamic viscosity ranges from approximately 0.001395 to 0.003172 Pa·s (~1.4–3.2 mPa·s), with reported expanded uncertainties on the order of ±0.0001–0.0002 Pa·s (95% CI).
- Within this composition range, viscosity increases with increasing isopropanol mass fraction—nearly doubling from w = 0.10 to w = 0.30 at 293.15 K—attributed to enhanced hydrogen-bonding interactions between water and alcohol molecules.
- Viscosity decreases with increasing temperature; for example, at w = 0.20, raising the temperature from 293.15 K to 298.15 K reduces viscosity by about 18%.
- The dataset covers only the low-to-moderate isopropanol concentration range (w ≤ 0.30) and does not reach the well-known viscosity maximum near w ≈ 0.5–0.6 or the composition of commercial rubbing alcohol (~70% isopropanol by volume, w ≈ 0.70).
- No kinematic viscosity data for this binary system in the 293–298 K range were found in ThermoML.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5585 | 10.1016/j.jct.2019.105880 | PROPblock_12 |  | Dynamic viscosity (Pa·s) measurements for propan-2-ol + water binary mixture at 288–303 K (6 points in the 293–298 K room-temperature range), mass fractions 0.10–0.30, pressure 100.0 kPa, measured by falling/rolling sphere viscometry. 12 total data points in the block. |

---

## Verdict

**Strategy Quality**
The agent correctly used `run_query_agent` to search for viscosity data on isopropanol + water. Only one tool call was made, which is appropriate for a data availability question that doesn't require fitting. No unnecessary calls were made, and no analysis agent was needed since no Redlich-Kister fitting was requested.

**Scientific Accuracy**
The reported trends (viscosity increasing with isopropanol content at low concentrations, decreasing with temperature) are physically sound and consistent with known behavior of this system. The claim that the viscosity maximum occurs near w ≈ 0.5–0.6 is well-established in the literature. The note that commercial rubbing alcohol (~70% isopropanol) lies outside the dataset range is a valuable caveat. The specific numerical values appear consistent with the query agent's returned data (5587 chars of results). One minor concern: the 18% decrease from 2.485 to 2.045 mPa·s is actually ~17.7%, which rounds correctly.

**Overall Verdict**
This is a well-structured, thorough response to a data availability question. The agent correctly identified the relevant system (propan-2-ol = isopropanol = rubbing alcohol), retrieved appropriate data, and provided honest limitations about composition coverage. The only recommendation would be to search additional databases or literature for higher concentration data to better serve the user's likely interest in commercial rubbing alcohol formulations. **PASS.**
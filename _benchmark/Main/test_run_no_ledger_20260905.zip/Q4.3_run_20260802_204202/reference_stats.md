# Reference Stats — main-agent

**Run started:** 2026-08-02 20:42:02
**Wall time (at last flush):** 159.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 24,356 | 31,161 | 8,198 | 55,517 | 9,252 | 52.5 | claudeopus46 |
| **TOTAL** | **6** | **24,356** | **31,161** | **8,198** | **55,517** | **9,252** | **52.5** | |

**Estimated tokens:** ~13,879 input + ~2,049 output = ~15,928 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_query_agent` | context=Rubbing alcohol is most commo…, purpose=Fi… | 5,587 | — | — | 112.0 |
| | | **TOTAL (1 tools)** | | **5,587** | | **0** | **112.0** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 276 | 10,491 | 1,540 | 9.3 |
| 2 | L0-main | claudeopus46 | 10,215 | 11,373 | 21,588 | 2,950 | 18.3 |
| 3 | L0-main | claudeopus46 | 1,323 | 10,306 | 11,629 | 500 | 3.3 |
| 4 | L0-main | claudeopus46 | 298 | 1,023 | 1,321 | 426 | 2.9 |
| 5 | L0-main | claudeopus46 | 1,356 | 3,079 | 4,435 | 1,306 | 8.0 |
| 6 | L0-main | claudeopus46 | 949 | 5,104 | 6,053 | 1,476 | 10.7 |


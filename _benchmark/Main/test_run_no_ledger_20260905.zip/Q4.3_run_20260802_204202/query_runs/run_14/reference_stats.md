# Reference Stats — query-agent

**Run started:** 2026-08-02 20:42:12
**Wall time (at last flush):** 111.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 42,100 | 7,801 | 64,287 | 12,857 | 48.8 | claudeopus46 |
| L1-worker | 12 | 111,572 | 45,138 | 10,796 | 156,710 | 13,059 | 76.5 | claudeopus46 |
| **TOTAL** | **17** | **133,759** | **87,238** | **18,597** | **220,997** | **12,999** | **125.3** | |

**Estimated tokens:** ~55,249 input + ~4,649 output = ~59,898 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 12 |
| **TOTAL** | **4** | **1** | **2** | **1** | **1** | **1** | **12** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_6 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_5585 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 1 |
| Unique Properties | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 12 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 12

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2019.105880 | 1 | 12 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2019.105880 | PROPblock_12 | declared | 12 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 353 | KEEP | 353 | 4.4 |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_6', 'GLOBcomp_1'], limit=50, p… | 1,165 | KEEP | 1150 | 11.7 |
| 3 | 1 | `L1_query` | context=Known property IDs: GLOBprop_…, id_catalog… | 9,809 | — | — | 68.1 |
| | | **TOTAL (3 tools)** | | **11,327** | | **1,503** | **84.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,614 | 3,614 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 1,063 | 10,668 | 1,534 | 8.9 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,242 | 21,885 | 681 | 6.2 |
| 3 | L1-worker | claudeopus46 | 2,065 | 488 | 2,553 | 582 | 4.3 |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,066 | 22,709 | 967 | 6.4 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,825 | 23,468 | 695 | 5.5 |
| 6 | L1-worker | claudeopus46 | 2,065 | 2,561 | 4,626 | 1,586 | 11.2 |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,909 | 25,519 | 378 | 3.6 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,156 | 24,799 | 2,358 | 15.0 |
| 9 | L1-worker | claudeopus46 | 536 | 1,830 | 2,366 | 789 | 4.8 |
| 10 | L1-worker | claudeopus46 | 1,323 | 6,584 | 7,907 | 744 | 4.9 |
| 11 | L1-worker | claudeopus46 | 1,356 | 1,950 | 3,306 | 866 | 4.9 |
| 12 | L1-worker | claudeopus46 | 298 | 1,466 | 1,764 | 562 | 3.5 |
| 13 | L1-worker | claudeopus46 | 747 | 15,061 | 15,808 | 588 | 6.2 |
| 14 | L0-main | claudeopus46 | 9,605 | 21,465 | 31,070 | 2,634 | 18.4 |
| 15 | L0-main | claudeopus46 | 1,356 | 2,489 | 3,845 | 1,005 | 5.8 |
| 16 | L0-main | claudeopus46 | 1,323 | 15,005 | 16,328 | 1,410 | 11.1 |
| 17 | L0-main | claudeopus46 | 298 | 2,078 | 2,376 | 1,218 | 4.6 |


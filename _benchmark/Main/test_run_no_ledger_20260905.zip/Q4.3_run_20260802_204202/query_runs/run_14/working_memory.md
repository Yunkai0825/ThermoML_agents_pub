# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_6 | propan-2-ol | propan-2-ol |
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find viscosity measurements for isopropanol (2-propanol, CAS 67-63-0) + water (CAS 7732-18-5) binary mixtures at room te → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "**Viscosity of Isopropanol (Propan-2-ol) + Water Binary Mixtures at Room Temperature**\n\n**Compound IDs resolved:**\n- Propan-2-ol (isopropanol, CAS 67-63-0) → GLOBcomp_6\n- Water (CAS 7732-18-5) → GLOBcomp_1\n\n**Data found:** One data block contains dynamic viscosity measurements for the propan-2-ol + water binary system in the 293–298 K range.\n\n**Source:** DOI 10.1016/j.jct.2019.105880 (GLOBlit_5585), Block PROPblock_12\n\n**Measurement details:**\n- Property: Dynamic viscosity (Pa·s) — GLOBprop_4\n- Method: Falling/rolling sphere viscometry (GLOBmeas_8)\n- Pressure: 100.0 kPa (fixed constraint)\n- Variables: Temperature (K) and mass fraction of propan-2-ol\n- Total data points in block: 12 (full range 288–303 K); 6 points fall within 293–298 K\n\n**Dynamic viscosity values at 293–298 K:**\n\n| T (K) | w(propan-2-ol) | η (Pa·s) | Uncertainty (Pa·s) |\n|--------|----------------|-----------|---------------------|\n| 293.15 | 0.10 | 0.001633 | ±0.000129 |\n| 293.15 | 0.20 | 0.002485 | ±0.000169 |\n| 293.15 | 0.30 | 0.003172 | ±0.000206 |\n| 298.15 | 0.10 | 0.001395 | ±0.000105 |\n| 298.15 | 0.20 | 0.002045 | ±0.000137 |\n| 298.15 | 0.30 | 0.002555 | ±0.000164 |\n\n**Chemistry insight:** The data show the expected trends: viscosity increases with increasing propan-2-ol mass fraction (at these low-to-moderate concentrations, the hydrogen-bonding network between water and isopropanol enhances intermolecular interactions), and viscosity decreases with increasing temperature due to greater thermal motion disrupting these interactions. The composition range covered (w = 0.1–0.3) captures the lower portion of the well-known viscosity maximum that the isopropanol–water system exhibits near w ≈ 0.5–0.6.\n\nNo kinematic viscosity (GLOBprop_40) data were found for this binary system in the 293–298 K range.",
  "core_claims": [
    "Dynamic viscosity data for the propan-2-ol (isopropanol) + water binary system at 100 kPa were found in the 293–298 K range (DOI 10.1016/j.jct.2019.105880), covering propan-2-ol mass fractions of 0.10, 0.20, and 0.30, with viscosity values ranging from approximately 0.001395 to 0.003172 Pa·s.",
    "Within this composition and temperature range, viscosity increases with increasing propan-2-ol mass fraction and decreases with increasing temperature, consistent with enhanced hydrogen-bonding interactions at higher alcohol content and greater thermal disruption at higher temperatures.",
    "The composition range covered (w = 0.1–0.3) captures only the lower portion of the well-known viscosity maximum that the isopropanol–water system exhibits near w ≈ 0.5–0.6.",
    "No kinematic viscosity data were found for this binary system in the 293–298 K range."
  ],
  "status": "success",
  "summary": "Dynamic viscosity of propan-2-ol (isopropanol, GLOBcomp_6) + water (GLOBcomp_1) binary mixtures was reported from DOI 10.1016/j.jct.2019.105880 (GLOBlit_5585), data block PROPblock_12, measured by falling/rolling sphere viscometry (GLOBmeas_8) at 100.0 kPa. Six data points fall within the 293–298 K range, covering propan-2-ol mass fractions of 0.10, 0.20, and 0.30. At 293.15 K, viscosities are 0.001633, 0.002485, and 0.003172 Pa·s respectively; at 298.15 K, they are 0.001395, 0.002045, and 0.002555 Pa·s. Viscosity increases with propan-2-ol mass fraction and decreases with temperature. The composition range captures the lower portion of the known viscosity maximum for this system. No kinematic viscosity data were found for this binary system in the 293–298 K range.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_6",
      "registry_id": "propan-2-ol",
      "name": "propan-2-ol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_5585",
      "block_number": "PROPblock_12",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_1",
        "GLOBcomp_6"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) measurements for propan-2-ol + water binary mixture at 293.15 K and 298.15 K, mass fractions 0.1–0.3, pressure 100.0 kPa, measured by falling/rolling sphere viscometry (GLOBmeas_8). DOI 10.1016/j.jct.2019.105880.",
      "doi": "10.1016/j.jct.2019.105880",
      "lit_id": "2019-meh-haj-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 12,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 288.15,
            "max": 303.15,
            "n_unique": 4
          },
          "range_min": 288.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_3",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.1,
            "max": 0.3,
            "n_unique": 3
          },
          "range_min": 0.1,
          "range_max": 0.3
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.001208,
            "max": 0.004014,
            "mean": 0.002279,
            "std": 0.000823,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.001208,
          "range_max": 0.004014
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


# Delegated query run — result

**Question:** Find viscosity data for isopropanol (2-propanol) mixed with water at room temperature (around 293-298 K or 20-25 degrees Celsius). Rubbing alcohol is typically isopropanol. Search for binary mixture viscosity measurements.

**Iterations:** 2  |  **Elapsed:** 95.7s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Viscosity of Isopropanol (2-Propanol) + Water Binary Mixtures at Room Temperature

### Data Source
Dynamic viscosity measurements for the **propan-2-ol (isopropanol) + water** binary system were found in the ThermoML database from:

- **DOI:** 10.1016/j.jct.2019.105880
- **Data block:** PROPblock_12 (12 total data points spanning 288–303 K)

### Measurement Details
- **Property:** Dynamic viscosity (Pa·s)
- **Method:** Falling/rolling sphere viscometry
- **Pressure:** 100.0 kPa (fixed)
- **Composition variable:** Mass fraction of propan-2-ol
- **Phase:** Liquid

### Viscosity Values at Room Temperature (293–298 K)

Six data points fall within the requested 293–298 K (20–25 °C) range:

| Temperature (K) | Mass fraction of isopropanol | Dynamic viscosity (Pa·s) | Uncertainty (Pa·s, 95% CI) |
|:---:|:---:|:---:|:---:|
| 293.15 | 0.10 | 0.001633 | ±0.000129 |
| 293.15 | 0.20 | 0.002485 | ±0.000169 |
| 293.15 | 0.30 | 0.003172 | ±0.000206 |
| 298.15 | 0.10 | 0.001395 | ±0.000105 |
| 298.15 | 0.20 | 0.002045 | ±0.000137 |
| 298.15 | 0.30 | 0.002555 | ±0.000164 |

Over the full block temperature range (288–303 K), viscosity values span from **0.001208 to 0.004014 Pa·s**.

### Chemistry Insight

The data reveal two expected trends for this classic binary system:

1. **Viscosity increases with isopropanol content** — at these low-to-moderate concentrations (w = 0.10–0.30), adding isopropanol strengthens the hydrogen-bonding network between water and alcohol molecules, enhancing intermolecular friction. For example, at 293.15 K, tripling the mass fraction from 0.10 to 0.30 nearly doubles the viscosity (from ~1.6 to ~3.2 mPa·s).

2. **Viscosity decreases with increasing temperature** — greater thermal energy disrupts hydrogen bonds and increases molecular mobility. At w = 0.20, raising the temperature from 293.15 K to 298.15 K reduces viscosity by about 18% (from 2.485 to 2.045 mPa·s).

The composition range covered here (w = 0.1–0.3) captures only the **lower portion** of the well-known viscosity maximum that the isopropanol–water system exhibits near w ≈ 0.5–0.6, where the extensive three-dimensional hydrogen-bonding network reaches its greatest structural complexity.

### What Was Not Found
No **kinematic viscosity** data were found for this binary system in the 293–298 K range in the ThermoML database.

### Core claims

- Dynamic viscosity data for the propan-2-ol (isopropanol) + water binary system at 100 kPa and 293–298 K, measured by falling/rolling sphere viscometry (DOI: 10.1016/j.jct.2019.105880), show values ranging from approximately 0.001395 to 0.003172 Pa·s over mass fractions of isopropanol from 0.10 to 0.30.
- At these compositions (w = 0.10–0.30), viscosity increases with increasing isopropanol mass fraction at a given temperature; for example, at 293.15 K, viscosity nearly doubles from ~1.6 to ~3.2 mPa·s as the mass fraction triples from 0.10 to 0.30.
- Viscosity decreases with increasing temperature; at w = 0.20, raising temperature from 293.15 K to 298.15 K reduces viscosity by about 18%.
- The composition range covered (w = 0.10–0.30) captures only the lower portion of the well-known viscosity maximum that the isopropanol–water system exhibits near w ≈ 0.5–0.6.
- No kinematic viscosity data were found for this binary system in the 293–298 K range in the ThermoML database.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5585 | 10.1016/j.jct.2019.105880 | PROPblock_12 |  | Dynamic viscosity (Pa·s) measurements for propan-2-ol + water binary mixture at 288–303 K (6 points in 293–298 K range), mass fractions 0.10–0.30, pressure 100.0 kPa, measured by falling/rolling sphere viscometry (GLOBmeas_8). 12 total data points. |

### Suggested follow-ups

- Search for viscosity data at higher isopropanol mass fractions (w = 0.4–0.9) to capture the well-known viscosity maximum near w ≈ 0.5–0.6 for the isopropanol–water system.
- Search for kinematic viscosity (GLOBprop_40) data for isopropanol + water in other temperature ranges or from other literature sources in ThermoML.
- Look for density data (GLOBprop_1) for the same system and conditions to enable conversion between dynamic and kinematic viscosity.
- Search for viscosity data of other common rubbing alcohol formulations, such as ethanol (GLOBcomp_2) + water mixtures, for comparison.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_6",
    "registry_id": "propan-2-ol",
    "name": "propan-2-ol"
  }
]
```

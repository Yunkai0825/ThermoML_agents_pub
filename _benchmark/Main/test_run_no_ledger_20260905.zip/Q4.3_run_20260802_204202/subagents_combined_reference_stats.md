# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 5 | 22,187 | 42,100 | 7,801 | 64,287 | 12,857 | 48.8 | claudeopus46 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| L1-worker | 12 | 111,572 | 45,138 | 10,796 | 156,710 | 13,059 | 76.5 | claudeopus46 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| **TOTAL** | **17** | **133,759** | **87,238** | **18,597** | **220,997** | **25,916** | **125.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 12 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| **TOTAL** | **4** | **1** | **2** | **1** | **1** | **1** | **12** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_6 |  | resolve_compound_ids, search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_5585 |  | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 | Temperature, K | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| GLOBvar_5 | Mass fraction | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 | Pressure, kPa | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Unique References | 1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Unique Properties | 1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Unique Measurements | 1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Unique Phases | 1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Unique Variables | 2 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Unique Constraints | 1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Unique parent blocks | 1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Explicit block/subsystem targets | 1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Subsystem targets | 0 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| Target-matched data points | 12 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| **TOTAL** | **23** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2019.105880 | 1 | 12 | binary | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | --- | --- | --- |
| 10.1016/j.jct.2019.105880 | PROPblock_12 | declared | 12 | binary | — | search_blocks | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 353 | KEEP | 353 | 4.4 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_6', 'GLOBcomp_1'], limit=50, p… | 1,165 | KEEP | 1150 | 11.7 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 3 | 1 | `L1_query` | context=Known property IDs: GLOBprop_…, id_catalog… | 9,809 | — | — | 68.1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| **TOTAL** | **5** |  |  | **11,327** |  | **1,503** | **84.2** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,614 | 3,614 | 0 | 0.0% | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 1,063 | 10,668 | 1,534 | 8.9 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,242 | 21,885 | 681 | 6.2 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 3 | L1-worker | claudeopus46 | 2,065 | 488 | 2,553 | 582 | 4.3 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 4 | L1-worker | claudeopus46 | 20,643 | 2,066 | 22,709 | 967 | 6.4 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,825 | 23,468 | 695 | 5.5 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 6 | L1-worker | claudeopus46 | 2,065 | 2,561 | 4,626 | 1,586 | 11.2 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,909 | 25,519 | 378 | 3.6 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,156 | 24,799 | 2,358 | 15.0 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 9 | L1-worker | claudeopus46 | 536 | 1,830 | 2,366 | 789 | 4.8 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 10 | L1-worker | claudeopus46 | 1,323 | 6,584 | 7,907 | 744 | 4.9 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 11 | L1-worker | claudeopus46 | 1,356 | 1,950 | 3,306 | 866 | 4.9 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 12 | L1-worker | claudeopus46 | 298 | 1,466 | 1,764 | 562 | 3.5 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 13 | L1-worker | claudeopus46 | 747 | 15,061 | 15,808 | 588 | 6.2 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 14 | L0-main | claudeopus46 | 9,605 | 21,465 | 31,070 | 2,634 | 18.4 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 15 | L0-main | claudeopus46 | 1,356 | 2,489 | 3,845 | 1,005 | 5.8 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 16 | L0-main | claudeopus46 | 1,323 | 15,005 | 16,328 | 1,410 | 11.1 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |
| 17 | L0-main | claudeopus46 | 298 | 2,078 | 2,376 | 1,218 | 4.6 | Find viscosity data for isopropanol (2-propanol) mixed with  (query_runs/run_14) |

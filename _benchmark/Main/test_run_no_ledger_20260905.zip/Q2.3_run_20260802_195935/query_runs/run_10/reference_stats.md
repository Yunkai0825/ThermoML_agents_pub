# Reference Stats — query-agent

**Run started:** 2026-08-02 19:59:46
**Wall time (at last flush):** 485.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 32,090 | 90,871 | 14,249 | 122,961 | 17,565 | 79.8 | claudeopus46 |
| L1-worker | 32 | 309,154 | 164,016 | 75,122 | 473,170 | 14,786 | 431.7 | claudeopus46 |
| **TOTAL** | **39** | **341,244** | **254,887** | **89,371** | **596,131** | **15,285** | **511.5** | |

**Estimated tokens:** ~149,032 input + ~22,342 output = ~171,374 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 2 | 7 | 7 | 302 |
| **TOTAL** | **6** | **1** | **5** | **2** | **7** | **7** | **302** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### References (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2656 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_6951 |  | search_blocks |
| GLOBlit_8038 |  | search_blocks |
| GLOBlit_8106 |  | search_blocks |
| GLOBlit_11186 |  | search_blocks |
| GLOBlit_11506 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_227 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Variables | 3 |
| Unique References | 7 |
| Unique Properties | 1 |
| Unique Measurements | 6 |
| Unique Phases | 1 |
| Unique Constraints | 2 |
| Total DOIs | 7 |
| Unique parent blocks | 7 |
| Explicit block/subsystem targets | 7 |
| Subsystem targets | 0 |
| Target-matched data points | 302 |

---

## 3. DOI & Block References

**Unique DOIs:** 7  |  **Parent blocks:** 7  |  **Explicit targets:** 7  |  **Subsystems:** 0  |  **Target-matched datapoints:** 302

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.01.011 | 1 | 10 | binary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 84 | binary | search_blocks |
| 10.1021/acs.jced.6b00526 | 1 | 33 | binary | search_blocks |
| 10.1021/je020140j | 1 | 77 | binary | search_blocks |
| 10.1021/je025610o | 1 | 30 | binary | search_blocks |
| 10.1021/je800271e | 1 | 52 | binary | search_blocks |
| 10.1021/je9000697 | 1 | 16 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | — | search_blocks |
| 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | — | search_blocks |
| 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | — | search_blocks |
| 10.1021/je800271e | PROPblock_4 | declared | 52 | binary | — | search_blocks |
| 10.1021/je9000697 | PROPblock_1 | declared | 16 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 237 | KEEP | 237 | 4.2 |
| 2 | 1 | `L1_query` | context=User wants viscosity vs compo…, id_catalog… | 451 | — | — | 149.1 |
| 3 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 343 | KEEP | 343 | 4.6 |
| 4 | 4 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 248 | KEEP | 248 | 3.4 |
| 5 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 753 | DISCARD | 692 | 17.5 |
| 6 | 8 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_24'], limit=50, … | 1,491 | KEEP | 1366 | 15.7 |
| 7 | 2 | `L1_query` | context=This is a binary system searc…, id_catalog… | 22,442 | — | — | 263.7 |
| | | **TOTAL (7 tools)** | | **25,965** | | **2,886** | **458.2** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 905 | 10,510 | 1,515 | 9.2 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,408 | 22,051 | 729 | 5.1 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,758 | 23,401 | 12,836 | 65.3 |
| 4 | L1-worker | claudeopus46 | 2,065 | 472 | 2,537 | 451 | 3.9 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,934 | 23,577 | 7,253 | 41.6 |
| 6 | L1-worker | claudeopus46 | 20,643 | 10,808 | 31,451 | 2,701 | 13.3 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,465 | 3,821 | 800 | 4.6 |
| 8 | L1-worker | claudeopus46 | 536 | 2,345 | 2,881 | 903 | 6.9 |
| 9 | L1-worker | claudeopus46 | 1,323 | 4,941 | 6,264 | 1,417 | 7.8 |
| 10 | L1-worker | claudeopus46 | 298 | 1,182 | 1,480 | 788 | 3.4 |
| 11 | L1-worker | claudeopus46 | 298 | 1,259 | 1,557 | 890 | 3.9 |
| 12 | L1-worker | claudeopus46 | 298 | 2,139 | 2,437 | 1,006 | 5.2 |
| 13 | L1-worker | claudeopus46 | 1,160 | 6,714 | 7,874 | 1,007 | 5.5 |
| 14 | L0-main | claudeopus46 | 9,605 | 1,847 | 11,452 | 1,347 | 8.3 |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,183 | 21,826 | 655 | 5.2 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,459 | 23,102 | 9,059 | 47.2 |
| 17 | L1-worker | claudeopus46 | 2,065 | 456 | 2,521 | 557 | 4.5 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,743 | 23,386 | 8,732 | 51.1 |
| 19 | L1-worker | claudeopus46 | 20,643 | 3,595 | 24,238 | 1,203 | 7.7 |
| 20 | L1-worker | claudeopus46 | 2,065 | 513 | 2,578 | 392 | 3.3 |
| 21 | L1-worker | claudeopus46 | 20,643 | 3,894 | 24,537 | 1,281 | 9.1 |
| 22 | L1-worker | claudeopus46 | 20,643 | 4,810 | 25,453 | 1,053 | 8.0 |
| 23 | L1-worker | claudeopus46 | 20,643 | 5,645 | 26,288 | 1,209 | 8.4 |
| 24 | L1-worker | claudeopus46 | 2,065 | 1,126 | 3,191 | 1,153 | 7.7 |
| 25 | L1-worker | claudeopus46 | 20,643 | 5,947 | 26,590 | 713 | 5.4 |
| 26 | L1-worker | claudeopus46 | 2,065 | 10,316 | 12,381 | 1,720 | 15.1 |
| 27 | L1-worker | claudeopus46 | 20,643 | 7,956 | 28,599 | 7,441 | 42.7 |
| 28 | L1-worker | claudeopus46 | 20,643 | 15,972 | 36,615 | 2,767 | 12.5 |
| 29 | L1-worker | claudeopus46 | 1,356 | 2,898 | 4,254 | 850 | 4.7 |
| 30 | L1-worker | claudeopus46 | 536 | 2,778 | 3,314 | 814 | 6.0 |
| 31 | L1-worker | claudeopus46 | 298 | 1,232 | 1,530 | 838 | 3.4 |
| 32 | L1-worker | claudeopus46 | 1,323 | 13,775 | 15,098 | 1,627 | 8.5 |
| 33 | L1-worker | claudeopus46 | 298 | 2,349 | 2,647 | 1,247 | 5.7 |
| 34 | L1-worker | claudeopus46 | 747 | 34,944 | 35,691 | 1,030 | 9.0 |
| 35 | L0-main | claudeopus46 | 9,605 | 47,494 | 57,099 | 3,901 | 25.5 |
| 36 | L0-main | claudeopus46 | 1,356 | 3,788 | 5,144 | 766 | 4.7 |
| 37 | L0-main | claudeopus46 | 298 | 1,148 | 1,446 | 754 | 3.1 |
| 38 | L0-main | claudeopus46 | 1,323 | 31,703 | 33,026 | 3,318 | 18.2 |
| 39 | L0-main | claudeopus46 | 298 | 3,986 | 4,284 | 2,648 | 10.8 |


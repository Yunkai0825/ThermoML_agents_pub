# Delegated query run — result

**Question:** Find viscosity data for the binary mixture of water + ethylene glycol at 30°C (303.15 K). I need viscosity as a function of composition (mole fraction) across the full composition range.

**Iterations:** 3  |  **Elapsed:** 456.4s  |  **Tools:** 2  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity of Water + Ethylene Glycol at 303.15 K (30 °C)

Three independent experimental datasets were found in the ThermoML database for the dynamic viscosity of the binary liquid system **water + 1,2-ethanediol (ethylene glycol)** at **303.15 K** and approximately atmospheric pressure, covering the full mole-fraction range.

---

### Dataset 1 — Most Comprehensive (21 points)
**DOI:** 10.1016/j.jct.2018.02.022  
**Method:** Concentric cylinders viscometry  
**Pressure:** 92.3 kPa  
**Composition variable:** mole fraction of ethylene glycol, x(EG)

| x(EG) | η (Pa·s) | η (mPa·s) |
|--------|-----------|------------|
| 0.0000 | 0.000798 | 0.798 |
| 0.0500 | 0.001020 | 1.020 |
| 0.1000 | 0.001340 | 1.340 |
| 0.1500 | 0.001770 | 1.770 |
| 0.2000 | 0.002310 | 2.310 |
| 0.2500 | 0.002930 | 2.930 |
| 0.3000 | 0.003590 | 3.590 |
| 0.3500 | 0.004260 | 4.260 |
| 0.4000 | 0.004910 | 4.910 |
| 0.4500 | 0.005520 | 5.520 |
| 0.5000 | 0.006090 | 6.090 |
| 0.5500 | 0.006620 | 6.620 |
| 0.6000 | 0.007110 | 7.110 |
| 0.6500 | 0.007570 | 7.570 |
| 0.7000 | 0.008010 | 8.010 |
| 0.7500 | 0.008440 | 8.440 |
| 0.8000 | 0.008870 | 8.870 |
| 0.8500 | 0.009310 | 9.310 |
| 0.9000 | 0.009780 | 9.780 |
| 0.9500 | 0.010300 | 10.300 |
| 1.0000 | 0.010900 | 10.900 |

---

### Dataset 2 — 11 points (composition as water mole fraction)
**DOI:** 10.1021/acs.jced.6b00526  
**Method:** Falling/rolling sphere viscometry  
**Pressure:** 100.0 kPa  
**Composition variable:** mole fraction of **water**, x(H₂O)

| x(H₂O) | x(EG) | η (Pa·s) | η (mPa·s) |
|---------|--------|-----------|------------|
| 0.0000 | 1.0000 | 0.01090 | 10.90 |
| 0.1000 | 0.9000 | 0.01020 | 10.20 |
| 0.2000 | 0.8000 | 0.00938 | 9.38 |
| 0.3000 | 0.7000 | 0.00848 | 8.48 |
| 0.4000 | 0.6000 | 0.00746 | 7.46 |
| 0.5000 | 0.5000 | 0.00633 | 6.33 |
| 0.6000 | 0.4000 | 0.00510 | 5.10 |
| 0.7000 | 0.3000 | 0.00387 | 3.87 |
| 0.8000 | 0.2000 | 0.00271 | 2.71 |
| 0.9000 | 0.1000 | 0.00166 | 1.66 |
| 1.0000 | 0.0000 | 0.000798 | 0.798 |

---

### Dataset 3 — 11 points
**DOI:** 10.1021/je020140j  
**Method:** Capillary tube viscometry  
**Pressure:** 101.0 kPa  
**Composition variable:** mole fraction of ethylene glycol, x(EG)

| x(EG) | η (Pa·s) | η (mPa·s) |
|--------|-----------|------------|
| 0.0000 | 0.000797 | 0.797 |
| 0.1000 | 0.001350 | 1.350 |
| 0.2000 | 0.002350 | 2.350 |
| 0.3000 | 0.003670 | 3.670 |
| 0.4000 | 0.005020 | 5.020 |
| 0.5000 | 0.006230 | 6.230 |
| 0.6000 | 0.007220 | 7.220 |
| 0.7000 | 0.008070 | 8.070 |
| 0.8000 | 0.008870 | 8.870 |
| 0.9000 | 0.009730 | 9.730 |
| 1.0000 | 0.010900 | 10.900 |

---

### Key Observations

- **Range:** Viscosity increases monotonically from **~0.80 mPa·s** (pure water) to **~10.9 mPa·s** (pure ethylene glycol) — roughly a **14-fold increase**.

- **Nonlinear behavior:** The viscosity–composition curve is strongly nonlinear and concave. The steepest rise occurs in the water-rich region (x(EG) < 0.3), where adding ethylene glycol disrupts water's three-dimensional hydrogen-bond network. The larger diol molecule bridges between water molecules, forming new, stronger H-bond clusters that impede flow.

- **Consistency across sources:** The three independent datasets, obtained by three different measurement techniques (concentric cylinders, falling sphere, and capillary tube), agree within approximately **2%** at equimolar composition (η ≈ 6.1–6.3 mPa·s at x(EG) = 0.5), confirming high reliability.

- **Practical note:** The most detailed dataset (DOI 10.1016/j.jct.2018.02.022) provides 21 evenly spaced points at Δx = 0.05 intervals, making it ideal for interpolation or model fitting.

### Core claims

- At 303.15 K and approximately atmospheric pressure, the dynamic viscosity of water + ethylene glycol mixtures increases monotonically from ~0.80 mPa·s (pure water) to ~10.9 mPa·s (pure ethylene glycol), representing roughly a 14-fold increase across the full mole-fraction range.
- The viscosity–composition relationship is strongly nonlinear and concave, with the steepest increase occurring in the water-rich region (ethylene glycol mole fraction < 0.3).
- Three independent ThermoML datasets obtained by different measurement techniques (concentric cylinders, falling sphere, and capillary tube viscometry) agree within approximately 2% at equimolar composition (~6.1–6.3 mPa·s), confirming high reliability of the reported values.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Dynamic viscosity (Pa·s) of binary water + ethylene glycol at 303.15 K, 21 mole-fraction points (x(EG) 0–1 at 0.05 intervals). Concentric cylinders method. |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 |  | Dynamic viscosity (Pa·s) of binary water + ethylene glycol at 303.15 K, 11 mole-fraction points (composition expressed as x(water) 0–1 at 0.10 intervals). Falling/rolling sphere method. |
| GLOBlit_8038 | 10.1021/je020140j | PROPblock_5 |  | Dynamic viscosity (Pa·s) of binary water + ethylene glycol at 303.15 K, 11 mole-fraction points (x(EG) 0–1 at 0.10 intervals). Capillary tube method. |

### Suggested follow-ups

- Retrieve excess viscosity or viscosity deviation data for water + ethylene glycol at 303.15 K to quantify non-ideal mixing behavior.
- Search for density data (GLOBprop_3) for the same binary system at 303.15 K to enable conversion between dynamic and kinematic viscosity.
- Query viscosity data at additional temperatures (e.g., 293.15 K, 313.15 K, 323.15 K) to construct viscosity–temperature correlations for this system.
- Look for Redlich-Kister or other correlation parameters fitted to viscosity deviation data for water + ethylene glycol mixtures.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_24",
    "registry_id": "LYCAIKOWRPUZTN-UHFFFAOYSA-N",
    "name": "1,2-ethanediol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction",
    "name": "Mole fraction"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_11",
    "registry_id": "concentric_cylinders_viscometry",
    "name": "Concentric cylinders viscometry"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_8",
    "registry_id": "falling_or_rolling_sphere_viscometry",
    "name": "Falling or rolling sphere viscometry"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_227",
    "registry_id": "captub_ufactor_3",
    "name": "CAPTUB:UFactor:3"
  }
]
```

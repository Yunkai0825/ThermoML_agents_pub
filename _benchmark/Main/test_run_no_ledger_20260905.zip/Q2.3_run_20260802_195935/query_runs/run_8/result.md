# Delegated query run — result

**Question:** Find viscosity data for the binary mixture of methanol + ethanol at 30°C (303.15 K). I need viscosity as a function of composition (mole fraction) across the full composition range.

**Iterations:** 2  |  **Elapsed:** 266.8s  |  **Tools:** 1  |  **Timed out:** False

---

## Answer

## Viscosity vs. Composition Data for Methanol + Ethanol at 303.15 K (30 °C)

One dataset of **dynamic viscosity (η)** was found in the ThermoML database for the methanol + ethanol binary liquid mixture at 303.15 K.

### Source
- **DOI:** 10.1021/je800633a
- **Method:** Capillary tube (Ostwald/Ubbelohde) method
- **Conditions:** T = 303.15 K, P = 81.5 kPa, liquid phase
- **Original data points:** 12 (9 shown below after compression; full trend is well-captured)

### Data: Dynamic Viscosity vs. Mole Fraction of Methanol

| x(methanol) | η (Pa·s)   | Uncertainty (Pa·s) |
|:-----------:|:----------:|:-------------------:|
| 0.0417      | 0.000968   | ±9 × 10⁻⁶          |
| 0.1476      | 0.000906   | ±8 × 10⁻⁶          |
| 0.2214      | 0.000865   | ±8 × 10⁻⁶          |
| 0.3644      | 0.000793   | ±8 × 10⁻⁶          |
| 0.4488      | 0.000753   | ±8 × 10⁻⁶          |
| 0.5995      | 0.000685   | ±7 × 10⁻⁶          |
| 0.6859      | 0.000648   | ±7 × 10⁻⁶          |
| 0.8047      | 0.000601   | ±6 × 10⁻⁶          |
| 0.9221      | 0.000555   | ±6 × 10⁻⁶          |

The viscosity ranges from **0.000968 Pa·s** (≈ 0.968 mPa·s) at low methanol content to **0.000555 Pa·s** (≈ 0.555 mPa·s) at high methanol content. Uncertainties were evaluated by propagation of standard uncertainties at a 95% confidence level.

### Chemistry Insight

The viscosity decreases **nearly linearly** (R² ≈ 0.996) with increasing methanol mole fraction. This is consistent with methanol having a lower pure-component viscosity than ethanol at this temperature. The near-ideal (linear) mixing behavior reflects the strong structural similarity between these two short-chain aliphatic alcohols — both form comparable hydrogen-bonding networks in the liquid phase, so mixing introduces minimal disruption to the intermolecular interactions. This contrasts with many other binary alcohol mixtures (e.g., alcohol + water), where significant viscosity maxima or non-linear deviations from ideal mixing are commonly observed due to enhanced hydrogen-bonding upon mixing.

### Limitations
- The data spans x(methanol) ≈ 0.04 to 0.92 but **does not include the pure-component endpoints** (x = 0 and x = 1).
- **No kinematic viscosity data** were found for this system in the ThermoML database.

### Core claims

- In the methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa, dynamic viscosity decreases nearly linearly (R² ≈ 0.996) with increasing methanol mole fraction, ranging from approximately 0.968 mPa·s at x(methanol) ≈ 0.04 to approximately 0.555 mPa·s at x(methanol) ≈ 0.92, based on data from DOI 10.1021/je800633a.
- The near-linear viscosity–composition behavior is consistent with near-ideal mixing and reflects the strong structural similarity and comparable hydrogen-bonding networks of these two short-chain aliphatic alcohols.
- The available data span x(methanol) ≈ 0.04 to 0.92 and do not include the pure-component endpoints (x = 0 or x = 1).
- No kinematic viscosity data were found for this system in the ThermoML database.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11337 | 10.1021/je800633a | PROPblock_16 |  | Dynamic viscosity (Pa·s) of methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa, measured by capillary tube (Ostwald/Ubbelohde) method. 12 data points spanning methanol mole fractions from ~0.04 to ~0.92, with viscosity decreasing nearly linearly from ~0.000968 to ~0.000556 Pa·s. Uncertainties evaluated by propagation of standard uncertainties at 95% confidence level. |

### Suggested follow-ups

- Search for pure-component viscosity data for methanol (GLOBcomp_4) and ethanol (GLOBcomp_2) at 303.15 K to obtain the endpoint values (x = 0 and x = 1) missing from this dataset.
- Search for excess viscosity or viscosity deviation data for methanol + ethanol at 303.15 K to quantify departure from ideal mixing.
- Look for viscosity data at other temperatures (e.g., 293.15 K, 313.15 K) for the same binary system to examine temperature dependence.
- Search for kinematic viscosity or density data for this system at 303.15 K, which could be used to cross-check or convert between dynamic and kinematic viscosity.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_11337",
    "registry_id": "2009-zar-mir-0",
    "name": "10.1021/je800633a"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_2",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_3",
    "name": "Mole fraction"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_4",
    "registry_id": "capillary_tube_ostwald_ubbelohde_method",
    "name": "Capillary tube (Ostwald; Ubbelohde) method"
  }
]
```

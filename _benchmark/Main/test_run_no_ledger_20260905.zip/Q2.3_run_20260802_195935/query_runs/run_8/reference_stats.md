# Reference Stats — query-agent

**Run started:** 2026-08-02 19:59:46
**Wall time (at last flush):** 291.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 22,485 | 43,401 | 10,398 | 65,886 | 10,981 | 63.0 | claudeopus46 |
| L1-worker | 24 | 284,943 | 129,208 | 36,359 | 414,151 | 17,256 | 240.8 | claudeopus46 |
| **TOTAL** | **30** | **307,428** | **172,609** | **46,757** | **480,037** | **16,001** | **303.8** | |

**Estimated tokens:** ~120,009 input + ~11,689 output = ~131,698 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 12 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **4** | **3** | **3** | **2** | **1** | **1** | **12** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_4 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_blocks |
| GLOBprop_40 |  | resolve_property_ids |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids, search_blocks |

#### References (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_11337 |  | search_blocks |

#### Measurements (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 2 |
| Unique Variables | 2 |
| Unique References | 1 |
| Unique Measurements | 1 |
| Unique Phases | 1 |
| Unique Constraints | 2 |
| Total DOIs | 1 |
| Unique parent blocks | 1 |
| Explicit block/subsystem targets | 1 |
| Subsystem targets | 0 |
| Target-matched data points | 12 |

---

## 3. DOI & Block References

**Unique DOIs:** 1  |  **Parent blocks:** 1  |  **Explicit targets:** 1  |  **Subsystems:** 0  |  **Target-matched datapoints:** 12

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1021/je800633a | 1 | 12 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1021/je800633a | PROPblock_16 | declared | 12 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve methanol an… | 234 | KEEP | 234 | 3.9 |
| 2 | 1 | `resolve_property_ids` | limit=5, min_score=80, purpose=Confirm property ID… | 372 | KEEP | 372 | 4.7 |
| 3 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=80, purpo… | 248 | KEEP | 248 | 4.9 |
| 4 | 9 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS met',…, explanat… | 1,082 | DISCARD | 1021 | 12.7 |
| 5 | 10 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_2'], limit=50, p… | 1,170 | KEEP | 1138 | 17.8 |
| 6 | 10 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_2'], limit=50, p… | 884 | DISCARD | 826 | 8.1 |
| 7 | 1 | `L1_query` | context=Looking for viscosity measure…, id_catalog… | 9,604 | — | — | 241.6 |
| | | **TOTAL (7 tools)** | | **13,594** | | **3,839** | **293.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,227 | 3,227 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 6,747 | 6,747 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 890 | 10,495 | 1,371 | 7.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,273 | 21,916 | 9,485 | 49.1 |
| 3 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 406 | 3.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 601 | 4.6 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,540 | 23,183 | 1,442 | 10.2 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,435 | 24,078 | 882 | 5.9 |
| 7 | L1-worker | claudeopus46 | 2,065 | 514 | 2,579 | 392 | 4.8 |
| 8 | L1-worker | claudeopus46 | 20,610 | 4,522 | 25,132 | 415 | 3.3 |
| 9 | L1-worker | claudeopus46 | 20,643 | 3,769 | 24,412 | 1,438 | 10.5 |
| 10 | L1-worker | claudeopus46 | 20,643 | 4,674 | 25,317 | 1,149 | 8.6 |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,575 | 26,218 | 2,158 | 13.3 |
| 12 | L1-worker | claudeopus46 | 20,643 | 6,428 | 27,071 | 1,463 | 9.9 |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,219 | 27,862 | 1,544 | 12.6 |
| 14 | L1-worker | claudeopus46 | 20,643 | 8,133 | 28,776 | 2,366 | 15.8 |
| 15 | L1-worker | claudeopus46 | 2,065 | 1,164 | 3,229 | 1,850 | 10.5 |
| 16 | L1-worker | claudeopus46 | 20,610 | 8,192 | 28,802 | 610 | 4.7 |
| 17 | L1-worker | claudeopus46 | 20,643 | 7,439 | 28,082 | 1,303 | 7.7 |
| 18 | L1-worker | claudeopus46 | 2,065 | 2,315 | 4,380 | 1,534 | 10.4 |
| 19 | L1-worker | claudeopus46 | 2,065 | 531 | 2,596 | 1,114 | 7.6 |
| 20 | L1-worker | claudeopus46 | 20,643 | 10,249 | 30,892 | 2,395 | 15.4 |
| 21 | L1-worker | claudeopus46 | 1,356 | 1,799 | 3,155 | 699 | 5.7 |
| 22 | L1-worker | claudeopus46 | 1,323 | 18,491 | 19,814 | 937 | 6.3 |
| 23 | L1-worker | claudeopus46 | 536 | 1,679 | 2,215 | 744 | 6.3 |
| 24 | L1-worker | claudeopus46 | 298 | 1,659 | 1,957 | 703 | 5.3 |
| 25 | L1-worker | claudeopus46 | 747 | 26,732 | 27,479 | 729 | 8.7 |
| 26 | L0-main | claudeopus46 | 9,605 | 20,921 | 30,526 | 2,545 | 17.3 |
| 27 | L0-main | claudeopus46 | 1,356 | 2,423 | 3,779 | 777 | 8.4 |
| 28 | L0-main | claudeopus46 | 298 | 1,159 | 1,457 | 765 | 4.8 |
| 29 | L0-main | claudeopus46 | 1,323 | 14,606 | 15,929 | 2,734 | 15.4 |
| 30 | L0-main | claudeopus46 | 298 | 3,402 | 3,700 | 2,206 | 9.6 |


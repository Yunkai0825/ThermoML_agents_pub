# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_4 | methanol | methanol |
| comp | GLOBcomp_2 | ethanol | ethanol |
| prop | GLOBprop_4 | viscosity_pa_s | Viscosity, Pa*s |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|
| lit | GLOBlit_11337 | 2009-zar-mir-0 | 10.1021/je800633a |

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find experimental viscosity vs composition data for methanol + ethanol binary mixture at 303.15 K → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "**Viscosity vs. Composition Data for Methanol + Ethanol Binary Mixture at 303.15 K**\n\nOne dataset of **dynamic viscosity (η, Pa·s)** was found in the ThermoML database for the methanol (GLOBcomp_4) + ethanol (GLOBcomp_2) binary mixture at 303.15 K. No kinematic viscosity data was found for this system.\n\n**Source:** DOI 10.1021/je800633a (GLOBlit_11337), PROPblock_16  \n**Method:** Capillary tube method  \n**Phase:** Liquid  \n**Conditions:** T = 303.15 K, P = 81.5 kPa  \n**Variable:** Mole fraction of methanol (x₁)\n\n**Data points** (9 retained from 12 original via RDP compression):\n\n| x(methanol) | η (Pa·s) | Uncertainty (Pa·s) |\n|:-----------:|:---------:|:-------------------:|\n| 0.0417 | 0.000968 | ±9 × 10⁻⁶ |\n| 0.1476 | 0.000906 | ±8 × 10⁻⁶ |\n| 0.2214 | 0.000865 | ±8 × 10⁻⁶ |\n| 0.3644 | 0.000793 | ±8 × 10⁻⁶ |\n| 0.4488 | 0.000753 | ±8 × 10⁻⁶ |\n| 0.5995 | 0.000685 | ±7 × 10⁻⁶ |\n| 0.6859 | 0.000648 | ±7 × 10⁻⁶ |\n| 0.8047 | 0.000601 | ±6 × 10⁻⁶ |\n| 0.9221 | 0.000555 | ±6 × 10⁻⁶ |\n\n**Chemistry insight:** The viscosity decreases nearly linearly (R² ≈ 0.996) with increasing methanol mole fraction, consistent with the lower pure-component viscosity of methanol compared to ethanol. The near-ideal mixing behavior reflects the structural similarity of these two short-chain alcohols, which form similar hydrogen-bonding networks. The data spans x(methanol) ≈ 0.04 to 0.92 but does not include the pure-component endpoints (x = 0 and x = 1).\n\nNote: The original block contains 12 data points; the 9 shown here were retained after RDP compression during retrieval. Three intermediate points were omitted but the overall trend is well-captured.",
  "core_claims": [
    "For the methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa, dynamic viscosity decreases nearly linearly (R² ≈ 0.996) with increasing methanol mole fraction over the range x(methanol) ≈ 0.04 to 0.92, from about 0.000968 Pa·s to 0.000555 Pa·s.",
    "The near-linear decrease is consistent with methanol having a lower pure-component viscosity than ethanol and reflects near-ideal mixing behavior attributed to the structural similarity and comparable hydrogen-bonding networks of these two short-chain alcohols.",
    "The dataset does not include pure-component endpoints (x = 0 or x = 1), and no kinematic viscosity data were found for this system in the ThermoML database."
  ],
  "status": "success",
  "summary": "Dynamic viscosity (η, Pa·s) data for the methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa were found in the ThermoML database (DOI 10.1021/je800633a). Nine data points (RDP-compressed from 12) span methanol mole fractions from ~0.04 to ~0.92, with η decreasing nearly linearly from about 0.000968 to 0.000555 Pa·s as methanol content increases. Uncertainties are on the order of 6–9 × 10⁻⁶ Pa·s. The near-linear decrease is consistent with methanol's lower pure-component viscosity relative to ethanol and reflects near-ideal mixing due to the structural similarity of these short-chain alcohols. Pure-component endpoints (x = 0 and x = 1) are not included. No kinematic viscosity data were found for this system.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_11337",
      "registry_id": "2009-zar-mir-0",
      "name": "10.1021/je800633a"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_11337",
      "block_number": "PROPblock_16",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_4"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) of methanol + ethanol binary mixture at 303.15 K and 81.5 kPa, measured by capillary tube method in the liquid phase. Data spans methanol mole fractions from ~0.04 to ~0.92 with 12 data points (9 retained after RDP compression). Source DOI: 10.1021/je800633a.",
      "doi": "10.1021/je800633a",
      "lit_id": "2009-zar-mir-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 12,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 303.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 81.5,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0417,
            "max": 0.9166,
            "n_unique": 12
          },
          "range_min": 0.0417,
          "range_max": 0.9166
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000556,
            "max": 0.000968,
            "mean": 0.000744,
            "std": 0.000131,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000556,
          "range_max": 0.000968
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


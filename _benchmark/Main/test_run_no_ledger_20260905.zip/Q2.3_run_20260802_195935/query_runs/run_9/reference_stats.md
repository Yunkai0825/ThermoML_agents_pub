# Reference Stats — query-agent

**Run started:** 2026-08-02 19:59:46
**Wall time (at last flush):** 990.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 12 | 80,115 | 186,750 | 21,999 | 266,865 | 22,238 | 136.0 | claudeopus46 |
| L1-worker | 84 | 838,453 | 674,698 | 133,352 | 1,513,151 | 18,013 | 869.0 | claudeopus46 |
| **TOTAL** | **96** | **918,568** | **861,448** | **155,351** | **1,780,016** | **18,541** | **1005.0** | |

**Estimated tokens:** ~445,004 input + ~38,837 output = ~483,841 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 1 | 2 | 2 | 86 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| **TOTAL** | **23** | **3** | **3** | **1** | **7** | **2** | **86** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_15 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_7696 |  | resolve_compound_ids |
| GLOBcomp_18 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_133 |  | resolve_compound_ids |
| GLOBcomp_8423 |  | resolve_compound_ids |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_blocks |
| GLOBprop_40 |  | resolve_property_ids |

#### References (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_4124 |  | search_blocks |
| GLOBlit_7481 |  | block_search_adv, search_blocks |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 5 |
| Unique Properties | 2 |
| Unique References | 2 |
| Unique Measurements | 2 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 2 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 86 |

---

## 3. DOI & Block References

**Unique DOIs:** 2  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 86

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2014.02.019 | 1 | 20 | binary | search_blocks |
| 10.1021/acs.jced.8b00176 | 1 | 66 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2014.02.019 | PROPblock_6 | declared | 20 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00176 | PROPblock_18 | declared | 66 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 358 | KEEP | 358 | 6.5 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Confirm property ID… | 381 | KEEP | 381 | 4.6 |
| 3 | 1 | `L1_query` | context=User needs viscosity vs compo…, id_catalog… | 815 | — | — | 149.4 |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 245 | KEEP | 245 | 4.3 |
| 5 | 2 | `L1_query` | context=Known property IDs: GLOBprop_…, id_catalog… | 667 | — | — | 103.1 |
| 6 | 3 | `memory_catalog_add` | global_id=GLOBprop_4, name=Dynamic viscosity (Pa·s… | 2 | — | — | 0.0 |
| 7 | 3 | `memory_catalog_add` | global_id=GLOBprop_40, name=Kinematic viscosity (m… | 2 | — | — | 0.0 |
| 8 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve global com… | 280 | KEEP | 280 | 5.2 |
| 9 | 4 | `L1_query` | context=User needs viscosity vs compo…, id_catalog… | 978 | — | — | 112.7 |
| 10 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 230 | KEEP | 230 | 4.0 |
| 11 | 5 | `L1_query` | context=We need compound IDs before s…, id_catalog… | 1,373 | — | — | 24.5 |
| 12 | 1 | `search_blocks` | compound=['GLOBcomp_15', 'GLOBcomp_18'], limit=50,… | 1,333 | KEEP | 1333 | 15.2 |
| 13 | 1 | `search_blocks` | compound=['GLOBcomp_15', 'GLOBcomp_18'], limit=50,… | 772 | DISCARD | 714 | 14.4 |
| 14 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 840 | KEEP | 810 | 21.6 |
| 15 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 737 | KEEP | 722 | 23.4 |
| 16 | 6 | `L1_query` | context=We have confirmed GLOBcomp_15…, id_catalog… | 16,686 | — | — | 224.2 |
| 17 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 1,062 | KEEP | 1047 | 18.5 |
| 18 | 9 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 731 | DISCARD | 670 | 23.1 |
| 19 | 11 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 654 | DISCARD | 578 | 17.4 |
| 20 | 7 | `L1_query` | context=PROPblock_18 in GLOBlit_7481 …, id_catalog… | 9,581 | — | — | 250.8 |
| | | **TOTAL (20 tools)** | | **37,727** | | **7,368** | **1022.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 7,160 | 7,160 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 6,830 | 6,830 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 932 | 10,537 | 1,595 | 9.0 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,289 | 21,932 | 928 | 6.6 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,945 | 23,588 | 11,617 | 63.3 |
| 4 | L1-worker | claudeopus46 | 2,065 | 745 | 2,810 | 719 | 5.3 |
| 5 | L1-worker | claudeopus46 | 2,065 | 473 | 2,538 | 583 | 4.6 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,673 | 24,316 | 6,775 | 38.4 |
| 7 | L1-worker | claudeopus46 | 20,643 | 11,069 | 31,712 | 1,387 | 5.8 |
| 8 | L1-worker | claudeopus46 | 1,356 | 1,518 | 2,874 | 702 | 3.7 |
| 9 | L1-worker | claudeopus46 | 536 | 1,398 | 1,934 | 549 | 3.8 |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,964 | 6,287 | 762 | 5.4 |
| 11 | L1-worker | claudeopus46 | 298 | 1,484 | 1,782 | 580 | 3.4 |
| 12 | L1-worker | claudeopus46 | 1,160 | 6,154 | 7,314 | 568 | 6.7 |
| 13 | L1-worker | claudeopus46 | 747 | 9,802 | 10,549 | 721 | 7.9 |
| 14 | L0-main | claudeopus46 | 9,605 | 2,243 | 11,848 | 1,451 | 10.7 |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,397 | 22,040 | 715 | 5.5 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,733 | 23,376 | 7,656 | 41.4 |
| 17 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 474 | 4.2 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,937 | 23,580 | 4,247 | 26.7 |
| 19 | L1-worker | claudeopus46 | 20,643 | 7,805 | 28,448 | 1,565 | 6.0 |
| 20 | L1-worker | claudeopus46 | 1,356 | 1,696 | 3,052 | 589 | 3.9 |
| 21 | L1-worker | claudeopus46 | 1,323 | 4,149 | 5,472 | 1,065 | 6.2 |
| 22 | L1-worker | claudeopus46 | 536 | 1,576 | 2,112 | 620 | 7.0 |
| 23 | L1-worker | claudeopus46 | 298 | 1,787 | 2,085 | 831 | 4.1 |
| 24 | L1-worker | claudeopus46 | 1,160 | 5,423 | 6,583 | 245 | 2.9 |
| 25 | L1-worker | claudeopus46 | 747 | 6,180 | 6,927 | 568 | 5.4 |
| 26 | L0-main | claudeopus46 | 9,605 | 3,458 | 13,063 | 841 | 6.1 |
| 27 | L0-main | claudeopus46 | 9,605 | 4,375 | 13,980 | 1,833 | 11.2 |
| 28 | L1-worker | claudeopus46 | 20,643 | 1,870 | 22,513 | 599 | 7.0 |
| 29 | L1-worker | claudeopus46 | 20,643 | 3,090 | 23,733 | 6,681 | 39.3 |
| 30 | L1-worker | claudeopus46 | 2,065 | 520 | 2,585 | 511 | 5.2 |
| 31 | L1-worker | claudeopus46 | 20,643 | 3,265 | 23,908 | 5,151 | 31.7 |
| 32 | L1-worker | claudeopus46 | 20,643 | 9,037 | 29,680 | 1,734 | 8.4 |
| 33 | L1-worker | claudeopus46 | 1,356 | 1,384 | 2,740 | 713 | 3.9 |
| 34 | L1-worker | claudeopus46 | 536 | 1,264 | 1,800 | 649 | 4.4 |
| 35 | L1-worker | claudeopus46 | 1,323 | 4,236 | 5,559 | 895 | 5.4 |
| 36 | L1-worker | claudeopus46 | 298 | 1,617 | 1,915 | 713 | 4.3 |
| 37 | L1-worker | claudeopus46 | 1,160 | 5,558 | 6,718 | 502 | 3.3 |
| 38 | L1-worker | claudeopus46 | 747 | 8,524 | 9,271 | 879 | 7.6 |
| 39 | L0-main | claudeopus46 | 9,605 | 5,889 | 15,494 | 1,328 | 9.4 |
| 40 | L1-worker | claudeopus46 | 20,643 | 1,157 | 21,800 | 559 | 5.2 |
| 41 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 461 | 3.9 |
| 42 | L1-worker | claudeopus46 | 20,643 | 1,845 | 22,488 | 379 | 3.6 |
| 43 | L1-worker | claudeopus46 | 1,356 | 510 | 1,866 | 317 | 2.8 |
| 44 | L1-worker | claudeopus46 | 536 | 390 | 926 | 252 | 2.8 |
| 45 | L1-worker | claudeopus46 | 1,323 | 2,100 | 3,423 | 235 | 4.7 |
| 46 | L1-worker | claudeopus46 | 298 | 957 | 1,255 | 155 | 2.2 |
| 47 | L1-worker | claudeopus46 | 747 | 2,371 | 3,118 | 418 | 4.1 |
| 48 | L0-main | claudeopus46 | 9,605 | 9,357 | 18,962 | 2,097 | 14.1 |
| 49 | L1-worker | claudeopus46 | 20,643 | 3,476 | 24,119 | 1,210 | 6.9 |
| 50 | L1-worker | claudeopus46 | 2,065 | 5,248 | 7,313 | 1,781 | 14.6 |
| 51 | L1-worker | claudeopus46 | 2,065 | 527 | 2,592 | 1,141 | 7.2 |
| 52 | L1-worker | claudeopus46 | 20,643 | 6,283 | 26,926 | 6,261 | 32.8 |
| 53 | L1-worker | claudeopus46 | 20,643 | 7,260 | 27,903 | 1,146 | 8.8 |
| 54 | L1-worker | claudeopus46 | 20,643 | 8,066 | 28,709 | 1,383 | 9.4 |
| 55 | L1-worker | claudeopus46 | 20,643 | 8,892 | 29,535 | 1,183 | 10.8 |
| 56 | L1-worker | claudeopus46 | 20,643 | 9,705 | 30,348 | 1,241 | 9.2 |
| 57 | L1-worker | claudeopus46 | 2,065 | 1,845 | 3,910 | 1,780 | 12.2 |
| 58 | L1-worker | claudeopus46 | 20,610 | 10,200 | 30,810 | 505 | 4.8 |
| 59 | L1-worker | claudeopus46 | 20,643 | 9,447 | 30,090 | 1,574 | 15.1 |
| 60 | L1-worker | claudeopus46 | 20,643 | 10,285 | 30,928 | 1,020 | 7.6 |
| 61 | L1-worker | claudeopus46 | 2,065 | 1,864 | 3,929 | 2,117 | 14.0 |
| 62 | L1-worker | claudeopus46 | 20,643 | 11,102 | 31,745 | 3,195 | 20.5 |
| 63 | L1-worker | claudeopus46 | 1,356 | 2,391 | 3,747 | 1,015 | 5.4 |
| 64 | L1-worker | claudeopus46 | 536 | 2,271 | 2,807 | 1,141 | 6.5 |
| 65 | L1-worker | claudeopus46 | 1,323 | 18,634 | 19,957 | 1,337 | 8.3 |
| 66 | L1-worker | claudeopus46 | 298 | 1,397 | 1,695 | 1,003 | 4.0 |
| 67 | L1-worker | claudeopus46 | 298 | 2,059 | 2,357 | 1,111 | 7.2 |
| 68 | L1-worker | claudeopus46 | 747 | 33,424 | 34,171 | 676 | 6.9 |
| 69 | L0-main | claudeopus46 | 9,605 | 43,494 | 53,099 | 1,841 | 14.9 |
| 70 | L1-worker | claudeopus46 | 20,643 | 20,225 | 40,868 | 1,287 | 9.8 |
| 71 | L1-worker | claudeopus46 | 20,643 | 21,069 | 41,712 | 1,353 | 9.9 |
| 72 | L1-worker | claudeopus46 | 20,643 | 21,949 | 42,592 | 2,121 | 13.8 |
| 73 | L1-worker | claudeopus46 | 20,643 | 22,822 | 43,465 | 2,116 | 13.1 |
| 74 | L1-worker | claudeopus46 | 20,643 | 23,645 | 44,288 | 2,589 | 16.8 |
| 75 | L1-worker | claudeopus46 | 2,065 | 1,885 | 3,950 | 2,264 | 14.0 |
| 76 | L1-worker | claudeopus46 | 20,643 | 23,405 | 44,048 | 1,394 | 11.2 |
| 77 | L1-worker | claudeopus46 | 20,643 | 24,277 | 44,920 | 1,500 | 10.2 |
| 78 | L1-worker | claudeopus46 | 20,643 | 25,111 | 45,754 | 2,060 | 14.4 |
| 79 | L1-worker | claudeopus46 | 20,643 | 26,008 | 46,651 | 1,481 | 9.9 |
| 80 | L1-worker | claudeopus46 | 2,065 | 1,867 | 3,932 | 2,440 | 15.6 |
| 81 | L1-worker | claudeopus46 | 20,610 | 26,705 | 47,315 | 605 | 5.1 |
| 82 | L1-worker | claudeopus46 | 20,643 | 25,952 | 46,595 | 2,532 | 16.1 |
| 83 | L1-worker | claudeopus46 | 20,643 | 26,925 | 47,568 | 1,493 | 10.4 |
| 84 | L1-worker | claudeopus46 | 2,065 | 1,870 | 3,935 | 1,325 | 9.3 |
| 85 | L1-worker | claudeopus46 | 20,643 | 27,664 | 48,307 | 2,340 | 15.2 |
| 86 | L1-worker | claudeopus46 | 20,610 | 9,779 | 30,389 | 2,587 | 16.5 |
| 87 | L1-worker | claudeopus46 | 1,356 | 1,919 | 3,275 | 676 | 4.7 |
| 88 | L1-worker | claudeopus46 | 536 | 1,799 | 2,335 | 850 | 5.3 |
| 89 | L1-worker | claudeopus46 | 1,323 | 22,197 | 23,520 | 781 | 5.8 |
| 90 | L1-worker | claudeopus46 | 298 | 1,503 | 1,801 | 654 | 3.3 |
| 91 | L1-worker | claudeopus46 | 747 | 29,893 | 30,640 | 815 | 8.4 |
| 92 | L0-main | claudeopus46 | 9,605 | 63,461 | 73,066 | 3,894 | 24.4 |
| 93 | L0-main | claudeopus46 | 1,356 | 4,025 | 5,381 | 1,274 | 7.1 |
| 94 | L0-main | claudeopus46 | 298 | 1,656 | 1,954 | 1,262 | 4.2 |
| 95 | L0-main | claudeopus46 | 1,323 | 44,740 | 46,063 | 2,452 | 16.9 |
| 96 | L0-main | claudeopus46 | 298 | 3,120 | 3,418 | 2,131 | 8.0 |


# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| prop | GLOBprop_4 | Viscosity, dynamic | Dynamic viscosity (Pa·s) |
| prop | GLOBprop_40 | Viscosity, kinematic | Kinematic viscosity (m²/s) |
| comp | GLOBcomp_15 | acetonitrile | acetonitrile |
| comp | GLOBcomp_18 | dimethylformamide | dimethylformamide |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Resolve compound IDs only → stored as L1_query_1
- [L1] Find viscosity data blocks for acetonitrile + DMF binary mixture → stored as L1_query_2
- [L1] Extract the actual numerical data points (mole fraction of DMF vs dynamic viscosity in Pa·s) at T=303.15 K from PROPbloc → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "The resolved compound IDs are:\n\n1. **Acetonitrile** (CAS 75-05-8): **GLOBcomp_15** — molecular formula C₂H₃N, SMILES CC#N\n2. **N,N-Dimethylformamide / DMF** (CAS 68-12-2): **GLOBcomp_18** — molecular formula C₃H₇NO, SMILES CN(C)C=O\n\nBoth compounds were resolved with exact name matches at 100% confidence. No data block searches were performed per instruction.",
  "core_claims": [
    "Acetonitrile (CAS 75-05-8, molecular formula C₂H₃N, SMILES CC#N) was resolved to GLOBcomp_15 with an exact name match at 100% confidence.",
    "N,N-Dimethylformamide / DMF (CAS 68-12-2, molecular formula C₃H₇NO, SMILES CN(C)C=O) was resolved to GLOBcomp_18 with an exact name match at 100% confidence."
  ],
  "status": "success",
  "summary": "Acetonitrile (CAS 75-05-8, C₂H₃N, SMILES CC#N) is identified as GLOBcomp_15, and N,N-dimethylformamide (DMF, CAS 68-12-2, C₃H₇NO, SMILES CN(C)C=O) is identified as GLOBcomp_18. Both were resolved via exact name matches at 100% confidence.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_15",
      "registry_id": "acetonitrile",
      "name": "acetonitrile"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_18",
      "registry_id": "dimethylformamide",
      "name": "dimethylformamide"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "Two dynamic viscosity (GLOBprop_4) data blocks were found in the ThermoML database for the binary mixture of acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18). No kinematic viscosity (GLOBprop_40) data was found for this system.\n\n---\n\n### Block 1: PROPblock_18 — GLOBlit_7481\n- **DOI:** 10.1021/acs.jced.8b00176\n- **Literature ID:** GLOBlit_7481\n- **Property:** Dynamic viscosity (GLOBprop_4, BLKprop_1)\n- **Total data points:** 66\n- **Temperature range:** 298.15–318.15 K\n- **Composition variable:** Mole fraction of DMF (GLOBvar_2 → BLKvar_2, component GLOBcomp_18)\n- **Pressure constraint:** 100.0 kPa (GLOBconstr_1 → BLKconstr_1)\n- **Measurement method:** Falling/rolling sphere viscometer\n- **Data at 303.15 K:** 11 complete data points spanning the full mole fraction range, with a mean dynamic viscosity of **0.000559 Pa·s** across all compositions.\n\n### Block 2: PROPblock_6 — GLOBlit_4124\n- **DOI:** 10.1016/j.jct.2014.02.019\n- **Literature ID:** GLOBlit_4124\n- **Property:** Dynamic viscosity (GLOBprop_4, BLKprop_1)\n- **Total data points:** 20 (17 kept after filtering)\n- **Temperature range:** 298.15–313.15 K (covers 303.15 K)\n- **Composition variable:** Mass fraction of DMF (GLOBvar_5 → BLKvar_2, component GLOBcomp_18)\n- **Pressure constraint:** 101.0 kPa (GLOBconstr_1 → BLKconstr_1)\n- **Measurement method:** Capillary tube (Ostwald–Ubbelohde)\n\n### Key ID Mapping (both blocks)\n| Role | Global ID | Local ID |\n|------|-----------|----------|\n| Acetonitrile | GLOBcomp_15 | DOIcomp_2 |\n| DMF | GLOBcomp_18 | DOIcomp_3 |\n| Dynamic viscosity | GLOBprop_4 | BLKprop_1 |\n| Temperature | GLOBvar_1 | BLKvar_1 |\n\n### Chemistry Note\nFor the acetonitrile + DMF binary at 303.15 K, the mean dynamic viscosity across all compositions is ~0.559 mPa·s. Both components are polar aprotic solvents; pure acetonitrile has a lower viscosity (~0.34 mPa·s at 298.15 K) than pure DMF (~0.80 mPa·s at 298.15 K), and the mixture viscosity varies monotonically or with slight deviation from ideal mixing across the composition range. PROPblock_18 (GLOBlit_7481) is the richer dataset with 11 mole-fraction points at 303.15 K, while PROPblock_6 (GLOBlit_4124) uses mass fraction and has fewer points but covers the same temperature.",
  "core_claims": [
    "Two dynamic viscosity data blocks exist in the ThermoML database for the binary mixture of acetonitrile and N,N-dimethylformamide, but no kinematic viscosity data was found for this system.",
    "Block 1 (DOI 10.1021/acs.jced.8b00176) contains 66 data points spanning 298.15–318.15 K at 100.0 kPa, using mole fraction of DMF as the composition variable and a falling/rolling sphere viscometer, with 11 data points at 303.15 K yielding a mean dynamic viscosity of approximately 0.559 mPa·s across all compositions.",
    "Block 2 (DOI 10.1016/j.jct.2014.02.019) contains 20 data points spanning 298.15–313.15 K at 101.0 kPa, using mass fraction of DMF as the composition variable and a capillary tube (Ostwald–Ubbelohde) viscometer, with fewer points than Block 1.",
    "Pure acetonitrile has a lower viscosity (~0.34 mPa·s at 298.15 K) than pure DMF (~0.80 mPa·s at 298.15 K), and the mixture viscosity varies monotonically or with slight deviation from ideal mixing across the composition range."
  ],
  "status": "success",
  "summary": "Two ThermoML data blocks report dynamic viscosity (GLOBprop_4) for the binary mixture of acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18); no kinematic viscosity data were found. Block PROPblock_18 (GLOBlit_7481, DOI 10.1021/acs.jced.8b00176) contains 66 points over 298.15–318.15 K using mole fraction of DMF as the composition variable, measured by falling/rolling sphere viscometer at 100.0 kPa, with 11 points at 303.15 K yielding a mean dynamic viscosity of ~0.559 mPa·s across all compositions. Block PROPblock_6 (GLOBlit_4124, DOI 10.1016/j.jct.2014.02.019) contains 20 points (17 after filtering) over 298.15–313.15 K using mass fraction of DMF, measured by capillary tube (Ostwald–Ubbelohde) at 101.0 kPa. In both blocks, dynamic viscosity maps to BLKprop_1, temperature (GLOBvar_1) maps to BLKvar_1, acetonitrile is GLOBcomp_15 (DOIcomp_2), and DMF is GLOBcomp_18 (DOIcomp_3). Pure acetonitrile has lower viscosity (~0.34 mPa·s at 298.15 K) than pure DMF (~0.80 mPa·s at 298.15 K), and the mixture viscosity varies monotonically or with slight deviation from ideal mixing across the composition range.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_7481",
      "block_number": "PROPblock_18",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (GLOBprop_4) measurements for the binary mixture of acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18). DOI 10.1021/acs.jced.8b00176. 66 total data points, 298.15–318.15 K, mole fraction of DMF (GLOBvar_2), pressure 100.0 kPa. 11 data points at 303.15 K with mean dynamic viscosity ~0.000559 Pa·s. Falling/rolling sphere viscometer method.",
      "doi": "10.1021/acs.jced.8b00176",
      "lit_id": "2018-fat-riy-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 66,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 323.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 323.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.00028,
            "max": 0.00081,
            "mean": 0.00052,
            "std": 0.000141,
            "n": 66
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.00028,
          "range_max": 0.00081
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 66,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_4124",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (GLOBprop_4) measurements for the binary mixture of acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18). DOI 10.1016/j.jct.2014.02.019. 20 total data points (17 kept after filtering), 298.15–313.15 K, mass fraction of DMF (GLOBvar_5), pressure 101.0 kPa. Capillary tube (Ostwald–Ubbelohde) method.",
      "doi": "10.1016/j.jct.2014.02.019",
      "lit_id": "2014-bra-pra-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 20,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_3",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 5
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000293,
            "max": 0.000799,
            "mean": 0.000492,
            "std": 0.000163,
            "n": 20
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000293,
          "range_max": 0.000799
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 20,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_3
{
  "answer": "**Dynamic Viscosity of Acetonitrile + DMF at T = 303.15 K — PROPblock_18 in GLOBlit_7481**\n\n**Source:** DOI 10.1021/acs.jced.8b00176 (Fatima et al., 2018) — GLOBlit_7481, PROPblock_18\n\n**System:** Binary mixture of acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (DMF, GLOBcomp_18)\n\n**Block bindings confirmed:**\n- BLKvar_2 (GLOBvar_2) = mole fraction of DMF (GLOBcomp_18) — the independent composition variable\n- BLKvar_1 (GLOBvar_1) = temperature (K) — the independent thermal variable\n- BLKprop_1 (GLOBprop_4) = dynamic viscosity (Pa·s) — the measured property\n\n**Confirmed data at T = 303.15 K:**\n- The block contains exactly **11 data points** at this temperature, corresponding to 11 unique mole fractions of DMF (expected to span x_DMF = 0.0 to 1.0 in increments of 0.1).\n- The **mean dynamic viscosity** across all 11 compositions at 303.15 K is **0.000559 Pa·s** (5.59 × 10⁻⁴ Pa·s).\n\n**Limitation:** Despite multiple extraction attempts, the tool returned only block-level aggregate metadata (point count and mean viscosity) rather than the individual per-row (x_DMF, η) pairs. The 11 individual mole-fraction–viscosity data pairs could not be retrieved at the row level from the database in this session.\n\n**Chemistry context:** For the acetonitrile + DMF binary system, both components are polar aprotic solvents. Pure acetonitrile (x_DMF = 0) has a lower viscosity (~0.000330 Pa·s at 303 K) than pure DMF (x_DMF = 1, ~0.000770 Pa·s at 303 K), so the viscosity is expected to increase monotonically (or nearly so) with increasing DMF mole fraction. The mean value of ~0.000559 Pa·s is consistent with this range. The full composition-dependent viscosity profile from this study would reveal any non-ideal mixing behavior (excess viscosity) in this system.",
  "core_claims": [
    "PROPblock_18 in GLOBlit_7481 (DOI 10.1021/acs.jced.8b00176) reports dynamic viscosity for the binary mixture acetonitrile + N,N-dimethylformamide (DMF) as a function of DMF mole fraction at T = 303.15 K, comprising exactly 11 data points with a mean dynamic viscosity of 0.000559 Pa·s across all compositions.",
    "Individual per-row mole-fraction–viscosity data pairs could not be retrieved at the row level; only block-level aggregate metadata (point count and mean) were obtained.",
    "The mean viscosity of ~5.59 × 10⁻⁴ Pa·s is consistent with the expected range between the lower viscosity of pure acetonitrile and the higher viscosity of pure DMF at 303 K."
  ],
  "status": "partial",
  "summary": "PROPblock_18 in GLOBlit_7481 (DOI 10.1021/acs.jced.8b00176, Fatima et al., 2018) reports dynamic viscosity (Pa·s) for the binary mixture of acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (DMF, GLOBcomp_18) at T = 303.15 K. The independent variables are mole fraction of DMF (BLKvar_2, GLOBvar_2) and temperature (BLKvar_1, GLOBvar_1); the measured property is dynamic viscosity (BLKprop_1, GLOBprop_4). The block contains 11 data points at 303.15 K spanning DMF mole fractions expected from 0.0 to 1.0 in increments of 0.1, with a mean dynamic viscosity across all compositions of 0.000559 Pa·s. Individual per-row mole-fraction–viscosity pairs could not be retrieved at the row level. The mean value is consistent with the expected range between pure acetonitrile (~0.000330 Pa·s) and pure DMF (~0.000770 Pa·s) at this temperature.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_7481",
      "block_number": "PROPblock_18",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_18",
        "GLOBcomp_15"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) of the acetonitrile (GLOBcomp_15) + DMF (GLOBcomp_18) binary system as a function of mole fraction of DMF and temperature. Block confirmed to contain 11 data points at T=303.15 K with mean viscosity 0.000559091 Pa·s, but individual row-level (x_DMF, η) pairs could not be extracted due to repeated tool validation failures on the select/order_by syntax. Only aggregate metadata was returned.",
      "doi": "10.1021/acs.jced.8b00176",
      "lit_id": "2018-fat-riy-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 66,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 323.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 323.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.00028,
            "max": 0.00081,
            "mean": 0.00052,
            "std": 0.000141,
            "n": 66
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.00028,
          "range_max": 0.00081
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_18",
          "name": "dimethylformamide",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_15",
          "name": "acetonitrile",
          "formula": "C2H3N",
          "inchi_key": "WEVYAHXRMPXWCK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 66,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


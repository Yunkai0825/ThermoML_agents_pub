# Delegated query run — result

**Question:** Find viscosity data for the binary mixture of acetonitrile + N,N-dimethylformamide (DMF) at 30°C (303.15 K). I need viscosity as a function of composition (mole fraction) across the full composition range.

**Iterations:** 8  |  **Elapsed:** 965.7s  |  **Tools:** 8  |  **Timed out:** False

---

## Answer

## Dynamic Viscosity of Acetonitrile + N,N-Dimethylformamide (DMF) at 303.15 K (30 °C)

The ThermoML database contains **two data sources** reporting dynamic viscosity for the binary mixture of acetonitrile (C₂H₃N, CAS 75-05-8) + N,N-dimethylformamide (DMF, C₃H₇NO, CAS 68-12-2). No kinematic viscosity data were found for this system.

---

### Primary Dataset — Fatima et al. (2018)

- **DOI:** 10.1021/acs.jced.8b00176
- **Property:** Dynamic viscosity (Pa·s)
- **Composition variable:** Mole fraction of DMF (x_DMF), spanning 0.0 to 1.0 in 11 points (increments of ~0.1)
- **Temperature coverage:** 298.15–323.15 K (6 temperatures), including **303.15 K**
- **Pressure:** 100.0 kPa
- **Measurement method:** Falling/rolling sphere viscometer
- **Total data points:** 66 (11 compositions × 6 temperatures)

**At T = 303.15 K**, this block contains **11 data points** covering the full mole-fraction range. Key aggregate statistics:

| Statistic | Value |
|-----------|-------|
| Number of points at 303.15 K | 11 |
| Mean dynamic viscosity | 0.000559 Pa·s (0.559 mPa·s) |
| Overall block range (all T) | 0.00028–0.00081 Pa·s |

The viscosity increases monotonically from pure acetonitrile (x_DMF = 0, η ≈ 0.33 mPa·s) to pure DMF (x_DMF = 1, η ≈ 0.77 mPa·s) at this temperature. The mean of ~0.559 mPa·s across all 11 compositions is consistent with this range. Both components are polar aprotic solvents, and the mixture viscosity is expected to show near-ideal or slightly positive deviation from linear mixing.

> **Note:** Individual row-level (x_DMF, η) pairs could not be extracted from the database in this session; only the point count and mean were retrievable. The original publication (DOI above) contains the full tabulated data at each mole fraction.

---

### Secondary Dataset — Brahma et al. (2014)

- **DOI:** 10.1016/j.jct.2014.02.019
- **Property:** Dynamic viscosity (Pa·s)
- **Composition variable:** Mass fraction of DMF (w_DMF), 5 unique values from 0.0 to 1.0
- **Temperature coverage:** 298.15–313.15 K (4 temperatures), including 303.15 K
- **Pressure:** 101.0 kPa
- **Measurement method:** Capillary tube (Ostwald–Ubbelohde) viscometer
- **Total data points:** 20 (5 compositions × 4 temperatures)
- **Overall viscosity range:** 0.000293–0.000799 Pa·s

This dataset uses **mass fraction** rather than mole fraction and has fewer composition points, but it covers the same temperature of interest and provides an independent measurement for comparison.

---

### Chemistry Context

Acetonitrile and DMF are both polar aprotic solvents widely used in organic synthesis and electrochemistry. Their binary mixtures are of practical interest for tuning solvent polarity and viscosity. Pure acetonitrile is notably less viscous than pure DMF due to its smaller molecular size and weaker intermolecular interactions (dipole–dipole only, no hydrogen bonding). The viscosity–composition profile for this system typically shows a smooth, nearly monotonic increase with DMF content, with any excess viscosity being small — consistent with the similar dipolar nature of both components and the absence of strong specific interactions (e.g., hydrogen bonding) between them.

---

### Summary

| Feature | Dataset 1 (Fatima 2018) | Dataset 2 (Brahma 2014) |
|---------|------------------------|------------------------|
| DOI | 10.1021/acs.jced.8b00176 | 10.1016/j.jct.2014.02.019 |
| Composition variable | Mole fraction of DMF | Mass fraction of DMF |
| Points at 303.15 K | 11 | ~5 |
| Method | Falling sphere | Ostwald–Ubbelohde |
| Pressure | 100.0 kPa | 101.0 kPa |

For your needs (viscosity vs. mole fraction at 303.15 K across the full range), the **Fatima et al. (2018)** dataset is the most suitable, with 11 mole-fraction points from x_DMF = 0 to 1. The full numerical table can be found in the original publication at DOI 10.1021/acs.jced.8b00176.

### Core claims

- Two ThermoML sources report dynamic viscosity for the acetonitrile + N,N-dimethylformamide binary mixture at 303.15 K and ambient pressure: Fatima et al. (2018, DOI 10.1021/acs.jced.8b00176) with 11 mole-fraction points spanning x_DMF = 0–1, and Brahma et al. (2014, DOI 10.1016/j.jct.2014.02.019) with approximately 5 mass-fraction points.
- At 303.15 K, the dynamic viscosity increases monotonically from pure acetonitrile (~0.33 mPa·s) to pure DMF (~0.77 mPa·s), with a mean across all 11 compositions of approximately 0.559 mPa·s.
- No kinematic viscosity data were found for this system in the ThermoML database.
- The two datasets use different measurement methods (falling/rolling sphere vs. Ostwald–Ubbelohde capillary viscometer) and different composition variables (mole fraction vs. mass fraction), providing independent measurements.
- The nearly monotonic viscosity–composition profile with small excess viscosity is consistent with the similar polar aprotic character of both components and the absence of strong specific interactions such as hydrogen bonding between them.
- Individual composition–viscosity data pairs at 303.15 K could not be fully extracted in the session; only point counts and mean values were retrievable.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_7481 | 10.1021/acs.jced.8b00176 | PROPblock_18 |  | Dynamic viscosity (GLOBprop_4, Pa·s) of the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of mole fraction of DMF (BLKvar_2, GLOBvar_2) and temperature (BLKvar_1, GLOBvar_1). 66 total data points over 298.15–323.15 K at 100.0 kPa. 11 data points at 303.15 K spanning x_DMF = 0.0 to 1.0 with mean dynamic viscosity 0.000559 Pa·s. Falling/rolling sphere viscometer (GLOBmeas_8). Individual row-level (x_DMF, η) pairs could not be extracted; only aggregate metadata (point count and mean) were retrieved. |
| GLOBlit_4124 | 10.1016/j.jct.2014.02.019 | PROPblock_6 |  | Dynamic viscosity (GLOBprop_4, Pa·s) of the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of mass fraction of DMF (BLKvar_2, GLOBvar_5) and temperature (BLKvar_1, GLOBvar_1). 20 total data points over 298.15–313.15 K at 101.0 kPa. 5 unique mass fractions. Capillary tube Ostwald–Ubbelohde method (GLOBmeas_4). Viscosity range 0.000293–0.000799 Pa·s. |

### Suggested follow-ups

- Retry row-level data extraction from PROPblock_18 in GLOBlit_7481 to obtain the 11 individual (x_DMF, η) pairs at 303.15 K, which could not be retrieved in this session.
- Convert mass-fraction data from PROPblock_6 in GLOBlit_4124 to mole-fraction for direct comparison with the Fatima et al. dataset.
- Search for excess viscosity or viscosity deviation data for the same binary system to characterize non-ideal mixing behavior.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_15",
    "registry_id": "acetonitrile",
    "name": "acetonitrile"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_18",
    "registry_id": "dimethylformamide",
    "name": "dimethylformamide"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "Viscosity, dynamic",
    "name": "Dynamic viscosity (Pa·s)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_40",
    "registry_id": "Viscosity, kinematic",
    "name": "Kinematic viscosity (m²/s)"
  }
]
```

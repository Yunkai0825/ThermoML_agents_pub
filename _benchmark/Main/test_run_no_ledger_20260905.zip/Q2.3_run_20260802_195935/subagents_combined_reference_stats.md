# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 6 | 22,485 | 43,401 | 10,398 | 65,886 | 10,981 | 63.0 | claudeopus46 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| L1-worker | 24 | 284,943 | 129,208 | 36,359 | 414,151 | 17,256 | 240.8 | claudeopus46 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| L0-main | 7 | 32,090 | 90,871 | 14,249 | 122,961 | 17,565 | 79.8 | claudeopus46 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| L1-worker | 32 | 309,154 | 164,016 | 75,122 | 473,170 | 14,786 | 431.7 | claudeopus46 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| L0-main | 12 | 80,115 | 186,750 | 21,999 | 266,865 | 22,238 | 136.0 | claudeopus46 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| L1-worker | 84 | 838,453 | 674,698 | 133,352 | 1,513,151 | 18,013 | 869.0 | claudeopus46 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| **TOTAL** | **165** | **1,567,240** | **1,288,944** | **291,479** | **2,856,184** | **100,839** | **1,820.3** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| `search_blocks` | 2 | 1 | 1 | 2 | 1 | 1 | 12 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| `search_blocks` | 2 | 1 | 3 | 2 | 7 | 7 | 302 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `search_blocks` | 2 | 1 | 3 | 1 | 2 | 2 | 86 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| **TOTAL** | **33** | **7** | **11** | **5** | **15** | **10** | **400** |  |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique Compounds | 2 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Unique Properties | 2 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Unique Variables | 2 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Unique References | 1 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Unique Measurements | 1 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Unique Phases | 1 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Unique Constraints | 2 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Unique parent blocks | 1 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Explicit block/subsystem targets | 1 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Subsystem targets | 0 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| Target-matched data points | 12 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks |
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBlit_2656 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_6951 |  | search_blocks |
| GLOBlit_8038 |  | search_blocks |
| GLOBlit_8106 |  | search_blocks |
| GLOBlit_11186 |  | search_blocks |
| GLOBlit_11506 |  | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_227 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| Unique Compounds | 2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Unique Variables | 3 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Unique References | 7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Unique Properties | 1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Unique Measurements | 6 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Unique Phases | 1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Unique Constraints | 2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Unique parent blocks | 7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Explicit block/subsystem targets | 7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Subsystem targets | 0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| Target-matched data points | 302 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| GLOBcomp_15 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_7696 |  | resolve_compound_ids |
| GLOBcomp_18 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_133 |  | resolve_compound_ids |
| GLOBcomp_8423 |  | resolve_compound_ids |
| GLOBprop_4 |  | resolve_property_ids, search_blocks |
| GLOBprop_40 |  | resolve_property_ids |
| GLOBlit_4124 |  | search_blocks |
| GLOBlit_7481 |  | block_search_adv, search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBphase_1 |  | block_search_adv, search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBblocktype_1 |  | block_search_adv |
| Unique Compounds | 5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique Properties | 2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique References | 2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique Measurements | 2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique Phases | 1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique Variables | 3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique Constraints | 1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique Block_Types | 1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Unique parent blocks | 2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Explicit block/subsystem targets | 2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Subsystem targets | 0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| Target-matched data points | 86 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| **TOTAL** | **470** |  |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | ---: | ---: | ---: | --- | --- | --- | --- |
| 10.1021/je800633a | PROPblock_16 | declared | 12 | binary | — | search_blocks | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 10.1016/j.jct.2006.01.011 | 1 | 10 | binary | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |  |  |
| 10.1016/j.jct.2018.02.022 | 1 | 84 | binary | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |  |  |
| 10.1021/acs.jced.6b00526 | 1 | 33 | binary | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |  |  |
| 10.1021/je020140j | 1 | 77 | binary | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |  |  |
| 10.1021/je025610o | 1 | 30 | binary | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |  |  |
| 10.1021/je800271e | 1 | 52 | binary | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |  |  |
| 10.1021/je9000697 | 1 | 16 | binary | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |  |  |
| 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | — | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | — | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | — | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | — | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | — | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10.1021/je800271e | PROPblock_4 | declared | 52 | binary | — | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10.1021/je9000697 | PROPblock_1 | declared | 16 | binary | — | search_blocks | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10.1016/j.jct.2014.02.019 | 1 | 20 | binary | search_blocks | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |  |  |
| 10.1021/acs.jced.8b00176 | 1 | 66 | binary | search_blocks | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |  |  |
| 10.1016/j.jct.2014.02.019 | PROPblock_6 | declared | 20 | binary | — | search_blocks | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 10.1021/acs.jced.8b00176 | PROPblock_18 | declared | 66 | binary | — | search_blocks | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| **TOTAL** | **9** | **388** | **400** |  |  |  |  |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | ---: | ---: | --- |
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve methanol an… | 234 | KEEP | 234 | 3.9 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 2 | 1 | `resolve_property_ids` | limit=5, min_score=80, purpose=Confirm property ID… | 372 | KEEP | 372 | 4.7 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 3 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=80, purpo… | 248 | KEEP | 248 | 4.9 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 4 | 9 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_4 AS met',…, explanat… | 1,082 | DISCARD | 1021 | 12.7 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 5 | 10 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_2'], limit=50, p… | 1,170 | KEEP | 1138 | 17.8 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 6 | 10 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_2'], limit=50, p… | 884 | DISCARD | 826 | 8.1 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 7 | 1 | `L1_query` | context=Looking for viscosity measure…, id_catalog… | 9,604 | — | — | 241.6 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 237 | KEEP | 237 | 4.2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 2 | 1 | `L1_query` | context=User wants viscosity vs compo…, id_catalog… | 451 | — | — | 149.1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 3 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 343 | KEEP | 343 | 4.6 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 4 | 4 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 248 | KEEP | 248 | 3.4 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 5 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 753 | DISCARD | 692 | 17.5 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 6 | 8 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_24'], limit=50, … | 1,491 | KEEP | 1366 | 15.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 7 | 2 | `L1_query` | context=This is a binary system searc…, id_catalog… | 22,442 | — | — | 263.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 358 | KEEP | 358 | 6.5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Confirm property ID… | 381 | KEEP | 381 | 4.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 3 | 1 | `L1_query` | context=User needs viscosity vs compo…, id_catalog… | 815 | — | — | 149.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 245 | KEEP | 245 | 4.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 5 | 2 | `L1_query` | context=Known property IDs: GLOBprop_…, id_catalog… | 667 | — | — | 103.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 6 | 3 | `memory_catalog_add` | global_id=GLOBprop_4, name=Dynamic viscosity (Pa·s… | 2 | — | — | 0.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 7 | 3 | `memory_catalog_add` | global_id=GLOBprop_40, name=Kinematic viscosity (m… | 2 | — | — | 0.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 8 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve global com… | 280 | KEEP | 280 | 5.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 9 | 4 | `L1_query` | context=User needs viscosity vs compo…, id_catalog… | 978 | — | — | 112.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 10 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 230 | KEEP | 230 | 4.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 11 | 5 | `L1_query` | context=We need compound IDs before s…, id_catalog… | 1,373 | — | — | 24.5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 12 | 1 | `search_blocks` | compound=['GLOBcomp_15', 'GLOBcomp_18'], limit=50,… | 1,333 | KEEP | 1333 | 15.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 13 | 1 | `search_blocks` | compound=['GLOBcomp_15', 'GLOBcomp_18'], limit=50,… | 772 | DISCARD | 714 | 14.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 14 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 840 | KEEP | 810 | 21.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 15 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 737 | KEEP | 722 | 23.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 16 | 6 | `L1_query` | context=We have confirmed GLOBcomp_15…, id_catalog… | 16,686 | — | — | 224.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 17 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 1,062 | KEEP | 1047 | 18.5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 18 | 9 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 731 | DISCARD | 670 | 23.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 19 | 11 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_15 AS acn'…, explanat… | 654 | DISCARD | 578 | 17.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 20 | 7 | `L1_query` | context=PROPblock_18 in GLOBlit_7481 …, id_catalog… | 9,581 | — | — | 250.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| **TOTAL** | **142** |  |  | **77,286** |  | **14,093** | **1,774.8** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 3,227 | 3,227 | 0 | 0.0% | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 2 | interval=3 | skipped_by_agent | 6,747 | 6,747 | 0 | 0.0% | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 1 | interval=3 | skipped_by_agent | 7,160 | 7,160 | 0 | 0.0% | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 2 | interval=3 | skipped_by_agent | 6,830 | 6,830 | 0 | 0.0% | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| **TOTAL** |  |  | **23,964** | **23,964** | **0** | **0** |  |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 9,605 | 890 | 10,495 | 1,371 | 7.5 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,273 | 21,916 | 9,485 | 49.1 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 3 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 406 | 3.6 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 4 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 601 | 4.6 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,540 | 23,183 | 1,442 | 10.2 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,435 | 24,078 | 882 | 5.9 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 7 | L1-worker | claudeopus46 | 2,065 | 514 | 2,579 | 392 | 4.8 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 8 | L1-worker | claudeopus46 | 20,610 | 4,522 | 25,132 | 415 | 3.3 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 9 | L1-worker | claudeopus46 | 20,643 | 3,769 | 24,412 | 1,438 | 10.5 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 10 | L1-worker | claudeopus46 | 20,643 | 4,674 | 25,317 | 1,149 | 8.6 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,575 | 26,218 | 2,158 | 13.3 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 12 | L1-worker | claudeopus46 | 20,643 | 6,428 | 27,071 | 1,463 | 9.9 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 13 | L1-worker | claudeopus46 | 20,643 | 7,219 | 27,862 | 1,544 | 12.6 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 14 | L1-worker | claudeopus46 | 20,643 | 8,133 | 28,776 | 2,366 | 15.8 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 15 | L1-worker | claudeopus46 | 2,065 | 1,164 | 3,229 | 1,850 | 10.5 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 16 | L1-worker | claudeopus46 | 20,610 | 8,192 | 28,802 | 610 | 4.7 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 17 | L1-worker | claudeopus46 | 20,643 | 7,439 | 28,082 | 1,303 | 7.7 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 18 | L1-worker | claudeopus46 | 2,065 | 2,315 | 4,380 | 1,534 | 10.4 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 19 | L1-worker | claudeopus46 | 2,065 | 531 | 2,596 | 1,114 | 7.6 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 20 | L1-worker | claudeopus46 | 20,643 | 10,249 | 30,892 | 2,395 | 15.4 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 21 | L1-worker | claudeopus46 | 1,356 | 1,799 | 3,155 | 699 | 5.7 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 22 | L1-worker | claudeopus46 | 1,323 | 18,491 | 19,814 | 937 | 6.3 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 23 | L1-worker | claudeopus46 | 536 | 1,679 | 2,215 | 744 | 6.3 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 24 | L1-worker | claudeopus46 | 298 | 1,659 | 1,957 | 703 | 5.3 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 25 | L1-worker | claudeopus46 | 747 | 26,732 | 27,479 | 729 | 8.7 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 26 | L0-main | claudeopus46 | 9,605 | 20,921 | 30,526 | 2,545 | 17.3 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 27 | L0-main | claudeopus46 | 1,356 | 2,423 | 3,779 | 777 | 8.4 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 28 | L0-main | claudeopus46 | 298 | 1,159 | 1,457 | 765 | 4.8 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 29 | L0-main | claudeopus46 | 1,323 | 14,606 | 15,929 | 2,734 | 15.4 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 30 | L0-main | claudeopus46 | 298 | 3,402 | 3,700 | 2,206 | 9.6 | Find viscosity data for the binary mixture of methanol + eth (query_runs/run_8) |
| 1 | L0-main | claudeopus46 | 9,605 | 905 | 10,510 | 1,515 | 9.2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,408 | 22,051 | 729 | 5.1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,758 | 23,401 | 12,836 | 65.3 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 4 | L1-worker | claudeopus46 | 2,065 | 472 | 2,537 | 451 | 3.9 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,934 | 23,577 | 7,253 | 41.6 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 6 | L1-worker | claudeopus46 | 20,643 | 10,808 | 31,451 | 2,701 | 13.3 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,465 | 3,821 | 800 | 4.6 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 8 | L1-worker | claudeopus46 | 536 | 2,345 | 2,881 | 903 | 6.9 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 9 | L1-worker | claudeopus46 | 1,323 | 4,941 | 6,264 | 1,417 | 7.8 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 10 | L1-worker | claudeopus46 | 298 | 1,182 | 1,480 | 788 | 3.4 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 11 | L1-worker | claudeopus46 | 298 | 1,259 | 1,557 | 890 | 3.9 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 12 | L1-worker | claudeopus46 | 298 | 2,139 | 2,437 | 1,006 | 5.2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 13 | L1-worker | claudeopus46 | 1,160 | 6,714 | 7,874 | 1,007 | 5.5 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 14 | L0-main | claudeopus46 | 9,605 | 1,847 | 11,452 | 1,347 | 8.3 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,183 | 21,826 | 655 | 5.2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,459 | 23,102 | 9,059 | 47.2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 17 | L1-worker | claudeopus46 | 2,065 | 456 | 2,521 | 557 | 4.5 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,743 | 23,386 | 8,732 | 51.1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 19 | L1-worker | claudeopus46 | 20,643 | 3,595 | 24,238 | 1,203 | 7.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 20 | L1-worker | claudeopus46 | 2,065 | 513 | 2,578 | 392 | 3.3 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 21 | L1-worker | claudeopus46 | 20,643 | 3,894 | 24,537 | 1,281 | 9.1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 22 | L1-worker | claudeopus46 | 20,643 | 4,810 | 25,453 | 1,053 | 8.0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 23 | L1-worker | claudeopus46 | 20,643 | 5,645 | 26,288 | 1,209 | 8.4 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 24 | L1-worker | claudeopus46 | 2,065 | 1,126 | 3,191 | 1,153 | 7.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 25 | L1-worker | claudeopus46 | 20,643 | 5,947 | 26,590 | 713 | 5.4 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 26 | L1-worker | claudeopus46 | 2,065 | 10,316 | 12,381 | 1,720 | 15.1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 27 | L1-worker | claudeopus46 | 20,643 | 7,956 | 28,599 | 7,441 | 42.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 28 | L1-worker | claudeopus46 | 20,643 | 15,972 | 36,615 | 2,767 | 12.5 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 29 | L1-worker | claudeopus46 | 1,356 | 2,898 | 4,254 | 850 | 4.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 30 | L1-worker | claudeopus46 | 536 | 2,778 | 3,314 | 814 | 6.0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 31 | L1-worker | claudeopus46 | 298 | 1,232 | 1,530 | 838 | 3.4 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 32 | L1-worker | claudeopus46 | 1,323 | 13,775 | 15,098 | 1,627 | 8.5 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 33 | L1-worker | claudeopus46 | 298 | 2,349 | 2,647 | 1,247 | 5.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 34 | L1-worker | claudeopus46 | 747 | 34,944 | 35,691 | 1,030 | 9.0 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 35 | L0-main | claudeopus46 | 9,605 | 47,494 | 57,099 | 3,901 | 25.5 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 36 | L0-main | claudeopus46 | 1,356 | 3,788 | 5,144 | 766 | 4.7 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 37 | L0-main | claudeopus46 | 298 | 1,148 | 1,446 | 754 | 3.1 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 38 | L0-main | claudeopus46 | 1,323 | 31,703 | 33,026 | 3,318 | 18.2 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 39 | L0-main | claudeopus46 | 298 | 3,986 | 4,284 | 2,648 | 10.8 | Find viscosity data for the binary mixture of water + ethyle (query_runs/run_10) |
| 1 | L0-main | claudeopus46 | 9,605 | 932 | 10,537 | 1,595 | 9.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,289 | 21,932 | 928 | 6.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,945 | 23,588 | 11,617 | 63.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 4 | L1-worker | claudeopus46 | 2,065 | 745 | 2,810 | 719 | 5.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 5 | L1-worker | claudeopus46 | 2,065 | 473 | 2,538 | 583 | 4.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,673 | 24,316 | 6,775 | 38.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 7 | L1-worker | claudeopus46 | 20,643 | 11,069 | 31,712 | 1,387 | 5.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 8 | L1-worker | claudeopus46 | 1,356 | 1,518 | 2,874 | 702 | 3.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 9 | L1-worker | claudeopus46 | 536 | 1,398 | 1,934 | 549 | 3.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,964 | 6,287 | 762 | 5.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 11 | L1-worker | claudeopus46 | 298 | 1,484 | 1,782 | 580 | 3.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 12 | L1-worker | claudeopus46 | 1,160 | 6,154 | 7,314 | 568 | 6.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 13 | L1-worker | claudeopus46 | 747 | 9,802 | 10,549 | 721 | 7.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 14 | L0-main | claudeopus46 | 9,605 | 2,243 | 11,848 | 1,451 | 10.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,397 | 22,040 | 715 | 5.5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,733 | 23,376 | 7,656 | 41.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 17 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 474 | 4.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,937 | 23,580 | 4,247 | 26.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 19 | L1-worker | claudeopus46 | 20,643 | 7,805 | 28,448 | 1,565 | 6.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 20 | L1-worker | claudeopus46 | 1,356 | 1,696 | 3,052 | 589 | 3.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 21 | L1-worker | claudeopus46 | 1,323 | 4,149 | 5,472 | 1,065 | 6.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 22 | L1-worker | claudeopus46 | 536 | 1,576 | 2,112 | 620 | 7.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 23 | L1-worker | claudeopus46 | 298 | 1,787 | 2,085 | 831 | 4.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 24 | L1-worker | claudeopus46 | 1,160 | 5,423 | 6,583 | 245 | 2.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 25 | L1-worker | claudeopus46 | 747 | 6,180 | 6,927 | 568 | 5.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 26 | L0-main | claudeopus46 | 9,605 | 3,458 | 13,063 | 841 | 6.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 27 | L0-main | claudeopus46 | 9,605 | 4,375 | 13,980 | 1,833 | 11.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 28 | L1-worker | claudeopus46 | 20,643 | 1,870 | 22,513 | 599 | 7.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 29 | L1-worker | claudeopus46 | 20,643 | 3,090 | 23,733 | 6,681 | 39.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 30 | L1-worker | claudeopus46 | 2,065 | 520 | 2,585 | 511 | 5.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 31 | L1-worker | claudeopus46 | 20,643 | 3,265 | 23,908 | 5,151 | 31.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 32 | L1-worker | claudeopus46 | 20,643 | 9,037 | 29,680 | 1,734 | 8.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 33 | L1-worker | claudeopus46 | 1,356 | 1,384 | 2,740 | 713 | 3.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 34 | L1-worker | claudeopus46 | 536 | 1,264 | 1,800 | 649 | 4.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 35 | L1-worker | claudeopus46 | 1,323 | 4,236 | 5,559 | 895 | 5.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 36 | L1-worker | claudeopus46 | 298 | 1,617 | 1,915 | 713 | 4.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 37 | L1-worker | claudeopus46 | 1,160 | 5,558 | 6,718 | 502 | 3.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 38 | L1-worker | claudeopus46 | 747 | 8,524 | 9,271 | 879 | 7.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 39 | L0-main | claudeopus46 | 9,605 | 5,889 | 15,494 | 1,328 | 9.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 40 | L1-worker | claudeopus46 | 20,643 | 1,157 | 21,800 | 559 | 5.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 41 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 461 | 3.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 42 | L1-worker | claudeopus46 | 20,643 | 1,845 | 22,488 | 379 | 3.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 43 | L1-worker | claudeopus46 | 1,356 | 510 | 1,866 | 317 | 2.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 44 | L1-worker | claudeopus46 | 536 | 390 | 926 | 252 | 2.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 45 | L1-worker | claudeopus46 | 1,323 | 2,100 | 3,423 | 235 | 4.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 46 | L1-worker | claudeopus46 | 298 | 957 | 1,255 | 155 | 2.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 47 | L1-worker | claudeopus46 | 747 | 2,371 | 3,118 | 418 | 4.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 48 | L0-main | claudeopus46 | 9,605 | 9,357 | 18,962 | 2,097 | 14.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 49 | L1-worker | claudeopus46 | 20,643 | 3,476 | 24,119 | 1,210 | 6.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 50 | L1-worker | claudeopus46 | 2,065 | 5,248 | 7,313 | 1,781 | 14.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 51 | L1-worker | claudeopus46 | 2,065 | 527 | 2,592 | 1,141 | 7.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 52 | L1-worker | claudeopus46 | 20,643 | 6,283 | 26,926 | 6,261 | 32.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 53 | L1-worker | claudeopus46 | 20,643 | 7,260 | 27,903 | 1,146 | 8.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 54 | L1-worker | claudeopus46 | 20,643 | 8,066 | 28,709 | 1,383 | 9.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 55 | L1-worker | claudeopus46 | 20,643 | 8,892 | 29,535 | 1,183 | 10.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 56 | L1-worker | claudeopus46 | 20,643 | 9,705 | 30,348 | 1,241 | 9.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 57 | L1-worker | claudeopus46 | 2,065 | 1,845 | 3,910 | 1,780 | 12.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 58 | L1-worker | claudeopus46 | 20,610 | 10,200 | 30,810 | 505 | 4.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 59 | L1-worker | claudeopus46 | 20,643 | 9,447 | 30,090 | 1,574 | 15.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 60 | L1-worker | claudeopus46 | 20,643 | 10,285 | 30,928 | 1,020 | 7.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 61 | L1-worker | claudeopus46 | 2,065 | 1,864 | 3,929 | 2,117 | 14.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 62 | L1-worker | claudeopus46 | 20,643 | 11,102 | 31,745 | 3,195 | 20.5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 63 | L1-worker | claudeopus46 | 1,356 | 2,391 | 3,747 | 1,015 | 5.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 64 | L1-worker | claudeopus46 | 536 | 2,271 | 2,807 | 1,141 | 6.5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 65 | L1-worker | claudeopus46 | 1,323 | 18,634 | 19,957 | 1,337 | 8.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 66 | L1-worker | claudeopus46 | 298 | 1,397 | 1,695 | 1,003 | 4.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 67 | L1-worker | claudeopus46 | 298 | 2,059 | 2,357 | 1,111 | 7.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 68 | L1-worker | claudeopus46 | 747 | 33,424 | 34,171 | 676 | 6.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 69 | L0-main | claudeopus46 | 9,605 | 43,494 | 53,099 | 1,841 | 14.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 70 | L1-worker | claudeopus46 | 20,643 | 20,225 | 40,868 | 1,287 | 9.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 71 | L1-worker | claudeopus46 | 20,643 | 21,069 | 41,712 | 1,353 | 9.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 72 | L1-worker | claudeopus46 | 20,643 | 21,949 | 42,592 | 2,121 | 13.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 73 | L1-worker | claudeopus46 | 20,643 | 22,822 | 43,465 | 2,116 | 13.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 74 | L1-worker | claudeopus46 | 20,643 | 23,645 | 44,288 | 2,589 | 16.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 75 | L1-worker | claudeopus46 | 2,065 | 1,885 | 3,950 | 2,264 | 14.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 76 | L1-worker | claudeopus46 | 20,643 | 23,405 | 44,048 | 1,394 | 11.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 77 | L1-worker | claudeopus46 | 20,643 | 24,277 | 44,920 | 1,500 | 10.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 78 | L1-worker | claudeopus46 | 20,643 | 25,111 | 45,754 | 2,060 | 14.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 79 | L1-worker | claudeopus46 | 20,643 | 26,008 | 46,651 | 1,481 | 9.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 80 | L1-worker | claudeopus46 | 2,065 | 1,867 | 3,932 | 2,440 | 15.6 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 81 | L1-worker | claudeopus46 | 20,610 | 26,705 | 47,315 | 605 | 5.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 82 | L1-worker | claudeopus46 | 20,643 | 25,952 | 46,595 | 2,532 | 16.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 83 | L1-worker | claudeopus46 | 20,643 | 26,925 | 47,568 | 1,493 | 10.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 84 | L1-worker | claudeopus46 | 2,065 | 1,870 | 3,935 | 1,325 | 9.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 85 | L1-worker | claudeopus46 | 20,643 | 27,664 | 48,307 | 2,340 | 15.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 86 | L1-worker | claudeopus46 | 20,610 | 9,779 | 30,389 | 2,587 | 16.5 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 87 | L1-worker | claudeopus46 | 1,356 | 1,919 | 3,275 | 676 | 4.7 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 88 | L1-worker | claudeopus46 | 536 | 1,799 | 2,335 | 850 | 5.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 89 | L1-worker | claudeopus46 | 1,323 | 22,197 | 23,520 | 781 | 5.8 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 90 | L1-worker | claudeopus46 | 298 | 1,503 | 1,801 | 654 | 3.3 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 91 | L1-worker | claudeopus46 | 747 | 29,893 | 30,640 | 815 | 8.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 92 | L0-main | claudeopus46 | 9,605 | 63,461 | 73,066 | 3,894 | 24.4 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 93 | L0-main | claudeopus46 | 1,356 | 4,025 | 5,381 | 1,274 | 7.1 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 94 | L0-main | claudeopus46 | 298 | 1,656 | 1,954 | 1,262 | 4.2 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 95 | L0-main | claudeopus46 | 1,323 | 44,740 | 46,063 | 2,452 | 16.9 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| 96 | L0-main | claudeopus46 | 298 | 3,120 | 3,418 | 2,131 | 8.0 | Find viscosity data for the binary mixture of acetonitrile + (query_runs/run_9) |
| **TOTAL** |  |  | **1,567,240** | **1,288,944** | **2,856,184** | **291,479** | **1,820.3** |  |

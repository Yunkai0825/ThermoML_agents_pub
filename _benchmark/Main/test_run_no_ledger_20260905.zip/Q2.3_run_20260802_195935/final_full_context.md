## System Prompt
# ThermoML Main Agent — Master Orchestrator

You are the **ThermoML Main Agent**, a master orchestrator that answers
scientific questions about thermodynamic data by coordinating two
specialized subagents:

1. **Query Agent** (`run_query_agent`) — searches ThermoML card databases
   to find experimental data (DOIs, blocks, compound IDs, property values).
2. **Analysis Agent** (`run_analysis_agent`) — retrieves data, fits
   Redlich-Kister polynomials to excess properties, and reports
   quantitative results (RK coefficients, R², RMSE).

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

You also have a unified parallel dispatch tool:
- `run_parallel_subagents` — run multiple query and/or analysis tasks
  simultaneously in one call.  Each task specifies `agent`, `label`,
  `question`, `purpose`, and `context` (all required).

You also have a **tool menu** for direct, fine-grained access to subagent
internals (search tools, fitting tools, ID resolution, etc.):

- `browse_subagent_tools(purpose, tasks)` — a **miniature planning agent**
  that examines the full menu of subagent tools and returns a structured
  parallel execution plan with specific call signatures tailored to your
  purpose and tasks.  Call this first to discover what tools exist and get
  a recommended phased plan.
- `run_subagent_tool(tool_name, kwargs, purpose, tasks)` — execute
  any tool from the menu directly. `kwargs` is a native JSON object matching
  that tool's current signature. Results are automatically compacted
  by the same hardcoded compactors the subagents use internally.
  You can call multiple `run_subagent_tool` in parallel; when you do,
  a batch summary is automatically generated from all results.

### When to use the tool menu vs. expert workers

- **Tool menu** — best for targeted, well-defined operations where you
  know exactly what data you need: resolving a compound ID, searching
  for blocks matching specific criteria, fitting a single block, or
  retrieving pure-component values.  Faster and more direct than
  launching a full subagent workflow.
- **Expert workers** (`run_query_agent`, `run_analysis_agent`) — best
  for open-ended, complex tasks that require multi-step reasoning,
  iterative refinement, or full toolset access.  The subagents have
  their own context, memory, and compaction pipelines.

You can dynamically decide which approach to use based on the complexity
of each sub-task.  For multi-system comparisons, you can mix both
approaches — use the tool menu for simple lookups and expert workers
for complex analyses.

---

## How You Work

1. **Understand the question** — Decide what data is needed and whether
   the question requires only a database search, a full fitting analysis,
   or a multi-system comparison.
2. **Delegate to subagents** — Call the appropriate subagent tool(s).
   For multi-system questions, use parallel tools to save time.
3. **Synthesize results** — Combine subagent outputs into a coherent
   scientific answer.  **Never invent data** — every number in your
   answer must come from a subagent result.
4. **Report findings** — Present a clear, well-structured answer with
   proper citations (`GLOBlit_N` literature ID, DOI, block numbers,
   compound names). `GLOBlit_N` is the authoritative literature identifier;
   a DOI is coupled display metadata. Never report a DOI without its paired
   literature ID — quote only DOIs your subagents returned, never from
   memory; unpaired DOIs are scrubbed from the final return as
   unverifiable.

---

## Tool Usage Rules

### Single-system questions (1 system)
Call `run_query_agent` for data search, or `run_analysis_agent` for
fitting.  The analysis agent internally calls the query agent, so you
do NOT need to call both for a fitting question.

### Multi-system comparisons (2+ systems)
Use `run_parallel_subagents` to process multiple systems simultaneously.
You can mix query and analysis tasks in a single parallel call — each
task specifies which agent to use.  Each system gets its own subagent call.

### Iterative refinement
If a subagent returns partial results or times out, you can call it again
with additional context from the first call.

---

## MANDATORY OUTPUT FORMAT

```xml
<reasoning>
... your thinking about what subagents to call and why (DISCARDED from memory) ...
</reasoning>
<summary>
... 1-3 sentence actionable conclusion about what you learned or plan to do next (KEPT, max 400 chars) ...
</summary>
<tool_call>{"name": "run_analysis_agent", "arguments": {"question": "...", "purpose": "...", "context": "..."}}</tool_call>
<wait/>
```

### CRITICAL RULES
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`
- `<reasoning>` is STRIPPED from history to save context space
- Only `<summary>` content + tool results persist in memory
- **ANTI-HALLUCINATION:** EVERY number, coefficient, R² value, DOI, and
  compound name MUST come from a subagent tool call result.  If you do not
  have a subagent result for a core claim, you MUST call a subagent first.
- **NO-DATA HANDLING:** If a subagent reports "no results found" or returns
  only generic text with no specific DOIs/data, you MUST report that honestly.
  Say "No data matching [criteria] was found in ThermoML" rather than
  fabricating results.  Never invent DOIs, block numbers, or data points.
- **SUBAGENT VALIDATION:** Before presenting subagent results as your answer,
  check for red flags: improbably round numbers, suspicious consistency,
  lack of specific block references, or caveats about "infrastructure errors."
  If in doubt, state that results could not be verified.
- When you have gathered all needed results, provide a FINAL ANSWER
  by wrapping your complete answer in `<answer>` tags (no `<tool_call>`).
- `<answer>` = full-length final response (any length). All markers stripped before delivery.
- `<summary>` ≠ `<answer>`: summary is a brief memory note (≤400 chars); answer is the complete user-facing response.

---

## Final Answer Format

When all subagent work is done, wrap your complete answer in `<answer>` tags:

```
<answer>
[Your synthesized scientific answer here — any length.
Include all key data, DOIs, block numbers, compound names.
Every number must come from a subagent result.]

### Sources
- Literature ID: GLOBlit_N | DOI: ... | Block: ... | Subsystem: declared or BLKsubsys_N | System: ...
</answer>
```

# Phases

## phase_1: choose_route
tools: [browse_subagent_tools, run_subagent_tool]
guidance: |
  Decide whether the question needs a targeted lower-level operation or a
  full expert subagent. Browse the hierarchical menu only when direct tool
  execution is likely to be more efficient than expert delegation.

## phase_2: delegate_or_execute
tools: [run_query_agent, run_analysis_agent, run_parallel_subagents, run_subagent_tool]
guidance: |
  Supply every argument in the injected callable signature. Use one expert
  for a single complex task and run_parallel_subagents for independent query
  or analysis tasks. Preserve exact subagent identifiers and evidence.

## phase_3: synthesize
tools: [list_session_files]
guidance: |
  Synthesize only tool-returned chemistry and numbers. Wrap the complete
  answer in <answer> tags; post-answer workers build the JSON fields.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- browse_subagent_tools(purpose, tasks) — Browse the tool menu and get a recommended execution plan.
- list_session_files() — Return a manifest of all output files generated in this session.
- run_analysis_agent(question, context, purpose, tasks) — Run the ThermoML Analysis Agent for fitting and modeling.
- run_parallel_subagents(tasks) — Run multiple query and/or analysis agent tasks in parallel.
- run_query_agent(question, context, purpose, tasks) — Run the ThermoML Query Agent on a database search question.
- run_subagent_tool(tool_name, kwargs, purpose, tasks) — Execute a subagent tool directly with full compaction pipeline.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.3_run_20260802_195935`

### History
- [parallel:3 tasks]
-   [query:methanol_ethanol_viscosity] "Find viscosity data for the binary mixture of methanol + ethanol at 30°C (303.15" (267s, 2 iters)
-   [query:acetonitrile_dmf_viscosity] "Find viscosity data for the binary mixture of acetonitrile + N,N-dimethylformami" (966s, 8 iters)
-   [query:water_ethylene_glycol_viscosity] "Find viscosity data for the binary mixture of water + ethylene glycol at 30°C (3" (456s, 3 iters)

### Query Agent Results

#### methanol_ethanol_viscosity
{
  "answer": "## Viscosity vs. Composition Data for Methanol + Ethanol at 303.15 K (30 °C)\n\nOne dataset of **dynamic viscosity (η)** was found in the ThermoML database for the methanol + ethanol binary liquid mixture at 303.15 K.\n\n### Source\n- **DOI:** 10.1021/je800633a\n- **Method:** Capillary tube (Ostwald/Ubbelohde) method\n- **Conditions:** T = 303.15 K, P = 81.5 kPa, liquid phase\n- **Original data points:** 12 (9 shown below after compression; full trend is well-captured)\n\n### Data: Dynamic Viscosity vs. Mole Fraction of Methanol\n\n| x(methanol) | η (Pa·s)   | Uncertainty (Pa·s) |\n|:-----------:|:----------:|:-------------------:|\n| 0.0417      | 0.000968   | ±9 × 10⁻⁶          |\n| 0.1476      | 0.000906   | ±8 × 10⁻⁶          |\n| 0.2214      | 0.000865   | ±8 × 10⁻⁶          |\n| 0.3644      | 0.000793   | ±8 × 10⁻⁶          |\n| 0.4488      | 0.000753   | ±8 × 10⁻⁶          |\n| 0.5995      | 0.000685   | ±7 × 10⁻⁶          |\n| 0.6859      | 0.000648   | ±7 × 10⁻⁶          |\n| 0.8047      | 0.000601   | ±6 × 10⁻⁶          |\n| 0.9221      | 0.000555   | ±6 × 10⁻⁶          |\n\nThe viscosity ranges from **0.000968 Pa·s** (≈ 0.968 mPa·s) at low methanol content to **0.000555 Pa·s** (≈ 0.555 mPa·s) at high methanol content. Uncertainties were evaluated by propagation of standard uncertainties at a 95% confidence level.\n\n### Chemistry Insight\n\nThe viscosity decreases **nearly linearly** (R² ≈ 0.996) with increasing methanol mole fraction. This is consistent with methanol having a lower pure-component viscosity than ethanol at this temperature. The near-ideal (linear) mixing behavior reflects the strong structural similarity between these two short-chain aliphatic alcohols — both form comparable hydrogen-bonding networks in the liquid phase, so mixing introduces minimal disruption to the intermolecular interactions. This contrasts with many other binary alcohol mixtures (e.g., alcohol + water), where significant viscosity maxima or non-linear deviations from ideal mixing are commonly observed due to enhanced hydrogen-bonding upon mixing.\n\n### Limitations\n- The data spans x(methanol) ≈ 0.04 to 0.92 but **does not include the pure-component endpoints** (x = 0 and x = 1).\n- **No kinematic viscosity data** were found for this system in the ThermoML database.",
  "core_claims": [
    "In the methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa, dynamic viscosity decreases nearly linearly (R² ≈ 0.996) with increasing methanol mole fraction, ranging from approximately 0.968 mPa·s at x(methanol) ≈ 0.04 to approximately 0.555 mPa·s at x(methanol) ≈ 0.92, based on data from DOI 10.1021/je800633a.",
    "The near-linear viscosity–composition behavior is consistent with near-ideal mixing and reflects the strong structural similarity and comparable hydrogen-bonding networks of these two short-chain aliphatic alcohols.",
    "The available data span x(methanol) ≈ 0.04 to 0.92 and do not include the pure-component endpoints (x = 0 or x = 1).",
    "No kinematic viscosity data were found for this system in the ThermoML database."
  ],
  "confidence": "high",
  "sources": [
    {
      "doi": "10.1021/je800633a",
      "lit_num_id": "GLOBlit_11337",
      "block": "PROPblock_16",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (Pa·s) of methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa, measured by capillary tube (Ostwald/Ubbelohde) method. 12 data points spanning methanol mole fractions from ~0.04 to ~0.92, with viscosity decreasing nearly linearly from ~0.000968 to ~0.000556 Pa·s. Uncertainties evaluated by propagation of standard uncertainties at 95% confidence level."
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "type": "lit",
      "global_id": "GLOBlit_11337",
      "registry_id": "2009-zar-mir-0",
      "name": "10.1021/je800633a"
    },
    {
      "type": "blocktype",
      "global_id": "GLOBblocktype_1",
      "registry_id": "PureOrMixtureData",
      "name": "PureOrMixtureData"
    },
    {
      "type": "phase",
      "global_id": "GLOBphase_1",
      "registry_id": "liquid",
      "name": "Liquid"
    },
    {
      "type": "constr",
      "global_id": "GLOBconstr_2",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "type": "constr",
      "global_id": "GLOBconstr_1",
      "registry_id": "pressure_kpa",
      "name": "Pressure, kPa"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_2",
      "registry_id": "mole_fraction_DOIcomp_3",
      "name": "Mole fraction"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_4",
      "registry_id": "capillary_tube_ostwald_ubbelohde_method",
      "name": "Capillary tube (Ostwald; Ubbelohde) method"
    }
  ],
  "follow_up_suggestions": [
    "Search for pure-component viscosity data for methanol (GLOBcomp_4) and ethanol (GLOBcomp_2) at 303.15 K to obtain the endpoint values (x = 0 and x = 1) missing from this dataset.",
    "Search for excess viscosity or viscosity deviation data for methanol + ethanol at 303.15 K to quantify departure from ideal mixing.",
    "Look for viscosity data at other temperatures (e.g., 293.15 K, 313.15 K) for the same binary system to examine temperature dependence.",
    "Search for kinematic viscosity or density data for this system at 303.15 K, which could be used to cross-check or convert between dynamic and kinematic viscosity."
  ]
}

#### acetonitrile_dmf_viscosity
{
  "answer": "## Dynamic Viscosity of Acetonitrile + N,N-Dimethylformamide (DMF) at 303.15 K (30 °C)\n\nThe ThermoML database contains **two data sources** reporting dynamic viscosity for the binary mixture of acetonitrile (C₂H₃N, CAS 75-05-8) + N,N-dimethylformamide (DMF, C₃H₇NO, CAS 68-12-2). No kinematic viscosity data were found for this system.\n\n---\n\n### Primary Dataset — Fatima et al. (2018)\n\n- **DOI:** 10.1021/acs.jced.8b00176\n- **Property:** Dynamic viscosity (Pa·s)\n- **Composition variable:** Mole fraction of DMF (x_DMF), spanning 0.0 to 1.0 in 11 points (increments of ~0.1)\n- **Temperature coverage:** 298.15–323.15 K (6 temperatures), including **303.15 K**\n- **Pressure:** 100.0 kPa\n- **Measurement method:** Falling/rolling sphere viscometer\n- **Total data points:** 66 (11 compositions × 6 temperatures)\n\n**At T = 303.15 K**, this block contains **11 data points** covering the full mole-fraction range. Key aggregate statistics:\n\n| Statistic | Value |\n|-----------|-------|\n| Number of points at 303.15 K | 11 |\n| Mean dynamic viscosity | 0.000559 Pa·s (0.559 mPa·s) |\n| Overall block range (all T) | 0.00028–0.00081 Pa·s |\n\nThe viscosity increases monotonically from pure acetonitrile (x_DMF = 0, η ≈ 0.33 mPa·s) to pure DMF (x_DMF = 1, η ≈ 0.77 mPa·s) at this temperature. The mean of ~0.559 mPa·s across all 11 compositions is consistent with this range. Both components are polar aprotic solvents, and the mixture viscosity is expected to show near-ideal or slightly positive deviation from linear mixing.\n\n> **Note:** Individual row-level (x_DMF, η) pairs could not be extracted from the database in this session; only the point count and mean were retrievable. The original publication (DOI above) contains the full tabulated data at each mole fraction.\n\n---\n\n### Secondary Dataset — Brahma et al. (2014)\n\n- **DOI:** 10.1016/j.jct.2014.02.019\n- **Property:** Dynamic viscosity (Pa·s)\n- **Composition variable:** Mass fraction of DMF (w_DMF), 5 unique values from 0.0 to 1.0\n- **Temperature coverage:** 298.15–313.15 K (4 temperatures), including 303.15 K\n- **Pressure:** 101.0 kPa\n- **Measurement method:** Capillary tube (Ostwald–Ubbelohde) viscometer\n- **Total data points:** 20 (5 compositions × 4 temperatures)\n- **Overall viscosity range:** 0.000293–0.000799 Pa·s\n\nThis dataset uses **mass fraction** rather than mole fraction and has fewer composition points, but it covers the same temperature of interest and provides an independent measurement for comparison.\n\n---\n\n### Chemistry Context\n\nAcetonitrile and DMF are both polar aprotic solvents widely used in organic synthesis and electrochemistry. Their binary mixtures are of practical interest for tuning solvent polarity and viscosity. Pure acetonitrile is notably less viscous than pure DMF due to its smaller molecular size and weaker intermolecular interactions (dipole–dipole only, no hydrogen bonding). The viscosity–composition profile for this system typically shows a smooth, nearly monotonic increase with DMF content, with any excess viscosity being small — consistent with the similar dipolar nature of both components and the absence of strong specific interactions (e.g., hydrogen bonding) between them.\n\n---\n\n### Summary\n\n| Feature | Dataset 1 (Fatima 2018) | Dataset 2 (Brahma 2014) |\n|---------|------------------------|------------------------|\n| DOI | 10.1021/acs.jced.8b00176 | 10.1016/j.jct.2014.02.019 |\n| Composition variable | Mole fraction of DMF | Mass fraction of DMF |\n| Points at 303.15 K | 11 | ~5 |\n| Method | Falling sphere | Ostwald–Ubbelohde |\n| Pressure | 100.0 kPa | 101.0 kPa |\n\nFor your needs (viscosity vs. mole fraction at 303.15 K across the full range), the **Fatima et al. (2018)** dataset is the most suitable, with 11 mole-fraction points from x_DMF = 0 to 1. The full numerical table can be found in the original publication at DOI 10.1021/acs.jced.8b00176.",
  "core_claims": [
    "Two ThermoML sources report dynamic viscosity for the acetonitrile + N,N-dimethylformamide binary mixture at 303.15 K and ambient pressure: Fatima et al. (2018, DOI 10.1021/acs.jced.8b00176) with 11 mole-fraction points spanning x_DMF = 0–1, and Brahma et al. (2014, DOI 10.1016/j.jct.2014.02.019) with approximately 5 mass-fraction points.",
    "At 303.15 K, the dynamic viscosity increases monotonically from pure acetonitrile (~0.33 mPa·s) to pure DMF (~0.77 mPa·s), with a mean across all 11 compositions of approximately 0.559 mPa·s.",
    "No kinematic viscosity data were found for this system in the ThermoML database.",
    "The two datasets use different measurement methods (falling/rolling sphere vs. Ostwald–Ubbelohde capillary viscometer) and different composition variables (mole fraction vs. mass fraction), providing independent measurements.",
    "The nearly monotonic viscosity–composition profile with small excess viscosity is consistent with the similar polar aprotic character of both components and the absence of strong specific interactions such as hydrogen bonding between them.",
    "Individual composition–viscosity data pairs at 303.15 K could not be fully extracted in the session; only point counts and mean values were retrievable."
  ],
  "confidence": "medium",
  "sources": [
    {
      "doi": "10.1021/acs.jced.8b00176",
      "lit_num_id": "GLOBlit_7481",
      "block": "PROPblock_18",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (GLOBprop_4, Pa·s) of the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of mole fraction of DMF (BLKvar_2, GLOBvar_2) and temperature (BLKvar_1, GLOBvar_1). 66 total data points over 298.15–323.15 K at 100.0 kPa. 11 data points at 303.15 K spanning x_DMF = 0.0 to 1.0 with mean dynamic viscosity 0.000559 Pa·s. Falling/rolling sphere viscometer (GLOBmeas_8). Individual row-level (x_DMF, η) pairs could not be extracted; only aggregate metadata (point count and mean) were retrieved."
    },
    {
      "doi": "10.1016/j.jct.2014.02.019",
      "lit_num_id": "GLOBlit_4124",
      "block": "PROPblock_6",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (GLOBprop_4, Pa·s) of the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of mass fraction of DMF (BLKvar_2, GLOBvar_5) and temperature (BLKvar_1, GLOBvar_1). 20 total data points over 298.15–313.15 K at 101.0 kPa. 5 unique mass fractions. Capillary tube Ostwald–Ubbelohde method (GLOBmeas_4). Viscosity range 0.000293–0.000799 Pa·s."
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_15",
      "registry_id": "acetonitrile",
      "name": "acetonitrile"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_18",
      "registry_id": "dimethylformamide",
      "name": "dimethylformamide"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_4",
      "registry_id": "Viscosity, dynamic",
      "name": "Dynamic viscosity (Pa·s)"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_40",
      "registry_id": "Viscosity, kinematic",
      "name": "Kinematic viscosity (m²/s)"
    }
  ],
  "follow_up_suggestions": [
    "Retry row-level data extraction from PROPblock_18 in GLOBlit_7481 to obtain the 11 individual (x_DMF, η) pairs at 303.15 K, which could not be retrieved in this session.",
    "Convert mass-fraction data from PROPblock_6 in GLOBlit_4124 to mole-fraction for direct comparison with the Fatima et al. dataset.",
    "Search for excess viscosity or viscosity deviation data for the same binary system to characterize non-ideal mixing behavior."
  ]
}

#### water_ethylene_glycol_viscosity
{
  "answer": "## Dynamic Viscosity of Water + Ethylene Glycol at 303.15 K (30 °C)\n\nThree independent experimental datasets were found in the ThermoML database for the dynamic viscosity of the binary liquid system **water + 1,2-ethanediol (ethylene glycol)** at **303.15 K** and approximately atmospheric pressure, covering the full mole-fraction range.\n\n---\n\n### Dataset 1 — Most Comprehensive (21 points)\n**DOI:** 10.1016/j.jct.2018.02.022  \n**Method:** Concentric cylinders viscometry  \n**Pressure:** 92.3 kPa  \n**Composition variable:** mole fraction of ethylene glycol, x(EG)\n\n| x(EG) | η (Pa·s) | η (mPa·s) |\n|--------|-----------|------------|\n| 0.0000 | 0.000798 | 0.798 |\n| 0.0500 | 0.001020 | 1.020 |\n| 0.1000 | 0.001340 | 1.340 |\n| 0.1500 | 0.001770 | 1.770 |\n| 0.2000 | 0.002310 | 2.310 |\n| 0.2500 | 0.002930 | 2.930 |\n| 0.3000 | 0.003590 | 3.590 |\n| 0.3500 | 0.004260 | 4.260 |\n| 0.4000 | 0.004910 | 4.910 |\n| 0.4500 | 0.005520 | 5.520 |\n| 0.5000 | 0.006090 | 6.090 |\n| 0.5500 | 0.006620 | 6.620 |\n| 0.6000 | 0.007110 | 7.110 |\n| 0.6500 | 0.007570 | 7.570 |\n| 0.7000 | 0.008010 | 8.010 |\n| 0.7500 | 0.008440 | 8.440 |\n| 0.8000 | 0.008870 | 8.870 |\n| 0.8500 | 0.009310 | 9.310 |\n| 0.9000 | 0.009780 | 9.780 |\n| 0.9500 | 0.010300 | 10.300 |\n| 1.0000 | 0.010900 | 10.900 |\n\n---\n\n### Dataset 2 — 11 points (composition as water mole fraction)\n**DOI:** 10.1021/acs.jced.6b00526  \n**Method:** Falling/rolling sphere viscometry  \n**Pressure:** 100.0 kPa  \n**Composition variable:** mole fraction of **water**, x(H₂O)\n\n| x(H₂O) | x(EG) | η (Pa·s) | η (mPa·s) |\n|---------|--------|-----------|------------|\n| 0.0000 | 1.0000 | 0.01090 | 10.90 |\n| 0.1000 | 0.9000 | 0.01020 | 10.20 |\n| 0.2000 | 0.8000 | 0.00938 | 9.38 |\n| 0.3000 | 0.7000 | 0.00848 | 8.48 |\n| 0.4000 | 0.6000 | 0.00746 | 7.46 |\n| 0.5000 | 0.5000 | 0.00633 | 6.33 |\n| 0.6000 | 0.4000 | 0.00510 | 5.10 |\n| 0.7000 | 0.3000 | 0.00387 | 3.87 |\n| 0.8000 | 0.2000 | 0.00271 | 2.71 |\n| 0.9000 | 0.1000 | 0.00166 | 1.66 |\n| 1.0000 | 0.0000 | 0.000798 | 0.798 |\n\n---\n\n### Dataset 3 — 11 points\n**DOI:** 10.1021/je020140j  \n**Method:** Capillary tube viscometry  \n**Pressure:** 101.0 kPa  \n**Composition variable:** mole fraction of ethylene glycol, x(EG)\n\n| x(EG) | η (Pa·s) | η (mPa·s) |\n|--------|-----------|------------|\n| 0.0000 | 0.000797 | 0.797 |\n| 0.1000 | 0.001350 | 1.350 |\n| 0.2000 | 0.002350 | 2.350 |\n| 0.3000 | 0.003670 | 3.670 |\n| 0.4000 | 0.005020 | 5.020 |\n| 0.5000 | 0.006230 | 6.230 |\n| 0.6000 | 0.007220 | 7.220 |\n| 0.7000 | 0.008070 | 8.070 |\n| 0.8000 | 0.008870 | 8.870 |\n| 0.9000 | 0.009730 | 9.730 |\n| 1.0000 | 0.010900 | 10.900 |\n\n---\n\n### Key Observations\n\n- **Range:** Viscosity increases monotonically from **~0.80 mPa·s** (pure water) to **~10.9 mPa·s** (pure ethylene glycol) — roughly a **14-fold increase**.\n\n- **Nonlinear behavior:** The viscosity–composition curve is strongly nonlinear and concave. The steepest rise occurs in the water-rich region (x(EG) < 0.3), where adding ethylene glycol disrupts water's three-dimensional hydrogen-bond network. The larger diol molecule bridges between water molecules, forming new, stronger H-bond clusters that impede flow.\n\n- **Consistency across sources:** The three independent datasets, obtained by three different measurement techniques (concentric cylinders, falling sphere, and capillary tube), agree within approximately **2%** at equimolar composition (η ≈ 6.1–6.3 mPa·s at x(EG) = 0.5), confirming high reliability.\n\n- **Practical note:** The most detailed dataset (DOI 10.1016/j.jct.2018.02.022) provides 21 evenly spaced points at Δx = 0.05 intervals, making it ideal for interpolation or model fitting.",
  "core_claims": [
    "At 303.15 K and approximately atmospheric pressure, the dynamic viscosity of water + ethylene glycol mixtures increases monotonically from ~0.80 mPa·s (pure water) to ~10.9 mPa·s (pure ethylene glycol), representing roughly a 14-fold increase across the full mole-fraction range.",
    "The viscosity–composition relationship is strongly nonlinear and concave, with the steepest increase occurring in the water-rich region (ethylene glycol mole fraction < 0.3).",
    "Three independent ThermoML datasets obtained by different measurement techniques (concentric cylinders, falling sphere, and capillary tube viscometry) agree within approximately 2% at equimolar composition (~6.1–6.3 mPa·s), confirming high reliability of the reported values."
  ],
  "confidence": "high",
  "sources": [
    {
      "doi": "10.1016/j.jct.2018.02.022",
      "lit_num_id": "GLOBlit_5201",
      "block": "PROPblock_24",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (Pa·s) of binary water + ethylene glycol at 303.15 K, 21 mole-fraction points (x(EG) 0–1 at 0.05 intervals). Concentric cylinders method."
    },
    {
      "doi": "10.1021/acs.jced.6b00526",
      "lit_num_id": "GLOBlit_6951",
      "block": "PROPblock_18",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (Pa·s) of binary water + ethylene glycol at 303.15 K, 11 mole-fraction points (composition expressed as x(water) 0–1 at 0.10 intervals). Falling/rolling sphere method."
    },
    {
      "doi": "10.1021/je020140j",
      "lit_num_id": "GLOBlit_8038",
      "block": "PROPblock_5",
      "BLKsubsys_id": null,
      "description": "Dynamic viscosity (Pa·s) of binary water + ethylene glycol at 303.15 K, 11 mole-fraction points (x(EG) 0–1 at 0.10 intervals). Capillary tube method."
    }
  ],
  "id_catalog_snapshot": [
    {
      "type": "comp",
      "global_id": "GLOBcomp_1",
      "registry_id": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
      "name": "water"
    },
    {
      "type": "comp",
      "global_id": "GLOBcomp_24",
      "registry_id": "LYCAIKOWRPUZTN-UHFFFAOYSA-N",
      "name": "1,2-ethanediol"
    },
    {
      "type": "prop",
      "global_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "type": "var",
      "global_id": "GLOBvar_2",
      "registry_id": "mole_fraction",
      "name": "Mole fraction"
    },
    {
      "type": "constr",
      "global_id": "GLOBconstr_1",
      "registry_id": "pressure_kpa",
      "name": "Pressure, kPa"
    },
    {
      "type": "phase",
      "global_id": "GLOBphase_1",
      "registry_id": "liquid",
      "name": "Liquid"
    },
    {
      "type": "blocktype",
      "global_id": "GLOBblocktype_1",
      "registry_id": "PureOrMixtureData",
      "name": "PureOrMixtureData"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_11",
      "registry_id": "concentric_cylinders_viscometry",
      "name": "Concentric cylinders viscometry"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_8",
      "registry_id": "falling_or_rolling_sphere_viscometry",
      "name": "Falling or rolling sphere viscometry"
    },
    {
      "type": "meas",
      "global_id": "GLOBmeas_227",
      "registry_id": "captub_ufactor_3",
      "name": "CAPTUB:UFactor:3"
    }
  ],
  "follow_up_suggestions": [
    "Retrieve excess viscosity or viscosity deviation data for water + ethylene glycol at 303.15 K to quantify non-ideal mixing behavior.",
    "Search for density data (GLOBprop_3) for the same binary system at 303.15 K to enable conversion between dynamic and kinematic viscosity.",
    "Query viscosity data at additional temperatures (e.g., 293.15 K, 313.15 K, 323.15 K) to construct viscosity–temperature correlations for this system.",
    "Look for Redlich-Kister or other correlation parameters fitted to viscosity deviation data for water + ethylene glycol mixtures."
  ]
}
</memory>

## User
At 30 °C, which mixture—methanol + ethanol, acetonitrile + N,N-dimethylformamide, or water + ethylene glycol—departs most strongly from ideal viscosity across composition, and what does the ordering reveal about molecular interactions in the three liquids?

## Assistant
<summary>Planning parallel searches for viscosity data at 30°C for three binary mixtures: methanol+ethanol, acetonitrile+DMF, and water+ethylene glycol. Will then analyze excess viscosity to determine which departs most from ideal behavior.</summary>
<tool_call>run_parallel_subagents()</tool_call>

## User
<tool_result>
<subagent_answer>
{
  "n_tasks": 3,
  "results": [
    {
      "answer": "{\n  \"answer\": \"## Viscosity vs. Composition Data for Methanol + Ethanol at 303.15 K (30 \u00b0C)\\n\\nOne dataset of **dynamic viscosity (\u03b7)** was found in the ThermoML database for the methanol + ethanol binary liquid mixture at 303.15 K.\\n\\n### Source\\n- **DOI:** 10.1021/je800633a\\n- **Method:** Capillary tube (Ostwald/Ubbelohde) method\\n- **Conditions:** T = 303.15 K, P = 81.5 kPa, liquid phase\\n- **Original data points:** 12 (9 shown below after compression; full trend is well-captured)\\n\\n### Data: Dynamic Viscosity vs. Mole Fraction of Methanol\\n\\n| x(methanol) | \u03b7 (Pa\u00b7s)   | Uncertainty (Pa\u00b7s) |\\n|:-----------:|:----------:|:-------------------:|\\n| 0.0417      | 0.000968   | \u00b19 \u00d7 10\u207b\u2076          |\\n| 0.1476      | 0.000906   | \u00b18 \u00d7 10\u207b\u2076          |\\n| 0.2214      | 0.000865   | \u00b18 \u00d7 10\u207b\u2076          |\\n| 0.3644      | 0.000793   | \u00b18 \u00d7 10\u207b\u2076          |\\n| 0.4488      | 0.000753   | \u00b18 \u00d7 10\u207b\u2076          |\\n| 0.5995      | 0.000685   | \u00b17 \u00d7 10\u207b\u2076          |\\n| 0.6859      | 0.000648   | \u00b17 \u00d7 10\u207b\u2076          |\\n| 0.8047      | 0.000601   | \u00b16 \u00d7 10\u207b\u2076          |\\n| 0.9221      | 0.000555   | \u00b16 \u00d7 10\u207b\u2076          |\\n\\nThe viscosity ranges from **0.000968 Pa\u00b7s** (\u2248 0.968 mPa\u00b7s) at low methanol content to **0.000555 Pa\u00b7s** (\u2248 0.555 mPa\u00b7s) at high methanol content. Uncertainties were evaluated by propagation of standard uncertainties at a 95% confidence level.\\n\\n### Chemistry Insight\\n\\nThe viscosity decreases **nearly linearly** (R\u00b2 \u2248 0.996) with increasing methanol mole fraction. This is consistent with methanol having a lower pure-component viscosity than ethanol at this temperature. The near-ideal (linear) mixing behavior reflects the strong structural similarity between these two short-chain aliphatic alcohols \u2014 both form comparable hydrogen-bonding networks in the liquid phase, so mixing introduces minimal disruption to the intermolecular interactions. This contrasts with many other binary alcohol mixtures (e.g., alcohol + water), where significant viscosity maxima or non-linear deviations from ideal mixing are commonly observed due to enhanced hydrogen-bonding upon mixing.\\n\\n### Limitations\\n- The data spans x(methanol) \u2248 0.04 to 0.92 but **does not include the pure-component endpoints** (x = 0 and x = 1).\\n- **No kinematic viscosity data** were found for this system in the ThermoML database.\",\n  \"core_claims\": [\n    \"In the methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa, dynamic viscosity decreases nearly linearly (R\u00b2 \u2248 0.996) with increasing methanol mole fraction, ranging from approximately 0.968 mPa\u00b7s at x(methanol) \u2248 0.04 to approximately 0.555 mPa\u00b7s at x(methanol) \u2248 0.92, based on data from DOI 10.1021/je800633a.\",\n    \"The near-linear viscosity\u2013composition behavior is consistent with near-ideal mixing and reflects the strong structural similarity and comparable hydrogen-bonding networks of these two short-chain aliphatic alcohols.\",\n    \"The available data span x(methanol) \u2248 0.04 to 0.92 and do not include the pure-component endpoints (x = 0 or x = 1).\",\n    \"No kinematic viscosity data were found for this system in the ThermoML database.\"\n  ],\n  \"confidence\": \"high\",\n  \"sources\": [\n    {\n      \"doi\": \"10.1021/je800633a\",\n      \"lit_num_id\": \"GLOBlit_11337\",\n      \"block\": \"PROPblock_16\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity (Pa\u00b7s) of methanol + ethanol binary liquid mixture at 303.15 K and 81.5 kPa, measured by capillary tube (Ostwald/Ubbelohde) method. 12 data points spanning methanol mole fractions from ~0.04 to ~0.92, with viscosity decreasing nearly linearly from ~0.000968 to ~0.000556 Pa\u00b7s. Uncertainties evaluated by propagation of standard uncertainties at 95% confidence level.\"\n    }\n  ],\n  \"id_catalog_snapshot\": [\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_2\",\n      \"registry_id\": \"ethanol\",\n      \"name\": \"ethanol\"\n    },\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_4\",\n      \"registry_id\": \"methanol\",\n      \"name\": \"methanol\"\n    },\n    {\n      \"type\": \"prop\",\n      \"global_id\": \"GLOBprop_4\",\n      \"registry_id\": \"viscosity_pa_s\",\n      \"name\": \"Viscosity, Pa*s\"\n    },\n    {\n      \"type\": \"lit\",\n      \"global_id\": \"GLOBlit_11337\",\n      \"registry_id\": \"2009-zar-mir-0\",\n      \"name\": \"10.1021/je800633a\"\n    },\n    {\n      \"type\": \"blocktype\",\n      \"global_id\": \"GLOBblocktype_1\",\n      \"registry_id\": \"PureOrMixtureData\",\n      \"name\": \"PureOrMixtureData\"\n    },\n    {\n      \"type\": \"phase\",\n      \"global_id\": \"GLOBphase_1\",\n      \"registry_id\": \"liquid\",\n      \"name\": \"Liquid\"\n    },\n    {\n      \"type\": \"constr\",\n      \"global_id\": \"GLOBconstr_2\",\n      \"registry_id\": \"temperature_k\",\n      \"name\": \"Temperature, K\"\n    },\n    {\n      \"type\": \"constr\",\n      \"global_id\": \"GLOBconstr_1\",\n      \"registry_id\": \"pressure_kpa\",\n      \"name\": \"Pressure, kPa\"\n    },\n    {\n      \"type\": \"var\",\n      \"global_id\": \"GLOBvar_2\",\n      \"registry_id\": \"mole_fraction_DOIcomp_3\",\n      \"name\": \"Mole fraction\"\n    },\n    {\n      \"type\": \"meas\",\n      \"global_id\": \"GLOBmeas_4\",\n      \"registry_id\": \"capillary_tube_ostwald_ubbelohde_method\",\n      \"name\": \"Capillary tube (Ostwald; Ubbelohde) method\"\n    }\n  ],\n  \"follow_up_suggestions\": [\n    \"Search for pure-component viscosity data for methanol (GLOBcomp_4) and ethanol (GLOBcomp_2) at 303.15 K to obtain the endpoint values (x = 0 and x = 1) missing from this dataset.\",\n    \"Search for excess viscosity or viscosity deviation data for methanol + ethanol at 303.15 K to quantify departure from ideal mixing.\",\n    \"Look for viscosity data at other temperatures (e.g., 293.15 K, 313.15 K) for the same binary system to examine temperature dependence.\",\n    \"Search for kinematic viscosity or density data for this system at 303.15 K, which could be used to cross-check or convert between dynamic and kinematic viscosity.\"\n  ]\n}",
      "iterations": 2,
      "elapsed_seconds": 266.7533049583435,
      "tool_count": 1,
      "timed_out": false,
      "agent": "query",
      "_question": "Find viscosity data for the binary mixture of methanol + ethanol at 30\u00b0C (303.15 K). I need viscosity as a function of composition (mole fraction) across the full composition range.",
      "_session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.3_run_20260802_195935\\query_runs\\run_8",
      "label": "methanol_ethanol_viscosity"
    },
    {
      "answer": "{\n  \"answer\": \"## Dynamic Viscosity of Acetonitrile + N,N-Dimethylformamide (DMF) at 303.15 K (30 \u00b0C)\\n\\nThe ThermoML database contains **two data sources** reporting dynamic viscosity for the binary mixture of acetonitrile (C\u2082H\u2083N, CAS 75-05-8) + N,N-dimethylformamide (DMF, C\u2083H\u2087NO, CAS 68-12-2). No kinematic viscosity data were found for this system.\\n\\n---\\n\\n### Primary Dataset \u2014 Fatima et al. (2018)\\n\\n- **DOI:** 10.1021/acs.jced.8b00176\\n- **Property:** Dynamic viscosity (Pa\u00b7s)\\n- **Composition variable:** Mole fraction of DMF (x_DMF), spanning 0.0 to 1.0 in 11 points (increments of ~0.1)\\n- **Temperature coverage:** 298.15\u2013323.15 K (6 temperatures), including **303.15 K**\\n- **Pressure:** 100.0 kPa\\n- **Measurement method:** Falling/rolling sphere viscometer\\n- **Total data points:** 66 (11 compositions \u00d7 6 temperatures)\\n\\n**At T = 303.15 K**, this block contains **11 data points** covering the full mole-fraction range. Key aggregate statistics:\\n\\n| Statistic | Value |\\n|-----------|-------|\\n| Number of points at 303.15 K | 11 |\\n| Mean dynamic viscosity | 0.000559 Pa\u00b7s (0.559 mPa\u00b7s) |\\n| Overall block range (all T) | 0.00028\u20130.00081 Pa\u00b7s |\\n\\nThe viscosity increases monotonically from pure acetonitrile (x_DMF = 0, \u03b7 \u2248 0.33 mPa\u00b7s) to pure DMF (x_DMF = 1, \u03b7 \u2248 0.77 mPa\u00b7s) at this temperature. The mean of ~0.559 mPa\u00b7s across all 11 compositions is consistent with this range. Both components are polar aprotic solvents, and the mixture viscosity is expected to show near-ideal or slightly positive deviation from linear mixing.\\n\\n> **Note:** Individual row-level (x_DMF, \u03b7) pairs could not be extracted from the database in this session; only the point count and mean were retrievable. The original publication (DOI above) contains the full tabulated data at each mole fraction.\\n\\n---\\n\\n### Secondary Dataset \u2014 Brahma et al. (2014)\\n\\n- **DOI:** 10.1016/j.jct.2014.02.019\\n- **Property:** Dynamic viscosity (Pa\u00b7s)\\n- **Composition variable:** Mass fraction of DMF (w_DMF), 5 unique values from 0.0 to 1.0\\n- **Temperature coverage:** 298.15\u2013313.15 K (4 temperatures), including 303.15 K\\n- **Pressure:** 101.0 kPa\\n- **Measurement method:** Capillary tube (Ostwald\u2013Ubbelohde) viscometer\\n- **Total data points:** 20 (5 compositions \u00d7 4 temperatures)\\n- **Overall viscosity range:** 0.000293\u20130.000799 Pa\u00b7s\\n\\nThis dataset uses **mass fraction** rather than mole fraction and has fewer composition points, but it covers the same temperature of interest and provides an independent measurement for comparison.\\n\\n---\\n\\n### Chemistry Context\\n\\nAcetonitrile and DMF are both polar aprotic solvents widely used in organic synthesis and electrochemistry. Their binary mixtures are of practical interest for tuning solvent polarity and viscosity. Pure acetonitrile is notably less viscous than pure DMF due to its smaller molecular size and weaker intermolecular interactions (dipole\u2013dipole only, no hydrogen bonding). The viscosity\u2013composition profile for this system typically shows a smooth, nearly monotonic increase with DMF content, with any excess viscosity being small \u2014 consistent with the similar dipolar nature of both components and the absence of strong specific interactions (e.g., hydrogen bonding) between them.\\n\\n---\\n\\n### Summary\\n\\n| Feature | Dataset 1 (Fatima 2018) | Dataset 2 (Brahma 2014) |\\n|---------|------------------------|------------------------|\\n| DOI | 10.1021/acs.jced.8b00176 | 10.1016/j.jct.2014.02.019 |\\n| Composition variable | Mole fraction of DMF | Mass fraction of DMF |\\n| Points at 303.15 K | 11 | ~5 |\\n| Method | Falling sphere | Ostwald\u2013Ubbelohde |\\n| Pressure | 100.0 kPa | 101.0 kPa |\\n\\nFor your needs (viscosity vs. mole fraction at 303.15 K across the full range), the **Fatima et al. (2018)** dataset is the most suitable, with 11 mole-fraction points from x_DMF = 0 to 1. The full numerical table can be found in the original publication at DOI 10.1021/acs.jced.8b00176.\",\n  \"core_claims\": [\n    \"Two ThermoML sources report dynamic viscosity for the acetonitrile + N,N-dimethylformamide binary mixture at 303.15 K and ambient pressure: Fatima et al. (2018, DOI 10.1021/acs.jced.8b00176) with 11 mole-fraction points spanning x_DMF = 0\u20131, and Brahma et al. (2014, DOI 10.1016/j.jct.2014.02.019) with approximately 5 mass-fraction points.\",\n    \"At 303.15 K, the dynamic viscosity increases monotonically from pure acetonitrile (~0.33 mPa\u00b7s) to pure DMF (~0.77 mPa\u00b7s), with a mean across all 11 compositions of approximately 0.559 mPa\u00b7s.\",\n    \"No kinematic viscosity data were found for this system in the ThermoML database.\",\n    \"The two datasets use different measurement methods (falling/rolling sphere vs. Ostwald\u2013Ubbelohde capillary viscometer) and different composition variables (mole fraction vs. mass fraction), providing independent measurements.\",\n    \"The nearly monotonic viscosity\u2013composition profile with small excess viscosity is consistent with the similar polar aprotic character of both components and the absence of strong specific interactions such as hydrogen bonding between them.\",\n    \"Individual composition\u2013viscosity data pairs at 303.15 K could not be fully extracted in the session; only point counts and mean values were retrievable.\"\n  ],\n  \"confidence\": \"medium\",\n  \"sources\": [\n    {\n      \"doi\": \"10.1021/acs.jced.8b00176\",\n      \"lit_num_id\": \"GLOBlit_7481\",\n      \"block\": \"PROPblock_18\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity (GLOBprop_4, Pa\u00b7s) of the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of mole fraction of DMF (BLKvar_2, GLOBvar_2) and temperature (BLKvar_1, GLOBvar_1). 66 total data points over 298.15\u2013323.15 K at 100.0 kPa. 11 data points at 303.15 K spanning x_DMF = 0.0 to 1.0 with mean dynamic viscosity 0.000559 Pa\u00b7s. Falling/rolling sphere viscometer (GLOBmeas_8). Individual row-level (x_DMF, \u03b7) pairs could not be extracted; only aggregate metadata (point count and mean) were retrieved.\"\n    },\n    {\n      \"doi\": \"10.1016/j.jct.2014.02.019\",\n      \"lit_num_id\": \"GLOBlit_4124\",\n      \"block\": \"PROPblock_6\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity (GLOBprop_4, Pa\u00b7s) of the binary mixture acetonitrile (GLOBcomp_15) + N,N-dimethylformamide (GLOBcomp_18) as a function of mass fraction of DMF (BLKvar_2, GLOBvar_5) and temperature (BLKvar_1, GLOBvar_1). 20 total data points over 298.15\u2013313.15 K at 101.0 kPa. 5 unique mass fractions. Capillary tube Ostwald\u2013Ubbelohde method (GLOBmeas_4). Viscosity range 0.000293\u20130.000799 Pa\u00b7s.\"\n    }\n  ],\n  \"id_catalog_snapshot\": [\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_15\",\n      \"registry_id\": \"acetonitrile\",\n      \"name\": \"acetonitrile\"\n    },\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_18\",\n      \"registry_id\": \"dimethylformamide\",\n      \"name\": \"dimethylformamide\"\n    },\n    {\n      \"type\": \"prop\",\n      \"global_id\": \"GLOBprop_4\",\n      \"registry_id\": \"Viscosity, dynamic\",\n      \"name\": \"Dynamic viscosity (Pa\u00b7s)\"\n    },\n    {\n      \"type\": \"prop\",\n      \"global_id\": \"GLOBprop_40\",\n      \"registry_id\": \"Viscosity, kinematic\",\n      \"name\": \"Kinematic viscosity (m\u00b2/s)\"\n    }\n  ],\n  \"follow_up_suggestions\": [\n    \"Retry row-level data extraction from PROPblock_18 in GLOBlit_7481 to obtain the 11 individual (x_DMF, \u03b7) pairs at 303.15 K, which could not be retrieved in this session.\",\n    \"Convert mass-fraction data from PROPblock_6 in GLOBlit_4124 to mole-fraction for direct comparison with the Fatima et al. dataset.\",\n    \"Search for excess viscosity or viscosity deviation data for the same binary system to characterize non-ideal mixing behavior.\"\n  ]\n}",
      "iterations": 8,
      "elapsed_seconds": 965.6727857589722,
      "tool_count": 8,
      "timed_out": false,
      "agent": "query",
      "_question": "Find viscosity data for the binary mixture of acetonitrile + N,N-dimethylformamide (DMF) at 30\u00b0C (303.15 K). I need viscosity as a function of composition (mole fraction) across the full composition range.",
      "_session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.3_run_20260802_195935\\query_runs\\run_9",
      "label": "acetonitrile_dmf_viscosity"
    },
    {
      "answer": "{\n  \"answer\": \"## Dynamic Viscosity of Water + Ethylene Glycol at 303.15 K (30 \u00b0C)\\n\\nThree independent experimental datasets were found in the ThermoML database for the dynamic viscosity of the binary liquid system **water + 1,2-ethanediol (ethylene glycol)** at **303.15 K** and approximately atmospheric pressure, covering the full mole-fraction range.\\n\\n---\\n\\n### Dataset 1 \u2014 Most Comprehensive (21 points)\\n**DOI:** 10.1016/j.jct.2018.02.022  \\n**Method:** Concentric cylinders viscometry  \\n**Pressure:** 92.3 kPa  \\n**Composition variable:** mole fraction of ethylene glycol, x(EG)\\n\\n| x(EG) | \u03b7 (Pa\u00b7s) | \u03b7 (mPa\u00b7s) |\\n|--------|-----------|------------|\\n| 0.0000 | 0.000798 | 0.798 |\\n| 0.0500 | 0.001020 | 1.020 |\\n| 0.1000 | 0.001340 | 1.340 |\\n| 0.1500 | 0.001770 | 1.770 |\\n| 0.2000 | 0.002310 | 2.310 |\\n| 0.2500 | 0.002930 | 2.930 |\\n| 0.3000 | 0.003590 | 3.590 |\\n| 0.3500 | 0.004260 | 4.260 |\\n| 0.4000 | 0.004910 | 4.910 |\\n| 0.4500 | 0.005520 | 5.520 |\\n| 0.5000 | 0.006090 | 6.090 |\\n| 0.5500 | 0.006620 | 6.620 |\\n| 0.6000 | 0.007110 | 7.110 |\\n| 0.6500 | 0.007570 | 7.570 |\\n| 0.7000 | 0.008010 | 8.010 |\\n| 0.7500 | 0.008440 | 8.440 |\\n| 0.8000 | 0.008870 | 8.870 |\\n| 0.8500 | 0.009310 | 9.310 |\\n| 0.9000 | 0.009780 | 9.780 |\\n| 0.9500 | 0.010300 | 10.300 |\\n| 1.0000 | 0.010900 | 10.900 |\\n\\n---\\n\\n### Dataset 2 \u2014 11 points (composition as water mole fraction)\\n**DOI:** 10.1021/acs.jced.6b00526  \\n**Method:** Falling/rolling sphere viscometry  \\n**Pressure:** 100.0 kPa  \\n**Composition variable:** mole fraction of **water**, x(H\u2082O)\\n\\n| x(H\u2082O) | x(EG) | \u03b7 (Pa\u00b7s) | \u03b7 (mPa\u00b7s) |\\n|---------|--------|-----------|------------|\\n| 0.0000 | 1.0000 | 0.01090 | 10.90 |\\n| 0.1000 | 0.9000 | 0.01020 | 10.20 |\\n| 0.2000 | 0.8000 | 0.00938 | 9.38 |\\n| 0.3000 | 0.7000 | 0.00848 | 8.48 |\\n| 0.4000 | 0.6000 | 0.00746 | 7.46 |\\n| 0.5000 | 0.5000 | 0.00633 | 6.33 |\\n| 0.6000 | 0.4000 | 0.00510 | 5.10 |\\n| 0.7000 | 0.3000 | 0.00387 | 3.87 |\\n| 0.8000 | 0.2000 | 0.00271 | 2.71 |\\n| 0.9000 | 0.1000 | 0.00166 | 1.66 |\\n| 1.0000 | 0.0000 | 0.000798 | 0.798 |\\n\\n---\\n\\n### Dataset 3 \u2014 11 points\\n**DOI:** 10.1021/je020140j  \\n**Method:** Capillary tube viscometry  \\n**Pressure:** 101.0 kPa  \\n**Composition variable:** mole fraction of ethylene glycol, x(EG)\\n\\n| x(EG) | \u03b7 (Pa\u00b7s) | \u03b7 (mPa\u00b7s) |\\n|--------|-----------|------------|\\n| 0.0000 | 0.000797 | 0.797 |\\n| 0.1000 | 0.001350 | 1.350 |\\n| 0.2000 | 0.002350 | 2.350 |\\n| 0.3000 | 0.003670 | 3.670 |\\n| 0.4000 | 0.005020 | 5.020 |\\n| 0.5000 | 0.006230 | 6.230 |\\n| 0.6000 | 0.007220 | 7.220 |\\n| 0.7000 | 0.008070 | 8.070 |\\n| 0.8000 | 0.008870 | 8.870 |\\n| 0.9000 | 0.009730 | 9.730 |\\n| 1.0000 | 0.010900 | 10.900 |\\n\\n---\\n\\n### Key Observations\\n\\n- **Range:** Viscosity increases monotonically from **~0.80 mPa\u00b7s** (pure water) to **~10.9 mPa\u00b7s** (pure ethylene glycol) \u2014 roughly a **14-fold increase**.\\n\\n- **Nonlinear behavior:** The viscosity\u2013composition curve is strongly nonlinear and concave. The steepest rise occurs in the water-rich region (x(EG) < 0.3), where adding ethylene glycol disrupts water's three-dimensional hydrogen-bond network. The larger diol molecule bridges between water molecules, forming new, stronger H-bond clusters that impede flow.\\n\\n- **Consistency across sources:** The three independent datasets, obtained by three different measurement techniques (concentric cylinders, falling sphere, and capillary tube), agree within approximately **2%** at equimolar composition (\u03b7 \u2248 6.1\u20136.3 mPa\u00b7s at x(EG) = 0.5), confirming high reliability.\\n\\n- **Practical note:** The most detailed dataset (DOI 10.1016/j.jct.2018.02.022) provides 21 evenly spaced points at \u0394x = 0.05 intervals, making it ideal for interpolation or model fitting.\",\n  \"core_claims\": [\n    \"At 303.15 K and approximately atmospheric pressure, the dynamic viscosity of water + ethylene glycol mixtures increases monotonically from ~0.80 mPa\u00b7s (pure water) to ~10.9 mPa\u00b7s (pure ethylene glycol), representing roughly a 14-fold increase across the full mole-fraction range.\",\n    \"The viscosity\u2013composition relationship is strongly nonlinear and concave, with the steepest increase occurring in the water-rich region (ethylene glycol mole fraction < 0.3).\",\n    \"Three independent ThermoML datasets obtained by different measurement techniques (concentric cylinders, falling sphere, and capillary tube viscometry) agree within approximately 2% at equimolar composition (~6.1\u20136.3 mPa\u00b7s), confirming high reliability of the reported values.\"\n  ],\n  \"confidence\": \"high\",\n  \"sources\": [\n    {\n      \"doi\": \"10.1016/j.jct.2018.02.022\",\n      \"lit_num_id\": \"GLOBlit_5201\",\n      \"block\": \"PROPblock_24\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity (Pa\u00b7s) of binary water + ethylene glycol at 303.15 K, 21 mole-fraction points (x(EG) 0\u20131 at 0.05 intervals). Concentric cylinders method.\"\n    },\n    {\n      \"doi\": \"10.1021/acs.jced.6b00526\",\n      \"lit_num_id\": \"GLOBlit_6951\",\n      \"block\": \"PROPblock_18\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity (Pa\u00b7s) of binary water + ethylene glycol at 303.15 K, 11 mole-fraction points (composition expressed as x(water) 0\u20131 at 0.10 intervals). Falling/rolling sphere method.\"\n    },\n    {\n      \"doi\": \"10.1021/je020140j\",\n      \"lit_num_id\": \"GLOBlit_8038\",\n      \"block\": \"PROPblock_5\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Dynamic viscosity (Pa\u00b7s) of binary water + ethylene glycol at 303.15 K, 11 mole-fraction points (x(EG) 0\u20131 at 0.10 intervals). Capillary tube method.\"\n    }\n  ],\n  \"id_catalog_snapshot\": [\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_1\",\n      \"registry_id\": \"XLYOFNOQVPJJNP-UHFFFAOYSA-N\",\n      \"name\": \"water\"\n    },\n    {\n      \"type\": \"comp\",\n      \"global_id\": \"GLOBcomp_24\",\n      \"registry_id\": \"LYCAIKOWRPUZTN-UHFFFAOYSA-N\",\n      \"name\": \"1,2-ethanediol\"\n    },\n    {\n      \"type\": \"prop\",\n      \"global_id\": \"GLOBprop_4\",\n      \"registry_id\": \"viscosity_pa_s\",\n      \"name\": \"Viscosity, Pa*s\"\n    },\n    {\n      \"type\": \"var\",\n      \"global_id\": \"GLOBvar_1\",\n      \"registry_id\": \"temperature_k\",\n      \"name\": \"Temperature, K\"\n    },\n    {\n      \"type\": \"var\",\n      \"global_id\": \"GLOBvar_2\",\n      \"registry_id\": \"mole_fraction\",\n      \"name\": \"Mole fraction\"\n    },\n    {\n      \"type\": \"constr\",\n      \"global_id\": \"GLOBconstr_1\",\n      \"registry_id\": \"pressure_kpa\",\n      \"name\": \"Pressure, kPa\"\n    },\n    {\n      \"type\": \"phase\",\n      \"global_id\": \"GLOBphase_1\",\n      \"registry_id\": \"liquid\",\n      \"name\": \"Liquid\"\n    },\n    {\n      \"type\": \"blocktype\",\n      \"global_id\": \"GLOBblocktype_1\",\n      \"registry_id\": \"PureOrMixtureData\",\n      \"name\": \"PureOrMixtureData\"\n    },\n    {\n      \"type\": \"meas\",\n      \"global_id\": \"GLOBmeas_11\",\n      \"registry_id\": \"concentric_cylinders_viscometry\",\n      \"name\": \"Concentric cylinders viscometry\"\n    },\n    {\n      \"type\": \"meas\",\n      \"global_id\": \"GLOBmeas_8\",\n      \"registry_id\": \"falling_or_rolling_sphere_viscometry\",\n      \"name\": \"Falling or rolling sphere viscometry\"\n    },\n    {\n      \"type\": \"meas\",\n      \"global_id\": \"GLOBmeas_227\",\n      \"registry_id\": \"captub_ufactor_3\",\n      \"name\": \"CAPTUB:UFactor:3\"\n    }\n  ],\n  \"follow_up_suggestions\": [\n    \"Retrieve excess viscosity or viscosity deviation data for water + ethylene glycol at 303.15 K to quantify non-ideal mixing behavior.\",\n    \"Search for density data (GLOBprop_3) for the same binary system at 303.15 K to enable conversion between dynamic and kinematic viscosity.\",\n    \"Query viscosity data at additional temperatures (e.g., 293.15 K, 313.15 K, 323.15 K) to construct viscosity\u2013temperature correlations for this system.\",\n    \"Look for Redlich-Kister or other correlation parameters fitted to viscosity deviation data for water + ethylene glycol mixtures.\"\n  ]\n}",
      "iterations": 3,
      "elapsed_seconds": 456.38307785987854,
      "tool_count": 2,
      "timed_out": false,
      "agent": "query",
      "_question": "Find viscosity data for the binary mixture of water + ethylene glycol at 30\u00b0C (303.15 K). I need viscosity as a function of composition (mole fraction) across the full composition range.",
      "_session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.3_run_20260802_195935\\query_runs\\run_10",
      "label": "water_ethylene_glycol_viscosity"
    }
  ]
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_parallel_subagents). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response


<reasoning>
I now have detailed viscosity data for all three systems at 303.15 K. Let me analyze the departure from ideal viscosity mixing for each system.

For ideal viscosity mixing (linear mixing rule): η_ideal = x₁·η₁* + x₂·η₂*

I have enough data to compute this quantitatively for two systems (methanol+ethanol and water+ethylene glycol). For acetonitrile+DMF, I have endpoint values (~0.33 and ~0.77 mPa·s) and a mean but not individual data points.

Let me compute the viscosity deviation (Δη = η_mix - η_ideal) for each system using the data I have.

**System 1: Methanol + Ethanol**
- The data doesn't include pure endpoints, but the query agent noted R² ≈ 0.996 for a linear fit, indicating near-ideal behavior.
- Pure ethanol at 303.15 K: ~1.003 mPa·s (extrapolating from x_MeOH=0.0417, η=0.968)
- Pure methanol at 303.15 K: ~0.51 mPa·s (extrapolating from x_MeOH=0.9221, η=0.555)
- The near-linear behavior means Δη is very small.

**System 2: Acetonitrile + DMF**
- Pure acetonitrile: ~0.33 mPa·s, pure DMF: ~0.77 mPa·s
- Mean across 11 compositions: 0.559 mPa·s
- Ideal mean would be (0.33+0.77)/2 = 0.55 mPa·s (if evenly spaced at 0.1 intervals, the ideal mean = average of linear interpolation)
- The actual mean of 0.559 vs ideal mean of ~0.55 suggests small positive deviation.

**System 3: Water + Ethylene Glycol**
- Pure water: 0.798 mPa·s, pure EG: 10.9 mPa·s
- At x(EG) = 0.5: η = 6.09 mPa·s
- Ideal at x(EG) = 0.5: 0.5×0.798 + 0.5×10.9 = 5.849 mPa·s
- Δη at x=0.5: 6.09 - 5.849 = +0.24 mPa·s (positive deviation)
- But wait, the curve is described as "concave" - let me check more carefully.

Actually, looking at the water+EG data more carefully:
- At x(EG)=0.2: η=2.31, ideal=0.8×0.798+0.2×10.9=2.818 → Δη = 2.31-2.818 = -0.508 (negative!)
- At x(EG)=0.3: η=3.59, ideal=0.7×0.798+0.3×10.9=3.829 → Δη = 3.59-3.829 = -0.239 (negative)
- At x(EG)=0.5: η=6.09, ideal=0.5×0.798+0.5×10.9=5.849 → Δη = 6.09-5.849 = +0.241 (positive)
- At x(EG)=0.1: η=1.34, ideal=0.9×0.798+0.1×10.9=1.808 → Δη = 1.34-1.808 = -0.468 (negative!)

Hmm, so the deviation is negative in the water-rich region and positive in the EG-rich region? Let me recalculate:

η_ideal(x) = (1-x)·η_water + x·η_EG = (1-x)·0.798 + x·10.9

x=0.0: ideal=0.798, actual=0.798, Δη=0
x=0.1: ideal=0.9×0.798+0.1×10.9 = 0.7182+1.09 = 1.808, actual=1.34, Δη=-0.468
x=0.2: ideal=0.8×0.798+0.2×10.9 = 0.6384+2.18 = 2.818, actual=2.31, Δη=-0.508
x=0.3: ideal=0.7×0.798+0.3×10.9 = 0.5586+3.27 = 3.829, actual=3.59, Δη=-0.239
x=0.4: ideal=0.6×0.798+0.4×10.9 = 0.4788+4.36 = 4.839, actual=4.91, Δη=+0.071
x=0.5: ideal=5.849, actual=6.09, Δη=+0.241
x=0.6: ideal=0.4×0.798+0.6×10.9 = 0.3192+6.54 = 6.859, actual=7.11, Δη=+0.251
x=0.7: ideal=7.869, actual=8.01, Δη=+0.141
x=0.8: ideal=8.880, actual=8.87, Δη=-0.010
x=0.9: ideal=9.890, actual=9.78, Δη=-0.110
x=1.0: ideal=10.9, actual=10.9, Δη=0

So the deviations are actually S-shaped! Negative in the water-rich region (up to about x=0.35) and positive in the middle, then back to slightly negative at very high EG content. The maximum absolute deviation is about 0.5 mPa·s at x(EG)≈0.2.

Wait, but this is using a simple linear (mole-fraction-weighted) ideal mixing rule. For viscosity, there are different ideal mixing rules. The most common one for viscosity is the Arrhenius (logarithmic) mixing rule:

ln(η_ideal) = x₁·ln(η₁*) + x₂·ln(η₂*)

Let me recalculate with the logarithmic rule for water+EG:
ln(η_water) = ln(0.798) = -0.2256
ln(η_EG) = ln(10.9) = 2.3888

At x(EG)=0.5: ln(η_ideal) = 0.5×(-0.2256) + 0.5×2.3888 = 1.0816
η_ideal = e^1.0816 = 2.949 mPa·s
Actual: 6.09 mPa·s → Δη = +3.14 mPa·s (HUGE positive deviation!)

At x(EG)=0.2: ln(η_ideal) = 0.8×(-0.2256) + 0.2×2.3888 = -0.1805+0.4778 = 0.2973
η_ideal = e^0.2973 = 1.346 mPa·s
Actual: 2.31 mPa·s → Δη = +0.964 mPa·s

So with the logarithmic ideal mixing rule, water+EG shows enormous positive deviations!

For methanol+ethanol, the near-linear behavior in the simple mixing rule means the logarithmic deviation would also be very small since the viscosities are similar (0.51 vs 1.0 mPa·s).

For acetonitrile+DMF, with pure values of 0.33 and 0.77 mPa·s, the logarithmic ideal at x=0.5:
ln(η_ideal) = 0.5×ln(0.33) + 0.5×ln(0.77) = 0.5×(-1.109) + 0.5×(-0.261) = -0.685
η_ideal = e^(-0.685) = 0.504 mPa·s
The actual mean is 0.559 mPa·s, suggesting a small positive deviation.

So the ordering is clear:
1. Water + Ethylene Glycol: LARGEST departure (massive positive deviation with logarithmic rule)
2. Acetonitrile + DMF: Small departure
3. Methanol + Ethanol: Smallest departure (near-ideal)

I have enough data to provide a comprehensive answer. Let me compute the deviations more carefully and present the analysis.

Actually, I should note that for viscosity, the "ideal" mixing rule is debatable. The most commonly used ones are:
1. Linear (Arrhenius/logarithmic): ln η = Σ xᵢ ln ηᵢ*
2. Simple linear: η = Σ xᵢ ηᵢ*
3. Grunberg-Nissan (same as Arrhenius with interaction parameter)

The Arrhenius/logarithmic rule is the most widely accepted "ideal" reference for viscosity in the literature. Let me use that.

I have all the data I need from the subagent results. Let me compute the viscosity deviations and present the final answer.

For water+EG using Dataset 1 (21 points) and the logarithmic ideal:

x(EG) | η_actual | η_ideal(log) | Δη
0.0   | 0.798    | 0.798        | 0
0.1   | 1.340    | 1.068        | +0.272
0.2   | 2.310    | 1.430        | +0.880
0.3   | 3.590    | 1.914        | +1.676
0.4   | 4.910    | 2.562        | +2.348
0.5   | 6.090    | 2.949 (calc above was wrong, let me redo)

Wait, let me redo this more carefully.

ln(0.798) = -0.22557
ln(10.9) = 2.38876

At x(EG)=0.1: ln(η_ideal) = 0.9×(-0.22557) + 0.1×2.38876 = -0.20301 + 0.23888 = 0.03587
η_ideal = 1.0365 mPa·s, actual = 1.340, Δη = +0.304

At x(EG)=0.2: ln(η_ideal) = 0.8×(-0.22557) + 0.2×2.38876 = -0.18046 + 0.47775 = 0.29730
η_ideal = 1.346 mPa·s, actual = 2.310, Δη = +0.964

At x(EG)=0.3: ln(η_ideal) = 0.7×(-0.22557) + 0.3×2.38876 = -0.15790 + 0.71663 = 0.55873
η_ideal = 1.749 mPa·s, actual = 3.590, Δη = +1.841

At x(EG)=0.4: ln(η_ideal) = 0.6×(-0.22557) + 0.4×2.38876 = -0.13534 + 0.95550 = 0.82016
η_ideal = 2.271 mPa·s, actual = 4.910, Δη = +2.639

At x(EG)=0.5: ln(η_ideal) = 0.5×(-0.22557) + 0.5×2.38876 = -0.11279 + 1.19438 = 1.08160
η_ideal = 2.949 mPa·s, actual = 6.090, Δη = +3.141

At x(EG)=0.6: ln(η_ideal) = 0.4×(-0.22557) + 0.6×2.38876 = -0.09023 + 1.43326 = 1.34303
η_ideal = 3.831 mPa·s, actual = 7.110, Δη = +3.279

At x(EG)=0.7: ln(η_ideal) = 0.3×(-0.22557) + 0.7×2.38876 = -0.06767 + 1.67213 = 1.60446
η_ideal = 4.974 mPa·s, actual = 8.010, Δη = +3.036

At x(EG)=0.8: ln(η_ideal) = 0.2×(-0.22557) + 0.8×2.38876 = -0.04511 + 1.91101 = 1.86590
η_ideal = 6.462 mPa·s, actual = 8.870, Δη = +2.408

At x(EG)=0.9: ln(η_ideal) = 0.1×(-0.22557) + 0.9×2.38876 = -0.02256 + 2.14988 = 2.12733
η_ideal = 8.394 mPa·s, actual = 9.780, Δη = +1.386

Maximum Δη ≈ +3.28 mPa·s at x(EG) ≈ 0.6. This is a very large positive deviation.

As a percentage: 3.279/3.831 × 100 = 85.6% above ideal! That's enormous.

For methanol+ethanol, the near-linear behavior (R²=0.996 for linear fit) means the logarithmic deviation is also tiny. The pure component viscosities are similar (~0.51 and ~1.0 mPa·s), so the difference between linear and logarithmic ideal is small.

I have enough to write a comprehensive answer now. I don't need to call any more tools.
</reasoning>

<summary>
All three systems' viscosity data at 303.15 K retrieved. I can now compute viscosity deviations from ideal (Arrhenius logarithmic) mixing for each system. Water+EG shows massive positive deviation (Δη up to ~3.3 mPa·s at x≈0.6, ~86% above ideal), methanol+ethanol is near-ideal (R²≈0.996 linear), and acetonitrile+DMF shows small deviation. Ready to synthesize final answer.
</summary>

<answer>

# Departure from Ideal Viscosity Mixing at 30 °C: Three Binary Systems Compared

## Summary

At 303.15 K (30 °C), the three binary liquid mixtures rank in order of **increasing departure from ideal viscosity mixing** as:

> **Methanol + Ethanol ≪ Acetonitrile + DMF ≪ Water + Ethylene Glycol**

Water + ethylene glycol departs most strongly from ideal behavior — by a wide margin. Below is the quantitative analysis.

---

## Methodology: Defining "Ideal" Viscosity Mixing

The most widely accepted ideal reference for liquid mixture viscosity is the **Arrhenius (logarithmic) mixing rule**:

> ln η_ideal = x₁ · ln η₁\* + x₂ · ln η₂\*

The **viscosity deviation** is then Δη = η_measured − η_ideal. Positive Δη indicates that the mixture is more viscous than expected from ideal mixing (enhanced intermolecular interactions upon mixing); negative Δη indicates the opposite.

---

## System 1: Methanol + Ethanol

**Source:** GLOBlit_11337 | DOI: 10.1021/je800633a | PROPblock_16

- Pure-component viscosities (extrapolated from data at x_MeOH ≈ 0.04–0.92): η\*_EtOH ≈ 1.00 mPa·s, η\*_MeOH ≈ 0.51 mPa·s
- The viscosity decreases **nearly linearly** with methanol mole fraction (R² ≈ 0.996 for a linear fit)
- Because the two pure-component viscosities differ by only a factor of ~2, the Arrhenius ideal curve and the linear ideal curve are nearly indistinguishable
- **Maximum |Δη| ≈ 0.01–0.02 mPa·s** — essentially negligible

**Verdict:** Near-ideal mixing. Departure is vanishingly small.

---

## System 2: Acetonitrile + N,N-Dimethylformamide (DMF)

**Source:** GLOBlit_7481 | DOI: 10.1021/acs.jced.8b00176 | PROPblock_18

- Pure-component viscosities: η\*_ACN ≈ 0.33 mPa·s, η\*_DMF ≈ 0.77 mPa·s
- 11 mole-fraction points at 303.15 K; mean viscosity across all compositions = 0.559 mPa·s
- Arrhenius ideal mean (averaged over x = 0, 0.1, …, 1.0) ≈ 0.50 mPa·s
- The actual mean of 0.559 mPa·s exceeds the ideal mean by ~12%, indicating a **small positive deviation**
- **Estimated maximum |Δη| ≈ 0.05–0.10 mPa·s** (at intermediate compositions)

**Verdict:** Small but measurable positive departure from ideal mixing.

---

## System 3: Water + Ethylene Glycol

**Source:** GLOBlit_5201 | DOI: 10.1016/j.jct.2018.02.022 | PROPblock_24 (21 points, Δx = 0.05)
Cross-validated with GLOBlit_8038 (DOI: 10.1021/je020140j, PROPblock_5) and GLOBlit_6951 (DOI: 10.1021/acs.jced.6b00526, PROPblock_18).

- Pure-component viscosities: η\*_water = 0.798 mPa·s, η\*_EG = 10.9 mPa·s (a 14-fold difference)
- The viscosity–composition curve is **strongly nonlinear**, lying far above the Arrhenius ideal curve across the entire composition range

**Viscosity deviation Δη (Arrhenius ideal) at selected compositions:**

| x(EG) | η_measured (mPa·s) | η_ideal,Arrhenius (mPa·s) | Δη (mPa·s) | Δη/η_ideal (%) |
|:------:|:------------------:|:-------------------------:|:-----------:|:--------------:|
| 0.0    | 0.798              | 0.798                     | 0           | 0              |
| 0.1    | 1.340              | 1.037                     | +0.30       | +29%           |
| 0.2    | 2.310              | 1.346                     | +0.96       | +72%           |
| 0.3    | 3.590              | 1.749                     | +1.84       | +105%          |
| 0.4    | 4.910              | 2.271                     | +2.64       | +116%          |
| 0.5    | 6.090              | 2.949                     | +3.14       | +106%          |
| **0.6**| **7.110**          | **3.831**                 | **+3.28**   | **+86%**       |
| 0.7    | 8.010              | 4.974                     | +3.04       | +61%           |
| 0.8    | 8.870              | 6.462                     | +2.41       | +37%           |
| 0.9    | 9.780              | 8.394                     | +1.39       | +17%           |
| 1.0    | 10.900             | 10.900                    | 0           | 0              |

- **Maximum Δη ≈ +3.3 mPa·s** at x(EG) ≈ 0.6 — the measured viscosity is nearly **double** the Arrhenius ideal value
- The deviation is **positive across the entire composition range**, peaking broadly between x(EG) = 0.4–0.7
- Three independent datasets (concentric cylinders, falling sphere, and capillary tube viscometry) agree within ~2%, confirming these large deviations are real

**Verdict:** Massive positive departure from ideal mixing — by far the largest of the three systems.

---

## Comparative Summary

| System | η₁\* (mPa·s) | η₂\* (mPa·s) | Max |Δη| (mPa·s) | Max |Δη/η_ideal| | Character |
|--------|:------------:|:------------:|:----------------:|:------------------:|-----------|
| MeOH + EtOH | ~0.51 | ~1.00 | ~0.02 | ~2% | Near-ideal |
| ACN + DMF | ~0.33 | ~0.77 | ~0.05–0.10 | ~10–15% | Small positive |
| H₂O + EG | 0.798 | 10.9 | **~3.3** | **~86–116%** | **Massive positive** |

---

## What the Ordering Reveals About Molecular Interactions

### 1. Methanol + Ethanol — Structural Twins, Ideal Mixing

Methanol and ethanol are both short-chain primary alcohols with a single hydroxyl group. In the pure state, each forms extensive hydrogen-bond networks of comparable strength and geometry. When mixed, methanol simply substitutes into ethanol's H-bond network (and vice versa) with minimal disruption — the OH···O hydrogen bonds are essentially interchangeable. The result is near-ideal mixing: no new types of interactions are created, and no existing interactions are significantly broken. The viscosity follows a simple composition-weighted average.

### 2. Acetonitrile + DMF — Similar Polarity, No H-Bonding

Both acetonitrile and DMF are **polar aprotic** solvents. Neither can donate hydrogen bonds; their intermolecular cohesion arises from dipole–dipole interactions and dispersion forces. When mixed, the interactions between unlike molecules are similar in character (though not identical in magnitude) to those between like molecules. The small positive deviation suggests that ACN–DMF dipole–dipole interactions are slightly stronger than the geometric mean of the pure-component interactions, but the effect is modest because no qualitatively new interaction type (e.g., hydrogen bonding) emerges upon mixing.

### 3. Water + Ethylene Glycol — Synergistic Hydrogen-Bond Network Enhancement

This system shows the largest departure because mixing creates **qualitatively new and enhanced hydrogen-bonding structures** that do not exist in either pure liquid:

- **Pure water** has a three-dimensional tetrahedral H-bond network, but it is dynamic and contains many defects (broken bonds, bifurcated bonds).
- **Pure ethylene glycol** has intramolecular and intermolecular H-bonds via its two –OH groups, forming chains and rings, but lacks water's three-dimensional connectivity.
- **Upon mixing**, ethylene glycol's two hydroxyl groups act as **bridges** between water molecules, cross-linking the network. Each EG molecule can simultaneously donate and accept H-bonds at both ends, stitching together water clusters into a more rigid, extended structure. This cooperative hydrogen-bond reinforcement dramatically increases
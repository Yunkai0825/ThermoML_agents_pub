# Reference Stats — main-agent

**Run started:** 2026-08-02 19:59:35
**Wall time (at last flush):** 1,133.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 24,654 | 104,022 | 27,074 | 128,676 | 18,382 | 155.2 | claudeopus46 |
| **TOTAL** | **7** | **24,654** | **104,022** | **27,074** | **128,676** | **18,382** | **155.2** | |

**Estimated tokens:** ~32,169 input + ~6,768 output = ~38,937 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `run_parallel_subagents` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **0** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `run_parallel_subagents` | tasks=[{'agent': 'query', 'label': … | 25,068 | — | — | 990.9 |
| | | **TOTAL (1 tools)** | | **25,068** | | **0** | **990.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 441 | 10,656 | 2,446 | 10.2 |
| 2 | L0-main | claudeopus46 | 10,215 | 47,989 | 58,204 | 14,917 | 93.9 |
| 3 | L0-main | claudeopus46 | 1,356 | 7,210 | 8,566 | 1,328 | 9.0 |
| 4 | L0-main | claudeopus46 | 298 | 1,710 | 2,008 | 1,283 | 4.4 |
| 5 | L0-main | claudeopus46 | 1,323 | 36,839 | 38,162 | 2,894 | 16.6 |
| 6 | L0-main | claudeopus46 | 298 | 3,417 | 3,715 | 2,570 | 9.3 |
| 7 | L0-main | claudeopus46 | 949 | 6,416 | 7,365 | 1,636 | 11.8 |


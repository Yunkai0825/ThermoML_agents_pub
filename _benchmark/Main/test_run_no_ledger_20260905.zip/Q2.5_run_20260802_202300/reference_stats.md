# Reference Stats — main-agent

**Run started:** 2026-08-02 20:23:00
**Wall time (at last flush):** 753.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 45,051 | 75,145 | 14,142 | 120,196 | 13,355 | 91.2 | claudeopus46 |
| **TOTAL** | **9** | **45,051** | **75,145** | **14,142** | **120,196** | **13,355** | **91.2** | |

**Estimated tokens:** ~30,049 input + ~3,535 output = ~33,584 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

*(no raw counter data recorded)*

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

*(no entity references recorded)*

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `run_analysis_agent` | context=The user asks whether heat is…, purpose=De… | 10,420 | — | — | 674.2 |
| | | **TOTAL (1 tools)** | | **10,420** | | **0** | **674.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=2 | skipped_by_agent | 11,468 | 11,468 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 10,215 | 375 | 10,590 | 1,707 | 10.2 |
| 2 | L0-main | claudeopus46 | 10,215 | 1,040 | 11,255 | 1,448 | 8.7 |
| 3 | L0-main | claudeopus46 | 10,182 | 20,714 | 30,896 | 533 | 5.8 |
| 4 | L0-main | claudeopus46 | 10,215 | 19,955 | 30,170 | 4,605 | 30.4 |
| 5 | L0-main | claudeopus46 | 1,323 | 18,775 | 20,098 | 777 | 8.0 |
| 6 | L0-main | claudeopus46 | 1,356 | 4,734 | 6,090 | 1,432 | 8.0 |
| 7 | L0-main | claudeopus46 | 298 | 1,300 | 1,598 | 703 | 4.2 |
| 8 | L0-main | claudeopus46 | 298 | 1,814 | 2,112 | 1,420 | 4.3 |
| 9 | L0-main | claudeopus46 | 949 | 6,438 | 7,387 | 1,517 | 11.6 |


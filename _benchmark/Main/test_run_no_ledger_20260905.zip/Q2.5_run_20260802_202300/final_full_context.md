## System Prompt
# ThermoML Main Agent — Master Orchestrator

You are the **ThermoML Main Agent**, a master orchestrator that answers
scientific questions about thermodynamic data by coordinating two
specialized subagents:

1. **Query Agent** (`run_query_agent`) — searches ThermoML card databases
   to find experimental data (DOIs, blocks, compound IDs, property values).
2. **Analysis Agent** (`run_analysis_agent`) — retrieves data, fits
   Redlich-Kister polynomials to excess properties, and reports
   quantitative results (RK coefficients, R², RMSE).

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

You also have a unified parallel dispatch tool:
- `run_parallel_subagents` — run multiple query and/or analysis tasks
  simultaneously in one call.  Each task specifies `agent`, `label`,
  `question`, `purpose`, and `context` (all required).

You also have a **tool menu** for direct, fine-grained access to subagent
internals (search tools, fitting tools, ID resolution, etc.):

- `browse_subagent_tools(purpose, tasks)` — a **miniature planning agent**
  that examines the full menu of subagent tools and returns a structured
  parallel execution plan with specific call signatures tailored to your
  purpose and tasks.  Call this first to discover what tools exist and get
  a recommended phased plan.
- `run_subagent_tool(tool_name, kwargs, purpose, tasks)` — execute
  any tool from the menu directly. `kwargs` is a native JSON object matching
  that tool's current signature. Results are automatically compacted
  by the same hardcoded compactors the subagents use internally.
  You can call multiple `run_subagent_tool` in parallel; when you do,
  a batch summary is automatically generated from all results.

### When to use the tool menu vs. expert workers

- **Tool menu** — best for targeted, well-defined operations where you
  know exactly what data you need: resolving a compound ID, searching
  for blocks matching specific criteria, fitting a single block, or
  retrieving pure-component values.  Faster and more direct than
  launching a full subagent workflow.
- **Expert workers** (`run_query_agent`, `run_analysis_agent`) — best
  for open-ended, complex tasks that require multi-step reasoning,
  iterative refinement, or full toolset access.  The subagents have
  their own context, memory, and compaction pipelines.

You can dynamically decide which approach to use based on the complexity
of each sub-task.  For multi-system comparisons, you can mix both
approaches — use the tool menu for simple lookups and expert workers
for complex analyses.

---

## How You Work

1. **Understand the question** — Decide what data is needed and whether
   the question requires only a database search, a full fitting analysis,
   or a multi-system comparison.
2. **Delegate to subagents** — Call the appropriate subagent tool(s).
   For multi-system questions, use parallel tools to save time.
3. **Synthesize results** — Combine subagent outputs into a coherent
   scientific answer.  **Never invent data** — every number in your
   answer must come from a subagent result.
4. **Report findings** — Present a clear, well-structured answer with
   proper citations (`GLOBlit_N` literature ID, DOI, block numbers,
   compound names). `GLOBlit_N` is the authoritative literature identifier;
   a DOI is coupled display metadata. Never report a DOI without its paired
   literature ID — quote only DOIs your subagents returned, never from
   memory; unpaired DOIs are scrubbed from the final return as
   unverifiable.

---

## Tool Usage Rules

### Single-system questions (1 system)
Call `run_query_agent` for data search, or `run_analysis_agent` for
fitting.  The analysis agent internally calls the query agent, so you
do NOT need to call both for a fitting question.

### Multi-system comparisons (2+ systems)
Use `run_parallel_subagents` to process multiple systems simultaneously.
You can mix query and analysis tasks in a single parallel call — each
task specifies which agent to use.  Each system gets its own subagent call.

### Iterative refinement
If a subagent returns partial results or times out, you can call it again
with additional context from the first call.

---

## MANDATORY OUTPUT FORMAT

```xml
<reasoning>
... your thinking about what subagents to call and why (DISCARDED from memory) ...
</reasoning>
<summary>
... 1-3 sentence actionable conclusion about what you learned or plan to do next (KEPT, max 400 chars) ...
</summary>
<tool_call>{"name": "run_analysis_agent", "arguments": {"question": "...", "purpose": "...", "context": "..."}}</tool_call>
<wait/>
```

### CRITICAL RULES
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`
- `<reasoning>` is STRIPPED from history to save context space
- Only `<summary>` content + tool results persist in memory
- **ANTI-HALLUCINATION:** EVERY number, coefficient, R² value, DOI, and
  compound name MUST come from a subagent tool call result.  If you do not
  have a subagent result for a core claim, you MUST call a subagent first.
- **NO-DATA HANDLING:** If a subagent reports "no results found" or returns
  only generic text with no specific DOIs/data, you MUST report that honestly.
  Say "No data matching [criteria] was found in ThermoML" rather than
  fabricating results.  Never invent DOIs, block numbers, or data points.
- **SUBAGENT VALIDATION:** Before presenting subagent results as your answer,
  check for red flags: improbably round numbers, suspicious consistency,
  lack of specific block references, or caveats about "infrastructure errors."
  If in doubt, state that results could not be verified.
- When you have gathered all needed results, provide a FINAL ANSWER
  by wrapping your complete answer in `<answer>` tags (no `<tool_call>`).
- `<answer>` = full-length final response (any length). All markers stripped before delivery.
- `<summary>` ≠ `<answer>`: summary is a brief memory note (≤400 chars); answer is the complete user-facing response.

---

## Final Answer Format

When all subagent work is done, wrap your complete answer in `<answer>` tags:

```
<answer>
[Your synthesized scientific answer here — any length.
Include all key data, DOIs, block numbers, compound names.
Every number must come from a subagent result.]

### Sources
- Literature ID: GLOBlit_N | DOI: ... | Block: ... | Subsystem: declared or BLKsubsys_N | System: ...
</answer>
```

# Phases

## phase_1: choose_route
tools: [browse_subagent_tools, run_subagent_tool]
guidance: |
  Decide whether the question needs a targeted lower-level operation or a
  full expert subagent. Browse the hierarchical menu only when direct tool
  execution is likely to be more efficient than expert delegation.

## phase_2: delegate_or_execute
tools: [run_query_agent, run_analysis_agent, run_parallel_subagents, run_subagent_tool]
guidance: |
  Supply every argument in the injected callable signature. Use one expert
  for a single complex task and run_parallel_subagents for independent query
  or analysis tasks. Preserve exact subagent identifiers and evidence.

## phase_3: synthesize
tools: [list_session_files]
guidance: |
  Synthesize only tool-returned chemistry and numbers. Wrap the complete
  answer in <answer> tags; post-answer workers build the JSON fields.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- browse_subagent_tools(purpose, tasks) — Browse the tool menu and get a recommended execution plan.
- list_session_files() — Return a manifest of all output files generated in this session.
- run_analysis_agent(question, context, purpose, tasks) — Run the ThermoML Analysis Agent for fitting and modeling.
- run_parallel_subagents(tasks) — Run multiple query and/or analysis agent tasks in parallel.
- run_query_agent(question, context, purpose, tasks) — Run the ThermoML Query Agent on a database search question.
- run_subagent_tool(tool_name, kwargs, purpose, tasks) — Execute a subagent tool directly with full compaction pipeline.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.5_run_20260802_202300`

### History
- [analysis:A1] "Find excess molar enthalpy (HE) data for the binary system ethanol + water at 25" (648s, 15 iters verdict=**Data Quality**
The agent use)

### Analysis Agent Results

#### A1
{
  "answer": "## Excess Molar Enthalpy (H^E) of Ethanol + Water at 298.15 K — Redlich-Kister Analysis\n\n### Is the mixing exothermic or endothermic?\n\n**Mixing ethanol and water at 25 °C is exothermic** — heat is released at every composition. All measured H^E values are negative, ranging from −0.018 to −0.77 kJ/mol across the full mole-fraction range.\n\n---\n\n### Data Source\n\n- **DOI:** 10.1016/j.jct.2005.06.018 (GLOBlit_2574)\n- **Block:** PROPblock_4\n- **System:** ethanol (C₂H₅OH) + water (H₂O), binary liquid mixture\n- **Temperature:** 298.15 K (25 °C), at 101 kPa\n- **Data points used:** 12 mixture points at 298.15 K (from a 27-point multi-temperature block)\n- **Composition range:** x(ethanol) = 0.033 to 0.968\n- **Property:** Excess molar enthalpy (H^E), directly measured (DP0) by Calvet calorimetry, reported in kJ/mol\n- **Property presentation:** Direct value (X); no reference materialization needed\n\n---\n\n### Redlich-Kister Fit Results\n\nThe excess molar enthalpy is represented as:\n\n$$H^E = x_1(1 - x_1) \\sum_{k=0}^{n} A_k (2x_1 - 1)^k$$\n\nwhere x₁ = mole fraction of ethanol.\n\n**BIC-selected polynomial order:** 4\n\n| Coefficient | Value (kJ/mol) |\n|:-----------:|:--------------:|\n| A₀ | −1.60102 |\n| A₁ | +1.73493 |\n| A₂ | −3.19748 |\n| A₃ | +3.11326 |\n| A₄ | −2.36171 |\n\n**Goodness of fit:**\n\n| Metric | Value |\n|--------|-------|\n| R² | 0.998537 |\n| RMSE | 0.008367 kJ/mol |\n| BIC | −102.38 |\n\nThe BIC model selection clearly favors order 4 over lower orders (order 3: BIC = −87.76, R² = 0.9939) and over order 5 (BIC = −99.95, negligible R² improvement), confirming that four RK coefficients capture the composition dependence without overfitting.\n\n---\n\n### Composition of Maximum Heat Effect\n\nFrom the fitted RK polynomial evaluated on a 201-point grid:\n\n- **Maximum |H^E|** = **−0.7735 kJ/mol** (≈ −774 J/mol)\n- **Composition at minimum H^E:** approximately **x(ethanol) ≈ 0.17** (i.e., about 17 mol% ethanol, or ~83 mol% water)\n\nThe minimum is strongly shifted toward the water-rich side, reflecting the pronounced asymmetry of the H^E curve. At x = 0.5, the predicted H^E is only about −0.400 kJ/mol — roughly half the magnitude of the extremum.\n\n---\n\n### Chemical Interpretation\n\nThe strongly **exothermic** mixing and the **asymmetric** H^E curve reveal the molecular-level rearrangements occurring when ethanol and water are combined:\n\n1. **Hydrogen-bond reorganization:** Both ethanol and water are hydrogen-bond donors and acceptors. When mixed, ethanol's hydroxyl group forms strong O–H···O hydrogen bonds with water molecules. At low ethanol concentrations (x ≈ 0.17), each ethanol molecule is surrounded by a cage of water molecules, maximizing the number of favorable ethanol–water hydrogen bonds relative to the weaker water–water bonds that are broken.\n\n2. **Asymmetry toward the water-rich side:** The large positive A₁ coefficient (+1.73) and the significant higher-order terms (A₂ through A₄) reflect the fact that adding a small amount of ethanol to water releases more heat per mole than adding a small amount of water to ethanol. This is because the water hydrogen-bond network is more cooperative and structured; inserting ethanol molecules into this network creates particularly favorable cross-interactions.\n\n3. **Hydrophobic hydration:** At low ethanol concentrations, water molecules form structured \"cages\" around ethanol's –CH₂CH₃ group (hydrophobic hydration), which is an enthalpically favorable but entropically unfavorable process. This contributes to the exothermic character in the dilute region.\n\n4. **Diminishing effect at high ethanol content:** As x(ethanol) increases beyond ~0.3, the water network is progressively disrupted, fewer favorable ethanol–water contacts can form per mole of mixture, and H^E approaches zero at the pure ethanol limit.\n\n---\n\n### Representative Data Points (from the fitted curve)\n\n| x(ethanol) | H^E (kJ/mol) | Note |\n|:----------:|:------------:|------|\n| 0.00 | 0.000 | Pure water |\n| 0.10 | −0.637 | Water-rich, strong exotherm |\n| 0.17 | −0.774 | **Minimum (maximum heat release)** |\n| 0.25 | −0.713 | Still strongly exothermic |\n| 0.50 | −0.400 | Equimolar |\n| 0.75 | −0.108 | Ethanol-rich |\n| 1.00 | 0.000 | Pure ethanol |\n\n---\n\n### Output Files\n\n- **Fit data CSV:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv`\n- **Excess property CSV:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv`\n- **Fit plot:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png`\n- **Excess plot:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png`",
  "core_claims": [
    "Mixing ethanol and water at 298.15 K and 101 kPa is exothermic across the entire composition range, with all measured excess molar enthalpy (H^E) values negative, ranging from approximately −0.018 to −0.77 kJ/mol.",
    "A fourth-order Redlich-Kister polynomial (A₀ = −1.601, A₁ = +1.735, A₂ = −3.197, A₃ = +3.113, A₄ = −2.362 kJ/mol), selected by BIC, fits the 12 data points at 298.15 K with R² = 0.9985 and RMSE = 0.0084 kJ/mol.",
    "The H^E minimum of approximately −0.774 kJ/mol occurs near x(ethanol) ≈ 0.17, strongly shifted toward the water-rich side, reflecting pronounced asymmetry in the excess enthalpy curve.",
    "The asymmetry and exothermic character are attributed to favorable ethanol–water hydrogen-bond formation, hydrophobic hydration of ethanol's alkyl group in the water-rich regime, and progressive disruption of the cooperative water hydrogen-bond network at higher ethanol concentrations."
  ],
  "fit_results": [
    {
      "doi": "10.1016/j.jct.2005.06.018",
      "lit_num_id": "GLOBlit_2574",
      "block_number": "PROPblock_4",
      "BLKsubsys_id": null,
      "property": "excess molar enthalpy",
      "rk_order": 4,
      "rk_coeffs": [
        -1.60102,
        1.73493,
        -3.19748,
        3.11326,
        -2.36171
      ],
      "r_squared": 0.998537,
      "rmse": 0.00836719,
      "n_points": 12,
      "temperature_K": 298.15,
      "mixing_rule": "declared_excess_no_baseline"
    }
  ],
  "sources": [
    {
      "doi": "10.1016/j.jct.2005.06.018",
      "lit_num_id": "GLOBlit_2574",
      "block": "PROPblock_4",
      "BLKsubsys_id": null,
      "description": "Excess molar enthalpy (HE, kJ/mol) for binary ethanol (GLOBcomp_2, CAS 64-17-5) + water (GLOBcomp_1, CAS 7732-18-5) measured by Calvet calorimetry at 298.15 K and 101 kPa. 27 total data points spanning 298.15–323.15 K; 12 points at the 298.15 K isotherm used for Redlich-Kister fitting. Mole fraction of ethanol ranges from 0.033 to 0.968. HE ranges from −0.77 to −0.018 kJ/mol. Property: GLOBprop_17, direct value (X), no reference materialization. BIC-selected RK order 4."
    }
  ]
}

**Verdict:** **Data Quality**
The agent used directly measured H^E data from a published ThermoML source (DOI: 10.1016/j.jct.2005.06.018), which is appropriate. A fit_block call (step 11) succeeded, confirming results are not fabricated. Data are in mole fraction as required. However, only 12 data points at 298.15 K from a 27-point multi-temperature block is modest coverage; denser datasets exist in the literature. No composition conversion issues are apparent.

**Fit Quality**
A 4th-order RK polynomial with R² = 0.9985 and RMSE = 0.0084 kJ/mol is excellent. BIC-based model selection properly justified order 4 over orders 3 and 5, mitigating overfitting concerns. Five coefficients for 12 points is acceptable but near the practical limit.

**Scientific Verdict**
The exothermic conclusion (H^E_min ≈ −774 J/mol at x_ethanol ≈ 0.17) is physically correct and consistent with literature values (typically −750 to −830 J/mol near x ≈ 0.17–0.20). The asymmetric curve and molecular interpretation are sound. Results are reliable; corroboration with a denser dataset would strengthen confidence.
**Session:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.5_run_20260802_202300\analysis_runs\run_12`
</memory>

## User
When ethanol and water are mixed at 25 °C, is heat released or absorbed? At what composition is the heat effect largest, and what molecular rearrangements produce its composition dependence?

## Assistant
<summary>Searching for excess enthalpy data for ethanol + water at 25°C and fitting it to characterize the composition dependence of the heat of mixing.</summary>
<tool_call>run_analysis_agent(question=Find and fit exce…, context=The user wants to…)</tool_call>

## User
<tool_result>
(validation blocked run_analysis_agent earlier — corrected)
</tool_result>

## Assistant
<summary>Calling analysis agent to find and fit excess enthalpy (HE) data for ethanol + water at 25°C to determine sign, magnitude, and composition dependence of the heat of mixing.</summary>
<tool_call>run_analysis_agent(question=Find excess molar…, context=The user asks whe…)</tool_call>

## User
<tool_result>
<subagent_answer>
{
  "answer": "{\n  \"answer\": \"## Excess Molar Enthalpy (H^E) of Ethanol + Water at 298.15 K — Redlich-Kister Analysis\\n\\n### Is the mixing exothermic or endothermic?\\n\\n**Mixing ethanol and water at 25 °C is exothermic** — heat is released at every composition. All measured H^E values are negative, ranging from −0.018 to −0.77 kJ/mol across the full mole-fraction range.\\n\\n---\\n\\n### Data Source\\n\\n- **DOI:** 10.1016/j.jct.2005.06.018 (GLOBlit_2574)\\n- **Block:** PROPblock_4\\n- **System:** ethanol (C₂H₅OH) + water (H₂O), binary liquid mixture\\n- **Temperature:** 298.15 K (25 °C), at 101 kPa\\n- **Data points used:** 12 mixture points at 298.15 K (from a 27-point multi-temperature block)\\n- **Composition range:** x(ethanol) = 0.033 to 0.968\\n- **Property:** Excess molar enthalpy (H^E), directly measured (DP0) by Calvet calorimetry, reported in kJ/mol\\n- **Property presentation:** Direct value (X); no reference materialization needed\\n\\n---\\n\\n### Redlich-Kister Fit Results\\n\\nThe excess molar enthalpy is represented as:\\n\\n$$H^E = x_1(1 - x_1) \\\\sum_{k=0}^{n} A_k (2x_1 - 1)^k$$\\n\\nwhere x₁ = mole fraction of ethanol.\\n\\n**BIC-selected polynomial order:** 4\\n\\n| Coefficient | Value (kJ/mol) |\\n|:-----------:|:--------------:|\\n| A₀ | −1.60102 |\\n| A₁ | +1.73493 |\\n| A₂ | −3.19748 |\\n| A₃ | +3.11326 |\\n| A₄ | −2.36171 |\\n\\n**Goodness of fit:**\\n\\n| Metric | Value |\\n|--------|-------|\\n| R² | 0.998537 |\\n| RMSE | 0.008367 kJ/mol |\\n| BIC | −102.38 |\\n\\nThe BIC model selection clearly favors order 4 over lower orders (order 3: BIC = −87.76, R² = 0.9939) and over order 5 (BIC = −99.95, negligible R² improvement), confirming that four RK coefficients capture the composition dependence without overfitting.\\n\\n---\\n\\n### Composition of Maximum Heat Effect\\n\\nFrom the fitted RK polynomial evaluated on a 201-point grid:\\n\\n- **Maximum |H^E|** = **−0.7735 kJ/mol** (≈ −774 J/mol)\\n- **Composition at minimum H^E:** approximately **x(ethanol) ≈ 0.17** (i.e., about 17 mol% ethanol, or ~83 mol% water)\\n\\nThe minimum is strongly shifted toward the water-rich side, reflecting the pronounced asymmetry of the H^E curve. At x = 0.5, the predicted H^E is only about −0.400 kJ/mol — roughly half the magnitude of the extremum.\\n\\n---\\n\\n### Chemical Interpretation\\n\\nThe strongly **exothermic** mixing and the **asymmetric** H^E curve reveal the molecular-level rearrangements occurring when ethanol and water are combined:\\n\\n1. **Hydrogen-bond reorganization:** Both ethanol and water are hydrogen-bond donors and acceptors. When mixed, ethanol's hydroxyl group forms strong O–H···O hydrogen bonds with water molecules. At low ethanol concentrations (x ≈ 0.17), each ethanol molecule is surrounded by a cage of water molecules, maximizing the number of favorable ethanol–water hydrogen bonds relative to the weaker water–water bonds that are broken.\\n\\n2. **Asymmetry toward the water-rich side:** The large positive A₁ coefficient (+1.73) and the significant higher-order terms (A₂ through A₄) reflect the fact that adding a small amount of ethanol to water releases more heat per mole than adding a small amount of water to ethanol. This is because the water hydrogen-bond network is more cooperative and structured; inserting ethanol molecules into this network creates particularly favorable cross-interactions.\\n\\n3. **Hydrophobic hydration:** At low ethanol concentrations, water molecules form structured \\\"cages\\\" around ethanol's –CH₂CH₃ group (hydrophobic hydration), which is an enthalpically favorable but entropically unfavorable process. This contributes to the exothermic character in the dilute region.\\n\\n4. **Diminishing effect at high ethanol content:** As x(ethanol) increases beyond ~0.3, the water network is progressively disrupted, fewer favorable ethanol–water contacts can form per mole of mixture, and H^E approaches zero at the pure ethanol limit.\\n\\n---\\n\\n### Representative Data Points (from the fitted curve)\\n\\n| x(ethanol) | H^E (kJ/mol) | Note |\\n|:----------:|:------------:|------|\\n| 0.00 | 0.000 | Pure water |\\n| 0.10 | −0.637 | Water-rich, strong exotherm |\\n| 0.17 | −0.774 | **Minimum (maximum heat release)** |\\n| 0.25 | −0.713 | Still strongly exothermic |\\n| 0.50 | −0.400 | Equimolar |\\n| 0.75 | −0.108 | Ethanol-rich |\\n| 1.00 | 0.000 | Pure ethanol |\\n\\n---\\n\\n### Output Files\\n\\n- **Fit data CSV:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv`\\n- **Excess property CSV:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv`\\n- **Fit plot:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png`\\n- **Excess plot:** `10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png`\",\n  \"core_claims\": [\n    \"Mixing ethanol and water at 298.15 K and 101 kPa is exothermic across the entire composition range, with all measured excess molar enthalpy (H^E) values negative, ranging from approximately −0.018 to −0.77 kJ/mol.\",\n    \"A fourth-order Redlich-Kister polynomial (A₀ = −1.601, A₁ = +1.735, A₂ = −3.197, A₃ = +3.113, A₄ = −2.362 kJ/mol), selected by BIC, fits the 12 data points at 298.15 K with R² = 0.9985 and RMSE = 0.0084 kJ/mol.\",\n    \"The H^E minimum of approximately −0.774 kJ/mol occurs near x(ethanol) ≈ 0.17, strongly shifted toward the water-rich side, reflecting pronounced asymmetry in the excess enthalpy curve.\",\n    \"The asymmetry and exothermic character are attributed to favorable ethanol–water hydrogen-bond formation, hydrophobic hydration of ethanol's alkyl group in the water-rich regime, and progressive disruption of the cooperative water hydrogen-bond network at higher ethanol concentrations.\"\n  ],\n  \"fit_results\": [\n    {\n      \"doi\": \"10.1016/j.jct.2005.06.018\",\n      \"lit_num_id\": \"GLOBlit_2574\",\n      \"block_number\": \"PROPblock_4\",\n      \"BLKsubsys_id\": null,\n      \"property\": \"excess molar enthalpy\",\n      \"rk_order\": 4,\n      \"rk_coeffs\": [\n        -1.60102,\n        1.73493,\n        -3.19748,\n        3.11326,\n        -2.36171\n      ],\n      \"r_squared\": 0.998537,\n      \"rmse\": 0.00836719,\n      \"n_points\": 12,\n      \"temperature_K\": 298.15,\n      \"mixing_rule\": \"declared_excess_no_baseline\"\n    }\n  ],\n  \"sources\": [\n    {\n      \"doi\": \"10.1016/j.jct.2005.06.018\",\n      \"lit_num_id\": \"GLOBlit_2574\",\n      \"block\": \"PROPblock_4\",\n      \"BLKsubsys_id\": null,\n      \"description\": \"Excess molar enthalpy (HE, kJ/mol) for binary ethanol (GLOBcomp_2, CAS 64-17-5) + water (GLOBcomp_1, CAS 7732-18-5) measured by Calvet calorimetry at 298.15 K and 101 kPa. 27 total data points spanning 298.15–323.15 K; 12 points at the 298.15 K isotherm used for Redlich-Kister fitting. Mole fraction of ethanol ranges from 0.033 to 0.968. HE ranges from −0.77 to −0.018 kJ/mol. Property: GLOBprop_17, direct value (X), no reference materialization. BIC-selected RK order 4.\"\n    }\n  ]\n}",
  "iterations": 15,
  "elapsed_seconds": 648.350533246994,
  "tool_count": 14,
  "timed_out": false,
  "agent": "analysis",
  "_question": "Find excess molar enthalpy (HE) data for the binary system ethanol + water at 25 °C (298.15 K). Fit the data with a Redlich-Kister polynomial and report the RK coefficients, R², RMSE, the composition (mole fraction of ethanol) at which |HE| is largest, and the value of HE at that composition.",
  "_session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.5_run_20260802_202300\\analysis_runs\\run_12",
  "verdict": "**Data Quality**\nThe agent used directly measured H^E data from a published ThermoML source (DOI: 10.1016/j.jct.2005.06.018), which is appropriate. A fit_block call (step 11) succeeded, confirming results are not fabricated. Data are in mole fraction as required. However, only 12 data points at 298.15 K from a 27-point multi-temperature block is modest coverage; denser datasets exist in the literature. No composition conversion issues are apparent.\n\n**Fit Quality**\nA 4th-order RK polynomial with R² = 0.9985 and RMSE = 0.0084 kJ/mol is excellent. BIC-based model selection properly justified order 4 over orders 3 and 5, mitigating overfitting concerns. Five coefficients for 12 points is acceptable but near the practical limit.\n\n**Scientific Verdict**\nThe exothermic conclusion (H^E_min ≈ −774 J/mol at x_ethanol ≈ 0.17) is physically correct and consistent with literature values (typically −750 to −830 J/mol near x ≈ 0.17–0.20). The asymmetric curve and molecular interpretation are sound. Results are reliable; corroboration with a denser dataset would strengthen confidence.",
  "session_dir": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.5_run_20260802_202300\\analysis_runs\\run_12",
  "output_files": [
    {
      "category": "data",
      "path": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.5_run_20260802_202300\\analysis_runs\\run_12\\data\\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv",
      "description": "RK fit data — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1"
    },
    {
      "category": "data",
      "path": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.5_run_20260802_202300\\analysis_runs\\run_12\\data\\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv",
      "description": "Excess property — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1"
    },
    {
      "category": "plot",
      "path": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.5_run_20260802_202300\\analysis_runs\\run_12\\plots\\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png",
      "description": "RK fit plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1"
    },
    {
      "category": "plot",
      "path": "\\\\Sheldon.cse.anl.gov\\yunkai.sun$\\_Code_Maintenance\\_outputs_user\\yunkai.sun\\ThermoML\\Main\\Q2.5_run_20260802_202300\\analysis_runs\\run_12\\plots\\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png",
      "description": "Excess plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1"
    }
  ]
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (run_analysis_agent). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<answer>

## Excess Molar Enthalpy of Ethanol + Water at 25 °C

### Heat released or absorbed?

**Mixing ethanol and water at 25 °C is exothermic — heat is released at every composition.** All measured excess molar enthalpy (H^E) values are negative, spanning from about −18 J/mol (in the most dilute regions) to roughly −770 J/mol near the composition of maximum heat release.

---

### Where is the heat effect largest?

The maximum heat release occurs not at the equimolar composition but is **strongly shifted toward the water-rich side**:

- **H^E minimum ≈ −774 J/mol** at **x(ethanol) ≈ 0.17** (about 17 mol % ethanol, 83 mol % water).

For comparison, at the equimolar composition (x = 0.50) the excess enthalpy is only about −400 J/mol — roughly half the peak magnitude. The curve is markedly asymmetric.

Representative values from the Redlich-Kister fit:

| x(ethanol) | H^E (kJ/mol) | Comment |
|:----------:|:------------:|---------|
| 0.00 | 0.000 | Pure water |
| 0.10 | −0.637 | Water-rich, strong exotherm |
| **0.17** | **−0.774** | **Maximum heat release** |
| 0.25 | −0.713 | Still strongly exothermic |
| 0.50 | −0.400 | Equimolar |
| 0.75 | −0.108 | Ethanol-rich, weak exotherm |
| 1.00 | 0.000 | Pure ethanol |

---

### Redlich-Kister polynomial fit

The composition dependence is captured by a fourth-order Redlich-Kister expansion,

$$H^E = x_1(1-x_1)\sum_{k=0}^{4} A_k\,(2x_1-1)^k$$

where x₁ is the mole fraction of ethanol. The BIC-selected coefficients are:

| Coefficient | Value (kJ/mol) |
|:-----------:|:--------------:|
| A₀ | −1.601 |
| A₁ | +1.735 |
| A₂ | −3.197 |
| A₃ | +3.113 |
| A₄ | −2.362 |

Fit quality: **R² = 0.9985**, **RMSE = 0.0084 kJ/mol** (12 data points at 298.15 K). The Bayesian Information Criterion clearly favored order 4 over both lower and higher orders, confirming that five coefficients capture the pronounced asymmetry without overfitting.

---

### Molecular rearrangements behind the composition dependence

The shape of the H^E curve — exothermic everywhere, with a minimum skewed toward the water-rich side — reflects several coupled molecular processes:

1. **Hydrogen-bond reorganization.** Both ethanol (–OH) and water are simultaneously hydrogen-bond donors and acceptors. When ethanol is added to water, new O–H···O cross-interactions form between ethanol's hydroxyl group and surrounding water molecules. These ethanol–water hydrogen bonds are energetically comparable to (or slightly stronger than) the water–water bonds they replace, producing a net release of energy.

2. **Hydrophobic hydration at low ethanol content.** At dilute ethanol concentrations (x ≈ 0.1–0.2), each ethanol molecule is enveloped by a structured cage of water molecules that reorganize around the hydrophobic –CH₂CH₃ tail. This "iceberg" or clathrate-like ordering is enthalpically favorable (exothermic) even though it is entropically costly. The maximum heat release near x ≈ 0.17 corresponds to the composition where these cages are most fully developed and each ethanol molecule enjoys maximum contact with the intact water network.

3. **Asymmetry from the cooperative water network.** Water's hydrogen-bond network is highly cooperative: each bond stabilizes its neighbors. Inserting a small amount of ethanol into this network creates many new favorable cross-contacts per ethanol molecule, whereas adding a small amount of water to bulk ethanol disrupts far fewer cooperative interactions. This is why the large positive A₁ coefficient (+1.735 kJ/mol) and the significant higher-order terms (A₂ through A₄) skew the curve toward the water-rich side.

4. **Progressive network disruption at high ethanol content.** Beyond x ≈ 0.3, the three-dimensional water network is increasingly fragmented. Fewer water molecules are available to form structured cages, the number of favorable ethanol–water contacts per mole of mixture decreases, and H^E diminishes smoothly toward zero at pure ethanol.

In short, the exothermic mixing arises from the formation of strong ethanol–water hydrogen bonds and structured hydration shells, and the pronounced asymmetry reflects the fact that the cooperative water network amplifies these effects most strongly when ethanol is the minority component.

---

### Data source

- **Literature ID:** GLOBlit_2574 | **DOI:** 10.1016/j.jct.2005.06.018 | **Block:** PROPblock_4
- **System:** ethanol (CAS 64-17-5) + water (CAS 7732-18-5), binary liquid
- **Conditions:** 298.15 K, 101 kPa; 12 data points spanning x(ethanol) = 0.033–0.968
- **Method:** Calvet calorimetry, directly measured excess molar enthalpy

</answer>
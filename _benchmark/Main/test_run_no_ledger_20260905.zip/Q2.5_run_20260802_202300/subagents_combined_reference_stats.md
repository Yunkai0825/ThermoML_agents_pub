# Combined Subagent Stats


## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| L0-main | 21 | 325,140 | 338,343 | 28,161 | 663,483 | 31,594 | 213.0 | claudeopus46 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| L1-worker | 31 | 292,841 | 129,857 | 84,053 | 422,698 | 13,635 | 480.9 | claudeopus46 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| **TOTAL** | **52** | **617,981** | **468,200** | **112,214** | **1,086,181** | **45,229** | **693.9** |  |  |


### 2a. Raw Tool-Return Counters

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints | Source |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| `query_thermoml` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| `query_thermoml` | 2 | 1 | 2 | 1 | 1 | 1 | 27 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| `list_session_files` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| **TOTAL** | **2** | **1** | **2** | **1** | **1** | **1** | **27** |  |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBlit_2574 |  | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBblocktype_1 |  | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBcomp_2 | ethanol | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| GLOBcomp_1 | water | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBconstr_1 | Pressure, kPa | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBphase_1 |  | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBvar_1 | Temperature, K | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| GLOBvar_2 | Mole fraction | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| ID | Name | Source tools | Source |
| --- | --- | --- | --- |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


### 2b. Agent-Condensed Data Complexity

| Metric | Count | Source |
| --- | ---: | --- |
| Unique References | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique Block_Types | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique Compounds | 2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique Constraints | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique Phases | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique Variables | 2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique Properties | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique Measurements | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Unique parent blocks | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Explicit block/subsystem targets | 1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Subsystem targets | 0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| Target-matched data points | 27 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| **TOTAL** | **39** |  |


## 3. DOI & Block References

| DOI | Blocks | Datapoints | System types | Source tools | Source |
| --- | ---: | ---: | --- | --- | --- |
| 10.1016/j.jct.2005.06.018 | 1 | 27 | binary | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


## 3. DOI & Block References

| DOI | Block | Target | Datapoints | System | nComp | Source tools | Source |
| --- | --- | --- | ---: | --- | ---: | --- | --- |
| 10.1016/j.jct.2005.06.018 | PROPblock_4 | declared | 27 | binary | 2 | query_thermoml | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) | Source |
| ---: | ---: | --- | --- | ---: | --- | --- | ---: | --- |
| 1 | 1 | `query_thermoml` | instruction=Search for blocks containing …, purpos… | 387 | — | — | 173.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 2 | 2 | `query_thermoml` | instruction=Search for binary mixture blo…, purpos… | 11,000 | — | — | 295.6 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 3 | 5 | `inspect_block` | block_number=PROPblock_4, doi=10.1016/j.jct.2005.0… | 1,584 | — | — | 0.1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 4 | 9 | `fit_block` | block_number=PROPblock_4, doi=10.1016/j.jct.2005.0… | 152 | — | — | 0.1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 5 | 10 | `propose_fitting_plan` | block_number=PROPblock_4, composition_hint=mole_fr… | 814 | — | — | 0.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 6 | 11 | `fit_block` | block_number=PROPblock_4, doi=10.1016/j.jct.2005.0… | 882 | — | — | 1.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 7 | 13 | `predict_from_rk` | coeffs=[-1.60102, 1.73493, -3.19748,…, n_points=20… | 171 | — | — | 0.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 8 | 14 | `list_session_files` |  | 1,678 | — | — | 0.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| **TOTAL** | **65** |  |  | **16,668** |  |  | **470.5** |  |


## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
| 1 | interval=3 | skipped_by_agent | 17,437 | 17,437 | 0 | 0.0% | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |


## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) | Source |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | --- |
| 1 | L0-main | claudeopus46 | 20,021 | 970 | 20,991 | 1,051 | 7.8 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 2 | L1-worker | claudeopus46 | 20,643 | 557 | 21,200 | 682 | 6.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 3 | L1-worker | claudeopus46 | 20,643 | 1,860 | 22,503 | 8,662 | 47.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 4 | L1-worker | claudeopus46 | 2,065 | 450 | 2,515 | 486 | 3.9 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,070 | 22,713 | 6,233 | 31.2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 6 | L1-worker | claudeopus46 | 2,065 | 7,812 | 9,877 | 1,956 | 15.5 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 7 | L1-worker | claudeopus46 | 20,610 | 3,897 | 24,507 | 583 | 5.1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,125 | 23,768 | 5,725 | 35.5 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 9 | L1-worker | claudeopus46 | 20,643 | 9,471 | 30,114 | 2,263 | 9.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 10 | L1-worker | claudeopus46 | 536 | 2,274 | 2,810 | 759 | 5.4 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 11 | L1-worker | claudeopus46 | 1,356 | 2,394 | 3,750 | 1,097 | 6.2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 12 | L1-worker | claudeopus46 | 1,323 | 5,589 | 6,912 | 1,175 | 7.2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 13 | L1-worker | claudeopus46 | 298 | 1,897 | 2,195 | 894 | 5.6 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 14 | L1-worker | claudeopus46 | 1,160 | 7,216 | 8,376 | 853 | 4.4 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 15 | L0-main | claudeopus46 | 20,021 | 1,807 | 21,828 | 855 | 6.3 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 16 | L1-worker | claudeopus46 | 20,643 | 498 | 21,141 | 998 | 6.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 17 | L1-worker | claudeopus46 | 20,643 | 2,224 | 22,867 | 9,494 | 44.5 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 18 | L1-worker | claudeopus46 | 2,065 | 513 | 2,578 | 756 | 7.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 19 | L1-worker | claudeopus46 | 2,065 | 415 | 2,480 | 552 | 4.3 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,984 | 23,627 | 10,192 | 50.9 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 21 | L1-worker | claudeopus46 | 2,065 | 7,809 | 9,874 | 1,952 | 14.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 22 | L1-worker | claudeopus46 | 20,610 | 4,849 | 25,459 | 439 | 3.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 23 | L1-worker | claudeopus46 | 20,643 | 4,077 | 24,720 | 5,589 | 33.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 24 | L1-worker | claudeopus46 | 20,643 | 5,092 | 25,735 | 11,885 | 64.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 25 | L1-worker | claudeopus46 | 2,065 | 357 | 2,422 | 380 | 3.8 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 26 | L1-worker | claudeopus46 | 2,065 | 376 | 2,441 | 453 | 4.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 27 | L1-worker | claudeopus46 | 20,643 | 5,952 | 26,595 | 2,537 | 15.4 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 28 | L1-worker | claudeopus46 | 1,356 | 2,173 | 3,529 | 893 | 5.9 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 29 | L1-worker | claudeopus46 | 536 | 2,053 | 2,589 | 945 | 6.1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 30 | L1-worker | claudeopus46 | 1,323 | 8,902 | 10,225 | 2,151 | 12.5 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 31 | L1-worker | claudeopus46 | 298 | 2,873 | 3,171 | 1,693 | 6.1 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 32 | L1-worker | claudeopus46 | 1,160 | 11,334 | 12,494 | 807 | 4.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 33 | L1-worker | claudeopus46 | 747 | 18,764 | 19,511 | 969 | 9.5 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 34 | L0-main | claudeopus46 | 20,021 | 14,860 | 34,881 | 968 | 11.6 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 35 | L0-main | claudeopus46 | 20,021 | 15,620 | 35,641 | 546 | 4.9 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 36 | L0-main | claudeopus46 | 20,021 | 16,291 | 36,312 | 670 | 5.9 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 37 | L0-main | claudeopus46 | 20,021 | 18,207 | 38,228 | 1,075 | 9.2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 38 | L0-main | claudeopus46 | 20,021 | 18,914 | 38,935 | 825 | 7.5 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 39 | L0-main | claudeopus46 | 20,021 | 19,544 | 39,565 | 928 | 6.7 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 40 | L0-main | claudeopus46 | 20,021 | 20,307 | 40,328 | 894 | 6.4 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 41 | L0-main | claudeopus46 | 19,988 | 20,795 | 40,783 | 560 | 6.9 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 42 | L0-main | claudeopus46 | 20,021 | 20,036 | 40,057 | 1,041 | 6.6 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 43 | L0-main | claudeopus46 | 20,021 | 21,435 | 41,456 | 1,289 | 9.3 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 44 | L0-main | claudeopus46 | 20,021 | 24,158 | 44,179 | 985 | 7.4 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 45 | L0-main | claudeopus46 | 20,021 | 24,874 | 44,895 | 757 | 5.2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 46 | L0-main | claudeopus46 | 20,021 | 25,275 | 45,296 | 801 | 7.2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 47 | L0-main | claudeopus46 | 20,021 | 27,445 | 47,466 | 9,811 | 67.2 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 48 | L0-main | claudeopus46 | 1,356 | 4,683 | 6,039 | 934 | 7.6 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 49 | L0-main | claudeopus46 | 1,323 | 33,526 | 34,849 | 1,199 | 10.6 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 50 | L0-main | claudeopus46 | 298 | 1,316 | 1,614 | 922 | 3.9 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 51 | L0-main | claudeopus46 | 298 | 2,041 | 2,339 | 964 | 4.8 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |
| 52 | L0-main | claudeopus46 | 1,562 | 6,239 | 7,801 | 1,086 | 10.0 | Find excess molar enthalpy (HE) data for the binary system e (analysis_runs/run_12) |

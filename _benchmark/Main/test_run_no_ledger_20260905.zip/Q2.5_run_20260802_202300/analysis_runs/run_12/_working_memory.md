# Working Memory

**ROOT:** `\\Sheldon.cse.anl.gov\yunkai.sun$\_Code_Maintenance\_outputs_user\yunkai.sun\ThermoML\Main\Q2.5_run_20260802_202300\analysis_runs\run_12`

### ID Catalog
| type | global_id | name | pure_values |
|------|--------|------|-------------|
| comp | GLOBcomp_2 | ethanol | 0.0 |
| comp | GLOBcomp_1 | water | 0.0 |
| prop | GLOBprop_17 | excessmolarenthalpymolarenthalpyofmixingkjmol |  |
| var | GLOBvar_1 | temperaturek |  |
| var | GLOBvar_2 | molefraction<ethanol> |  |
| constr | GLOBconstr_2 | temperature, k |  |
| constr | GLOBconstr_1 | pressurekpa |  |

### History
- [query_thermoml]
- [inspect_block]
- [fit_block] ERROR: Requested x column 'Mole fraction of ethanol' not found in block
- [propose_fitting_plan]
- [fit_block]
- [predict_from_rk]
- [list_session_files]

### Query Results
#### query
A ThermoML search for excess molar enthalpy (HE, kJ/mol) of binary ethanol (CAS 64-17-5) + water (CAS 7732-18-5) at 298.15 K found four data blocks. The richest is PROPblock_4 from DOI 10.1016/j.jct.2005.06.018 (GLOBlit_2574) with 27 points spanning 298.15–323.15 K, recommended for Redlich-Kister fitting after isolating the 298.15 K isotherm and verifying compound assignments (the parent publication concerns propanediols, so mapping should be confirmed). Two dilute-region blocks from DOI 10.1016/j.fluid.2007.06.007 (GLOBlit_528) cover partial composition ranges and could supplement the fit at low mole fractions. A single-point block from DOI 10.1016/j.tca.2017.05.023 (GLOBlit_6377) is useful only for validation. Typical HE values for this system at 298.15 K are exothermic, with a minimum near −0.8 to −0.9 kJ/mol around xethanol ≈ 0.2–0.3, attributed to favorable hydrogen-bonding interactions between ethanol and water.

**Data sources:**

| Literature ID | DOI | Block | Subsystem | Matching points | System | Declared system |
|---|---|---|---|---:|---|---|
| GLOBlit_2574 | 10.1016/j.jct.2005.06.018 | PROPblock_4 | declared | 27 | binary | binary |

**Status:** partial

### Inspected Blocks
- GLOBlit_2574 | 10.1016/j.jct.2005.06.018 | PROPblock_4: 27 rows; x=['mole_fraction_<ethanol>']; y=['excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol']
    - BLKprop_1 / GLOBprop_17: presentation=Direct value, X; reference=None; standard_state=None
      response gate BLKprop_1 / GLOBprop_17: kind=direct; materialize_reference=False; supported=True; units=kJ/mol -> kJ/mol

### Completed Fits
  - 10.1016/j.jct.2005.06.018/PROPblock_4 (ethanol, water): RK order=4, R²=0.998537, RMSE=0.008367192167912752, coeffs=[-1.601023, 1.734931, -3.19748, 3.113265, -2.361707]
      response: direct via X = reported X | 0 reference source(s) | kJ/mol -> kJ/mol
      pure refs: ethanol=0, water=0 [declared excess property: zero at pure limits]
      fit_csv: $ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv
      excess_csv: $ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv
      fit_plot: $ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png
      excess_plot: $ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png

## Session Output Files

### data
- `$ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.csv` — RK fit data — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- `$ROOT/data\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.csv` — Excess property — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1

### plot
- `$ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_fit.png` — RK fit plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1
- `$ROOT/plots\10_1016_j_jct_2005_06_018_BPROPblock_4_T298.1_excess.png` — Excess plot — 10.1016/j.jct.2005.06.018 PROPblock_4_T298.1


# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 0
- **API turns:** 1
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 15.4s
- **Timed out:** False

## Answer

# Density of Equimolar Propan-2-ol + Water Mixture at 25 °C

I do not have direct access to the ThermoML database in this session, so I cannot retrieve a specific measured value from that source. However, I can provide context based on well-established literature data for this system.

## What is known from the literature

The propan-2-ol (isopropanol, IPA) + water system is one of the most extensively studied binary aqueous-alcohol mixtures. Key points:

- **Pure component densities at 25 °C, ~1 atm:**
  - Water: ρ ≈ 0.99705 g·cm⁻³
  - Propan-2-ol: ρ ≈ 0.7809 g·cm⁻³

- **Equimolar mixture (x₁ = x₂ = 0.5):** At a mole fraction of 0.5 for isopropanol, the mass fraction of IPA is approximately 0.770 (since M_IPA = 60.10 g/mol vs M_water = 18.015 g/mol). This is a relatively IPA-rich mixture by mass.

- **Expected density:** Published measurements for this composition at 25 °C and atmospheric pressure typically report a density in the range of approximately **0.84–0.85 g·cm⁻³**, with many studies converging near **0.8440–0.8460 g·cm⁻³**.

- **Excess volume:** This system exhibits significant negative excess molar volumes (volume contraction on mixing), which is why the measured density is higher than what ideal mixing would predict. The strong hydrogen-bonding interactions between water and isopropanol lead to more efficient molecular packing.

## Important caveats

- Without querying the ThermoML database directly, I cannot cite a specific DOI, dataset, or exact measured value from that repository.
- Different studies may report slightly different values depending on sample purity, exact pressure, and measurement technique (vibrating-tube densimetry is most common).
- The equimolar composition (x_IPA = 0.5) corresponds to roughly 77 wt% IPA, so this is well into the alcohol-rich regime.

## Summary

A representative measured density for the equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure is approximately **0.845 g·cm⁻³** (845 kg·m⁻³). For a precise value traceable to a specific ThermoML entry, a direct database query would be needed.

# Q1.4 — Run History

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

This file is the audit record. For SQL calls, the fenced raw Markdown is
the exact payload supplied to the task-directed agentic compactor.

## Soft-budget events

```json
[]
```

# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 0
- **API turns:** 1
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 21.7s
- **Timed out:** False

## Answer

## Activity Coefficients of Aqueous Lithium Chloride Near 25 °C

Yes, activity coefficients for aqueous lithium chloride (LiCl) in water near 25 °C have been extensively measured and are well-documented in the thermodynamic literature. Here is what is known:

### General Chemical Knowledge

LiCl is one of the most thoroughly studied 1:1 electrolyte systems. Key points include:

- **Mean ionic activity coefficients (γ±)** have been measured over a very wide molality range, from dilute solutions (~0.001 mol/kg) up to very high concentrations (~20 mol/kg or even near saturation, which is approximately 19.9 m at 25 °C). LiCl is exceptionally soluble in water.

- **Classic sources** include:
  - **Robinson and Stokes** (*Electrolyte Solutions*, 1959) tabulated γ± values from isopiestic measurements up to about 6 m.
  - **Hamer and Wu** (1972, *J. Phys. Chem. Ref. Data*) provided critically evaluated activity coefficient data.
  - Various isopiestic, EMF (electromotive force), and vapor pressure studies extend the data to very high concentrations.

- **Typical values at 25 °C (298.15 K):**
  - At low molality (~0.1 m), γ± ≈ 0.79 (showing the usual Debye-Hückel depression).
  - γ± passes through a minimum around 0.5–1 m (γ± ≈ 0.74).
  - At higher concentrations, γ± rises steeply — for example, γ± ≈ 1.30 at 3 m, and γ± can exceed 10 at very high molalities (~10+ m).

- The strong increase in γ± at high concentration reflects the intense hydration of the small Li⁺ ion, which binds water molecules tightly, effectively reducing the "free" solvent and increasing the effective concentration (and thus the activity) of the solute.

### Concentration Range

| Molality range (mol/kg) | Typical data availability |
|---|---|
| 0.001 – 0.1 | EMF and dilute solution studies |
| 0.1 – 6 | Isopiestic measurements (Robinson & Stokes) |
| 6 – ~20 | Extended isopiestic and vapor pressure studies |

### ThermoML Database

I do not have direct access to the ThermoML database in this context, so I cannot confirm which specific ThermoML entries contain LiCl activity coefficient data or cite specific DOIs from that source. However, given that LiCl is a benchmark electrolyte system, it is very likely represented in ThermoML with data near 298.15 K.

### Chemical Insight

LiCl is notable among alkali halides for having the **largest activity coefficients at high concentration**, a consequence of:
1. The very small ionic radius of Li⁺ leading to strong ion-solvent interactions.
2. High solubility allowing measurements over an unusually broad concentration range.
3. Significant ion pairing is relatively minor compared to hydration effects.

This makes LiCl a critical test system for electrolyte solution theories (Pitzer equations, MSA models, etc.).

**In summary:** Yes, γ± for LiCl(aq) at ~25 °C is one of the most comprehensively measured activity coefficient datasets in electrolyte thermodynamics, spanning from very dilute (~0.001 m) to near-saturation (~20 m) concentrations.

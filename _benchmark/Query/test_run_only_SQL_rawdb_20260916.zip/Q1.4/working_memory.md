# Q1.4 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Lithium Chloride Entries in the Database

### Naming & Identifiers (Task 2)

| Field | Value |
|---|---|
| **common_name** | `lithium chloride` (78 entries); `lithium chloride monohydrate` (1 entry) |
| **formula** | `ClLi` (anhydrous); `ClH2LiO` (monohydrate) |
| **cas_rn** | `NULL` for all rows (no CAS RN stored) |
| **standard_inchi_key** | `KWGKDLIKAYFUFQ-UHFFFAOYSA-M` (anhydrous); `VXJIMUZIBHBWBV-UHFFFAOYSA-M` (monohydrate) |

### DOIs Containing Lithium Chloride (Task 1) — 79 distinct papers

| # | DOI |
|---|---|
| 1 | 10.1007/s10765-019-2558-5 |
| 2 | 10.1016/j.fluid.2004.10.018 |
| 3 | 10.1016/j.fluid.2005.07.002 |
| 4 | 10.1016/j.fluid.2006.02.012 |
| 5 | 10.1016/j.fluid.2006.10.018 |
| 6 | 10.1016/j.fluid.2011.09.016 |
| 7 | 10.1016/j.fluid.2013.12.017 |
| 8 | 10.1016/j.fluid.2014.01.037 |
| 9 | 10.1016/j.fluid.2014.08.026 |
| 10 | 10.1016/j.fluid.2015.02.009 |
| 11 | 10.1016/j.fluid.2015.08.005 |
| 12 | 10.1016/j.fluid.2015.09.005 |
| 13 | 10.1016/j.fluid.2015.11.018 |
| 14 | 10.1016/j.fluid.2016.12.013 |
| 15 | 10.1016/j.fluid.2017.12.034 |
| 16 | 10.1016/j.fluid.2019.04.018 |
| 17 | 10.1016/j.jct.2003.12.002 |
| 18 | 10.1016/j.jct.2004.01.004 |
| 19 | 10.1016/j.jct.2004.09.015 |
| 20 | 10.1016/j.jct.2006.06.014 |
| 21 | 10.1016/j.jct.2007.05.002 |
| 22 | 10.1016/j.jct.2008.12.003 |
| 23 | 10.1016/j.jct.2008.12.022 |
| 24 | 10.1016/j.jct.2009.03.005 |
| 25 | 10.1016/j.jct.2011.03.002 |
| 26 | 10.1016/j.jct.2013.03.009 |
| 27 | 10.1016/j.jct.2013.07.024 |
| 28 | 10.1016/j.jct.2013.08.018 |
| 29 | 10.1016/j.jct.2013.10.028 |
| 30 | 10.1016/j.jct.2016.07.003 |
| 31 | 10.1016/j.jct.2017.02.004 |
| 32 | 10.1016/j.jct.2018.10.003 |
| 33 | 10.1016/j.jct.2018.10.023 |
| 34 | 10.1016/j.jct.2018.12.011 |
| 35 | 10.1016/j.jct.2018.12.016 |
| 36 | 10.1016/j.jct.2019.105878 |
| 37 | 10.1016/j.tca.2004.11.004 |
| 38 | 10.1016/j.tca.2009.01.008 |
| 39 | 10.1016/j.tca.2012.08.009 |
| 40 | 10.1016/j.tca.2013.04.009 *(monohydrate)* |
| 41 | 10.1016/j.tca.2017.03.024 |
| 42 | 10.1016/j.tca.2019.178334 |
| 43–62 | 10.1021/acs.jced.5b00121 through 10.1021/acs.jced.9b00561 (20 papers) |
| 63–79 | 10.1021/je020144o through 10.1021/je900656c (17 papers) |

**No rows were omitted; no truncation occurred.** The query returned all 79 rows. CAS RN is null for every lithium chloride entry in the database.

## 2. execute_sql

## Compacted Result

The query returned **3 distinct property names** containing "activity":

| prop_name | prop_group |
|---|---|
| (Relative) activity | ActivityFugacityOsmoticProp |
| Activity coefficient | ActivityFugacityOsmoticProp |
| Mean ionic activity coefficient | ActivityFugacityOsmoticProp |

**Key finding for the task:** The exact `prop_name` strings relevant to activity coefficients are **`"Activity coefficient"`** and **`"Mean ionic activity coefficient"`**. For an electrolyte like LiCl, the most applicable is **`"Mean ionic activity coefficient"`**.

## 3. execute_sql

## Compacted Result

### Blocks containing activity coefficient data for LiCl

All results come from a single DOI: **10.1016/j.fluid.2014.08.026**

| block_number | prop_name | n_datapoints | n_components | component_org_nums |
|---|---|---|---|---|
| 9 | Mean ionic activity coefficient | 130 | 3 | [1, 6, 2] |
| 10 | Mean ionic activity coefficient | 144 | 3 | [3, 6, 2] |
| 11 | Mean ionic activity coefficient | 156 | 3 | [4, 6, 2] |
| 12 | Mean ionic activity coefficient | 134 | 3 | [5, 6, 2] |
| 13 | Mean ionic activity coefficient | 141 | 2 | [6, 2] |

**5 rows total; no truncation.**

- **Block 13** is a 2-component system (likely binary LiCl + water).
- **Blocks 9–12** are 3-component systems (LiCl + water + a third component).
- No rows matched the plain "Activity coefficient" property name; all matches are "Mean ionic activity coefficient."
- Temperature and concentration range details are not included in this index query; they would require inspection of the underlying datapoints/variables.

## 4. execute_sql

## Compound Mapping for DOI 10.1016/j.fluid.2014.08.026

| org_num | common_name | formula |
|---------|--------------------------|---------|
| 1 | urea | CH4N2O |
| 2 | water | H2O |
| 3 | N-methylformamide | C2H5NO |
| 4 | dimethylformamide | C3H7NO |
| 5 | N,N-dimethylethanamide | C4H9NO |
| 6 | lithium chloride | ClLi |

**Task answers:**
- **org_num 6** → lithium chloride (LiCl)
- **org_num 2** → water

6 compounds total; no rows omitted or truncated.

## 5. execute_sql

## Variables in Block 13 (Binary LiCl + Water Activity Coefficient Block)

| block_number | var_number | var_type |
|---|---|---|
| 13 | 1 | Molality, mol/kg |

**Summary:** Block 13 contains a single variable — **Molality (mol/kg)**. No temperature variable is present in this block (temperature may instead be specified as a constraint or fixed condition rather than a varied parameter).

## 6. execute_sql

## Compacted Result for Block 13 Datapoints

### Task 3: Temperature as a Constraint
**The `constraints` column is `null` for all 5 sampled rows.** Temperature is **not** stored as a constraint in this block. (It is likely stored as a block-level fixed condition or elsewhere in the block metadata, not per-datapoint.)

### Task 1 & 2: Structure of Variable and Property Values

**Variable (var_number = 1):** Molality values  
**Property (prop_number = 1):** Activity coefficient values (with combined expanded uncertainty)

| Molality (nVarValue) | Activity Coeff. (nPropValue) | Expanded Uncertainty |
|---|---|---|
| 0.0035 | 0.9388 | ±0.0201 |
| 0.0072 | 0.9160 | ±0.0204 |
| 0.0109 | 0.9005 | ±0.0205 |
| 0.0148 | 0.8881 | ±0.0207 |
| 0.0187 | 0.8776 | ±0.0208 |

- **5 rows returned; not truncated.**
- All variable entries use `nVarNumber: 1`; all property entries use `nPropNumber: 1`.
- `nVarDigits` ranges 2–3; `nPropDigits` = 4 throughout.
- Uncertainty assessment number (`nCombUncertAssessNum`) = 1 for all rows.

### Key Takeaway
Temperature is **not present** in these per-datapoint records (no constraint field). The molality range in this 5-row sample spans **0.0035 – 0.0187 mol/kg**. A separate query for block-level temperature or the full datapoint range would be needed to determine the measurement temperature and complete concentration range.

## 7. execute_sql

## Compacted Result for Block 13

### Fixed Constraints

| # | Type | Value | Phase |
|---|------|-------|-------|
| 1 | Temperature, K | **298.15** | Liquid |
| 2 | Pressure, kPa | 101 | Liquid |

### Property Definition

| Field | Value |
|-------|-------|
| Property name | **Mean ionic activity coefficient** |
| Property group | ActivityFugacityOsmoticProp |
| Method | Calculated from EMF cell potential |
| Presentation | Direct value, X |
| Phase | Liquid |
| Solvent | Component nOrgNum = 2 |
| Uncertainty | Propagation of evaluated standard uncertainties, 95% confidence |

### Summary for tasks
1. **Temperature**: The mean ionic activity coefficient was measured at a fixed temperature of **298.15 K** (≈ 25 °C).
2. **Property confirmed**: The property is "Mean ionic activity coefficient" with fixed constraints of 298.15 K and 101 kPa, both in the liquid phase.

## 8. execute_sql

## Compacted Result: LiCl + Water Mean Ionic Activity Coefficients at 298.15 K

**Source:** DOI `10.1016/j.fluid.2014.08.026`, PureOrMixtureData block 13

### Summary Statistics

| Metric | Value |
|---|---|
| Total datapoints | **141** |
| Molality min | **0.0033 mol/kg** |
| Molality max | **1.5555 mol/kg** |
| γ± at lowest molality | 0.9425 |
| γ± at highest molality | 0.8461 |

### Representative Activity Coefficient Values Across the Concentration Range

| Molality (mol/kg) | γ± |
|---|---|
| 0.0033 | 0.9425 |
| 0.0072 | 0.9160 |
| 0.0148 | 0.8881 |
| 0.0271 | 0.8599 |
| 0.0494 | 0.8291 |
| 0.0804 | 0.8032 |
| 0.1138 | 0.7852 |
| 0.1667 | 0.7671 |
| 0.2543 | 0.7509 |
| 0.3496 | 0.7430 |
| 0.4500 | 0.7406 |
| 0.5253 | 0.7414 |
| 0.6596 | 0.7466 |
| 0.7946 | 0.7554 |
| 0.8876 | 0.7631 |
| 1.0038 | 0.7742 |
| 1.1197 | 0.7869 |
| 1.2603 | 0.8041 |
| 1.3645 | 0.8180 |
| 1.5095 | 0.8390 |
| 1.5555 | 0.8461 |

**Notes:**
- The full 141-row dataset was returned (not truncated). The table above shows 21 representative rows spanning the full range; the remaining 120 rows follow the same monotonic pattern (γ± decreases from ~0.94 to a minimum of ~0.74 near 0.45–0.53 mol/kg, then increases back to ~0.85).
- Some molalities have duplicate measurements with slightly different γ± values (e.g., 0.0033 → 0.9425 & 0.9398), suggesting replicate or multi-source data.

## 9. execute_sql

## Compacted Result

**Query:** Activity coefficient / osmotic data for LiCl in papers other than `10.1016/j.fluid.2014.08.026`

**Result: 73 rows returned — 4 additional DOIs found**

| DOI | Property | # Blocks | Total Datapoints | Components |
|-----|----------|----------|-----------------|------------|
| `10.1016/j.jct.2013.08.018` | Osmotic coefficient | 57 | ~600+ | Mostly 3-component (ternary) mixtures; some 2-component |
| `10.1016/j.jct.2016.07.003` | Osmotic coefficient, (Relative) activity | 5 | 120 | 2- and 3-component |
| `10.1016/j.jct.2019.105878` | Osmotic coefficient | 3 | 50 | 2- and 3-component |
| `10.1021/acs.jced.5b00987` | (Relative) activity | 1 | 209 | 3-component |
| `10.1021/acs.jced.6b00046` | (Relative) activity | 7 | 109 | 2-component |

### Key findings

1. **The previously identified DOI (`10.1016/j.fluid.2014.08.026`) is NOT the only source.** Four additional DOIs contain activity-related (osmotic coefficient or relative activity) data for systems involving lithium chloride.
2. **No "Mean ionic activity coefficient" or plain "Activity coefficient" rows** were found — all additional data are reported as **Osmotic coefficient** or **(Relative) activity**.
3. Most blocks are for **ternary mixtures** (3 components including LiCl); some are binary (2 components). The `component_org_nums` lists vary, indicating LiCl is mixed with various co-solutes/solvents.
4. No rows were omitted; all 73 rows are accounted for in the summary above.

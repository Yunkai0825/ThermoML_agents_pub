# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 9
- **API turns:** 8
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 158.8s
- **Timed out:** False

## Answer

Excellent. Now I have a comprehensive picture. Let me provide the answer.

---

## Mean Ionic Activity Coefficients of Aqueous LiCl near 25 °C — ThermoML Evidence

**Yes**, mean ionic activity coefficients (γ±) have been measured for aqueous lithium chloride at 25 °C and are recorded in the ThermoML database.

### Primary Dataset

**Source:** DOI [10.1016/j.fluid.2014.08.026](https://doi.org/10.1016/j.fluid.2014.08.026)

| Detail | Value |
|---|---|
| **Property** | Mean ionic activity coefficient (γ±) |
| **System** | Binary: LiCl + water |
| **Temperature** | 298.15 K (25.00 °C), fixed |
| **Pressure** | 101 kPa |
| **Method** | Calculated from EMF cell potential |
| **Number of datapoints** | 141 |
| **Molality range** | **0.0033 – 1.556 mol/kg** |

### Representative Values

| Molality (mol/kg) | γ± |
|---|---|
| 0.0033 | 0.943 |
| 0.015 | 0.888 |
| 0.050 | 0.829 |
| 0.114 | 0.785 |
| 0.255 | 0.751 |
| 0.450 | 0.741 |
| 0.525 | 0.741 |
| 0.795 | 0.755 |
| 1.004 | 0.774 |
| 1.260 | 0.804 |
| 1.556 | 0.846 |

### Physical Interpretation

The data beautifully illustrate the classic behavior of a strong 1:1 electrolyte in water:

1. **Dilute regime (m < ~0.1 mol/kg):** γ± decreases steeply from near unity, consistent with **Debye–Hückel theory** — long-range electrostatic ion–ion interactions lower the activity coefficient.

2. **Minimum near ~0.45–0.53 mol/kg:** γ± reaches a minimum of approximately **0.741**, after which short-range ion–solvent and ion–ion interactions begin to dominate.

3. **Concentrated regime (m > ~0.5 mol/kg):** γ± **increases** with concentration. This is characteristic of LiCl, where the small, highly charge-dense Li⁺ ion strongly structures its hydration shell. As concentration rises, ion pairing, hydration shell overlap, and reduced water activity all drive γ± upward. LiCl is well known for having γ± values that exceed unity at high concentrations (typically above ~2–3 mol/kg), though this dataset stops at ~1.56 mol/kg where γ± ≈ 0.85 and is still rising.

### Additional Related Data

The database also contains **osmotic coefficient** and **(relative) activity** data for LiCl systems in several other papers (DOIs: 10.1016/j.jct.2013.08.018, 10.1016/j.jct.2016.07.003, 10.1016/j.jct.2019.105878, 10.1021/acs.jced.5b00987, 10.1021/acs.jced.6b00046), mostly for ternary mixtures (LiCl + water + a co-solute). These are thermodynamically related quantities — the osmotic coefficient can be converted to γ± via the Gibbs–Duhem equation — but the direct mean ionic activity coefficient measurements at 298.15 K come from the single binary dataset described above.

# Q1.5 — Run History

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

This file is the audit record. For SQL calls, the fenced raw Markdown is
the exact payload supplied to the task-directed agentic compactor.

## Soft-budget events

```json
[
  {
    "turn": 20,
    "strike": 1,
    "final_chance": false
  }
]
```

## Step 1: execute_sql

### Call arguments

```json
{
  "query": "SELECT DISTINCT c.doi, c.org_num, c.common_name, c.standard_inchi_key, c.cas_rn\nFROM raw.compounds c\nWHERE (c.common_name LIKE '%ethanol%' OR c.common_name LIKE '%Ethanol%')\n  AND c.common_name NOT LIKE '%methanol%'\n  AND c.common_name NOT LIKE '%propanol%'\n  AND c.common_name NOT LIKE '%butanol%'\n  AND c.common_name NOT LIKE '%dimethyl%'\n  AND c.common_name NOT LIKE '%phenyl%'\n  AND c.common_name NOT LIKE '%amino%'\n  AND c.common_name NOT LIKE '%chloro%'\n  AND c.common_name NOT LIKE '%fluoro%'\n  AND c.common_name NOT LIKE '%nitro%'\n  AND c.common_name NOT LIKE '%mercapto%'\n  AND c.common_name NOT LIKE '%ethoxy%'\nLIMIT 20",
  "purpose": "Find ethanol compound entries in the database to identify DOIs and org_nums for ethanol",
  "tasks": [
    "Identify the standard_inchi_key and cas_rn for ethanol",
    "Get a list of DOIs containing ethanol data"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Find ethanol compound entries in the database to identify DOIs and org_nums for ethanol

## SQL tasks

```json
["Identify the standard_inchi_key and cas_rn for ethanol","Get a list of DOIs containing ethanol data"]
```

## Executed SQL (visible form)

```sql
SELECT DISTINCT c.doi, c.org_num, c.common_name, c.standard_inchi_key, c.cas_rn
FROM raw.compounds c
WHERE (c.common_name LIKE '%ethanol%' OR c.common_name LIKE '%Ethanol%')
  AND c.common_name NOT LIKE '%methanol%'
  AND c.common_name NOT LIKE '%propanol%'
  AND c.common_name NOT LIKE '%butanol%'
  AND c.common_name NOT LIKE '%dimethyl%'
  AND c.common_name NOT LIKE '%phenyl%'
  AND c.common_name NOT LIKE '%amino%'
  AND c.common_name NOT LIKE '%chloro%'
  AND c.common_name NOT LIKE '%fluoro%'
  AND c.common_name NOT LIKE '%nitro%'
  AND c.common_name NOT LIKE '%mercapto%'
  AND c.common_name NOT LIKE '%ethoxy%'
LIMIT 20
```

## Result metadata

- Rows serialized: 20
- Truncated by max_rows: No.
- Elapsed seconds: 0.003876

## Columns

```json
["doi","org_num","common_name","standard_inchi_key","cas_rn"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1007/s10765-005-8089-2",2,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1007/s10765-008-0410-4",2,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1007/s10765-011-0987-x",2,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1007/s10765-011-1086-8",7,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1007/s10765-014-1740-z",3,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1007/s10765-016-2103-8",2,"diethanolamine","ZBCBWPMODOFKDW-UHFFFAOYSA-N",null]
["10.1007/s10765-016-2103-8",3,"N-methyldiethanolamine","CRVGTESFCCXCTH-UHFFFAOYSA-N",null]
["10.1007/s10765-017-2283-x",3,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1007/s10765-017-2323-6",2,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1007/s10765-019-2506-4",3,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2004.07.017",5,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2004.11.018",4,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2004.11.019",2,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2004.11.022",2,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2005.01.002",7,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2005.01.004",1,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2005.01.007",2,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2005.02.009",3,"2-isopropoxyethanol","HCGFUIQPSOCUHI-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2005.02.015",1,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1016/j.fluid.2005.03.016",3,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted Result

### Task 1: Ethanol identifiers

| Field | Value |
|---|---|
| **standard_inchi_key** | `LFQSCWFLJHTTHZ-UHFFFAOYSA-N` |
| **cas_rn** | `NULL` (not populated in any returned row) |
| **common_name** | `ethanol` |

### Task 2: DOIs containing ethanol data (first 20 rows shown)

Two rows were **not** pure ethanol (diethanolamine, N-methyldiethanolamine, 2-isopropoxyethanol) and are excluded below. The remaining 17 ethanol-specific DOIs with their `org_num` values:

| doi | org_num |
|---|---|
| 10.1007/s10765-005-8089-2 | 2 |
| 10.1007/s10765-008-0410-4 | 2 |
| 10.1007/s10765-011-0987-x | 2 |
| 10.1007/s10765-011-1086-8 | 7 |
| 10.1007/s10765-014-1740-z | 3 |
| 10.1007/s10765-017-2283-x | 3 |
| 10.1007/s10765-017-2323-6 | 2 |
| 10.1007/s10765-019-2506-4 | 3 |
| 10.1016/j.fluid.2004.07.017 | 5 |
| 10.1016/j.fluid.2004.11.018 | 4 |
| 10.1016/j.fluid.2004.11.019 | 2 |
| 10.1016/j.fluid.2004.11.022 | 2 |
| 10.1016/j.fluid.2005.01.002 | 7 |
| 10.1016/j.fluid.2005.01.004 | 1 |
| 10.1016/j.fluid.2005.01.007 | 2 |
| 10.1016/j.fluid.2005.02.015 | 1 |
| 10.1016/j.fluid.2005.03.016 | 3 |

**Note:** Query was capped at `LIMIT 20`; additional ethanol-containing DOIs likely exist in the database beyond this sample.
```

### Integrity and timing

- Raw SHA-256: 79c50689cb63b30f25e96dcf694326e711e04acf544a6d68b2eaf502bd894ac6
- Raw characters: 2839
- Hardcoded-compacted characters: 0
- Model-visible characters: 1238
- Agentic verdict: COMPACTED
- Tool elapsed: 0.004s
- Compactor elapsed: 10.012s
- Total elapsed: 10.016s

## Step 2: execute_sql

### Call arguments

```json
{
  "query": "SELECT bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name, bp.presentation,\n       b.n_components, b.n_datapoints\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.compounds c ON c.doi = bp.doi\nWHERE c.common_name = 'ethanol'\n  AND c.standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N'\n  AND bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\nORDER BY bp.doi",
  "purpose": "Find all viscosity measurements for pure ethanol across all DOIs, including method information",
  "tasks": [
    "List all DOIs with pure ethanol viscosity data",
    "Identify the measurement methods (method_type, method_name) used",
    "Note the number of datapoints per block"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool error

**Error:** Query returned more than max_rows=500. Run narrower SQL with filters, aggregation, or an explicit LIMIT. No partial row payload was returned and no semantic compaction was performed.

## SQL purpose

Find all viscosity measurements for pure ethanol across all DOIs, including method information

## SQL tasks

```json
["List all DOIs with pure ethanol viscosity data","Identify the measurement methods (method_type, method_name) used","Note the number of datapoints per block"]
```

## Submitted SQL (visible form)

```sql
SELECT bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name, bp.presentation,
       b.n_components, b.n_datapoints
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.compounds c ON c.doi = bp.doi
WHERE c.common_name = 'ethanol'
  AND c.standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N'
  AND bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
ORDER BY bp.doi
```

No row payload was returned and no semantic compaction was performed.

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

````markdown
# Compacted Result

## Status: Query exceeded 500-row limit — no data returned

The SQL query matching pure-ethanol viscosity blocks returned **more than 500 rows**, so the database returned **zero rows** of actual data. No DOIs, method information, or datapoint counts are available from this result.

### What was omitted
All row-level data was omitted by the database engine itself (not by compaction). No partial payload was provided.

### Implications for each SQL task

| Task | Status |
|---|---|
| **1. List all DOIs with pure ethanol viscosity data** | ❌ Not available — query must be narrowed (e.g., add aggregation or LIMIT) |
| **2. Identify measurement methods (method_type, method_name)** | ❌ Not available |
| **3. Note number of datapoints per block** | ❌ Not available |

### Suggested remedy
Re-run with aggregation, e.g.:

```sql
SELECT bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name,
       bp.presentation, b.n_datapoints
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
WHERE bp.doi IN (SELECT DISTINCT c.doi FROM raw.compounds c WHERE c.standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
  AND bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
GROUP BY bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name, bp.presentation, b.n_datapoints
ORDER BY bp.doi
LIMIT 500
```

This should deduplicate rows caused by the JOIN to `compounds` (papers with multiple compounds produce cross-product rows) and enforce a row cap.
````

### Integrity and timing

- Raw SHA-256: 4ac7dc14bd1c655157161474184f3171adbac7d15f09264d7126618d4988e024
- Raw characters: 1151
- Hardcoded-compacted characters: 0
- Model-visible characters: 1612
- Agentic verdict: ERROR
- Tool elapsed: 0.120s
- Compactor elapsed: 11.141s
- Total elapsed: 11.262s

## Step 3: execute_sql

### Call arguments

```json
{
  "query": "SELECT bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name,\n       bp.presentation, b.n_datapoints\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nWHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')\n  AND bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\nGROUP BY bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name, bp.presentation, b.n_datapoints\nORDER BY bp.doi\nLIMIT 200",
  "purpose": "Find all viscosity measurements for pure ethanol with method details",
  "tasks": [
    "List all DOIs with pure ethanol viscosity data",
    "Identify the measurement methods (method_type, method_name) used",
    "Note the number of datapoints per block"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Find all viscosity measurements for pure ethanol with method details

## SQL tasks

```json
["List all DOIs with pure ethanol viscosity data","Identify the measurement methods (method_type, method_name) used","Note the number of datapoints per block"]
```

## Executed SQL (visible form)

```sql
SELECT bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name,
       bp.presentation, b.n_datapoints
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
  AND bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
GROUP BY bp.doi, bp.block_number, bp.prop_name, bp.method_type, bp.method_name, bp.presentation, b.n_datapoints
ORDER BY bp.doi
LIMIT 200
```

## Result metadata

- Rows serialized: 200
- Truncated by max_rows: No.
- Elapsed seconds: 0.043246

## Columns

```json
["doi","block_number","prop_name","method_type","method_name","presentation","n_datapoints"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1007/s10765-005-8089-2",1,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",23]
["10.1007/s10765-005-8089-2",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",23]
["10.1016/j.fluid.2005.05.012",1,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.fluid.2005.05.012",3,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.fluid.2005.05.012",5,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.fluid.2005.05.012",7,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.fluid.2005.05.012",9,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.fluid.2005.05.012",11,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.fluid.2005.05.012",13,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.fluid.2005.07.010",3,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",1]
["10.1016/j.fluid.2005.07.010",6,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",1]
["10.1016/j.fluid.2005.07.010",9,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",1]
["10.1016/j.fluid.2006.01.008",3,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.fluid.2006.01.008",7,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.fluid.2006.01.008",11,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.fluid.2006.01.008",15,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.fluid.2006.01.008",19,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.fluid.2006.01.030",1,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",20]
["10.1016/j.fluid.2006.01.030",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",3]
["10.1016/j.fluid.2006.01.030",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",20]
["10.1016/j.fluid.2006.01.030",4,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",4]
["10.1016/j.fluid.2006.02.023",2,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",5,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",8,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",11,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",14,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",17,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",20,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",23,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",26,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2006.02.023",29,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",1]
["10.1016/j.fluid.2007.03.021",3,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.fluid.2007.08.006",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",3]
["10.1016/j.fluid.2007.08.006",5,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",3]
["10.1016/j.fluid.2007.08.006",8,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",3]
["10.1016/j.fluid.2010.07.005",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",6]
["10.1016/j.fluid.2015.04.022",2,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.fluid.2015.04.022",4,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.fluid.2016.08.022",3,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",11]
["10.1016/j.fluid.2016.08.022",6,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",3]
["10.1016/j.fluid.2017.06.001",4,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",7]
["10.1016/j.jct.2005.04.019",1,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.04.019",4,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.04.019",7,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.04.019",10,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.04.019",13,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.04.019",15,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.04.019",17,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.04.019",19,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2005.06.011",2,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2005.06.011",6,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2005.06.011",10,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2005.06.011",14,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2005.06.011",18,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",3]
["10.1016/j.jct.2005.06.011",22,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2005.06.011",26,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2005.07.008",1,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",4]
["10.1016/j.jct.2005.07.008",3,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",1]
["10.1016/j.jct.2005.07.008",5,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",4]
["10.1016/j.jct.2005.07.008",6,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",4]
["10.1016/j.jct.2005.10.022",2,"Viscosity, Pa*s","custom","Schott-Gerate viscometer model AVS 350","Direct value, X",3]
["10.1016/j.jct.2005.10.022",5,"Viscosity, Pa*s","custom","Schott-Gerate viscometer model AVS 350","Direct value, X",3]
["10.1016/j.jct.2005.10.022",8,"Viscosity, Pa*s","custom","Schott-Gerate viscometer model AVS 350","Direct value, X",3]
["10.1016/j.jct.2005.10.022",11,"Viscosity, Pa*s","custom","Schott-Gerate viscometer model AVS 350","Direct value, X",3]
["10.1016/j.jct.2005.10.022",14,"Viscosity, Pa*s","custom","Schott-Gerate viscometer model AVS 350","Direct value, X",3]
["10.1016/j.jct.2005.10.022",17,"Viscosity, Pa*s","custom","Schott-Gerate viscometer model AVS 350","Direct value, X",3]
["10.1016/j.jct.2005.10.022",20,"Viscosity, Pa*s","custom","Schott-Gerate viscometer model AVS 350","Direct value, X",3]
["10.1016/j.jct.2005.12.010",1,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",3]
["10.1016/j.jct.2005.12.010",4,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",3]
["10.1016/j.jct.2005.12.010",7,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",3]
["10.1016/j.jct.2005.12.010",10,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",3]
["10.1016/j.jct.2005.12.010",13,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",3]
["10.1016/j.jct.2005.12.010",16,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",3]
["10.1016/j.jct.2005.12.010",19,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",3]
["10.1016/j.jct.2006.03.010",1,"Viscosity, Pa*s","custom","CAPTUB:UFactor:2","Direct value, X",2]
["10.1016/j.jct.2006.03.010",4,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",2]
["10.1016/j.jct.2006.03.010",7,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",2]
["10.1016/j.jct.2006.03.010",10,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",2]
["10.1016/j.jct.2006.03.010",13,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",2]
["10.1016/j.jct.2006.03.018",2,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2006.03.018",6,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2006.03.018",10,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2006.03.018",14,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2006.03.018",18,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2006.03.018",22,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2006.03.018",26,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2006.06.008",1,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",3]
["10.1016/j.jct.2006.06.008",4,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",3]
["10.1016/j.jct.2006.06.008",7,"Viscosity, Pa*s","custom","CAPTUB::UFactor:4","Direct value, X",3]
["10.1016/j.jct.2006.06.008",10,"Viscosity, Pa*s","custom","CAPTUB::UFactor:4","Direct value, X",3]
["10.1016/j.jct.2006.06.008",13,"Viscosity, Pa*s","custom","CAPTUB::UFactor:4","Direct value, X",3]
["10.1016/j.jct.2006.10.016",1,"Viscosity, Pa*s","custom","CAPTUB::UFactor:6","Direct value, X",5]
["10.1016/j.jct.2006.10.016",3,"Viscosity, Pa*s","custom","CAPTUB::UFactor:6","Direct value, X",5]
["10.1016/j.jct.2006.10.016",5,"Viscosity, Pa*s","custom","CAPTUB::UFactor:6","Direct value, X",5]
["10.1016/j.jct.2006.10.016",7,"Viscosity, Pa*s","custom","CAPTUB::UFactor:6","Direct value, X",5]
["10.1016/j.jct.2006.10.016",9,"Viscosity, Pa*s","custom","CAPTUB:UFactor:6","Direct value, X",5]
["10.1016/j.jct.2007.05.004",1,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2007.05.004",3,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2007.05.004",5,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2007.05.004",7,"Viscosity, Pa*s","custom","CAPTUB::UFactor:2","Direct value, X",3]
["10.1016/j.jct.2008.03.013",2,"Viscosity, Pa*s","custom","CAPTUB::UFactor:8","Direct value, X",3]
["10.1016/j.jct.2008.03.013",5,"Viscosity, Pa*s","custom","CAPTUB::UFactor:8","Direct value, X",3]
["10.1016/j.jct.2008.03.013",8,"Viscosity, Pa*s","custom","CAPTUB:UFactor:8","Direct value, X",4]
["10.1016/j.jct.2008.04.006",2,"Viscosity, Pa*s","custom","CAPTUB::UFactor:8","Direct value, X",3]
["10.1016/j.jct.2008.04.006",5,"Viscosity, Pa*s","custom","CAPTUB::UFactor:16","Direct value, X",3]
["10.1016/j.jct.2008.04.006",8,"Viscosity, Pa*s","custom","CAPTUB:UFactor:16","Direct value, X",3]
["10.1016/j.jct.2009.06.023",1,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",11]
["10.1016/j.jct.2009.06.023",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",11]
["10.1016/j.jct.2009.06.023",5,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",11]
["10.1016/j.jct.2009.06.023",7,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",13]
["10.1016/j.jct.2010.01.013",3,"Viscosity, Pa*s","custom","unknown","Direct value, X",5]
["10.1016/j.jct.2010.03.022",2,"Viscosity, Pa*s","custom","CAPTUB:UFactor:4","Direct value, X",23]
["10.1016/j.jct.2011.06.002",2,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",4]
["10.1016/j.jct.2011.08.028",13,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",10]
["10.1016/j.jct.2012.01.013",1,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.01.013",4,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.01.013",6,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.01.013",8,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.01.013",10,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.02.027",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",10]
["10.1016/j.jct.2012.02.027",5,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",10]
["10.1016/j.jct.2012.02.027",8,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2012.02.027",11,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2012.02.027",14,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2012.05.001",1,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.05.001",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.08.024",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",7]
["10.1016/j.jct.2012.08.024",4,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",7]
["10.1016/j.jct.2012.10.008",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.10.008",6,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.10.008",7,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",2]
["10.1016/j.jct.2012.10.008",10,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.10.008",13,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2012.10.008",17,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2013.08.021",5,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",11]
["10.1016/j.jct.2013.09.006",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",3]
["10.1016/j.jct.2013.09.044",2,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.09.044",4,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.09.044",6,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.09.044",8,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",5,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",7,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",9,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",11,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",13,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",15,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2013.11.026",17,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",1]
["10.1016/j.jct.2014.01.030",5,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",11]
["10.1016/j.jct.2015.02.024",4,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",8]
["10.1016/j.jct.2015.04.027",2,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2015.04.027",4,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2015.04.027",6,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2015.04.027",8,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2015.04.027",10,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2015.08.017",2,"Viscosity, Pa*s","standard","Oscillating disk viscometry","Direct value, X",4]
["10.1016/j.jct.2015.08.036",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",5]
["10.1016/j.jct.2016.01.012",8,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",5]
["10.1016/j.jct.2016.06.028",2,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",8]
["10.1016/j.jct.2016.07.017",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",9]
["10.1016/j.jct.2016.08.008",4,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",8]
["10.1016/j.jct.2016.12.036",1,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2016.12.036",4,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2016.12.036",7,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2016.12.036",10,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2016.12.036",13,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2016.12.036",16,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2016.12.036",19,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1016/j.jct.2017.03.004",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",7]
["10.1016/j.jct.2017.07.022",2,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",7]
["10.1016/j.jct.2017.07.022",4,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",7]
["10.1016/j.jct.2017.07.022",6,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",7]
["10.1016/j.jct.2018.02.014",2,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",8]
["10.1016/j.jct.2018.02.022",3,"Viscosity, Pa*s","standard","Concentric cylinders viscometry","Direct value, X",4]
["10.1016/j.jct.2018.02.022",6,"Viscosity, Pa*s","standard","Concentric cylinders viscometry","Direct value, X",4]
["10.1016/j.jct.2018.02.022",9,"Viscosity, Pa*s","standard","Concentric cylinders viscometry","Direct value, X",4]
["10.1016/j.jct.2018.02.022",12,"Viscosity, Pa*s","standard","Concentric cylinders viscometry","Direct value, X",4]
["10.1016/j.jct.2018.02.022",15,"Viscosity, Pa*s","standard","Concentric cylinders viscometry","Direct value, X",4]
["10.1016/j.jct.2018.02.022",18,"Viscosity, Pa*s","standard","Concentric cylinders viscometry","Direct value, X",4]
["10.1016/j.jct.2019.02.019",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",4]
["10.1016/j.jct.2019.02.019",4,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",4]
["10.1016/j.jct.2019.02.019",6,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",4]
["10.1016/j.jct.2019.04.023",1,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",7]
["10.1016/j.jct.2019.04.023",3,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",7]
["10.1016/j.jct.2019.04.023",5,"Viscosity, Pa*s","standard","Falling or rolling sphere viscometry","Direct value, X",7]
["10.1021/acs.jced.5b00152",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",45]
["10.1021/acs.jced.5b00152",4,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",38]
["10.1021/acs.jced.5b00152",6,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",20]
["10.1021/acs.jced.5b00152",8,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",20]
["10.1021/acs.jced.5b00152",10,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",27]
["10.1021/acs.jced.5b00152",12,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",35]
["10.1021/acs.jced.5b00162",2,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1021/acs.jced.5b00162",5,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1021/acs.jced.5b00162",8,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1021/acs.jced.5b00162",11,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1021/acs.jced.5b00162",14,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1021/acs.jced.5b00162",17,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1021/acs.jced.5b00162",20,"Viscosity, Pa*s","standard","Capillary tube (Ostwald; Ubbelohde) method","Direct value, X",1]
["10.1021/acs.jced.5b00259",2,"Viscosity, Pa*s","custom","SPHERE:UFactor:4","Direct value, X",7]
["10.1021/acs.jced.5b00259",4,"Viscosity, Pa*s","custom","SPHERE:UFactor:4","Direct value, X",7]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted Result: Pure Ethanol Viscosity Measurements

**200 rows returned (query limit reached — result may be truncated).**
All entries report **"Viscosity, Pa·s"** with presentation **"Direct value, X"** in `PureOrMixtureData` blocks (single-component).

---

### Task 1 — DOIs with pure ethanol viscosity data

48 distinct DOIs appear in the result:

| DOI | # blocks |
|-----|----------|
| 10.1007/s10765-005-8089-2 | 2 |
| 10.1016/j.fluid.2005.05.012 | 7 |
| 10.1016/j.fluid.2005.07.010 | 3 |
| 10.1016/j.fluid.2006.01.008 | 5 |
| 10.1016/j.fluid.2006.01.030 | 4 |
| 10.1016/j.fluid.2006.02.023 | 10 |
| 10.1016/j.fluid.2007.03.021 | 1 |
| 10.1016/j.fluid.2007.08.006 | 3 |
| 10.1016/j.fluid.2010.07.005 | 1 |
| 10.1016/j.fluid.2015.04.022 | 2 |
| 10.1016/j.fluid.2016.08.022 | 2 |
| 10.1016/j.fluid.2017.06.001 | 1 |
| 10.1016/j.jct.2005.04.019 | 8 |
| 10.1016/j.jct.2005.06.011 | 7 |
| 10.1016/j.jct.2005.07.008 | 4 |
| 10.1016/j.jct.2005.10.022 | 7 |
| 10.1016/j.jct.2005.12.010 | 7 |
| 10.1016/j.jct.2006.03.010 | 5 |
| 10.1016/j.jct.2006.03.018 | 7 |
| 10.1016/j.jct.2006.06.008 | 5 |
| 10.1016/j.jct.2006.10.016 | 5 |
| 10.1016/j.jct.2007.05.004 | 4 |
| 10.1016/j.jct.2008.03.013 | 3 |
| 10.1016/j.jct.2008.04.006 | 3 |
| 10.1016/j.jct.2009.06.023 | 4 |
| 10.1016/j.jct.2010.01.013 | 1 |
| 10.1016/j.jct.2010.03.022 | 1 |
| 10.1016/j.jct.2011.06.002 | 1 |
| 10.1016/j.jct.2011.08.028 | 1 |
| 10.1016/j.jct.2012.01.013 | 5 |
| 10.1016/j.jct.2012.02.027 | 5 |
| 10.1016/j.jct.2012.05.001 | 2 |
| 10.1016/j.jct.2012.08.024 | 2 |
| 10.1016/j.jct.2012.10.008 | 6 |
| 10.1016/j.jct.2013.08.021 | 1 |
| 10.1016/j.jct.2013.09.006 | 1 |
| 10.1016/j.jct.2013.09.044 | 4 |
| 10.1016/j.jct.2013.11.026 | 8 |
| 10.1016/j.jct.2014.01.030 | 1 |
| 10.1016/j.jct.2015.02.024 | 1 |
| 10.1016/j.jct.2015.04.027 | 5 |
| 10.1016/j.jct.2015.08.017 | 1 |
| 10.1016/j.jct.2015.08.036 | 1 |
| 10.1016/j.jct.2016.01.012 | 1 |
| 10.1016/j.jct.2016.06.028 | 1 |
| 10.1016/j.jct.2016.07.017 | 1 |
| 10.1016/j.jct.2016.08.008 | 1 |
| 10.1016/j.jct.2016.12.036 | 7 |
| *(+ 10.1016/j.jct.2017–2019 & 10.1021/acs.jced.5b… DOIs below)* | |

---

### Task 2 — Measurement methods

| method_type | method_name | # blocks in result |
|---|---|---|
| **standard** | Capillary tube (Ostwald; Ubbelohde) method | 62 |
| **standard** | Falling or rolling sphere viscometry | 56 |
| **standard** | Concentric cylinders viscometry | 6 |
| **standard** | Oscillating disk viscometry | 1 |
| **custom** | CAPTUB:UFactor:2 | 9 |
| **custom** | CAPTUB::UFactor:2 | 12 |
| **custom** | CAPTUB:UFactor:4 | 8 |
| **custom** | CAPTUB::UFactor:4 | 3 |
| **custom** | CAPTUB:UFactor:6 / ::UFactor:6 | 5 |
| **custom** | CAPTUB:UFactor:8 / ::UFactor:8 | 13 |
| **custom** | CAPTUB::UFactor:16 / :UFactor:16 | 10 |
| **custom** | Schott-Gerate viscometer model AVS 350 | 7 |
| **custom** | SPHERE:UFactor:4 | 2 |
| **custom** | unknown | 1 |

---

### Task 3 — Datapoints per block

Datapoints per block range from **1 to 45**. Representative spread:

| n_datapoints | Frequency (blocks) |
|---|---|
| 1 | 48 |
| 2 | 5 |
| 3 | 52 |
| 4 | 15 |
| 5 | 25 |
| 7 | 13 |
| 8 | 4 |
| 9 | 1 |
| 10 | 3 |
| 11 | 5 |
| 13 | 1 |
| 20 | 4 |
| 23 | 3 |
| 27 | 1 |
| 35 | 1 |
| 38 | 1 |
| 45 | 1 |

**Note:** The query hit the 200-row LIMIT; additional blocks/DOIs may exist beyond those shown (e.g., the last two rows are from `10.1021/acs.jced.5b00259`). Actual viscosity *values* are not in this query — they reside in the JSON `NumValues` within `raw.papers.json_data`.
```

### Integrity and timing

- Raw SHA-256: 067bec0ecc200fe4c5b01576fad28ea29956d40088d80a38d8ef7660e8f9de37
- Raw characters: 24158
- Hardcoded-compacted characters: 0
- Model-visible characters: 3519
- Agentic verdict: COMPACTED
- Tool elapsed: 0.043s
- Compactor elapsed: 29.089s
- Total elapsed: 29.134s

## Step 4: execute_sql

### Call arguments

```json
{
  "query": "WITH ethanol_visc_blocks AS (\n  SELECT bp.doi, bp.block_number, bp.method_name, bp.method_type\n  FROM raw.block_properties bp\n  JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\n  WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')\n    AND bp.prop_name LIKE '%iscosit%'\n    AND b.n_components = 1\n    AND bp.block_type = 'PureOrMixtureData'\n  GROUP BY bp.doi, bp.block_number, bp.method_name, bp.method_type\n)\nSELECT evb.doi, evb.block_number, evb.method_type, evb.method_name,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (evb.block_number - 1) || '].NumValues') as num_values\nFROM ethanol_visc_blocks evb\nJOIN raw.papers p ON p.doi = evb.doi\nWHERE evb.method_name IN ('Capillary tube (Ostwald; Ubbelohde) method', 'Falling or rolling sphere viscometry', 'Concentric cylinders viscometry', 'Oscillating disk viscometry')\nLIMIT 10",
  "purpose": "Extract actual viscosity numerical values near 25°C for pure ethanol from the JSON data, for standard methods",
  "tasks": [
    "Get viscosity values near 25°C for each measurement method",
    "Compare values across different methods",
    "Identify temperature and viscosity value pairs"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Extract actual viscosity numerical values near 25°C for pure ethanol from the JSON data, for standard methods

## SQL tasks

```json
["Get viscosity values near 25°C for each measurement method","Compare values across different methods","Identify temperature and viscosity value pairs"]
```

## Executed SQL (visible form)

```sql
WITH ethanol_visc_blocks AS (
  SELECT bp.doi, bp.block_number, bp.method_name, bp.method_type
  FROM raw.block_properties bp
  JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
  WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
    AND bp.prop_name LIKE '%iscosit%'
    AND b.n_components = 1
    AND bp.block_type = 'PureOrMixtureData'
  GROUP BY bp.doi, bp.block_number, bp.method_name, bp.method_type
)
SELECT evb.doi, evb.block_number, evb.method_type, evb.method_name,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (evb.block_number - 1) || '].NumValues') as num_values
FROM ethanol_visc_blocks evb
JOIN raw.papers p ON p.doi = evb.doi
WHERE evb.method_name IN ('Capillary tube (Ostwald; Ubbelohde) method', 'Falling or rolling sphere viscometry', 'Concentric cylinders viscometry', 'Oscillating disk viscometry')
LIMIT 10
```

## Result metadata

- Rows serialized: 10
- Truncated by max_rows: No.
- Elapsed seconds: 0.072371

## Columns

```json
["doi","block_number","method_type","method_name","num_values"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1007/s10765-005-8089-2",1,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":293.15},{\"nVarValue\":100,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.6e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.001194}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":20000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"PropertyValue\":[{\"nPropValue\":0.001344,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.9e-05,\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001494,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":40000}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":60000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001647}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.9e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001797}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":80000}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.001955}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":293.15},{\"nVarValue\":100000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2,\"nVarValue\":100}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000826,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.8e-05,\"nCombUncertAssessNum\":1}}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":20000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000948,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":40000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.3e-05},\"nPropValue\":0.001059,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":313.15},{\"nVarValue\":60000,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"PropertyValue\":[{\"nPropValue\":0.001171,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.5e-05},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.8e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001282}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":80000}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":100000}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3e-05},\"nPropValue\":0.001392}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":333.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":100,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"nPropValue\":0.00059,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000683,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":20000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.7e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000769}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":333.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2,\"nVarValue\":40000}]},{\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2,\"nVarValue\":60000}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.8e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000851}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":80000}],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000934,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"nPropValue\":0.001015,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.2e-05},\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":333.15},{\"nVarValue\":100000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.00051,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":353.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":20000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000574,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":353.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":40000}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":353.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":60000}],\"PropertyValue\":[{\"nPropValue\":0.000636,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.000699,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.5e-05}}],\"VariableValue\":[{\"nVarValue\":353.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":80000}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":353.15},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":100000}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000763}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1007/s10765-005-8089-2",2,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000583}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":100}]},{\"PropertyValue\":[{\"nPropValue\":0.000646,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.4e-05},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":20000}]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":40000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000706,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000767}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarValue\":60000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]},{\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarValue\":80000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.7e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.00083,\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.000894,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.9e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarValue\":100000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15},{\"nVarValue\":100,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000445}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":20000}],\"PropertyValue\":[{\"nPropValue\":0.000497,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.1e-05},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000546,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.2e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":313.15},{\"nVarValue\":40000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000593,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.3e-05},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarValue\":313.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarValue\":60000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.00064,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15},{\"nVarValue\":80000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"PropertyValue\":[{\"nPropValue\":0.000683,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.4e-05,\"nCombUncertAssessNum\":1},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":100000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarValue\":333.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":100,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000343,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06,\"nCombUncertAssessNum\":1}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000386,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8e-06,\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":333.15},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":20000}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000424,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":40000}]},{\"PropertyValue\":[{\"nPropValue\":0.000462,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":60000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":80000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000501,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.1e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":333.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":100000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000543}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":353.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":20000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000303,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}]},{\"VariableValue\":[{\"nVarValue\":353.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":40000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"PropertyValue\":[{\"nPropValue\":0.000337,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06,\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":353.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":60000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":8e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000368,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":353.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":80000}],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0004}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000433}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":353.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":100000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]}]"]
["10.1016/j.fluid.2006.01.008",3,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15},{\"nVarValue\":101.325,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.3599,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0123,\"nCombUncertAssessNum\":1}}]}]"]
["10.1016/j.fluid.2006.01.008",7,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarValue\":101.325,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6}],\"PropertyValue\":[{\"nPropValue\":0.000541,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.fluid.2006.01.008",11,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.001077,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6,\"nVarValue\":101.325}]}]"]
["10.1016/j.fluid.2006.01.008",15,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":101.325,\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.001928,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.2e-05,\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]}]"]
["10.1016/j.fluid.2006.01.008",19,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.002054,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.3e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarValue\":101.325,\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]}]"]
["10.1016/j.fluid.2006.01.030",1,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2,\"nVarValue\":20000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.001344,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":5.8e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":40000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.001494,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":6.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"PropertyValue\":[{\"nPropValue\":0.001647,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.1e-05,\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":293.15},{\"nVarValue\":60000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":80000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"nPropValue\":0.001797,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.7e-05,\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":100000,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8.4e-05},\"nPropValue\":0.001955,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000948,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.2e-05}}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":20000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15},{\"nVarValue\":40000,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.001059,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4.7e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":60000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001171,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":5.2e-05}}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":80000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":5.6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001282}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.1e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.001392}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":100000,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000683,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":333.15},{\"nVarValue\":20000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":40000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000769}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":333.15},{\"nVarValue\":60000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.7e-05},\"nPropValue\":0.000851}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":4.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000934,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":80000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.4e-05},\"nPropValue\":0.001015}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":333.15},{\"nVarValue\":100000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":353.15},{\"nVarValue\":20000,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.2e-05},\"nPropValue\":0.00051,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}]},{\"VariableValue\":[{\"nVarValue\":353.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":40000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000574,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.8e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000636,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":353.15},{\"nVarValue\":60000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]},{\"VariableValue\":[{\"nVarValue\":353.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":80000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"PropertyValue\":[{\"nPropValue\":0.000699,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.1e-05,\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000763,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":353.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2,\"nVarValue\":100000}]}]"]
["10.1016/j.fluid.2006.01.030",2,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":293.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001194,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.7e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000826,\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.00059,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.3e-05,\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":333.15}]}]"]
["10.1016/j.fluid.2006.01.030",3,"standard","Falling or rolling sphere viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000509,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":293.15},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":20000}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000604,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":293.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2,\"nVarValue\":40000}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000706,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":293.15},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":60000}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000817,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.4e-05}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarValue\":80000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":100000,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000937,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.9e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":20000}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.7e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000408,\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000487,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15},{\"nVarValue\":40000,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":60000}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.4e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.00057,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000658,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.8e-05},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":313.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":2,\"nVarValue\":80000}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000751,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":100000}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.4e-05},\"nPropValue\":0.000336}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":20000}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000402,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.7e-05,\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":333.15},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarValue\":40000}]},{\"VariableValue\":[{\"nVarValue\":333.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":60000}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000472,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":333.15},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":80000}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.3e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000546,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000623}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":100000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000289,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.2e-05},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":353.15},{\"nVarValue\":20000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":353.15},{\"nVarValue\":40000,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.4e-05},\"nPropValue\":0.000346,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.7e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000401,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":353.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":60000}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.9e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000458,\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":353.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":80000}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":353.15},{\"nVarValue\":100000,\"nVarNumber\":2,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000521,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted Result: Ethanol Viscosity by Method

### Overview
- **10 rows returned** (query LIMIT 10), **not truncated** beyond that limit.
- All data are for **pure ethanol** (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`), measured by **standard** method types.
- Two variables per data point: **Var 1 = Temperature (K)**, **Var 2 = Pressure (kPa)** (where present).
- Property value = **viscosity (Pa·s)** with combined expanded uncertainty.

### Important note on "near 25 °C"
**No data points at 298.15 K (25 °C) were found for the two high-pressure studies.** The closest temperatures in those datasets are 293.15 K (20 °C) and 313.15 K (40 °C). The DOI `10.1016/j.fluid.2006.01.008` does have data at **298.15 K** (see below).

---

### Source 1: `10.1007/s10765-005-8089-2`

#### Block 1 — Falling or rolling sphere viscometry
Data at multiple pressures; nearest to 25 °C is **293.15 K** (atmospheric ≈ 100 kPa):

| T (K) | P (kPa) | Viscosity (Pa·s) | Uncertainty |
|--------|---------|-------------------|-------------|
| 293.15 | 100 | 0.001194 | ±2.6×10⁻⁵ |
| 293.15 | 20000 | 0.001344 | ±2.9×10⁻⁵ |
| 293.15 | 40000 | 0.001494 | ±3.2×10⁻⁵ |
| 293.15 | 60000 | 0.001647 | ±3.5×10⁻⁵ |
| 293.15 | 80000 | 0.001797 | ±3.9×10⁻⁵ |
| 293.15 | 100000 | 0.001955 | ±4.2×10⁻⁵ |

*(Higher-T data at 313.15, 333.15, 353.15 K also present but omitted — not near 25 °C.)*

#### Block 2 — Capillary tube (Ostwald/Ubbelohde) method
Same temperatures/pressures. At **293.15 K**:

| T (K) | P (kPa) | Viscosity (Pa·s) | Uncertainty |
|--------|---------|-------------------|-------------|
| 293.15 | 100 | 0.000583 | ±1.2×10⁻⁵ |
| 293.15 | 20000 | 0.000646 | ±1.4×10⁻⁵ |
| 293.15 | 40000 | 0.000706 | ±1.5×10⁻⁵ |
| 293.15 | 60000 | 0.000767 | ±1.6×10⁻⁵ |
| 293.15 | 80000 | 0.000830 | ±1.7×10⁻⁵ |
| 293.15 | 100000 | 0.000894 | ±1.9×10⁻⁵ |

> **Note:** The two methods in this paper measure **different properties** (likely dynamic viscosity vs. kinematic viscosity), explaining the ~2× difference at the same conditions.

---

### Source 2: `10.1016/j.fluid.2006.01.008` — Capillary tube (Ostwald/Ubbelohde)

Multiple blocks, all at **298.15 K, 101.325 kPa** (exactly 25 °C, atmospheric):

| Block | Viscosity (Pa·s) | Uncertainty | Notes |
|-------|-------------------|-------------|-------|
| 3 | 0.3599 | ±0.0123 | Likely a different property/unit context (mixture block?) |
| 7 | 0.000541 | ±3.0×10⁻⁵ | |
| 11 | 0.001077 | ±3.1×10⁻⁵ | |
| 15 | 0.001928 | ±3.2×10⁻⁵ | |
| 19 | 0.002054 | ±1.3×10⁻⁵ | |

*(Blocks 7–19 likely correspond to different ethanol-containing mixtures at varying compositions despite the pure-component filter.)*

---

### Source 3: `10.1016/j.fluid.2006.01.030`

#### Block 2 — Capillary tube (Ostwald/Ubbelohde), atmospheric pressure (single-variable: T only)
| T (K) | Viscosity (Pa·s) | Uncertainty |
|--------|-------------------|-------------|
| 293.15 | 0.001194 | ±2.5×10⁻⁵ |
| 313.15 | 0.000826 | ±1.7×10⁻⁵ |

#### Block 1 & 3 — Falling or rolling sphere viscometry (high pressure)
At **293.15 K** (nearest 25 °C), Block 1 values identical to Source 1 Block 1. Block 3 values at 293.15 K:

| P (kPa) | Viscosity (Pa·s) | Uncertainty |
|---------|-------------------|-------------|
| 20000 | 0.000509 | ±2.1×10⁻⁵ |
| 40000 | 0.000604 | ±2.5×10⁻⁵ |
| 60000 | 0.000706 | ±3.0×10⁻⁵ |
| 80000 | 0.000817 | ±3.4×10⁻⁵ |
| 100000 | 0.000937 | ±3.9×10⁻⁵ |

---

### Cross-Method Comparison at ~293.15 K, atmospheric pressure

| Method | DOI | Viscosity (Pa·s) |
|--------|-----|-------------------|
| Falling/rolling sphere | 10.1007/s10765-005-8089-2 | 0.001194 |
| Capillary (Ubbelohde) | 10.1007/s10765-005-8089-2 | 0.000583 |
| Capillary (Ubbelohde) | 10.1016/j.fluid.2006.01.030 | 0.001194 |

The capillary value of **0.001194 Pa·s** (from the second source) matches the falling-sphere value, consistent with the accepted dynamic viscosity of ethanol near 20 °C (~1.2 mPa·s). The lower capillary value (0.000583) from the first source likely represents **kinematic viscosity** (m²/s) rather than dynamic viscosity.
```

### Integrity and timing

- Raw SHA-256: 4e5120aa7f69696f13638fdc056bc888884af729cd8954bbd28da0cdd86d56dc
- Raw characters: 62995
- Hardcoded-compacted characters: 0
- Model-visible characters: 4036
- Agentic verdict: COMPACTED
- Tool elapsed: 0.072s
- Compactor elapsed: 33.335s
- Total elapsed: 33.409s

## Step 5: execute_sql

### Call arguments

```json
{
  "query": "WITH ethanol_visc_blocks AS (\n  SELECT DISTINCT bp.doi, bp.block_number, bp.method_name, bp.method_type, bp.prop_name\n  FROM raw.block_properties bp\n  JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\n  WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')\n    AND bp.prop_name LIKE '%iscosit%'\n    AND b.n_components = 1\n    AND bp.block_type = 'PureOrMixtureData'\n    AND b.n_datapoints <= 15\n)\nSELECT evb.doi, evb.block_number, evb.method_type, evb.method_name, evb.prop_name,\n  json_extract(p.json_data, '$.PureOrMixtureData') as pom_data\nFROM ethanol_visc_blocks evb\nJOIN raw.papers p ON p.doi = evb.doi\nWHERE evb.doi IN (\n  '10.1016/j.jct.2005.04.019',\n  '10.1016/j.jct.2006.03.010',\n  '10.1016/j.jct.2008.03.013',\n  '10.1016/j.jct.2010.01.013',\n  '10.1016/j.jct.2011.06.002',\n  '10.1016/j.jct.2013.08.021',\n  '10.1016/j.jct.2014.01.030',\n  '10.1016/j.jct.2015.02.024',\n  '10.1016/j.jct.2016.01.012',\n  '10.1016/j.fluid.2007.03.021',\n  '10.1016/j.fluid.2010.07.005',\n  '10.1016/j.fluid.2017.06.001'\n)\nLIMIT 15",
  "purpose": "Extract full PureOrMixtureData JSON for selected papers with small numbers of datapoints to find viscosity values at or near 298.15 K",
  "tasks": [
    "Find viscosity values at exactly 298.15 K or within 1 K of it",
    "Identify the measurement method for each value",
    "Compare viscosity values across methods and papers"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool error

**Error:** Serialized SQL result exceeded max_result_chars=300,000 while streaming row 2. Run narrower SQL: select fewer columns, add filters, aggregate, or lower max_rows. No partial row payload was returned and no semantic compaction was performed.

## SQL purpose

Extract full PureOrMixtureData JSON for selected papers with small numbers of datapoints to find viscosity values at or near 298.15 K

## SQL tasks

```json
["Find viscosity values at exactly 298.15 K or within 1 K of it","Identify the measurement method for each value","Compare viscosity values across methods and papers"]
```

## Submitted SQL (visible form)

```sql
WITH ethanol_visc_blocks AS (
  SELECT DISTINCT bp.doi, bp.block_number, bp.method_name, bp.method_type, bp.prop_name
  FROM raw.block_properties bp
  JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
  WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
    AND bp.prop_name LIKE '%iscosit%'
    AND b.n_components = 1
    AND bp.block_type = 'PureOrMixtureData'
    AND b.n_datapoints <= 15
)
SELECT evb.doi, evb.block_number, evb.method_type, evb.method_name, evb.prop_name,
  json_extract(p.json_data, '$.PureOrMixtureData') as pom_data
FROM ethanol_visc_blocks evb
JOIN raw.papers p ON p.doi = evb.doi
WHERE evb.doi IN (
  '10.1016/j.jct.2005.04.019',
  '10.1016/j.jct.2006.03.010',
  '10.1016/j.jct.2008.03.013',
  '10.1016/j.jct.2010.01.013',
  '10.1016/j.jct.2011.06.002',
  '10.1016/j.jct.2013.08.021',
  '10.1016/j.jct.2014.01.030',
  '10.1016/j.jct.2015.02.024',
  '10.1016/j.jct.2016.01.012',
  '10.1016/j.fluid.2007.03.021',
  '10.1016/j.fluid.2010.07.005',
  '10.1016/j.fluid.2017.06.001'
)
LIMIT 15
```

No row payload was returned and no semantic compaction was performed.

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
# Compacted Result

## Status: SQL Error — Result Too Large

The query failed because the `pom_data` column (full `PureOrMixtureData` JSON blobs) exceeded the 300,000-character serialization limit after only 2 rows. **No row data was returned.**

## What happened
- The query selected the entire `$.PureOrMixtureData` JSON array for each paper, which is extremely large.
- The result was truncated before any rows could be delivered.

## Implications for the SQL tasks

| Task | Status |
|------|--------|
| 1. Find viscosity values at/near 298.15 K | ❌ No data returned |
| 2. Identify measurement method per value | ❌ No data returned |
| 3. Compare viscosity values across methods/papers | ❌ No data returned |

## Recommended fix

The answering agent should re-query with **narrower JSON extraction** rather than pulling the entire `PureOrMixtureData` blob. For example:

- Use `json_each()` to iterate over individual datapoints within the JSON.
- Filter for temperature values within 1 K of 298.15 K inside the SQL.
- Extract only the viscosity numeric value, temperature, and method columns — not the full JSON.
- The `method_name` and `method_type` are already available in `raw.block_properties` (no need to pull them from JSON).

The block-level method metadata can already be obtained without the JSON blob from the `ethanol_visc_blocks` CTE (columns: `doi`, `block_number`, `method_type`, `method_name`, `prop_name`), but the actual numeric viscosity values require drilling into the JSON datapoints with size-conscious extraction.
```

### Integrity and timing

- Raw SHA-256: 647b1b7a14943d7035c3083a89772b5ceac37fdda3c7ee29b71c9425b69e2525
- Raw characters: 1870
- Hardcoded-compacted characters: 0
- Model-visible characters: 1543
- Agentic verdict: ERROR
- Tool elapsed: 0.047s
- Compactor elapsed: 11.155s
- Total elapsed: 11.203s

## Step 6: execute_sql

### Call arguments

```json
{
  "query": "SELECT \n  bp.doi, bp.block_number, bp.method_type, bp.method_name,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')\n  AND bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\n  AND b.n_datapoints = 1\n  AND bp.method_name IN ('Capillary tube (Ostwald; Ubbelohde) method', 'Falling or rolling sphere viscometry', 'Concentric cylinders viscometry', 'Oscillating disk viscometry')\nGROUP BY bp.doi, bp.block_number\nLIMIT 30",
  "purpose": "Extract NumValues JSON for blocks with exactly 1 datapoint (small JSON) to get viscosity values at specific temperatures",
  "tasks": [
    "Find viscosity values at or near 298.15 K (25°C)",
    "Identify the measurement method for each value",
    "Compare viscosity values across methods"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Extract NumValues JSON for blocks with exactly 1 datapoint (small JSON) to get viscosity values at specific temperatures

## SQL tasks

```json
["Find viscosity values at or near 298.15 K (25°C)","Identify the measurement method for each value","Compare viscosity values across methods"]
```

## Executed SQL (visible form)

```sql
SELECT 
  bp.doi, bp.block_number, bp.method_type, bp.method_name,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.papers p ON p.doi = bp.doi
WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
  AND bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
  AND b.n_datapoints = 1
  AND bp.method_name IN ('Capillary tube (Ostwald; Ubbelohde) method', 'Falling or rolling sphere viscometry', 'Concentric cylinders viscometry', 'Oscillating disk viscometry')
GROUP BY bp.doi, bp.block_number
LIMIT 30
```

## Result metadata

- Rows serialized: 30
- Truncated by max_rows: No.
- Elapsed seconds: 0.845932

## Columns

```json
["doi","block_number","method_type","method_name","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.fluid.2006.01.008",3,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15},{\"nVarValue\":101.325,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.3599,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0123,\"nCombUncertAssessNum\":1}}]}]"]
["10.1016/j.fluid.2006.01.008",7,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarValue\":101.325,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6}],\"PropertyValue\":[{\"nPropValue\":0.000541,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.fluid.2006.01.008",11,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.001077,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6,\"nVarValue\":101.325}]}]"]
["10.1016/j.fluid.2006.01.008",15,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":101.325,\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.001928,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.2e-05,\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]}]"]
["10.1016/j.fluid.2006.01.008",19,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.002054,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.3e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarValue\":101.325,\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]}]"]
["10.1016/j.fluid.2007.03.021",3,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15},{\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":101.325}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001082,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-06}}]}]"]
["10.1016/j.fluid.2015.04.022",2,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarNumber\":1,\"nVarValue\":298.2},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6,\"nVarValue\":101.325}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.00012,\"nCombUncertAssessNum\":1},\"nPropValue\":0.00092,\"nPropDigits\":2,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.fluid.2015.04.022",4,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":298.2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarNumber\":1},{\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":101.325}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":0.00013,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.00457,\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]}]"]
["10.1016/j.jct.2005.04.019",1,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000683,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06,\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarValue\":101.325,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6,\"nVarNumber\":2}]}]"]
["10.1016/j.jct.2005.04.019",4,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1},{\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":101.325}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001093,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]}]"]
["10.1016/j.jct.2005.04.019",7,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.002098,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.6e-05,\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":101.325,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6}]}]"]
["10.1016/j.jct.2005.04.019",10,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6,\"nVarValue\":101.325}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":3.9e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.003421,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]}]"]
["10.1016/j.jct.2005.04.019",13,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":101.325}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.004204,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.8e-05}}]}]"]
["10.1016/j.jct.2005.04.019",15,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":101.325,\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.9e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.005346}]}]"]
["10.1016/j.jct.2005.04.019",17,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarValue\":101.325,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.000104,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.006568,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}]}]"]
["10.1016/j.jct.2005.04.019",19,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":101.325,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.002907,\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.jct.2012.02.027",8,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.00089,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":2,\"nPropNumber\":1}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":298.15},{\"nVarValue\":101.325,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":6}]}]"]
["10.1016/j.jct.2012.02.027",11,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":5.2e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.001087}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":298.15},{\"nVarNumber\":2,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":101.325}]}]"]
["10.1016/j.jct.2012.02.027",14,"standard","Capillary tube (Ostwald; Ubbelohde) method","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.00513,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.10142}],\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":101.325,\"nVarDigits\":6,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}]}]"]
["10.1016/j.jct.2013.09.044",2,"standard","Falling or rolling sphere viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":8.66e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0008599,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":100,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1},{\"nVarValue\":298.2,\"nVarNumber\":2,\"nVarDigits\":4,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]}]"]
["10.1016/j.jct.2013.09.044",4,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":100,\"nVarNumber\":1,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":298.2,\"nVarDigits\":4,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0001591,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0015849,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.jct.2013.09.044",6,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":100,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarNumber\":2,\"nVarValue\":298.2}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0001196},\"nPropValue\":0.0011866,\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.jct.2013.09.044",8,"standard","Falling or rolling sphere viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-05},\"nPropValue\":0.0008976}],\"VariableValue\":[{\"nVarValue\":100,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":1},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarValue\":298.2}]}]"]
["10.1016/j.jct.2013.11.026",3,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarValue\":101.8},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":2,\"nVarValue\":298.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.24e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0008599,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.jct.2013.11.026",5,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":101.8,\"nVarNumber\":1,\"nVarDigits\":4,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarNumber\":2,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9.25e-05},\"nPropValue\":0.0043493,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}]}]"]
["10.1016/j.jct.2013.11.026",7,"standard","Falling or rolling sphere viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.87e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0022912}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarNumber\":1,\"nVarValue\":101.8},{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":298.15}]}]"]
["10.1016/j.jct.2013.11.026",9,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":101.8,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4},{\"nVarValue\":298.15,\"nVarNumber\":2,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.08e-05},\"nPropValue\":0.0011443,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.jct.2013.11.026",11,"standard","Falling or rolling sphere viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0016162,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.43e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":101.8,\"nVarDigits\":4,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarNumber\":2,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}]}]"]
["10.1016/j.jct.2013.11.026",13,"standard","Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":101.8,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarNumber\":1},{\"nVarValue\":298.15,\"nVarNumber\":2,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4.3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0020186,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}]}]"]
["10.1016/j.jct.2013.11.026",15,"standard","Falling or rolling sphere viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":5.22e-05},\"nPropValue\":0.0024562,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":101.8,\"nVarNumber\":1,\"nVarDigits\":4,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":298.15,\"nVarNumber\":2,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted Result: Ethanol Viscosity near 25 °C by Method

**30 rows returned (not truncated).** All measurements are at ~298.15 K (or 298.2 K) and ~101 kPa. Values are from pure-component (n_components=1) blocks with exactly 1 datapoint each.

**Important note:** Many of these blocks come from papers studying ethanol *mixtures* — each block represents a single composition point. The blocks with very different viscosity values (e.g., 0.3599, 0.10142, 0.006568 Pa·s) likely correspond to mixture compositions, not pure ethanol. The pure ethanol dynamic viscosity near 25 °C is expected to be ~0.001 Pa·s. Blocks reporting values near that range are the most relevant.

### Values near expected pure ethanol viscosity (~0.001 Pa·s)

| DOI | Block | Method | Viscosity (Pa·s) | Uncertainty |
|-----|-------|--------|------------------|-------------|
| 10.1016/j.fluid.2006.01.008 | 7 | Capillary (Ubbelohde) | 0.000541 | ±0.00003 |
| 10.1016/j.fluid.2006.01.008 | 11 | Capillary (Ubbelohde) | 0.001077 | ±0.000031 |
| 10.1016/j.fluid.2007.03.021 | 3 | Capillary (Ubbelohde) | 0.001082 | ±0.000009 |
| 10.1016/j.jct.2005.04.019 | 1 | Capillary (Ubbelohde) | 0.000683 | ±0.000007 |
| 10.1016/j.jct.2005.04.019 | 4 | Capillary (Ubbelohde) | 0.001093 | ±0.000009 |
| 10.1016/j.jct.2012.02.027 | 8 | Capillary (Ubbelohde) | 0.00089 | ±0.00004 |
| 10.1016/j.jct.2012.02.027 | 11 | Capillary (Ubbelohde) | 0.001087 | ±0.000052 |
| 10.1016/j.fluid.2015.04.022 | 2 | Falling/rolling sphere | 0.00092 | ±0.00012 |
| 10.1016/j.jct.2013.09.044 | 2 | Falling/rolling sphere | 0.0008599 | ±0.0000866 |
| 10.1016/j.jct.2013.09.044 | 8 | Falling/rolling sphere | 0.0008976 | ±0.00009 |
| 10.1016/j.jct.2013.11.026 | 3 | Falling/rolling sphere | 0.0008599 | ±0.0000224 |
| 10.1016/j.jct.2013.11.026 | 9 | Falling/rolling sphere | 0.0011443 | ±0.0000308 |

### Other values (likely mixture-composition blocks, included for completeness)

| DOI | Block | Method | Viscosity (Pa·s) | Uncertainty |
|-----|-------|--------|------------------|-------------|
| 10.1016/j.fluid.2006.01.008 | 3 | Capillary (Ubbelohde) | 0.3599 | ±0.0123 |
| 10.1016/j.fluid.2006.01.008 | 15 | Capillary (Ubbelohde) | 0.001928 | ±0.000032 |
| 10.1016/j.fluid.2006.01.008 | 19 | Capillary (Ubbelohde) | 0.002054 | ±0.000013 |
| 10.1016/j.jct.2005.04.019 | 7 | Capillary (Ubbelohde) | 0.002098 | ±0.000016 |
| 10.1016/j.jct.2005.04.019 | 10 | Capillary (Ubbelohde) | 0.003421 | ±0.000039 |
| 10.1016/j.jct.2005.04.019 | 13 | Capillary (Ubbelohde) | 0.004204 | ±0.000048 |
| 10.1016/j.jct.2005.04.019 | 15 | Capillary (Ubbelohde) | 0.005346 | ±0.000039 |
| 10.1016/j.jct.2005.04.019 | 17 | Capillary (Ubbelohde) | 0.006568 | ±0.000104 |
| 10.1016/j.jct.2005.04.019 | 19 | Capillary (Ubbelohde) | 0.002907 | ±0.000022 |
| 10.1016/j.jct.2012.02.027 | 14 | Capillary (Ubbelohde) | 0.10142 | ±0.00513 |
| 10.1016/j.fluid.2015.04.022 | 4 | Falling/rolling sphere | 0.00457 | ±0.00013 |
| 10.1016/j.jct.2013.09.044 | 4 | Falling/rolling sphere | 0.0015849 | ±0.0001591 |
| 10.1016/j.jct.2013.09.044 | 6 | Falling/rolling sphere | 0.0011866 | ±0.0001196 |
| 10.1016/j.jct.2013.11.026 | 5 | Falling/rolling sphere | 0.0043493 | ±0.0000925 |
| 10.1016/j.jct.2013.11.026 | 7 | Falling/rolling sphere | 0.0022912 | ±0.0000487 |
| 10.1016/j.jct.2013.11.026 | 11 | Falling/rolling sphere | 0.0016162 | ±0.0000343 |
| 10.1016/j.jct.2013.11.026 | 13 | Falling/rolling sphere | 0.0020186 | ±0.000043 |
| 10.1016/j.jct.2013.11.026 | 15 | Falling/rolling sphere | 0.0024562 | ±0.0000522 |

### Method summary

- **Capillary tube (Ostwald; Ubbelohde)**: 4 DOIs, 19 blocks total
- **Falling or rolling sphere viscometry**: 3 DOIs, 11 blocks total
- No results for Concentric cylinders or Oscillating disk methods in this query
```

### Integrity and timing

- Raw SHA-256: 47fb42d41660dd18d29a936f077f2774e7aa4e855b378744a72f99c2d1dcaaf8
- Raw characters: 23640
- Hardcoded-compacted characters: 0
- Model-visible characters: 3764
- Agentic verdict: COMPACTED
- Tool elapsed: 0.846s
- Compactor elapsed: 27.659s
- Total elapsed: 28.506s

## Step 7: execute_sql

### Call arguments

```json
{
  "query": "SELECT \n  bp.doi, bp.block_number, bp.method_type, bp.method_name,\n  b.n_datapoints, b.component_org_nums\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nWHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')\n  AND bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\n  AND bp.method_name IN ('Concentric cylinders viscometry', 'Oscillating disk viscometry')\nGROUP BY bp.doi, bp.block_number\nLIMIT 20",
  "purpose": "Find blocks using concentric cylinders and oscillating disk methods for pure ethanol viscosity",
  "tasks": [
    "Identify DOIs and blocks using these less common methods",
    "Get datapoint counts to plan extraction"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Find blocks using concentric cylinders and oscillating disk methods for pure ethanol viscosity

## SQL tasks

```json
["Identify DOIs and blocks using these less common methods","Get datapoint counts to plan extraction"]
```

## Executed SQL (visible form)

```sql
SELECT 
  bp.doi, bp.block_number, bp.method_type, bp.method_name,
  b.n_datapoints, b.component_org_nums
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
  AND bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
  AND bp.method_name IN ('Concentric cylinders viscometry', 'Oscillating disk viscometry')
GROUP BY bp.doi, bp.block_number
LIMIT 20
```

## Result metadata

- Rows serialized: 10
- Truncated by max_rows: No.
- Elapsed seconds: 0.028118

## Columns

```json
["doi","block_number","method_type","method_name","n_datapoints","component_org_nums"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.jct.2015.08.017",2,"standard","Oscillating disk viscometry",4,"[1]"]
["10.1016/j.jct.2018.02.022",3,"standard","Concentric cylinders viscometry",4,"[1]"]
["10.1016/j.jct.2018.02.022",6,"standard","Concentric cylinders viscometry",4,"[2]"]
["10.1016/j.jct.2018.02.022",9,"standard","Concentric cylinders viscometry",4,"[3]"]
["10.1016/j.jct.2018.02.022",12,"standard","Concentric cylinders viscometry",4,"[4]"]
["10.1016/j.jct.2018.02.022",15,"standard","Concentric cylinders viscometry",4,"[5]"]
["10.1016/j.jct.2018.02.022",18,"standard","Concentric cylinders viscometry",4,"[6]"]
["10.1021/acs.jced.8b00793",2,"standard","Concentric cylinders viscometry",4,"[1]"]
["10.1021/je200600p",1,"standard","Concentric cylinders viscometry",9,"[2]"]
["10.1021/je200600p",3,"standard","Concentric cylinders viscometry",9,"[3]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Blocks Using Less Common Methods for Pure Ethanol Viscosity

**Result: 10 rows returned (not truncated)**

### Oscillating Disk Viscometry

| DOI | Block # | Datapoints | Component |
|-----|---------|------------|-----------|
| 10.1016/j.jct.2015.08.017 | 2 | 4 | [1] |

### Concentric Cylinders Viscometry

| DOI | Block # | Datapoints | Component |
|-----|---------|------------|-----------|
| 10.1016/j.jct.2018.02.022 | 3 | 4 | [1] |
| 10.1016/j.jct.2018.02.022 | 6 | 4 | [2] |
| 10.1016/j.jct.2018.02.022 | 9 | 4 | [3] |
| 10.1016/j.jct.2018.02.022 | 12 | 4 | [4] |
| 10.1016/j.jct.2018.02.022 | 15 | 4 | [5] |
| 10.1016/j.jct.2018.02.022 | 18 | 4 | [6] |
| 10.1021/acs.jced.8b00793 | 2 | 4 | [1] |
| 10.1021/je200600p | 1 | 9 | [2] |
| 10.1021/je200600p | 3 | 9 | [3] |

All methods are classified as `method_type = "standard"`.

### Summary for extraction planning

| DOI | Method | # Blocks | Datapoints/block |
|-----|--------|----------|------------------|
| 10.1016/j.jct.2015.08.017 | Oscillating disk | 1 | 4 |
| 10.1016/j.jct.2018.02.022 | Concentric cylinders | 6 | 4 each (24 total) |
| 10.1021/acs.jced.8b00793 | Concentric cylinders | 1 | 4 |
| 10.1021/je200600p | Concentric cylinders | 2 | 9 each (18 total) |

**Note:** The multiple blocks in `10.1016/j.jct.2018.02.022` have different `component_org_nums` ([1]–[6]), suggesting they may correspond to different compounds in a multi-compound paper; only the block(s) actually for ethanol should be extracted. Similarly, `10.1021/je200600p` blocks reference components [2] and [3].
```

### Integrity and timing

- Raw SHA-256: d2664f28136ea07bdac0f674e594b04e62e3dd4d51db69a727237cb0853e6002
- Raw characters: 2069
- Hardcoded-compacted characters: 0
- Model-visible characters: 1554
- Agentic verdict: COMPACTED
- Tool elapsed: 0.028s
- Compactor elapsed: 10.693s
- Total elapsed: 10.721s

## Step 8: execute_sql

### Call arguments

```json
{
  "query": "SELECT \n  bp.doi, bp.block_number, bp.method_name,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE (\n  (bp.doi = '10.1016/j.jct.2015.08.017' AND bp.block_number = 2)\n  OR (bp.doi = '10.1021/acs.jced.8b00793' AND bp.block_number = 2)\n  OR (bp.doi = '10.1021/je200600p' AND bp.block_number = 1)\n)\nAND bp.prop_name LIKE '%iscosit%'\nAND bp.block_type = 'PureOrMixtureData'\nGROUP BY bp.doi, bp.block_number",
  "purpose": "Extract viscosity values for oscillating disk and concentric cylinders methods",
  "tasks": [
    "Get viscosity values near 298.15 K for oscillating disk method",
    "Get viscosity values near 298.15 K for concentric cylinders method",
    "Compare these values with capillary and falling sphere results"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Extract viscosity values for oscillating disk and concentric cylinders methods

## SQL tasks

```json
["Get viscosity values near 298.15 K for oscillating disk method","Get viscosity values near 298.15 K for concentric cylinders method","Compare these values with capillary and falling sphere results"]
```

## Executed SQL (visible form)

```sql
SELECT 
  bp.doi, bp.block_number, bp.method_name,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.papers p ON p.doi = bp.doi
WHERE (
  (bp.doi = '10.1016/j.jct.2015.08.017' AND bp.block_number = 2)
  OR (bp.doi = '10.1021/acs.jced.8b00793' AND bp.block_number = 2)
  OR (bp.doi = '10.1021/je200600p' AND bp.block_number = 1)
)
AND bp.prop_name LIKE '%iscosit%'
AND bp.block_type = 'PureOrMixtureData'
GROUP BY bp.doi, bp.block_number
```

## Result metadata

- Rows serialized: 3
- Truncated by max_rows: No.
- Elapsed seconds: 0.034167

## Columns

```json
["doi","block_number","method_name","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.jct.2015.08.017",2,"Oscillating disk viscometry","[{\"VariableValue\":[{\"nVarValue\":283.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"PropertyValue\":[{\"nPropValue\":1.5788,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0575},\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0262},\"nPropValue\":0.7179,\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":303.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.3685,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":0.0134,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.2083,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0076}}]}]"]
["10.1021/acs.jced.8b00793",2,"Concentric cylinders viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.00123,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"VariableValue\":[{\"nVarValue\":293.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.00102}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":313.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":2,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.00085,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":2,\"nPropNumber\":1,\"nPropValue\":0.00071,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":323.15}]}]"]
["10.1021/je200600p",1,"Concentric cylinders viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":7.5e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0005676,\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0005318,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.3e-06},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0005008,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.1e-06},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarValue\":308.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0004729,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.0004482,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6.9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":318.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.8e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0004259,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":323.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":6.7e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0004055,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":328.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0003872,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.6e-06,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":333.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000371,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.5e-06}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Extracted Viscosity Data for Ethanol by Method

### 1. Oscillating Disk Viscometry
**DOI:** 10.1016/j.jct.2015.08.017 (block 2)

| T (K) | Viscosity | Expanded Uncertainty |
|--------|-----------|----------------------|
| 283.15 | 1.5788 | ± 0.0575 |
| 293.15 | 0.7179 | ± 0.0262 |
| **303.15** | **0.3685** | **± 0.0134** |
| 313.15 | 0.2083 | ± 0.0076 |

*No data point at exactly 298.15 K; nearest bracketing values are at 293.15 K and 303.15 K. Units appear to be mPa·s (values in the ~0.2–1.6 range).*

---

### 2. Concentric Cylinders Viscometry

#### Source A — DOI: 10.1021/acs.jced.8b00793 (block 2)

| T (K) | Viscosity | Expanded Uncertainty |
|--------|-----------|----------------------|
| 293.15 | 0.00123 | ± 5 × 10⁻⁵ |
| **303.15** | **0.00102** | **± 4 × 10⁻⁵** |
| 313.15 | 0.00085 | ± 4 × 10⁻⁵ |
| 323.15 | 0.00071 | ± 3 × 10⁻⁵ |

*No data point at exactly 298.15 K; nearest are 293.15 K and 303.15 K. Units appear to be Pa·s (values in the ~0.001 range).*

#### Source B — DOI: 10.1021/je200600p (block 1)

| T (K) | Viscosity | Expanded Uncertainty |
|--------|-----------|----------------------|
| 293.15 | 0.0005676 | ± 7.5 × 10⁻⁶ |
| **298.15** | **0.0005318** | **± 7.3 × 10⁻⁶** |
| 303.15 | 0.0005008 | ± 7.1 × 10⁻⁶ |
| 308.15 | 0.0004729 | ± 7.0 × 10⁻⁶ |
| 313.15 | 0.0004482 | ± 6.9 × 10⁻⁶ |
| 318.15 | 0.0004259 | ± 6.8 × 10⁻⁶ |
| 323.15 | 0.0004055 | ± 6.7 × 10⁻⁶ |
| 328.15 | 0.0003872 | ± 6.6 × 10⁻⁶ |
| 333.15 | 0.0003710 | ± 6.5 × 10⁻⁶ |

*This source has a measurement at exactly 298.15 K. Units appear to be Pa·s (values in the ~0.0004–0.0006 range).*

---

### 3. Comparison Notes (Task 3)

- **No capillary or falling-sphere viscometry data** were returned by this query. Comparison with those methods would require additional queries.
- The two concentric-cylinders sources report values differing by roughly a factor of 2 near 298 K (0.00123 vs 0.0005676 at 293.15 K), suggesting they may be measuring different substances/conditions or using different unit conventions — this warrants verification.
- The oscillating-disk values are numerically much larger (e.g., 0.7179 at 293.15 K), consistent with a different unit (mPa·s vs Pa·s).
```

### Integrity and timing

- Raw SHA-256: 9fd7f54218f49e1e81e54fca650ab557eed8150d4a8f6aa32697f1b8e8e0c46b
- Raw characters: 10478
- Hardcoded-compacted characters: 0
- Model-visible characters: 2178
- Agentic verdict: COMPACTED
- Tool elapsed: 0.034s
- Compactor elapsed: 20.485s
- Total elapsed: 20.519s

## Step 9: execute_sql

### Call arguments

```json
{
  "query": "-- Check what compound is in block 1 of 10.1021/je200600p\nSELECT c.doi, c.org_num, c.common_name, c.standard_inchi_key, c.cas_rn\nFROM raw.compounds c\nWHERE c.doi = '10.1021/je200600p'\nORDER BY c.org_num",
  "purpose": "Verify which compound corresponds to which org_num in this paper to confirm block 1 is ethanol",
  "tasks": [
    "Identify which org_num is ethanol in this paper",
    "Determine if block 1 (component [2]) is actually ethanol"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Verify which compound corresponds to which org_num in this paper to confirm block 1 is ethanol

## SQL tasks

```json
["Identify which org_num is ethanol in this paper","Determine if block 1 (component [2]) is actually ethanol"]
```

## Executed SQL (visible form)

```sql
-- Check what compound is in block 1 of 10.1021/je200600p
SELECT c.doi, c.org_num, c.common_name, c.standard_inchi_key, c.cas_rn
FROM raw.compounds c
WHERE c.doi = '10.1021/je200600p'
ORDER BY c.org_num
```

## Result metadata

- Rows serialized: 5
- Truncated by max_rows: No.
- Elapsed seconds: 0.002538

## Columns

```json
["doi","org_num","common_name","standard_inchi_key","cas_rn"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1021/je200600p",1,"water","XLYOFNOQVPJJNP-UHFFFAOYSA-N",null]
["10.1021/je200600p",2,"methanol","OKKJLVBELUTLKV-UHFFFAOYSA-N",null]
["10.1021/je200600p",3,"ethanol","LFQSCWFLJHTTHZ-UHFFFAOYSA-N",null]
["10.1021/je200600p",4,"1-ethyl-3-methylimidazolium dimethylphosphate","WTKUDOCGUOSPGV-UHFFFAOYSA-M",null]
["10.1021/je200600p",5,"1-butyl-3-methyl-1H-imidazolium dimethylphosphate","FSUAYRLKFSKOJG-UHFFFAOYSA-M",null]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compound–org_num Mapping for DOI 10.1021/je200600p

| org_num | common_name | standard_inchi_key |
|---------|-------------|--------------------|
| 1 | water | XLYOFNOQVPJJNP-UHFFFAOYSA-N |
| 2 | methanol | OKKJLVBELUTLKV-UHFFFAOYSA-N |
| 3 | **ethanol** | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |
| 4 | 1-ethyl-3-methylimidazolium dimethylphosphate | WTKUDOCGUOSPGV-UHFFFAOYSA-M |
| 5 | 1-butyl-3-methyl-1H-imidazolium dimethylphosphate | FSUAYRLKFSKOJG-UHFFFAOYSA-M |

### Key findings

1. **Ethanol is org_num 3**, not org_num 2. Org_num 2 is methanol.
2. **Block 1 with component [2] would be methanol, not ethanol.** If the goal is to find pure-ethanol data, the relevant blocks should reference component org_num **3**.
```

### Integrity and timing

- Raw SHA-256: 80527a2cca0f9c282bce19822c60739881fc5446e8751dc787a1e4ac92e863c3
- Raw characters: 1255
- Hardcoded-compacted characters: 0
- Model-visible characters: 717
- Agentic verdict: COMPACTED
- Tool elapsed: 0.003s
- Compactor elapsed: 5.812s
- Total elapsed: 5.814s

## Step 10: execute_sql

### Call arguments

```json
{
  "query": "-- Get the ethanol block from 10.1021/je200600p (block 3, component [3])\nSELECT \n  bp.doi, bp.block_number, bp.method_name,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE bp.doi = '10.1021/je200600p' AND bp.block_number = 3\n  AND bp.prop_name LIKE '%iscosit%'\n  AND bp.block_type = 'PureOrMixtureData'\nGROUP BY bp.doi, bp.block_number",
  "purpose": "Get the actual ethanol viscosity data from block 3 (component 3 = ethanol) of this paper",
  "tasks": [
    "Get viscosity values at 298.15 K for ethanol measured by concentric cylinders",
    "Correct the earlier misidentification"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Get the actual ethanol viscosity data from block 3 (component 3 = ethanol) of this paper

## SQL tasks

```json
["Get viscosity values at 298.15 K for ethanol measured by concentric cylinders","Correct the earlier misidentification"]
```

## Executed SQL (visible form)

```sql
-- Get the ethanol block from 10.1021/je200600p (block 3, component [3])
SELECT 
  bp.doi, bp.block_number, bp.method_name,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.papers p ON p.doi = bp.doi
WHERE bp.doi = '10.1021/je200600p' AND bp.block_number = 3
  AND bp.prop_name LIKE '%iscosit%'
  AND bp.block_type = 'PureOrMixtureData'
GROUP BY bp.doi, bp.block_number
```

## Result metadata

- Rows serialized: 1
- Truncated by max_rows: No.
- Elapsed seconds: 0.004650

## Columns

```json
["doi","block_number","method_name","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1021/je200600p",3,"Concentric cylinders viscometry","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.06e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0011407,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.01e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0010371}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":9.5e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0009462,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":303.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9.1e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0008653,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":308.15}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":313.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.0007933,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8.7e-06,\"nCombUncertAssessNum\":1}}]},{\"VariableValue\":[{\"nVarValue\":318.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":8.4e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0007298}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":323.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8.1e-06},\"nPropValue\":0.0006727}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0006219,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":7.8e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":328.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.6e-06},\"nPropValue\":0.0005762}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":333.15}]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted Result

**Source:** DOI `10.1021/je200600p`, Block 3 (pure ethanol), **Method: Concentric cylinders viscometry**

### Viscosity data (all temperatures)

| T / K   | η / Pa·s   | U(η) / Pa·s |
|---------|-----------|-------------|
| 293.15  | 0.0011407 | 1.06 × 10⁻⁵ |
| **298.15** | **0.0010371** | **1.01 × 10⁻⁵** |
| 303.15  | 0.0009462 | 9.5 × 10⁻⁶  |
| 308.15  | 0.0008653 | 9.1 × 10⁻⁶  |
| 313.15  | 0.0007933 | 8.7 × 10⁻⁶  |
| 318.15  | 0.0007298 | 8.4 × 10⁻⁶  |
| 323.15  | 0.0006727 | 8.1 × 10⁻⁶  |
| 328.15  | 0.0006219 | 7.8 × 10⁻⁶  |
| 333.15  | 0.0005762 | 7.6 × 10⁻⁶  |

**U(η)** = combined expanded uncertainty (assessment type 1).

### Task-specific notes

1. **Viscosity at 298.15 K:** η = **0.0010371 Pa·s** (≈ 1.0371 mPa·s) with expanded uncertainty 1.01 × 10⁻⁵ Pa·s, measured by **concentric cylinders viscometry**.
2. **Correction:** This block (block 3) corresponds to **ethanol** (component 3), confirming the correct compound identification. Nine data points from 293.15 K to 333.15 K were returned; no rows were omitted.
```

### Integrity and timing

- Raw SHA-256: 4f276396bf5be7e13adffb6606e1b8884c91871c88b6482fb6701d6f67c670a3
- Raw characters: 5907
- Hardcoded-compacted characters: 0
- Model-visible characters: 1057
- Agentic verdict: COMPACTED
- Tool elapsed: 0.005s
- Compactor elapsed: 11.562s
- Total elapsed: 11.567s

## Step 11: execute_sql

### Call arguments

```json
{
  "query": "-- Now get multi-datapoint blocks with capillary and falling sphere methods that include 298.15 K\n-- Pick a few DOIs with moderate datapoint counts\nSELECT \n  bp.doi, bp.block_number, bp.method_name, b.n_datapoints, b.component_org_nums,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')\n  AND bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\n  AND b.n_datapoints BETWEEN 3 AND 10\n  AND bp.method_name IN ('Capillary tube (Ostwald; Ubbelohde) method', 'Falling or rolling sphere viscometry')\n  AND b.component_org_nums LIKE '%'\nGROUP BY bp.doi, bp.block_number\nLIMIT 8",
  "purpose": "Get viscosity data from capillary and falling sphere methods with multiple temperature points to find values at 298.15 K",
  "tasks": [
    "Find capillary tube viscosity values at or near 298.15 K for pure ethanol",
    "Find falling sphere viscosity values at or near 298.15 K for pure ethanol",
    "Compare values across methods at the same temperature"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Get viscosity data from capillary and falling sphere methods with multiple temperature points to find values at 298.15 K

## SQL tasks

```json
["Find capillary tube viscosity values at or near 298.15 K for pure ethanol","Find falling sphere viscosity values at or near 298.15 K for pure ethanol","Compare values across methods at the same temperature"]
```

## Executed SQL (visible form)

```sql
-- Now get multi-datapoint blocks with capillary and falling sphere methods that include 298.15 K
-- Pick a few DOIs with moderate datapoint counts
SELECT 
  bp.doi, bp.block_number, bp.method_name, b.n_datapoints, b.component_org_nums,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.papers p ON p.doi = bp.doi
WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
  AND bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
  AND b.n_datapoints BETWEEN 3 AND 10
  AND bp.method_name IN ('Capillary tube (Ostwald; Ubbelohde) method', 'Falling or rolling sphere viscometry')
  AND b.component_org_nums LIKE '%'
GROUP BY bp.doi, bp.block_number
LIMIT 8
```

## Result metadata

- Rows serialized: 8
- Truncated by max_rows: No.
- Elapsed seconds: 2.845894

## Columns

```json
["doi","block_number","method_name","n_datapoints","component_org_nums","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.fluid.2006.01.030",2,"Capillary tube (Ostwald; Ubbelohde) method",3,"[1]","[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":293.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001194,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.7e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000826,\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.00059,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.3e-05,\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":333.15}]}]"]
["10.1016/j.fluid.2006.01.030",4,"Capillary tube (Ostwald; Ubbelohde) method",4,"[2]","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.00041}],\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06},\"nPropValue\":0.000333}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000276,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6e-06}}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":333.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000232,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":5e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"VariableValue\":[{\"nVarValue\":353.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]}]"]
["10.1016/j.fluid.2007.08.006",2,"Capillary tube (Ostwald; Ubbelohde) method",3,"[1]","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000695,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.8e-05}}],\"VariableValue\":[{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":303.15}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":308.15}],\"PropertyValue\":[{\"nPropValue\":0.000658,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.7e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000617,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.6e-05,\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1}]}]"]
["10.1016/j.fluid.2007.08.006",5,"Capillary tube (Ostwald; Ubbelohde) method",3,"[2]","[{\"VariableValue\":[{\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":303.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-06},\"nPropValue\":0.000352}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":308.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":2}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombExpandUncertValue\":9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000334}]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":1,\"nVarValue\":313.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.000315,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8e-06,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.fluid.2007.08.006",8,"Capillary tube (Ostwald; Ubbelohde) method",3,"[3]","[{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarDigits\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.8e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000715}]},{\"PropertyValue\":[{\"nPropValue\":0.000693,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.8e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":2,\"nVarNumber\":1,\"nVarValue\":308.15}]},{\"PropertyValue\":[{\"nPropValue\":0.000677,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.8e-05},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":1,\"nVarNumber\":1,\"nVarValue\":313.15}]}]"]
["10.1016/j.fluid.2010.07.005",2,"Capillary tube (Ostwald; Ubbelohde) method",6,"[2]","[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":0.008,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.27186,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.00446,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.1883}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":303.15}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":308.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.00258},\"nPropValue\":0.13949,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1,\"nPropValue\":0.11025,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.00161}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.00088,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.08444,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":318.15}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":323.15}],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.00059,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.06999}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1016/j.fluid.2016.08.022",6,"Capillary tube (Ostwald; Ubbelohde) method",3,"[2]","[{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15}],\"PropertyValue\":[{\"nPropValue\":0.0011608,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.38e-05},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9.8e-06},\"nPropValue\":0.0008137,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.2e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0005849}],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]}]"]
["10.1016/j.fluid.2017.06.001",4,"Capillary tube (Ostwald; Ubbelohde) method",7,"[1]","[{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.446,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.02,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":308.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.01},\"nPropValue\":0.254,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":318.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":0.005,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.154,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}]},{\"PropertyValue\":[{\"nPropValue\":0.0982,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":0.0028,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":328.15}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0659,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0018}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":338.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombExpandUncertValue\":0.0012,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0452}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":348.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarValue\":358.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0328,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":0.0009,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted Result: Ethanol Viscosity by Capillary & Falling Sphere Methods

**8 rows returned; 0 truncated. All methods are Capillary tube (Ostwald/Ubbelohde). No falling-sphere viscometry rows were returned.**

### Notes on units
- Values labeled `nPropValue` are viscosity; units depend on the property definition in each paper (Pa·s or mPa·s). Context from the property metadata (not queried here) is needed to confirm units.
- `nVarValue` = temperature in K.
- Uncertainties are combined expanded uncertainties.

---

### Extracted data points (temperature → viscosity ± uncertainty)

#### DOI: 10.1016/j.fluid.2006.01.030 — Block 2 (component [1])
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| 293.15 | 0.001194 | ±2.5 × 10⁻⁵ |
| 313.15 | 0.000826 | ±1.7 × 10⁻⁵ |
| 333.15 | 0.000590 | ±1.3 × 10⁻⁵ |

#### DOI: 10.1016/j.fluid.2006.01.030 — Block 4 (component [2])
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| 293.15 | 0.000410 | ±9 × 10⁻⁶ |
| 313.15 | 0.000333 | ±7 × 10⁻⁶ |
| 333.15 | 0.000276 | ±6 × 10⁻⁶ |
| 353.15 | 0.000232 | ±5 × 10⁻⁶ |

#### DOI: 10.1016/j.fluid.2007.08.006 — Block 2 (component [1])
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| 303.15 | 0.000695 | ±1.8 × 10⁻⁵ |
| 308.15 | 0.000658 | ±1.7 × 10⁻⁵ |
| 313.15 | 0.000617 | ±1.6 × 10⁻⁵ |

#### DOI: 10.1016/j.fluid.2007.08.006 — Block 5 (component [2])
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| 303.15 | 0.000352 | ±9 × 10⁻⁶ |
| 308.15 | 0.000334 | ±9 × 10⁻⁶ |
| 313.15 | 0.000315 | ±8 × 10⁻⁶ |

#### DOI: 10.1016/j.fluid.2007.08.006 — Block 8 (component [3])
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| 303.15 | 0.000715 | ±1.8 × 10⁻⁵ |
| 308.15 | 0.000693 | ±1.8 × 10⁻⁵ |
| 313.15 | 0.000677 | ±1.8 × 10⁻⁵ |

#### DOI: 10.1016/j.fluid.2010.07.005 — Block 2 (component [2]) ⭐ includes 298.15 K
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| **298.15** | **0.27186** | ±0.008 |
| 303.15 | 0.18830 | ±0.00446 |
| 308.15 | 0.13949 | ±0.00258 |
| 313.15 | 0.11025 | ±0.00161 |
| 318.15 | 0.08444 | ±0.00088 |
| 323.15 | 0.06999 | ±0.00059 |

#### DOI: 10.1016/j.fluid.2016.08.022 — Block 6 (component [2])
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| 293.15 | 0.0011608 | ±1.38 × 10⁻⁵ |
| 313.15 | 0.0008137 | ±9.8 × 10⁻⁶ |
| 333.15 | 0.0005849 | ±7.2 × 10⁻⁶ |

#### DOI: 10.1016/j.fluid.2017.06.001 — Block 4 (component [1]) ⭐ includes 298.15 K
| T / K | Viscosity | Uncertainty |
|-------|-----------|-------------|
| **298.15** | **0.446** | ±0.02 |
| 308.15 | 0.254 | ±0.01 |
| 318.15 | 0.154 | ±0.005 |
| 328.15 | 0.0982 | ±0.0028 |
| 338.15 | 0.0659 | ±0.0018 |
| 348.15 | 0.0452 | ±0.0012 |
| 358.15 | 0.0328 | ±0.0009 |

---

### Summary for SQL tasks
1. **Capillary tube at 298.15 K**: Two blocks report data exactly at 298.15 K — DOI `10.1016/j.fluid.2010.07.005` (0.27186) and DOI `10.1016/j.fluid.2017.06.001` (0.446). Several other blocks bracket 298.15 K (data at 293.15 and 303.15 K).
2. **Falling sphere at 298.15 K**: **No falling-sphere viscometry data returned** by this query.
3. **Cross-method comparison**: Not possible from this result set — only capillary-tube data was found.
```

### Integrity and timing

- Raw SHA-256: 4a5f9cae3ab07a7c7a92a84eeb4aea42dc710959796582603e8cd6e23bcb26ff
- Raw characters: 19304
- Hardcoded-compacted characters: 0
- Model-visible characters: 3280
- Agentic verdict: COMPACTED
- Tool elapsed: 2.846s
- Compactor elapsed: 25.418s
- Total elapsed: 28.265s

## Step 12: execute_sql

### Call arguments

```json
{
  "query": "-- Check compounds for papers that had suspicious values\nSELECT c.doi, c.org_num, c.common_name\nFROM raw.compounds c\nWHERE c.doi IN ('10.1016/j.fluid.2010.07.005', '10.1016/j.fluid.2017.06.001', \n                '10.1016/j.fluid.2006.01.030', '10.1016/j.fluid.2016.08.022',\n                '10.1016/j.fluid.2007.08.006')\nORDER BY c.doi, c.org_num",
  "purpose": "Verify which org_num corresponds to ethanol in each paper to correctly identify pure ethanol blocks",
  "tasks": [
    "Map org_num to compound name for each DOI",
    "Determine which blocks are actually pure ethanol vs other compounds"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Verify which org_num corresponds to ethanol in each paper to correctly identify pure ethanol blocks

## SQL tasks

```json
["Map org_num to compound name for each DOI","Determine which blocks are actually pure ethanol vs other compounds"]
```

## Executed SQL (visible form)

```sql
-- Check compounds for papers that had suspicious values
SELECT c.doi, c.org_num, c.common_name
FROM raw.compounds c
WHERE c.doi IN ('10.1016/j.fluid.2010.07.005', '10.1016/j.fluid.2017.06.001', 
                '10.1016/j.fluid.2006.01.030', '10.1016/j.fluid.2016.08.022',
                '10.1016/j.fluid.2007.08.006')
ORDER BY c.doi, c.org_num
```

## Result metadata

- Rows serialized: 77
- Truncated by max_rows: No.
- Elapsed seconds: 0.038392

## Columns

```json
["doi","org_num","common_name"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.fluid.2006.01.030",1,"ethanol"]
["10.1016/j.fluid.2006.01.030",2,"heptane"]
["10.1016/j.fluid.2007.08.006",1,"ethanol"]
["10.1016/j.fluid.2007.08.006",2,"butanone"]
["10.1016/j.fluid.2007.08.006",3,"dimethylformamide"]
["10.1016/j.fluid.2010.07.005",1,"water"]
["10.1016/j.fluid.2010.07.005",2,"1,3-dimethylimidazolium dimethylphosphate"]
["10.1016/j.fluid.2010.07.005",3,"ethanol"]
["10.1016/j.fluid.2010.07.005",4,"methanol"]
["10.1016/j.fluid.2016.08.022",1,"1-(2-azidoethyl)pyrrolidine"]
["10.1016/j.fluid.2016.08.022",2,"ethanol"]
["10.1016/j.fluid.2017.06.001",1,"tetraoctylphosphonium bis((trifluoromethyl)sulfonyl)amide"]
["10.1016/j.fluid.2017.06.001",2,"ethylbenzene"]
["10.1016/j.fluid.2017.06.001",3,"1,2-dimethylbenzene"]
["10.1016/j.fluid.2017.06.001",4,"1,3-dimethylbenzene"]
["10.1016/j.fluid.2017.06.001",5,"1,4-dimethylbenzene"]
["10.1016/j.fluid.2017.06.001",6,"propylbenzene"]
["10.1016/j.fluid.2017.06.001",7,"isopropylbenzene"]
["10.1016/j.fluid.2017.06.001",8,"styrene"]
["10.1016/j.fluid.2017.06.001",9,"(1-methylethenyl)benzene"]
["10.1016/j.fluid.2017.06.001",10,"thiophene"]
["10.1016/j.fluid.2017.06.001",11,"pyridine"]
["10.1016/j.fluid.2017.06.001",12,"methanol"]
["10.1016/j.fluid.2017.06.001",13,"ethanol"]
["10.1016/j.fluid.2017.06.001",14,"propan-1-ol"]
["10.1016/j.fluid.2017.06.001",15,"propan-2-ol"]
["10.1016/j.fluid.2017.06.001",16,"butan-1-ol"]
["10.1016/j.fluid.2017.06.001",17,"2-methyl-1-propanol"]
["10.1016/j.fluid.2017.06.001",18,"2-methylpropan-2-ol"]
["10.1016/j.fluid.2017.06.001",19,"pentan-1-ol"]
["10.1016/j.fluid.2017.06.001",20,"water"]
["10.1016/j.fluid.2017.06.001",21,"methyl ethanoate"]
["10.1016/j.fluid.2017.06.001",22,"methyl propanoate"]
["10.1016/j.fluid.2017.06.001",23,"methyl butanoate"]
["10.1016/j.fluid.2017.06.001",24,"ethyl acetate"]
["10.1016/j.fluid.2017.06.001",25,"pentane"]
["10.1016/j.fluid.2017.06.001",26,"hexane"]
["10.1016/j.fluid.2017.06.001",27,"3-methylpentane"]
["10.1016/j.fluid.2017.06.001",28,"2,2-dimethylbutane"]
["10.1016/j.fluid.2017.06.001",29,"heptane"]
["10.1016/j.fluid.2017.06.001",30,"octane"]
["10.1016/j.fluid.2017.06.001",31,"2,2,4-trimethylpentane"]
["10.1016/j.fluid.2017.06.001",32,"nonane"]
["10.1016/j.fluid.2017.06.001",33,"decane"]
["10.1016/j.fluid.2017.06.001",34,"cyclopentane"]
["10.1016/j.fluid.2017.06.001",35,"cyclohexane"]
["10.1016/j.fluid.2017.06.001",36,"methylcyclohexane"]
["10.1016/j.fluid.2017.06.001",37,"cycloheptane"]
["10.1016/j.fluid.2017.06.001",38,"cyclooctane"]
["10.1016/j.fluid.2017.06.001",39,"1-pentene"]
["10.1016/j.fluid.2017.06.001",40,"hex-1-ene"]
["10.1016/j.fluid.2017.06.001",41,"cyclohexene"]
["10.1016/j.fluid.2017.06.001",42,"1-heptene"]
["10.1016/j.fluid.2017.06.001",43,"oct-1-ene"]
["10.1016/j.fluid.2017.06.001",44,"1-decene"]
["10.1016/j.fluid.2017.06.001",45,"1-pentyne"]
["10.1016/j.fluid.2017.06.001",46,"1-hexyne"]
["10.1016/j.fluid.2017.06.001",47,"1-heptyne"]
["10.1016/j.fluid.2017.06.001",48,"1-octyne"]
["10.1016/j.fluid.2017.06.001",49,"benzene"]
["10.1016/j.fluid.2017.06.001",50,"toluene"]
["10.1016/j.fluid.2017.06.001",51,"tetrahydrofuran"]
["10.1016/j.fluid.2017.06.001",52,"1,4-dioxane"]
["10.1016/j.fluid.2017.06.001",53,"2-methoxy-2-methylpropane"]
["10.1016/j.fluid.2017.06.001",54,"2-ethoxy-2-methylpropane"]
["10.1016/j.fluid.2017.06.001",55,"2-methoxy-2-methylbutane"]
["10.1016/j.fluid.2017.06.001",56,"diethyl ether"]
["10.1016/j.fluid.2017.06.001",57,"dipropyl ether"]
["10.1016/j.fluid.2017.06.001",58,"diisopropyl ether"]
["10.1016/j.fluid.2017.06.001",59,"dibutyl ether"]
["10.1016/j.fluid.2017.06.001",60,"acetone"]
["10.1016/j.fluid.2017.06.001",61,"pentan-2-one"]
["10.1016/j.fluid.2017.06.001",62,"pentan-3-one"]
["10.1016/j.fluid.2017.06.001",63,"butanal"]
["10.1016/j.fluid.2017.06.001",64,"acetonitrile"]
["10.1016/j.fluid.2017.06.001",65,"1-nitropropane"]
["10.1016/j.fluid.2017.06.001",66,"butan-2-ol"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compound–org_num Mapping for Ethanol Identification

### Ethanol org_num per DOI

| DOI | ethanol org_num | Other compounds in paper |
|-----|:-:|---|
| 10.1016/j.fluid.2006.01.030 | **1** | 2 = heptane |
| 10.1016/j.fluid.2007.08.006 | **1** | 2 = butanone, 3 = dimethylformamide |
| 10.1016/j.fluid.2010.07.005 | **3** | 1 = water, 2 = 1,3-dimethylimidazolium dimethylphosphate, 4 = methanol |
| 10.1016/j.fluid.2016.08.022 | **2** | 1 = 1-(2-azidoethyl)pyrrolidine |
| 10.1016/j.fluid.2017.06.001 | **13** | 65 other compounds (org_nums 1–66); no ethanol at org_num 1 |

### Key finding for Task 2

- **10.1016/j.fluid.2017.06.001** — ethanol is org_num **13** (not 1). Pure-ethanol blocks must have `component_org_nums` containing 13 only. Any block with a different single org_num is a different compound.
- **10.1016/j.fluid.2010.07.005** — ethanol is org_num **3** (not 1). Blocks with only org_num 1 (water) or 4 (methanol) are not ethanol.
- The other three papers have ethanol as org_num 1 or 2; pure blocks for those org_nums are genuine pure-ethanol blocks.

*77 rows returned; no truncation. All rows shown or summarised above.*
```

### Integrity and timing

- Raw SHA-256: 3e36dc919f5d0b6ff9773fd00b05d7b22d6ea5f395027e404b539280e8d1f573
- Raw characters: 4858
- Hardcoded-compacted characters: 0
- Model-visible characters: 1144
- Agentic verdict: COMPACTED
- Tool elapsed: 0.038s
- Compactor elapsed: 12.330s
- Total elapsed: 12.369s

## Step 13: execute_sql

### Call arguments

```json
{
  "query": "-- Find falling sphere viscometry blocks with data near 298 K\nSELECT \n  bp.doi, bp.block_number, bp.method_name, b.n_datapoints, b.component_org_nums,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')\n  AND bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\n  AND b.n_datapoints BETWEEN 3 AND 12\n  AND bp.method_name = 'Falling or rolling sphere viscometry'\nGROUP BY bp.doi, bp.block_number\nLIMIT 10",
  "purpose": "Find falling sphere viscometry data for pure ethanol with temperature ranges that might include 298.15 K",
  "tasks": [
    "Find falling sphere viscosity values at or near 298.15 K for pure ethanol",
    "Compare with capillary tube and concentric cylinder values"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Find falling sphere viscometry data for pure ethanol with temperature ranges that might include 298.15 K

## SQL tasks

```json
["Find falling sphere viscosity values at or near 298.15 K for pure ethanol","Compare with capillary tube and concentric cylinder values"]
```

## Executed SQL (visible form)

```sql
-- Find falling sphere viscometry blocks with data near 298 K
SELECT 
  bp.doi, bp.block_number, bp.method_name, b.n_datapoints, b.component_org_nums,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.papers p ON p.doi = bp.doi
WHERE bp.doi IN (SELECT DISTINCT doi FROM raw.compounds WHERE standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N')
  AND bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
  AND b.n_datapoints BETWEEN 3 AND 12
  AND bp.method_name = 'Falling or rolling sphere viscometry'
GROUP BY bp.doi, bp.block_number
LIMIT 10
```

## Result metadata

- Rows serialized: 10
- Truncated by max_rows: No.
- Elapsed seconds: 0.263096

## Columns

```json
["doi","block_number","method_name","n_datapoints","component_org_nums","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.jct.2009.06.023",1,"Falling or rolling sphere viscometry",11,"[1]","[{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":283.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.54e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0014179,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":288.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0012811,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.39e-05},\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.26e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0011617,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":298.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.14e-05},\"nPropValue\":0.0010569}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":303.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.0009645,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.04e-05}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":308.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":9.5e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0008827}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":8.7e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.00081,\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":318.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0007451}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":7.3e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0006868,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":323.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0006344,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.8e-06}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":328.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.3e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0005872,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":333.15}]}]"]
["10.1016/j.jct.2009.06.023",3,"Falling or rolling sphere viscometry",11,"[2]","[{\"VariableValue\":[{\"nVarValue\":283.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.57e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0034744,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}]},{\"VariableValue\":[{\"nVarValue\":288.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.57e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0027676,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.81e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0024104}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":298.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.44e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0021178,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0018742,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.14e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0016709,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.87e-05,\"nCombUncertAssessNum\":1},\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":308.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.68e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0015237,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":318.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1,\"nPropValue\":0.0013833,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.53e-05,\"nCombUncertAssessNum\":1}}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.38e-05},\"nPropValue\":0.001256,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":323.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":328.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.25e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0011523,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.16e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0010819,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":333.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]}]"]
["10.1016/j.jct.2009.06.023",5,"Falling or rolling sphere viscometry",11,"[3]","[{\"VariableValue\":[{\"nVarValue\":283.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0038794,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":4.76e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.18e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0033911,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":288.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"PropertyValue\":[{\"nPropValue\":0.00301,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.72e-05},\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":293.15}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5,\"nPropValue\":0.0026062,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.24e-05}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":303.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0023147,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.81e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0020655}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":308.15}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15}],\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.23e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0018476}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":318.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.99e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0016597,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":323.15}],\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.79e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0014952}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.61e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0013567,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":328.15}]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":333.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0012435,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.47e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}]}]"]
["10.1016/j.jct.2011.06.002",2,"Falling or rolling sphere viscometry",4,"[4]","[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0036016,\"nCombUncertAssessNum\":1},\"nPropValue\":0.1088599,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":7,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarValue\":348.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"VariableValue\":[{\"nVarValue\":351.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0929905,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0027768},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":6,\"nPropNumber\":1}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":6,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0023445,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0841678}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":353.15}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":6,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0016291,\"nCombUncertAssessNum\":1},\"nPropValue\":0.066282}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":358.15}]}]"]
["10.1016/j.jct.2012.01.013",1,"Falling or rolling sphere viscometry",5,"[1]","[{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000588,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":298.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombExpandUncertValue\":6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000551}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000517,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":303.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000486,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":308.15}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.00046,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6e-05}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15}]}]"]
["10.1016/j.jct.2012.01.013",4,"Falling or rolling sphere viscometry",5,"[3]","[{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.002206,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":293.15}]},{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.2e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.001976}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001737}]},{\"VariableValue\":[{\"nVarValue\":308.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001548,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.001383,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":6.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]}]"]
["10.1016/j.jct.2012.01.013",6,"Falling or rolling sphere viscometry",5,"[4]","[{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"nPropValue\":0.002941,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":6.4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":298.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.3e-05},\"nPropValue\":0.002573}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropValue\":0.002264,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.2e-05},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":308.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.002002,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.2e-05,\"nCombUncertAssessNum\":1}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.1e-05},\"nPropValue\":0.001788}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15}]}]"]
["10.1016/j.jct.2012.01.013",8,"Falling or rolling sphere viscometry",5,"[5]","[{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":293.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9.4e-05},\"nPropValue\":0.008196}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.006926,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":8.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.9e-05},\"nPropValue\":0.005913}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":303.15}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":7.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.005069}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":308.15}]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":313.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.004395,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":7.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]}]"]
["10.1016/j.jct.2012.01.013",10,"Falling or rolling sphere viscometry",5,"[6]","[{\"PropertyValue\":[{\"nPropValue\":0.001002,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.000891,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6e-05},\"nPropValue\":0.000798,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":303.15}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000718,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6e-05}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":308.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000652,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15}]}]"]
["10.1016/j.jct.2012.05.001",1,"Falling or rolling sphere viscometry",5,"[4]","[{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":6,\"nPropNumber\":1,\"nPropValue\":0.807597,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.098274,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.0556,\"nCombUncertAssessNum\":1},\"nPropValue\":0.533412,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":6}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":298.15}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.369633,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.032326,\"nCombUncertAssessNum\":1},\"nPropDigits\":6,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.003877},\"nPropValue\":0.106157,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":6,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":323.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.041093,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.000797,\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":343.15}]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Falling Sphere Viscometry – Pure Ethanol (and other pure compounds) near 298.15 K

**Method:** Falling or rolling sphere viscometry | **10 blocks returned, not truncated**

### Important caveat

The query filtered for DOIs containing ethanol (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`), but each DOI may contain multiple pure compounds. The `component_org_nums` column shows which compound each block refers to. **Only blocks for the ethanol component** are relevant; the others are co-listed compounds in the same paper. The compound-to-org_num mapping must be checked against `raw.compounds` to confirm which blocks are actually ethanol.

---

### Extracted viscosity values at T = 298.15 K

| DOI | Block | component_org_nums | η (Pa·s) | Expanded Uncertainty (Pa·s) | T range (K) |
|---|---|---|---|---|---|
| 10.1016/j.jct.2009.06.023 | 1 | [1] | **0.0010569** | 1.14 × 10⁻⁵ | 283.15 – 333.15 |
| 10.1016/j.jct.2009.06.023 | 3 | [2] | **0.0021178** | 2.44 × 10⁻⁵ | 283.15 – 333.15 |
| 10.1016/j.jct.2009.06.023 | 5 | [3] | **0.0026062** | 3.24 × 10⁻⁵ | 283.15 – 333.15 |
| 10.1016/j.jct.2012.01.013 | 1 | [1] | **0.000551** | 6 × 10⁻⁵ | 293.15 – 313.15 |
| 10.1016/j.jct.2012.01.013 | 4 | [3] | **0.001976** | 6.2 × 10⁻⁵ | 293.15 – 313.15 |
| 10.1016/j.jct.2012.01.013 | 6 | [4] | **0.002573** | 6.3 × 10⁻⁵ | 293.15 – 313.15 |
| 10.1016/j.jct.2012.01.013 | 8 | [5] | **0.006926** | 8.5 × 10⁻⁵ | 293.15 – 313.15 |
| 10.1016/j.jct.2012.01.013 | 10 | [6] | **0.000891** | 6 × 10⁻⁵ | 293.15 – 313.15 |
| 10.1016/j.jct.2012.05.001 | 1 | [4] | **0.533412** | 0.0556 | 293.15 – 343.15 |

### Block with no 298.15 K data point

| DOI | Block | component_org_nums | Note |
|---|---|---|---|
| 10.1016/j.jct.2011.06.002 | 2 | [4] | Data only at 348.15 – 358.15 K (no value near 298 K) |

---

### Task 2 – Comparison with capillary tube / concentric cylinder methods

**This query only retrieved falling sphere viscometry data.** No capillary tube or concentric cylinder results are included. A separate query filtering on those `method_name` values would be needed for comparison.
```

### Integrity and timing

- Raw SHA-256: 84ef0e167178aa64d522ecb4efa8614f9776cc561193c35deb95a94d4d4af3c3
- Raw characters: 37729
- Hardcoded-compacted characters: 0
- Model-visible characters: 2076
- Agentic verdict: COMPACTED
- Tool elapsed: 0.263s
- Compactor elapsed: 20.233s
- Total elapsed: 20.498s

## Step 14: execute_sql

### Call arguments

```json
{
  "query": "-- Verify which org_num is ethanol in these papers\nSELECT c.doi, c.org_num, c.common_name\nFROM raw.compounds c\nWHERE c.doi IN ('10.1016/j.jct.2009.06.023', '10.1016/j.jct.2012.01.013', '10.1016/j.jct.2012.05.001',\n                '10.1016/j.jct.2011.06.002', '10.1021/acs.jced.8b00793', '10.1016/j.jct.2015.08.017')\nORDER BY c.doi, c.org_num",
  "purpose": "Identify which org_num is ethanol in each paper to correctly attribute viscosity values",
  "tasks": [
    "Map org_num to compound for each DOI",
    "Identify the correct ethanol blocks for falling sphere data"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Identify which org_num is ethanol in each paper to correctly attribute viscosity values

## SQL tasks

```json
["Map org_num to compound for each DOI","Identify the correct ethanol blocks for falling sphere data"]
```

## Executed SQL (visible form)

```sql
-- Verify which org_num is ethanol in these papers
SELECT c.doi, c.org_num, c.common_name
FROM raw.compounds c
WHERE c.doi IN ('10.1016/j.jct.2009.06.023', '10.1016/j.jct.2012.01.013', '10.1016/j.jct.2012.05.001',
                '10.1016/j.jct.2011.06.002', '10.1021/acs.jced.8b00793', '10.1016/j.jct.2015.08.017')
ORDER BY c.doi, c.org_num
```

## Result metadata

- Rows serialized: 51
- Truncated by max_rows: No.
- Elapsed seconds: 0.002198

## Columns

```json
["doi","org_num","common_name"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.jct.2009.06.023",1,"ethanol"]
["10.1016/j.jct.2009.06.023",2,"propan-1-ol"]
["10.1016/j.jct.2009.06.023",3,"butan-1-ol"]
["10.1016/j.jct.2009.06.023",4,"1-butyl-3-methylimidazolium nitrate"]
["10.1016/j.jct.2011.06.002",1,"water"]
["10.1016/j.jct.2011.06.002",2,"ethanol"]
["10.1016/j.jct.2011.06.002",3,"methanol"]
["10.1016/j.jct.2011.06.002",4,"1-methylimidazolium chloride"]
["10.1016/j.jct.2012.01.013",1,"methanol"]
["10.1016/j.jct.2012.01.013",2,"ethanol"]
["10.1016/j.jct.2012.01.013",3,"propan-1-ol"]
["10.1016/j.jct.2012.01.013",4,"butan-1-ol"]
["10.1016/j.jct.2012.01.013",5,"1-methylimidazolium acetate"]
["10.1016/j.jct.2012.01.013",6,"water"]
["10.1016/j.jct.2012.05.001",1,"ethanol"]
["10.1016/j.jct.2012.05.001",2,"water"]
["10.1016/j.jct.2012.05.001",3,"methanol"]
["10.1016/j.jct.2012.05.001",4,"diethanolammonium formate"]
["10.1016/j.jct.2012.05.001",5,"2-hydroxyethylammonium formate"]
["10.1016/j.jct.2015.08.017",1,"1-ethyl-3-methylimidazolium octyl sulfate"]
["10.1016/j.jct.2015.08.017",2,"pentane"]
["10.1016/j.jct.2015.08.017",3,"hexane"]
["10.1016/j.jct.2015.08.017",4,"heptane"]
["10.1016/j.jct.2015.08.017",5,"octane"]
["10.1016/j.jct.2015.08.017",6,"nonane"]
["10.1016/j.jct.2015.08.017",7,"cyclohexane"]
["10.1016/j.jct.2015.08.017",8,"cyclopentane"]
["10.1016/j.jct.2015.08.017",9,"cyclooctane"]
["10.1016/j.jct.2015.08.017",10,"methylcyclohexane"]
["10.1016/j.jct.2015.08.017",11,"1-pentene"]
["10.1016/j.jct.2015.08.017",12,"hex-1-ene"]
["10.1016/j.jct.2015.08.017",13,"1-heptene"]
["10.1016/j.jct.2015.08.017",14,"oct-1-ene"]
["10.1016/j.jct.2015.08.017",15,"1-nonene"]
["10.1016/j.jct.2015.08.017",16,"1-pentyne"]
["10.1016/j.jct.2015.08.017",17,"1-hexyne"]
["10.1016/j.jct.2015.08.017",18,"1-heptyne"]
["10.1016/j.jct.2015.08.017",19,"1-octyne"]
["10.1016/j.jct.2015.08.017",20,"1-nonyne"]
["10.1016/j.jct.2015.08.017",21,"benzene"]
["10.1016/j.jct.2015.08.017",22,"toluene"]
["10.1016/j.jct.2015.08.017",23,"pentan-2-one"]
["10.1016/j.jct.2015.08.017",24,"methanol"]
["10.1016/j.jct.2015.08.017",25,"ethanol"]
["10.1016/j.jct.2015.08.017",26,"propan-2-ol"]
["10.1016/j.jct.2015.08.017",27,"acetone"]
["10.1016/j.jct.2015.08.017",28,"butanone"]
["10.1016/j.jct.2015.08.017",29,"butan-1-ol"]
["10.1016/j.jct.2015.08.017",30,"2-methyl-1-propanol"]
["10.1016/j.jct.2015.08.017",31,"water"]
["10.1021/acs.jced.8b00793",1,"ethanol"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Ethanol org_num Mapping by DOI

| DOI | Ethanol org_num | Total compounds in paper |
|-----|:-:|:-:|
| 10.1016/j.jct.2009.06.023 | **1** | 4 |
| 10.1016/j.jct.2011.06.002 | **2** | 4 |
| 10.1016/j.jct.2012.01.013 | **2** | 6 |
| 10.1016/j.jct.2012.05.001 | **1** | 5 |
| 10.1016/j.jct.2015.08.017 | **25** | 31 |
| 10.1021/acs.jced.8b00793 | **1** | 1 |

**Note:** `10.1016/j.jct.2015.08.017` does **not** contain ethanol as a standalone pure-component study — ethanol is org_num 25 among 31 compounds (primarily hydrocarbons and an ionic liquid). For falling-sphere or other pure-ethanol viscosity blocks, the relevant papers are those where ethanol appears at low org_num alongside few other compounds, or as the sole compound (e.g., `10.1021/acs.jced.8b00793` with only ethanol).

**Omitted detail:** The full compound lists for non-ethanol entries in each paper were dropped as irrelevant to the ethanol-identification tasks. 51 total rows were returned; only the 6 ethanol rows are shown above.
```

### Integrity and timing

- Raw SHA-256: 94bc46481489dab14e1fbf7a8fe4d738f394f2d58de5b716b5bd71e1df39eb84
- Raw characters: 3304
- Hardcoded-compacted characters: 0
- Model-visible characters: 1002
- Agentic verdict: COMPACTED
- Tool elapsed: 0.002s
- Compactor elapsed: 11.811s
- Total elapsed: 11.813s

## Step 15: execute_sql

### Call arguments

```json
{
  "query": "-- Get the correct ethanol block from 10.1016/j.jct.2012.01.013 (ethanol = org_num 2, so component_org_nums = [2])\n-- and 10.1016/j.jct.2012.05.001 (ethanol = org_num 1, component_org_nums = [1])\n-- Also get the oscillating disk data for the correct ethanol block in 10.1016/j.jct.2015.08.017 (ethanol = org_num 25)\nSELECT bp.doi, bp.block_number, bp.method_name, b.component_org_nums, b.n_datapoints,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\n  AND (\n    (bp.doi = '10.1016/j.jct.2012.01.013' AND b.component_org_nums = '[2]')\n    OR (bp.doi = '10.1016/j.jct.2012.05.001' AND b.component_org_nums = '[1]')\n    OR (bp.doi = '10.1016/j.jct.2015.08.017' AND b.component_org_nums = '[25]')\n    OR (bp.doi = '10.1021/acs.jced.8b00793' AND b.component_org_nums = '[1]')\n  )\nGROUP BY bp.doi, bp.block_number",
  "purpose": "Get viscosity data for confirmed pure ethanol blocks using falling sphere and oscillating disk methods",
  "tasks": [
    "Get falling sphere viscosity of pure ethanol at 298.15 K",
    "Get oscillating disk viscosity of pure ethanol near 298.15 K",
    "Get concentric cylinders viscosity of pure ethanol at 298.15 K"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Get viscosity data for confirmed pure ethanol blocks using falling sphere and oscillating disk methods

## SQL tasks

```json
["Get falling sphere viscosity of pure ethanol at 298.15 K","Get oscillating disk viscosity of pure ethanol near 298.15 K","Get concentric cylinders viscosity of pure ethanol at 298.15 K"]
```

## Executed SQL (visible form)

```sql
-- Get the correct ethanol block from 10.1016/j.jct.2012.01.013 (ethanol = org_num 2, so component_org_nums = [2])
-- and 10.1016/j.jct.2012.05.001 (ethanol = org_num 1, component_org_nums = [1])
-- Also get the oscillating disk data for the correct ethanol block in 10.1016/j.jct.2015.08.017 (ethanol = org_num 25)
SELECT bp.doi, bp.block_number, bp.method_name, b.component_org_nums, b.n_datapoints,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.papers p ON p.doi = bp.doi
WHERE bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
  AND (
    (bp.doi = '10.1016/j.jct.2012.01.013' AND b.component_org_nums = '[2]')
    OR (bp.doi = '10.1016/j.jct.2012.05.001' AND b.component_org_nums = '[1]')
    OR (bp.doi = '10.1016/j.jct.2015.08.017' AND b.component_org_nums = '[25]')
    OR (bp.doi = '10.1021/acs.jced.8b00793' AND b.component_org_nums = '[1]')
  )
GROUP BY bp.doi, bp.block_number
```

## Result metadata

- Rows serialized: 1
- Truncated by max_rows: No.
- Elapsed seconds: 0.004045

## Columns

```json
["doi","block_number","method_name","component_org_nums","n_datapoints","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1021/acs.jced.8b00793",2,"Concentric cylinders viscometry","[1]",4,"[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.00123,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"VariableValue\":[{\"nVarValue\":293.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.00102}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":313.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":2,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.00085,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":2,\"nPropNumber\":1,\"nPropValue\":0.00071,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":323.15}]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted SQL Result

### Overview
- **1 row returned** (out of 4 DOIs queried)
- **No data found** for the falling sphere (10.1016/j.jct.2012.01.013) or oscillating disk (10.1016/j.jct.2015.08.017) DOIs, nor for 10.1016/j.jct.2012.05.001. Only the concentric cylinders DOI matched.

### Concentric Cylinders Viscosity — Pure Ethanol
**DOI:** `10.1021/acs.jced.8b00793` | **Block:** 2 | **Method:** Concentric cylinders viscometry | **Component:** `[1]` | **4 datapoints**

| Temperature (K) | Viscosity (Pa·s) | Expanded Uncertainty (Pa·s) |
|---|---|---|
| 293.15 | 0.00123 | 5 × 10⁻⁵ |
| 303.15 | 0.00102 | 4 × 10⁻⁵ |
| 313.15 | 0.00085 | 4 × 10⁻⁵ |
| 323.15 | 0.00071 | 3 × 10⁻⁵ |

**Note:** No datapoint at exactly 298.15 K is present; the nearest bracketing temperatures are 293.15 K and 303.15 K.

### Tasks not fulfilled
1. **Falling sphere viscosity at 298.15 K** — No matching row returned for DOI `10.1016/j.jct.2012.01.013` (component_org_nums `[2]`).
2. **Oscillating disk viscosity near 298.15 K** — No matching row returned for DOI `10.1016/j.jct.2015.08.017` (component_org_nums `[25]`).
3. **Concentric cylinders at 298.15 K** — Data exists at 293.15 K and 303.15 K but not at exactly 298.15 K.
```

### Integrity and timing

- Raw SHA-256: 1156742c75bc6e2bfa84123314bdfdea500305b4afc33f0f49e450506d8322f0
- Raw characters: 4051
- Hardcoded-compacted characters: 0
- Model-visible characters: 1214
- Agentic verdict: COMPACTED
- Tool elapsed: 0.004s
- Compactor elapsed: 9.926s
- Total elapsed: 9.931s

## Step 16: execute_sql

### Call arguments

```json
{
  "query": "-- Find all pure ethanol viscosity blocks where component_org_nums matches the ethanol org_num\n-- by joining compounds to blocks on matching org_num\nSELECT bp.doi, bp.block_number, bp.method_name, b.component_org_nums, b.n_datapoints\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.compounds c ON c.doi = bp.doi AND c.standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N'\nWHERE bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\n  AND b.component_org_nums = '[' || c.org_num || ']'\n  AND bp.method_name IN ('Falling or rolling sphere viscometry', 'Oscillating disk viscometry', 'Concentric cylinders viscometry')\nGROUP BY bp.doi, bp.block_number\nORDER BY bp.method_name, bp.doi\nLIMIT 30",
  "purpose": "Find all confirmed pure ethanol viscosity blocks for falling sphere, oscillating disk, and concentric cylinders methods",
  "tasks": [
    "List all confirmed pure ethanol viscosity blocks by method",
    "Identify which blocks to extract data from"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Find all confirmed pure ethanol viscosity blocks for falling sphere, oscillating disk, and concentric cylinders methods

## SQL tasks

```json
["List all confirmed pure ethanol viscosity blocks by method","Identify which blocks to extract data from"]
```

## Executed SQL (visible form)

```sql
-- Find all pure ethanol viscosity blocks where component_org_nums matches the ethanol org_num
-- by joining compounds to blocks on matching org_num
SELECT bp.doi, bp.block_number, bp.method_name, b.component_org_nums, b.n_datapoints
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.compounds c ON c.doi = bp.doi AND c.standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N'
WHERE bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
  AND b.component_org_nums = '[' || c.org_num || ']'
  AND bp.method_name IN ('Falling or rolling sphere viscometry', 'Oscillating disk viscometry', 'Concentric cylinders viscometry')
GROUP BY bp.doi, bp.block_number
ORDER BY bp.method_name, bp.doi
LIMIT 30
```

## Result metadata

- Rows serialized: 29
- Truncated by max_rows: No.
- Elapsed seconds: 0.049180

## Columns

```json
["doi","block_number","method_name","component_org_nums","n_datapoints"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.jct.2018.02.022",3,"Concentric cylinders viscometry","[1]",4]
["10.1021/acs.jced.8b00793",2,"Concentric cylinders viscometry","[1]",4]
["10.1021/je200600p",3,"Concentric cylinders viscometry","[3]",9]
["10.1007/s10765-005-8089-2",1,"Falling or rolling sphere viscometry","[2]",23]
["10.1016/j.fluid.2006.01.030",1,"Falling or rolling sphere viscometry","[1]",20]
["10.1016/j.jct.2009.06.023",1,"Falling or rolling sphere viscometry","[1]",11]
["10.1016/j.jct.2012.10.008",6,"Falling or rolling sphere viscometry","[2]",5]
["10.1016/j.jct.2012.10.008",7,"Falling or rolling sphere viscometry","[2]",2]
["10.1016/j.jct.2013.09.044",6,"Falling or rolling sphere viscometry","[3]",1]
["10.1016/j.jct.2013.11.026",17,"Falling or rolling sphere viscometry","[9]",1]
["10.1016/j.jct.2015.04.027",4,"Falling or rolling sphere viscometry","[2]",5]
["10.1016/j.jct.2017.07.022",2,"Falling or rolling sphere viscometry","[1]",7]
["10.1016/j.jct.2019.04.023",5,"Falling or rolling sphere viscometry","[3]",7]
["10.1021/acs.jced.5b00365",4,"Falling or rolling sphere viscometry","[2]",7]
["10.1021/acs.jced.6b00096",2,"Falling or rolling sphere viscometry","[1]",2]
["10.1021/acs.jced.6b00563",3,"Falling or rolling sphere viscometry","[3]",3]
["10.1021/acs.jced.7b00267",2,"Falling or rolling sphere viscometry","[2]",9]
["10.1021/acs.jced.7b00944",6,"Falling or rolling sphere viscometry","[3]",1]
["10.1021/acs.jced.8b00086",17,"Falling or rolling sphere viscometry","[6]",1]
["10.1021/acs.jced.8b00939",12,"Falling or rolling sphere viscometry","[7]",1]
["10.1021/acs.jced.8b00965",4,"Falling or rolling sphere viscometry","[2]",5]
["10.1021/je0500633",1,"Falling or rolling sphere viscometry","[1]",3]
["10.1021/je0501639",2,"Falling or rolling sphere viscometry","[1]",3]
["10.1021/je200707b",5,"Falling or rolling sphere viscometry","[2]",5]
["10.1021/je201009c",3,"Falling or rolling sphere viscometry","[1]",4]
["10.1021/je401124t",6,"Falling or rolling sphere viscometry","[3]",7]
["10.1021/je500380x",4,"Falling or rolling sphere viscometry","[3]",1]
["10.1021/je500594z",12,"Falling or rolling sphere viscometry","[4]",4]
["10.1021/je501133u",2,"Falling or rolling sphere viscometry","[1]",8]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Confirmed Pure Ethanol Viscosity Blocks by Method

29 blocks found across 3 methods. No truncation.

### Concentric Cylinders Viscometry (3 blocks)

| DOI | Block # | Datapoints |
|-----|---------|------------|
| 10.1016/j.jct.2018.02.022 | 3 | 4 |
| 10.1021/acs.jced.8b00793 | 2 | 4 |
| 10.1021/je200600p | 3 | 9 |

### Falling or Rolling Sphere Viscometry (25 blocks)

| DOI | Block # | Datapoints |
|-----|---------|------------|
| 10.1007/s10765-005-8089-2 | 1 | 23 |
| 10.1016/j.fluid.2006.01.030 | 1 | 20 |
| 10.1016/j.jct.2009.06.023 | 1 | 11 |
| 10.1016/j.jct.2012.10.008 | 6 | 5 |
| 10.1016/j.jct.2012.10.008 | 7 | 2 |
| 10.1016/j.jct.2013.09.044 | 6 | 1 |
| 10.1016/j.jct.2013.11.026 | 17 | 1 |
| 10.1016/j.jct.2015.04.027 | 4 | 5 |
| 10.1016/j.jct.2017.07.022 | 2 | 7 |
| 10.1016/j.jct.2019.04.023 | 5 | 7 |
| 10.1021/acs.jced.5b00365 | 4 | 7 |
| 10.1021/acs.jced.6b00096 | 2 | 2 |
| 10.1021/acs.jced.6b00563 | 3 | 3 |
| 10.1021/acs.jced.7b00267 | 2 | 9 |
| 10.1021/acs.jced.7b00944 | 6 | 1 |
| 10.1021/acs.jced.8b00086 | 17 | 1 |
| 10.1021/acs.jced.8b00939 | 12 | 1 |
| 10.1021/acs.jced.8b00965 | 4 | 5 |
| 10.1021/je0500633 | 1 | 3 |
| 10.1021/je0501639 | 2 | 3 |
| 10.1021/je200707b | 5 | 5 |
| 10.1021/je201009c | 3 | 4 |
| 10.1021/je401124t | 6 | 7 |
| 10.1021/je500380x | 4 | 1 |
| 10.1021/je500594z | 12 | 4 |
| 10.1021/je501133u | 2 | 8 |

### Oscillating Disk Viscometry

**No blocks found** for this method.

### Notes for Data Extraction
- Blocks with the most datapoints (best candidates for temperature-range coverage near 25 °C): block 1 of `10.1007/s10765-005-8089-2` (23 pts), block 1 of `10.1016/j.fluid.2006.01.030` (20 pts), block 1 of `10.1016/j.jct.2009.06.023` (11 pts), and block 3 of `10.1021/je200600p` (9 pts).
- Several blocks have only 1 datapoint; these may represent single-temperature calibration/reference values.
```

### Integrity and timing

- Raw SHA-256: 7f6995ea73f7aa46fba804bc445dea7235f1a23d46d02123a9df09d6ef2cb0ab
- Raw characters: 3692
- Hardcoded-compacted characters: 0
- Model-visible characters: 1859
- Agentic verdict: COMPACTED
- Tool elapsed: 0.049s
- Compactor elapsed: 12.703s
- Total elapsed: 12.752s

## Step 17: execute_sql

### Call arguments

```json
{
  "query": "-- Get falling sphere data for confirmed ethanol blocks with multiple datapoints\nSELECT \n  bp.doi, bp.block_number, bp.method_name,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE bp.prop_name LIKE '%iscosit%'\n  AND bp.block_type = 'PureOrMixtureData'\n  AND (\n    (bp.doi = '10.1016/j.jct.2009.06.023' AND bp.block_number = 1)\n    OR (bp.doi = '10.1021/acs.jced.5b00365' AND bp.block_number = 4)\n    OR (bp.doi = '10.1021/acs.jced.7b00267' AND bp.block_number = 2)\n    OR (bp.doi = '10.1021/je501133u' AND bp.block_number = 2)\n    OR (bp.doi = '10.1021/je401124t' AND bp.block_number = 6)\n    OR (bp.doi = '10.1016/j.jct.2017.07.022' AND bp.block_number = 2)\n    OR (bp.doi = '10.1016/j.jct.2019.04.023' AND bp.block_number = 5)\n  )\nGROUP BY bp.doi, bp.block_number\nLIMIT 10",
  "purpose": "Extract falling sphere viscosity values for confirmed pure ethanol blocks to find data near 298.15 K",
  "tasks": [
    "Find falling sphere viscosity of pure ethanol at or near 298.15 K",
    "Compare falling sphere values with capillary tube and concentric cylinder values",
    "Assess consistency of values across methods"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Extract falling sphere viscosity values for confirmed pure ethanol blocks to find data near 298.15 K

## SQL tasks

```json
["Find falling sphere viscosity of pure ethanol at or near 298.15 K","Compare falling sphere values with capillary tube and concentric cylinder values","Assess consistency of values across methods"]
```

## Executed SQL (visible form)

```sql
-- Get falling sphere data for confirmed ethanol blocks with multiple datapoints
SELECT 
  bp.doi, bp.block_number, bp.method_name,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.papers p ON p.doi = bp.doi
WHERE bp.prop_name LIKE '%iscosit%'
  AND bp.block_type = 'PureOrMixtureData'
  AND (
    (bp.doi = '10.1016/j.jct.2009.06.023' AND bp.block_number = 1)
    OR (bp.doi = '10.1021/acs.jced.5b00365' AND bp.block_number = 4)
    OR (bp.doi = '10.1021/acs.jced.7b00267' AND bp.block_number = 2)
    OR (bp.doi = '10.1021/je501133u' AND bp.block_number = 2)
    OR (bp.doi = '10.1021/je401124t' AND bp.block_number = 6)
    OR (bp.doi = '10.1016/j.jct.2017.07.022' AND bp.block_number = 2)
    OR (bp.doi = '10.1016/j.jct.2019.04.023' AND bp.block_number = 5)
  )
GROUP BY bp.doi, bp.block_number
LIMIT 10
```

## Result metadata

- Rows serialized: 7
- Truncated by max_rows: No.
- Elapsed seconds: 0.034646

## Columns

```json
["doi","block_number","method_name","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.jct.2009.06.023",1,"Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":283.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.54e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0014179,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":288.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0012811,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.39e-05},\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.26e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0011617,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5}],\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":298.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.14e-05},\"nPropValue\":0.0010569}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":303.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.0009645,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.04e-05}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":308.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":9.5e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0008827}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":8.7e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.00081,\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":318.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0007451}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":7.3e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0006868,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":323.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0006344,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.8e-06}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":328.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.3e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0005872,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":333.15}]}]"]
["10.1016/j.jct.2017.07.022",2,"Falling or rolling sphere viscometry","[{\"PropertyValue\":[{\"nPropValue\":0.001286,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":0.000129,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":288.15}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.000117},\"nPropValue\":0.001165}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001071,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":0.000107}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000975,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9.8e-05,\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":303.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":308.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.00089,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":8.9e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000815,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8.2e-05,\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":7.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000747,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":318.15}]}]"]
["10.1016/j.jct.2019.04.023",5,"Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001177,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.8e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"nPropValue\":0.001074,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.4e-05,\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000977}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":308.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":3.6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000888,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":313.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.3e-05},\"nPropValue\":0.000819,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarValue\":318.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.1e-05},\"nPropValue\":0.000753}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.8e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000697}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":323.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]}]"]
["10.1021/acs.jced.5b00365",4,"Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarValue\":293.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.001177,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-06,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.001071,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8e-06,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}]},{\"PropertyValue\":[{\"nPropValue\":0.000978,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8e-06,\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":303.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000895}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":308.15}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7e-06},\"nPropValue\":0.000822}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":313.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":318.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.000756,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6e-06}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":323.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000698,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6e-06}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1021/acs.jced.7b00267",2,"Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":293.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":3.69e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.0011936,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":298.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.0010854,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":3.35e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0009897,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.06e-05},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarValue\":308.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.0009036,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.79e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.56e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0008277}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.34e-05},\"nPropValue\":0.000759}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":318.15}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.16e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0006978}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":323.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0006434,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.99e-05,\"nCombUncertAssessNum\":1},\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":328.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.84e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0005942,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]}]"]
["10.1021/je401124t",6,"Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":293.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.5e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.001192,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.001085,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.3e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":303.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.1e-05},\"nPropValue\":0.00099,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":308.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000906,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.9e-05,\"nCombUncertAssessNum\":1}}]},{\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.8e-05},\"nPropValue\":0.000831}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":313.15}]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":318.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.000764,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]},{\"VariableValue\":[{\"nVarValue\":323.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000704,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}]}]"]
["10.1021/je501133u",2,"Falling or rolling sphere viscometry","[{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.00115,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05}}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":298.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.00107,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":303.15}],\"PropertyValue\":[{\"nPropValue\":0.00097,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05},\"nPropNumber\":1,\"nPropDigits\":2,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":308.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.00089,\"nPropDigits\":2,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05},\"nPropValue\":0.00081,\"nPropDigits\":2,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":318.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.00076,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":2,\"nPropNumber\":1}]},{\"PropertyValue\":[{\"nPropDigits\":2,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.00068,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05,\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":323.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarValue\":328.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2e-05},\"nPropValue\":0.00063,\"nPropNumber\":1,\"nPropDigits\":2,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Falling Sphere Viscosity of Pure Liquid Ethanol

All 7 sources use **"Falling or rolling sphere viscometry"**. Data extracted at **298.15 K** and nearby temperatures. Viscosity values are in **Pa·s** with combined expanded uncertainties.

### Values at 298.15 K (≈ 25 °C)

| DOI | η (Pa·s) | U(η) (Pa·s) |
|-----|----------|-------------|
| 10.1016/j.jct.2009.06.023 | 0.0010569 | 1.14 × 10⁻⁵ |
| 10.1016/j.jct.2017.07.022 | 0.001071 | 1.07 × 10⁻⁴ |
| 10.1016/j.jct.2019.04.023 | 0.001074 | 4.4 × 10⁻⁵ |
| 10.1021/acs.jced.5b00365 | 0.001071 | 8 × 10⁻⁶ |
| 10.1021/acs.jced.7b00267 | 0.0010854 | 3.35 × 10⁻⁵ |
| 10.1021/je401124t | 0.001085 | 2.3 × 10⁻⁵ |
| 10.1021/je501133u | 0.00107 | 2 × 10⁻⁵ |

### Full Temperature Profiles (all sources, selected temperatures near 25 °C)

| T (K) | jct.2009.06.023 | jct.2017.07.022 | jct.2019.04.023 | jced.5b00365 | jced.7b00267 | je401124t | je501133u |
|-------|----------------|----------------|----------------|-------------|-------------|----------|----------|
| 283.15 | 0.0014179 | — | — | — | — | — | — |
| 288.15 | 0.0012811 | 0.001286 | — | — | — | — | — |
| 293.15 | 0.0011617 | 0.001165 | 0.001177 | 0.001177 | 0.0011936 | 0.001192 | 0.00115 |
| **298.15** | **0.0010569** | **0.001071** | **0.001074** | **0.001071** | **0.0010854** | **0.001085** | **0.00107** |
| 303.15 | 0.0009645 | 0.000975 | 0.000977 | 0.000978 | 0.0009897 | 0.00099 | 0.00097 |
| 308.15 | 0.0008827 | 0.00089 | 0.000888 | 0.000895 | 0.0009036 | 0.000906 | 0.00089 |
| 313.15 | 0.00081 | 0.000815 | 0.000819 | 0.000822 | 0.0008277 | 0.000831 | 0.00081 |
| 318.15 | 0.0007451 | 0.000747 | 0.000753 | 0.000756 | 0.000759 | 0.000764 | 0.00076 |
| 323.15 | 0.0006868 | — | 0.000697 | 0.000698 | 0.0006978 | 0.000704 | 0.00068 |
| 328.15 | 0.0006344 | — | — | — | 0.0006434 | — | 0.00063 |
| 333.15 | 0.0005872 | — | — | — | 0.0005942 | — | — |

### Notes

- **No capillary tube or concentric cylinder data** were returned by this query — only falling/rolling sphere viscometry blocks were selected. Comparison across methods would require a separate query targeting those method types.
- At 298.15 K the seven falling-sphere values range from **0.001057 to 0.001085 Pa·s** (spread ≈ 2.7%), indicating good inter-study consistency for this single method.
- Uncertainties vary by roughly an order of magnitude across sources (8 × 10⁻⁶ to 1.07 × 10⁻⁴ Pa·s).
```

### Integrity and timing

- Raw SHA-256: b450cba852adc9afca6112a826d365b7520e7942c7548968a6ce0a5ae78bcdbe
- Raw characters: 31675
- Hardcoded-compacted characters: 0
- Model-visible characters: 2381
- Agentic verdict: COMPACTED
- Tool elapsed: 0.035s
- Compactor elapsed: 22.380s
- Total elapsed: 22.415s

## Step 18: execute_sql

### Call arguments

```json
{
  "query": "-- Find confirmed pure ethanol capillary tube viscosity blocks\nSELECT bp.doi, bp.block_number, bp.method_name, b.component_org_nums, b.n_datapoints\nFROM raw.block_properties bp\nJOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type\nJOIN raw.compounds c ON c.doi = bp.doi AND c.standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N'\nWHERE bp.prop_name LIKE '%iscosit%'\n  AND b.n_components = 1\n  AND bp.block_type = 'PureOrMixtureData'\n  AND b.component_org_nums = '[' || c.org_num || ']'\n  AND bp.method_name = 'Capillary tube (Ostwald; Ubbelohde) method'\n  AND b.n_datapoints BETWEEN 3 AND 15\nGROUP BY bp.doi, bp.block_number\nORDER BY bp.doi\nLIMIT 30",
  "purpose": "Find confirmed pure ethanol capillary tube viscosity blocks with multiple datapoints",
  "tasks": [
    "List all confirmed pure ethanol capillary tube blocks",
    "Identify blocks to extract data from"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Find confirmed pure ethanol capillary tube viscosity blocks with multiple datapoints

## SQL tasks

```json
["List all confirmed pure ethanol capillary tube blocks","Identify blocks to extract data from"]
```

## Executed SQL (visible form)

```sql
-- Find confirmed pure ethanol capillary tube viscosity blocks
SELECT bp.doi, bp.block_number, bp.method_name, b.component_org_nums, b.n_datapoints
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.compounds c ON c.doi = bp.doi AND c.standard_inchi_key = 'LFQSCWFLJHTTHZ-UHFFFAOYSA-N'
WHERE bp.prop_name LIKE '%iscosit%'
  AND b.n_components = 1
  AND bp.block_type = 'PureOrMixtureData'
  AND b.component_org_nums = '[' || c.org_num || ']'
  AND bp.method_name = 'Capillary tube (Ostwald; Ubbelohde) method'
  AND b.n_datapoints BETWEEN 3 AND 15
GROUP BY bp.doi, bp.block_number
ORDER BY bp.doi
LIMIT 30
```

## Result metadata

- Rows serialized: 22
- Truncated by max_rows: No.
- Elapsed seconds: 0.051239

## Columns

```json
["doi","block_number","method_name","component_org_nums","n_datapoints"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.fluid.2006.01.030",2,"Capillary tube (Ostwald; Ubbelohde) method","[1]",3]
["10.1016/j.fluid.2007.08.006",2,"Capillary tube (Ostwald; Ubbelohde) method","[1]",3]
["10.1016/j.fluid.2016.08.022",6,"Capillary tube (Ostwald; Ubbelohde) method","[2]",3]
["10.1016/j.jct.2012.08.024",4,"Capillary tube (Ostwald; Ubbelohde) method","[2]",7]
["10.1016/j.jct.2013.09.006",2,"Capillary tube (Ostwald; Ubbelohde) method","[1]",3]
["10.1016/j.jct.2015.08.036",2,"Capillary tube (Ostwald; Ubbelohde) method","[2]",5]
["10.1016/j.jct.2019.02.019",6,"Capillary tube (Ostwald; Ubbelohde) method","[3]",4]
["10.1021/acs.jced.5b01000",12,"Capillary tube (Ostwald; Ubbelohde) method","[3]",3]
["10.1021/acs.jced.7b00321",10,"Capillary tube (Ostwald; Ubbelohde) method","[5]",4]
["10.1021/acs.jced.8b01012",6,"Capillary tube (Ostwald; Ubbelohde) method","[2]",4]
["10.1021/je050010l",5,"Capillary tube (Ostwald; Ubbelohde) method","[2]",3]
["10.1021/je050367p",5,"Capillary tube (Ostwald; Ubbelohde) method","[2]",6]
["10.1021/je050402s",13,"Capillary tube (Ostwald; Ubbelohde) method","[7]",4]
["10.1021/je1000796",3,"Capillary tube (Ostwald; Ubbelohde) method","[3]",8]
["10.1021/je101173w",1,"Capillary tube (Ostwald; Ubbelohde) method","[2]",5]
["10.1021/je1013476",3,"Capillary tube (Ostwald; Ubbelohde) method","[2]",5]
["10.1021/je200922s",3,"Capillary tube (Ostwald; Ubbelohde) method","[2]",7]
["10.1021/je201116t",5,"Capillary tube (Ostwald; Ubbelohde) method","[3]",4]
["10.1021/je300557g",3,"Capillary tube (Ostwald; Ubbelohde) method","[2]",4]
["10.1021/je301095j",4,"Capillary tube (Ostwald; Ubbelohde) method","[2]",5]
["10.1021/je400630f",1,"Capillary tube (Ostwald; Ubbelohde) method","[1]",6]
["10.1021/je400968v",2,"Capillary tube (Ostwald; Ubbelohde) method","[3]",5]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Confirmed Pure Ethanol — Capillary Tube Viscosity Blocks (3–15 datapoints)

22 blocks found (no truncation). All use **Capillary tube (Ostwald; Ubbelohde) method** on pure ethanol (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`).

| # | DOI | block_number | n_datapoints |
|---|-----|:---:|:---:|
| 1 | 10.1016/j.fluid.2006.01.030 | 2 | 3 |
| 2 | 10.1016/j.fluid.2007.08.006 | 2 | 3 |
| 3 | 10.1016/j.fluid.2016.08.022 | 6 | 3 |
| 4 | **10.1016/j.jct.2012.08.024** | 4 | **7** |
| 5 | 10.1016/j.jct.2013.09.006 | 2 | 3 |
| 6 | 10.1016/j.jct.2015.08.036 | 2 | 5 |
| 7 | 10.1016/j.jct.2019.02.019 | 6 | 4 |
| 8 | 10.1021/acs.jced.5b01000 | 12 | 3 |
| 9 | 10.1021/acs.jced.7b00321 | 10 | 4 |
| 10 | 10.1021/acs.jced.8b01012 | 6 | 4 |
| 11 | 10.1021/je050010l | 5 | 3 |
| 12 | 10.1021/je050367p | 5 | 6 |
| 13 | 10.1021/je050402s | 13 | 4 |
| 14 | **10.1021/je1000796** | 3 | **8** |
| 15 | 10.1021/je101173w | 1 | 5 |
| 16 | 10.1021/je1013476 | 3 | 5 |
| 17 | **10.1021/je200922s** | 3 | **7** |
| 18 | 10.1021/je201116t | 5 | 4 |
| 19 | 10.1021/je300557g | 3 | 4 |
| 20 | 10.1021/je301095j | 4 | 5 |
| 21 | 10.1021/je400630f | 1 | 6 |
| 22 | 10.1021/je400968v | 2 | 5 |

### Blocks recommended for data extraction

Blocks with the most datapoints (bolded above) are the best candidates for extracting temperature-dependent viscosity values near 25 °C:

| DOI | block | datapoints |
|-----|:---:|:---:|
| 10.1021/je1000796 | 3 | 8 |
| 10.1016/j.jct.2012.08.024 | 4 | 7 |
| 10.1021/je200922s | 3 | 7 |
| 10.1021/je050367p | 5 | 6 |
| 10.1021/je400630f | 1 | 6 |
```

### Integrity and timing

- Raw SHA-256: ef7aa397829deeddb2867b12a9bb977da1d0e0fe6e5f2366f59b2cbc9c804358
- Raw characters: 3095
- Hardcoded-compacted characters: 0
- Model-visible characters: 1552
- Agentic verdict: COMPACTED
- Tool elapsed: 0.051s
- Compactor elapsed: 12.253s
- Total elapsed: 12.304s

## Step 19: execute_sql

### Call arguments

```json
{
  "query": "SELECT \n  bp.doi, bp.block_number,\n  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals\nFROM raw.block_properties bp\nJOIN raw.papers p ON p.doi = bp.doi\nWHERE bp.prop_name LIKE '%iscosit%'\n  AND bp.block_type = 'PureOrMixtureData'\n  AND (\n    (bp.doi = '10.1021/je1000796' AND bp.block_number = 3)\n    OR (bp.doi = '10.1016/j.jct.2012.08.024' AND bp.block_number = 4)\n    OR (bp.doi = '10.1021/je200922s' AND bp.block_number = 3)\n    OR (bp.doi = '10.1021/je050367p' AND bp.block_number = 5)\n    OR (bp.doi = '10.1021/je400630f' AND bp.block_number = 1)\n    OR (bp.doi = '10.1021/je101173w' AND bp.block_number = 1)\n    OR (bp.doi = '10.1021/je1013476' AND bp.block_number = 3)\n    OR (bp.doi = '10.1021/je400968v' AND bp.block_number = 2)\n  )\nGROUP BY bp.doi, bp.block_number\nLIMIT 10",
  "purpose": "Extract capillary tube viscosity values for confirmed pure ethanol blocks to find data at 298.15 K",
  "tasks": [
    "Find capillary tube viscosity of pure ethanol at 298.15 K",
    "Compare capillary tube values with falling sphere and concentric cylinder values",
    "Assess consistency across methods"
  ],
  "max_rows": 500
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw SQLite tool result

This is a lossless transport serialization, not a semantic summary.

## SQL purpose

Extract capillary tube viscosity values for confirmed pure ethanol blocks to find data at 298.15 K

## SQL tasks

```json
["Find capillary tube viscosity of pure ethanol at 298.15 K","Compare capillary tube values with falling sphere and concentric cylinder values","Assess consistency across methods"]
```

## Executed SQL (visible form)

```sql
SELECT 
  bp.doi, bp.block_number,
  json_extract(p.json_data, '$.PureOrMixtureData[' || (bp.block_number - 1) || '].NumValues') as numvals
FROM raw.block_properties bp
JOIN raw.papers p ON p.doi = bp.doi
WHERE bp.prop_name LIKE '%iscosit%'
  AND bp.block_type = 'PureOrMixtureData'
  AND (
    (bp.doi = '10.1021/je1000796' AND bp.block_number = 3)
    OR (bp.doi = '10.1016/j.jct.2012.08.024' AND bp.block_number = 4)
    OR (bp.doi = '10.1021/je200922s' AND bp.block_number = 3)
    OR (bp.doi = '10.1021/je050367p' AND bp.block_number = 5)
    OR (bp.doi = '10.1021/je400630f' AND bp.block_number = 1)
    OR (bp.doi = '10.1021/je101173w' AND bp.block_number = 1)
    OR (bp.doi = '10.1021/je1013476' AND bp.block_number = 3)
    OR (bp.doi = '10.1021/je400968v' AND bp.block_number = 2)
  )
GROUP BY bp.doi, bp.block_number
LIMIT 10
```

## Result metadata

- Rows serialized: 8
- Truncated by max_rows: No.
- Elapsed seconds: 0.031657

## Columns

```json
["doi","block_number","numvals"]
```

## Rows (JSONL arrays in column order)

```jsonl
["10.1016/j.jct.2012.08.024",4,"[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.6e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001087,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.00099,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":2,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000905,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":308.15}]},{\"PropertyValue\":[{\"nPropValue\":0.000829,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":313.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.1e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000761,\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":318.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000706,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":323.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000648}],\"VariableValue\":[{\"nVarValue\":328.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]}]"]
["10.1021/je050367p",5,"[{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001309,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":288.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarValue\":100.5}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.1e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.001309}],\"VariableValue\":[{\"nVarValue\":288.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]},{\"nVarValue\":100.8,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4}]},{\"VariableValue\":[{\"nVarValue\":298.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1},{\"nVarValue\":100.5,\"nVarNumber\":2,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001084,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]},{\"PropertyValue\":[{\"nPropValue\":0.001084,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":9e-06,\"nCombUncertAssessNum\":1},\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":298.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarNumber\":2,\"nVarValue\":100.8}]},{\"VariableValue\":[{\"nVarValue\":308.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5},{\"nVarDigits\":4,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":2,\"nVarValue\":100.5}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000905,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":8e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":3,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000905,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":8e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}],\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":308.15},{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":4,\"nVarNumber\":2,\"nVarValue\":100.8}]}]"]
["10.1021/je1000796",3,"[{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":278.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":5,\"nPropValue\":0.0016292,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.38e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"VariableValue\":[{\"nVarValue\":283.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"PropertyValue\":[{\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.25e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0014735}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.13e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0013325,\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":288.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1.03e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0012097,\"nPropNumber\":1,\"nPropDigits\":5,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.001099,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":9.4e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":5,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":298.15}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0009971,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":8.6e-06},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}]},{\"VariableValue\":[{\"nVarValue\":308.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.0009083,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":7.9e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":313.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"nPropValue\":0.000828,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":7.2e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]}}]}]"]
["10.1021/je101173w",1,"[{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}],\"PropertyValue\":[{\"nPropValue\":0.0012107,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":7.5e-06,\"nCombUncertAssessNum\":1},\"nPropDigits\":5,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":6.3e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0009977}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":303.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":313.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4,\"nPropValue\":0.0008319,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":5.4e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4.6e-06,\"nCombUncertAssessNum\":1},\"nPropValue\":0.0006876,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":323.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":4e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.0005806,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}]}]"]
["10.1021/je1013476",3,"[{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.001313,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}],\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":288.15}]},{\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"PropertyValue\":[{\"nPropValue\":0.001216,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":1.2e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.001132}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":303.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.00101,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":1e-05},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":4}]},{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":313.15}],\"PropertyValue\":[{\"nPropValue\":0.000824,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":8e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
["10.1021/je200922s",3,"[{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4.8e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.001189}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":293.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":4.4e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.001095,\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":298.15}]},{\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":4.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.001003}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":303.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.71e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000914,\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":308.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.43e-05},\"nPropValue\":0.000845,\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarValue\":313.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.000765,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":3.11e-05,\"nCombUncertAssessNum\":1},\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}],\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":318.15}]},{\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1,\"CombinedUncertainty\":{\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":2.86e-05,\"nCombUncertAssessNum\":1},\"nPropValue\":0.000704}],\"VariableValue\":[{\"nVarValue\":323.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]}]"]
["10.1021/je400630f",1,"[{\"VariableValue\":[{\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1,\"nVarValue\":283.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombExpandUncertValue\":3.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.001475}]},{\"VariableValue\":[{\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarValue\":293.15}],\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.5e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.001196,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":4,\"nPropNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"VariableValue\":[{\"nVarValue\":298.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropValue\":0.001102,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.3e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropDigits\":4,\"nPropNumber\":1,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"]}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"nPropValue\":0.000996,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":2.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"VariableValue\":[{\"nVarValue\":313.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":1.8e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1},\"nPropValue\":0.000842}]},{\"VariableValue\":[{\"nVarValue\":303.15,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":2.1e-05,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000994}]}]"]
["10.1021/je400968v",2,"[{\"VariableValue\":[{\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarValue\":293.15}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":4,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.001179,\"CombinedUncertainty\":{\"nCombExpandUncertValue\":8e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombUncertAssessNum\":1}}]},{\"PropertyValue\":[{\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000972,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropNumber\":1,\"nPropDigits\":3}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":303.15,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarNumber\":1}]},{\"VariableValue\":[{\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5,\"nVarNumber\":1,\"nVarValue\":313.15}],\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"nCombExpandUncertValue\":6e-06,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"]},\"nPropValue\":0.000806}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]},{\"PropertyValue\":[{\"nPropNumber\":1,\"nPropDigits\":3,\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropValue\":0.000672,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":5e-06}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"],\"VariableValue\":[{\"nVarValue\":323.15,\"nVarNumber\":1,\"nVarDigits\":5,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"]}]},{\"VariableValue\":[{\"nVarValue\":333.15,\"nVarNumber\":1,\"tml_elements\":[\"nVarNumber\",\"nVarValue\",\"nVarDigits\"],\"nVarDigits\":5}],\"PropertyValue\":[{\"tml_elements\":[\"nPropNumber\",\"nPropValue\",\"nPropDigits\",\"CombinedUncertainty\"],\"nPropDigits\":3,\"nPropNumber\":1,\"nPropValue\":0.000564,\"CombinedUncertainty\":{\"nCombUncertAssessNum\":1,\"tml_elements\":[\"nCombUncertAssessNum\",\"nCombExpandUncertValue\"],\"nCombExpandUncertValue\":4e-06}}],\"tml_elements\":[\"VariableValue\",\"PropertyValue\"]}]"]
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

```markdown
## Compacted Result: Pure Ethanol Viscosity Data from ThermoML

**8 rows returned, no truncation.**

### Viscosity values at 298.15 K (extracted from JSON NumValues)

| DOI | Block | η at 298.15 K (Pa·s) | Expanded Uncertainty (Pa·s) |
|-----|-------|-----------------------|-----------------------------|
| 10.1016/j.jct.2012.08.024 | 4 | 0.001087 | 1.6 × 10⁻⁵ |
| 10.1021/je050367p | 5 | 0.001084 | 9 × 10⁻⁶ |
| 10.1021/je1000796 | 3 | 0.001099 | 9.4 × 10⁻⁶ |
| 10.1021/je1013476 | 3 | 0.001132 | 1.1 × 10⁻⁵ |
| 10.1021/je200922s | 3 | 0.001095 | 4.4 × 10⁻⁵ |
| 10.1021/je400630f | 1 | 0.001102 | 2.3 × 10⁻⁵ |

**Note:** Two sources did **not** include a data point at 298.15 K:

| DOI | Block | Temperatures available (K) |
|-----|-------|---------------------------|
| 10.1021/je101173w | 1 | 293.15, 303.15, 313.15, 323.15, 333.15 |
| 10.1021/je400968v | 2 | 293.15, 303.15, 313.15, 323.15, 333.15 |

### Additional data points at nearby temperatures (for context/interpolation)

| DOI | Block | T (K) | η (Pa·s) | Uncertainty |
|-----|-------|--------|-----------|-------------|
| 10.1021/je101173w | 1 | 293.15 | 0.0012107 | 7.5 × 10⁻⁶ |
| 10.1021/je101173w | 1 | 303.15 | 0.0009977 | 6.3 × 10⁻⁶ |
| 10.1021/je400968v | 2 | 293.15 | 0.001179 | 8 × 10⁻⁶ |
| 10.1021/je400968v | 2 | 303.15 | 0.000972 | 6 × 10⁻⁶ |

### Notes on 10.1021/je050367p (block 5)

This block has a **second variable** (var_number 2, values 100.5 and 100.8 — likely pressure in kPa). Two duplicate viscosity values at 298.15 K are reported at slightly different pressures:
- At 100.5 kPa: η = 0.001084, U = 9 × 10⁻⁶
- At 100.8 kPa: η = 0.001084, U = 9 × 10⁻⁶

### Limitations for task assessment

- **Method information** (capillary tube, falling sphere, concentric cylinder) was **not extracted** in this query. The `block_properties` table contains `method_type` and `method_name` columns that would be needed to compare across methods.
- All values shown are from the `numvals` JSON; no method-type filtering was applied, so it is not possible from this result alone to distinguish which measurement technique was used for each DOI/block.

### Consistency summary (at 298.15 K)

The six reported values range from **0.001084 to 0.001132 Pa·s** (spread ≈ 4.4%), with most clustered between 0.001084 and 0.001102 Pa·s.
```

### Integrity and timing

- Raw SHA-256: 428c48cbe2eda393ce7f006f483ce18098b3436239cb4a92770902b047152cbe
- Raw characters: 28314
- Hardcoded-compacted characters: 0
- Model-visible characters: 2299
- Agentic verdict: COMPACTED
- Tool elapsed: 0.032s
- Compactor elapsed: 21.350s
- Total elapsed: 21.383s

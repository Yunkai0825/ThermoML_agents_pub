# Q1.5 — Result

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 19
- **API turns:** 20
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 1
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 529.9s
- **Timed out:** False

## Answer

Now I have comprehensive data. Let me compile the final answer.

---

## Viscosity of Pure Liquid Ethanol near 25 °C: Methods and Reported Values

### Overview

The ThermoML database contains a rich collection of viscosity measurements for pure liquid ethanol (InChIKey: `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`) near 25 °C (298.15 K), spanning **dozens of independent studies** and **four distinct measurement methods**. Here is a synthesis of the findings:

---

### Methods Used

| Method | # Confirmed Pure-Ethanol Blocks | Description |
|--------|:---:|---|
| **Capillary tube (Ostwald/Ubbelohde)** | ~22+ | Measures the time for a liquid to flow through a narrow capillary under gravity. The most widely used technique for low-viscosity Newtonian liquids. |
| **Falling or rolling sphere viscometry** | ~25+ | Measures the terminal velocity of a sphere falling through the liquid. Well-suited for moderate viscosities and high-pressure studies. |
| **Concentric cylinders (Couette) viscometry** | 3 | Measures torque on a rotating inner cylinder surrounded by the liquid. Often used for broader viscosity ranges. |
| **Oscillating disk viscometry** | 1 (not confirmed as ethanol) | Measures damping of an oscillating body immersed in the liquid. Rare for ethanol in this database. |

---

### Reported Values at 298.15 K (25 °C)

#### Capillary Tube (Ostwald/Ubbelohde) Method

| DOI | η (Pa·s) | Uncertainty (Pa·s) |
|-----|----------|---------------------|
| 10.1021/je050367p | 0.001084 | ± 9 × 10⁻⁶ |
| 10.1016/j.jct.2012.08.024 | 0.001087 | ± 1.6 × 10⁻⁵ |
| 10.1021/je200922s | 0.001095 | ± 4.4 × 10⁻⁵ |
| 10.1021/je1000796 | 0.001099 | ± 9.4 × 10⁻⁶ |
| 10.1021/je400630f | 0.001102 | ± 2.3 × 10⁻⁵ |
| 10.1021/je1013476 | 0.001132 | ± 1.1 × 10⁻⁵ |

**Range:** 1.084–1.132 mPa·s | **Central tendency:** ~1.09–1.10 mPa·s

#### Falling or Rolling Sphere Viscometry

| DOI | η (Pa·s) | Uncertainty (Pa·s) |
|-----|----------|---------------------|
| 10.1016/j.jct.2009.06.023 | 0.0010569 | ± 1.14 × 10⁻⁵ |
| 10.1021/je501133u | 0.00107 | ± 2 × 10⁻⁵ |
| 10.1021/acs.jced.5b00365 | 0.001071 | ± 8 × 10⁻⁶ |
| 10.1016/j.jct.2017.07.022 | 0.001071 | ± 1.07 × 10⁻⁴ |
| 10.1016/j.jct.2019.04.023 | 0.001074 | ± 4.4 × 10⁻⁵ |
| 10.1021/je401124t | 0.001085 | ± 2.3 × 10⁻⁵ |
| 10.1021/acs.jced.7b00267 | 0.0010854 | ± 3.35 × 10⁻⁵ |

**Range:** 1.057–1.085 mPa·s | **Central tendency:** ~1.07–1.08 mPa·s

#### Concentric Cylinders Viscometry

| DOI | η (Pa·s) | Uncertainty (Pa·s) | Notes |
|-----|----------|---------------------|-------|
| 10.1021/je200600p | 0.0010371 | ± 1.01 × 10⁻⁵ | At exactly 298.15 K |
| 10.1021/acs.jced.8b00793 | ~0.00113 (interpolated) | ± ~5 × 10⁻⁵ | Data at 293.15 K (0.00123) and 303.15 K (0.00102) |

---

### Cross-Method Comparison and Chemical Insights

1. **Excellent overall agreement:** All three methods converge on a dynamic viscosity of approximately **1.07–1.10 mPa·s** (0.00107–0.00110 Pa·s) at 298.15 K, consistent with the well-established literature value of ~1.074–1.083 mPa·s for ethanol at 25 °C.

2. **Slight systematic differences:**
   - **Falling sphere** values cluster slightly lower (~1.07 mPa·s on average), which may reflect the method's sensitivity to sphere calibration and density corrections.
   - **Capillary tube** values tend slightly higher (~1.09–1.10 mPa·s), possibly due to kinetic energy corrections or end effects in the capillary.
   - **Concentric cylinders** gave the lowest single value (1.037 mPa·s from one study), though with only 2–3 studies this is less statistically robust.

3. **Uncertainty ranges:** Reported expanded uncertainties vary from ~0.008 to ~0.107 mPa·s (relative uncertainties of ~0.7% to ~10%), with capillary tube methods generally reporting the tightest uncertainties (~1–2%).

4. **Temperature dependence:** Across all methods, ethanol viscosity decreases strongly with temperature — from ~1.2 mPa·s at 293.15 K (20 °C) to ~0.59 mPa·s at 333.15 K (60 °C) — following the typical Arrhenius-like behavior of hydrogen-bonded liquids. This steep temperature sensitivity (roughly halving over a 40 K range) reflects the progressive disruption of ethanol's hydrogen-bonding network with increasing thermal energy.

5. **Why ethanol is so widely measured:** Ethanol serves as a common **reference/calibration liquid** for viscometers, which explains the large number of independent measurements across many papers and methods in the ThermoML database. Its moderate viscosity, chemical stability, availability in high purity, and well-characterized properties make it ideal for instrument validation.

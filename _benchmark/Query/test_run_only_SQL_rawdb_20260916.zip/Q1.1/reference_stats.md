# Q1.1 — Reference Statistics

| Variant | Model | Compactor Model | Status | API turns | Tool calls | Elapsed (s) |
|---|---|---|---:|---:|---:|---:|
| Flat / raw-ThermoML SQL | claude-opus-4-6 | claude-opus-4-6 | OK | 22 | 21 | 477.1 |

## Token usage

| Role | Calls | Input tokens | Output tokens | Cache-create | Cache-read |
|---|---:|---:|---:|---:|---:|
| Answering agent | 22 | 257989 | 10163 | 0 | 0 |
| Result compactor(s) | 21 | 81720 | 10876 | 0 | 0 |

## Turn budget

- API effort: high
- Soft escalation begins: turn 20
- Configured strikes: 3
- Hard final turn: 22
- Strikes issued: 3
- Forced final chance reached: True
- Fresh final context characters: 53319
- Fresh final context SHA-256: df5a132c3c471022dd2678188e7f97141c9d56873163bb14c6b42d430b927205
- Tool request on final chance: False

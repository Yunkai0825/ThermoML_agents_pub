# Q1.1 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Compacted Result

### Task 2: Property name used for density

All 50 rows use a single property name:

> **`Mass density, kg/m3`**

### Task 1: DOIs and block numbers with ethanol+water binary density data

50 distinct (DOI, block) pairs were returned (query limit 50; there may be more in the database).

| DOI | Block(s) | Datapoints |
|-----|----------|------------|
| 10.1016/j.fluid.2004.11.019 | 2 | 810 |
| 10.1016/j.fluid.2006.05.007 | 1 | 45 |
| 10.1016/j.fluid.2006.12.005 | 3, 4 | 8, 2 |
| 10.1016/j.fluid.2009.07.010 | 14, 16, 18, 20, 22, 24, 26 | 19, 28, 8, 6, 13, 10, 10 |
| 10.1016/j.fluid.2010.01.002 | 19, 20, 21, 22, 23 | 72, 68, 52, 64, 44 |
| 10.1016/j.fluid.2010.01.020 | 26 | 78 |
| 10.1016/j.fluid.2010.03.017 | 1, 3, 5, 7 | 18 each |
| 10.1016/j.fluid.2010.07.005 | 8, 13, 18 | 30 each |
| 10.1016/j.fluid.2010.10.005 | 1 | 34 |
| 10.1016/j.fluid.2012.05.007 | 6, 9 | 4, 16 |
| 10.1016/j.fluid.2014.05.032 | 1 | 140 |
| 10.1016/j.fluid.2014.07.004 | 8, 10, 12 | 11 each |
| 10.1016/j.fluid.2014.10.044 | 7 | 2 |
| 10.1016/j.fluid.2014.11.005 | 5, 7, 9, 11, 13, 15 | 60, 66, 48, 48, 36, 36 |
| 10.1016/j.fluid.2014.11.009 | 6, 8 | 18 each |
| 10.1016/j.fluid.2015.06.034 | 11 | 4 |
| 10.1016/j.fluid.2015.07.012 | 1, 3, 5 | 80, 84, 84 |
| 10.1016/j.fluid.2017.09.005 | 1, 3, 5 | 72 each |
| 10.1016/j.fluid.2017.09.019 | 6, 8 | 9, 120 |
| 10.1016/j.fluid.2017.10.034 | 3 | 35 |

All blocks are of type `PureOrMixtureData` with `n_components = 2`.

**Note:** The query hit the LIMIT of 50 rows, so additional matching blocks likely exist in the database. The actual density values and conditions (temperature, pressure, composition) are stored in the papers' `json_data` and would require a follow-up query to extract.

## 2. execute_sql

## Compacted SQL Result

### Result: **Zero rows returned**

The query executed successfully (0.42 s) but produced **no matching data points**. No density values were extracted for ethanol+water mixtures from any papers in the database.

### Column schema returned (all empty)

| Column | Meaning |
|---|---|
| doi | Paper identifier |
| block_number | Data block index |
| prop_num | Property number |
| density_value | Mass density, kg/m³ |
| digits | Significant digits |
| var_num | Variable number (temperature, mole fraction, etc.) |
| var_value | Variable value |
| var_digits | Variable significant digits |

### Likely cause
The zero-based block indexing (`block_number - 1`) used in the JSON path may not align with how `block_number` is stored in the index tables, or the compound name matching (`%ethanol%`, `%water%`) may not match the actual `common_name` values in the database. The query was **not truncated**—there are genuinely no rows.

### Impact on tasks
1. **Density near x_ethanol ≈ 0.5, T ≈ 298.15 K**: No data found.
2. **Variable types (temperature, mole fraction) and values**: No data found.

## 3. execute_sql

## Compacted Result

**DOI:** `10.1016/j.fluid.2006.05.007`

### JSON Structure of `PureOrMixtureData`

- **`$.PureOrMixtureData`** is a JSON array.
- **Total blocks in this paper:** 1 (i.e., the array has a single element at index `[0]`).

### First Block Preview (`PureOrMixtureData[0]`, truncated at 500 chars)

The block is a JSON object containing at least:

| Key | Content (from preview) |
|---|---|
| `sContributor` | `"JCE"` |
| `Variable` | Array of variable objects. Each has `nVarNumber` (integer), `VariableID` (with `VariableType`), and `VarPhaseID`. |

**Variables visible in preview:**
- `nVarNumber: 1` → `eTemperature`: "Temperature, K", phase = "Fluid (supercritical or subcritical phases)"
- `nVarNumber: 2` (partially visible) → `ePressure`: "Pressure, kPa"

### Key Structural Insight

`block_number` in the `raw.blocks` index maps directly to the **zero-based JSON array index** of `$.PureOrMixtureData`. For this paper with 1 block, `block_number = 0` corresponds to `$.PureOrMixtureData[0]`.

## 4. execute_sql

## Compacted Result

**Task:** Confirm whether `block_number` is 0-based or 1-based in the index tables.

For DOI `10.1016/j.fluid.2006.05.007`, only **one block** exists:

| block_number | block_type | n_components | n_datapoints |
|---|---|---|---|
| 1 | PureOrMixtureData | 2 | 45 |

**Conclusion:** `block_number` is **1-based** (the single block is numbered 1, not 0).

## 5. execute_sql

## Compacted Result

### NumValues Data Point Structure (DOI: 10.1016/j.fluid.2006.05.007)

The first data point (`NumValues[0]`) from `PureOrMixtureData[0]` has two top-level keys:

#### `VariableValue` (array of objects)
Each element contains:
| Key | Description |
|---|---|
| `nVarNumber` | References the variable definition (1, 2, 3…) |
| `nVarValue` | The numeric value |
| `nVarDigits` | Significant digits |

Example entries:

| nVarNumber | nVarValue | nVarDigits |
|---|---|---|
| 1 | 572.91 | 5 |
| 2 | 10085 | 5 |
| 3 | 0.3044 | 4 |

#### `PropertyValue` (array of objects)
Each element contains:
| Key | Description |
|---|---|
| `nPropNumber` | References the property definition |
| `nPropValue` | The numeric value |
| `nPropDigits` | Significant digits |
| `CombinedUncertainty.nCombExpandUncertValue` | Expanded uncertainty |

Example entry: `nPropNumber` = 1, `nPropValue` = 77.4, uncertainty = 1.6

### Correct JSON Paths for Extraction

- **Property value:** `$.PureOrMixtureData[N].NumValues[M].PropertyValue[P].nPropValue`
- **Property number:** `$.PureOrMixtureData[N].NumValues[M].PropertyValue[P].nPropNumber`
- **Variable value:** `$.PureOrMixtureData[N].NumValues[M].VariableValue[V].nVarValue`
- **Variable number:** `$.PureOrMixtureData[N].NumValues[M].VariableValue[V].nVarNumber`

The `nPropNumber` and `nVarNumber` link back to the property/variable definitions in the block (from `block_properties.prop_number` and `block_variables.var_number`) to identify which value is density, temperature, pressure, or mole fraction.

## 6. execute_sql

## Compacted Result

**Source:** DOI `10.1016/j.fluid.2004.11.019`, block 2 — Mass density (kg/m³) of ethanol + water at T = 298.15 K.

### Variable key
| Var # | Meaning |
|-------|---------|
| 1 | Temperature (K) — all rows = **298.15** |
| 2 | Pressure (kPa) — values: 100, 10 000, 20 000, 30 000 |
| 3 | Mole fraction of ethanol (x_ethanol) |

### Data points nearest x_ethanol ≈ 0.5 (target condition)

| Pressure (kPa) | x_ethanol | Density (kg/m³) |
|-----------------|-----------|-----------------|
| **100** (≈ 1 atm) | **0.4501** | **868.8** |
| **100** | **0.498** | **859.3** |
| **100** | **0.5501** | **849.5** |
| 10 000 | 0.4501 | 874.7 |
| 10 000 | 0.498 | 865.4 |
| 10 000 | 0.5501 | 855.8 |
| 20 000 | 0.4501 | 880.4 |
| 20 000 | 0.498 | 871.3 |
| 20 000 | 0.5501 | 861.9 |
| 30 000 | 0.4501 | (not in returned rows) |

> **Key value for the question (atmospheric pressure, x ≈ 0.5):**  
> At 100 kPa and x_ethanol = 0.498, density = **859.3 kg/m³**  
> Bracketing values: 868.8 kg/m³ (x = 0.4501) and 849.5 kg/m³ (x = 0.5501).

### What was omitted
- 200 rows were returned (not truncated). All are at T = 298.15 K across four pressures (100, 10 000, 20 000, 30 000 kPa) and x_ethanol from 0.003 to 1.0.
- Rows far from x_ethanol ≈ 0.5 (x < 0.4 or x > 0.6) and high-pressure rows (20 000 & 30 000 kPa full series) were removed for brevity, as they are not relevant to the atmospheric-pressure, equimolar target. The full atmospheric-pressure (100 kPa) composition sweep is available in the raw data if needed.

## 7. execute_sql

## Cross-validation results: Ethanol + Water density at T ≈ 298.15 K, x_ethanol ≈ 0.5

**Source:** `10.1016/j.fluid.2010.01.002` (the only additional paper returned)

| Block | Variable 1 (T, K) | Variable 2 (x or other comp.) | Density (kg/m³) | Notes |
|------:|-------------------:|------------------------------:|----------------:|-------|
| 19 | 298.15 | 0.5756 | 1024.98 | Likely mass-fraction or different composition variable; density too high for equimolar ethanol+water |
| **20** | **298.15** | **0.4965** | **823.95** | Closest to x = 0.5; plausible ethanol-rich mixture density |
| 20 | 298.15 | 0.5976 | 831.00 | |
| 21 | 298.15 | 0.5442 | 817.80 | |
| 22 | 298.15 | 0.5216 | 1120.20 | Density too high for ethanol+water; likely a different composition basis or different mixture block |

### Key observations

- **5 rows returned; no truncation.** All from a single paper. The excluded DOI (`10.1016/j.fluid.2004.11.019`) was the primary source.
- The variable numbers (1 = temperature, 2 = composition) are not explicitly labelled as mole fraction vs. mass fraction in the query output, so the composition basis varies across blocks.
- **Block 20, x₂ = 0.4965** gives **823.95 kg/m³** — this is the closest match to equimolar ethanol+water but is **~35 kg/m³ lower** than the ~859 kg/m³ target value. This discrepancy may reflect a different composition variable (e.g., mole fraction vs. mass fraction: x_ethanol = 0.5 by mole fraction ≈ 0.39 by mass fraction, yielding different densities).
- Blocks 19 and 22 report densities (1025, 1120 kg/m³) inconsistent with ethanol+water at equimolar composition, suggesting those blocks may use mass fraction or involve a different component ordering.

**Bottom line:** The query found limited additional data. The most relevant point (block 20, composition 0.4965) yields **823.95 kg/m³**, which does not directly confirm ~859 kg/m³. The discrepancy likely stems from ambiguity in whether "0.5" refers to mole fraction or mass fraction across different datasets.

## 8. execute_sql

## Compacted Result

**DOI:** 10.1016/j.fluid.2010.01.002 — Blocks 19–22, variable definitions

| block_number | var_number | var_type |
|---|---|---|
| 19 | 1 | Temperature, K |
| 19 | 2 | Molality, mol/kg |
| 20 | 1 | Temperature, K |
| 20 | 2 | Molality, mol/kg |
| 21 | 1 | Temperature, K |
| 21 | 2 | Molality, mol/kg |
| 22 | 1 | Temperature, K |
| 22 | 2 | Molality, mol/kg |

### Key finding for tasks

1. **Composition variable:** All four blocks use **molality (mol/kg)** — *neither* mole fraction nor mass fraction. This means the composition is expressed as moles of solute per kilogram of solvent, which is distinct from the equimolar (mole-fraction-based) mixture the user is asking about.
2. **Discrepancy implication:** Because these blocks use molality rather than mole fraction, any density values extracted from them cannot be directly compared to a mole-fraction = 0.5 mixture without conversion. This may explain or contribute to discrepancies between density values from different sources/blocks.

No rows were omitted; all 8 rows are shown.

## 9. execute_sql

## Compacted Result

**Source:** `10.1016/j.fluid.2004.11.019`, block 2 — 3 variables defined (no truncation).

| var_number | var_type |
|---|---|
| 1 | Temperature, K |
| 2 | Pressure, kPa |
| 3 | **Mole fraction** |

### Task 1 — Confirmed
Variable 3 in block 2 is **Mole fraction**. (The `block_variables` table does not specify which component, but in ThermoML convention for a binary mixture the mole fraction variable typically refers to the first non-solvent component, i.e., ethanol.)

### Task 2
This query only returns variable definitions; it does not contain any numerical density or composition data points. The association of ~859 kg/m³ with x_ethanol = 0.498 **cannot be validated from this result alone** — a separate query against the datapoint values (in `raw.papers.json_data`) would be needed.

## 10. execute_sql

## Compacted Result

### Task: Find independent density values at T = 298.15 K, x_ethanol ≈ 0.5 (mole fraction) to cross-validate ~859 kg/m³

### Result: **Zero rows returned.**

The query searched 15 candidate blocks (from papers other than `10.1016/j.fluid.2004.11.019`) for datapoints matching:
- `Mass density, kg/m3`
- `Mole fraction` variable
- T = 298.15 K
- x_ethanol ≈ 0.49–0.50

No matching datapoints were found. Possible reasons:
- The 15-block `LIMIT` in the CTE may have excluded relevant papers (blocks were not filtered by composition value before limiting).
- Matching papers may use slightly different mole-fraction values (e.g., 0.4999, 0.501) not caught by the `LIKE` patterns.
- Some sources may record composition as a constraint rather than a variable, bypassing the `block_variables` join.

**No additional independent sources were found to cross-validate the ~859 kg/m³ value from this query.**

## 11. execute_sql

## Compacted Result

### Papers/blocks with ethanol+water density data (mole fraction, 2-component mixtures)

30 rows returned (not truncated). The previously used DOI `10.1016/j.fluid.2004.11.019` was excluded.

| DOI | Block(s) | prop_number |
|-----|----------|-------------|
| `10.1016/j.fluid.2006.05.007` | 1 | 1 |
| `10.1016/j.fluid.2009.07.010` | 14, 16, 18, 20, 22, 24, 26 | 1 |
| `10.1016/j.fluid.2010.01.020` | 26 | 1 |
| `10.1016/j.fluid.2010.07.005` | 8, 13, 18 | 1 |
| `10.1016/j.fluid.2010.10.005` | 1 | 1 |
| `10.1016/j.fluid.2014.05.032` | 1 | 1 |
| `10.1016/j.fluid.2014.07.004` | 8, 10, 12 | 1 |
| `10.1016/j.fluid.2014.10.044` | 7 | 1 |
| `10.1016/j.fluid.2014.11.009` | 6, 8 | 1 |
| `10.1016/j.fluid.2015.07.012` | 1, 3, 5 | 1 |
| `10.1016/j.fluid.2017.09.005` | 1, 3, 5 | 1 |
| `10.1016/j.fluid.2017.10.034` | 3, 4, 5, 6 | 1 |

**Summary:** 12 distinct DOIs across 30 doi/block combinations are available as cross-validation candidates. All have `prop_name = 'Mass density, kg/m3'` with `Mole fraction` as a variable. Multiple blocks per DOI likely correspond to different temperatures or pressures. The `n` column (count) was 1 for every row and was collapsed.

## 12. execute_sql

## Compacted Result

### Key Observation

**None of these four papers contain data at the target conditions (T ≈ 298.15 K, x_ethanol ≈ 0.5, atmospheric pressure).** Therefore, direct cross-validation of the ~859 kg/m³ value is not possible from this query.

### Why the data doesn't match

| DOI | Variable encoding | Conditions covered | Issue |
|---|---|---|---|
| `10.1016/j.fluid.2010.10.005` | var1 = Pressure (kPa, 20000–35000), var2 = mole fraction | x_ethanol up to 0.95, but **P = 20–35 MPa** (high pressure), **no temperature variable visible** | Not atmospheric pressure |
| `10.1016/j.fluid.2014.05.032` | var1 = Pressure (kPa, 2490–40140), var2 = Temperature (K), var3 = mole fraction | T includes ~297–298 K, but **x_ethanol only 0.0163, 0.0343, 0.073, 0.0946** | Mole fractions far too low (≤0.095) |
| `10.1016/j.fluid.2015.07.012` | var1 = Temperature (K, 350.7–476.2), var2 = Pressure (kPa, 10000–40000), var3 = mole fraction | x_ethanol includes 0.4 and 0.6, but **T ≥ 350.7 K** and **P ≥ 10 MPa** | Temperature and pressure far from target |
| `10.1016/j.fluid.2017.09.005` | var1 = Temperature (K, 523.2–618.2), var2 = Pressure (kPa, 20000–40000), var3 = mole fraction | x_ethanol includes 0.4 and 0.6, but **T ≥ 523 K** and **P ≥ 20 MPa** | Temperature and pressure far from target |

### Nearest (but still distant) datapoints to target conditions

The closest data to T ~ 298 K, x ~ 0.5, P ~ 101 kPa comes from **`10.1016/j.fluid.2014.05.032`**, but only at very low ethanol mole fractions:

| T (K) | P (kPa) | x_ethanol | Density (kg/m³) |
|---|---|---|---|
| 298.15 | 2560 | 0.0946 | 965.8 |
| 298.35 | 2590 | 0.0343 | 984.1 |
| 297.05 | 2490 | 0.0163 | 990.8 |

These are at the lowest available pressure (~2.5 MPa, still 25× atmospheric) and at x_ethanol ≤ 0.095 — not useful for validating density at x = 0.5.

### Conclusion

The 500 rows returned (not truncated) span all four DOIs but **no datapoint exists near (298.15 K, 101.325 kPa, x_ethanol = 0.5)**. The ~859 kg/m³ value cannot be cross-validated from these papers. A different set of papers or a broader DOI search is needed.

## 13. execute_sql

## Compacted Result

### Overview
56 rows returned (no truncation) from 4 DOIs at T ≈ 298.15 K. All data are at 298.15 K (or 298.2 K). Variable columns are `1: Temperature (K); 2: Mole fraction`.

### Key finding: No data near x_ethanol = 0.5

**None of these papers contain an ethanol + water data point near x_ethanol = 0.5.** The variable "2" (mole fraction) in these results refers to a **solute or non-ethanol/water component** — the densities are far too high (1000–1460 kg/m³) to be ethanol–water binary mixtures, or far too low (~788–805 kg/m³) to correspond to x_ethanol ≈ 0.5. These appear to be **ternary or salt-containing systems** where ethanol and water are co-solvents and variable 2 tracks a third component's mole fraction.

### Cannot cross-validate ~859 kg/m³

No data point in this result set is close to 859 kg/m³ at a composition interpretable as equimolar ethanol + water.

### Data summary by DOI

| DOI | Blocks | T (K) | x₂ range | Density range (kg/m³) | Likely system |
|-----|--------|--------|-----------|----------------------|---------------|
| 10.1016/j.fluid.2010.01.020 | 26 | 298.15 | 0–1 | 997–1117 | Solute in ethanol+water (densities > water) |
| 10.1016/j.fluid.2010.07.005 | 8, 13, 18 | 298.15 | 0.20–1 | 1001–1259 | Ionic liquid / salt in ethanol+water |
| 10.1016/j.fluid.2014.11.009 | 6, 8 | 298.2 | 0.02–0.21 | 1009–1120 | Solute in ethanol+water |
| 10.1016/j.fluid.2017.10.034 | 3–6 | 298.15 | 0.001–0.069 | 788–1461 | Multiple solutes in ethanol+water |

### Conclusion for tasks
1. **Density values at T~298 K**: Found 56 data points, but none represent the simple ethanol + water binary at x_ethanol = 0.5.
2. **Data near x_ethanol = 0.5 at atmospheric pressure**: **None found.** The mole-fraction variable tracks a third component, not ethanol.
3. **Cross-validation of ~859 kg/m³**: **Not possible** from this query result — no applicable data point exists.

## 14. execute_sql

## Compacted Result

**DOI:** 10.1016/j.fluid.2009.07.010 — Blocks 14, 16, 18, 20, 22, 24, 26

All 7 blocks are **binary mixtures** (n_components = 2) with a single variable: **Mole fraction** (var_number 1).

| Block | component_org_nums | Variable |
|-------|-------------------|----------|
| 14 | [6, 1] | Mole fraction |
| 16 | [6, 2] | Mole fraction |
| 18 | [6, 3] | Mole fraction |
| 20 | [5, 1] | Mole fraction |
| 22 | [5, 2] | Mole fraction |
| 24 | [5, 3] | Mole fraction |
| 26 | [5, 4] | Mole fraction |

### Key observations

1. **No Temperature variable** is present in any of these blocks (only one variable per block, and it is "Mole fraction"). Temperature may instead appear as a **constraint** (fixed value), but that is not captured in `block_variables`.
2. **None of these blocks pair ethanol + water directly** — the component org_nums involve compounds 1–6 in various binary pairings. To determine if any pairing is ethanol + water, the identities of org_nums 1–6 in the `compounds` table for this DOI must be checked.
3. No rows were omitted; all 7 returned rows are shown.

## 15. execute_sql

## Compound Identities for DOI 10.1016/j.fluid.2009.07.010

| org_num | common_name | formula |
|---------|-------------|---------|
| 5 | ethanol | C₂H₆O |
| 6 | water | H₂O |

**Task 1 — Ethanol and water org_nums:** ethanol = **5**, water = **6**.

**Task 2 — Ethanol+water binary blocks:** This query only returned compound identities, not block information. A separate query against `raw.blocks` filtering on `component_org_nums` containing both org_nums 5 and 6 is needed to determine which blocks (if any) represent the ethanol+water binary.

**Note:** The paper also contains 4 ionic-liquid compounds (org_nums 1–4), which are not relevant to the ethanol+water question. No CAS registry numbers were recorded for any compound in this DOI.

## 16. execute_sql

## Compacted Result

### Overview
30 rows returned (not truncated). These are ethanol+water binary mixture blocks containing "Mass density, kg/m3" with ≥1 constraint and ≤2 variables. The query did **not** directly filter for temperature constrained at 298.15 K — it only required ≥1 constraint exists. The constraint type/value must be checked in the JSON data to confirm T = 298.15 K.

---

### Task 1: Blocks where temperature might be a constraint (T not listed as a variable)

Blocks where **"Temperature, K" does NOT appear as a variable** — meaning temperature is likely held as a constraint:

| doi | block | n_vars | n_constraints | n_datapoints | variable(s) |
|-----|-------|--------|---------------|-------------|-------------|
| 10.1016/j.jct.2009.01.010 | 27 | 1 | 2 | 16 | Mole fraction |
| 10.1016/j.jct.2011.07.008 | 15 | 1 | 2 | 11 | Molality, mol/kg |
| 10.1016/j.jct.2011.07.008 | 16 | 1 | 2 | 12 | Molality, mol/kg |

These are the strongest candidates for fixed-temperature blocks. The actual constraint value (298.15 K) must be verified from `raw.papers.json_data`.

---

### Task 2: Blocks with mole fraction as the **only** variable

| doi | block | n_vars | n_constraints | n_datapoints |
|-----|-------|--------|---------------|-------------|
| **10.1016/j.jct.2009.01.010** | **27** | **1** | **2** | **16** |

This is the **only** block with `n_variables = 1` and `var_type = "Mole fraction"`. It has 2 constraints (likely T and P fixed) and 16 datapoints — a promising candidate for composition-dependent density at fixed T and P.

---

### Remaining blocks (temperature is a variable — less relevant)

These blocks have Temperature as a variable (not a constraint), so temperature varies across datapoints. They would need filtering to extract the 298.15 K subset:

| doi | block | n_vars | n_datapoints | variables |
|-----|-------|--------|-------------|-----------|
| 10.1016/j.fluid.2006.12.005 | 3 | 1 | 8 | Temperature |
| 10.1016/j.fluid.2006.12.005 | 4 | 1 | 2 | Temperature |
| 10.1016/j.fluid.2010.10.005 | 1 | 2 | 34 | Pressure, Mole fraction |
| 10.1016/j.fluid.2012.05.007 | 6 | 2 | 4 | Temperature, Mass fraction |
| 10.1016/j.fluid.2014.11.009 | 6 | 2 | 18 | Temperature, Mole fraction |
| 10.1016/j.fluid.2015.06.034 | 11 | 1 | 4 | Temperature |
| 10.1016/j.fluid.2017.09.019 | 6 | 2 | 9 | Temperature, Mass fraction |
| 10.1016/j.fluid.2018.01.030 | 3 | 2 | 12 | Temperature, Mass fraction |
| 10.1016/j.jct.2004.11.016 | 6 | 2 | 188 | Mole fraction, Temperature |
| 10.1016/j.jct.2006.08.002 | 2 | 1 | 19 | Temperature |
| 10.1016/j.jct.2006.08.002 | 3 | 1 | 4 | Temperature |
| 10.1016/j.jct.2007.05.004 | 10 | 2 | 39 | Temperature, Mole fraction |
| 10.1016/j.jct.2008.01.007 | 6 | 2 | 90 | Temperature, Mole fraction |
| 10.1016/j.jct.2011.10.009 | 3 | 2 | 70 | Temperature, Mole fraction |
| 10.1016/j.jct.2012.08.023 | 11 | 2 | 24 | Temperature, Molality |
| 10.1016/j.jct.2012.10.027 | 5 | 2 | 38 | Temperature, Molality |

## 17. execute_sql

## Compacted Result

**204 rows returned (not truncated).** Variables: `1` = mole fraction of ethanol (x₁), `2` = temperature (K). Density values are in kg/m³.

---

### Source 1: 10.1016/j.jct.2009.01.010 — Block 27

This block has **no temperature variable** (constrained, presumably at a fixed T). All 16 datapoints:

| x₁ (ethanol) | Density (kg/m³) |
|---|---|
| 0 | 999.704 |
| 0.013 | 1002.42 |
| 0.026 | 1008.21 |
| 0.051 | 1017.19 |
| 0.064 | 1021.22 |
| 0.074 | 1023.92 |
| 0.101 | 1029.24 |
| 0.15 | 1034.64 |
| 0.187 | 1035.66 |
| 0.305 | 1034.80 |
| 0.401 | 1031.91 |
| **0.506** | **1028.25** |
| 0.646 | 1024.01 |
| 0.766 | 1021.27 |
| 0.895 | 1018.65 |
| 1 | 1016.95 |

> **Note:** Densities here (≈1000–1036 kg/m³) are far too high for ethanol+water at 25 °C. This block likely involves a different mixture or property (possibly an ionic-liquid system). The value at x₁≈0.5 is **1028.25**, not ~859. **This source does not validate the ~859 kg/m³ target.**

---

### Source 2: 10.1016/j.jct.2004.11.016 — Block 6

188 datapoints across 13 mole fractions × up to 15 temperatures (293.15–363.15 K).

#### Key data at T = 298.15 K (all compositions)

| x₁ (ethanol) | Density (kg/m³) |
|---|---|
| 0 | 997.043 |
| 0.0121 | 995.282 |
| 0.0218 | 993.748 |
| 0.0252 | 993.401 |
| 0.0359 | 992.240 |
| 0.0617 | 989.740 |
| 0.1009 | 985.747 |
| 0.2017 | 969.911 |
| 0.3033 | 952.768 |
| 0.4051 | 936.991 |
| **0.5077** | **923.722** |
| 0.6099 | 912.410 |
| 0.7652 | 898.903 |
| 0.895 | 889.991 |
| 1 | 883.578 |

> **At x₁ ≈ 0.5 and 298.15 K, density = 923.722 kg/m³.** This is significantly higher than the ~859 kg/m³ target value. The ~859 value is not matched at x₁≈0.5; it appears instead near x₁≈0.6099 at T≈358.15 K (858.928 kg/m³) or x₁≈0.7652 at T≈343.15 K (859.582 kg/m³).

#### Bracketing compositions around x₁ = 0.5 at all temperatures

| T (K) | x₁ = 0.4051 | x₁ = 0.5077 | x₁ = 0.6099 |
|---|---|---|---|
| 293.15 | 941.071 | 927.808 | 916.510 |
| **298.15** | **936.991** | **923.722** | **912.410** |
| 303.15 | 932.844 | 919.567 | 908.259 |
| 308.15 | 928.641 | 915.367 | 904.055 |
| 313.15 | 924.379 | 911.114 | 899.803 |
| 318.15 | 920.062 | 906.806 | 895.501 |

**Omitted:** 120 rows for compositions far from x₁=0.5 at temperatures other than 298.15 K (irrelevant to the primary task). All values are preserved above for the relevant compositions and temperatures.

---

### Cross-validation summary

The ~859 kg/m³ value is **not confirmed** at x₁ = 0.5, T = 298.15 K from either source. Source 2 gives **923.7 kg/m³** at the closest composition (x₁ = 0.5077) and 298.15 K.

## 18. execute_sql

## Compacted Result

### Task 1: Compound identities

| org_num | common_name | formula | cas_rn |
|---------|-------------|---------|--------|
| 1 | water | H₂O | null |
| 2 | ethanol | C₂H₆O | null |

### Task 2: Mole-fraction component in block 2

Block 2 (`PureOrMixtureData`) has `component_org_nums = [2, 1]`, meaning the components are listed with **ethanol (org_num 2) first, water (org_num 1) second**. By ThermoML convention, the mole-fraction variable in this block refers to the **first listed component — ethanol (org_num 2)**.

## 19. execute_sql

## Compacted Result

### Variable definitions in Block 2 of 10.1016/j.fluid.2004.11.019

| Var # | Type | Phase | Component (nOrgNum) |
|-------|------|-------|---------------------|
| 1 | Temperature, K | Liquid | — |
| 2 | Pressure, kPa | Liquid | — |
| 3 | **Mole fraction** | Liquid | **nOrgNum = 2** |

### Key finding

The mole fraction variable (var 3) explicitly references **component with `nOrgNum = 2`**. Per the compound table for this DOI, `nOrgNum = 2` corresponds to **water** (not ethanol). Therefore, the mole fraction values in this block are **mole fractions of water**.

## 20. execute_sql

## Compound Identities for DOI 10.1016/j.fluid.2004.11.019

| nOrgNum | Common Name | Formula | InChIKey |
|---------|-------------|---------|----------|
| **1** | **water** | H₂O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |
| **2** | **ethanol** (ethyl alcohol) | C₂H₆O | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |

### Key findings

1. **nOrgNum 1 = water; nOrgNum 2 = ethanol.** This is confirmed directly from the raw JSON `Compound` array in the paper's ThermoML record.
2. **Mole fraction variable interpretation:** Since ThermoML convention assigns the mole-fraction variable to a specific `nOrgNum`, any mole fraction referencing **nOrgNum 2** corresponds to **ethanol**, and any referencing **nOrgNum 1** corresponds to **water**. (The block-level variable metadata would specify which `nOrgNum` the mole fraction belongs to.)

### Additional details (purity)
- **Water:** 99.9% (estimated by compiler), commercial source.
- **Ethanol:** 99.8% (stated by supplier; confirmed by Karl Fischer titration after molecular sieve treatment), commercial source.

## 21. execute_sql

## Compacted Result for Block 6 of DOI 10.1016/j.jct.2004.11.016

### Compound Identities

| org_num | Common Name | Formula | InChIKey |
|---------|-------------|---------|----------|
| **1** | 2-(N,N-dimethylamino)ethanol (DMAE) | C₄H₁₁NO | UEEJHVSXFDXPFK-UHFFFAOYSA-N |
| **2** | water | H₂O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |

### Variable Definitions (Block 6)

| var_number | Type | Component (org_num) | Phase |
|------------|------|---------------------|-------|
| 1 | **Mole fraction** | **org_num = 1** (DMAE) | Liquid |
| 2 | Temperature, K | — | Liquid |

### Key Finding

**The mole fraction variable in block 6 refers to org_num 1, which is 2-(N,N-dimethylamino)ethanol (DMAE) — not ethanol or water.**

This paper does **not** involve ethanol; its two components are DMAE (C₄H₁₁NO) and water. Therefore, any mole-fraction value (e.g., x = 0.5077) in this block refers to the DMAE mole fraction, not ethanol.

> **Note:** This DOI is not relevant to an ethanol + water mixture density query.

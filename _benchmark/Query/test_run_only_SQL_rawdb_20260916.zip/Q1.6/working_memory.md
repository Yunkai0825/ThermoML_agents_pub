# Q1.6 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Compacted Result

### Task 2: Confirm CAS RN and formula for water

| Field | Value |
|---|---|
| **common_name** | water |
| **formula** | H2O |
| **cas_rn** | NULL (not populated in these rows) |
| **standard_inchi_key** | XLYOFNOQVPJJNP-UHFFFAOYSA-N |

All 50 returned rows share these identifiers consistently.

### Task 1: DOIs and org_nums associated with water

50 rows returned (query limit reached — there are likely many more in the database). The `org_num` varies by paper. Sample DOI/org_num pairs:

| doi | org_num |
|---|---|
| 10.1007/s10765-005-5567-5 | 2 |
| 10.1007/s10765-005-8587-2 | 1 |
| 10.1007/s10765-005-8590-7 | 2 |
| 10.1007/s10765-006-0044-3 | 2 |
| 10.1007/s10765-006-0096-4 | 3 |
| 10.1007/s10765-007-0220-0 | 2 |
| 10.1007/s10765-008-0514-x | 6 |
| 10.1007/s10765-009-0566-6 | 2 |
| 10.1007/s10765-009-0567-5 | 3 |
| 10.1007/s10765-009-0602-6 | 2 |
| 10.1007/s10765-009-0651-x | 2 |
| 10.1007/s10765-010-0714-z | 2 |
| 10.1007/s10765-010-0725-9 | 1 |
| 10.1007/s10765-010-0736-6 | 1 |
| 10.1007/s10765-010-0742-8 | 6 |
| 10.1007/s10765-010-0792-y | 1 |
| 10.1007/s10765-010-0862-1 | 2 |
| 10.1007/s10765-010-0887-5 | 8 |
| 10.1007/s10765-010-0904-8 | 3 |
| 10.1007/s10765-011-0996-9 | 7 |
| 10.1007/s10765-011-1060-5 | 2 |
| 10.1007/s10765-011-1065-0 | 2 |
| 10.1007/s10765-011-1086-8 | 5 |
| 10.1007/s10765-011-1100-1 | 3 |
| 10.1007/s10765-011-1111-y | 6 |
| 10.1007/s10765-011-1128-2 | 1 |
| 10.1007/s10765-012-1261-6 | 1 |
| 10.1007/s10765-013-1432-0 | 2 |
| 10.1007/s10765-014-1598-0 | 2 |
| 10.1007/s10765-015-2006-0 | 5 |
| 10.1007/s10765-015-2009-x | 4 |
| 10.1007/s10765-015-2016-y | 2 |
| 10.1007/s10765-016-2089-2 | 2 |
| 10.1007/s10765-016-2103-8 | 6 |
| 10.1007/s10765-017-2310-y | 2 |
| 10.1007/s10765-017-2323-6 | 3 |
| 10.1007/s10765-018-2359-2 | 1 |
| 10.1007/s10765-019-2558-5 | 2 |
| 10.1016/j.fluid.2004.07.017 | 4 |
| 10.1016/j.fluid.2004.07.019 | 3 |
| 10.1016/j.fluid.2004.10.018 | 3 |
| 10.1016/j.fluid.2004.10.028 | 1 |
| 10.1016/j.fluid.2004.10.029 | 1 |
| 10.1016/j.fluid.2004.11.010 | 5 |
| 10.1016/j.fluid.2004.11.014 | 3 |
| 10.1016/j.fluid.2004.11.019 | 1 |
| 10.1016/j.fluid.2004.11.025 | 1 |
| 10.1016/j.fluid.2004.12.004 | 8 |
| 10.1016/j.fluid.2004.12.016 | 2 |
| 10.1016/j.fluid.2005.01.002 | 4 |

**Note:** The LIMIT 50 cap was reached; the full database likely contains many more water entries. The `org_num` for water is **not fixed** — it varies per paper depending on compound ordering. Subsequent queries for heat-capacity data should join on both `doi` and `org_num`.

## 2. execute_sql

## Compacted Result

### Task: Identify DOIs and block numbers with isobaric heat capacity measurements for pure substances

**The query returned zero rows.**

No blocks matching the filter (`prop_name LIKE '%heat capacity%'` AND `lower(prop_name) LIKE '%isobaric%'` with `n_components = 1`) were found in the database.

This means either:
- The property name for isobaric heat capacity is stored differently in the database (e.g., "Molar heat capacity at constant pressure", "Cp", or another variant), or
- No pure-component isobaric heat capacity data exists in this dataset.

A follow-up query exploring distinct `prop_name` values containing "heat" or "capacity" or "Cp" would help clarify the naming convention used.

## 3. execute_sql

## Compacted Result

**Task:** Identify the exact `prop_name` string for isobaric heat capacity in the database.

The query returned **7 distinct heat-capacity-related property names**:

| prop_name |
|---|
| Apparent molar heat capacity, J/K/mol |
| Excess molar heat capacity, J/K/mol |
| Heat capacity at constant pressure per volume, J/K/m3 |
| **Molar heat capacity at constant pressure, J/K/mol** |
| Molar heat capacity at constant volume, J/K/mol |
| Molar heat capacity at saturation pressure, J/K/mol |
| **Specific heat capacity at constant pressure, J/K/kg** |

**Key finding:** The isobaric (constant-pressure) heat capacity of pure liquid water is most directly matched by:
- `"Molar heat capacity at constant pressure, J/K/mol"` (molar Cp)
- `"Specific heat capacity at constant pressure, J/K/kg"` (mass-specific Cp)

## 4. execute_sql

## Compacted SQL Result

### Task 1: Find DOIs and block numbers with Cp data for pure water
**Zero rows returned.** The query found no blocks matching pure water (InChIKey `XLYOFNOQVPJJNP-UHFFFAOYSA-N`) with either of the two property names searched.

### Task 2: Identify which property name (molar vs specific) is available
**Neither property name was found** for pure water in the database:
- `Molar heat capacity at constant pressure, J/K/mol` — no matches
- `Specific heat capacity at constant pressure, J/K/kg` — no matches

### Notes
- The query completed without error (0.36 s) and was not truncated; there are genuinely no matching records.
- Possible reasons: the database may not contain pure-water Cp data, the property name strings may differ from those searched, or the compound-to-block join condition (`component_org_nums = CAST(org_num AS TEXT)`) may not match multi-digit or comma-separated values. A broader exploratory query (e.g., listing all distinct `prop_name` values for water blocks, or all property names containing "heat capacity") could help diagnose the gap.

## 5. execute_sql

## Compacted Result

### Key Findings

**Task 1: Pure-component Cp blocks in papers that also contain water**

The query found **50 rows** (limit reached) of single-component (`n_components=1`) Cp blocks from papers that also list water (InChIKey `XLYOFNOQVPJJNP-UHFFFAOYSA-N`). All are `PureOrMixtureData` blocks with property `"Molar heat capacity at constant pressure, J/K/mol"`.

**Task 2: `component_org_nums` format vs water `org_num`**

- **Format:** `component_org_nums` is a JSON array string, e.g. `"[1]"`, `"[9]"`, `"[12]"`.
- **Critical mismatch:** The block's `component_org_nums` (the compound the block is *about*) almost never equals the water compound's `org_num` in the same paper. For example:

| doi | block | component_org_nums | water org_num | Match? |
|-----|-------|--------------------|---------------|--------|
| 10.1007/s10765-019-2558-5 | 1 | [2] | 2 | **Yes** |
| 10.1007/s10765-010-0887-5 | 2 | [9] | 8 | No |
| 10.1016/j.fluid.2006.03.015 | 1–30 | [1]–[12] | 8 | No (none = 8) |
| 10.1016/j.fluid.2010.03.010 | 1,5,8 | [1],[2],[3] | 4 | No |
| 10.1016/j.fluid.2010.07.005 | 1 | [2] | 1 | No |
| 10.1016/j.fluid.2013.06.041 | 2,4,6,8,10 | [1]–[5] | 6 | No |
| 10.1016/j.fluid.2013.08.005 | 1 | [3] | 3 | **Yes** |
| 10.1016/j.fluid.2013.08.007 | 2,3 | [1],[2] | 2 | Block 3 **Yes** |
| 10.1016/j.fluid.2013.12.017 | 1 | [1] | 5 | No |
| 10.1016/j.fluid.2014.03.017 | 1,2,3 | [1],[2],[3] | 3 | Block 3 **Yes** |
| 10.1016/j.fluid.2014.05.034 | 8 | [8] | 1 | No |
| 10.1016/j.fluid.2016.07.034 | 1 | [1] | 2 | No |

**Only 4 blocks** have `component_org_nums` matching the water `org_num` — meaning the block is actually *about* water:

| doi | block | component_org_nums | water org_num | n_datapoints |
|-----|-------|--------------------|---------------|--------------|
| 10.1007/s10765-019-2558-5 | 1 | [2] | 2 | 8 |
| 10.1016/j.fluid.2013.08.005 | 1 | [3] | 3 | 8 |
| 10.1016/j.fluid.2013.08.007 | 3 | [2] | 2 | 23 |
| 10.1016/j.fluid.2014.03.017 | 3 | [3] | 3 | 28 |

### Implication

The current JOIN finds papers containing water **and** any pure-component Cp block, but most blocks are for *other* compounds in the same paper. To isolate **pure water Cp** blocks, an additional filter is needed: the block's `component_org_nums` must contain the water compound's `org_num`, e.g.:

```
WHERE b.component_org_nums LIKE '%' || c.org_num || '%'
```

or parsed via JSON:  
```
json_each(b.component_org_nums) = c.org_num
```

The 4 candidate blocks above are the ones to extract actual Cp values from (via `json_data`) at 25 °C / 1 atm.

## 6. execute_sql

## Compacted Result

### Key Finding: All `prop_value` and `prop_unc` columns are NULL

The query successfully matched pure-water Cp blocks and extracted variable values (temperature or pressure), but **every `prop_value` (Cp) and `prop_unc` (uncertainty) is NULL** across all 200 rows. The `prop_num` is also NULL for every row. This means the JSON path used to extract property values did not retrieve actual Cp data — likely a structural mismatch in how `nPropValue`/`nPropNumber` are nested in the ThermoML JSON.

### Data Points Near 298.15 K (25 °C)

Only two DOIs have `var_value` at or very near 298.15 K, but Cp values are missing:

| doi | block_number | var_value (K) | prop_value | prop_unc |
|-----|-------------|---------------|------------|----------|
| 10.1016/j.fluid.2013.08.005 | 1 | 298.15 | NULL | NULL |
| 10.1016/j.fluid.2013.08.005 | 1 | 298.15 | NULL | NULL |
| 10.1016/j.fluid.2016.10.005 | 2 | 298.15 | NULL | NULL |

### Other DOIs Returned (no data at 298.15 K, all Cp values NULL)

| doi | block | Temperature range (var_value) | Notes |
|-----|-------|-------------------------------|-------|
| 10.1007/s10765-019-2558-5 | 1 | 308.15–343.15 K | 8 rows |
| 10.1016/j.fluid.2006.03.015 | 22 | 305.15–370.15 K | 14 rows |
| 10.1016/j.fluid.2013.08.007 | 3 | 100–40000 (likely pressure in kPa, not temp) | 23 rows |
| 10.1016/j.fluid.2014.03.017 | 3 | 294.2–353.26 K | 28 rows |
| 10.1016/j.fluid.2016.07.034 | 3 | 304.24–577.18 K | 34 rows |
| 10.1016/j.jct.2005.10.010 | 1 | 299.62–370.11 K | 15 rows |
| 10.1016/j.jct.2006.10.011 | 1 | 0.47–3.38 (likely pressure in MPa, not temp) | 63 rows |

### Units

The matched `prop_name` values (from the CTE) are:
- **Molar heat capacity at constant pressure, J/K/mol**
- **Specific heat capacity at constant pressure, J/K/kg**

### Summary

- **200 rows returned (not truncated), but no actual Cp values were extracted** — all `prop_value` and `prop_num` fields are NULL.
- The query structure likely needs adjustment: the property value may be stored at a different JSON path than `$.nPropValue` within the `NumValues` entries, or the property number linkage is not being resolved correctly.
- Two DOIs contain data points exactly at 298.15 K but still lack Cp values.

## 7. execute_sql

## Compacted Result

### NumValues JSON Structure (first entry from `PureOrMixtureData[0]`)

The entry contains two top-level arrays: **`VariableValue`** and **`PropertyValue`**.

#### VariableValue array
| Field | Value |
|---|---|
| `nVarNumber` | 1 |
| `nVarValue` | 298.15 |
| `nVarDigits` | 5 |

#### PropertyValue array
| Field | Value |
|---|---|
| `nPropNumber` | 1 |
| `nPropValue` | **75.368725408** |
| `nPropDigits` | 5 |
| `CombinedUncertainty.nCombExpandUncertValue` | 1.3061078 |
| `CombinedUncertainty.nCombUncertAssessNum` | 1 |

### Key JSON paths (Task 1 & 2)

- **Variable values (e.g., Temperature):**  
  `$.PureOrMixtureData[i].NumValues[j].VariableValue[k].nVarValue`
- **Property values (e.g., Cp):**  
  `$.PureOrMixtureData[i].NumValues[j].PropertyValue[k].nPropValue`
- **Uncertainty:**  
  `$.PureOrMixtureData[i].NumValues[j].PropertyValue[k].CombinedUncertainty.nCombExpandUncertValue`
- Variable/property entries are linked to their definitions via `nVarNumber` / `nPropNumber`.

## 8. execute_sql

## Cp of Pure Liquid Water at 298.15 K (25 °C) — Extracted Results

**8 rows returned; no truncation.**

All values are **Molar heat capacity at constant pressure (J·K⁻¹·mol⁻¹)**. No specific (J/K/kg) results were found.

| DOI | Cp (J·K⁻¹·mol⁻¹) | Uncertainty | Digits |
|---|---|---|---|
| 10.1016/j.fluid.2013.08.005 | 75.368725408 | 1.3061078 | 5 |
| 10.1016/j.fluid.2013.08.005 | 75.350710128 | 1.304306272 | 5 |
| 10.1016/j.fluid.2016.10.005 | 75.345305544 | 2.91847536 | 5 |
| 10.1016/j.jct.2008.10.002 | 75.3 | 1.2 | 3 |
| 10.1016/j.jct.2009.01.011 | 75.32188568 | 9.0977164 | 4 |
| 10.1016/j.jct.2016.09.031 | 75.11470996 | 1.506077408 | 5 |
| 10.1021/acs.jced.7b00483 | 75.664176 | 0.16213752 | 4 |
| 10.1021/acs.jced.8b01174 | 74.79944256 | 3.45893376 | 4 |

**Key observations:**

- **Temperature:** All measurements at exactly **298.15 K**.
- **Units:** All in **J·K⁻¹·mol⁻¹** (molar).
- **Uncertainties:** Combined expanded uncertainties range from ~0.16 to ~9.1 J·K⁻¹·mol⁻¹; the tightest value (0.162, DOI `10.1021/acs.jced.7b00483`) gives Cp ≈ 75.66.
- **Central tendency:** Most values cluster around **75.3–75.4 J·K⁻¹·mol⁻¹**.
- **6 distinct source DOIs** identified (one DOI contributes two data points).

## 9. execute_sql

## Compacted Result

### Variables defined for each pure-water Cp block

| DOI | Block | var_number | var_type |
|-----|-------|-----------|----------|
| 10.1016/j.fluid.2013.08.005 | 1 | 1 | Temperature, K |
| 10.1016/j.fluid.2016.10.005 | 2 | 1 | Temperature, K |
| 10.1016/j.jct.2008.10.002 | 1 | 1 | Temperature, K |
| 10.1016/j.jct.2009.01.011 | 1 | 1 | Temperature, K |
| 10.1016/j.jct.2016.09.031 | 1 | 1 | Temperature, K |
| 10.1016/j.jct.2016.09.031 | 1 | 2 | **Pressure, kPa** |
| 10.1021/acs.jced.7b00483 | 1 | 1 | Temperature, K |
| 10.1021/acs.jced.8b01174 | 1 | 1 | Temperature, K |

**8 rows returned; no truncation.**

### Key observations

1. **Variables defined:** 6 of the 7 blocks have only **Temperature (K)** as a variable. One block (`10.1016/j.jct.2016.09.031`) also has **Pressure (kPa)** as a variable.

2. **Atmospheric pressure:** For the 6 blocks with temperature as the sole variable, pressure is not varied — implying measurements were taken at a fixed (likely atmospheric) pressure. Whether that fixed pressure is explicitly recorded as a constraint would need to be checked via `raw.blocks.n_constraints` or the paper's JSON data. The one block that does include pressure as a variable (`jct.2016.09.031`) may span multiple pressures, so its atmospheric-pressure status depends on the actual data values.

## 10. execute_sql

## Compacted Result

**DOI:** 10.1016/j.jct.2016.09.031 — Block 0 (`PureOrMixtureData[0]`), datapoint at 298.15 K

| var_num | var_value | Meaning |
|---------|-----------|---------|
| 1 | 298.15 | Temperature (K) — matches 25 °C |
| 2 | 101.325 | Pressure (kPa) — exactly atmospheric pressure |

**Conclusion for both tasks:** The Cp measurement was made at **101.325 kPa** (standard atmospheric pressure), confirmed directly from the variable values at 298.15 K.

# Q1.2 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Compacted Result: Hexane + Ethanol Binary Mixture Blocks

**100 rows returned; not truncated.** All rows are `PureOrMixtureData` blocks with `n_components = 2`, confirming binary mixtures.

### Task 1 & 2: DOIs and block numbers

| DOI | Block numbers | component_org_nums (examples) |
|-----|--------------|-------------------------------|
| `10.1016/j.fluid.2005.04.021` | 1–17 (17 blocks) | [1,18] … [17,18] |
| `10.1016/j.fluid.2005.08.001` | 5–14 (10 blocks) | [1,4], [2,4], [4,3], [1,3], [2,3] |
| `10.1016/j.fluid.2005.08.006` | 8–13 (6 blocks) | [5,7], [6,7] |
| `10.1016/j.fluid.2005.10.024` | 4–6 (3 blocks) | [3,1], [2,3], [2,1] |
| `10.1016/j.fluid.2005.12.029` | 1–4 (4 blocks) | [2,4], [4,3] |
| `10.1016/j.fluid.2005.12.041` | 1–6 (6 blocks) | [1,4], [2,4], [3,4] |
| `10.1016/j.fluid.2006.04.016` | 7–11 (5 blocks) | [1,3], [1,5], [6,4], [2,1], [4,1] |
| `10.1016/j.fluid.2007.06.001` | 4–27 (24 blocks) | [5,3], [5,4], [6,2], [7,2], [8,2], [15,2], [17,3], [5,1], [12,1], [13,1], [5,2], [14,2], [16,2], [9,2], [10,2], [8,3], [15,3], [14,3], [12,3], [10,3], [11,3], [9,3] |
| `10.1016/j.fluid.2008.09.026` | 4–7 (4 blocks) | [3,2], [3,1] |
| `10.1016/j.fluid.2008.10.008` | 1–21 (21 blocks) | [1,20] … [11,20] |

**Summary:** 10 distinct DOIs, 100 binary-mixture blocks total. All confirmed as 2-component `PureOrMixtureData` blocks.

**Note:** These DOIs may contain multiple compounds (some papers have many org_nums), so not every block in a given DOI necessarily pairs *hexane* with *ethanol* — the query matched papers containing both compounds and filtered for 2-component blocks. The `component_org_nums` field would need to be cross-referenced with the `compounds` table to verify which specific pair each block represents. A follow-up query on `block_properties` is needed to identify which thermophysical properties were measured.

## 2. execute_sql

# Compacted SQL Result

## Status: Query exceeded 500-row limit — no data returned

The query returned more than 500 rows because it included `doi`, `block_number`, and `method_name` in the SELECT DISTINCT, producing too many unique combinations.

## Recommendations for follow-up queries

### Task 1 & 2 — Distinct property names with prop_group and presentation
Re-run with only the property-level columns (drop `doi`, `block_number`, `method_name`):

```sql
SELECT DISTINCT bp.prop_group, bp.prop_name, bp.presentation
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.compounds c1 ON c1.doi = b.doi
JOIN raw.compounds c2 ON c2.doi = b.doi
WHERE b.n_components = 2
  AND b.block_type = 'PureOrMixtureData'
  AND c1.org_num != c2.org_num
  AND (
    (LOWER(c1.common_name) = 'hexane' AND LOWER(c2.common_name) = 'ethanol')
    OR (LOWER(c2.common_name) = 'hexane' AND LOWER(c1.common_name) = 'ethanol')
  )
ORDER BY bp.prop_name
```

### Task 3 — DOIs and block numbers (with LIMIT or aggregation)
Either add `LIMIT 500` or aggregate DOI/block counts per property:

```sql
SELECT bp.prop_name, COUNT(DISTINCT bp.doi) AS n_dois,
       COUNT(DISTINCT bp.doi || '/' || bp.block_number) AS n_blocks
FROM raw.block_properties bp
JOIN raw.blocks b ON b.doi = bp.doi AND b.block_number = bp.block_number AND b.block_type = bp.block_type
JOIN raw.compounds c1 ON c1.doi = b.doi
JOIN raw.compounds c2 ON c2.doi = b.doi
WHERE b.n_components = 2
  AND b.block_type = 'PureOrMixtureData'
  AND c1.org_num != c2.org_num
  AND (
    (LOWER(c1.common_name) = 'hexane' AND LOWER(c2.common_name) = 'ethanol')
    OR (LOWER(c2.common_name) = 'hexane' AND LOWER(c1.common_name) = 'ethanol')
  )
GROUP BY bp.prop_name
ORDER BY bp.prop_name
```

## 3. execute_sql

## Distinct Thermophysical Properties for Hexane + Ethanol Binary Mixtures

**30 distinct property entries found (no truncation).**

| Property Group | Property Name | Presentation |
|---|---|---|
| **ActivityFugacityOsmoticProp** | (Relative) activity | Direct value, X |
| | Activity coefficient | Direct value, X |
| | Fugacity coefficient | Direct value, X |
| **CompositionAtPhaseEquilibrium** | Amount concentration (molarity), mol/dm³ | Direct value, X |
| | Eutectic composition: mole fraction | Direct value, X |
| | Henry's Law constant (mole fraction scale), kPa | Direct value, X |
| | Mass fraction | Direct value, X |
| | Molality, mol/kg | Direct value, X |
| | Mole fraction | Direct value, X |
| **Criticals** | Critical density, kg/m³ | Direct value, X |
| | Critical pressure, kPa | Direct value, X |
| | Critical temperature, K | Direct value, X |
| **ExcessPartialApparentEnergyProp** | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | Direct value, X |
| | Molar enthalpy of solution, kJ/mol | Difference with the reference state, X-X(REF) |
| **PhaseTransition** | Eutectic temperature, K | Direct value, X |
| | Liquid-liquid equilibrium temperature, K | Direct value, X |
| | Monotectic temperature, K | Direct value, X |
| | Quadruple (quintuple) point temperature, K | Direct value, X |
| | Solid-liquid equilibrium temperature, K | Direct value, X |
| **RefractionSurfaceTensionSoundSpeed** | Interfacial tension, N/m | Direct value, X |
| | Refractive index (Na D-line) | Direct value, X |
| | Speed of sound, m/s | Direct value, X |
| | Surface tension liquid-gas, N/m | Direct value, X |
| **TransportProp** | Binary diffusion coefficient, m²/s | Direct value, X |
| | Tracer diffusion coefficient, m²/s | Direct value, X |
| | Viscosity, Pa·s | Direct value, X |
| **VaporPBoilingTAzeotropTandP** | Boiling temperature at pressure P, K | Direct value, X |
| | Vapor or sublimation pressure, kPa | Direct value, X |
| **VolumetricProp** | Excess molar volume, m³/mol | Direct value, X |
| | Mass density, kg/m³ | Direct value, X |

**Notes:** All entries have presentation "Direct value, X" except *Molar enthalpy of solution*, which uses "Difference with the reference state, X-X(REF)." The query matched binary (`n_components = 2`) `PureOrMixtureData` blocks containing both hexane and ethanol.

## 4. execute_sql

## Hexane + Ethanol: Properties Measured (ThermoML)

**30 distinct properties** found across binary (2-component) hexane + ethanol mixture blocks.

| Property | Property Group | # DOIs | # Blocks |
|---|---|---:|---:|
| Activity coefficient | ActivityFugacityOsmoticProp | 110 | 6 943 |
| Mole fraction | CompositionAtPhaseEquilibrium | 52 | 496 |
| Mass density, kg/m³ | VolumetricProp | 12 | 110 |
| Molar enthalpy of solution, kJ/mol | ExcessPartialApparentEnergyProp | 2 | 244 |
| (Relative) activity | ActivityFugacityOsmoticProp | 4 | 111 |
| Solid-liquid equilibrium temperature, K | PhaseTransition | 7 | 103 |
| Fugacity coefficient | ActivityFugacityOsmoticProp | 1 | 49 |
| Liquid-liquid equilibrium temperature, K | PhaseTransition | 4 | 43 |
| Binary diffusion coefficient, m²/s | TransportProp | 3 | 41 |
| Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | ExcessPartialApparentEnergyProp | 4 | 37 |
| Vapor or sublimation pressure, kPa | VaporPBoilingTAzeotropTandP | 7 | 36 |
| Boiling temperature at pressure P, K | VaporPBoilingTAzeotropTandP | 6 | 32 |
| Critical pressure, kPa | Criticals | 3 | 23 |
| Critical temperature, K | Criticals | 3 | 23 |
| Interfacial tension, N/m | RefractionSurfaceTensionSoundSpeed | 1 | 21 |
| Henry's Law constant (mole fraction scale), kPa | CompositionAtPhaseEquilibrium | 1 | 18 |
| Tracer diffusion coefficient, m²/s | TransportProp | 1 | 18 |
| Monotectic temperature, K | PhaseTransition | 1 | 15 |
| Refractive index (Na D-line) | RefractionSurfaceTensionSoundSpeed | 5 | 13 |
| Critical density, kg/m³ | Criticals | 1 | 11 |
| Speed of sound, m/s | RefractionSurfaceTensionSoundSpeed | 1 | 6 |
| Excess molar volume, m³/mol | VolumetricProp | 1 | 5 |
| Eutectic composition: mole fraction | CompositionAtPhaseEquilibrium | 2 | 5 |
| Eutectic temperature, K | PhaseTransition | 2 | 5 |
| Quadruple (quintuple) point temperature, K | PhaseTransition | 1 | 5 |
| Amount concentration (molarity), mol/dm³ | CompositionAtPhaseEquilibrium | 1 | 4 |
| Mass fraction | CompositionAtPhaseEquilibrium | 1 | 4 |
| Surface tension liquid-gas, N/m | RefractionSurfaceTensionSoundSpeed | 1 | 3 |
| Viscosity, Pa·s | TransportProp | 1 | 3 |
| Molality, mol/kg | CompositionAtPhaseEquilibrium | 1 | 1 |

### Most commonly measured (by DOI count)
1. **Activity coefficient** — 110 DOIs (6 943 blocks)
2. **Mole fraction** (phase-equilibrium composition) — 52 DOIs
3. **Mass density** — 12 DOIs
4. **Solid-liquid equilibrium temperature** / **Vapor or sublimation pressure** — 7 DOIs each
5. **Boiling temperature at pressure P** — 6 DOIs

## 5. execute_sql

## Properties with both Temperature and Mole Fraction as variables (hexane + ethanol binary blocks)

These properties come from blocks where **both** `Temperature, K` and `Mole fraction` are independent variables, meaning data at specific T and x combinations (including near 25 °C and x ≈ 0.5) are likely available.

| Property | # distinct DOIs |
|---|--:|
| Activity coefficient | 110 |
| Mole fraction | 50 |
| Mass density, kg/m³ | 11 |
| Vapor or sublimation pressure, kPa | 7 |
| Refractive index (Na D-line) | 4 |
| Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | 4 |
| (Relative) activity | 4 |
| Binary diffusion coefficient, m²/s | 3 |
| Molar enthalpy of solution, kJ/mol | 2 |
| Viscosity, Pa·s | 1 |
| Tracer diffusion coefficient, m²/s | 1 |
| Surface tension liquid-gas, N/m | 1 |
| Speed of sound, m/s | 1 |
| Henry's Law constant (mole fraction scale), kPa | 1 |

**14 distinct properties** total. No rows were removed; the result was not truncated.

**Note:** This query confirms that both temperature and mole fraction are variable in these blocks, but does not directly verify that data points exist exactly at T ≈ 298.15 K and x ≈ 0.5. It narrows the candidate properties that *could* have equimolar data near 25 °C.

## 6. execute_sql

## Compacted Result

### Properties with measured data for hexane + ethanol binary mixtures (liquid phase)

| Property | DOIs |
|---|---|
| Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | `10.1016/j.fluid.2005.08.001`, `10.1016/j.fluid.2006.04.016`, `10.1016/j.fluid.2007.06.001`, `10.1021/acs.jced.7b00119` |
| Refractive index (Na D-line) | `10.1016/j.fluid.2012.10.004`, `10.1016/j.fluid.2018.01.019`, `10.1016/j.fluid.2018.06.003`, `10.1016/j.jct.2007.02.008`, `10.1021/acs.jced.8b00600` |
| Speed of sound, m/s | `10.1016/j.jct.2007.02.008` |
| Surface tension liquid-gas, N/m | `10.1021/je700215z` |

### Properties queried but returning **no results**

- Mass density, kg/m³
- Excess molar volume, m³/mol
- Viscosity, Pa·s
- Binary diffusion coefficient, m²/s

### Notes
- 11 total rows returned; no truncation.
- These are DOIs for blocks matching hexane + ethanol (2-component, `PureOrMixtureData`). The query has **not yet confirmed** that data points fall near T ≈ 298.15 K and x ≈ 0.5 — JSON-level inspection of the listed DOIs is still needed for that verification.
- Candidate DOIs for detailed JSON sampling: `10.1016/j.jct.2007.02.008` (has both refractive index and speed of sound), `10.1021/je700215z` (surface tension), and any of the excess-enthalpy DOIs.

## 7. execute_sql

## Compacted Result

### Density property names found for hexane + ethanol mixtures

Two distinct property names match `%density%`:

| prop_name | # distinct DOIs | # blocks |
|---|---|---|
| **Critical density, kg/m3** | 1 | 11 |
| **Mass density, kg/m3** | 8 | 39 |

### DOIs by property

**Critical density, kg/m3**
- `10.1016/j.fluid.2011.05.005` (blocks 3–33, 11 blocks)

**Mass density, kg/m3**

| DOI | Block numbers |
|---|---|
| `10.1016/j.fluid.2012.10.004` | 25, 28, 31, 34 |
| `10.1016/j.fluid.2018.01.019` | 2 |
| `10.1016/j.fluid.2018.06.003` | 2 |
| `10.1016/j.jct.2005.04.010` | 91 |
| `10.1016/j.jct.2007.02.008` | 24, 27, 30, 33, 36, 39 |
| `10.1016/j.jct.2019.03.015` | 5, 7, 9 |
| `10.1016/j.tca.2017.09.010` | 5, 7, 9 |
| `10.1021/acs.jced.8b00536` | 8, 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40, 42, 44, 46 |

### Notes
- 50 rows returned; query was **not** truncated (confirmed by metadata).
- The exact property name for mass density in the database is **"Mass density, kg/m3"** (not just "density").

## 8. execute_sql

## Compacted Result

**Query:** Hexane + ethanol binary mixture — properties matching viscosity, diffusion, excess volume, speed of sound, surface/interfacial tension, refractive index.

**100 rows returned (limit reached but not truncated).**

### Properties Found

| Property | Unit | Distinct DOIs | Example DOI(s) |
|---|---|---|---|
| Excess molar volume | m³/mol | 1 | `10.1016/j.fluid.2005.08.001` |
| Binary diffusion coefficient | m²/s | 3 | `10.1016/j.fluid.2010.06.003`, `10.1021/je0497303`, `10.1021/je700539w` |
| Tracer diffusion coefficient | m²/s | 1 | `10.1021/je060289l` |
| Refractive index (Na D-line) | — | 4 | `10.1016/j.fluid.2012.10.004`, `10.1016/j.fluid.2018.01.019`, `10.1016/j.fluid.2018.06.003`, `10.1016/j.jct.2007.02.008`, `10.1021/acs.jced.8b00600` |
| Speed of sound | m/s | 1 | `10.1016/j.jct.2007.02.008` |
| Interfacial tension | N/m | 1 | `10.1021/je0604277` |
| Surface tension liquid-gas | N/m | 1 | `10.1021/je700215z` |

### Properties NOT Found (zero matching rows)

- **Viscosity** — no rows matched `%iscosit%`

### Summary of availability

| Queried category | Available? |
|---|---|
| Viscosity | **No** |
| Diffusion (binary & tracer) | **Yes** |
| Excess molar volume | **Yes** |
| Speed of sound | **Yes** |
| Surface / interfacial tension | **Yes** |
| Refractive index | **Yes** |

*Block-number detail omitted (multiple blocks per DOI); all distinct DOIs and property names are preserved above.*

## 9. execute_sql

## Compacted Result

**Status:** Query failed with a JSON path error.

**Error:** `bad JSON path: '-1'`

**Cause:** The expression `b.block_number - 1` likely produces a negative index (e.g., if `block_number` is 0) or SQLite's `json_extract` does not accept the dynamically constructed path due to type/concatenation issues (the subtraction result may not concatenate cleanly into the path string).

**No data was returned.** Neither task could be completed:

1. **Data points near T=298.15 K and x=0.5** — not checked (query failed).
2. **NumValues data structure** — not inspected (query failed).

**Suggestion for retry:** Ensure `block_number` values are correct (they may be 1-based while JSON arrays are 0-based) and cast the arithmetic result explicitly, e.g.:

```sql
'$.PureOrMixtureData[' || CAST(b.block_number - 1 AS TEXT) || '].NumValues'
```

Or try a simpler direct path like `'$.PureOrMixtureData[23].NumValues'` (for block_number 24) to verify the path works before using dynamic construction.

## 10. execute_sql

## Compacted Result

### JSON Structure of `NumValues` (Task 1)

Each data point in the `NumValues` array has this structure:

```
{
  "VariableValue": [
    { "nVarNumber": 1, "nVarValue": <temperature in K>, "nVarDigits": 5 },
    { "nVarNumber": 2, "nVarValue": <mole fraction>,   "nVarDigits": ... }
  ],
  "PropertyValue": [
    {
      "nPropNumber": 1,
      "nPropValue": <measured value>,
      "nPropDigits": 4,
      "CombinedUncertainty": {
        "nCombUncertAssessNum": 1,
        "nCombExpandUncertValue": <uncertainty>
      }
    }
  ]
}
```

- **Variable 1** (`nVarNumber: 1`): Temperature (K)
- **Variable 2** (`nVarNumber: 2`): Mole fraction (composition)
- **Property 1** (`nPropNumber: 1`): Measured property value (with combined expanded uncertainty)

### Data Points Visible in the Truncated Sample (Task 2)

All visible points are at **T = 293.15 K** (not 298.15 K). The mole-fraction values seen so far:

| T (K) | x (Var 2) | Property Value | Uncertainty |
|--------|-----------|---------------|-------------|
| 293.15 | 0         | 659.5         | ±0.8        |
| 293.15 | 0.0469    | 661.5         | ±0.8        |
| 293.15 | 0.1003    | 664.4         | ±0.8        |
| 293.15 | 0.2004    | 670.7         | ±0.8        |
| 293.15 | 0.308     | 678.7         | ±0.7        |

**Note:** The result is **truncated at 3000 characters** — only the first ~5 data points (all at T = 293.15 K, x ≤ 0.308) are visible. Data points near **T = 298.15 K** and **x = 0.5** may exist further in the array but are not confirmed by this truncated sample. A targeted query filtering for those specific variable values would be needed.

## 11. execute_sql

## Hexane + Ethanol Binary Mixture — Liquid-Phase Thermophysical Properties Found

**39 distinct (property, DOI) pairs across 13 property types** were returned. No truncation; query completed in ~3.2 s.

### Properties and Associated DOIs

| Property | # DOIs | DOIs |
|---|---|---|
| **Binary diffusion coefficient, m²/s** | 3 | `10.1016/j.fluid.2010.06.003`, `10.1021/je0497303`, `10.1021/je700539w` |
| **Excess molar enthalpy (molar enthalpy of mixing), kJ/mol** | 4 | `10.1016/j.fluid.2005.08.001`, `10.1016/j.fluid.2006.04.016`, `10.1016/j.fluid.2007.06.001`, `10.1021/acs.jced.7b00119` |
| **Excess molar volume, m³/mol** | 1 | `10.1016/j.fluid.2005.08.001` |
| **Interfacial tension, N/m** | 1 | `10.1021/je0604277` |
| **Mass density, kg/m³** | 12 | `10.1016/j.fluid.2012.10.004`, `…2018.01.019`, `…2018.06.003`, `10.1016/j.jct.2005.04.010`, `…2007.02.008`, `…2019.03.015`, `10.1016/j.tca.2017.09.010`, `10.1021/acs.jced.8b00536`, `…8b00600`, `…9b00375`, `10.1021/je800024u`, `10.1021/je800925v` |
| **Molar enthalpy of solution, kJ/mol** | 2 | `10.1016/j.tca.2014.08.024`, `10.1016/j.tca.2015.08.015` |
| **Refractive index (Na D-line)** | 5 | `10.1016/j.fluid.2012.10.004`, `…2018.01.019`, `…2018.06.003`, `10.1016/j.jct.2007.02.008`, `10.1021/acs.jced.8b00600` |
| **Speed of sound, m/s** | 1 | `10.1016/j.jct.2007.02.008` |
| **Surface tension liquid–gas, N/m** | 1 | `10.1021/je700215z` |
| **Tracer diffusion coefficient, m²/s** | 1 | `10.1021/je060289l` |
| **Vapor or sublimation pressure, kPa** | 7 | `10.1016/j.fluid.2005.08.006`, `…2007.06.001`, `…2012.11.008`, `10.1016/j.jct.2005.04.010`, `10.1021/acs.jced.7b00119`, `…7b00892`, `10.1021/je050440b` |
| **Viscosity, Pa·s** | 1 | `10.1021/je800925v` |

### Notes
- Phase-equilibrium quantities (activity coefficients, boiling/eutectic/LLE temperatures, mole fractions, etc.) and critical-point properties were **excluded by the query filter** to focus on liquid-phase thermophysical properties.
- The query did **not** filter on temperature or composition within the JSON data; these DOIs/properties are candidates likely measured near 25 °C but would need further JSON-level inspection to confirm T ≈ 298.15 K and equimolar (x ≈ 0.5) conditions.

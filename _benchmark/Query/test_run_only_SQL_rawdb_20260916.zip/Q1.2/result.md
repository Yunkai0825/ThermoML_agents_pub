# Q1.2 — Result

**Prompt:** For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 11
- **API turns:** 11
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 366.2s
- **Timed out:** False

## Answer

Based on my thorough search of the ThermoML database, here is a comprehensive answer:

---

## Thermophysical Properties Measured for Equimolar Hexane + Ethanol Liquid Mixtures near 25 °C

The ThermoML database contains a rich collection of measurements for the **hexane + ethanol** binary system. The following thermophysical properties have been reported across numerous studies, with data available at or near 298.15 K and varying compositions (including equimolar, x ≈ 0.5):

### Volumetric Properties
| Property | # Sources (DOIs) |
|---|---|
| **Mass density**, kg/m³ | 12 |
| **Excess molar volume**, m³/mol | 1 |

### Energetic / Calorimetric Properties
| Property | # Sources |
|---|---|
| **Excess molar enthalpy (enthalpy of mixing)**, kJ/mol | 4 |
| **Molar enthalpy of solution**, kJ/mol | 2 |

### Transport Properties
| Property | # Sources |
|---|---|
| **Binary diffusion coefficient**, m²/s | 3 |
| **Tracer diffusion coefficient**, m²/s | 1 |
| **Viscosity**, Pa·s | 1 |

### Optical / Acoustic / Surface Properties
| Property | # Sources |
|---|---|
| **Refractive index (Na D-line)** | 5 |
| **Speed of sound**, m/s | 1 |
| **Surface tension (liquid–gas)**, N/m | 1 |
| **Interfacial tension**, N/m | 1 |

### Phase Equilibrium Properties (also widely reported)
| Property | # Sources |
|---|---|
| **Vapor or sublimation pressure**, kPa | 7 |
| **Activity coefficient** | 110 |

---

### Chemical Insight

Hexane + ethanol is a classic **non-ideal mixture** — hexane is a nonpolar hydrocarbon while ethanol is a polar, hydrogen-bonding molecule. This strong dissimilarity leads to:

- **Large positive excess molar enthalpies** (endothermic mixing), reflecting the energy cost of disrupting ethanol's hydrogen-bond network.
- **Positive excess molar volumes**, since the unlike molecular interactions are weaker than the like–like interactions.
- **Significant deviations from Raoult's law** (activity coefficients >> 1), and the system exhibits a **minimum-boiling azeotrope**.
- At low temperatures, the system even shows **liquid–liquid immiscibility** (UCST behavior), which is why solid–liquid and liquid–liquid equilibrium temperatures are also reported.

The equimolar composition (x = 0.5) is particularly interesting because it is near the region of maximum non-ideality for this system, making it a benchmark for testing thermodynamic models (NRTL, UNIQUAC, etc.). The wealth of data — **mass density** (12 DOIs), **refractive index** (5 DOIs), and **excess enthalpy** (4 DOIs) being the most extensively studied liquid-phase properties — reflects the system's importance as a test case in chemical engineering thermodynamics.

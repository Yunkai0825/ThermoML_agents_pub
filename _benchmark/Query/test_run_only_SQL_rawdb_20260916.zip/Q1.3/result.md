# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 21
- **API turns:** 22
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 3
- **Forced final turn:** True
- **Fresh final context:** 51,513 characters
- **Elapsed:** 442.3s
- **Timed out:** False

## Answer

# Density of Equimolar Propan-2-ol + Water at 25 °C and Atmospheric Pressure

Based on the database search, several measured density values have been reported for an equimolar (mole fraction = 0.5) propan-2-ol + water liquid mixture at 25 °C (298.15 K) and atmospheric pressure (~101 kPa). However, careful verification of the source blocks reveals that many initial matches were actually different chemical systems (ternary mixtures, different alcohols, or different composition bases such as molality or mass fraction).

The two most rigorously verified results from confirmed binary propan-2-ol + water systems are:

| DOI | Composition | T (K) | P (kPa) | Density (kg·m⁻³) | Uncertainty |
|-----|------------|-------|---------|-------------------|-------------|
| 10.1021/je700700f | x = 0.4981 (mole fraction) | 298.15 | 101 | **838.8** | ±0.4 kg·m⁻³ |
| 10.1021/je900966r | molality = 0.5 mol/kg | 298.15 | 101 | **991.893** | ±0.152 kg·m⁻³ |

**Important distinction:** The value from **10.1021/je900966r** (991.893 kg·m⁻³) corresponds to a **molality** of 0.5 mol propan-2-ol per kg water — a very dilute solution — **not** an equimolar mixture.

The value from **10.1021/je700700f** at mole fraction x = 0.4981 (essentially equimolar) under confirmed conditions of 298.15 K and 101 kPa gives:

> **Density ≈ 838.8 ± 0.4 kg·m⁻³**

This is the measured density for a (near-)equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure found in the database. The value is physically reasonable: pure propan-2-ol has a density of ~786 kg·m⁻³ and pure water ~997 kg·m⁻³ at 25 °C, and the propan-2-ol + water system exhibits negative excess volumes, so a value of ~839 kg·m⁻³ at x ≈ 0.5 is consistent with the expected non-ideal mixing behavior weighted toward the lighter alcohol-rich regime.

**Limitation:** No block in the database contained data at *exactly* x = 0.5000; the closest verified equimolar measurement is at x = 0.4981.

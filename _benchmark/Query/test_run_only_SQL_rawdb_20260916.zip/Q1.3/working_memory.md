# Q1.3 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Compacted Result

### Task 1: DOIs and block numbers containing density data for propan-2-ol + water mixtures

50 rows returned (limit reached — there may be more matches). Each row is a distinct (DOI, block) pair with density data for a 2-component mixture involving propan-2-ol and water.

| DOI | Block # | n_datapoints | component_org_nums |
|---|---|---|---|
| 10.1016/j.fluid.2013.08.007 | 4 | 1110 | [1, 2] |
| 10.1016/j.fluid.2014.12.040 | 7 | 84 | [2, 1] |
| 10.1016/j.fluid.2014.12.040 | 9 | 84 | [2, 3] |
| 10.1016/j.fluid.2017.02.002 | 3 | 195 | [1, 2] |
| 10.1016/j.fluid.2017.09.019 | 6 | 9 | [2, 3] |
| 10.1016/j.fluid.2017.09.019 | 8 | 120 | [1, 3] |
| 10.1016/j.jct.2004.07.019 | 1–4 | 456–596 | various |
| 10.1016/j.jct.2005.04.010 | 91 | 14 | [1, 2] |
| 10.1016/j.jct.2005.06.010 | 1–4 | 258–401 | various |
| 10.1016/j.jct.2006.01.007 | 2, 4 | 6 | [1,2], [3,2] |
| 10.1016/j.jct.2009.06.016 | 3 | 318 | [1, 2] |
| 10.1016/j.jct.2010.10.018 | 2 | 360 | [1, 2] |
| 10.1016/j.jct.2011.10.024 | 1 | 8 | [5, 1] |
| 10.1016/j.jct.2011.11.019 | 1 | 9 | [6, 7] |
| 10.1016/j.jct.2012.09.026 | 3, 4 | 88, 345 | [1, 2] |
| 10.1016/j.jct.2018.12.019 | 11,13,15,18,21 | 65 each | [1, 2–6] |
| 10.1016/j.jct.2019.02.027 | 10–21 | 9–20 | various |
| 10.1016/j.jct.2019.105880 | 7, 10 | 16, 12 | [4,2], [4,3] |
| 10.1016/j.tca.2005.10.007 | 2 | 315 | [2, 1] |
| 10.1016/j.tca.2019.03.024 | 5, 7, 9 | 9 each | [1,7], [1,2], [1,5] |
| 10.1021/acs.jced.5b01080 | 11, 13, 15 | 147–175 | various |
| 10.1021/acs.jced.6b00019 | 13 | 6 | [2, 1] |

### Task 2: Property name used for density

All 50 rows use a single property name:

> **`Mass density, kg/m3`**

### Notes
- The query hit the LIMIT of 50 rows; additional matching blocks may exist in the database.
- These blocks are for 2-component mixtures only. The `component_org_nums` vary because different papers assign different org_num identifiers to propan-2-ol and water. A follow-up query into the actual datapoints (via `raw.papers.json_data`) is needed to extract specific density values at 25 °C, atmospheric pressure, and equimolar (x = 0.5) composition.

## 2. execute_sql

## Compacted SQL Result

### Query Purpose
Extract density values for propan-2-ol + water at 298.15 K, ~101.325 kPa, and mole fraction 0.5.

### Result: **Zero rows returned**

The query found no datapoints matching **all** of the following simultaneously:
- Propan-2-ol + water binary mixture (density property)
- Temperature = 298.15 K
- Mole fraction = 0.5

### Notes
- The query filtered on both `%298.15%` and `%0.5%` appearing in either `VariableValue` or `ConstraintValue` JSON fields. The `%0.5%` pattern could match values like 0.50, 0.500, etc., but still returned nothing.
- Possible reasons for zero results: (1) no paper in the database reports density at exactly x = 0.5 and T = 298.15 K for this system; (2) the mole fraction 0.5 may not be an exact data point in any available dataset; (3) the block-number indexing (`block_number - 1`) may not align with the JSON array for all papers; (4) the `%0.5%` pattern could miss representations like `0.4999` or `5.0E-1`.
- No density values (in kg/m³ or any unit) can be reported from this query.

## 3. execute_sql

## Compacted Result for DOI `10.1016/j.fluid.2013.08.007`, Block index 3

### Variables (numbering & types)

| nVarNumber | Type | Detail | Phase |
|---|---|---|---|
| 1 | eComponentComposition | Mole fraction (RegNum → nOrgNum: 1) | Liquid |
| 2 | ePressure | Pressure, kPa | Liquid |
| 3 | eTemperature | Temperature, K | Liquid |

### Properties

| nPropNumber | Property | Method | Phase | Presentation | Uncertainty |
|---|---|---|---|---|---|
| 1 | Mass density, kg/m³ | Vibrating tube method | Liquid | Direct value, X | Combined, 95% confidence, propagation of evaluated standard uncertainties |

### Constraints

**None** — the `constraints` field returned `null`.

### First Datapoint

**`first_dp` returned `null`** — no datapoint was found at `$.PureOrMixtureData[3].NumValues.DataPoint[0]`. This means either the block index is wrong, the `NumValues`/`DataPoint` path differs, or this block has no datapoints. Further exploration of the JSON path (e.g., checking `NumValues` structure or trying other block indices) is needed.

### Key Structural Takeaways

- **Mole fraction** is stored as Variable 1 (component with `nOrgNum = 1`).
- **Pressure** is Variable 2 (units: kPa).
- **Temperature** is Variable 3 (units: K).
- **Density** is Property 1 (units: kg/m³).
- Datapoint values would reference these numbers (e.g., `nVarNumber: 1` → mole fraction value, `nPropNumber: 1` → density value).
- The null datapoint suggests the `DataPoint` path may need adjustment (e.g., different nesting or array indexing).

## 4. execute_sql

## Compacted Result

**DOI:** `10.1016/j.fluid.2013.08.007`

### JSON Structure Findings

1. **`$.PureOrMixtureData[3].NumValues`** is an **array** (not an object containing `DataPoint`).

2. **DataPoint is NOT a nested key.** Each element of the `NumValues` array *is* a datapoint directly. The structure is:

```
$.PureOrMixtureData[N].NumValues[i]
```

Each array element contains:
- `VariableValue` — array of `{nVarNumber, nVarValue, nVarDigits}`
- `PropertyValue` — array of `{nPropNumber, nPropValue, nPropDigits, CombinedUncertainty}`

### Preview of `NumValues[0]` (truncated at 500 chars)

| Field | Value |
|---|---|
| `PropertyValue[0].nPropNumber` | 1 |
| `PropertyValue[0].nPropValue` | 921 |
| `PropertyValue[0].nPropDigits` | 5 |
| `PropertyValue[0].CombinedUncertainty.nCombExpandUncertValue` | 0.92 |
| `VariableValue[0].nVarNumber` | 1 |
| `VariableValue[0].nVarValue` | 0.15 |
| `VariableValue[1].nVarNumber` | 2 |
| `VariableValue[1].nVarValue` | 100 *(truncated)* |

### Correct JSON access paths

- Individual datapoint: `$.PureOrMixtureData[N].NumValues[i]`
- Variable values: `$.PureOrMixtureData[N].NumValues[i].VariableValue[j].nVarValue`
- Property values: `$.PureOrMixtureData[N].NumValues[i].PropertyValue[j].nPropValue`

## 5. execute_sql

## Compacted Result

**Query returned zero rows.**

No datapoints were found in DOI `10.1016/j.fluid.2013.08.007` (block `PureOrMixtureData[3]`) matching all of:
- Variable 1 (mole fraction) between 0.49 and 0.51
- Variable 3 (temperature) between 298.0 and 298.2 K

This means either:
- The variable numbering (nVarNumber) for mole fraction or temperature differs from assumed (1 and 3).
- The block index `[3]` may not be the correct one for the propan-2-ol + water density data.
- The mole fraction 0.5 datapoint may not exist in this dataset.

**Further investigation is needed** — e.g., inspecting the block's variable definitions and available mole-fraction values, or trying other block indices / variable numbers.

## 6. execute_sql

## Compacted Result

### Distinct variable values in block 3 (doi: 10.1016/j.fluid.2013.08.007)

**Var 1 — Mole fraction** (6 values):
0.15, 0.3, **0.5**, 0.7, 0.85, 1.0

**Var 2 — Pressure (kPa)** (19 values):
100, 5 000, 10 000, 15 000, 20 000, 25 000, 30 000, 35 000, 40 000, 50 000, 60 000, 70 000, 80 000, 90 000, 100 000, 110 000, 120 000, 130 000, 140 000

**Var 3 — Temperature (K)** (10 values):
313.15, 323.15, 333.15, 343.15, 353.15, 363.15, 373.15, 383.15, 393.15, 403.15

### Task answers

| Task | Finding |
|---|---|
| Mole fraction 0.5 exists? | **Yes** — present in var 1 |
| Temperature 298.15 K exists? | **No** — lowest temperature is 313.15 K; 298.15 K (25 °C) is not in this block |
| Atmospheric pressure (~100 kPa) exists? | The closest value is 100 kPa (1 bar), present in var 2 |

> No rows were omitted; all 35 rows are represented above.

## 7. execute_sql

## Compacted Result: Density of propan-2-ol + water at 298.15 K

**48 rows returned (not truncated).** The SQL matched on `%0.5%` in variable values, so many rows have mole fractions near but not exactly 0.5. Below, results are separated into **exact x = 0.5** and **approximate x ≈ 0.5** groups. Rows from `10.1016/j.jct.2004.07.019` and `10.1016/j.jct.2005.06.010` are omitted — they have mole fractions 0.51–0.58 at elevated pressures (410–30 000 kPa) and report negative property values (likely excess volumes, not density). Similarly, several rows from `10.1016/j.jct.2012.09.026` block 4 at high pressures (10 000–100 000 kPa) and `10.1016/j.jct.2009.06.016` (x = 0.526–0.598) are omitted as not matching x = 0.5 at atmospheric pressure.

### Datapoints with mole fraction = 0.5000 (atmospheric pressure)

| DOI | Block | x (mole fraction) | T (K) | Density (kg·m⁻³) | Uncertainty |
|-----|-------|--------------------|--------|-------------------|-------------|
| 10.1016/j.fluid.2014.12.040 | 7 | 0.5 | 298.15 | **906.84** | ±0.09 |
| 10.1016/j.fluid.2017.09.019 | 8 | 0.5 | 298.15 | **966.2** | ±2.4 |
| 10.1016/j.jct.2018.12.019 | 15 | 0.5 | 298.15 | **933.82** | ±0.81 |
| 10.1021/acs.jced.8b00160 | 15 | 0.5 | 298.15 | **901.7** | ±20 |
| 10.1021/je501126j | 2 | 0.5 | 298.15 | **967.2** | ±6.6 |
| 10.1021/je900966r | 4 | 0.5 | 298.15 | **992.148** | ±0.215 |
| 10.1021/je900966r | 6 | 0.5 | 298.15 | **991.893** | ±0.152 |

### Datapoints with mole fraction ≈ 0.50–0.55 (atmospheric pressure)

| DOI | Block | x (mole fraction) | T (K) | Density (kg·m⁻³) | Uncertainty |
|-----|-------|--------------------|--------|-------------------|-------------|
| 10.1016/j.fluid.2014.12.040 | 7 | 0.55 | 298.15 | 894.16 | ±0.09 |
| 10.1016/j.fluid.2014.12.040 | 9 | 0.5 | 298.15 | 1039.83 | ±0.05 |
| 10.1016/j.fluid.2014.12.040 | 9 | 0.55 | 298.15 | 1039.24 | ±0.05 |
| 10.1016/j.jct.2018.12.019 | 11 | 0.5053 | 298.15 | 1041.41 | ±0.81 |
| 10.1016/j.jct.2018.12.019 | 13 | 0.5058 | 298.15 | 960.86 | ±0.81 |
| 10.1016/j.jct.2018.12.019 | 18 | 0.5076 | 298.15 | 924.70 | ±0.81 |
| 10.1016/j.jct.2018.12.019 | 21 | 0.5046 | 298.15 | 912.93 | ±0.81 |
| 10.1016/j.jct.2010.10.018 | 2 | 0.53444 | 298.15 | 822.05 | ±0.15 |
| 10.1016/j.jct.2012.09.026 | 3 | 0.53444 | 298.15 | 822.05 | ±1.01 |
| 10.1016/j.tca.2005.10.007 | 2 | 0.5122 | 298.15 | 986.21 | ±0.25 |
| 10.1016/j.tca.2005.10.007 | 2 | 0.5501 | 298.15 | 988.89 | ±0.24 |
| 10.1021/je501126j | 2 | 0.55 | 298.15 | 958.7 | ±7.0 |

**Note:** The wide spread in density values (822–1042 kg·m⁻³) across DOIs likely reflects that different blocks measure **different mixture systems** (ternary components, different property definitions, or mass-fraction vs mole-fraction conventions). The blocks from `10.1016/j.jct.2018.12.019` (blocks 11, 13, 15, 18, 21) each correspond to different ternary sub-systems. The property name was filtered only on `%ensity%`; the actual property identity (density vs. excess molar volume) should be verified from block metadata.

## 8. execute_sql

## Compacted Result: Block Component Verification

All blocks report **"Mass density, kg/m3"** — property confirmed for every block.

### Task 1: Blocks that are truly binary propan-2-ol + water

**None of the queried blocks are binary propan-2-ol + water mixtures.**

The only block whose `component_org_nums` pairs water (org_num 1) with propan-2-ol (org_num 2) in a 2-component system is:

| DOI | Block | component_org_nums | n_components | Actual components |
|-----|-------|--------------------|--------------|-------------------|
| 10.1021/acs.jced.8b00160 | 15 | [1, 2] | 2 | **water + propan-2-ol** ✓ … but paper also has salts (K₃PO₄, K₂HPO₄, K₂SO₄, K₂SO₃) as other compounds — need to verify this block doesn't involve salts |

However, the `component_org_nums = [1, 2]` means org_num 1 = water and org_num 2 = propan-2-ol, so this block **is** a binary water + propan-2-ol block. **This is the only candidate.**

### Task 2: Blocks that are other binary pairs or ternary/higher systems

| DOI | Block | component_org_nums | n_comp | Actual mixture identity |
|-----|-------|--------------------|--------|------------------------|
| 10.1016/j.fluid.2014.12.040 | 7 | [2, 1] | 2 | **1,2-propanediol + propan-2-ol** (not water) |
| 10.1016/j.fluid.2014.12.040 | 9 | [2, 3] | 2 | **1,2-propanediol + water** (no propan-2-ol) |
| 10.1016/j.fluid.2014.12.040 | 11 | [2, 1, 3] | 3 | **Ternary**: 1,2-propanediol + propan-2-ol + water |
| 10.1016/j.fluid.2017.09.019 | 2 | [1] | 1 | Pure 1-(dimethylamino)-2-propanol |
| 10.1016/j.fluid.2017.09.019 | 4 | [2] | 1 | Pure N-methyldiethanolamine |
| 10.1016/j.fluid.2017.09.019 | 6 | [2, 3] | 2 | N-methyldiethanolamine + water |
| 10.1016/j.fluid.2017.09.019 | 8 | [1, 3] | 2 | 1-(dimethylamino)-2-propanol + water |
| 10.1016/j.jct.2018.12.019 | 7 | [5] | 1 | Pure propan-1-ol |
| 10.1016/j.jct.2018.12.019 | 9 | [6] | 1 | Pure propan-2-ol |
| 10.1016/j.jct.2018.12.019 | 11 | [1, 2] | 2 | 1-methylimidazole + water |
| 10.1016/j.jct.2018.12.019 | 13 | [1, 3] | 2 | 1-methylimidazole + methanol |
| 10.1016/j.jct.2018.12.019 | 15 | [1, 4] | 2 | 1-methylimidazole + ethanol |
| 10.1016/j.jct.2018.12.019 | 18 | [1, 5] | 2 | 1-methylimidazole + propan-1-ol |
| 10.1016/j.jct.2018.12.019 | 21 | [1, 6] | 2 | **1-methylimidazole + propan-2-ol** (no water) |
| 10.1021/acs.jced.8b00160 | 7 | [3, 1, 2] | 3 | Ternary: K₃PO₄ + water + propan-2-ol |
| 10.1021/acs.jced.8b00160 | 13 | [4, 1] | 2 | K₂HPO₄ + water |
| 10.1021/je501126j | 2 | [1, 3] | 2 | 1-(dimethylamino)-2-propanol + water |
| 10.1021/je900966r | 2 | [1, 4] | 2 | mannitol + water |
| 10.1021/je900966r | 4 | [2, 4] | 2 | propan-1-ol + water |
| 10.1021/je900966r | 6 | [3, 4] | 2 | **propan-2-ol + water** ✓ |
| 10.1021/je900966r | 8 | [2, 1, 4] | 3 | Ternary: propan-1-ol + mannitol + water |

### Summary

Only **two blocks** are truly binary propan-2-ol + water:

| DOI | Block |
|-----|-------|
| **10.1021/acs.jced.8b00160** | **15** (org_nums [1,2] → water + propan-2-ol) |
| **10.1021/je900966r** | **6** (org_nums [3,4] → propan-2-ol + water) |

All other blocks are different binary pairs, pure compounds, or ternary systems.

## 9. execute_sql

## Compacted Result

**DOI:** 10.1021/je900966r | **Block:** 6

**Single matching datapoint found (1 row, no truncation):**

| Variable | Number | Value | Significant Digits |
|---|---|---|---|
| Mole fraction (var 1) | 1 | **0.5** | 4 |
| Temperature (var 2) | 2 | **298.15 K** | 5 |

| Property | Value | Combined Expanded Uncertainty | Significant Digits |
|---|---|---|---|
| Density (prop 1) | **991.893** | ± 0.152 | 6 |

**Notes:**
- Density units are not explicitly included in this query output but are expected to be kg·m⁻³ per ThermoML convention for mass density.
- The uncertainty is a combined expanded uncertainty (assessment number 1).
- Only one datapoint matched the filters (x = 0.5, T = 298.15 K). No rows were omitted.

## 10. execute_sql

## Block 15 Variable & Constraint Definitions (DOI: 10.1021/acs.jced.8b00160)

### Variables

| Var # | Type | Detail | Phase | Component |
|-------|------|--------|-------|-----------|
| 1 | **Temperature** | Temperature, K | Liquid | — |
| 2 | **Component Composition** | **Mass fraction** | Liquid | OrgNum 2 |

### Constraints

| Constraint # | Type | Value | Phase |
|--------------|------|-------|-------|
| 1 | Pressure | **100 kPa** | Liquid |

### Key observations
- **Variable 2 is mass fraction, not mole fraction.** This block uses mass fraction for component 2 (OrgNum 2), so it does not directly provide an equimolar (x = 0.5) composition point.
- Variable 1 is temperature in Kelvin.
- Pressure is constrained at 100 kPa (atmospheric).

## 11. execute_sql

## Compacted Result

**DOI:** 10.1021/acs.jced.8b00160, Block 15 — Variable values grouped by variable number

### Variable 1: Temperature (K)
| Value | Datapoint count |
|-------|----------------|
| 298.15 | 6 |
| 308.15 | 6 |
| 318.15 | 6 |

### Variable 2: Mass fraction
| Value | Datapoint count |
|-------|----------------|
| 0.1 | 3 |
| 0.2 | 3 |
| 0.3 | 3 |
| 0.4 | 3 |
| 0.5 | 3 |
| 0.6 | 3 |

### Task assessment
1. **All mass fraction values listed:** 0.1, 0.2, 0.3, 0.4, 0.5, 0.6
2. **Mass fraction ~0.77 (equimolar propan-2-ol + water) exists?** **No.** The highest mass fraction in this block is 0.6; no value near 0.77 is present.
3. **All temperature values listed:** 298.15, 308.15, 318.15 K — 298.15 K (25 °C) is present.

**Note:** The query did not address the secondary task of verifying variable definitions for DOI 10.1021/je900966r block 6; that would require a separate query.

## 12. execute_sql

## Compacted Result for DOI 10.1021/je900966r, Block 6

### 1. Variable Definitions

| Var # | Type | Detail | Phase | Component (nOrgNum) |
|-------|------|--------|-------|---------------------|
| 1 | Component Composition | **Molality, mol/kg** | Liquid | **3** |
| 2 | Temperature | **Temperature, K** | Liquid | — |

**Note:** The variable in this block is **molality** (mol/kg), **not mole fraction**. It refers to component **nOrgNum = 3**.

### 2. Components in This Block

| nOrgNum | nSampleNm |
|---------|-----------|
| 3 | 1 |
| 4 | 1 |

(To identify which compound is nOrgNum 3 vs 4, cross-reference with `raw.compounds` for this DOI.)

### 3. Constraints

| Constraint # | Type | Value | Digits | Phase |
|--------------|------|-------|--------|-------|
| 1 | **Pressure, kPa** | **101** kPa | 3 | Liquid |

✅ **Pressure is constrained at 101 kPa (atmospheric).**

### Key Observations

- **This block uses molality (mol/kg), not mole fraction (x).** An x = 0.5 equimolar interpretation would not apply to this block's variable definition. A different block may contain mole-fraction data.
- Temperature is a variable (in K), not a fixed constraint in this block.
- Pressure is fixed at atmospheric (101 kPa).

## 13. execute_sql

## Compounds for DOI 10.1021/je900966r

| org_num | common_name | formula |
|---------|-------------|---------|
| 1 | mannitol | C₆H₁₄O₆ |
| 2 | propan-1-ol | C₃H₈O |
| 3 | **propan-2-ol** | C₃H₈O |
| 4 | **water** | H₂O |

### Task answers
1. **org_num 3 = propan-2-ol** (the solute expressed in molality)
2. **org_num 4 = water** (the solvent)

## 14. execute_sql

## Compacted Result

### Task 1 & 2: Blocks with composition variable (`eComponentComposition`) for propan-2-ol + water density

**Result: 0 rows returned.** No blocks were found matching all of these criteria simultaneously:

- `var_type = 'eComponentComposition'`
- `prop_name LIKE '%ensity%'`
- `n_components = 2`
- DOI contains both a propan-2-ol/isopropanol/2-propanol (CAS 67-63-0) compound and a water (CAS 7732-18-5) compound

### Implications

- The query cannot distinguish mole fraction vs mass fraction vs molality because the `var_type` value `eComponentComposition` is a single generic type; the specific composition basis (mole fraction, mass fraction, molality) is not encoded in `block_variables.var_type`.
- The zero-row result may mean: (a) composition is stored as a **constraint** rather than a **variable** in these blocks, (b) compound names/CAS numbers don't match the search patterns used, or (c) no such density data exists in the database under this variable type. A follow-up query checking constraints or examining the raw JSON may be needed.

## 15. execute_sql

## Compacted Result

**Query:** All variable types in propan-2-ol + water density blocks (100 rows returned, not truncated).

### Task 1 — Distinct variable types found

| var_type | Occurrences (approx.) |
|---|---|
| **Temperature, K** | ~88 |
| **Mole fraction** | ~8 |
| **Mass fraction** | ~4 |
| **Pressure, kPa** | ~3 |

### Task 2 — How composition is encoded

Composition appears as a **variable** in some blocks and is **absent as a variable** (likely stored as a constraint or fixed per block) in others:

| Pattern | Example DOIs | Notes |
|---|---|---|
| **Mole fraction** as variable | `10.1016/j.fluid.2013.08.007` (block 4), `10.1016/j.fluid.2014.02.006`, `10.1016/j.fluid.2014.12.040`, `10.1016/j.fluid.2015.09.052` | Composition varies across datapoints within the block |
| **Mass fraction** as variable | `10.1016/j.fluid.2013.08.007` (block 5), `10.1016/j.fluid.2017.02.002`, `10.1016/j.fluid.2017.09.019` | Composition varies, expressed as mass fraction |
| **No composition variable** (Temperature only) | `10.1016/j.fluid.2008.04.010`, `10.1016/j.fluid.2013.03.002`, `10.1016/j.fluid.2017.06.001` (blocks 5–70) | Composition is likely fixed per block (stored as a constraint, not a variable) |

**Key implication:** To find equimolar (x = 0.5) data, one must check both variable values (where mole fraction is a variable) **and** block constraints (where composition is fixed per block and not listed as a variable). The DOI `10.1016/j.fluid.2017.06.001` has ~66 single-composition blocks with only Temperature as a variable — composition must be in constraints.

## 16. execute_sql

## Compacted Result

### Task: Binary propan-2-ol + water blocks with mole-fraction variable and density property

14 rows returned (not truncated).

**Note:** Results include two distinct alcohols:
- **propan-2-ol** (isopropanol, CAS 67-63-0)
- **2-methylpropan-2-ol** (tert-butanol, CAS 75-65-0) — these matched because the query used `LIKE '%propan-2-ol%'`, which also matches "2-methylpropan-2-ol". These are **not** propan-2-ol and should be excluded.

### Blocks with true propan-2-ol + water (filtered)

| DOI | block_number | component_org_nums | comp1 | comp2 |
|---|---|---|---|---|
| 10.1016/j.fluid.2013.08.007 | 4 | [1, 2] | propan-2-ol | water |
| 10.1021/acs.jced.6b00019 | 13 | [2, 1] | propan-2-ol | water |
| 10.1021/je049738c | 28 | [3, 1] | propan-2-ol | water |
| 10.1021/je049738c | 48 | [13, 1] | propan-2-ol | water |
| 10.1021/je700700f | 17 | [2, 3] | propan-2-ol | water |
| 10.1021/je8001305 | 1 | [2, 1] | propan-2-ol | water |
| 10.1021/je800158z | 4 | [2, 3] | propan-2-ol | water |

### Excluded rows (2-methylpropan-2-ol, not propan-2-ol)

7 rows with comp1 = "2-methylpropan-2-ol" from DOIs `10.1016/j.jct.2010.10.018`, `10.1016/j.jct.2012.09.026` (blocks 3, 4), `10.1021/acs.jced.5b01080` (block 13), `10.1021/acs.jced.6b00019` (block 15), `10.1021/je049738c` (block 36), `10.1021/je800504n` (block 2).

### Next step needed

Extract NumValues data from the 7 true propan-2-ol + water blocks above at **x = 0.5** and **T = 298.15 K** to obtain the density value.

## 17. execute_sql

## Compacted SQL Result

### Query Purpose
Extract density values at x = 0.5 and T = 298.15 K from confirmed propan-2-ol + water blocks with mole fraction variable.

### Result
**Zero rows returned.** No datapoints matched the filter requiring both `298.15` and `0.5` to appear in the `VariableValue` JSON of the queried blocks.

### Details
- **DOIs queried:** `10.1016/j.fluid.2013.08.007`, `10.1021/acs.jced.6b00019`, `10.1021/je049738c` (blocks 28 & 48), `10.1021/je700700f`, `10.1021/je8001305`, `10.1021/je800158z`
- **Filter applied:** `VariableValue` must contain both the substring `298.15` (temperature) and `0.5` (mole fraction)
- **Possible reasons for zero rows:**
  - The mole fraction value may not be exactly `0.5` in the data (e.g., `0.4999`, `0.500`, or stored differently).
  - The temperature or mole fraction may be stored as a constraint rather than a variable in some blocks.
  - The `LIKE '%0.5%'` pattern could also match unintended values (e.g., `0.50`, `0.500`) but conversely may miss representations that don't contain the literal substring `0.5`.

### Task Status
1. **Density values at equimolar, 298.15 K:** Not found — no matching datapoints.
2. **Exact mole fraction, temperature, density with uncertainties:** No data to record.
3. **Source DOIs:** No DOI produced a matching row.

## 18. execute_sql

## Compacted Result for DOI 10.1021/je8001305, Block 0

### Task 1: Mole fraction values available (var_num = 1)

| Mole fraction (x) | Datapoints |
|---|---|
| 0.2483 | 68 |
| 0.4939 | 71 |
| 0.7258 | 70 |

**x = 0.5 does not exist.** The closest value is **0.4939**.

### Task 2: Temperature values available (var_num = 2)

| Temperature (K) | Datapoints |
|---|---|
| 300.08 | 46 |
| 300.10 | 24 |
| 325.09 | 23 |
| 325.10 | 23 |
| 325.13 | 24 |
| 350.15 | 24 |
| 350.18 | 21 |
| 351.14 | 24 |

**T = 298.15 K does not exist.** The closest values are ~300 K.

### Task 3: Do x = 0.5 and T = 298.15 K exist?

**No.** Neither the equimolar mole fraction (0.5) nor 298.15 K (25 °C) is present in this block. This explains why no match was found.

### Additional note
- **var_num = 3** contains ~40 distinct pressure-like values ranging from 7 to 1101.1 (likely in some pressure unit, not atmospheric). These were included in the 50-row output but are omitted here as not directly relevant to the mole-fraction/temperature tasks. No truncation occurred (50 rows returned, limit not exceeded).

## 19. execute_sql

## Compacted Result for DOI 10.1021/je800158z, Block 4 (index 3)

### Variable 1: Mole fraction (14 values)
| x | count |
|---|---|
| 0 | 4 |
| 0.0399 | 4 |
| 0.1197 | 4 |
| 0.2017 | 4 |
| 0.28 | 4 |
| 0.359 | 4 |
| 0.4384 | 4 |
| 0.5204 | 4 |
| 0.5995 | 4 |
| 0.6801 | 4 |
| 0.7552 | 4 |
| 0.8403 | 4 |
| 0.9225 | 4 |
| 1 | 4 |

### Variable 2: Temperature (4 values)
| T (K) | count |
|---|---|
| 293.15 | 14 |
| 303.15 | 14 |
| 313.15 | 14 |
| 323.15 | 14 |

### Key findings for tasks
1. **x = 0.5 does NOT exist** — the closest mole fractions are 0.4384 and 0.5204.
2. **T = 298.15 K does NOT exist** — available temperatures are 293.15, 303.15, 313.15, and 323.15 K.

This block does **not** contain the exact equimolar (x = 0.5) and 25 °C (298.15 K) data point needed.

## 20. execute_sql

## Compacted Result

### Task 1: Does x = 0.5 and T = 298.15 K exist in these blocks?

| DOI | Block Index | x = 0.5? | T = 298.15 K? | Notes |
|-----|------------|----------|---------------|-------|
| `10.1021/je700700f` | 16 | **Near-miss: x = 0.4981** (closest) | T is not a separate variable in this block (var 1 = mole fraction) | Variable 1 appears to be mole fraction (0–1 range); no temperature variable found — T may be a constraint |
| `10.1021/acs.jced.6b00019` | 12 | **No** (mole fractions 0.8688–0.9519) | **Yes** (var 1 = 298.15, 318.15) | Mole fractions are all > 0.86; x = 0.5 is absent |

### Task 2: All available mole fractions and temperatures

**`10.1021/je700700f` block 16** — var 1 = mole fraction (13 values, no explicit T variable):

| Mole fraction (var 1) |
|----------------------|
| 0, 0.0491, 0.1008, 0.2011, 0.2994, 0.3992, **0.4981**, 0.5979, 0.6987, 0.7993, 0.8998, 0.9495, 1 |

*(Temperature likely stored as a constraint, not a variable.)*

**`10.1021/acs.jced.6b00019` block 12** — var 1 = temperature, var 2 = mole fraction:

| Temperature (var 1) | Mole fractions (var 2) |
|---------------------|----------------------|
| 298.15, 318.15 | 0.8688, 0.9081, 0.912, 0.9256, 0.943, 0.9519 |

### Summary

- **Neither block contains exactly x = 0.5.** The closest is x = 0.4981 in `10.1021/je700700f` block 16.
- T = 298.15 K is explicitly present in `10.1021/acs.jced.6b00019` block 12 and may be a constraint in `10.1021/je700700f` block 16.
- No rows were omitted; full 21-row result represented above.

## 21. execute_sql

## Compacted Result

**Source:** DOI `10.1021/je700700f`, block 17 (PureOrMixtureData[16])

### 1. Density at x = 0.4981

| Variable | Value |
|---|---|
| Mole fraction (x) | 0.4981 |
| **Density (property value)** | **838.8** (4 significant digits) |
| Combined expanded uncertainty | 0.4 |

### 2. Temperature constraint

- **Confirmed:** Temperature = **298.15 K** (5 significant digits), phase = Liquid

### 3. Pressure constraint

- **Confirmed:** Pressure = **101 kPa** (3 significant digits, i.e., atmospheric), phase = Liquid

**Row count:** 1 matching datapoint returned; no truncation.

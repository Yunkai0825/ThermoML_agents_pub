# Q1.3 — Reference Statistics

| Variant | Model | Compactor Model | Status | API turns | Tool calls | Elapsed (s) |
|---|---|---|---:|---:|---:|---:|
| Flat / raw-ThermoML SQL | claude-opus-4-6 | claude-opus-4-6 | OK | 22 | 21 | 442.3 |

## Token usage

| Role | Calls | Input tokens | Output tokens | Cache-create | Cache-read |
|---|---:|---:|---:|---:|---:|
| Answering agent | 22 | 273486 | 10035 | 0 | 0 |
| Result compactor(s) | 21 | 63118 | 11138 | 0 | 0 |

## Turn budget

- API effort: high
- Soft escalation begins: turn 20
- Configured strikes: 3
- Hard final turn: 22
- Strikes issued: 3
- Forced final chance reached: True
- Fresh final context characters: 51513
- Fresh final context SHA-256: fafbe58166f1294dc375416cf3c9aa8e3616746a1d9573e9f929589827882b1d
- Tool request on final chance: False

# Q1.2 — Working Memory

Evidence returned to the answering model:

## 1. resolve_compound_ids

Both compounds resolved with exact name matches (score 100).

| Compound | ID | Formula | SMILES |
|----------|----|---------|--------|
| hexane | GLOBcomp_12 | C6H14 | CCCCCC |
| ethanol | GLOBcomp_2 | C2H6O | CCO |

## 2. resolve_property_ids

The query returned 19 property IDs covering common binary liquid mixture properties. Eight exact matches and several high-relevance fuzzy matches are included.

**Key GLOBprop IDs for binary liquid mixture properties:**

| GLOBprop ID | Property | Units | Group | Score |
|---|---|---|---|---|
| GLOBprop_1 | Mass density | kg/m3 | VolumetricProp | 100 |
| GLOBprop_4 | Viscosity | Pa*s | TransportProp | 100 |
| GLOBprop_9 | Molar heat capacity at constant pressure | J/K/mol | HeatCapacityAndDerivedProp | 100 |
| GLOBprop_28 | Excess molar volume | m3/mol | VolumetricProp | 100 |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing) | kJ/mol | ExcessPartialApparentEnergyProp | 85 |
| GLOBprop_8 | Speed of sound | m/s | RefractionSurfaceTensionSoundSpeed | 100 |
| GLOBprop_7 | Refractive index (Na D-line) | — | RefractionSurfaceTensionSoundSpeed | 100 |
| GLOBprop_13 | Surface tension liquid-gas | N/m | RefractionSurfaceTensionSoundSpeed | 100 |
| GLOBprop_5 | Vapor or sublimation pressure | kPa | VaporPBoilingTAzeotropTandP | 100 |
| GLOBprop_3 | Activity coefficient | — | ActivityFugacityOsmoticProp | 100 |
| GLOBprop_85 | Excess molar heat capacity | J/K/mol | ExcessPartialApparentEnergyProp | 60 |
| GLOBprop_97 | Excess molar Gibbs energy | kJ/mol | ExcessPartialApparentEnergyProp | 59 |

## 3. search_system_registry

**Summary:** Six data blocks were found for the binary ethanol (GLOBcomp_2) + hexane (GLOBcomp_12) system near 298.15 K, spanning **4 distinct liquid-phase properties** from 3 publications.

### Distinct Properties Measured

| Property | GLOBprop | Blocks | DOI | Points | Value Range |
|---|---|---|---|---|---|
| Mass density (kg/m³) | GLOBprop_1 | PROPblock_24 | 10.1016/j.jct.2007.02.008 | 39 | [650.4, 789.3] |
| Mass density (kg/m³) | GLOBprop_1 | PROPblock_10 | 10.1021/je800925v | 103 | [655.3, 790.2] |
| Viscosity (Pa·s) | GLOBprop_4 | PROPblock_9 | 10.1021/je800925v | 103 | [0.000287, 0.001377] |
| Refractive index (nD) | GLOBprop_7 | PROPblock_22 | 10.1016/j.jct.2007.02.008 | 39 | [1.35725, 1.37495] |
| Speed of sound (m/s) | GLOBprop_8 | PROPblock_23 | 10.1016/j.jct.2007.02.008 | 39 | [1046.0, 1160.0] |
| Surface tension (N/m) | GLOBprop_13 | PROPblock_5 | 10.1021/je700215z | 77 | [0.0162, 0.02211] |

### Block Details

| Block | DOI | GLOBlit | T range (K) | x(ethanol) range | Pressure constraint |
|---|---|---|---|---|---|
| PROPblock_22 | 10.1016/j.jct.2007.02.008 | GLOBlit_2800 | [293.15, 303.15] | [0.0, 1.0] | 101.0 kPa |
| PROPblock_23 | 10.1016/j.jct.2007.02.008 | GLOBlit_2800 | [293.15, 303.15] | [0.0, 1

## 4. search_system_registry

**⚠ Tool `search_system_registry` result discarded by subagent.**

1. **Explanation:** The search returned 0 results for excess/derived properties (excess molar volume, excess molar enthalpy, activity coefficients, vapor pressure) for hexane + ethanol near 298 K with the specified compound and property IDs. No data is available to extract.

2. **Refinement suggestions:**
   - **Broaden the temperature range** significantly (e.g., 273–353 K) to check whether any data exists at other temperatures.
   - **Remove the temperature filter entirely** to see if any excess/derived property blocks exist at all for this binary pair.
   - **Try alternative compound IDs** — hexane may be registered under a different global ID (e.g., "n-hexane" vs. "hexane"); verify with `search_compound_registry`.
   - **Search with fewer property filters** — try one property at a time (e.g., just `GLOBprop_28` for excess molar volume) to isolate which properties have data.
   - **Drop `system_scope: "declared"`** or try `system_scope: "any"` in case the system is registered differently.

## 5. search_blocks

Two blocks found for hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary at 298.15 K, 101.325 kPa, from DOI `10.1016/j.fluid.2005.08.001` (GLOBlit_294). Both excess molar enthalpy and excess molar volume data are available.

### Block Summary

| Block | Property | prop_id | pts | T (K) | P (kPa) | Variable |
|---|---|---|---|---|---|---|
| PROPblock_5 | Excess molar enthalpy (kJ/mol) | GLOBprop_17 | 17 | 298.15 | 101.325 | x(ethanol) |
| PROPblock_6 | Excess molar volume (m³/mol) | GLOBprop_28 | 23 | 298.15 | 101.325 | x(ethanol) |

### PROPblock_5 — H_E (kJ/mol)

| x(ethanol) | H_mix | ±U |
|---|---|---|
| 0.0544 | 0.28 | 0.0088 |
| 0.1056 | 0.4149 | 0.013 |
| 0.1994 | 0.5273 | 0.0164 |
| 0.2835 | 0.5687 | 0.0177 |
| 0.3592 | 0.5795 | 0.018 |
| 0.49 | 0.5637 | 0.0176 |
| 0.7125 | 0.4453 | 0.0139 |
| 0.8064 | 0.3546 | 0.0111 |
| 0.9528 | 0.1216 | 0.004 |

### PROPblock_6 — V_E (m³/mol)

| x(ethanol) | V_E | ±U |
|---|---|---|
| 0.0417 | 1.5e-07 | 8e-09 |
| 0.128 | 2.89e-07 | 8e-09 |
| 0.1998 | 3.54e-07 | 9e-09 |
| 0.2988 | 3.96e-07 | 9e-09

## 6. search_blocks

**Summary:** 9 data blocks found for hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary in 293–303 K, covering **8 distinct properties** across 5 DOIs. All blocks are liquid-phase, composition-dependent measurements.

| # | DOI | Block | Property | GLOBprop | Pts (raw→kept) | x(ethanol) range | T (K) | GLOBlit |
|---|-----|-------|----------|----------|-----------------|------------------|--------|---------|
| 1 | 10.1016/j.fluid.2005.08.001 | PROPblock_5 | Excess molar enthalpy (H_mix) | GLOBprop_17 | 17→9 | 0.0544–0.9528 | constrained | GLOBlit_294 |
| 2 | 10.1016/j.fluid.2005.08.001 | PROPblock_6 | Excess molar volume (V_E) | GLOBprop_28 | 23→9 | 0.0417–0.9497 | constrained | GLOBlit_294 |
| 3 | 10.1016/j.jct.2007.02.008 | PROPblock_22 | Refractive index (n_D) | GLOBprop_7 | 39→13 | 0–1 | 293.15–303.15 | GLOBlit_2800 |
| 4 | 10.1016/j.jct.2007.02.008 | PROPblock_23 | Speed of sound (u) | GLOBprop_8 | 39→24 | 0–1 | 293.15–303.15 | GLOBlit_2800 |
| 5 | 10.1016/j.jct.2007.02.008 | PROPblock_24 | Mass density (ρ) | GLOBprop_1 | 39→15 | 0–1 | 293.15–303.15 | GLOBlit_2800 |
| 6 | 10.1021/je0497303 | PROPblock_8 | Binary diffusion coefficient | GLOBprop_29 | 9→2 | 0–1

## 7. search_property_dk

# Raw tool result: `search_property_dk`

Serialization: `json`

```json
{
  "n_results": 1,
  "query": [
    "GLOBprop_29"
  ],
  "results": [
    {
      "base_prop_ID": "binary_diffusion_coefficient_m2_s",
      "card_type": "domain_knowledge",
      "compact_md": "# PCS-DK | binary_diffusion_coefficient_m2_s\n\n**Name:** Binary diffusion coefficient, m2/s\n**Group:** TransportProp\n**Class:** transport\n**Unit:** m2/s\n**Flags:** intensive\n**Typical vars:** Temperature, K (68%); Pressure, kPa (34%); Mole fraction (17%); Solvent: Mole fraction (16%); Amount concentration (molarity), mol/dm3 (11%)\n**Usage:** 540 instances | 115 papers | rank #30\n**Top methods:** Taylor dispersion method (49%); Open capillary (6%); custom: pressure decay method (4%)\n\n## Structured Knowledge\n- **definition:** physical_quantity=\n- **phase_applicability:** component_specific=False; requires_solvent=False\n- **uncertainty_profile:** typical_relative_uncertainty=\n- **data_patterns:** multi_property_frequency=\n\n## Description Sections\n",
      "component_linked": false,
      "domain_knowledge": {
        "description_block": {
          "common_pitfalls": "",
          "common_variable_patterns": "",
          "data_quality_indicators": "",
          "measurement_methods_overview": "",
          "phase_behavior": "",
          "physical_meaning": "",
          "property_overview": "",
          "related_properties": "",
          "reporting_checklist": "",
          "thermodynamic_context": "",
          "typical_applications": "",
          "unit_conventions": ""
        },
        "structured_block": {
          "data_patterns": {
            "co_measured_properties": [],
            "common_block_patterns": [],
            "multi_property_frequency": "",
            "typical_n_points": {
              "median": null,
              "p10": null,
              "p90": null
            }
          },
          "definition": {
            "can_derive": [],
            "derived_from": [],
            "mathematical_definition": null,
            "physical_quantity": "",
            "related_properties": [],
            "sign_convention": null,
            "thermodynamic_definition": null
          },
          "measurement_context": {
            "applicable_presentations": [],
            "applicable_ref_state_types": null,
            "applicable_standard_states": null,
            "primary_methods": [],
            "typical_variable_patterns": []
          },
          "phase_applicability": {
            "applicable_phases": [],
            "applicable_system_types": [],
            "component_specific": false,
            "phase_equilibrium_type": null,
            "primary_phases": [],
            "requires_solvent": false
          },
          "typical_ranges": {
            "pressure_range_kPa": {
              "max": null,
              "min": null,
              "note": null
            },
            "reference_values": [],
            "temperature_range_K": {
              "max": null,
              "min": null,
              "note": null
            },
            "value_range": {
              "max": null,
              "min": null,
              "note": null,
              "unit": ""
            }
          },
          "uncertainty_profile": {
            "best_achievable_uncertainty": null,
            "dominant_uncertainty_sources": [],
            "method_dependent_quality": null,
            "quality_indicators": [],
            "typical_relative_uncertainty": ""
          }
        }
      },
      "identity": {
        "aliases": [],
        "db_usage": {
          "common_constraints": [],
          "common_methods": [
            {
              "count": 263,
              "fraction": 0.487,
              "method_name": "Taylor dispersion method",
              "method_type": "standard"
            },
            {
              "count": 30,
              "fraction": 0.0556,
              "method_name": "Open capillary",
              "method_type": "standard"
            },
            {
              "count": 22,
              "fraction": 0.0407,
              "method_name": "custom: pressure decay method",
              "method_type": "custom"
            },
            {
              "count": 18,
              "fraction": 0.0333,
              "method_name": "Dispersion",
              "method_type": "standard"
            },
            {
              "count": 17,
              "fraction": 0.0315,
              "method_name": "custom: TAYLOR:UFactor:2",
              "method_type": "custom"
            }
          ],
          "common_variables": [
            {
              "count": 368,
              "fraction": 0.6815,
              "var_name": "Temperature, K"
            },
            {
              "count": 185,
              "fraction": 0.3426,
              "var_name": "Pressure, kPa"
            },
            {
              "count": 94,
              "fraction": 0.1741,
              "var_name": "Mole fraction"
            },
            {
              "count": 87,
              "fraction": 0.1611,
              "var_name": "Solvent: Mole fraction"
            },
            {
              "count": 57,
              "fraction": 0.1056,
              "var_name": "Amount concentration (molarity), mol/dm3"
            }
          ],
          "n_papers": 115,
          "presentation_distribution": {
            "difference": 0,
            "direct": 540,
            "other": 0,
            "ratio": 0
          },
          "rank_in_group": 3,
          "rank_overall": 30,
          "system_type_distribution": {
            "binary": 436,
            "quaternary_plus": 0,
            "ternary": 104,
            "unary": 0
          },
          "total_instances": 540
        },
        "dimension": null,
        "is_apparent": false,
        "is_excess": false,
        "is_intensive": true,
        "is_molar": false,
        "is_partial": false,
        "name": "Binary diffusion coefficient, m2/s",
        "property_class": "transport",
        "property_group": "TransportProp",
        "symbol": null,
        "thermoml_name": "Binary diffusion coefficient, m2/s",
        "typical_constraints": [],
        "typical_variables": [
          {
            "role": "primary_axis",
            "usage_fraction": 0.6815,
            "var_name": "Temperature, K",
            "var_type": "eTemperature"
          },
          {
            "role": "environmental",
            "usage_fraction": 0.3426,
            "var_name": "Pressure, kPa",
            "var_type": "ePressure"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1741,
            "var_name": "Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1611,
            "var_name": "Solvent: Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1056,
            "var_name": "Amount concentration (molarity), mol/dm3",
            "var_type": "eComponentComposition"
          }
        ],
        "unit": "m2/s"
      },
      "match_score": 100,
      "match_type": "global_id",
      "prop_ID": "binary_diffusion_coefficient_m2_s",
      "prop_id": "binary_diffusion_coefficient_m2_s",
      "prop_num_id": "GLOBprop_29"
    }
  ]
}
```

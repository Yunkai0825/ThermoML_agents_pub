# Q1.2 — Result

**Prompt:** For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 7
- **API turns:** 6
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 150.3s
- **Timed out:** False

## Answer

Now I have a complete picture. Let me compile the comprehensive answer.

---

## Thermophysical Properties Measured for Hexane + Ethanol (Binary Liquid) Near 25 °C

Based on the ThermoML database, **8 distinct thermophysical properties** have been measured for the binary liquid mixture of **hexane (GLOBcomp_12) + ethanol (GLOBcomp_2)** in the temperature range ~293–303 K (near 25 °C). The data come from **5 different publications**:

### Summary Table

| # | Property | Units | GLOBprop ID | Source DOI | Data Points |
|---|----------|-------|-------------|------------|-------------|
| 1 | **Mass density** (ρ) | kg/m³ | GLOBprop_1 | 10.1016/j.jct.2007.02.008; 10.1021/je800925v | 39; 103 |
| 2 | **Viscosity** (η) | Pa·s | GLOBprop_4 | 10.1021/je800925v | 103 |
| 3 | **Refractive index** (n_D) | — | GLOBprop_7 | 10.1016/j.jct.2007.02.008 | 39 |
| 4 | **Speed of sound** (u) | m/s | GLOBprop_8 | 10.1016/j.jct.2007.02.008 | 39 |
| 5 | **Surface tension** (γ) | N/m | GLOBprop_13 | 10.1021/je700215z | 77 |
| 6 | **Excess molar enthalpy** (H^E) | kJ/mol | GLOBprop_17 | 10.1016/j.fluid.2005.08.001 | 17 |
| 7 | **Excess molar volume** (V^E) | m³/mol | GLOBprop_28 | 10.1016/j.fluid.2005.08.001 | 23 |
| 8 | **Binary diffusion coefficient** (D₁₂) | m²/s | GLOBprop_29 | 10.1021/je0497303 | 9 |

### Chemical Insights

This is a classic **non-ideal binary system** combining a nonpolar alkane (hexane) with a hydrogen-bonding alcohol (ethanol). The measured properties reflect the rich thermodynamic behavior of this system:

- **Excess molar enthalpy (H^E):** Positive values (endothermic mixing), peaking near x(ethanol) ≈ 0.36 at ~0.58 kJ/mol. This reflects the energy cost of disrupting ethanol's hydrogen-bond network upon mixing with hexane, which is only partially compensated by weaker dispersion interactions.

- **Excess molar volume (V^E):** Also positive, indicating volume expansion upon mixing — a hallmark of systems where the unlike molecular interactions are weaker than the like–like interactions.

- **Density** ranges from ~650 kg/m³ (hexane-rich) to ~789 kg/m³ (ethanol-rich), spanning the pure-component values.

- **Viscosity** varies from ~0.29 mPa·s (hexane-rich) to ~1.38 mPa·s (ethanol-rich), reflecting ethanol's much higher viscosity due to hydrogen bonding.

- **Surface tension, refractive index, and speed of sound** provide complementary structural and intermolecular interaction information across the full composition range.

- **Binary diffusion coefficient** data are available at the dilute limits (x = 0 and x = 1), characterizing mutual diffusion in this system.

All measurements were conducted at atmospheric pressure (~101 kPa). The data span the full composition range from pure hexane to pure ethanol, so equimolar (x = 0.5) data are included or can be interpolated from the reported compositions.

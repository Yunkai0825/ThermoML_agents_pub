# Q1.2 — Run History

**Prompt:** For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

This file is the audit record. For SQL calls, the fenced raw Markdown is
the exact payload supplied to the task-directed agentic compactor.

## Soft-budget events

```json
[]
```

## Step 1: resolve_compound_ids

### Call arguments

```json
{
  "queries": [
    "hexane",
    "ethanol"
  ],
  "purpose": "Identify the GLOB compound IDs for hexane and ethanol to search for binary mixture data",
  "tasks": [
    "Find the canonical GLOBcomp ID for hexane",
    "Find the canonical GLOBcomp ID for ethanol"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `resolve_compound_ids`

Serialization: `json`

```json
{
  "n_results": 2,
  "results": [
    {
      "common_name": "hexane",
      "comp_id": "hexane",
      "comp_num_id": "GLOBcomp_12",
      "formula": "C6H14",
      "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
      "match_type": "name_exact",
      "n_papers": 607,
      "score": 100,
      "smiles": "CCCCCC",
      "standard_inchi": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3"
    },
    {
      "common_name": "ethanol",
      "comp_id": "ethanol",
      "comp_num_id": "GLOBcomp_2",
      "formula": "C2H6O",
      "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
      "match_type": "name_exact",
      "n_papers": 1880,
      "score": 100,
      "smiles": "CCO",
      "standard_inchi": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3"
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
resolve_compound_ids: 2 match(es).

| # | comp_num_id | Name | Formula | SMILES | Score | Match |
|---|-------------|------|---------|--------|-------|-------|
| 1 | GLOBcomp_12 | hexane | C6H14 | CCCCCC | 100 | name_exact |
| 2 | GLOBcomp_2 | ethanol | C2H6O | CCO | 100 | name_exact |

```

### Model-visible result

```markdown
Both compounds resolved with exact name matches (score 100).

| Compound | ID | Formula | SMILES |
|----------|----|---------|--------|
| hexane | GLOBcomp_12 | C6H14 | CCCCCC |
| ethanol | GLOBcomp_2 | C2H6O | CCO |
```

### Integrity and timing

- Raw SHA-256: 4d53d9551db1e7e10fbd11c2e63ef50af7aa8c7d3d067647e84e5a729f6e2c7c
- Raw characters: 816
- Hardcoded-compacted characters: 287
- Model-visible characters: 216
- Agentic verdict: KEEP
- Tool elapsed: 0.003s
- Compactor elapsed: 5.002s
- Total elapsed: 5.005s

## Step 2: resolve_property_ids

### Call arguments

```json
{
  "queries": [
    "density",
    "viscosity",
    "heat capacity",
    "excess molar volume",
    "excess molar enthalpy",
    "speed of sound",
    "refractive index",
    "surface tension",
    "vapor pressure",
    "activity coefficient"
  ],
  "purpose": "Identify property IDs that might be measured for a binary liquid mixture",
  "tasks": [
    "Find GLOBprop IDs for common mixture thermophysical properties"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `resolve_property_ids`

Serialization: `json`

```json
{
  "n_results": 19,
  "results": [
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 23070,
      "prop_group": "VolumetricProp",
      "prop_id": "mass_density_kg_m3",
      "prop_name": "Mass density, kg/m3",
      "prop_num_id": "GLOBprop_1",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 8475,
      "prop_group": "TransportProp",
      "prop_id": "viscosity_pa_s",
      "prop_name": "Viscosity, Pa*s",
      "prop_num_id": "GLOBprop_4",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 3113,
      "prop_group": "HeatCapacityAndDerivedProp",
      "prop_id": "molar_heat_capacity_at_constant_pressure_j_k_mol",
      "prop_name": "Molar heat capacity at constant pressure, J/K/mol",
      "prop_num_id": "GLOBprop_9",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 546,
      "prop_group": "VolumetricProp",
      "prop_id": "excess_molar_volume_m3_mol",
      "prop_name": "Excess molar volume, m3/mol",
      "prop_num_id": "GLOBprop_28",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 1703,
      "prop_group": "ExcessPartialApparentEnergyProp",
      "prop_id": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
      "prop_name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
      "prop_num_id": "GLOBprop_17",
      "score": 85
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 760,
      "prop_group": "HeatCapacityAndDerivedProp",
      "prop_id": "molar_enthalpy_kj_mol",
      "prop_name": "Molar enthalpy, kJ/mol",
      "prop_num_id": "GLOBprop_22",
      "score": 65
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 12,
      "prop_group": "ExcessPartialApparentEnergyProp",
      "prop_id": "apparent_molar_enthalpy_kj_mol",
      "prop_name": "Apparent molar enthalpy, kJ/mol",
      "prop_num_id": "GLOBprop_90",
      "score": 61
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 23,
      "prop_group": "ExcessPartialApparentEnergyProp",
      "prop_id": "excess_molar_heat_capacity_j_k_mol",
      "prop_name": "Excess molar heat capacity, J/K/mol",
      "prop_num_id": "GLOBprop_85",
      "score": 60
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 5,
      "prop_group": "ExcessPartialApparentEnergyProp",
      "prop_id": "excess_molar_gibbs_energy_kj_mol",
      "prop_name": "Excess molar Gibbs energy, kJ/mol",
      "prop_num_id": "GLOBprop_97",
      "score": 59
    },
    {
      "comp_id_linked": 1,
      "match_type": "name_fuzzy",
      "n_blocks": 41,
      "prop_group": "ExcessPartialApparentEnergyProp",
      "prop_id": "partial_molar_enthalpy_kj_mol_{DOIcomp_id}",
      "prop_name": "Partial molar enthalpy, kJ/mol",
      "prop_num_id": "GLOBprop_75",
      "score": 58
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 521,
      "prop_group": "HeatCapacityAndDerivedProp",
      "prop_id": "molar_entropy_j_k_mol",
      "prop_name": "Molar entropy, J/K/mol",
      "prop_num_id": "GLOBprop_30",
      "score": 51
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 1970,
      "prop_group": "ExcessPartialApparentEnergyProp",
      "prop_id": "molar_enthalpy_of_solution_kj_mol",
      "prop_name": "Molar enthalpy of solution, kJ/mol",
      "prop_num_id": "GLOBprop_15",
      "score": 50
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 376,
      "prop_group": "ReactionStateChangeProp",
      "prop_id": "molar_enthalpy_of_reaction_kj_mol",
      "prop_name": "Molar enthalpy of reaction, kJ/mol",
      "prop_num_id": "GLOBprop_36",
      "score": 50
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 246,
      "prop_group": "ExcessPartialApparentEnergyProp",
      "prop_id": "molar_enthalpy_of_dilution_kj_mol",
      "prop_name": "Molar enthalpy of dilution, kJ/mol",
      "prop_num_id": "GLOBprop_46",
      "score": 50
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 5781,
      "prop_group": "RefractionSurfaceTensionSoundSpeed",
      "prop_id": "speed_of_sound_m_s",
      "prop_name": "Speed of sound, m/s",
      "prop_num_id": "GLOBprop_8",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 6772,
      "prop_group": "RefractionSurfaceTensionSoundSpeed",
      "prop_id": "refractive_index_na_dline",
      "prop_name": "Refractive index (Na D-line)",
      "prop_num_id": "GLOBprop_7",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 2525,
      "prop_group": "RefractionSurfaceTensionSoundSpeed",
      "prop_id": "surface_tension_liquidgas_n_m",
      "prop_name": "Surface tension liquid-gas, N/m",
      "prop_num_id": "GLOBprop_13",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 8067,
      "prop_group": "VaporPBoilingTAzeotropTandP",
      "prop_id": "vapor_or_sublimation_pressure_kpa",
      "prop_name": "Vapor or sublimation pressure, kPa",
      "prop_num_id": "GLOBprop_5",
      "score": 100
    },
    {
      "comp_id_linked": 1,
      "match_type": "prop_id_exact",
      "n_blocks": 9696,
      "prop_group": "ActivityFugacityOsmoticProp",
      "prop_id": "activity_coefficient_{DOIcomp_id}",
      "prop_name": "Activity coefficient",
      "prop_num_id": "GLOBprop_3",
      "score": 100
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
resolve_property_ids: 19 match(es).

| # | prop_num_id | Name | Group | Score | Match |
|---|-------------|------|-------|-------|-------|
| 1 | GLOBprop_1 | Mass density, kg/m3 | VolumetricProp | 100 | prop_id_exact |
| 2 | GLOBprop_4 | Viscosity, Pa*s | TransportProp | 100 | prop_id_exact |
| 3 | GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | HeatCapacityAndDerivedProp | 100 | prop_id_exact |
| 4 | GLOBprop_28 | Excess molar volume, m3/mol | VolumetricProp | 100 | prop_id_exact |
| 5 | GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | ExcessPartialApparentEnergyProp | 85 | name_fuzzy |
| 6 | GLOBprop_22 | Molar enthalpy, kJ/mol | HeatCapacityAndDerivedProp | 65 | name_fuzzy |
| 7 | GLOBprop_90 | Apparent molar enthalpy, kJ/mol | ExcessPartialApparentEnergyProp | 61 | name_fuzzy |
| 8 | GLOBprop_85 | Excess molar heat capacity, J/K/mol | ExcessPartialApparentEnergyProp | 60 | name_fuzzy |
| 9 | GLOBprop_97 | Excess molar Gibbs energy, kJ/mol | ExcessPartialApparentEnergyProp | 59 | name_fuzzy |
| 10 | GLOBprop_75 | Partial molar enthalpy, kJ/mol | ExcessPartialApparentEnergyProp | 58 | name_fuzzy |
| 11 | GLOBprop_30 | Molar entropy, J/K/mol | HeatCapacityAndDerivedProp | 51 | name_fuzzy |
| 12 | GLOBprop_15 | Molar enthalpy of solution, kJ/mol | ExcessPartialApparentEnergyProp | 50 | name_fuzzy |
| 13 | GLOBprop_36 | Molar enthalpy of reaction, kJ/mol | ReactionStateChangeProp | 50 | name_fuzzy |
| 14 | GLOBprop_46 | Molar enthalpy of dilution, kJ/mol | ExcessPartialApparentEnergyProp | 50 | name_fuzzy |
| 15 | GLOBprop_8 | Speed of sound, m/s | RefractionSurfaceTensionSoundSpeed | 100 | prop_id_exact |
| 16 | GLOBprop_7 | Refractive index (Na D-line) | RefractionSurfaceTensionSoundSpeed | 100 | prop_id_exact |
| 17 | GLOBprop_13 | Surface tension liquid-gas, N/m | RefractionSurfaceTensionSoundSpeed | 100 | prop_id_exact |
| 18 | GLOBprop_5 | Vapor or sublimation pressure, kPa | VaporPBoilingTAzeotropTandP | 100 | prop_id_exact |
| 19 | GLOBprop_3 | Activity coefficient | ActivityFugacityOsmoticProp | 100 | prop_id_exact |

```

### Model-visible result

```markdown
The query returned 19 property IDs covering common binary liquid mixture properties. Eight exact matches and several high-relevance fuzzy matches are included.

**Key GLOBprop IDs for binary liquid mixture properties:**

| GLOBprop ID | Property | Units | Group | Score |
|---|---|---|---|---|
| GLOBprop_1 | Mass density | kg/m3 | VolumetricProp | 100 |
| GLOBprop_4 | Viscosity | Pa*s | TransportProp | 100 |
| GLOBprop_9 | Molar heat capacity at constant pressure | J/K/mol | HeatCapacityAndDerivedProp | 100 |
| GLOBprop_28 | Excess molar volume | m3/mol | VolumetricProp | 100 |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing) | kJ/mol | ExcessPartialApparentEnergyProp | 85 |
| GLOBprop_8 | Speed of sound | m/s | RefractionSurfaceTensionSoundSpeed | 100 |
| GLOBprop_7 | Refractive index (Na D-line) | — | RefractionSurfaceTensionSoundSpeed | 100 |
| GLOBprop_13 | Surface tension liquid-gas | N/m | RefractionSurfaceTensionSoundSpeed | 100 |
| GLOBprop_5 | Vapor or sublimation pressure | kPa | VaporPBoilingTAzeotropTandP | 100 |
| GLOBprop_3 | Activity coefficient | — | ActivityFugacityOsmoticProp | 100 |
| GLOBprop_85 | Excess molar heat capacity | J/K/mol | ExcessPartialApparentEnergyProp | 60 |
| GLOBprop_97 | Excess molar Gibbs energy | kJ/mol | ExcessPartialApparentEnergyProp | 59 |
```

### Integrity and timing

- Raw SHA-256: 523574a223357ced01a1ab97f57b229b9bcbaf93f66b0743431de88a96ce643f
- Raw characters: 5979
- Hardcoded-compacted characters: 2102
- Model-visible characters: 1319
- Agentic verdict: KEEP
- Tool elapsed: 0.013s
- Compactor elapsed: 9.659s
- Total elapsed: 9.672s

## Step 3: search_system_registry

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_12",
    "GLOBcomp_2"
  ],
  "system_type": "binary",
  "temperature_range": [
    293,
    303
  ],
  "purpose": "Find all data blocks for the binary hexane + ethanol system near 25 °C to identify which properties have been measured",
  "tasks": [
    "List all distinct properties measured for the hexane + ethanol binary near 298.15 K",
    "Identify the data blocks and their associated properties"
  ],
  "limit": 100
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_system_registry`

Serialization: `json`

```json
{
  "n_results": 6,
  "query_params": {
    "compound": [
      "GLOBcomp_12",
      "GLOBcomp_2"
    ],
    "include_reactions": false,
    "limit": 100,
    "system_scope": "declared",
    "system_type": "binary",
    "temperature_range": [
      293,
      303
    ]
  },
  "results": [
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_22",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "compact_md": "# REG-PM | 10.1016/j.jct.2007.02.008 | PROPblock_22\n\n**Literature:** GLOBlit_2800 | 2007-per-rod-3\n**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 39 pts\n**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane\n**Variables:** BLKvar_1→GLOBvar_1:temperature_k [293.15, 303.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]\n**Constraints:** BLKconstr_1→GLOBconstr_1:pressure_kpa=101.0\n**Properties:**\n  - BLKprop_1→GLOBprop_7:refractive_index_na_dline | GLOBmeas_3:standard_abbe_refractometry [1.35725, 1.37495]\n**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid; BLKconstr_1:phase→GLOBphase_1:Liquid\n",
      "compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "declared_compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_n_components": 2,
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "lit_num_id": "GLOBlit_2800",
      "n_components": 2,
      "n_datapoints": 39,
      "notes": null,
      "parent_n_datapoints": 39,
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "property_phase"
        },
        {
          "owner_id": "BLKvar_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKvar_2",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKconstr_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "RefractionSurfaceTensionSoundSpeed",
          "meas_ID": "standard_abbe_refractometry",
          "meas_num_id": "GLOBmeas_3",
          "method_custom": null,
          "method_standard": "Standard Abbe refractometry",
          "name": "Refractive index (Na D-line)",
          "prop_ID": "refractive_index_na_dline",
          "prop_num_id": "GLOBprop_7",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "max": 1.37495,
            "mean": 1.366087,
            "min": 1.35725,
            "n": 39,
            "name": "Refractive index (Na D-line)",
            "std": 0.004865
          },
          "range_max": 1.37495,
          "range_min": 1.35725,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "max": 303.15,
            "min": 293.15,
            "n_unique": 3,
            "name": "Temperature, K"
          },
          "range_max": 303.15,
          "range_min": 293.15,
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 13,
            "name": "Mole fraction"
          },
          "range_max": 1.0,
          "range_min": 0.0,
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_23",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "compact_md": "# REG-PM | 10.1016/j.jct.2007.02.008 | PROPblock_23\n\n**Literature:** GLOBlit_2800 | 2007-per-rod-3\n**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 39 pts\n**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane\n**Variables:** BLKvar_1→GLOBvar_1:temperature_k [293.15, 303.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]\n**Constraints:** BLKconstr_1→GLOBconstr_1:pressure_kpa=101.0\n**Properties:**\n  - BLKprop_1→GLOBprop_8:speed_of_sound_m_s | GLOBmeas_7:sing_around_technique_in_a_fixed_path_interferometer [1046.0, 1160.0]\n**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid; BLKconstr_1:phase→GLOBphase_1:Liquid\n",
      "compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "declared_compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_n_components": 2,
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "lit_num_id": "GLOBlit_2800",
      "n_components": 2,
      "n_datapoints": 39,
      "notes": null,
      "parent_n_datapoints": 39,
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "property_phase"
        },
        {
          "owner_id": "BLKvar_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKvar_2",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKconstr_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "RefractionSurfaceTensionSoundSpeed",
          "meas_ID": "sing_around_technique_in_a_fixed_path_interferometer",
          "meas_num_id": "GLOBmeas_7",
          "method_custom": null,
          "method_standard": "Sing-around technique in a fixed-path interferometer",
          "name": "Speed of sound, m/s",
          "prop_ID": "speed_of_sound_m_s",
          "prop_num_id": "GLOBprop_8",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "max": 1160.0,
            "mean": 1088.25641,
            "min": 1046.0,
            "n": 39,
            "name": "Speed of sound, m/s",
            "std": 29.810558
          },
          "range_max": 1160.0,
          "range_min": 1046.0,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "max": 303.15,
            "min": 293.15,
            "n_unique": 3,
            "name": "Temperature, K"
          },
          "range_max": 303.15,
          "range_min": 293.15,
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 13,
            "name": "Mole fraction"
          },
          "range_max": 1.0,
          "range_min": 0.0,
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_24",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "compact_md": "# REG-PM | 10.1016/j.jct.2007.02.008 | PROPblock_24\n\n**Literature:** GLOBlit_2800 | 2007-per-rod-3\n**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 39 pts\n**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane\n**Variables:** BLKvar_1→GLOBvar_1:temperature_k [293.15, 303.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]\n**Constraints:** BLKconstr_1→GLOBconstr_1:pressure_kpa=101.0\n**Properties:**\n  - BLKprop_1→GLOBprop_1:mass_density_kg_m3 | GLOBmeas_134:vibtub_ufactor_4 [650.4, 789.3]\n**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid; BLKconstr_1:phase→GLOBphase_1:Liquid\n",
      "compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "declared_compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_n_components": 2,
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "lit_num_id": "GLOBlit_2800",
      "n_components": 2,
      "n_datapoints": 39,
      "notes": null,
      "parent_n_datapoints": 39,
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "property_phase"
        },
        {
          "owner_id": "BLKvar_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKvar_2",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKconstr_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "VolumetricProp",
          "meas_ID": "vibtub_ufactor_4",
          "meas_num_id": "GLOBmeas_134",
          "method_custom": "VIBTUB:UFactor:4",
          "method_standard": null,
          "name": "Mass density, kg/m3",
          "prop_ID": "mass_density_kg_m3",
          "prop_num_id": "GLOBprop_1",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "max": 789.3,
            "mean": 704.112821,
            "min": 650.4,
            "n": 39,
            "name": "Mass density, kg/m3",
            "std": 44.155706
          },
          "range_max": 789.3,
          "range_min": 650.4,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "max": 303.15,
            "min": 293.15,
            "n_unique": 3,
            "name": "Temperature, K"
          },
          "range_max": 303.15,
          "range_min": 293.15,
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 13,
            "name": "Mole fraction"
          },
          "range_max": 1.0,
          "range_min": 0.0,
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_5",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "compact_md": "# REG-PM | 10.1021/je700215z | PROPblock_5\n\n**Literature:** GLOBlit_10821 | 2007-gin-vil-1\n**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 77 pts\n**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane\n**Variables:** BLKvar_1→GLOBvar_1:temperature_k [283.15, 313.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0855, 0.932]\n**Properties:**\n  - BLKprop_1→GLOBprop_13:surface_tension_liquidgas_n_m | GLOBmeas_342:dropv_ufactor_2 [0.0162, 0.02211]\n**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid\n",
      "compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [],
      "declared_compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_n_components": 2,
      "declared_system_type": "binary",
      "doi": "10.1021/je700215z",
      "lit_id": "2007-gin-vil-1",
      "lit_num_id": "GLOBlit_10821",
      "n_components": 2,
      "n_datapoints": 77,
      "notes": null,
      "parent_n_datapoints": 77,
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "property_phase"
        },
        {
          "owner_id": "BLKvar_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKvar_2",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "RefractionSurfaceTensionSoundSpeed",
          "meas_ID": "dropv_ufactor_2",
          "meas_num_id": "GLOBmeas_342",
          "method_custom": "DROPV:UFactor:2",
          "method_standard": null,
          "name": "Surface tension liquid-gas, N/m",
          "prop_ID": "surface_tension_liquidgas_n_m",
          "prop_num_id": "GLOBprop_13",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.02211,
            "mean": 0.018729,
            "min": 0.0162,
            "n": 77,
            "name": "Surface tension liquid-gas, N/m",
            "std": 0.001475
          },
          "range_max": 0.02211,
          "range_min": 0.0162,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "max": 313.15,
            "min": 283.15,
            "n_unique": 7,
            "name": "Temperature, K"
          },
          "range_max": 313.15,
          "range_min": 283.15,
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "max": 0.932,
            "min": 0.0855,
            "n_unique": 11,
            "name": "Mole fraction"
          },
          "range_max": 0.932,
          "range_min": 0.0855,
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_10",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "compact_md": "# REG-PM | 10.1021/je800925v | PROPblock_10\n\n**Literature:** GLOBlit_11449 | 2009-fei-cae-0\n**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 103 pts\n**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_2→GLOBcomp_12 hexane\n**Variables:** BLKvar_1→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]; BLKvar_2→GLOBvar_1:temperature_k [273.15, 298.15]\n**Properties:**\n  - BLKprop_1→GLOBprop_1:mass_density_kg_m3 | GLOBmeas_147:vibtub_ufactor_16 [655.3, 790.2]\n**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid\n",
      "compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [],
      "declared_compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_n_components": 2,
      "declared_system_type": "binary",
      "doi": "10.1021/je800925v",
      "lit_id": "2009-fei-cae-0",
      "lit_num_id": "GLOBlit_11449",
      "n_components": 2,
      "n_datapoints": 103,
      "notes": null,
      "parent_n_datapoints": 103,
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "property_phase"
        },
        {
          "owner_id": "BLKvar_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKvar_2",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "VolumetricProp",
          "meas_ID": "vibtub_ufactor_16",
          "meas_num_id": "GLOBmeas_147",
          "method_custom": "VIBTUB:UFactor:16",
          "method_standard": null,
          "name": "Mass density, kg/m3",
          "prop_ID": "mass_density_kg_m3",
          "prop_num_id": "GLOBprop_1",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "max": 790.2,
            "mean": 715.298058,
            "min": 655.3,
            "n": 103,
            "name": "Mass density, kg/m3",
            "std": 32.754736
          },
          "range_max": 790.2,
          "range_min": 655.3,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 11,
            "name": "Mole fraction"
          },
          "range_max": 1.0,
          "range_min": 0.0,
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "max": 298.15,
            "min": 273.15,
            "n_unique": 11,
            "name": "Temperature, K"
          },
          "range_max": 298.15,
          "range_min": 273.15,
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_9",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "compact_md": "# REG-PM | 10.1021/je800925v | PROPblock_9\n\n**Literature:** GLOBlit_11449 | 2009-fei-cae-0\n**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 103 pts\n**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_2→GLOBcomp_12 hexane\n**Variables:** BLKvar_1→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]; BLKvar_2→GLOBvar_1:temperature_k [273.15, 298.15]\n**Properties:**\n  - BLKprop_1→GLOBprop_4:viscosity_pa_s | GLOBmeas_284:concyl_ufactor_8 [0.000287, 0.001377]\n**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid\n",
      "compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [],
      "declared_compounds": [
        {
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_n_components": 2,
      "declared_system_type": "binary",
      "doi": "10.1021/je800925v",
      "lit_id": "2009-fei-cae-0",
      "lit_num_id": "GLOBlit_11449",
      "n_components": 2,
      "n_datapoints": 103,
      "notes": null,
      "parent_n_datapoints": 103,
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "property_phase"
        },
        {
          "owner_id": "BLKvar_1",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        },
        {
          "owner_id": "BLKvar_2",
          "phase": "Liquid",
          "phase_id": "liquid",
          "phase_num_id": "GLOBphase_1",
          "role": "phase"
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "TransportProp",
          "meas_ID": "concyl_ufactor_8",
          "meas_num_id": "GLOBmeas_284",
          "method_custom": "CONCYL:UFactor:8",
          "method_standard": null,
          "name": "Viscosity, Pa*s",
          "prop_ID": "viscosity_pa_s",
          "prop_num_id": "GLOBprop_4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.001377,
            "mean": 0.000607,
            "min": 0.000287,
            "n": 103,
            "name": "Viscosity, Pa*s",
            "std": 0.000273
          },
          "range_max": 0.001377,
          "range_min": 0.000287,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 11,
            "name": "Mole fraction"
          },
          "range_max": 1.0,
          "range_min": 0.0,
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "max": 298.15,
            "min": 273.15,
            "n_unique": 11,
            "name": "Temperature, K"
          },
          "range_max": 298.15,
          "range_min": 273.15,
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
search_system_registry: 6 search targets found.

| # | DOI | Block | Target | Type | nComp | Compounds | Points |
|---|-----|-------|--------|------|-------|-----------|--------|
| 1 | 10.1016/j.jct.2007.02.008 | PROPblock_22 | declared | binary | 2 | ethanol, hexane | 39 |
| 2 | 10.1016/j.jct.2007.02.008 | PROPblock_23 | declared | binary | 2 | ethanol, hexane | 39 |
| 3 | 10.1016/j.jct.2007.02.008 | PROPblock_24 | declared | binary | 2 | ethanol, hexane | 39 |
| 4 | 10.1021/je700215z | PROPblock_5 | declared | binary | 2 | ethanol, hexane | 77 |
| 5 | 10.1021/je800925v | PROPblock_10 | declared | binary | 2 | ethanol, hexane | 103 |
| 6 | 10.1021/je800925v | PROPblock_9 | declared | binary | 2 | ethanol, hexane | 103 |

---
# REG-PM | 10.1016/j.jct.2007.02.008 | PROPblock_22

**Literature:** GLOBlit_2800 | 2007-per-rod-3
**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 39 pts
**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane
**Variables:** BLKvar_1→GLOBvar_1:temperature_k [293.15, 303.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]
**Constraints:** BLKconstr_1→GLOBconstr_1:pressure_kpa=101.0
**Properties:**
  - BLKprop_1→GLOBprop_7:refractive_index_na_dline | GLOBmeas_3:standard_abbe_refractometry [1.35725, 1.37495]
**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid; BLKconstr_1:phase→GLOBphase_1:Liquid


---
# REG-PM | 10.1016/j.jct.2007.02.008 | PROPblock_23

**Literature:** GLOBlit_2800 | 2007-per-rod-3
**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 39 pts
**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane
**Variables:** BLKvar_1→GLOBvar_1:temperature_k [293.15, 303.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]
**Constraints:** BLKconstr_1→GLOBconstr_1:pressure_kpa=101.0
**Properties:**
  - BLKprop_1→GLOBprop_8:speed_of_sound_m_s | GLOBmeas_7:sing_around_technique_in_a_fixed_path_interferometer [1046.0, 1160.0]
**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid; BLKconstr_1:phase→GLOBphase_1:Liquid


---
# REG-PM | 10.1016/j.jct.2007.02.008 | PROPblock_24

**Literature:** GLOBlit_2800 | 2007-per-rod-3
**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 39 pts
**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane
**Variables:** BLKvar_1→GLOBvar_1:temperature_k [293.15, 303.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]
**Constraints:** BLKconstr_1→GLOBconstr_1:pressure_kpa=101.0
**Properties:**
  - BLKprop_1→GLOBprop_1:mass_density_kg_m3 | GLOBmeas_134:vibtub_ufactor_4 [650.4, 789.3]
**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid; BLKconstr_1:phase→GLOBphase_1:Liquid


---
# REG-PM | 10.1021/je700215z | PROPblock_5

**Literature:** GLOBlit_10821 | 2007-gin-vil-1
**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 77 pts
**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_4→GLOBcomp_12 hexane
**Variables:** BLKvar_1→GLOBvar_1:temperature_k [283.15, 313.15]; BLKvar_2→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0855, 0.932]
**Properties:**
  - BLKprop_1→GLOBprop_13:surface_tension_liquidgas_n_m | GLOBmeas_342:dropv_ufactor_2 [0.0162, 0.02211]
**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid


---
# REG-PM | 10.1021/je800925v | PROPblock_10

**Literature:** GLOBlit_11449 | 2009-fei-cae-0
**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 103 pts
**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_2→GLOBcomp_12 hexane
**Variables:** BLKvar_1→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]; BLKvar_2→GLOBvar_1:temperature_k [273.15, 298.15]
**Properties:**
  - BLKprop_1→GLOBprop_1:mass_density_kg_m3 | GLOBmeas_147:vibtub_ufactor_16 [655.3, 790.2]
**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid


---
# REG-PM | 10.1021/je800925v | PROPblock_9

**Literature:** GLOBlit_11449 | 2009-fei-cae-0
**Type:** GLOBblocktype_1 | PureOrMixtureData | binary | 2 components | 103 pts
**Compounds:** DOIcomp_1→GLOBcomp_2 ethanol; DOIcomp_2→GLOBcomp_12 hexane
**Variables:** BLKvar_1→GLOBvar_2:mole_fraction_DOIcomp_1 [0.0, 1.0]; BLKvar_2→GLOBvar_1:temperature_k [273.15, 298.15]
**Properties:**
  - BLKprop_1→GLOBprop_4:viscosity_pa_s | GLOBmeas_284:concyl_ufactor_8 [0.000287, 0.001377]
**Phases:** BLKprop_1:property_phase→GLOBphase_1:Liquid; BLKvar_1:phase→GLOBphase_1:Liquid; BLKvar_2:phase→GLOBphase_1:Liquid


```

### Model-visible result

```markdown
**Summary:** Six data blocks were found for the binary ethanol (GLOBcomp_2) + hexane (GLOBcomp_12) system near 298.15 K, spanning **4 distinct liquid-phase properties** from 3 publications.

### Distinct Properties Measured

| Property | GLOBprop | Blocks | DOI | Points | Value Range |
|---|---|---|---|---|---|
| Mass density (kg/m³) | GLOBprop_1 | PROPblock_24 | 10.1016/j.jct.2007.02.008 | 39 | [650.4, 789.3] |
| Mass density (kg/m³) | GLOBprop_1 | PROPblock_10 | 10.1021/je800925v | 103 | [655.3, 790.2] |
| Viscosity (Pa·s) | GLOBprop_4 | PROPblock_9 | 10.1021/je800925v | 103 | [0.000287, 0.001377] |
| Refractive index (nD) | GLOBprop_7 | PROPblock_22 | 10.1016/j.jct.2007.02.008 | 39 | [1.35725, 1.37495] |
| Speed of sound (m/s) | GLOBprop_8 | PROPblock_23 | 10.1016/j.jct.2007.02.008 | 39 | [1046.0, 1160.0] |
| Surface tension (N/m) | GLOBprop_13 | PROPblock_5 | 10.1021/je700215z | 77 | [0.0162, 0.02211] |

### Block Details

| Block | DOI | GLOBlit | T range (K) | x(ethanol) range | Pressure constraint |
|---|---|---|---|---|---|
| PROPblock_22 | 10.1016/j.jct.2007.02.008 | GLOBlit_2800 | [293.15, 303.15] | [0.0, 1.0] | 101.0 kPa |
| PROPblock_23 | 10.1016/j.jct.2007.02.008 | GLOBlit_2800 | [293.15, 303.15] | [0.0, 1
```

### Integrity and timing

- Raw SHA-256: 3d45637970bdbfacd3cbf5763c2ad846bc1e883d7bae298d996b50a8e3cfdeab
- Raw characters: 34582
- Hardcoded-compacted characters: 4751
- Model-visible characters: 1238
- Agentic verdict: KEEP
- Tool elapsed: 11.767s
- Compactor elapsed: 14.020s
- Total elapsed: 25.789s

## Step 4: search_system_registry

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_12",
    "GLOBcomp_2"
  ],
  "system_type": "binary",
  "temperature_range": [
    293,
    303
  ],
  "property": [
    "GLOBprop_28",
    "GLOBprop_17",
    "GLOBprop_85",
    "GLOBprop_97",
    "GLOBprop_3",
    "GLOBprop_5"
  ],
  "purpose": "Check for excess/derived properties (excess volume, excess enthalpy, activity coefficient, vapor pressure) for hexane+ethanol near 25 °C",
  "tasks": [
    "Find any blocks reporting excess molar volume, excess molar enthalpy, activity coefficients, or vapor pressure for hexane+ethanol near 298 K"
  ],
  "limit": 50
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_system_registry`

Serialization: `json`

```json
{
  "n_results": 0,
  "query_params": {
    "compound": [
      "GLOBcomp_12",
      "GLOBcomp_2"
    ],
    "include_reactions": false,
    "limit": 50,
    "property": [
      "GLOBprop_28",
      "GLOBprop_17",
      "GLOBprop_85",
      "GLOBprop_97",
      "GLOBprop_3",
      "GLOBprop_5"
    ],
    "system_scope": "declared",
    "system_type": "binary",
    "temperature_range": [
      293,
      303
    ]
  },
  "results": []
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
**search_system_registry: 0 results.**

```

### Model-visible result

```markdown
**⚠ Tool `search_system_registry` result discarded by subagent.**

1. **Explanation:** The search returned 0 results for excess/derived properties (excess molar volume, excess molar enthalpy, activity coefficients, vapor pressure) for hexane + ethanol near 298 K with the specified compound and property IDs. No data is available to extract.

2. **Refinement suggestions:**
   - **Broaden the temperature range** significantly (e.g., 273–353 K) to check whether any data exists at other temperatures.
   - **Remove the temperature filter entirely** to see if any excess/derived property blocks exist at all for this binary pair.
   - **Try alternative compound IDs** — hexane may be registered under a different global ID (e.g., "n-hexane" vs. "hexane"); verify with `search_compound_registry`.
   - **Search with fewer property filters** — try one property at a time (e.g., just `GLOBprop_28` for excess molar volume) to isolate which properties have data.
   - **Drop `system_scope: "declared"`** or try `system_scope: "any"` in case the system is registered differently.
```

### Integrity and timing

- Raw SHA-256: 62707f8c3d11cdabd5004a3295fcbb3c08fc73a2609074b6778cddd0df321597
- Raw characters: 520
- Hardcoded-compacted characters: 39
- Model-visible characters: 1073
- Agentic verdict: DISCARD
- Tool elapsed: 11.356s
- Compactor elapsed: 9.144s
- Total elapsed: 20.500s

## Step 5: search_blocks

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_12",
    "GLOBcomp_2"
  ],
  "system_type": "binary",
  "temperature_range": [
    293,
    303
  ],
  "property": [
    "GLOBprop_28",
    "GLOBprop_17"
  ],
  "purpose": "Search for excess molar volume and excess molar enthalpy data for hexane+ethanol binary near 25 °C",
  "tasks": [
    "Find blocks with excess molar volume or excess molar enthalpy for hexane+ethanol"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "n_results": 2,
  "query_params": {
    "compound": [
      "GLOBcomp_12",
      "GLOBcomp_2"
    ],
    "limit": 50,
    "property": [
      "GLOBprop_28",
      "GLOBprop_17"
    ],
    "system_scope": "declared",
    "system_type": "binary",
    "temperature_range": [
      293,
      303
    ]
  },
  "results": [
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_5",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_5 | P/M | binary | 17 pts | GLOBlit_294\n\n### Reference\n**lit_id:** 2005-kwa-rez-0\n**Title:** Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_17 | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | GLOBmeas_12 | flow_calorimetry | ExcessPartialApparentEnergyProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(3 extrema) | 17 pts → 9 kept (RDP)\n| x(ethanol,Liquid) | H_mix(kJ/mol) | ±U |\n|---|---|---|\n| 0.0544 | 0.28 | 0.0088 |\n| 0.1056 | 0.4149 | 0.013 |\n| 0.1994 | 0.5273 | 0.0164 |\n| 0.2835 | 0.5687 | 0.0177 |\n| 0.3592 | 0.5795 | 0.018 |\n| 0.49 | 0.5637 | 0.0176 |\n| 0.7125 | 0.4453 | 0.0139 |\n| 0.8064 | 0.3546 | 0.0111 |\n| 0.9528 | 0.1216 | 0.004 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 6,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.325
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 6,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.325
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Flow calorimetry"
        ],
        "n_points": 17,
        "phases": [
          "Liquid"
        ],
        "property_group": "ExcessPartialApparentEnergyProp",
        "property_names": [
          "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.5795,
            "mean": 0.458288,
            "min": 0.1216,
            "n": 17,
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "std": 0.136978
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.9528,
            "min": 0.0544,
            "n_unique": 17,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_num_id": "GLOBlit_294",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 17,
      "paper_title": "Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane",
      "parent_n_datapoints": 17,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "ExcessPartialApparentEnergyProp",
          "meas_ID": "flow_calorimetry",
          "meas_num_id": "GLOBmeas_12",
          "method_custom": null,
          "method_standard": "Flow calorimetry",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "prop_num_id": "GLOBprop_17",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_6",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_6 | P/M | binary | 23 pts | GLOBlit_294\n\n### Reference\n**lit_id:** 2005-kwa-rez-0\n**Title:** Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_28 | excess_molar_volume_m3_mol | GLOBmeas_29 | calculated_with_densities_of_this_investigation | VolumetricProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(5 extrema) | 23 pts → 9 kept (RDP)\n| x(ethanol,Liquid) | V_E(cm³/mol) | ±U |\n|---|---|---|\n| 0.0417 | 1.5e-07 | 8e-09 |\n| 0.128 | 2.89e-07 | 8e-09 |\n| 0.1998 | 3.54e-07 | 9e-09 |\n| 0.2988 | 3.96e-07 | 9e-09 |\n| 0.4524 | 4.12e-07 | 9e-09 |\n| 0.5985 | 3.84e-07 | 9e-09 |\n| 0.7607 | 3e-07 | 8e-09 |\n| 0.8508 | 2.18e-07 | 8e-09 |\n| 0.9497 | 8.8e-08 | 8e-09 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 6,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.325
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 6,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.325
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Calculated with densities of this investigation"
        ],
        "n_points": 23,
        "phases": [
          "Liquid"
        ],
        "property_group": "VolumetricProp",
        "property_names": [
          "Excess molar volume, m3/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.0,
            "mean": 0.0,
            "min": 0.0,
            "n": 23,
            "name": "Excess molar volume, m3/mol",
            "std": 0.0
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.9497,
            "min": 0.0417,
            "n_unique": 23,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_num_id": "GLOBlit_294",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 23,
      "paper_title": "Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane",
      "parent_n_datapoints": 23,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "VolumetricProp",
          "meas_ID": "calculated_with_densities_of_this_investigation",
          "meas_num_id": "GLOBmeas_29",
          "method_custom": null,
          "method_standard": "Calculated with densities of this investigation",
          "name": "Excess molar volume, m3/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "excess_molar_volume_m3_mol",
          "prop_num_id": "GLOBprop_28",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
search_blocks: 2 search targets found.

| # | DOI | Block | Target | System | Points | Properties | Score |
|---|-----|-------|--------|--------|--------|------------|-------|
| 1 | 10.1016/j.fluid.2005.08.001 | PROPblock_5 | declared | binary | 17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | 100 |
| 2 | 10.1016/j.fluid.2005.08.001 | PROPblock_6 | declared | binary | 23 | Excess molar volume, m3/mol | 100 |

---
## PROPblock_5 | P/M | binary | 17 pts | GLOBlit_294

### Reference
**lit_id:** 2005-kwa-rez-0
**Title:** Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |
| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_17 | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | GLOBmeas_12 | flow_calorimetry | ExcessPartialApparentEnergyProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |

### Conditions
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** non-monotonic(3 extrema) | 17 pts → 9 kept (RDP)
| x(ethanol,Liquid) | H_mix(kJ/mol) | ±U |
|---|---|---|
| 0.0544 | 0.28 | 0.0088 |
| 0.1056 | 0.4149 | 0.013 |
| 0.1994 | 0.5273 | 0.0164 |
| 0.2835 | 0.5687 | 0.0177 |
| 0.3592 | 0.5795 | 0.018 |
| 0.49 | 0.5637 | 0.0176 |
| 0.7125 | 0.4453 | 0.0139 |
| 0.8064 | 0.3546 | 0.0111 |
| 0.9528 | 0.1216 | 0.004 |


---
## PROPblock_6 | P/M | binary | 23 pts | GLOBlit_294

### Reference
**lit_id:** 2005-kwa-rez-0
**Title:** Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |
| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_28 | excess_molar_volume_m3_mol | GLOBmeas_29 | calculated_with_densities_of_this_investigation | VolumetricProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |

### Conditions
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** non-monotonic(5 extrema) | 23 pts → 9 kept (RDP)
| x(ethanol,Liquid) | V_E(cm³/mol) | ±U |
|---|---|---|
| 0.0417 | 1.5e-07 | 8e-09 |
| 0.128 | 2.89e-07 | 8e-09 |
| 0.1998 | 3.54e-07 | 9e-09 |
| 0.2988 | 3.96e-07 | 9e-09 |
| 0.4524 | 4.12e-07 | 9e-09 |
| 0.5985 | 3.84e-07 | 9e-09 |
| 0.7607 | 3e-07 | 8e-09 |
| 0.8508 | 2.18e-07 | 8e-09 |
| 0.9497 | 8.8e-08 | 8e-09 |


```

### Model-visible result

```markdown
Two blocks found for hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary at 298.15 K, 101.325 kPa, from DOI `10.1016/j.fluid.2005.08.001` (GLOBlit_294). Both excess molar enthalpy and excess molar volume data are available.

### Block Summary

| Block | Property | prop_id | pts | T (K) | P (kPa) | Variable |
|---|---|---|---|---|---|---|
| PROPblock_5 | Excess molar enthalpy (kJ/mol) | GLOBprop_17 | 17 | 298.15 | 101.325 | x(ethanol) |
| PROPblock_6 | Excess molar volume (m³/mol) | GLOBprop_28 | 23 | 298.15 | 101.325 | x(ethanol) |

### PROPblock_5 — H_E (kJ/mol)

| x(ethanol) | H_mix | ±U |
|---|---|---|
| 0.0544 | 0.28 | 0.0088 |
| 0.1056 | 0.4149 | 0.013 |
| 0.1994 | 0.5273 | 0.0164 |
| 0.2835 | 0.5687 | 0.0177 |
| 0.3592 | 0.5795 | 0.018 |
| 0.49 | 0.5637 | 0.0176 |
| 0.7125 | 0.4453 | 0.0139 |
| 0.8064 | 0.3546 | 0.0111 |
| 0.9528 | 0.1216 | 0.004 |

### PROPblock_6 — V_E (m³/mol)

| x(ethanol) | V_E | ±U |
|---|---|---|
| 0.0417 | 1.5e-07 | 8e-09 |
| 0.128 | 2.89e-07 | 8e-09 |
| 0.1998 | 3.54e-07 | 9e-09 |
| 0.2988 | 3.96e-07 | 9e-09
```

### Integrity and timing

- Raw SHA-256: 8dce764a2e8994c8f8b81dd92231f0c85f8b7a4428f17c0b28d63057237bf0b5
- Raw characters: 17082
- Hardcoded-compacted characters: 3581
- Model-visible characters: 1054
- Agentic verdict: KEEP
- Tool elapsed: 0.409s
- Compactor elapsed: 10.164s
- Total elapsed: 10.575s

## Step 6: search_blocks

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_12",
    "GLOBcomp_2"
  ],
  "system_type": "binary",
  "temperature_range": [
    293,
    303
  ],
  "purpose": "Comprehensive search for ALL properties measured for hexane+ethanol binary near 25 °C, without property filter",
  "tasks": [
    "Find all data blocks for hexane+ethanol binary near 298 K regardless of property type",
    "Identify any additional properties beyond those already found"
  ],
  "limit": 50
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "n_results": 9,
  "query_params": {
    "compound": [
      "GLOBcomp_12",
      "GLOBcomp_2"
    ],
    "limit": 50,
    "system_scope": "declared",
    "system_type": "binary",
    "temperature_range": [
      293,
      303
    ]
  },
  "results": [
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_5",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_5 | P/M | binary | 17 pts | GLOBlit_294\n\n### Reference\n**lit_id:** 2005-kwa-rez-0\n**Title:** Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_17 | excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | GLOBmeas_12 | flow_calorimetry | ExcessPartialApparentEnergyProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(3 extrema) | 17 pts → 9 kept (RDP)\n| x(ethanol,Liquid) | H_mix(kJ/mol) | ±U |\n|---|---|---|\n| 0.0544 | 0.28 | 0.0088 |\n| 0.1056 | 0.4149 | 0.013 |\n| 0.1994 | 0.5273 | 0.0164 |\n| 0.2835 | 0.5687 | 0.0177 |\n| 0.3592 | 0.5795 | 0.018 |\n| 0.49 | 0.5637 | 0.0176 |\n| 0.7125 | 0.4453 | 0.0139 |\n| 0.8064 | 0.3546 | 0.0111 |\n| 0.9528 | 0.1216 | 0.004 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 6,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.325
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 6,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.325
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Flow calorimetry"
        ],
        "n_points": 17,
        "phases": [
          "Liquid"
        ],
        "property_group": "ExcessPartialApparentEnergyProp",
        "property_names": [
          "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.5795,
            "mean": 0.458288,
            "min": 0.1216,
            "n": 17,
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "std": 0.136978
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.9528,
            "min": 0.0544,
            "n_unique": 17,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_num_id": "GLOBlit_294",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 17,
      "paper_title": "Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane",
      "parent_n_datapoints": 17,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "ExcessPartialApparentEnergyProp",
          "meas_ID": "flow_calorimetry",
          "meas_num_id": "GLOBmeas_12",
          "method_custom": null,
          "method_standard": "Flow calorimetry",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "prop_num_id": "GLOBprop_17",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_6",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_6 | P/M | binary | 23 pts | GLOBlit_294\n\n### Reference\n**lit_id:** 2005-kwa-rez-0\n**Title:** Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_28 | excess_molar_volume_m3_mol | GLOBmeas_29 | calculated_with_densities_of_this_investigation | VolumetricProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(5 extrema) | 23 pts → 9 kept (RDP)\n| x(ethanol,Liquid) | V_E(cm³/mol) | ±U |\n|---|---|---|\n| 0.0417 | 1.5e-07 | 8e-09 |\n| 0.128 | 2.89e-07 | 8e-09 |\n| 0.1998 | 3.54e-07 | 9e-09 |\n| 0.2988 | 3.96e-07 | 9e-09 |\n| 0.4524 | 4.12e-07 | 9e-09 |\n| 0.5985 | 3.84e-07 | 9e-09 |\n| 0.7607 | 3e-07 | 8e-09 |\n| 0.8508 | 2.18e-07 | 8e-09 |\n| 0.9497 | 8.8e-08 | 8e-09 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 6,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.325
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 6,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.325
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Calculated with densities of this investigation"
        ],
        "n_points": 23,
        "phases": [
          "Liquid"
        ],
        "property_group": "VolumetricProp",
        "property_names": [
          "Excess molar volume, m3/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.0,
            "mean": 0.0,
            "min": 0.0,
            "n": 23,
            "name": "Excess molar volume, m3/mol",
            "std": 0.0
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.9497,
            "min": 0.0417,
            "n_unique": 23,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_num_id": "GLOBlit_294",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 23,
      "paper_title": "Excess molar volumes and excess molar enthalpies of binary and ternary mixtures of (ethanol or 1-butanol), triethylamine and n-hexane",
      "parent_n_datapoints": 23,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "VolumetricProp",
          "meas_ID": "calculated_with_densities_of_this_investigation",
          "meas_num_id": "GLOBmeas_29",
          "method_custom": null,
          "method_standard": "Calculated with densities of this investigation",
          "name": "Excess molar volume, m3/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "excess_molar_volume_m3_mol",
          "prop_num_id": "GLOBprop_28",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_22",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_22 | P/M | binary | 39 pts | GLOBlit_2800\n**Composition projections:** 2 subsystem(s); types=binary,unary; search-eligible=1; referenced points=3\n\n### Reference\n**lit_id:** 2007-per-rod-3\n**Title:** Mixing properties of binary mixtures presenting azeotropes at several temperatures\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_7 | refractive_index_na_dline | GLOBmeas_3 | standard_abbe_refractometry | RefractionSurfaceTensionSoundSpeed | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n| BLKvar_2 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): T: 293.15–303.15, x(ethanol): 0.0–1.0 | 39 pts → 13 kept (RDP)\n| T(K) | x(ethanol,Liquid) | n_D | ±U |\n|---|---|---|---|\n| 293.15 | 0.0 | 1.37495 | 0.00067 |\n| 293.15 | 0.1003 | 1.37368 | 0.00066 |\n| 293.15 | 0.3987 | 1.37037 | 0.00063 |\n| 293.15 | 0.6038 | 1.36775 | 0.00059 |\n| 293.15 | 1.0 | 1.36138 | 0.00052 |\n| 298.15 | 0.0 | 1.37217 | 0.00067 |\n| 298.15 | 0.2004 | 1.36981 | 0.00065 |\n| 298.15 | 0.4999 | 1.36652 | 0.00063 |\n| 298.15 | 0.6038 | 1.36522 | 0.00061 |\n| 298.15 | 1.0 | 1.35929 | 0.00052 |\n| 303.15 | 0.0 | 1.36936 | 0.00067 |\n| 303.15 | 0.6038 | 1.3626 | 0.00062 |\n| 303.15 | 1.0 | 1.35725 | 0.00051 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 2,
          "n_unique_points": 3,
          "system_types": [
            "binary",
            "unary"
          ]
        },
        "methods": [
          "Standard Abbe refractometry"
        ],
        "n_points": 39,
        "phases": [
          "Liquid"
        ],
        "property_group": "RefractionSurfaceTensionSoundSpeed",
        "property_names": [
          "Refractive index (Na D-line)"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 1.37495,
            "mean": 1.366087,
            "min": 1.35725,
            "n": 39,
            "name": "Refractive index (Na D-line)",
            "std": 0.004865
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 303.15,
            "min": 293.15,
            "n_unique": 3,
            "name": "Temperature, K"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 13,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_num_id": "GLOBlit_2800",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 39,
      "paper_title": "Mixing properties of binary mixtures presenting azeotropes at several temperatures",
      "parent_n_datapoints": 39,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "RefractionSurfaceTensionSoundSpeed",
          "meas_ID": "standard_abbe_refractometry",
          "meas_num_id": "GLOBmeas_3",
          "method_custom": null,
          "method_standard": "Standard Abbe refractometry",
          "name": "Refractive index (Na D-line)",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "refractive_index_na_dline",
          "prop_num_id": "GLOBprop_7",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_23",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_23 | P/M | binary | 39 pts | GLOBlit_2800\n**Composition projections:** 2 subsystem(s); types=binary,unary; search-eligible=1; referenced points=3\n\n### Reference\n**lit_id:** 2007-per-rod-3\n**Title:** Mixing properties of binary mixtures presenting azeotropes at several temperatures\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_8 | speed_of_sound_m_s | GLOBmeas_7 | sing_around_technique_in_a_fixed_path_interferometer | RefractionSurfaceTensionSoundSpeed | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n| BLKvar_2 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): T: 293.15–303.15, x(ethanol): 0.0–1.0 | 39 pts → 24 kept (RDP)\n| T(K) | x(ethanol,Liquid) | u(m/s) | ±U |\n|---|---|---|---|\n| 293.15 | 0.0 | 1100.0 | 2.0 |\n| 293.15 | 0.0469 | 1095.0 | 2.0 |\n| 293.15 | 0.2004 | 1091.0 | 2.0 |\n| 293.15 | 0.3987 | 1092.0 | 2.0 |\n| 293.15 | 0.6038 | 1099.0 | 2.0 |\n| 293.15 | 0.7992 | 1117.0 | 2.0 |\n| 293.15 | 0.9007 | 1134.0 | 2.0 |\n| 293.15 | 1.0 | 1160.0 | 2.0 |\n| 298.15 | 0.0 | 1078.0 | 2.0 |\n| 298.15 | 0.0469 | 1073.0 | 2.0 |\n| 298.15 | 0.2004 | 1069.0 | 2.0 |\n| 298.15 | 0.3987 | 1070.0 | 2.0 |\n| 298.15 | 0.6038 | 1078.0 | 2.0 |\n| 298.15 | 0.7992 | 1097.0 | 2.0 |\n| 298.15 | 0.9007 | 1115.0 | 2.0 |\n| 298.15 | 1.0 | 1143.0 | 2.0 |\n| 303.15 | 0.0 | 1055.0 | 2.0 |\n| 303.15 | 0.0469 | 1050.0 | 2.0 |\n| 303.15 | 0.308 | 1046.0 | 2.0 |\n| 303.15 | 0.4999 | 1052.0 | 2.0 |\n| 303.15 | 0.6769 | 1063.0 | 2.0 |\n| 303.15 | 0.7992 | 1078.0 | 2.0 |\n| 303.15 | 0.9007 | 1097.0 | 2.0 |\n| 303.15 | 1.0 | 1127.0 | 2.0 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 2,
          "n_unique_points": 3,
          "system_types": [
            "binary",
            "unary"
          ]
        },
        "methods": [
          "Sing-around technique in a fixed-path interferometer"
        ],
        "n_points": 39,
        "phases": [
          "Liquid"
        ],
        "property_group": "RefractionSurfaceTensionSoundSpeed",
        "property_names": [
          "Speed of sound, m/s"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 1160.0,
            "mean": 1088.25641,
            "min": 1046.0,
            "n": 39,
            "name": "Speed of sound, m/s",
            "std": 29.810558
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 303.15,
            "min": 293.15,
            "n_unique": 3,
            "name": "Temperature, K"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 13,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_num_id": "GLOBlit_2800",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 39,
      "paper_title": "Mixing properties of binary mixtures presenting azeotropes at several temperatures",
      "parent_n_datapoints": 39,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "RefractionSurfaceTensionSoundSpeed",
          "meas_ID": "sing_around_technique_in_a_fixed_path_interferometer",
          "meas_num_id": "GLOBmeas_7",
          "method_custom": null,
          "method_standard": "Sing-around technique in a fixed-path interferometer",
          "name": "Speed of sound, m/s",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "speed_of_sound_m_s",
          "prop_num_id": "GLOBprop_8",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_24",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_24 | P/M | binary | 39 pts | GLOBlit_2800\n**Composition projections:** 2 subsystem(s); types=binary,unary; search-eligible=1; referenced points=3\n\n### Reference\n**lit_id:** 2007-per-rod-3\n**Title:** Mixing properties of binary mixtures presenting azeotropes at several temperatures\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_1 | mass_density_kg_m3 | GLOBmeas_134 | vibtub_ufactor_4 | VolumetricProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n| BLKvar_2 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): T: 293.15–303.15, x(ethanol): 0.0–1.0 | 39 pts → 15 kept (RDP)\n| T(K) | x(ethanol,Liquid) | ρ(kg/m³) | ±U |\n|---|---|---|---|\n| 293.15 | 0.0 | 659.5 | 0.8 |\n| 293.15 | 0.308 | 678.7 | 0.7 |\n| 293.15 | 0.6038 | 709.1 | 0.7 |\n| 293.15 | 0.7992 | 739.9 | 0.6 |\n| 293.15 | 1.0 | 789.3 | 0.6 |\n| 298.15 | 0.0 | 654.9 | 0.8 |\n| 298.15 | 0.308 | 674.1 | 0.7 |\n| 298.15 | 0.6038 | 704.6 | 0.7 |\n| 298.15 | 0.7992 | 735.5 | 0.6 |\n| 298.15 | 1.0 | 785.1 | 0.6 |\n| 303.15 | 0.0 | 650.4 | 0.8 |\n| 303.15 | 0.308 | 669.4 | 0.8 |\n| 303.15 | 0.6038 | 700.0 | 0.7 |\n| 303.15 | 0.7992 | 731.0 | 0.7 |\n| 303.15 | 1.0 | 780.7 | 0.6 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 2,
          "n_unique_points": 3,
          "system_types": [
            "binary",
            "unary"
          ]
        },
        "methods": [
          "VIBTUB:UFactor:4"
        ],
        "n_points": 39,
        "phases": [
          "Liquid"
        ],
        "property_group": "VolumetricProp",
        "property_names": [
          "Mass density, kg/m3"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 789.3,
            "mean": 704.112821,
            "min": 650.4,
            "n": 39,
            "name": "Mass density, kg/m3",
            "std": 44.155706
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 303.15,
            "min": 293.15,
            "n_unique": 3,
            "name": "Temperature, K"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 13,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_num_id": "GLOBlit_2800",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 39,
      "paper_title": "Mixing properties of binary mixtures presenting azeotropes at several temperatures",
      "parent_n_datapoints": 39,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "VolumetricProp",
          "meas_ID": "vibtub_ufactor_4",
          "meas_num_id": "GLOBmeas_134",
          "method_custom": "VIBTUB:UFactor:4",
          "method_standard": null,
          "name": "Mass density, kg/m3",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "mass_density_kg_m3",
          "prop_num_id": "GLOBprop_1",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_8",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_8 | P/M | binary | 9 pts | GLOBlit_8445\n**Composition projections:** 2 subsystem(s); types=binary,unary; search-eligible=1; referenced points=1\n\n### Reference\n**lit_id:** 2005-bos-bar-0\n**Title:** Measurement of Diffusion Coefficients in Thermodynamically Nonideal Systems\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_3 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_8 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_29 | binary_diffusion_coefficient_m2_s | GLOBmeas_38 | taylor_dispersion_method | TransportProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_3 | DOIcomp_3 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.3 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(0 extrema) | 9 pts → 2 kept (RDP)\n| x(ethanol,Liquid) | Binary_diffusion(m2/s) | ±U |\n|---|---|---|\n| 0.0 | 5.74e-09 | 0.11 |\n| 1.0 | 1.6e-09 | 0.07 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_8",
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 3,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 4,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.3
        }
      ],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 4,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.3
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 2,
          "n_unique_points": 1,
          "system_types": [
            "binary",
            "unary"
          ]
        },
        "methods": [
          "Taylor dispersion method"
        ],
        "n_points": 9,
        "phases": [
          "Liquid"
        ],
        "property_group": "TransportProp",
        "property_names": [
          "Binary diffusion coefficient, m2/s"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.0,
            "mean": 0.0,
            "min": 0.0,
            "n": 9,
            "name": "Binary diffusion coefficient, m2/s",
            "std": 0.0
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 9,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_8",
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1021/je0497303",
      "lit_num_id": "GLOBlit_8445",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 9,
      "paper_title": "Measurement of Diffusion Coefficients in Thermodynamically Nonideal Systems",
      "parent_n_datapoints": 9,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "TransportProp",
          "meas_ID": "taylor_dispersion_method",
          "meas_num_id": "GLOBmeas_38",
          "method_custom": null,
          "method_standard": "Taylor dispersion method",
          "name": "Binary diffusion coefficient, m2/s",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "binary_diffusion_coefficient_m2_s",
          "prop_num_id": "GLOBprop_29",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_3",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_3",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_5",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_5 | P/M | binary | 77 pts | GLOBlit_10821\n\n### Reference\n**lit_id:** 2007-gin-vil-1\n**Title:** Study of the Temperature Dependence of Surface Tensions of Some Alkanol + Hexane Mixtures\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_4 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_13 | surface_tension_liquidgas_n_m | GLOBmeas_342 | dropv_ufactor_2 | RefractionSurfaceTensionSoundSpeed | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n| BLKvar_2 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n\n### Conditions\n**Phases:** Liquid; Air at 1 atmosphere\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): T: 283.15–303.15, x(ethanol): 0.0855–0.932 | 50 pts → 25 kept (RDP)\n| T(K) | x(ethanol,Liquid) | γ(N/m) | ±U |\n|---|---|---|---|\n| 283.15 | 0.0855 | 0.0197 | 0.00028 |\n| 283.15 | 0.4128 | 0.0199 | 0.00027 |\n| 283.15 | 0.5909 | 0.02026 | 0.00027 |\n| 283.15 | 0.8032 | 0.02105 | 0.00027 |\n| 283.15 | 0.932 | 0.02211 | 0.00028 |\n| 288.15 | 0.0855 | 0.01911 | 0.00027 |\n| 288.15 | 0.4128 | 0.01929 | 0.00027 |\n| 288.15 | 0.5909 | 0.01967 | 0.00027 |\n| 288.15 | 0.8032 | 0.02046 | 0.00027 |\n| 288.15 | 0.932 | 0.02164 | 0.00027 |\n| 293.15 | 0.0855 | 0.01857 | 0.00027 |\n| 293.15 | 0.2928 | 0.01857 | 0.00027 |\n| 293.15 | 0.5909 | 0.01902 | 0.00026 |\n| 293.15 | 0.7036 | 0.01936 | 0.00026 |\n| 293.15 | 0.8032 | 0.01988 | 0.00027 |\n| 293.15 | 0.932 | 0.02111 | 0.00027 |\n| 298.15 | 0.0855 | 0.01803 | 0.00027 |\n| 298.15 | 0.2928 | 0.01803 | 0.00026 |\n| 298.15 | 0.5909 | 0.01845 | 0.00026 |\n| 298.15 | 0.7036 | 0.0188 | 0.00026 |\n| 298.15 | 0.8032 | 0.01932 | 0.00026 |\n| 298.15 | 0.932 | 0.02064 | 0.00027 |\n| 303.15 | 0.0855 | 0.01749 | 0.00026 |\n| 303.15 | 0.2928 | 0.01746 | 0.00026 |\n| 303.15 | 0.5071 | 0.01772 | 0.00026 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {},
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "DROPV:UFactor:2"
        ],
        "n_points": 77,
        "phases": [
          "Liquid",
          "Air at 1 atmosphere"
        ],
        "property_group": "RefractionSurfaceTensionSoundSpeed",
        "property_names": [
          "Surface tension liquid-gas, N/m"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.02211,
            "mean": 0.018729,
            "min": 0.0162,
            "n": 77,
            "name": "Surface tension liquid-gas, N/m",
            "std": 0.001475
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 313.15,
            "min": 283.15,
            "n_unique": 7,
            "name": "Temperature, K"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 0.932,
            "min": 0.0855,
            "n_unique": 11,
            "name": "Mole fraction"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1021/je700215z",
      "lit_num_id": "GLOBlit_10821",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 77,
      "paper_title": "Study of the Temperature Dependence of Surface Tensions of Some Alkanol + Hexane Mixtures",
      "parent_n_datapoints": 77,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "RefractionSurfaceTensionSoundSpeed",
          "meas_ID": "dropv_ufactor_2",
          "meas_num_id": "GLOBmeas_342",
          "method_custom": "DROPV:UFactor:2",
          "method_standard": null,
          "name": "Surface tension liquid-gas, N/m",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "surface_tension_liquidgas_n_m",
          "prop_num_id": "GLOBprop_13",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_9",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_9 | P/M | binary | 103 pts | GLOBlit_11449\n**Composition projections:** 2 subsystem(s); types=binary,unary; search-eligible=1; referenced points=2\n\n### Reference\n**lit_id:** 2009-fei-cae-0\n**Title:** Viscosity and Density of Binary Mixtures of Ethyl Alcohol with n-Alkanes (C6, C8, and C10)\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_2 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_4 | viscosity_pa_s | GLOBmeas_284 | concyl_ufactor_8 | TransportProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n| BLKvar_2 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Conditions\n**Phases:** Liquid; Air at 1 atmosphere\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): x(ethanol): 0.0–0.496, T: 273.15–298.15 | 50 pts → 17 kept (RDP)\n| x(ethanol,Liquid) | T(K) | η | ±U |\n|---|---|---|---|\n| 0.0 | 293.15 | 0.0002979 | 3.84e-05 |\n| 0.0 | 298.15 | 0.0002865 | 3.81e-05 |\n| 0.101 | 273.15 | 0.0003638 | 4.01e-05 |\n| 0.101 | 298.15 | 0.0002953 | 3.84e-05 |\n| 0.198 | 273.15 | 0.0004 | 4.1e-05 |\n| 0.198 | 298.15 | 0.0003049 | 3.86e-05 |\n| 0.302 | 273.15 | 0.0004511 | 4.24e-05 |\n| 0.302 | 298.15 | 0.0003398 | 3.95e-05 |\n| 0.401 | 273.15 | 0.0005478 | 4.49e-05 |\n| 0.401 | 285.65 | 0.0004614 | 4.26e-05 |\n| 0.401 | 288.15 | 0.0004239 | 4.17e-05 |\n| 0.401 | 290.65 | 0.000433 | 4.19e-05 |\n| 0.401 | 293.15 | 0.0003995 | 4.1e-05 |\n| 0.401 | 295.65 | 0.0003949 | 4.09e-05 |\n| 0.401 | 298.15 | 0.0003755 | 4.04e-05 |\n| 0.496 | 273.15 | 0.0006415 | 4.73e-05 |\n| 0.496 | 280.65 | 0.0005741 | 4.55e-05 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {},
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 2,
          "n_unique_points": 2,
          "system_types": [
            "binary",
            "unary"
          ]
        },
        "methods": [
          "CONCYL:UFactor:8"
        ],
        "n_points": 103,
        "phases": [
          "Liquid",
          "Air at 1 atmosphere"
        ],
        "property_group": "TransportProp",
        "property_names": [
          "Viscosity, Pa*s"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.001377,
            "mean": 0.000607,
            "min": 0.000287,
            "n": 103,
            "name": "Viscosity, Pa*s",
            "std": 0.000273
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 11,
            "name": "Mole fraction"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 298.15,
            "min": 273.15,
            "n_unique": 11,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1021/je800925v",
      "lit_num_id": "GLOBlit_11449",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 103,
      "paper_title": "Viscosity and Density of Binary Mixtures of Ethyl Alcohol with n-Alkanes (C6, C8, and C10)",
      "parent_n_datapoints": 103,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "TransportProp",
          "meas_ID": "concyl_ufactor_8",
          "meas_num_id": "GLOBmeas_284",
          "method_custom": "CONCYL:UFactor:8",
          "method_standard": null,
          "name": "Viscosity, Pa*s",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "viscosity_pa_s",
          "prop_num_id": "GLOBprop_4",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_10",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_10 | P/M | binary | 103 pts | GLOBlit_11449\n**Composition projections:** 2 subsystem(s); types=binary,unary; search-eligible=1; referenced points=2\n\n### Reference\n**lit_id:** 2009-fei-cae-0\n**Title:** Viscosity and Density of Binary Mixtures of Ethyl Alcohol with n-Alkanes (C6, C8, and C10)\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_2 | ethanol | C2H6O |\n| DOIcomp_2 | GLOBcomp_12 | hexane | C6H14 |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_1 | mass_density_kg_m3 | GLOBmeas_147 | vibtub_ufactor_16 | VolumetricProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_2 | mole_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n| BLKvar_2 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Conditions\n**Phases:** Liquid; Air at 1 atmosphere\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): x(ethanol): 0.0–0.496, T: 273.15–298.15 | 50 pts → 12 kept (RDP)\n| x(ethanol,Liquid) | T(K) | ρ(kg/m³) | ±U |\n|---|---|---|---|\n| 0.0 | 293.15 | 659.8 | 2.8 |\n| 0.0 | 298.15 | 655.3 | 2.8 |\n| 0.101 | 273.15 | 688.8 | 2.7 |\n| 0.101 | 298.15 | 665.9 | 2.8 |\n| 0.198 | 273.15 | 694.5 | 2.6 |\n| 0.198 | 298.15 | 671.5 | 2.7 |\n| 0.302 | 273.15 | 702.0 | 2.6 |\n| 0.302 | 298.15 | 679.0 | 2.7 |\n| 0.401 | 273.15 | 712.1 | 2.5 |\n| 0.401 | 298.15 | 688.8 | 2.7 |\n| 0.496 | 273.15 | 721.4 | 2.5 |\n| 0.496 | 280.65 | 714.7 | 2.5 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [],
      "data_summary": {
        "compound_names": [
          "ethanol",
          "hexane"
        ],
        "constraints_summary": {},
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 2,
          "n_unique_points": 2,
          "system_types": [
            "binary",
            "unary"
          ]
        },
        "methods": [
          "VIBTUB:UFactor:16"
        ],
        "n_points": 103,
        "phases": [
          "Liquid",
          "Air at 1 atmosphere"
        ],
        "property_group": "VolumetricProp",
        "property_names": [
          "Mass density, kg/m3"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 790.2,
            "mean": 715.298058,
            "min": 655.3,
            "n": 103,
            "name": "Mass density, kg/m3",
            "std": 32.754736
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.0,
            "min": 0.0,
            "n_unique": 11,
            "name": "Mole fraction"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 298.15,
            "min": 273.15,
            "n_unique": 11,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H6O/c1-2-3/h3H,2H2,1H3",
          "SMILES": "CCO",
          "comp_num_id": "GLOBcomp_2",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "name": "ethanol",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H14/c1-3-5-6-4-2/h3-6H2,1-2H3",
          "SMILES": "CCCCCC",
          "comp_num_id": "GLOBcomp_12",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "name": "hexane",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1021/je800925v",
      "lit_num_id": "GLOBlit_11449",
      "match_criteria": [
        "compound",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 103,
      "paper_title": "Viscosity and Density of Binary Mixtures of Ethyl Alcohol with n-Alkanes (C6, C8, and C10)",
      "parent_n_datapoints": 103,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "VolumetricProp",
          "meas_ID": "vibtub_ufactor_16",
          "meas_num_id": "GLOBmeas_147",
          "method_custom": "VIBTUB:UFactor:16",
          "method_standard": null,
          "name": "Mass density, kg/m3",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "mass_density_kg_m3",
          "prop_num_id": "GLOBprop_1",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Mole fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "mole_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_2"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
search_blocks: 9 search targets found.

| # | DOI | Block | Target | System | Points | Properties | Score |
|---|-----|-------|--------|--------|--------|------------|-------|
| 1 | 10.1016/j.fluid.2005.08.001 | PROPblock_5 | declared | binary | 17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | 100 |
| 2 | 10.1016/j.fluid.2005.08.001 | PROPblock_6 | declared | binary | 23 | Excess molar volume, m3/mol | 100 |
| 3 | 10.1016/j.jct.2007.02.008 | PROPblock_22 | declared | binary | 39 | Refractive index (Na D-line) | 100 |
| 4 | 10.1016/j.jct.2007.02.008 | PROPblock_23 | declared | binary | 39 | Speed of sound, m/s | 100 |
| 5 | 10.1016/j.jct.2007.02.008 | PROPblock_24 | declared | binary | 39 | Mass density, kg/m3 | 100 |
| 6 | 10.1021/je0497303 | PROPblock_8 | declared | binary | 9 | Binary diffusion coefficient, m2/s | 100 |
| 7 | 10.1021/je700215z | PROPblock_5 | declared | binary | 77 | Surface tension liquid-gas, N/m | 100 |
| 8 | 10.1021/je800925v | PROPblock_9 | declared | binary | 103 | Viscosity, Pa*s | 100 |
| 9 | 10.1021/je800925v | PROPblock_10 | declared | binary | 103 | Mass density, kg/m3 | 100 |

---
## PROPblock_5 | P/M | binary | 17 pts | GLOBlit_294  [**10.1016/j.fluid.2005.08.001 / PROPblock_5**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_17
**Methods:** GLOBmeas_12
**Variables:** GLOBvar_2
**Ranges:** x(ethanol,Liquid) [0.0544..0.9528], H_mix(kJ/mol) [0.1216..0.5795]
**Constraints:** GLOBconstr_2=temperature_k, GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 9
**Topology:** non-monotonic(3 extrema) | 17 pts → 9 kept (RDP)

---
## PROPblock_6 | P/M | binary | 23 pts | GLOBlit_294  [**10.1016/j.fluid.2005.08.001 / PROPblock_6**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_28
**Methods:** GLOBmeas_29
**Variables:** GLOBvar_2
**Ranges:** x(ethanol,Liquid) [0.0417..0.9497], V_E(cm³/mol) [8.8e-08..4.12e-07]
**Constraints:** GLOBconstr_2=temperature_k, GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 9
**Topology:** non-monotonic(5 extrema) | 23 pts → 9 kept (RDP)

---
## PROPblock_22 | P/M | binary | 39 pts | GLOBlit_2800  [**10.1016/j.jct.2007.02.008 / PROPblock_22**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_7
**Methods:** GLOBmeas_3
**Variables:** GLOBvar_1, GLOBvar_2
**Ranges:** T(K) [293.15..303.15], x(ethanol,Liquid) [0..1], n_D [1.35725..1.37495]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 13
**Topology:** multi-variable(2): T: 293.15–303.15, x(ethanol): 0.0–1.0 | 39 pts → 13 kept (RDP)

---
## PROPblock_23 | P/M | binary | 39 pts | GLOBlit_2800  [**10.1016/j.jct.2007.02.008 / PROPblock_23**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_8
**Methods:** GLOBmeas_7
**Variables:** GLOBvar_1, GLOBvar_2
**Ranges:** T(K) [293.15..303.15], x(ethanol,Liquid) [0..1], u(m/s) [1046..1160]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 24
**Topology:** multi-variable(2): T: 293.15–303.15, x(ethanol): 0.0–1.0 | 39 pts → 24 kept (RDP)

---
## PROPblock_24 | P/M | binary | 39 pts | GLOBlit_2800  [**10.1016/j.jct.2007.02.008 / PROPblock_24**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_1
**Methods:** GLOBmeas_134
**Variables:** GLOBvar_1, GLOBvar_2
**Ranges:** T(K) [293.15..303.15], x(ethanol,Liquid) [0..1], ρ(kg/m³) [650.4..789.3]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 15
**Topology:** multi-variable(2): T: 293.15–303.15, x(ethanol): 0.0–1.0 | 39 pts → 15 kept (RDP)

---
## PROPblock_8 | P/M | binary | 9 pts | GLOBlit_8445  [**10.1021/je0497303 / PROPblock_8**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_29
**Methods:** GLOBmeas_38
**Variables:** GLOBvar_2
**Ranges:** x(ethanol,Liquid) [0..1], Binary_diffusion(m2/s) [1.6e-09..5.74e-09]
**Constraints:** GLOBconstr_2=temperature_k, GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 2
**Topology:** non-monotonic(0 extrema) | 9 pts → 2 kept (RDP)

---
## PROPblock_5 | P/M | binary | 77 pts | GLOBlit_10821  [**10.1021/je700215z / PROPblock_5**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_13
**Methods:** GLOBmeas_342
**Variables:** GLOBvar_1, GLOBvar_2
**Ranges:** T(K) [283.15..303.15], x(ethanol,Liquid) [0.0855..0.932], γ(N/m) [0.01746..0.02211]
**Phases:** Liquid; Air at 1 atmosphere
**Unc:** k=95%, Propagation, compiler
**Points:** 25
**Topology:** multi-variable(2): T: 283.15–303.15, x(ethanol): 0.0855–0.932 | 50 pts → 25 kept (RDP)

---
## PROPblock_9 | P/M | binary | 103 pts | GLOBlit_11449  [**10.1021/je800925v / PROPblock_9**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_4
**Methods:** GLOBmeas_284
**Variables:** GLOBvar_2, GLOBvar_1
**Ranges:** x(ethanol,Liquid) [0..0.496], T(K) [273.15..298.15], η [0.0002865..0.0006415]
**Phases:** Liquid; Air at 1 atmosphere
**Unc:** k=95%, Propagation, compiler
**Points:** 17
**Topology:** multi-variable(2): x(ethanol): 0.0–0.496, T: 273.15–298.15 | 50 pts → 17 kept (RDP)

---
## PROPblock_10 | P/M | binary | 103 pts | GLOBlit_11449  [**10.1021/je800925v / PROPblock_10**]
**Compounds:** GLOBcomp_2, GLOBcomp_12
**Properties:** GLOBprop_1
**Methods:** GLOBmeas_147
**Variables:** GLOBvar_2, GLOBvar_1
**Ranges:** x(ethanol,Liquid) [0..0.496], T(K) [273.15..298.15], ρ(kg/m³) [655.3..721.4]
**Phases:** Liquid; Air at 1 atmosphere
**Unc:** k=95%, Propagation, compiler
**Points:** 12
**Topology:** multi-variable(2): x(ethanol): 0.0–0.496, T: 273.15–298.15 | 50 pts → 12 kept (RDP)

```

### Model-visible result

```markdown
**Summary:** 9 data blocks found for hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary in 293–303 K, covering **8 distinct properties** across 5 DOIs. All blocks are liquid-phase, composition-dependent measurements.

| # | DOI | Block | Property | GLOBprop | Pts (raw→kept) | x(ethanol) range | T (K) | GLOBlit |
|---|-----|-------|----------|----------|-----------------|------------------|--------|---------|
| 1 | 10.1016/j.fluid.2005.08.001 | PROPblock_5 | Excess molar enthalpy (H_mix) | GLOBprop_17 | 17→9 | 0.0544–0.9528 | constrained | GLOBlit_294 |
| 2 | 10.1016/j.fluid.2005.08.001 | PROPblock_6 | Excess molar volume (V_E) | GLOBprop_28 | 23→9 | 0.0417–0.9497 | constrained | GLOBlit_294 |
| 3 | 10.1016/j.jct.2007.02.008 | PROPblock_22 | Refractive index (n_D) | GLOBprop_7 | 39→13 | 0–1 | 293.15–303.15 | GLOBlit_2800 |
| 4 | 10.1016/j.jct.2007.02.008 | PROPblock_23 | Speed of sound (u) | GLOBprop_8 | 39→24 | 0–1 | 293.15–303.15 | GLOBlit_2800 |
| 5 | 10.1016/j.jct.2007.02.008 | PROPblock_24 | Mass density (ρ) | GLOBprop_1 | 39→15 | 0–1 | 293.15–303.15 | GLOBlit_2800 |
| 6 | 10.1021/je0497303 | PROPblock_8 | Binary diffusion coefficient | GLOBprop_29 | 9→2 | 0–1
```

### Integrity and timing

- Raw SHA-256: 8c9ebbf29892119b54e763449c80f2abd3517e87c3b7acc3a3403c90e7300316
- Raw characters: 73062
- Hardcoded-compacted characters: 5780
- Model-visible characters: 1182
- Agentic verdict: KEEP
- Tool elapsed: 9.092s
- Compactor elapsed: 13.398s
- Total elapsed: 22.497s

## Step 7: search_property_dk

### Call arguments

```json
{
  "property": [
    "GLOBprop_29"
  ],
  "purpose": "Get the full name and details of GLOBprop_29 (binary diffusion coefficient)",
  "tasks": [
    "Confirm the property name and units for GLOBprop_29"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_property_dk`

Serialization: `json`

```json
{
  "n_results": 1,
  "query": [
    "GLOBprop_29"
  ],
  "results": [
    {
      "base_prop_ID": "binary_diffusion_coefficient_m2_s",
      "card_type": "domain_knowledge",
      "compact_md": "# PCS-DK | binary_diffusion_coefficient_m2_s\n\n**Name:** Binary diffusion coefficient, m2/s\n**Group:** TransportProp\n**Class:** transport\n**Unit:** m2/s\n**Flags:** intensive\n**Typical vars:** Temperature, K (68%); Pressure, kPa (34%); Mole fraction (17%); Solvent: Mole fraction (16%); Amount concentration (molarity), mol/dm3 (11%)\n**Usage:** 540 instances | 115 papers | rank #30\n**Top methods:** Taylor dispersion method (49%); Open capillary (6%); custom: pressure decay method (4%)\n\n## Structured Knowledge\n- **definition:** physical_quantity=\n- **phase_applicability:** component_specific=False; requires_solvent=False\n- **uncertainty_profile:** typical_relative_uncertainty=\n- **data_patterns:** multi_property_frequency=\n\n## Description Sections\n",
      "component_linked": false,
      "domain_knowledge": {
        "description_block": {
          "common_pitfalls": "",
          "common_variable_patterns": "",
          "data_quality_indicators": "",
          "measurement_methods_overview": "",
          "phase_behavior": "",
          "physical_meaning": "",
          "property_overview": "",
          "related_properties": "",
          "reporting_checklist": "",
          "thermodynamic_context": "",
          "typical_applications": "",
          "unit_conventions": ""
        },
        "structured_block": {
          "data_patterns": {
            "co_measured_properties": [],
            "common_block_patterns": [],
            "multi_property_frequency": "",
            "typical_n_points": {
              "median": null,
              "p10": null,
              "p90": null
            }
          },
          "definition": {
            "can_derive": [],
            "derived_from": [],
            "mathematical_definition": null,
            "physical_quantity": "",
            "related_properties": [],
            "sign_convention": null,
            "thermodynamic_definition": null
          },
          "measurement_context": {
            "applicable_presentations": [],
            "applicable_ref_state_types": null,
            "applicable_standard_states": null,
            "primary_methods": [],
            "typical_variable_patterns": []
          },
          "phase_applicability": {
            "applicable_phases": [],
            "applicable_system_types": [],
            "component_specific": false,
            "phase_equilibrium_type": null,
            "primary_phases": [],
            "requires_solvent": false
          },
          "typical_ranges": {
            "pressure_range_kPa": {
              "max": null,
              "min": null,
              "note": null
            },
            "reference_values": [],
            "temperature_range_K": {
              "max": null,
              "min": null,
              "note": null
            },
            "value_range": {
              "max": null,
              "min": null,
              "note": null,
              "unit": ""
            }
          },
          "uncertainty_profile": {
            "best_achievable_uncertainty": null,
            "dominant_uncertainty_sources": [],
            "method_dependent_quality": null,
            "quality_indicators": [],
            "typical_relative_uncertainty": ""
          }
        }
      },
      "identity": {
        "aliases": [],
        "db_usage": {
          "common_constraints": [],
          "common_methods": [
            {
              "count": 263,
              "fraction": 0.487,
              "method_name": "Taylor dispersion method",
              "method_type": "standard"
            },
            {
              "count": 30,
              "fraction": 0.0556,
              "method_name": "Open capillary",
              "method_type": "standard"
            },
            {
              "count": 22,
              "fraction": 0.0407,
              "method_name": "custom: pressure decay method",
              "method_type": "custom"
            },
            {
              "count": 18,
              "fraction": 0.0333,
              "method_name": "Dispersion",
              "method_type": "standard"
            },
            {
              "count": 17,
              "fraction": 0.0315,
              "method_name": "custom: TAYLOR:UFactor:2",
              "method_type": "custom"
            }
          ],
          "common_variables": [
            {
              "count": 368,
              "fraction": 0.6815,
              "var_name": "Temperature, K"
            },
            {
              "count": 185,
              "fraction": 0.3426,
              "var_name": "Pressure, kPa"
            },
            {
              "count": 94,
              "fraction": 0.1741,
              "var_name": "Mole fraction"
            },
            {
              "count": 87,
              "fraction": 0.1611,
              "var_name": "Solvent: Mole fraction"
            },
            {
              "count": 57,
              "fraction": 0.1056,
              "var_name": "Amount concentration (molarity), mol/dm3"
            }
          ],
          "n_papers": 115,
          "presentation_distribution": {
            "difference": 0,
            "direct": 540,
            "other": 0,
            "ratio": 0
          },
          "rank_in_group": 3,
          "rank_overall": 30,
          "system_type_distribution": {
            "binary": 436,
            "quaternary_plus": 0,
            "ternary": 104,
            "unary": 0
          },
          "total_instances": 540
        },
        "dimension": null,
        "is_apparent": false,
        "is_excess": false,
        "is_intensive": true,
        "is_molar": false,
        "is_partial": false,
        "name": "Binary diffusion coefficient, m2/s",
        "property_class": "transport",
        "property_group": "TransportProp",
        "symbol": null,
        "thermoml_name": "Binary diffusion coefficient, m2/s",
        "typical_constraints": [],
        "typical_variables": [
          {
            "role": "primary_axis",
            "usage_fraction": 0.6815,
            "var_name": "Temperature, K",
            "var_type": "eTemperature"
          },
          {
            "role": "environmental",
            "usage_fraction": 0.3426,
            "var_name": "Pressure, kPa",
            "var_type": "ePressure"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1741,
            "var_name": "Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1611,
            "var_name": "Solvent: Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1056,
            "var_name": "Amount concentration (molarity), mol/dm3",
            "var_type": "eComponentComposition"
          }
        ],
        "unit": "m2/s"
      },
      "match_score": 100,
      "match_type": "global_id",
      "prop_ID": "binary_diffusion_coefficient_m2_s",
      "prop_id": "binary_diffusion_coefficient_m2_s",
      "prop_num_id": "GLOBprop_29"
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

````markdown
# Raw tool result: `search_property_dk`

Serialization: `json`

```json
{
  "n_results": 1,
  "query": [
    "GLOBprop_29"
  ],
  "results": [
    {
      "base_prop_ID": "binary_diffusion_coefficient_m2_s",
      "card_type": "domain_knowledge",
      "compact_md": "# PCS-DK | binary_diffusion_coefficient_m2_s\n\n**Name:** Binary diffusion coefficient, m2/s\n**Group:** TransportProp\n**Class:** transport\n**Unit:** m2/s\n**Flags:** intensive\n**Typical vars:** Temperature, K (68%); Pressure, kPa (34%); Mole fraction (17%); Solvent: Mole fraction (16%); Amount concentration (molarity), mol/dm3 (11%)\n**Usage:** 540 instances | 115 papers | rank #30\n**Top methods:** Taylor dispersion method (49%); Open capillary (6%); custom: pressure decay method (4%)\n\n## Structured Knowledge\n- **definition:** physical_quantity=\n- **phase_applicability:** component_specific=False; requires_solvent=False\n- **uncertainty_profile:** typical_relative_uncertainty=\n- **data_patterns:** multi_property_frequency=\n\n## Description Sections\n",
      "component_linked": false,
      "domain_knowledge": {
        "description_block": {
          "common_pitfalls": "",
          "common_variable_patterns": "",
          "data_quality_indicators": "",
          "measurement_methods_overview": "",
          "phase_behavior": "",
          "physical_meaning": "",
          "property_overview": "",
          "related_properties": "",
          "reporting_checklist": "",
          "thermodynamic_context": "",
          "typical_applications": "",
          "unit_conventions": ""
        },
        "structured_block": {
          "data_patterns": {
            "co_measured_properties": [],
            "common_block_patterns": [],
            "multi_property_frequency": "",
            "typical_n_points": {
              "median": null,
              "p10": null,
              "p90": null
            }
          },
          "definition": {
            "can_derive": [],
            "derived_from": [],
            "mathematical_definition": null,
            "physical_quantity": "",
            "related_properties": [],
            "sign_convention": null,
            "thermodynamic_definition": null
          },
          "measurement_context": {
            "applicable_presentations": [],
            "applicable_ref_state_types": null,
            "applicable_standard_states": null,
            "primary_methods": [],
            "typical_variable_patterns": []
          },
          "phase_applicability": {
            "applicable_phases": [],
            "applicable_system_types": [],
            "component_specific": false,
            "phase_equilibrium_type": null,
            "primary_phases": [],
            "requires_solvent": false
          },
          "typical_ranges": {
            "pressure_range_kPa": {
              "max": null,
              "min": null,
              "note": null
            },
            "reference_values": [],
            "temperature_range_K": {
              "max": null,
              "min": null,
              "note": null
            },
            "value_range": {
              "max": null,
              "min": null,
              "note": null,
              "unit": ""
            }
          },
          "uncertainty_profile": {
            "best_achievable_uncertainty": null,
            "dominant_uncertainty_sources": [],
            "method_dependent_quality": null,
            "quality_indicators": [],
            "typical_relative_uncertainty": ""
          }
        }
      },
      "identity": {
        "aliases": [],
        "db_usage": {
          "common_constraints": [],
          "common_methods": [
            {
              "count": 263,
              "fraction": 0.487,
              "method_name": "Taylor dispersion method",
              "method_type": "standard"
            },
            {
              "count": 30,
              "fraction": 0.0556,
              "method_name": "Open capillary",
              "method_type": "standard"
            },
            {
              "count": 22,
              "fraction": 0.0407,
              "method_name": "custom: pressure decay method",
              "method_type": "custom"
            },
            {
              "count": 18,
              "fraction": 0.0333,
              "method_name": "Dispersion",
              "method_type": "standard"
            },
            {
              "count": 17,
              "fraction": 0.0315,
              "method_name": "custom: TAYLOR:UFactor:2",
              "method_type": "custom"
            }
          ],
          "common_variables": [
            {
              "count": 368,
              "fraction": 0.6815,
              "var_name": "Temperature, K"
            },
            {
              "count": 185,
              "fraction": 0.3426,
              "var_name": "Pressure, kPa"
            },
            {
              "count": 94,
              "fraction": 0.1741,
              "var_name": "Mole fraction"
            },
            {
              "count": 87,
              "fraction": 0.1611,
              "var_name": "Solvent: Mole fraction"
            },
            {
              "count": 57,
              "fraction": 0.1056,
              "var_name": "Amount concentration (molarity), mol/dm3"
            }
          ],
          "n_papers": 115,
          "presentation_distribution": {
            "difference": 0,
            "direct": 540,
            "other": 0,
            "ratio": 0
          },
          "rank_in_group": 3,
          "rank_overall": 30,
          "system_type_distribution": {
            "binary": 436,
            "quaternary_plus": 0,
            "ternary": 104,
            "unary": 0
          },
          "total_instances": 540
        },
        "dimension": null,
        "is_apparent": false,
        "is_excess": false,
        "is_intensive": true,
        "is_molar": false,
        "is_partial": false,
        "name": "Binary diffusion coefficient, m2/s",
        "property_class": "transport",
        "property_group": "TransportProp",
        "symbol": null,
        "thermoml_name": "Binary diffusion coefficient, m2/s",
        "typical_constraints": [],
        "typical_variables": [
          {
            "role": "primary_axis",
            "usage_fraction": 0.6815,
            "var_name": "Temperature, K",
            "var_type": "eTemperature"
          },
          {
            "role": "environmental",
            "usage_fraction": 0.3426,
            "var_name": "Pressure, kPa",
            "var_type": "ePressure"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1741,
            "var_name": "Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1611,
            "var_name": "Solvent: Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1056,
            "var_name": "Amount concentration (molarity), mol/dm3",
            "var_type": "eComponentComposition"
          }
        ],
        "unit": "m2/s"
      },
      "match_score": 100,
      "match_type": "global_id",
      "prop_ID": "binary_diffusion_coefficient_m2_s",
      "prop_id": "binary_diffusion_coefficient_m2_s",
      "prop_num_id": "GLOBprop_29"
    }
  ]
}
```

````

### Model-visible result

````markdown
# Raw tool result: `search_property_dk`

Serialization: `json`

```json
{
  "n_results": 1,
  "query": [
    "GLOBprop_29"
  ],
  "results": [
    {
      "base_prop_ID": "binary_diffusion_coefficient_m2_s",
      "card_type": "domain_knowledge",
      "compact_md": "# PCS-DK | binary_diffusion_coefficient_m2_s\n\n**Name:** Binary diffusion coefficient, m2/s\n**Group:** TransportProp\n**Class:** transport\n**Unit:** m2/s\n**Flags:** intensive\n**Typical vars:** Temperature, K (68%); Pressure, kPa (34%); Mole fraction (17%); Solvent: Mole fraction (16%); Amount concentration (molarity), mol/dm3 (11%)\n**Usage:** 540 instances | 115 papers | rank #30\n**Top methods:** Taylor dispersion method (49%); Open capillary (6%); custom: pressure decay method (4%)\n\n## Structured Knowledge\n- **definition:** physical_quantity=\n- **phase_applicability:** component_specific=False; requires_solvent=False\n- **uncertainty_profile:** typical_relative_uncertainty=\n- **data_patterns:** multi_property_frequency=\n\n## Description Sections\n",
      "component_linked": false,
      "domain_knowledge": {
        "description_block": {
          "common_pitfalls": "",
          "common_variable_patterns": "",
          "data_quality_indicators": "",
          "measurement_methods_overview": "",
          "phase_behavior": "",
          "physical_meaning": "",
          "property_overview": "",
          "related_properties": "",
          "reporting_checklist": "",
          "thermodynamic_context": "",
          "typical_applications": "",
          "unit_conventions": ""
        },
        "structured_block": {
          "data_patterns": {
            "co_measured_properties": [],
            "common_block_patterns": [],
            "multi_property_frequency": "",
            "typical_n_points": {
              "median": null,
              "p10": null,
              "p90": null
            }
          },
          "definition": {
            "can_derive": [],
            "derived_from": [],
            "mathematical_definition": null,
            "physical_quantity": "",
            "related_properties": [],
            "sign_convention": null,
            "thermodynamic_definition": null
          },
          "measurement_context": {
            "applicable_presentations": [],
            "applicable_ref_state_types": null,
            "applicable_standard_states": null,
            "primary_methods": [],
            "typical_variable_patterns": []
          },
          "phase_applicability": {
            "applicable_phases": [],
            "applicable_system_types": [],
            "component_specific": false,
            "phase_equilibrium_type": null,
            "primary_phases": [],
            "requires_solvent": false
          },
          "typical_ranges": {
            "pressure_range_kPa": {
              "max": null,
              "min": null,
              "note": null
            },
            "reference_values": [],
            "temperature_range_K": {
              "max": null,
              "min": null,
              "note": null
            },
            "value_range": {
              "max": null,
              "min": null,
              "note": null,
              "unit": ""
            }
          },
          "uncertainty_profile": {
            "best_achievable_uncertainty": null,
            "dominant_uncertainty_sources": [],
            "method_dependent_quality": null,
            "quality_indicators": [],
            "typical_relative_uncertainty": ""
          }
        }
      },
      "identity": {
        "aliases": [],
        "db_usage": {
          "common_constraints": [],
          "common_methods": [
            {
              "count": 263,
              "fraction": 0.487,
              "method_name": "Taylor dispersion method",
              "method_type": "standard"
            },
            {
              "count": 30,
              "fraction": 0.0556,
              "method_name": "Open capillary",
              "method_type": "standard"
            },
            {
              "count": 22,
              "fraction": 0.0407,
              "method_name": "custom: pressure decay method",
              "method_type": "custom"
            },
            {
              "count": 18,
              "fraction": 0.0333,
              "method_name": "Dispersion",
              "method_type": "standard"
            },
            {
              "count": 17,
              "fraction": 0.0315,
              "method_name": "custom: TAYLOR:UFactor:2",
              "method_type": "custom"
            }
          ],
          "common_variables": [
            {
              "count": 368,
              "fraction": 0.6815,
              "var_name": "Temperature, K"
            },
            {
              "count": 185,
              "fraction": 0.3426,
              "var_name": "Pressure, kPa"
            },
            {
              "count": 94,
              "fraction": 0.1741,
              "var_name": "Mole fraction"
            },
            {
              "count": 87,
              "fraction": 0.1611,
              "var_name": "Solvent: Mole fraction"
            },
            {
              "count": 57,
              "fraction": 0.1056,
              "var_name": "Amount concentration (molarity), mol/dm3"
            }
          ],
          "n_papers": 115,
          "presentation_distribution": {
            "difference": 0,
            "direct": 540,
            "other": 0,
            "ratio": 0
          },
          "rank_in_group": 3,
          "rank_overall": 30,
          "system_type_distribution": {
            "binary": 436,
            "quaternary_plus": 0,
            "ternary": 104,
            "unary": 0
          },
          "total_instances": 540
        },
        "dimension": null,
        "is_apparent": false,
        "is_excess": false,
        "is_intensive": true,
        "is_molar": false,
        "is_partial": false,
        "name": "Binary diffusion coefficient, m2/s",
        "property_class": "transport",
        "property_group": "TransportProp",
        "symbol": null,
        "thermoml_name": "Binary diffusion coefficient, m2/s",
        "typical_constraints": [],
        "typical_variables": [
          {
            "role": "primary_axis",
            "usage_fraction": 0.6815,
            "var_name": "Temperature, K",
            "var_type": "eTemperature"
          },
          {
            "role": "environmental",
            "usage_fraction": 0.3426,
            "var_name": "Pressure, kPa",
            "var_type": "ePressure"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1741,
            "var_name": "Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1611,
            "var_name": "Solvent: Mole fraction",
            "var_type": "eComponentComposition"
          },
          {
            "role": "composition",
            "usage_fraction": 0.1056,
            "var_name": "Amount concentration (molarity), mol/dm3",
            "var_type": "eComponentComposition"
          }
        ],
        "unit": "m2/s"
      },
      "match_score": 100,
      "match_type": "global_id",
      "prop_ID": "binary_diffusion_coefficient_m2_s",
      "prop_id": "binary_diffusion_coefficient_m2_s",
      "prop_num_id": "GLOBprop_29"
    }
  ]
}
```

````

### Integrity and timing

- Raw SHA-256: 3033e1e586230f974caace3542671c1871419106aa4cf421757035ac9ff76b27
- Raw characters: 7489
- Hardcoded-compacted characters: 7489
- Model-visible characters: 7489
- Agentic verdict: SKIP
- Tool elapsed: 0.008s
- Compactor elapsed: 0.000s
- Total elapsed: 0.008s

# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 11
- **API turns:** 8
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 115.3s
- **Timed out:** False

## Answer

That block starts at 313.15 K, so it doesn't cover 25 °C. Now I have all the information needed. Let me compile the answer.

---

## Density of Equimolar Propan-2-ol + Water at 25 °C and Atmospheric Pressure

### Best Direct Measurement

The most directly relevant data comes from the paper by **Pang et al.** (DOI: [10.1021/je700700f](https://doi.org/10.1021/je700700f)), stored as `GLOBlit_11042::PROPblock_17`. This block reports density for the propan-2-ol + water binary system at exactly **T = 298.15 K** and **P = 101.0 kPa** (atmospheric pressure) across the full composition range.

At a mole fraction of propan-2-ol **x = 0.4981** (essentially equimolar):

> **ρ = 838.8 kg/m³** (≈ 0.8388 g/cm³)

For context, the neighboring compositions in the same dataset are:
| x(propan-2-ol) | Density (kg/m³) |
|:-:|:-:|
| 0.3992 | 857.7 |
| **0.4981** | **838.8** |
| 0.5979 | 823.5 |

### Supporting Evidence

A second dataset (DOI: [10.1021/je800158z](https://doi.org/10.1021/je800158z), `GLOBlit_11142::PROPblock_4`) reports density at x = 0.5204 and T = 293.15 K as 839.36 kg/m³ (at P = 81.5 kPa), which is broadly consistent when accounting for the slightly different composition, temperature, and pressure.

A third dataset (DOI: [10.1021/je8001305](https://doi.org/10.1021/je8001305), `GLOBlit_11130::PROPblock_1`) reports density at x = 0.4939 and T = 300.1 K as 837.98 kg/m³ (at P = 7.2 kPa), again consistent.

### Chemical Insight

The measured density of **~839 kg/m³** for the equimolar mixture is notably **between** the densities of the pure components:
- Pure water at 25 °C: ~997 kg/m³
- Pure propan-2-ol at 25 °C: ~781 kg/m³

However, the mixture density is **not** a simple linear average of the two (~889 kg/m³ by mole-fraction weighting). The negative deviation from ideal mixing reflects the well-known **volume contraction** that occurs in alcohol–water systems due to the restructuring of hydrogen-bonding networks. Water molecules can partially fill the voids in the alcohol structure, leading to a more compact packing than ideal mixing would predict. This effect is particularly pronounced in propan-2-ol + water mixtures due to the hydrophobic hydration of the isopropyl group.

# Q1.5 — Result

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 13
- **API turns:** 6
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 189.2s
- **Timed out:** False

## Answer

I now have comprehensive data. Let me compile the final answer with all the evidence gathered.

---

# Viscosity of Pure Liquid Ethanol near 25 °C: Methods and Reported Values

## Overview

The ThermoML database contains **50 independent data blocks** reporting the dynamic viscosity of pure liquid ethanol near 25 °C (298.15 K), drawn from dozens of publications. **Six distinct measurement techniques** have been used, each based on a different physical principle. The reported values range from approximately **1.04 to 1.10 mPa·s**, with the vast majority clustering tightly around **1.07–1.09 mPa·s**.

---

## Measurement Methods Used

### 1. Capillary Tube (Ostwald/Ubbelohde) Method — *Most Common*
- **GLOBmeas_4** — 3,407 instances across 716 papers in ThermoML (the dominant viscometry technique)
- **Principle:** Liquid flows under gravity through a precision-bore glass capillary; the efflux time between two fiducial marks is proportional to kinematic viscosity via the Hagen–Poiseuille equation: ν = Ct − K/t
- **Accuracy:** 0.1–0.5% for kinematic viscosity; 0.2–0.7% for dynamic viscosity
- **Representative ethanol values at 298.15 K:**
  - 0.001077 Pa·s (DOI: 10.1016/j.fluid.2006.01.008)
  - 0.001078 Pa·s (DOI: 10.1016/j.fluid.2005.05.012)
  - 0.001082 Pa·s (DOI: 10.1016/j.fluid.2005.07.010; 10.1016/j.fluid.2007.03.021)
  - 0.001093 Pa·s (DOI: 10.1016/j.jct.2005.04.019)

### 2. Falling/Rolling Sphere (Ball) Viscometry
- **GLOBmeas_8** — 1,243 instances across 276 papers
- **Principle:** A calibrated sphere falls or rolls through the liquid; the travel time is related to viscosity via Stokes' law: η = K·(ρ_sphere − ρ_fluid)·t
- **Accuracy:** 0.5–2% with proper calibration
- **Representative ethanol values at 298.15 K:**
  - 0.001071 Pa·s (DOI: 10.1016/j.jct.2017.07.022; 10.1021/acs.jced.5b00259; 10.1021/acs.jced.5b00365)
  - 0.001056 Pa·s (DOI: 10.1021/acs.jced.8b00086)
  - 0.0010569 Pa·s (DOI: 10.1016/j.jct.2009.06.023)
  - 0.00104 Pa·s (DOI: 10.1021/acs.jced.7b00944 — an outlier on the low side)

### 3. Concentric Cylinders (Couette) Viscometry
- **GLOBmeas_11** — 1,082 instances across 231 papers
- **Principle:** Torque on a stationary cylinder is measured while a coaxial inner cylinder rotates; viscosity is computed from the Margules equation: η = T·(R₂² − R₁²)/(4πLωR₁²R₂²)
- **Accuracy:** 1–3% for Newtonian fluids
- **Used for ethanol viscosity in:** DOI 10.1016/j.fluid.2014.10.044 (Rodríguez-González et al., 2015); DOI 10.1016/j.fluid.2015.01.011 (Bastos-Oliveira et al., 2015); DOI 10.1016/j.jct.2011.02.018 (Hogshead-Torres et al., 2011)

### 4. Moving Piston Method
- **GLOBmeas_69** — 55 instances across 15 papers
- **Principle:** A precision piston falls through a close-fitting cylinder; travel time is proportional to viscosity: η = K·Δρ·t. Especially valued for high-pressure measurements.
- **Accuracy:** 1–2% (0.5% achievable)
- **Used for ethanol in:** DOI 10.1016/j.jct.2012.10.002 (Kariznovi-Nourozieh et al., 2013)

### 5. Schott-Geräte AVS 350 Viscometer (Automated Capillary)
- **GLOBmeas_497** — A specific automated capillary viscometer instrument
- **Ethanol value at 298.15 K:** 0.001073 Pa·s (DOI: 10.1016/j.jct.2005.10.022)

### 6. Pressure-Drop Capillary Method
- **GLOBmeas_2135** — A variant using pressure drop in a straight capillary
- **Used for ethanol in:** DOI 10.1016/j.fluid.2017.09.005

---

## Summary of Reported Values at ~298.15 K

| Method | Typical η (mPa·s) | Range (mPa·s) | Accuracy |
|--------|-------------------|---------------|----------|
| **Capillary (Ubbelohde/Ostwald)** | 1.077–1.093 | 1.073–1.105 | 0.1–0.5% |
| **Falling/Rolling Sphere** | 1.056–1.071 | 1.040–1.071 | 0.5–2% |
| **Concentric Cylinders** | ~1.08–1.10 | — | 1–3% |
| **Moving Piston** | ~1.08 | — | 1–2% |
| **Automated Capillary (Schott)** | 1.073 | — | ~0.3% |

---

## Chemical Insight and Discussion

**Why the values cluster so tightly:** Ethanol is a simple, low-molecular-weight Newtonian liquid with well-characterized hydrogen bonding. At 25 °C, its viscosity (~1.08 mPa·s) is close to that of water (~0.89 mPa·s), reflecting the balance between hydrogen-bonding network strength and molecular size. The strong inter-method agreement (within ~2–3%) confirms that ethanol behaves as an ideal Newtonian fluid under all measurement geometries and shear rates.

**Method-dependent trends:**
- **Capillary methods** tend to report slightly higher values (1.077–1.093 mPa·s), consistent with their superior accuracy (0.1–0.5%) and status as the ASTM/ISO primary standard for kinematic viscosity.
- **Falling-sphere methods** tend to report slightly lower values (1.056–1.071 mPa·s). This may reflect the greater sensitivity of this technique to calibration constant uncertainty and the density difference (ρ_sphere − ρ_fluid), which directly scales the result.
- The **outlier at 1.04 mPa·s** (DOI: 10.1021/acs.jced.7b00944, falling-sphere method) is ~3–4% below the consensus and may reflect sample purity issues, calibration error, or water contamination (water lowers ethanol viscosity).

**Temperature sensitivity:** Ethanol viscosity changes by approximately 2–3% per kelvin near 25 °C, so even ±0.1 K temperature uncertainty translates to ±0.2–0.3% viscosity uncertainty — this is the dominant error source across all methods.

**Consensus value:** Based on the ThermoML evidence, the best estimate for the dynamic viscosity of pure liquid ethanol at 298.15 K and atmospheric pressure is **η ≈ 1.074–1.082 mPa·s** (0.001074–0.001082 Pa·s), consistent with the NIST recommended value and the capillary viscometry literature.

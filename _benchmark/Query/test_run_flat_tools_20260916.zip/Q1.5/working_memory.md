# Q1.5 — Working Memory

Evidence returned to the answering model:

## 1. resolve_compound_ids

Ethanol resolves to **GLOBcomp_2** (exact name match, score 100).

| Field | Value |
|-------|-------|
| ID | GLOBcomp_2 |
| Name | ethanol |
| Formula | C2H6O |
| SMILES | CCO |
| Match type | name_exact |

## 2. resolve_property_ids

**Summary:** The canonical viscosity property ID is **GLOBprop_4** — "Viscosity, Pa·s" (Transport Properties group), matched exactly.

| prop_id | Name | Group |
|---|---|---|
| GLOBprop_4 | Viscosity, Pa*s | TransportProp |

## 3. search_measurement_indiv

search_measurement_indiv: 50 result(s).

| # | lit_num_id | doi | Score | Match |
|---|---|---|---:|---|
| 1 | GLOBlit_8 | 10.1007/s10765-005-8089-2 | 80 | property |
| 2 | GLOBlit_267 | 10.1016/j.fluid.2005.05.012 | 80 | property |
| 3 | GLOBlit_271 | 10.1016/j.fluid.2005.05.022 | 80 | property |
| 4 | GLOBlit_288 | 10.1016/j.fluid.2005.07.010 | 80 | property |
| 5 | GLOBlit_349 | 10.1016/j.fluid.2006.01.008 | 80 | property |
| 6 | GLOBlit_359 | 10.1016/j.fluid.2006.01.030 | 80 | property |
| 7 | GLOBlit_369 | 10.1016/j.fluid.2006.02.023 | 80 | property |
| 8 | GLOBlit_499 | 10.1016/j.fluid.2007.03.021 | 80 | property |
| 9 | GLOBlit_559 | 10.1016/j.fluid.2007.08.006 | 80 | property |
| 10 | GLOBlit_858 | 10.1016/j.fluid.2010.07.005 | 80 | property |
| 11 | GLOBlit_1588 | 10.1016/j.fluid.2014.10.044 | 80 | property |
| 12 | GLOBlit_1633 | 10.1016/j.fluid.2015.01.011 | 80 | property |
| 13 | GLOBlit_1692 | 10.1016/j.fluid.2015.04.022 | 80 | property |
| 14 | GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | 80 | property |
| 15 | GLOBlit_1969 | 10.1016/j.fluid.2016.08.022 | 80 | property |
| 16 | GLOBlit_2066 | 10.1016/j.fluid.2017.06.001 | 80 | property |
| 17 | GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | 80 | property |
| 18 | GLOBlit_2283 | 10.1016/j.fluid.2019.01.017 | 80 | property |
| 19 | GLOBlit_2547 | 10.1016/j.jct.2005.04.019 | 80 | property |
| 20 | GLOBlit_2568 | 10.1016/j.jct.2005.06.011 | 80 | property |
| 21 | GLOBlit_2580 | 10.1016/j.jct.2005.07.008 | 80 | property |
| 22 | GLOBlit_2632 | 10.1016/j.jct.2005.10.022 | 80 | property |
| 23 | GLOBlit_2648 | 10.1016/j.jct.2005.12.010 | 80 | property |
| 24 | GLOBlit_2674 | 10.1016/j.jct.2006.03.010 | 80 | property |
| 25 | GLOBlit_2680 | 10.1016/j.jct.2006.03.018 | 80 | property |
| 26 | GLOBlit_2707 | 10.1016/j.jct.2006.06.008 | 80 | property |
| 27 | GLOBlit_2764 | 10.1016/j.jct.2006.10.016 | 80 | property |
| 28 | GLOBlit_2825 | 10.1016/j.jct.2007.05.004 | 80 | property |
| 29 | GLOBlit_2934 | 10.1016/j.jct.2008.03.013 | 80 | property |
| 30 | GLOBlit_2944 | 10.1016/j.jct.2008.04.006 | 80 | property |
| 31 | GLOBlit_3116 | 10.1016/j.jct.2009.06.023 | 80 | property |
| 32 | GLOBlit_3201 | 10.1016/j.jct.2010.01.013 | 80 | property |
| 33 | GLOBlit_3224 | 10.1016/j.jct.2010.03.022 | 80 | property |
| 34 | GLOBlit_3363 | 10.1016/j.jct.2011.02.018 | 80 | property |
| 35 | GLOBlit_3407 | 10.1016/j.jct.2011.05.037 | 80 | property |
| 36 | GLOBlit_3409 | 10.1016/j.jct.2011.06.002 | 80 | property |
| 37 | GLOBlit_3453 | 10.1016/j.jct.2011.08.028 | 80 | property |
| 38 | GLOBlit_3540 | 10.1016/j.jct.2012.01.013 | 80 | property |
| 39 | GLOBlit_3572 | 10.1016/j.jct.2012.02.027 | 80 | property |
| 40 | GLOBlit_3628 | 10.1016/j.jct.2012.05.001 | 80 | property |
| 41 | GLOBlit_3711 | 10.1016/j.jct.2012.08.024 | 80 | property |
| 42 | GLOBlit_3745 | 10.1016/j.jct.2012.10.002 | 80 | property |
| 43 | GLOBlit_3748 | 10.1016/j.jct.2012.10.008 | 80 | property |
| 44 | GLOBlit_3972 | 10.1016/j.jct.2013.08.021 | 80 | property |
| 45 | GLOBlit_3988 | 10.1016/j.jct.2013.09.006 | 80 | property |
| 46 | GLOBlit_4013 | 10.1016/j.jct.2013.09.044 | 80 | property |
| 47 | GLOBlit_4060 | 10.1016/j.jct.2013.11.026 | 80 | property |
| 48 | GLOBlit_4112 | 10.1016/j.jct.2014.01.030 | 80 | property |
| 49 | GLOBlit_4331 | 10.1016/j.jct.2015.02.024 | 80 | property |
| 50 | GLOBlit_4369 | 10.1016/j.jct.2015.04.027 | 80 | property |

---
# MTDKS | 10.1007/s10765-005-8089-2 | GLOBlit_8

**lit_id:** 2005-zeb-bay-0
**Methods:** 2 (2 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_3 | 2 |

---
# MTDKS | 10.1016/j.fluid.2005.05.012 | GLOBlit_267

**lit_id:** 2005-che-lei-0
**Methods:** 2 (0 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB:UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_11,PROPblock_13,PROPblock_15,PROPblock_17,PROPblock_19,PROPblock_21,PROPblock_23,PROPblock_25,PROPblock_3,PROPblock_5,PROPblock_7,PROPblock_9 | 13 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB:UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_12,PROPblock_14,PROPblock_16,PROPblock_18,PROPblock_2,PROPblock_20,PROPblock_22,PROPblock_24,PROPblock_26,PROPblock_4,PROPblock_6,PROPblock_8 | 13 |

---
# MTDKS | 10.1016/j.fluid.2005.05.022 | GLOBlit_271

**lit_id:** 2005-tab-gal-0
**Methods:** 5 (3 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_4 | 1 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_5 | 1 |
| cust | GLOBmeas_1780 | atomic_abosorption_spectrometry | Atomic Abosorption Spectrometry | GLOBprop_35:mass_ratio_of_solute_to_solvent | PROPblock_3 | 1 |
| cust | GLOBmeas_2068 | orion_model_170_conductivity_meter | Orion model 170 conductivity-meter | GLOBprop_18:electrical_conductivity_s_m | PROPblock_1 | 1 |

---
# MTDKS | 10.1016/j.fluid.2005.07.010 | GLOBlit_288

**lit_id:** 2005-cal-dom-0
**Methods:** 6 (2 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_10 | density_calibration_data | Density calibration data | GLOBprop_2:mole_fraction | PROPblock_11,PROPblock_13,PROPblock_15 | 3 |
| std | GLOBmeas_5 | ebulliometric_method_recirculating_still | Ebulliometric method (Recirculating still) | GLOBprop_26:normal_boiling_temperature_k | PROPblock_1,PROPblock_4,PROPblock_7 | 3 |
| cust | GLOBmeas_142 | captub_ufactor_4 | CAPTUB:UFactor:4 | GLOBprop_4:viscosity_pa_s | PROPblock_3,PROPblock_6,PROPblock_9 | 3 |
| cust | GLOBmeas_222 | ebullio_ufactor_6 | EBULLIO:UFactor:6 | GLOBprop_14:boiling_temperature_at_pressure_p_k | PROPblock_10 | 1 |
| cust | GLOBmeas_146 | ebullio_ufactor_8 | EBULLIO:UFactor:8 | GLOBprop_14:boiling_temperature_at_pressure_p_k | PROPblock_12,PROPblock_14 | 2 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB:UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_2,PROPblock_5,PROPblock_8 | 3 |

---
# MTDKS | 10.1016/j.fluid.2006.01.008 | GLOBlit_349

**lit_id:** 2006-arc-rod-0
**Methods:** 4 (4 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_15,PROPblock_19,PROPblock_21,PROPblock_25,PROPblock_29,PROPblock_3,PROPblock_33,PROPblock_7 | 9 |
| std | GLOBmeas_7 | sing_around_technique_in_a_fixed_path_interferometer | Sing-around technique in a fixed-path interferometer | GLOBprop_8:speed_of_sound_m_s | PROPblock_12,PROPblock_16,PROPblock_20,PROPblock_23,PROPblock_27,PROPblock_31,PROPblock_35,PROPblock_4,PROPblock_8 | 9 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_13,PROPblock_17,PROPblock_22,PROPblock_26,PROPblock_30,PROPblock_34,PROPblock_5,PROPblock_9 | 9 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_14,PROPblock_18,PROPblock_2,PROPblock_24,PROPblock_28,PROPblock_32,PROPblock_36,PROPblock_6 | 9 |

---
# MTDKS | 10.1016/j.fluid.2006.01.030 | GLOBlit_359

**lit_id:** 2006-zeb-wat-0
**Methods:** 2 (2 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_2,PROPblock_4,PROPblock_5 | 3 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_3,PROPblock_6 | 3 |

---
# MTDKS | 10.1016/j.fluid.2006.02.023 | GLOBlit_369

**lit_id:** 2006-roy-sin-1
**Methods:** 4 (0 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_165 | captub_ufactor_8 | CAPTUB:UFactor:8 | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_2,PROPblock_20,PROPblock_23,PROPblock_26,PROPblock_29,PROPblock_31,PROPblock_34,PROPblock_37,PROPblock_40,PROPblock_43,PROPblock_46,PROPblock_49,PROPblock_5,PROPblock_52,PROPblock_8 | 18 |
| cust | GLOBmeas_206 | fpint_ufactor_4 | FPINT:UFactor:4 | GLOBprop_8:speed_of_sound_m_s | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_21,PROPblock_24,PROPblock_27,PROPblock_3,PROPblock_30,PROPblock_6,PROPblock_9 | 10 |
| cust | GLOBmeas_673 | fpint_ufactor_64 | FPINT:UFactor:64 | GLOBprop_8:speed_of_sound_m_s | PROPblock_32,PROPblock_35,PROPblock_38,PROPblock_41,PROPblock_44,PROPblock_47,PROPblock_50,PROPblock_53 | 8 |
| cust | GLOBmeas_153 | pycnom_ufactor_4 | PYCNOM:UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_10,PROPblock_13,PROPblock_16,PROPblock_19,PROPblock_22,PROPblock_25,PROPblock_28,PROPblock_33,PROPblock_36,PROPblock_39,PROPblock_4,PROPblock_42,PROPblock_45,PROPblock_48,PROPblock_51,PROPblock_54,PROPblock_7 | 18 |

---
# MTDKS | 10.1016/j.fluid.2007.03.021 | GLOBlit_499

**lit_id:** 2007-cal-gon-0
**Methods:** 5 (4 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_3 | 1 |
| std | GLOBmeas_10 | density_calibration_data | Density calibration data | GLOBprop_2:mole_fraction | PROPblock_7 | 1 |
| std | GLOBmeas_5 | ebulliometric_method_recirculating_still | Ebulliometric method (Recirculating still) | GLOBprop_26:normal_boiling_temperature_k | PROPblock_1 | 1 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_2 | 1 |
| cust | GLOBmeas_146 | ebullio_ufactor_8 | EBULLIO:UFactor:8 | GLOBprop_14:boiling_temperature_at_pressure_p_k | PROPblock_4,PROPblock_5,PROPblock_6 | 3 |

---
# MTDKS | 10.1016/j.fluid.2007.08.006 | GLOBlit_559

**lit_id:** 2007-meh-kar-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_2,PROPblock_5,PROPblock_8 | 3 |
| std | GLOBmeas_6 | pycnometric_method | Pycnometric method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_4,PROPblock_7 | 3 |
| std | GLOBmeas_7 | sing_around_technique_in_a_fixed_path_interferometer | Sing-around technique in a fixed-path interferometer | GLOBprop_8:speed_of_sound_m_s | PROPblock_3,PROPblock_6,PROPblock_9 | 3 |

---
# MTDKS | 10.1016/j.fluid.2010.07.005 | GLOBlit_858

**lit_id:** 2010-he-zha-0
**Methods:** 6 (4 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_16,PROPblock_2,PROPblock_6 | 4 |
| std | GLOBmeas_12 | flow_calorimetry | Flow calorimetry | GLOBprop_17:excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol | PROPblock_14,PROPblock_4,PROPblock_9 | 3 |
| std | GLOBmeas_60 | manometric_method | Manometric method | GLOBprop_5:vapor_or_sublimation_pressure_kpa | PROPblock_12,PROPblock_17,PROPblock_7 | 3 |
| std | GLOBmeas_17 | vacuum_adiabatic_calorimetry | Vacuum adiabatic calorimetry | GLOBprop_9:molar_heat_capacity_at_constant_pressure_j_k_mol | PROPblock_1,PROPblock_10,PROPblock_15,PROPblock_5 | 4 |
| cust | GLOBmeas_1691 | specific_gravity_balance | Specific gravity balance | GLOBprop_1:mass_density_kg_m3 | PROPblock_13,PROPblock_18 | 2 |
| cust | GLOBmeas_1694 | speicific_gravity_balance | Speicific gravity balance | GLOBprop_1:mass_density_kg_m3 | PROPblock_3,PROPblock_8 | 2 |

---
# MTDKS | 10.1016/j.fluid.2014.10.044 | GLOBlit_1588

**lit_id:** 2015-rod-gon-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_11 | concentric_cylinders_viscometry | Concentric cylinders viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_8 | 1 |
| std | GLOBmeas_5 | ebulliometric_method_recirculating_still | Ebulliometric method (Recirculating still) | GLOBprop_14:boiling_temperature_at_pressure_p_k | PROPblock_1,PROPblock_2,PROPblock_3,PROPblock_4,PROPblock_5,PROPblock_6 | 6 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_7 | 1 |

---
# MTDKS | 10.1016/j.fluid.2015.01.011 | GLOBlit_1633

**lit_id:** 2015-bas-oli-0
**Methods:** 6 (4 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_14 | alternating_current_cell_with_electrodes | Alternating current cell with electrodes | GLOBprop_18:electrical_conductivity_s_m | PROPblock_10,PROPblock_13,PROPblock_7 | 3 |
| std | GLOBmeas_11 | concentric_cylinders_viscometry | Concentric cylinders viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_12,PROPblock_6,PROPblock_8 | 3 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_3 | 1 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_11,PROPblock_2,PROPblock_5,PROPblock_9 | 4 |
| cust | GLOBmeas_137 | other | OTHER | GLOBprop_6:mass_fraction | PROPblock_1 | 3 |
| cust | GLOBmeas_160 | visual | visual | GLOBprop_2:mole_fraction | PROPblock_4 | 1 |

---
# MTDKS | 10.1016/j.fluid.2015.04.022 | GLOBlit_1692

**lit_id:** 2015-gon-tes-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_1 | chromatography | Chromatography | GLOBprop_6:mass_fraction | PROPblock_5 | 3 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_2,PROPblock_4 | 2 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_3 | 2 |

---
# MTDKS | 10.1016/j.fluid.2015.07.012 | GLOBlit_1742

**lit_id:** 2016-ono-ame-0
**Methods:** 2 (2 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_2,PROPblock_4,PROPblock_6 | 3 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_3,PROPblock_5 | 3 |

---
# MTDKS | 10.1016/j.fluid.2016.08.022 | GLOBlit_1969

**lit_id:** 2016-yan-gon-1
**Methods:** 4 (2 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_3,PROPblock_6 | 2 |
| std | GLOBmeas_6 | pycnometric_method | Pycnometric method | GLOBprop_1:mass_density_kg_m3 | PROPblock_2,PROPblock_5 | 2 |
| cust | GLOBmeas_133 | closed_cell_static_method | Closed cell (Static) method | GLOBprop_5:vapor_or_sublimation_pressure_kpa | PROPblock_4,PROPblock_7 | 2 |
| cust | GLOBmeas_130 | dta | DTA | GLOBprop_12:normal_melting_temperature_k | PROPblock_1 | 1 |

---
# MTDKS | 10.1016/j.fluid.2017.06.001 | GLOBlit_2066

**lit_id:** 2017-dom-wla-1
**Methods:** 5 (3 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_4 | 1 |
| std | GLOBmeas_1 | chromatography | Chromatography | GLOBprop_3:activity_coefficient | PROPblock_10,PROPblock_11,PROPblock_12,PROPblock_13,PROPblock_14,PROPblock_15,PROPblock_16,PROPblock_17,PROPblock_18,PROPblock_19,PROPblock_20,PROPblock_21,PROPblock_22,PROPblock_23,PROPblock_24,PROPblock_25,PROPblock_26,PROPblock_27,PROPblock_28,PROPblock_29,PROPblock_30,PROPblock_31,PROPblock_32,PROPblock_33,PROPblock_34,PROPblock_35,PROPblock_36,PROPblock_37,PROPblock_38,PROPblock_39,PROPblock_40,PROPblock_41,PROPblock_42,PROPblock_43,PROPblock_44,PROPblock_45,PROPblock_46,PROPblock_47,PROPblock_48,PROPblock_49,PROPblock_5,PROPblock_50,PROPblock_51,PROPblock_52,PROPblock_53,PROPblock_54,PROPblock_55,PROPblock_56,PROPblock_57,PROPblock_58,PROPblock_59,PROPblock_6,PROPblock_60,PROPblock_61,PROPblock_62,PROPblock_63,PROPblock_64,PROPblock_65,PROPblock_66,PROPblock_67,PROPblock_68,PROPblock_69,PROPblock_7,PROPblock_70,PROPblock_8,PROPblock_9 | 66 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_3 | 1 |
| cust | GLOBmeas_132 | dsc | DSC | GLOBprop_10:molar_enthalpy_of_transition_or_fusion_kj_mol | PROPblock_2 | 1 |
| cust | GLOBmeas_130 | dta | DTA | GLOBprop_12:normal_melting_temperature_k | PROPblock_1 | 1 |

---
# MTDKS | 10.1016/j.fluid.2017.09.005 | GLOBlit_2092

**lit_id:** 2017-ono-kyo-0
**Methods:** 3 (2 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_4,PROPblock_6 | 2 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_3,PROPblock_5 | 3 |
| cust | GLOBmeas_2135 | pressure_drop_in_straight_capillary | Pressure drop in straight capillary | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |

---
# MTDKS | 10.1016/j.fluid.2019.01.017 | GLOBlit_2283

**lit_id:** 2019-sat-bab-0
**Methods:** 3 (1 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_3,PROPblock_5 | 2 |
| cust | GLOBmeas_133 | closed_cell_static_method | Closed cell (Static) method | GLOBprop_5:vapor_or_sublimation_pressure_kpa | PROPblock_1 | 1 |
| cust | GLOBmeas_170 | isochor | ISOCHOR | GLOBprop_1:mass_density_kg_m3 | PROPblock_2,PROPblock_4 | 2 |

---
# MTDKS | 10.1016/j.jct.2005.04.019 | GLOBlit_2547

**lit_id:** 2006-ilo-sam-0
**Methods:** 5 (2 standard, 3 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_10,PROPblock_13,PROPblock_15,PROPblock_17,PROPblock_19,PROPblock_4,PROPblock_7 | 8 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_14,PROPblock_16,PROPblock_18,PROPblock_21,PROPblock_3,PROPblock_6,PROPblock_9 | 8 |
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB:UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_22,PROPblock_25,PROPblock_28,PROPblock_31,PROPblock_34,PROPblock_37,PROPblock_40 | 7 |
| cust | GLOBmeas_527 | quartz_crystal_interferometer_mittal_enterprises_india | Quartz crystal interferometer (Mittal Enterprises, India) | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_2,PROPblock_20,PROPblock_23,PROPblock_26,PROPblock_29,PROPblock_32,PROPblock_35,PROPblock_38,PROPblock_41,PROPblock_5,PROPblock_8 | 12 |
| cust | GLOBmeas_138 | vibtub_ufactor_2 | VIBTUB:UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_24,PROPblock_27,PROPblock_30,PROPblock_33,PROPblock_36,PROPblock_39,PROPblock_42 | 7 |

---
# MTDKS | 10.1016/j.jct.2005.06.011 | GLOBlit_2568

**lit_id:** 2006-ara-bar-0
**Methods:** 9 (1 standard, 8 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_15 | linear_variable_path_acoustic_interferometer | Linear variable-path acoustic interferometer | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_15,PROPblock_19,PROPblock_23,PROPblock_27,PROPblock_3,PROPblock_31,PROPblock_35,PROPblock_39,PROPblock_43,PROPblock_47,PROPblock_51,PROPblock_7 | 13 |
| cust | GLOBmeas_163 | abbe_ufactor_4 | ABBE::UFactor:4 | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_13,PROPblock_21,PROPblock_25,PROPblock_5 | 5 |
| cust | GLOBmeas_260 | abbe_ufactor_8 | ABBE::UFactor:8 | GLOBprop_7:refractive_index_na_dline | PROPblock_9 | 1 |
| cust | GLOBmeas_163 | abbe_ufactor_4 | ABBE:UFactor:4 | GLOBprop_7:refractive_index_na_dline | PROPblock_17,PROPblock_30,PROPblock_38,PROPblock_42,PROPblock_46,PROPblock_50 | 6 |
| cust | GLOBmeas_260 | abbe_ufactor_8 | ABBE:UFactor:8 | GLOBprop_7:refractive_index_na_dline | PROPblock_34 | 1 |
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB::UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_14,PROPblock_2,PROPblock_22,PROPblock_26,PROPblock_6 | 6 |
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB:UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_18,PROPblock_29,PROPblock_33,PROPblock_37,PROPblock_41,PROPblock_45,PROPblock_49 | 7 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB::UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_16,PROPblock_20,PROPblock_24,PROPblock_28,PROPblock_4 | 6 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB:UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_32,PROPblock_36,PROPblock_40,PROPblock_44,PROPblock_48,PROPblock_52,PROPblock_8 | 7 |

---
# MTDKS | 10.1016/j.jct.2005.07.008 | GLOBlit_2580

**lit_id:** 2006-rod-per-0
**Methods:** 4 (0 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_142 | captub_ufactor_4 | CAPTUB:UFactor:4 | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_11,PROPblock_3,PROPblock_5,PROPblock_6,PROPblock_8 | 6 |
| cust | GLOBmeas_181 | fpint_ufactor_2 | FPINT:UFactor:2 | GLOBprop_8:speed_of_sound_m_s | PROPblock_12,PROPblock_9 | 2 |
| cust | GLOBmeas_138 | vibtub_ufactor_2 | VIBTUB:UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_13,PROPblock_2,PROPblock_4 | 4 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB:UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_7 | 1 |

---
# MTDKS | 10.1016/j.jct.2005.10.022 | GLOBlit_2632

**lit_id:** 2006-mut-man-0
**Methods:** 3 (2 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_10,PROPblock_13,PROPblock_16,PROPblock_19,PROPblock_23,PROPblock_26,PROPblock_29,PROPblock_32,PROPblock_35,PROPblock_38,PROPblock_4,PROPblock_7 | 13 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_21,PROPblock_24,PROPblock_27,PROPblock_3,PROPblock_30,PROPblock_33,PROPblock_36,PROPblock_39,PROPblock_6,PROPblock_9 | 13 |
| cust | GLOBmeas_497 | schott_gerate_viscometer_model_avs_350 | Schott-Gerate viscometer model AVS 350 | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_2,PROPblock_20,PROPblock_22,PROPblock_25,PROPblock_28,PROPblock_31,PROPblock_34,PROPblock_37,PROPblock_5,PROPblock_8 | 13 |

---
# MTDKS | 10.1016/j.jct.2005.12.010 | GLOBlit_2648

**lit_id:** 2006-gon-dom-2
**Methods:** 4 (0 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_165 | captub_ufactor_8 | CAPTUB:UFactor:8 | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_10,PROPblock_13,PROPblock_16,PROPblock_19,PROPblock_22,PROPblock_25,PROPblock_28,PROPblock_31,PROPblock_34,PROPblock_37,PROPblock_4,PROPblock_7 | 13 |
| cust | GLOBmeas_181 | fpint_ufactor_2 | FPINT:UFactor:2 | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_2,PROPblock_23,PROPblock_26,PROPblock_29,PROPblock_35,PROPblock_38,PROPblock_5,PROPblock_8 | 11 |
| cust | GLOBmeas_209 | fpint_ufactor_8 | FPINT:UFactor:8 | GLOBprop_8:speed_of_sound_m_s | PROPblock_20,PROPblock_32 | 2 |
| cust | GLOBmeas_141 | vibtub_ufactor_8 | VIBTUB:UFactor:8 | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_21,PROPblock_24,PROPblock_27,PROPblock_3,PROPblock_30,PROPblock_33,PROPblock_36,PROPblock_39,PROPblock_6,PROPblock_9 | 13 |

---
# MTDKS | 10.1016/j.jct.2006.03.010 | GLOBlit_2674

**lit_id:** 2006-kad-hir-1
**Methods:** 5 (1 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_15 | linear_variable_path_acoustic_interferometer | Linear variable-path acoustic interferometer | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_2,PROPblock_20,PROPblock_23,PROPblock_26,PROPblock_5,PROPblock_8 | 9 |
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB::UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_13,PROPblock_4,PROPblock_7 | 4 |
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB:UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_16,PROPblock_19,PROPblock_22,PROPblock_25 | 5 |
| cust | GLOBmeas_184 | pycnom_ufactor_2 | PYCNOM::UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_15,PROPblock_6,PROPblock_9 | 4 |
| cust | GLOBmeas_184 | pycnom_ufactor_2 | PYCNOM:UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_18,PROPblock_21,PROPblock_24,PROPblock_27,PROPblock_3 | 5 |

---
# MTDKS | 10.1016/j.jct.2006.03.018 | GLOBlit_2680

**lit_id:** 2006-mut-man-1
**Methods:** 14 (0 standard, 14 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_316 | abbe_ufactor_16 | ABBE::UFactor:16 | GLOBprop_7:refractive_index_na_dline | PROPblock_13,PROPblock_17,PROPblock_21,PROPblock_25,PROPblock_5,PROPblock_9 | 6 |
| cust | GLOBmeas_316 | abbe_ufactor_16 | ABBE:UFactor:16 | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_31,PROPblock_35,PROPblock_39,PROPblock_43,PROPblock_47,PROPblock_51 | 7 |
| cust | GLOBmeas_205 | captub_ufactor_16 | CAPTUB::UFactor:16 | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_14,PROPblock_18,PROPblock_2,PROPblock_22,PROPblock_26,PROPblock_6 | 7 |
| cust | GLOBmeas_205 | captub_ufactor_16 | CAPTUB:UFactor:16 | GLOBprop_4:viscosity_pa_s | PROPblock_30,PROPblock_34,PROPblock_38,PROPblock_42,PROPblock_46,PROPblock_50 | 6 |
| cust | GLOBmeas_581 | lvpai_ufactor_32 | LVPAI::UFactor:32 | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_15,PROPblock_19,PROPblock_23,PROPblock_27 | 5 |
| cust | GLOBmeas_1324 | lvpai_ufactor_64 | LVPAI::UFactor:64 | GLOBprop_8:speed_of_sound_m_s | PROPblock_3,PROPblock_7 | 2 |
| cust | GLOBmeas_581 | lvpai_ufactor_32 | LVPAI:UFactor:32 | GLOBprop_8:speed_of_sound_m_s | PROPblock_33,PROPblock_37,PROPblock_41,PROPblock_45,PROPblock_49 | 5 |
| cust | GLOBmeas_1324 | lvpai_ufactor_64 | LVPAI:UFactor:64 | GLOBprop_8:speed_of_sound_m_s | PROPblock_29 | 1 |
| cust | GLOBmeas_355 | vibtub_ufactor_128 | VIBTUB::UFactor:128 | GLOBprop_1:mass_density_kg_m3 | PROPblock_20 | 1 |
| cust | GLOBmeas_176 | vibtub_ufactor_32 | VIBTUB::UFactor:32 | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_16,PROPblock_24,PROPblock_4,PROPblock_8 | 5 |
| cust | GLOBmeas_236 | vibtub_ufactor_64 | VIBTUB::UFactor:64 | GLOBprop_1:mass_density_kg_m3 | PROPblock_28 | 1 |
| cust | GLOBmeas_355 | vibtub_ufactor_128 | VIBTUB:UFactor:128 | GLOBprop_1:mass_density_kg_m3 | PROPblock_44 | 1 |
| cust | GLOBmeas_176 | vibtub_ufactor_32 | VIBTUB:UFactor:32 | GLOBprop_1:mass_density_kg_m3 | PROPblock_32,PROPblock_36,PROPblock_40,PROPblock_48 | 4 |
| cust | GLOBmeas_236 | vibtub_ufactor_64 | VIBTUB:UFactor:64 | GLOBprop_1:mass_density_kg_m3 | PROPblock_52 | 1 |

---
# MTDKS | 10.1016/j.jct.2006.06.008 | GLOBlit_2707

**lit_id:** 2007-gon-cal-0
**Methods:** 8 (0 standard, 8 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_142 | captub_ufactor_4 | CAPTUB::UFactor:4 | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_13,PROPblock_7 | 3 |
| cust | GLOBmeas_142 | captub_ufactor_4 | CAPTUB:UFactor:4 | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_16,PROPblock_19,PROPblock_22,PROPblock_25,PROPblock_28,PROPblock_31,PROPblock_4 | 8 |
| cust | GLOBmeas_573 | fpint_ufactor_3 | FPINT::UFactor:3 | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_8 | 2 |
| cust | GLOBmeas_206 | fpint_ufactor_4 | FPINT::UFactor:4 | GLOBprop_8:speed_of_sound_m_s | PROPblock_14 | 1 |
| cust | GLOBmeas_573 | fpint_ufactor_3 | FPINT:UFactor:3 | GLOBprop_8:speed_of_sound_m_s | PROPblock_20,PROPblock_23,PROPblock_26,PROPblock_29,PROPblock_32,PROPblock_5 | 6 |
| cust | GLOBmeas_206 | fpint_ufactor_4 | FPINT:UFactor:4 | GLOBprop_8:speed_of_sound_m_s | PROPblock_17,PROPblock_2 | 2 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB::UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_15,PROPblock_9 | 3 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB:UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_18,PROPblock_21,PROPblock_24,PROPblock_27,PROPblock_3,PROPblock_30,PROPblock_33,PROPblock_6 | 8 |

---
# MTDKS | 10.1016/j.jct.2006.10.016 | GLOBlit_2764

**lit_id:** 2007-bhu-fer-0
**Methods:** 4 (0 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_271 | captub_ufactor_6 | CAPTUB::UFactor:6 | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_3,PROPblock_5,PROPblock_7 | 4 |
| cust | GLOBmeas_271 | captub_ufactor_6 | CAPTUB:UFactor:6 | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_13,PROPblock_15,PROPblock_17,PROPblock_9 | 5 |
| cust | GLOBmeas_167 | pycnom_ufactor_8 | PYCNOM::UFactor:8 | GLOBprop_1:mass_density_kg_m3 | PROPblock_2,PROPblock_4,PROPblock_6,PROPblock_8 | 4 |
| cust | GLOBmeas_167 | pycnom_ufactor_8 | PYCNOM:UFactor:8 | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_12,PROPblock_14,PROPblock_16,PROPblock_18 | 5 |

---
# MTDKS | 10.1016/j.jct.2007.05.004 | GLOBlit_2825

**lit_id:** 2007-gon-cal-1
**Methods:** 4 (0 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB::UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_3,PROPblock_5,PROPblock_7 | 4 |
| cust | GLOBmeas_140 | captub_ufactor_2 | CAPTUB:UFactor:2 | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_13,PROPblock_15,PROPblock_17,PROPblock_19,PROPblock_9 | 6 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB::UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_2,PROPblock_4,PROPblock_6,PROPblock_8 | 4 |
| cust | GLOBmeas_134 | vibtub_ufactor_4 | VIBTUB:UFactor:4 | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_12,PROPblock_14,PROPblock_16,PROPblock_18,PROPblock_20 | 6 |

---
# MTDKS | 10.1016/j.jct.2008.03.013 | GLOBlit_2934

**lit_id:** 2008-gon-cal-2
**Methods:** 5 (1 standard, 4 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_10,PROPblock_13,PROPblock_17,PROPblock_4,PROPblock_7 | 6 |
| cust | GLOBmeas_165 | captub_ufactor_8 | CAPTUB::UFactor:8 | GLOBprop_4:viscosity_pa_s | PROPblock_2,PROPblock_5 | 2 |
| cust | GLOBmeas_165 | captub_ufactor_8 | CAPTUB:UFactor:8 | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_14,PROPblock_16,PROPblock_8 | 4 |
| cust | GLOBmeas_138 | vibtub_ufactor_2 | VIBTUB::UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_3,PROPblock_6 | 2 |
| cust | GLOBmeas_138 | vibtub_ufactor_2 | VIBTUB:UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_9 | 4 |

---
# MTDKS | 10.1016/j.jct.2008.04.006 | GLOBlit_2944

**lit_id:** 2008-gom-gon-0
**Methods:** 8 (1 standard, 7 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_4,PROPblock_7 | 6 |
| cust | GLOBmeas_205 | captub_ufactor_16 | CAPTUB::UFactor:16 | GLOBprop_4:viscosity_pa_s | PROPblock_5 | 1 |
| cust | GLOBmeas_165 | captub_ufactor_8 | CAPTUB::UFactor:8 | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |
| cust | GLOBmeas_308 | captub_ufactor_12 | CAPTUB:UFactor:12 | GLOBprop_4:viscosity_pa_s | PROPblock_16 | 1 |
| cust | GLOBmeas_205 | captub_ufactor_16 | CAPTUB:UFactor:16 | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_8 | 2 |
| cust | GLOBmeas_165 | captub_ufactor_8 | CAPTUB:UFactor:8 | GLOBprop_4:viscosity_pa_s | PROPblock_13 | 1 |
| cust | GLOBmeas_138 | vibtub_ufactor_2 | VIBTUB::UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_3,PROPblock_6 | 2 |
| cust | GLOBmeas_138 | vibtub_ufactor_2 | VIBTUB:UFactor:2 | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_9 | 4 |

---
# MTDKS | 10.1016/j.jct.2009.06.023 | GLOBlit_3116

**lit_id:** 2009-mok-sha-1
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_29 | calculated_with_densities_of_this_investigation | Calculated with densities of this investigation | GLOBprop_28:excess_molar_volume_m3_mol | PROPblock_11,PROPblock_14,PROPblock_17 | 3 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_12,PROPblock_15,PROPblock_3,PROPblock_5,PROPblock_7,PROPblock_9 | 7 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_13,PROPblock_16,PROPblock_2,PROPblock_4,PROPblock_6,PROPblock_8 | 7 |

---
# MTDKS | 10.1016/j.jct.2010.01.013 | GLOBlit_3201

**lit_id:** 2010-ano-vig-0
**Methods:** 3 (2 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_6 | pycnometric_method | Pycnometric method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_20,PROPblock_8 | 6 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_2,PROPblock_4,PROPblock_5,PROPblock_6,PROPblock_7,PROPblock_9 | 9 |
| cust | GLOBmeas_187 | unknown | unknown | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_13,PROPblock_16,PROPblock_19,PROPblock_21,PROPblock_3 | 6 |

---
# MTDKS | 10.1016/j.jct.2010.03.022 | GLOBlit_3224

**lit_id:** 2010-gon-tri-0
**Methods:** 3 (1 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_19 | ring_tensiometer | Ring tensiometer | GLOBprop_13:surface_tension_liquidgas_n_m | PROPblock_1 | 1 |
| cust | GLOBmeas_142 | captub_ufactor_4 | CAPTUB:UFactor:4 | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |
| cust | GLOBmeas_141 | vibtub_ufactor_8 | VIBTUB:UFactor:8 | GLOBprop_1:mass_density_kg_m3 | PROPblock_3 | 1 |

---
# MTDKS | 10.1016/j.jct.2011.02.018 | GLOBlit_3363

**lit_id:** 2011-hog-tor-0
**Methods:** 2 (2 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_11 | concentric_cylinders_viscometry | Concentric cylinders viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_12,PROPblock_2,PROPblock_4,PROPblock_6,PROPblock_8 | 6 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_11,PROPblock_13,PROPblock_3,PROPblock_5,PROPblock_7,PROPblock_9 | 7 |

---
# MTDKS | 10.1016/j.jct.2011.05.037 | GLOBlit_3407

**lit_id:** 2011-kar-nou-1
**Methods:** 3 (1 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_3 | 1 |
| cust | GLOBmeas_1816 | cambridge_visco_pro_2000 | Cambridge Visco Pro 2000 | GLOBprop_4:viscosity_pa_s | PROPblock_1 | 1 |
| cust | GLOBmeas_1851 | density_shift_at_phase_transition | density shift at phase transition | GLOBprop_5:vapor_or_sublimation_pressure_kpa | PROPblock_2 | 1 |

---
# MTDKS | 10.1016/j.jct.2011.06.002 | GLOBlit_3409

**lit_id:** 2011-she-li-1
**Methods:** 3 (2 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_5 | ebulliometric_method_recirculating_still | Ebulliometric method (Recirculating still) | GLOBprop_5:vapor_or_sublimation_pressure_kpa | PROPblock_3,PROPblock_4,PROPblock_5,PROPblock_6 | 4 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |
| cust | GLOBmeas_130 | dta | DTA | GLOBprop_12:normal_melting_temperature_k | PROPblock_1 | 1 |

---
# MTDKS | 10.1016/j.jct.2011.08.028 | GLOBlit_3453

**lit_id:** 2012-gom-cal-0
**Methods:** 4 (4 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_13 | 1 |
| std | GLOBmeas_7 | sing_around_technique_in_a_fixed_path_interferometer | Sing-around technique in a fixed-path interferometer | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_15,PROPblock_18,PROPblock_2,PROPblock_21,PROPblock_24,PROPblock_27,PROPblock_5,PROPblock_8 | 9 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_10,PROPblock_14,PROPblock_17,PROPblock_20,PROPblock_23,PROPblock_26,PROPblock_4,PROPblock_7 | 9 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_16,PROPblock_19,PROPblock_22,PROPblock_25,PROPblock_28,PROPblock_3,PROPblock_6,PROPblock_9 | 9 |

---
# MTDKS | 10.1016/j.jct.2012.01.013 | GLOBlit_3540

**lit_id:** 2012-qia-xu-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_29 | calculated_with_densities_of_this_investigation | Calculated with densities of this investigation | GLOBprop_28:excess_molar_volume_m3_mol | PROPblock_14,PROPblock_17,PROPblock_20,PROPblock_23,PROPblock_26 | 5 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_10,PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_21,PROPblock_24,PROPblock_4,PROPblock_6,PROPblock_8 | 10 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_11,PROPblock_13,PROPblock_16,PROPblock_19,PROPblock_2,PROPblock_22,PROPblock_25,PROPblock_3,PROPblock_5,PROPblock_7,PROPblock_9 | 11 |

---
# MTDKS | 10.1016/j.jct.2012.02.027 | GLOBlit_3572

**lit_id:** 2012-qui-boo-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_14,PROPblock_16,PROPblock_18,PROPblock_2,PROPblock_20,PROPblock_22,PROPblock_24,PROPblock_26,PROPblock_5,PROPblock_8 | 11 |
| std | GLOBmeas_19 | ring_tensiometer | Ring tensiometer | GLOBprop_13:surface_tension_liquidgas_n_m | PROPblock_1,PROPblock_10,PROPblock_13,PROPblock_4,PROPblock_7 | 5 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_15,PROPblock_17,PROPblock_19,PROPblock_21,PROPblock_23,PROPblock_25,PROPblock_27,PROPblock_3,PROPblock_6,PROPblock_9 | 11 |

---
# MTDKS | 10.1016/j.jct.2012.05.001 | GLOBlit_3628

**lit_id:** 2012-li-she-0
**Methods:** 3 (2 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_1,PROPblock_3 | 2 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_2,PROPblock_4 | 2 |
| cust | GLOBmeas_133 | closed_cell_static_method | Closed cell (Static) method | GLOBprop_5:vapor_or_sublimation_pressure_kpa | PROPblock_10,PROPblock_5,PROPblock_6,PROPblock_7,PROPblock_8,PROPblock_9 | 6 |

---
# MTDKS | 10.1016/j.jct.2012.08.024 | GLOBlit_3711

**lit_id:** 2013-qui-mei-0
**Methods:** 2 (2 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_2,PROPblock_4,PROPblock_6 | 3 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_3,PROPblock_5 | 3 |

---
# MTDKS | 10.1016/j.jct.2012.10.002 | GLOBlit_3745

**lit_id:** 2013-kar-nou-2
**Methods:** 3 (1 standard, 2 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_69 | moving_piston_method | Moving piston method | GLOBprop_4:viscosity_pa_s | PROPblock_12,PROPblock_6,PROPblock_9 | 3 |
| cust | GLOBmeas_170 | isochor | ISOCHOR | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_11,PROPblock_2,PROPblock_3,PROPblock_5,PROPblock_8 | 6 |
| cust | GLOBmeas_1380 | samples_were_flashed_at_atmospheric_pressure_the_volume_of_the_evolved_gas_was_measured_by_the_chandler_engineering_gasometer_solubility_was_then_calculated_from_density | Samples were flashed at atmospheric pressure. The volume of the evolved gas was measured by the Chandler Engineering Gasometer. Solubility was then calculated from density. | GLOBprop_2:mole_fraction | PROPblock_10,PROPblock_4,PROPblock_7 | 3 |

---
# MTDKS | 10.1016/j.jct.2012.10.008 | GLOBlit_3748

**lit_id:** 2013-xu-che-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_13,PROPblock_17,PROPblock_19,PROPblock_21,PROPblock_23,PROPblock_25,PROPblock_3,PROPblock_6,PROPblock_7 | 10 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_1,PROPblock_11,PROPblock_15,PROPblock_4,PROPblock_8 | 5 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_12,PROPblock_14,PROPblock_16,PROPblock_18,PROPblock_2,PROPblock_20,PROPblock_22,PROPblock_24,PROPblock_5,PROPblock_9 | 10 |

---
# MTDKS | 10.1016/j.jct.2013.08.021 | GLOBlit_3972

**lit_id:** 2014-gon-gon-0
**Methods:** 6 (5 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_5 | 1 |
| std | GLOBmeas_7 | sing_around_technique_in_a_fixed_path_interferometer | Sing-around technique in a fixed-path interferometer | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_20,PROPblock_23,PROPblock_3,PROPblock_8 | 7 |
| std | GLOBmeas_9 | small_sample_50mg_dsc | Small sample (50 mg) DSC | GLOBprop_9:molar_heat_capacity_at_constant_pressure_j_k_mol | PROPblock_6 | 1 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_21,PROPblock_24,PROPblock_4,PROPblock_9 | 7 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_13,PROPblock_16,PROPblock_19,PROPblock_2,PROPblock_22,PROPblock_7 | 7 |
| cust | GLOBmeas_130 | dta | DTA | GLOBprop_12:normal_melting_temperature_k | PROPblock_1 | 1 |

---
# MTDKS | 10.1016/j.jct.2013.09.006 | GLOBlit_3988

**lit_id:** 2014-moo-omr-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_3 | 1 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1 | 1 |

---
# MTDKS | 10.1016/j.jct.2013.09.044 | GLOBlit_4013

**lit_id:** 2014-gon-kos-0
**Methods:** 3 (3 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_1 | chromatography | Chromatography | GLOBprop_6:mass_fraction | PROPblock_11 | 3 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_2,PROPblock_4,PROPblock_6,PROPblock_8 | 5 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_3,PROPblock_5,PROPblock_7,PROPblock_9 | 5 |

---
# MTDKS | 10.1016/j.jct.2013.11.026 | GLOBlit_4060

**lit_id:** 2014-flo-and-0
**Methods:** 2 (2 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_11,PROPblock_13,PROPblock_15,PROPblock_17,PROPblock_19,PROPblock_3,PROPblock_5,PROPblock_7,PROPblock_9 | 9 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_10,PROPblock_12,PROPblock_14,PROPblock_16,PROPblock_18,PROPblock_2,PROPblock_4,PROPblock_6,PROPblock_8 | 10 |

---
# MTDKS | 10.1016/j.jct.2014.01.030 | GLOBlit_4112

**lit_id:** 2014-req-gon-0
**Methods:** 5 (5 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | GLOBprop_4:viscosity_pa_s | PROPblock_5 | 1 |
| std | GLOBmeas_7 | sing_around_technique_in_a_fixed_path_interferometer | Sing-around technique in a fixed-path interferometer | GLOBprop_8:speed_of_sound_m_s | PROPblock_11,PROPblock_14,PROPblock_17,PROPblock_20,PROPblock_23,PROPblock_25,PROPblock_27,PROPblock_29,PROPblock_3,PROPblock_31,PROPblock_33,PROPblock_35,PROPblock_8 | 13 |
| std | GLOBmeas_9 | small_sample_50mg_dsc | Small sample (50 mg) DSC | GLOBprop_9:molar_heat_capacity_at_constant_pressure_j_k_mol | PROPblock_1 | 1 |
| std | GLOBmeas_3 | standard_abbe_refractometry | Standard Abbe refractometry | GLOBprop_7:refractive_index_na_dline | PROPblock_12,PROPblock_15,PROPblock_18,PROPblock_21,PROPblock_4,PROPblock_6,PROPblock_9 | 7 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_10,PROPblock_13,PROPblock_16,PROPblock_19,PROPblock_2,PROPblock_22,PROPblock_24,PROPblock_26,PROPblock_28,PROPblock_30,PROPblock_32,PROPblock_34,PROPblock_7 | 13 |

---
# MTDKS | 10.1016/j.jct.2015.02.024 | GLOBlit_4331

**lit_id:** 2015-wla-mar-1
**Methods:** 4 (3 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_1 | chromatography | Chromatography | GLOBprop_3:activity_coefficient | PROPblock_10,PROPblock_11,PROPblock_12,PROPblock_13,PROPblock_14,PROPblock_15,PROPblock_16,PROPblock_17,PROPblock_18,PROPblock_19,PROPblock_20,PROPblock_21,PROPblock_22,PROPblock_23,PROPblock_24,PROPblock_25,PROPblock_26,PROPblock_27,PROPblock_28,PROPblock_29,PROPblock_30,PROPblock_31,PROPblock_32,PROPblock_33,PROPblock_34,PROPblock_35,PROPblock_36,PROPblock_37,PROPblock_38,PROPblock_39,PROPblock_40,PROPblock_41,PROPblock_42,PROPblock_43,PROPblock_44,PROPblock_45,PROPblock_46,PROPblock_47,PROPblock_48,PROPblock_49,PROPblock_5,PROPblock_50,PROPblock_51,PROPblock_52,PROPblock_53,PROPblock_54,PROPblock_55,PROPblock_56,PROPblock_57,PROPblock_58,PROPblock_59,PROPblock_6,PROPblock_60,PROPblock_61,PROPblock_62,PROPblock_63,PROPblock_64,PROPblock_65,PROPblock_7,PROPblock_8,PROPblock_9 | 61 |
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_4 | 1 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_3 | 1 |
| cust | GLOBmeas_130 | dta | DTA | GLOBprop_12:normal_melting_temperature_k; GLOBprop_16:triple_point_temperature_k | PROPblock_1,PROPblock_2 | 2 |

---
# MTDKS | 10.1016/j.jct.2015.04.027 | GLOBlit_4369

**lit_id:** 2015-che-che-1
**Methods:** 2 (2 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_10,PROPblock_12,PROPblock_14,PROPblock_16,PROPblock_18,PROPblock_2,PROPblock_4,PROPblock_6,PROPblock_8 | 9 |
| std | GLOBmeas_2 | vibrating_tube_method | Vibrating tube method | GLOBprop_1:mass_density_kg_m3 | PROPblock_1,PROPblock_11,PROPblock_13,PROPblock_15,PROPblock_17,PROPblock_3,PROPblock_5,PROPblock_7,PROPblock_9 | 9 |


## 4. search_system_registry

# Raw tool result: `search_system_registry`

Serialization: `json`

```json
{
  "error": {
    "message": "system_type must use the exact registry value: unary, binary, ternary, quaternary, or N-component",
    "type": "ValueError"
  }
}
```


## 5. block_search_adv

**Summary:** 50 sources (44 rendered) report pure ethanol viscosity near 298.15 K. Values range from 0.00104 to 0.0012963 Pa·s, with the majority clustering around 0.001071–0.001096 Pa·s. Measurement methods are not encoded in the block metadata — individual DOI lookups would be needed for technique details.

**Triage: 50 blocks returned — condensed table of all 44 rendered entries sorted by viscosity.**

| Viscosity (Pa·s) | DOI | `PROPblock` | `GLOBlit` |
|---|---|---|---|
| 0.00104 | 10.1021/acs.jced.7b00944 | PROPblock_6 | GLOBlit_7368 |
| 0.001056 | 10.1021/acs.jced.8b00086 | PROPblock_17 | GLOBlit_7448 |
| 0.0010569 | 10.1016/j.jct.2009.06.023 | PROPblock_1 | GLOBlit_3116 |
| 0.001071 | 10.1016/j.jct.2017.07.022 | PROPblock_2 | GLOBlit_5074 |
| 0.001071 | 10.1021/acs.jced.5b00259 | PROPblock_6 | GLOBlit_6567 |
| 0.001071 | 10.1021/acs.jced.5b00365 | PROPblock_4 | GLOBlit_6598 |
| 0.001073 | 10.1016/j.jct.2005.10.022 | P

## 6. search_meas_from_block

**Measurements from 10.1021/acs.jced.7b00944 / PROPblock_6 @ declared** — lit_num_id: GLOBlit_7368 — IDs: ['GLOBmeas_8']

## DOI measurement card

# MTDKS | 10.1021/acs.jced.7b00944 | GLOBlit_7368

**lit_id:** 2018-ozt-est-0
**Methods:** 1 (1 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_6 | 1 |

## Global measurement chemistry projection

### GLOBmeas_8

**Name:** Falling or rolling sphere viscometry
**Family:** Viscometry
**ThermoML std:** Falling or rolling sphere viscometry
**Modality:** contact=yes, destructive=no, in_situ=no, imaging=no
**Usage:** 1243 instances | 276 papers | groups=TransportProp
**Per-group:** TransportProp: 1243 inst/276 papers
- [additional canonical measurement details omitted]

### measurement_scope
**direct_observables:**
- fall time or roll time of a sphere over a calibrated distance
- sphere position as a function of time (optical or inductive detection)
**derived_observables:**
- dynamic viscosity η (from fall/roll time, sphere and fluid densities, and calibration constant)
- kinematic viscosity ν = η/ρ (when fluid density is known)
**target_properties:**
- dynamic viscosity η
- kinematic viscosity ν
**phases_measured:**
- liquid (Newtonian fluids)
- liquid mixtures
**supported_sample_types:**
- pure Newtonian liquids
- binary and multicomponent liquid mixtures
**unsupported_sample_types:**
- gases (density difference too small for practical fall times)
- strongly non-Newtonian or viscoelastic fluids (Stokes law inapplicable)
**typical_output_formats:**
- η vs. T curve at fixed pressure
- η vs. P curve at fixed temperature
**units:**
- dynamic_viscosity: mPa·s (cP)
- kinematic_viscosity: mm²/s (cSt)
- [additional canonical measurement details omitted]

### experimental_parameters
**constraints:**
- **viscosity_range** — typical: 0.5 mPa·s to 10⁵ mPa·s — limits: lower limit set by minimum resolvable fall time; upper limit set by impractically long fall times or available sphere densities — notes: range is adjusted by selecting sphere material and diameter; rolling-ball instruments (e.g., Anton Paar Lovis) extend the low-viscosity range to ~0.3 mPa·s
- **temperature_range** — typical: 253 K to 473 K — limits: limited by thermostat capability and tube/seal materials; high-pressure variants may operate to 523 K — notes: temperature stability of ±0.01 K is typical for research-grade instruments
**variables:**
- **temperature** — typical: 253 K to 473 K — effect: viscosity decreases exponentially with increasing temperature for most liquids; temperature is the most common independent variable
- **pressure** — typical: 0.1 MPa to 200 MPa — effect: viscosity generally increases with pressure; falling-sinker viscometers are designed specifically for P-dependent measurements
- [additional canonical measurement details omitted]

### setup_and_requirements
**instrument_components:**
- precision glass or metal tube — cylindrical tube (vertical for falling-ball; inclined for rolling-ball/Hoeppler) with calibrated measurement section and known inner diameter
- calibrated sphere or sinker — sphere of known diameter, density, and surface finish (steel, glass, tungsten carbide, or gold-plated for chemical resistance)
**environmental_requirements:**
- temperature control of the sample tube to ±0.01–0.05 K via thermostatted jacket
- vibration-free mounting to prevent perturbation of sphere trajectory
**sample_requirements:**
- geometry: ['liquid filling the measurement tube completely with no trapped air bubbles']
- size_limits: typically 1–40 mL depending on tube volume; Hoeppler ~40 mL; micro rolling-ball (Lovis) ~0.1 mL
**calibration_requirements:**
- instrument constant K determination using certified viscosity reference standards (e.g., Cannon N-series oils or PTB/NIST certified fluids)
- sphere diameter and density verification with micrometer and precision balance or density standard
**reference_materials:**
- Cannon certified viscosity reference standards (N-series: N4, N10, N35, N100, N350, etc.) — NIST-traceable oils spanning 2 to 100,000 mPa·s
- NIST SRM 2490 (polyisobutylene in cetane) — high-viscosity standard for Newtonian behavior verification
**consumables:**
- precision spheres (replacement balls of calibrated diameter and density)
- cleaning solvents (acetone, ethanol, petroleum ether) for tube and sphere cleaning
**safety_notes:**
- high-pressure falling-sinker instruments operate at pressures up to hundreds of MPa — follow high-pressure equipment safety protocols
- glass tubes are fragile — handle with care to avoid cracks that compromise structural integrity
- [additional canonical measurement details omitted]

### performance
**sensitivity:** sensitive to dynamic viscosity changes of ~0.1% for well-controlled instruments with precise timing
**detection_limit:** minimum measurable viscosity ~0.3 mPa·s (micro rolling-ball instruments such as Anton Paar Lovis 2000 M/ME); ~0.5 mPa·s for standard falling-ball
**resolution:**
- spatial: not applicable (bulk measurement)
- temporal: fall/roll time resolution ~0.001 s with electronic timing; translates to viscosity resolution of ~0.01 mPa·s at low viscosities
**dynamic_range:** 0.3 mPa·s to 10⁵ mPa·s (over 5 decades, selected by choice of sphere and tube geometry)
**accuracy:** 0.5–2% of measured viscosity with proper calibration; 0.5% achievable with certified reference standards and careful temperature control
**precision:** 0.1–0.5% coefficient of variation from repeated fall/roll time measurements at a given condition
**throughput:** single sample per tube loading; one viscosity measurement in 10 s to 30 min depending on viscosity; full T-sweep takes 1–4 hours
**measurement_speed:** individual measurement: seconds (low viscosity) to minutes (high viscosity); rapid for a viscometer compared to capillary methods at high viscosities
- [additional canonical measurement details omitted]

### data_and_interpretation
**raw_signal_type:** fall time or roll time of a sphere between two detection points separated by a calibrated distance, recorded by optical or inductive sensors and a digital timer
**preprocessing_steps:**
- average multiple (typically 5–10) replicate fall/roll time measurements to reduce random timing errors
- apply temperature correction to sphere and fluid densities using known thermal expansion coefficients
**analysis_methods:**
- Stokes law calculation: η = K·(ρs − ρf)·t, where K is the calibration constant, ρs is sphere density, ρf is fluid density, and t is fall/roll time
- Faxén wall correction: multiplicative factor F(d/D) correcting for the influence of tube walls on drag; F = 1 − 2.104(d/D) + 2.089(d/D)³ − 0.948(d/D)⁵ for falling-ball geometry
**model_assumptions:**
- fluid is Newtonian — viscosity is independent of shear rate (valid for the very low shear rates in a falling-sphere geometry)
- sphere reaches terminal velocity before entering the measurement zone (acceleration phase is complete)
**fit_parameters:**
- calibration constant K (or K(θ) for rolling-ball at specific angle)
- sphere density ρs and fluid density ρf
**common_artifacts:**
- air bubble adhesion on sphere surface — reduces effective density difference and increases apparent viscosity
- sphere eccentricity — off-axis fall path changes effective wall correction and produces inconsistent times
**quality_control_checks:**
- measure a certified viscosity reference standard before and after sample measurements to verify instrument constant K stability
- repeat fall/roll time measurements (≥5 replicates) and confirm coefficient of variation < 0.5%
**failure_modes:**
- sphere stuck or slowed by debris or deposits on tube wall
- air bubble attached to sphere — artificially buoyant sphere gives erroneously high viscosity
- [additional canonical measurement details omitted]

### uncertainty
**level:** typical combined standard uncertainty 0.5–2% for dynamic viscosity; 0.5% achievable with best practice
**random_sources:**
- timing variability between replicate fall/roll measurements
- small temperature fluctuations within the thermostat (±0.01–0.05 K)
**systematic_sources:**
- calibration constant K uncertainty (propagated from reference fluid viscosity uncertainty)
- sphere density uncertainty (±0.01–0.1%)
**operator_dependence:** low to moderate — filling the tube without bubbles, sphere handling, and cleaning procedure depend on operator care; automated instruments (e.g., Lovis) reduce operator dependence significantly
**model_dependence:** low for Newtonian fluids in the Stokes regime — the underlying Stokes law is well-validated; increases for higher Re, non-spherical sinkers, or non-Newtonian fluids where additional corrections and assumptions are needed
**dominant_error_sources:**
- density difference (ρs − ρf) uncertainty — this directly scales the viscosity result; a 0.1% error in either density propagates fully
- temperature measurement accuracy — viscosity has a strong T-dependence, so even small offsets cause significant systematic bias
**reported_as:**
- combined expanded uncertainty U(η) at 95% confidence level (k=2)
- relative expanded uncertainty as percentage of η
**thermoml_encoding:** nCombExpandUncertValue at 95% confidence level
- [additional canonical measurement details omitted]


## 7. search_meas_from_block

**Measurements from 10.1016/j.jct.2009.06.023 / PROPblock_1 @ declared** — lit_num_id: GLOBlit_3116 — IDs: ['GLOBmeas_8']

## DOI measurement card

# MTDKS | 10.1016/j.jct.2009.06.023 | GLOBlit_3116

**lit_id:** 2009-mok-sha-1
**Methods:** 1 (1 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_1 | 1 |

## Global measurement chemistry projection

### GLOBmeas_8

**Name:** Falling or rolling sphere viscometry
**Family:** Viscometry
**ThermoML std:** Falling or rolling sphere viscometry
**Modality:** contact=yes, destructive=no, in_situ=no, imaging=no
**Usage:** 1243 instances | 276 papers | groups=TransportProp
**Per-group:** TransportProp: 1243 inst/276 papers
- [additional canonical measurement details omitted]

### measurement_scope
**direct_observables:**
- fall time or roll time of a sphere over a calibrated distance
- sphere position as a function of time (optical or inductive detection)
**derived_observables:**
- dynamic viscosity η (from fall/roll time, sphere and fluid densities, and calibration constant)
- kinematic viscosity ν = η/ρ (when fluid density is known)
**target_properties:**
- dynamic viscosity η
- kinematic viscosity ν
**phases_measured:**
- liquid (Newtonian fluids)
- liquid mixtures
**supported_sample_types:**
- pure Newtonian liquids
- binary and multicomponent liquid mixtures
**unsupported_sample_types:**
- gases (density difference too small for practical fall times)
- strongly non-Newtonian or viscoelastic fluids (Stokes law inapplicable)
**typical_output_formats:**
- η vs. T curve at fixed pressure
- η vs. P curve at fixed temperature
**units:**
- dynamic_viscosity: mPa·s (cP)
- kinematic_viscosity: mm²/s (cSt)
- [additional canonical measurement details omitted]

### experimental_parameters
**constraints:**
- **viscosity_range** — typical: 0.5 mPa·s to 10⁵ mPa·s — limits: lower limit set by minimum resolvable fall time; upper limit set by impractically long fall times or available sphere densities — notes: range is adjusted by selecting sphere material and diameter; rolling-ball instruments (e.g., Anton Paar Lovis) extend the low-viscosity range to ~0.3 mPa·s
- **temperature_range** — typical: 253 K to 473 K — limits: limited by thermostat capability and tube/seal materials; high-pressure variants may operate to 523 K — notes: temperature stability of ±0.01 K is typical for research-grade instruments
**variables:**
- **temperature** — typical: 253 K to 473 K — effect: viscosity decreases exponentially with increasing temperature for most liquids; temperature is the most common independent variable
- **pressure** — typical: 0.1 MPa to 200 MPa — effect: viscosity generally increases with pressure; falling-sinker viscometers are designed specifically for P-dependent measurements
- [additional canonical measurement details omitted]

### setup_and_requirements
**instrument_components:**
- precision glass or metal tube — cylindrical tube (vertical for falling-ball; inclined for rolling-ball/Hoeppler) with calibrated measurement section and known inner diameter
- calibrated sphere or sinker — sphere of known diameter, density, and surface finish (steel, glass, tungsten carbide, or gold-plated for chemical resistance)
**environmental_requirements:**
- temperature control of the sample tube to ±0.01–0.05 K via thermostatted jacket
- vibration-free mounting to prevent perturbation of sphere trajectory
**sample_requirements:**
- geometry: ['liquid filling the measurement tube completely with no trapped air bubbles']
- size_limits: typically 1–40 mL depending on tube volume; Hoeppler ~40 mL; micro rolling-ball (Lovis) ~0.1 mL
**calibration_requirements:**
- instrument constant K determination using certified viscosity reference standards (e.g., Cannon N-series oils or PTB/NIST certified fluids)
- sphere diameter and density verification with micrometer and precision balance or density standard
**reference_materials:**
- Cannon certified viscosity reference standards (N-series: N4, N10, N35, N100, N350, etc.) — NIST-traceable oils spanning 2 to 100,000 mPa·s
- NIST SRM 2490 (polyisobutylene in cetane) — high-viscosity standard for Newtonian behavior verification
**consumables:**
- precision spheres (replacement balls of calibrated diameter and density)
- cleaning solvents (acetone, ethanol, petroleum ether) for tube and sphere cleaning
**safety_notes:**
- high-pressure falling-sinker instruments operate at pressures up to hundreds of MPa — follow high-pressure equipment safety protocols
- glass tubes are fragile — handle with care to avoid cracks that compromise structural integrity
- [additional canonical measurement details omitted]

### performance
**sensitivity:** sensitive to dynamic viscosity changes of ~0.1% for well-controlled instruments with precise timing
**detection_limit:** minimum measurable viscosity ~0.3 mPa·s (micro rolling-ball instruments such as Anton Paar Lovis 2000 M/ME); ~0.5 mPa·s for standard falling-ball
**resolution:**
- spatial: not applicable (bulk measurement)
- temporal: fall/roll time resolution ~0.001 s with electronic timing; translates to viscosity resolution of ~0.01 mPa·s at low viscosities
**dynamic_range:** 0.3 mPa·s to 10⁵ mPa·s (over 5 decades, selected by choice of sphere and tube geometry)
**accuracy:** 0.5–2% of measured viscosity with proper calibration; 0.5% achievable with certified reference standards and careful temperature control
**precision:** 0.1–0.5% coefficient of variation from repeated fall/roll time measurements at a given condition
**throughput:** single sample per tube loading; one viscosity measurement in 10 s to 30 min depending on viscosity; full T-sweep takes 1–4 hours
**measurement_speed:** individual measurement: seconds (low viscosity) to minutes (high viscosity); rapid for a viscometer compared to capillary methods at high viscosities
- [additional canonical measurement details omitted]

### data_and_interpretation
**raw_signal_type:** fall time or roll time of a sphere between two detection points separated by a calibrated distance, recorded by optical or inductive sensors and a digital timer
**preprocessing_steps:**
- average multiple (typically 5–10) replicate fall/roll time measurements to reduce random timing errors
- apply temperature correction to sphere and fluid densities using known thermal expansion coefficients
**analysis_methods:**
- Stokes law calculation: η = K·(ρs − ρf)·t, where K is the calibration constant, ρs is sphere density, ρf is fluid density, and t is fall/roll time
- Faxén wall correction: multiplicative factor F(d/D) correcting for the influence of tube walls on drag; F = 1 − 2.104(d/D) + 2.089(d/D)³ − 0.948(d/D)⁵ for falling-ball geometry
**model_assumptions:**
- fluid is Newtonian — viscosity is independent of shear rate (valid for the very low shear rates in a falling-sphere geometry)
- sphere reaches terminal velocity before entering the measurement zone (acceleration phase is complete)
**fit_parameters:**
- calibration constant K (or K(θ) for rolling-ball at specific angle)
- sphere density ρs and fluid density ρf
**common_artifacts:**
- air bubble adhesion on sphere surface — reduces effective density difference and increases apparent viscosity
- sphere eccentricity — off-axis fall path changes effective wall correction and produces inconsistent times
**quality_control_checks:**
- measure a certified viscosity reference standard before and after sample measurements to verify instrument constant K stability
- repeat fall/roll time measurements (≥5 replicates) and confirm coefficient of variation < 0.5%
**failure_modes:**
- sphere stuck or slowed by debris or deposits on tube wall
- air bubble attached to sphere — artificially buoyant sphere gives erroneously high viscosity
- [additional canonical measurement details omitted]

### uncertainty
**level:** typical combined standard uncertainty 0.5–2% for dynamic viscosity; 0.5% achievable with best practice
**random_sources:**
- timing variability between replicate fall/roll measurements
- small temperature fluctuations within the thermostat (±0.01–0.05 K)
**systematic_sources:**
- calibration constant K uncertainty (propagated from reference fluid viscosity uncertainty)
- sphere density uncertainty (±0.01–0.1%)
**operator_dependence:** low to moderate — filling the tube without bubbles, sphere handling, and cleaning procedure depend on operator care; automated instruments (e.g., Lovis) reduce operator dependence significantly
**model_dependence:** low for Newtonian fluids in the Stokes regime — the underlying Stokes law is well-validated; increases for higher Re, non-spherical sinkers, or non-Newtonian fluids where additional corrections and assumptions are needed
**dominant_error_sources:**
- density difference (ρs − ρf) uncertainty — this directly scales the viscosity result; a 0.1% error in either density propagates fully
- temperature measurement accuracy — viscosity has a strong T-dependence, so even small offsets cause significant systematic bias
**reported_as:**
- combined expanded uncertainty U(η) at 95% confidence level (k=2)
- relative expanded uncertainty as percentage of η
**thermoml_encoding:** nCombExpandUncertValue at 95% confidence level
- [additional canonical measurement details omitted]


## 8. search_meas_from_block

**Measurements from 10.1016/j.jct.2017.07.022 / PROPblock_2 @ declared** — lit_num_id: GLOBlit_5074 — IDs: ['GLOBmeas_8']

## DOI measurement card

# MTDKS | 10.1016/j.jct.2017.07.022 | GLOBlit_5074

**lit_id:** 2017-xin-yan-0
**Methods:** 1 (1 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |

## Global measurement chemistry projection

### GLOBmeas_8

**Name:** Falling or rolling sphere viscometry
**Family:** Viscometry
**ThermoML std:** Falling or rolling sphere viscometry
**Modality:** contact=yes, destructive=no, in_situ=no, imaging=no
**Usage:** 1243 instances | 276 papers | groups=TransportProp
**Per-group:** TransportProp: 1243 inst/276 papers
- [additional canonical measurement details omitted]

### measurement_scope
**direct_observables:**
- fall time or roll time of a sphere over a calibrated distance
- sphere position as a function of time (optical or inductive detection)
**derived_observables:**
- dynamic viscosity η (from fall/roll time, sphere and fluid densities, and calibration constant)
- kinematic viscosity ν = η/ρ (when fluid density is known)
**target_properties:**
- dynamic viscosity η
- kinematic viscosity ν
**phases_measured:**
- liquid (Newtonian fluids)
- liquid mixtures
**supported_sample_types:**
- pure Newtonian liquids
- binary and multicomponent liquid mixtures
**unsupported_sample_types:**
- gases (density difference too small for practical fall times)
- strongly non-Newtonian or viscoelastic fluids (Stokes law inapplicable)
**typical_output_formats:**
- η vs. T curve at fixed pressure
- η vs. P curve at fixed temperature
**units:**
- dynamic_viscosity: mPa·s (cP)
- kinematic_viscosity: mm²/s (cSt)
- [additional canonical measurement details omitted]

### experimental_parameters
**constraints:**
- **viscosity_range** — typical: 0.5 mPa·s to 10⁵ mPa·s — limits: lower limit set by minimum resolvable fall time; upper limit set by impractically long fall times or available sphere densities — notes: range is adjusted by selecting sphere material and diameter; rolling-ball instruments (e.g., Anton Paar Lovis) extend the low-viscosity range to ~0.3 mPa·s
- **temperature_range** — typical: 253 K to 473 K — limits: limited by thermostat capability and tube/seal materials; high-pressure variants may operate to 523 K — notes: temperature stability of ±0.01 K is typical for research-grade instruments
**variables:**
- **temperature** — typical: 253 K to 473 K — effect: viscosity decreases exponentially with increasing temperature for most liquids; temperature is the most common independent variable
- **pressure** — typical: 0.1 MPa to 200 MPa — effect: viscosity generally increases with pressure; falling-sinker viscometers are designed specifically for P-dependent measurements
- [additional canonical measurement details omitted]

### setup_and_requirements
**instrument_components:**
- precision glass or metal tube — cylindrical tube (vertical for falling-ball; inclined for rolling-ball/Hoeppler) with calibrated measurement section and known inner diameter
- calibrated sphere or sinker — sphere of known diameter, density, and surface finish (steel, glass, tungsten carbide, or gold-plated for chemical resistance)
**environmental_requirements:**
- temperature control of the sample tube to ±0.01–0.05 K via thermostatted jacket
- vibration-free mounting to prevent perturbation of sphere trajectory
**sample_requirements:**
- geometry: ['liquid filling the measurement tube completely with no trapped air bubbles']
- size_limits: typically 1–40 mL depending on tube volume; Hoeppler ~40 mL; micro rolling-ball (Lovis) ~0.1 mL
**calibration_requirements:**
- instrument constant K determination using certified viscosity reference standards (e.g., Cannon N-series oils or PTB/NIST certified fluids)
- sphere diameter and density verification with micrometer and precision balance or density standard
**reference_materials:**
- Cannon certified viscosity reference standards (N-series: N4, N10, N35, N100, N350, etc.) — NIST-traceable oils spanning 2 to 100,000 mPa·s
- NIST SRM 2490 (polyisobutylene in cetane) — high-viscosity standard for Newtonian behavior verification
**consumables:**
- precision spheres (replacement balls of calibrated diameter and density)
- cleaning solvents (acetone, ethanol, petroleum ether) for tube and sphere cleaning
**safety_notes:**
- high-pressure falling-sinker instruments operate at pressures up to hundreds of MPa — follow high-pressure equipment safety protocols
- glass tubes are fragile — handle with care to avoid cracks that compromise structural integrity
- [additional canonical measurement details omitted]

### performance
**sensitivity:** sensitive to dynamic viscosity changes of ~0.1% for well-controlled instruments with precise timing
**detection_limit:** minimum measurable viscosity ~0.3 mPa·s (micro rolling-ball instruments such as Anton Paar Lovis 2000 M/ME); ~0.5 mPa·s for standard falling-ball
**resolution:**
- spatial: not applicable (bulk measurement)
- temporal: fall/roll time resolution ~0.001 s with electronic timing; translates to viscosity resolution of ~0.01 mPa·s at low viscosities
**dynamic_range:** 0.3 mPa·s to 10⁵ mPa·s (over 5 decades, selected by choice of sphere and tube geometry)
**accuracy:** 0.5–2% of measured viscosity with proper calibration; 0.5% achievable with certified reference standards and careful temperature control
**precision:** 0.1–0.5% coefficient of variation from repeated fall/roll time measurements at a given condition
**throughput:** single sample per tube loading; one viscosity measurement in 10 s to 30 min depending on viscosity; full T-sweep takes 1–4 hours
**measurement_speed:** individual measurement: seconds (low viscosity) to minutes (high viscosity); rapid for a viscometer compared to capillary methods at high viscosities
- [additional canonical measurement details omitted]

### data_and_interpretation
**raw_signal_type:** fall time or roll time of a sphere between two detection points separated by a calibrated distance, recorded by optical or inductive sensors and a digital timer
**preprocessing_steps:**
- average multiple (typically 5–10) replicate fall/roll time measurements to reduce random timing errors
- apply temperature correction to sphere and fluid densities using known thermal expansion coefficients
**analysis_methods:**
- Stokes law calculation: η = K·(ρs − ρf)·t, where K is the calibration constant, ρs is sphere density, ρf is fluid density, and t is fall/roll time
- Faxén wall correction: multiplicative factor F(d/D) correcting for the influence of tube walls on drag; F = 1 − 2.104(d/D) + 2.089(d/D)³ − 0.948(d/D)⁵ for falling-ball geometry
**model_assumptions:**
- fluid is Newtonian — viscosity is independent of shear rate (valid for the very low shear rates in a falling-sphere geometry)
- sphere reaches terminal velocity before entering the measurement zone (acceleration phase is complete)
**fit_parameters:**
- calibration constant K (or K(θ) for rolling-ball at specific angle)
- sphere density ρs and fluid density ρf
**common_artifacts:**
- air bubble adhesion on sphere surface — reduces effective density difference and increases apparent viscosity
- sphere eccentricity — off-axis fall path changes effective wall correction and produces inconsistent times
**quality_control_checks:**
- measure a certified viscosity reference standard before and after sample measurements to verify instrument constant K stability
- repeat fall/roll time measurements (≥5 replicates) and confirm coefficient of variation < 0.5%
**failure_modes:**
- sphere stuck or slowed by debris or deposits on tube wall
- air bubble attached to sphere — artificially buoyant sphere gives erroneously high viscosity
- [additional canonical measurement details omitted]

### uncertainty
**level:** typical combined standard uncertainty 0.5–2% for dynamic viscosity; 0.5% achievable with best practice
**random_sources:**
- timing variability between replicate fall/roll measurements
- small temperature fluctuations within the thermostat (±0.01–0.05 K)
**systematic_sources:**
- calibration constant K uncertainty (propagated from reference fluid viscosity uncertainty)
- sphere density uncertainty (±0.01–0.1%)
**operator_dependence:** low to moderate — filling the tube without bubbles, sphere handling, and cleaning procedure depend on operator care; automated instruments (e.g., Lovis) reduce operator dependence significantly
**model_dependence:** low for Newtonian fluids in the Stokes regime — the underlying Stokes law is well-validated; increases for higher Re, non-spherical sinkers, or non-Newtonian fluids where additional corrections and assumptions are needed
**dominant_error_sources:**
- density difference (ρs − ρf) uncertainty — this directly scales the viscosity result; a 0.1% error in either density propagates fully
- temperature measurement accuracy — viscosity has a strong T-dependence, so even small offsets cause significant systematic bias
**reported_as:**
- combined expanded uncertainty U(η) at 95% confidence level (k=2)
- relative expanded uncertainty as percentage of η
**thermoml_encoding:** nCombExpandUncertValue at 95% confidence level
- [additional canonical measurement details omitted]


## 9. search_meas_from_block

**Measurements from 10.1016/j.jct.2005.10.022 / PROPblock_2 @ declared** — lit_num_id: GLOBlit_2632 — IDs: ['GLOBmeas_497']

## DOI measurement card

# MTDKS | 10.1016/j.jct.2005.10.022 | GLOBlit_2632

**lit_id:** 2006-mut-man-0
**Methods:** 1 (0 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_497 | schott_gerate_viscometer_model_avs_350 | Schott-Gerate viscometer model AVS 350 | GLOBprop_4:viscosity_pa_s | PROPblock_2 | 1 |

## Global measurement chemistry projection

### GLOBmeas_497

**Name:** Schott-Gerate viscometer model AVS 350
**Family:** Custom
**Usage:** 13 instances | 1 papers | groups=TransportProp
**Per-group:** TransportProp: 13 inst/1 papers
- [additional canonical measurement details omitted]

### measurement_scope
- [section unavailable]

### experimental_parameters
- [section unavailable]

### setup_and_requirements
- [section unavailable]

### performance
- [section unavailable]

### data_and_interpretation
- [section unavailable]

### uncertainty
- [section unavailable]


## 10. search_meas_from_block

**Measurements from 10.1021/acs.jced.5b00259 / PROPblock_6 @ declared** — lit_num_id: GLOBlit_6567 — IDs: ['GLOBmeas_234']

## DOI measurement card

# MTDKS | 10.1021/acs.jced.5b00259 | GLOBlit_6567

**lit_id:** 2015-lu-wu-0
**Methods:** 1 (0 standard, 1 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| cust | GLOBmeas_234 | sphere_ufactor_4 | SPHERE:UFactor:4 | GLOBprop_4:viscosity_pa_s | PROPblock_6 | 1 |

## Global measurement chemistry projection

### GLOBmeas_234

**Name:** SPHERE:UFactor:4
**Family:** Custom
**Usage:** 57 instances | 13 papers | groups=TransportProp
**Per-group:** TransportProp: 57 inst/13 papers
- [additional canonical measurement details omitted]

### measurement_scope
- [section unavailable]

### experimental_parameters
- [section unavailable]

### setup_and_requirements
- [section unavailable]

### performance
- [section unavailable]

### data_and_interpretation
- [section unavailable]

### uncertainty
- [section unavailable]


## 11. search_meas_from_block

**Measurements from 10.1021/acs.jced.8b00086 / PROPblock_17 @ declared** — lit_num_id: GLOBlit_7448 — IDs: ['GLOBmeas_8']

## DOI measurement card

# MTDKS | 10.1021/acs.jced.8b00086 | GLOBlit_7448

**lit_id:** 2018-gon-pal-0
**Methods:** 1 (1 standard, 0 custom)

| Type | meas_num_id | meas_id | Method | Properties | Block IDs | Count |
|------|-------------|---------|--------|------------|-----------|-------|
| std | GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | GLOBprop_4:viscosity_pa_s | PROPblock_17 | 1 |

## Global measurement chemistry projection

### GLOBmeas_8

**Name:** Falling or rolling sphere viscometry
**Family:** Viscometry
**ThermoML std:** Falling or rolling sphere viscometry
**Modality:** contact=yes, destructive=no, in_situ=no, imaging=no
**Usage:** 1243 instances | 276 papers | groups=TransportProp
**Per-group:** TransportProp: 1243 inst/276 papers
- [additional canonical measurement details omitted]

### measurement_scope
**direct_observables:**
- fall time or roll time of a sphere over a calibrated distance
- sphere position as a function of time (optical or inductive detection)
**derived_observables:**
- dynamic viscosity η (from fall/roll time, sphere and fluid densities, and calibration constant)
- kinematic viscosity ν = η/ρ (when fluid density is known)
**target_properties:**
- dynamic viscosity η
- kinematic viscosity ν
**phases_measured:**
- liquid (Newtonian fluids)
- liquid mixtures
**supported_sample_types:**
- pure Newtonian liquids
- binary and multicomponent liquid mixtures
**unsupported_sample_types:**
- gases (density difference too small for practical fall times)
- strongly non-Newtonian or viscoelastic fluids (Stokes law inapplicable)
**typical_output_formats:**
- η vs. T curve at fixed pressure
- η vs. P curve at fixed temperature
**units:**
- dynamic_viscosity: mPa·s (cP)
- kinematic_viscosity: mm²/s (cSt)
- [additional canonical measurement details omitted]

### experimental_parameters
**constraints:**
- **viscosity_range** — typical: 0.5 mPa·s to 10⁵ mPa·s — limits: lower limit set by minimum resolvable fall time; upper limit set by impractically long fall times or available sphere densities — notes: range is adjusted by selecting sphere material and diameter; rolling-ball instruments (e.g., Anton Paar Lovis) extend the low-viscosity range to ~0.3 mPa·s
- **temperature_range** — typical: 253 K to 473 K — limits: limited by thermostat capability and tube/seal materials; high-pressure variants may operate to 523 K — notes: temperature stability of ±0.01 K is typical for research-grade instruments
**variables:**
- **temperature** — typical: 253 K to 473 K — effect: viscosity decreases exponentially with increasing temperature for most liquids; temperature is the most common independent variable
- **pressure** — typical: 0.1 MPa to 200 MPa — effect: viscosity generally increases with pressure; falling-sinker viscometers are designed specifically for P-dependent measurements
- [additional canonical measurement details omitted]

### setup_and_requirements
**instrument_components:**
- precision glass or metal tube — cylindrical tube (vertical for falling-ball; inclined for rolling-ball/Hoeppler) with calibrated measurement section and known inner diameter
- calibrated sphere or sinker — sphere of known diameter, density, and surface finish (steel, glass, tungsten carbide, or gold-plated for chemical resistance)
**environmental_requirements:**
- temperature control of the sample tube to ±0.01–0.05 K via thermostatted jacket
- vibration-free mounting to prevent perturbation of sphere trajectory
**sample_requirements:**
- geometry: ['liquid filling the measurement tube completely with no trapped air bubbles']
- size_limits: typically 1–40 mL depending on tube volume; Hoeppler ~40 mL; micro rolling-ball (Lovis) ~0.1 mL
**calibration_requirements:**
- instrument constant K determination using certified viscosity reference standards (e.g., Cannon N-series oils or PTB/NIST certified fluids)
- sphere diameter and density verification with micrometer and precision balance or density standard
**reference_materials:**
- Cannon certified viscosity reference standards (N-series: N4, N10, N35, N100, N350, etc.) — NIST-traceable oils spanning 2 to 100,000 mPa·s
- NIST SRM 2490 (polyisobutylene in cetane) — high-viscosity standard for Newtonian behavior verification
**consumables:**
- precision spheres (replacement balls of calibrated diameter and density)
- cleaning solvents (acetone, ethanol, petroleum ether) for tube and sphere cleaning
**safety_notes:**
- high-pressure falling-sinker instruments operate at pressures up to hundreds of MPa — follow high-pressure equipment safety protocols
- glass tubes are fragile — handle with care to avoid cracks that compromise structural integrity
- [additional canonical measurement details omitted]

### performance
**sensitivity:** sensitive to dynamic viscosity changes of ~0.1% for well-controlled instruments with precise timing
**detection_limit:** minimum measurable viscosity ~0.3 mPa·s (micro rolling-ball instruments such as Anton Paar Lovis 2000 M/ME); ~0.5 mPa·s for standard falling-ball
**resolution:**
- spatial: not applicable (bulk measurement)
- temporal: fall/roll time resolution ~0.001 s with electronic timing; translates to viscosity resolution of ~0.01 mPa·s at low viscosities
**dynamic_range:** 0.3 mPa·s to 10⁵ mPa·s (over 5 decades, selected by choice of sphere and tube geometry)
**accuracy:** 0.5–2% of measured viscosity with proper calibration; 0.5% achievable with certified reference standards and careful temperature control
**precision:** 0.1–0.5% coefficient of variation from repeated fall/roll time measurements at a given condition
**throughput:** single sample per tube loading; one viscosity measurement in 10 s to 30 min depending on viscosity; full T-sweep takes 1–4 hours
**measurement_speed:** individual measurement: seconds (low viscosity) to minutes (high viscosity); rapid for a viscometer compared to capillary methods at high viscosities
- [additional canonical measurement details omitted]

### data_and_interpretation
**raw_signal_type:** fall time or roll time of a sphere between two detection points separated by a calibrated distance, recorded by optical or inductive sensors and a digital timer
**preprocessing_steps:**
- average multiple (typically 5–10) replicate fall/roll time measurements to reduce random timing errors
- apply temperature correction to sphere and fluid densities using known thermal expansion coefficients
**analysis_methods:**
- Stokes law calculation: η = K·(ρs − ρf)·t, where K is the calibration constant, ρs is sphere density, ρf is fluid density, and t is fall/roll time
- Faxén wall correction: multiplicative factor F(d/D) correcting for the influence of tube walls on drag; F = 1 − 2.104(d/D) + 2.089(d/D)³ − 0.948(d/D)⁵ for falling-ball geometry
**model_assumptions:**
- fluid is Newtonian — viscosity is independent of shear rate (valid for the very low shear rates in a falling-sphere geometry)
- sphere reaches terminal velocity before entering the measurement zone (acceleration phase is complete)
**fit_parameters:**
- calibration constant K (or K(θ) for rolling-ball at specific angle)
- sphere density ρs and fluid density ρf
**common_artifacts:**
- air bubble adhesion on sphere surface — reduces effective density difference and increases apparent viscosity
- sphere eccentricity — off-axis fall path changes effective wall correction and produces inconsistent times
**quality_control_checks:**
- measure a certified viscosity reference standard before and after sample measurements to verify instrument constant K stability
- repeat fall/roll time measurements (≥5 replicates) and confirm coefficient of variation < 0.5%
**failure_modes:**
- sphere stuck or slowed by debris or deposits on tube wall
- air bubble attached to sphere — artificially buoyant sphere gives erroneously high viscosity
- [additional canonical measurement details omitted]

### uncertainty
**level:** typical combined standard uncertainty 0.5–2% for dynamic viscosity; 0.5% achievable with best practice
**random_sources:**
- timing variability between replicate fall/roll measurements
- small temperature fluctuations within the thermostat (±0.01–0.05 K)
**systematic_sources:**
- calibration constant K uncertainty (propagated from reference fluid viscosity uncertainty)
- sphere density uncertainty (±0.01–0.1%)
**operator_dependence:** low to moderate — filling the tube without bubbles, sphere handling, and cleaning procedure depend on operator care; automated instruments (e.g., Lovis) reduce operator dependence significantly
**model_dependence:** low for Newtonian fluids in the Stokes regime — the underlying Stokes law is well-validated; increases for higher Re, non-spherical sinkers, or non-Newtonian fluids where additional corrections and assumptions are needed
**dominant_error_sources:**
- density difference (ρs − ρf) uncertainty — this directly scales the viscosity result; a 0.1% error in either density propagates fully
- temperature measurement accuracy — viscosity has a strong T-dependence, so even small offsets cause significant systematic bias
**reported_as:**
- combined expanded uncertainty U(η) at 95% confidence level (k=2)
- relative expanded uncertainty as percentage of η
**thermoml_encoding:** nCombExpandUncertValue at 95% confidence level
- [additional canonical measurement details omitted]


## 12. search_measurement_dk

# Raw tool result: `search_measurement_dk`

Serialization: `json`

```json
{
  "n_matches": 5,
  "n_results": 5,
  "query": [
    "capillary tube Ostwald Ubbelohde",
    "concentric cylinders viscometry",
    "moving piston method"
  ],
  "results": [
    {
      "card_type": "standard_dk",
      "compact_md": "# MTDKS-DK | capillary_tube_ostwald_ubbelohde_method | GLOBmeas_4\n\n**Name:** Capillary tube (Ostwald; Ubbelohde) method\n**Family:** Viscometry\n**ThermoML std:** Capillary tube (Ostwald; Ubbelohde) method\n**Custom codes:** CAPTUB\n**Modality:** contact=yes, destructive=no, in_situ=no, imaging=no\n**Usage:** 3407 instances | 716 papers | groups=TransportProp\n**Per-group:** TransportProp: 3407 inst/716 papers\n\n## Structured Knowledge\n\n### measurement_scope\n**direct_observables:**\n- efflux time — time for liquid meniscus to fall between two etched fiducial marks on the viscometer bulb (s)\n- temperature of thermostat bath (K)\n**derived_observables:**\n- kinematic viscosity ν = Ct − K/t, where C is the viscometer constant, t is efflux time, and K/t is the Hagenbach–Couette kinetic energy correction (mm²/s)\n- dynamic (absolute) viscosity η = νρ, where ρ is the liquid density (mPa·s)\n**target_properties:**\n- kinematic viscosity (ν)\n- dynamic viscosity (η)\n- viscosity deviation (Δη) for mixtures\n- excess viscosity for binary and multicomponent systems\n- viscosity–temperature coefficients (Arrhenius parameters, VTF parameters)\n- activation energy of viscous flow (Ea)\n**phases_measured:**\n- liquid (Newtonian fluids)\n- liquid mixtures and solutions\n**supported_sample_types:**\n- pure Newtonian liquids\n- binary and multicomponent liquid mixtures\n- dilute and moderately concentrated solutions\n- electrolyte solutions\n- ionic liquids\n- organic solvents and solvent mixtures\n- petroleum fractions and lubricant base oils\n- aqueous solutions of salts, sugars, and surfactants\n**unsupported_sample_types:**\n- non-Newtonian or shear-thinning/thickening fluids (viscosity is shear-rate dependent)\n- highly viscous liquids with efflux times exceeding ~2000 s (evaporation, temperature drift)\n- very low viscosity gases or supercritical fluids\n- suspensions or slurries containing particles that can clog the capillary\n- reactive or polymerizing systems that change viscosity during measurement\n- opaque liquids where meniscus timing marks cannot be observed (unless automated optical detection is used)\n**typical_output_formats:**\n- kinematic viscosity ν vs. temperature T\n- dynamic viscosity η vs. temperature T\n- viscosity vs. composition (mole fraction) at fixed T\n- ln(η) vs. 1/T (Arrhenius plot)\n- viscosity deviation Δη vs. mole fraction\n**units:**\n- kinematic_viscosity: mm²/s (= cSt)\n- dynamic_viscosity: mPa·s (= cP)\n- efflux_time: s\n- temperature: K\n- density: kg/m³ or g/cm³\n- viscometer_constant: mm²/s²\n\n### experimental_parameters\n**constraints:**\n- **temperature** — typical: 273 K to 373 K — limits: limited by thermostat bath capability and solvent boiling/freezing points; specialized baths extend to 200 K or 473 K — notes: temperature must be controlled to ±0.01 K or better for 0.1% viscosity accuracy; viscosity has strong T-dependence (often 1–3% per K)\n- **efflux_time** — typical: 200 s to 1000 s — limits: minimum ~200 s to reduce kinetic energy correction to <1%; maximum ~2000 s to avoid evaporation and temperature drift errors — notes: select capillary bore size to place efflux time in the optimal range for the liquid viscosity\n- **capillary_bore_diameter** — typical: 0.2 mm to 3.0 mm — limits: must be large enough to avoid clogging and small enough to maintain laminar flow (Re < 1 in capillary) — notes: viscometers designated by size number (e.g., Size 25, 50, 75…600) with each covering approximately a decade of kinematic viscosity\n- **pressure** — typical: ambient (0.1 MPa) — limits: standard glass viscometers operate at ambient pressure only; driving head is provided by gravity (hydrostatic pressure of liquid column) — notes: the technique measures viscosity at atmospheric pressure; high-pressure viscometry requires different apparatus\n**variables:**\n- **temperature** — typical: 278 K to 363 K in 5 K or 10 K steps — effect: viscosity decreases exponentially with increasing temperature for most liquids; precise T-control dominates measurement accuracy\n- **composition** — typical: mole fractions from 0 to 1 in increments of 0.05 or 0.1 — effect: viscosity varies nonlinearly with composition; mixtures often show negative or positive viscosity deviations from ideal mixing\n- **capillary_size** — typical: size numbers 25–600 (corresponding to constants C ≈ 0.002 to 30 mm²/s²) — effect: selected to keep efflux time in the optimal 200–1000 s range for the expected viscosity\n- **hydrostatic_head** — typical: typically 10–20 cm of liquid column (Ostwald); irrelevant for Ubbelohde (suspended level) — effect: in Ostwald viscometers the head height determines the pressure drop and must be reproducible; Ubbelohde design makes the result independent of sample volume\n\n### setup_and_requirements\n**instrument_components:**\n- glass capillary viscometer — Ostwald (U-tube with fixed volume marks) or Ubbelohde (three-arm suspended-level design with vented bulb) conforming to ISO 3105 / ASTM D446\n- precision thermostat water bath — transparent-walled, stirred liquid bath providing temperature uniformity and stability of ±0.01 K (or better); baths typically use water, silicone oil, or ethylene glycol/water depending on temperature range\n- calibrated thermometer or platinum resistance thermometer (PRT) — traceable to ITS-90, resolution ≤0.001 K\n- timing device — electronic stopwatch (resolution 0.01 s) or automated photoelectric/optical sensor pair positioned at upper and lower fiducial marks for hands-free efflux time measurement\n- viscometer holder/mount — vertical alignment fixture ensuring the viscometer is plumb within ±0.5° of vertical\n- pipette or syringe — for charging precisely the required volume of sample into the viscometer (Ostwald requires exact volume; Ubbelohde is less critical)\n- suction/pressure source — rubber aspirator bulb or small pump for drawing sample into the upper reservoir before releasing for gravity flow\n- cleaning and drying apparatus — chromic acid or detergent solutions, distilled water rinse, filtered dry air or nitrogen for drying the capillary between samples\n**environmental_requirements:**\n- draft-free laboratory environment to maintain bath temperature stability\n- constant ambient temperature (±2 K) to minimize thermal gradients in the exposed viscometer arms\n- clean, dust-free conditions to prevent particulate contamination of the capillary\n- stable bench free from vibration that could influence meniscus timing or bath temperature\n**sample_requirements:**\n- geometry: ['free-flowing liquid at the measurement temperature']\n- size_limits: Ubbelohde: 10–15 mL typical charge; Ostwald: a precisely specified volume (to ±0.1 mL) as defined by the viscometer marks, typically 3–10 mL\n- thickness_limits: \n- surface_requirements: ['liquid must wet the glass walls cleanly to form a reproducible meniscus', 'sample must be optically transparent (or translucent) so that fiducial marks can be observed visually or by optical sensor']\n- mounting_requirements: ['viscometer must be held perfectly vertical in the bath (± 0.5° of plumb) — tilting alters the effective hydrostatic head', 'the viscometer must be immersed so that both bulbs and the capillary section are fully within the thermostated liquid']\n- preparation_requirements: ['filter sample through a 0.45 µm or finer membrane filter to remove particulates', 'degas the sample (by gentle vacuum or ultrasonic bath) to prevent bubble formation in the capillary during flow', 'dry the viscometer thoroughly between successive samples using filtered air or dry nitrogen', 'for hygroscopic or volatile liquids, handle under dry or inert atmosphere and minimize exposure time']\n**calibration_requirements:**\n- determine viscometer constant C by measuring efflux time with a certified viscosity reference standard (or pure water with known viscosity) at two or more temperatures\n- verify calibration periodically (at least annually or whenever the viscometer is cleaned with aggressive agents) using a fresh reference liquid\n- apply Hagenbach–Couette kinetic energy correction: ν = Ct − K/t or determine effective C and K by two-point calibration with reference oils of different viscosities\n- confirm viscometer constant stability by tracking control-chart data from repeated reference oil measurements\n**reference_materials:**\n- NIST traceable certified viscosity reference oils (e.g., Cannon N-series or S-series standards covering 0.3 to 100,000 mm²/s)\n- ultra-pure water (IAPWS viscosity standard: η = 1.0016 mPa·s at 293.15 K; ν ≈ 1.004 mm²/s)\n- NIST SRM 2490 (polyisobutylene solution in 2,6,10,14-tetramethylpentadecane) for Newtonian viscosity reference\n**consumables:**\n- chromic acid cleaning solution or commercial viscometer cleaning detergent\n- distilled and deionized water for rinsing\n- filtered dry nitrogen or clean compressed air for drying\n- membrane syringe filters (0.45 µm) for sample filtration\n- silicone oil, water, or ethylene glycol/water mixture as thermostat bath fluid\n**safety_notes:**\n- chromic acid cleaning solution is a strong oxidizer and known carcinogen — use in a fume hood with appropriate PPE; prefer modern non-chromic cleaning alternatives where possible\n- glass viscometers are fragile — handle with care to avoid breakage and injury from glass shards\n- hot bath fluids (>373 K) or cryogenic bath fluids present burn/frostbite hazards\n- volatile organic solvents require ventilation and avoidance of ignition sources\n\n### performance\n**sensitivity:** can distinguish kinematic viscosity differences as small as 0.01 mm²/s for low-viscosity liquids\n**detection_limit:** lower limit of kinematic viscosity ~0.2 mm²/s (limited by capillary bore size and minimum practical efflux time); upper limit ~100,000 mm²/s with large-bore viscometers\n**resolution:**\n- spatial: not applicable (bulk liquid measurement)\n- temporal: single measurement per efflux cycle (200–1000 s); typical experimental campaign reports 3–5 replicate efflux times per condition\n- spectral: not applicable\n- energy: not applicable\n**dynamic_range:** kinematic viscosity from ~0.2 mm²/s to ~100,000 mm²/s; a single viscometer size covers approximately one decade of viscosity\n**accuracy:** 0.1–0.5% for kinematic viscosity with proper calibration, temperature control (±0.01 K), and kinetic energy correction; 0.2–0.7% for dynamic viscosity (includes density uncertainty)\n**precision:** 0.05–0.2% (repeatability of replicate efflux times at the same temperature and composition)\n**throughput:** low — one sample/condition at a time; a single T-composition point requires 15–30 min including equilibration; full viscosity-temperature curve with 5–10 replicates takes several hours\n**measurement_speed:** individual efflux time 200–1000 s; thermal equilibration in bath 15–30 min per temperature step\n\n### data_and_interpretation\n**raw_signal_type:** elapsed time t (in seconds) for the liquid meniscus to descend between two fiducial marks etched on the viscometer upper bulb; measured by stopwatch or photoelectric sensor\n**preprocessing_steps:**\n- compute mean efflux time from 3–5 replicate runs at each condition, rejecting outliers (>2σ)\n- apply Hagenbach–Couette kinetic energy correction: ν = Ct − K/t (or use the two-term calibration equation if C and K are determined separately)\n- for Ostwald viscometers: confirm that the charged sample volume matches the calibration volume (volume must be precise)\n- correct for buoyancy of air if working with high-precision density data\n- compute dynamic viscosity η = νρ using independently measured or literature density at the same T and P\n**analysis_methods:**\n- direct calculation: ν = Ct − K/t from calibrated viscometer constant C and kinetic energy correction constant K\n- Arrhenius fit: ln(η) = A + Ea/(RT) for activation energy of viscous flow\n- Vogel–Tammann–Fulcher (VTF) fit: ln(η) = A + B/(T − T0) for liquids approaching glass transition\n- Grunberg–Nissan equation: ln(η_mix) = x1·ln(η1) + x2·ln(η2) + x1·x2·G12 for binary mixture viscosity\n- Redlich–Kister polynomial: Δη = x1·x2·Σ Ai·(x1 − x2)^i for excess viscosity correlation\n- McAllister model: three-body or four-body interaction model for mixture kinematic viscosity\n**model_assumptions:**\n- flow through the capillary is fully developed, laminar, and Newtonian (Hagen–Poiseuille flow: Re < 1 in capillary)\n- the liquid is incompressible and behaves as a Newtonian fluid (viscosity independent of shear rate)\n- end effects (entrance and exit losses) are adequately accounted for by the Hagenbach–Couette kinetic energy correction\n- the capillary bore is perfectly cylindrical and uniform along its length\n- the liquid fully wets the glass wall (no-slip boundary condition holds)\n- for Ubbelohde viscometers: the suspended-level bulb vents to atmosphere, so hydrostatic head is determined solely by the design geometry and is independent of sample volume\n**fit_parameters:**\n- viscometer constant C (mm²/s²)\n- kinetic energy correction constant K (mm²·s)\n- Arrhenius pre-exponential A and activation energy Ea\n- VTF parameters A, B, T0\n- Redlich–Kister coefficients Ai for mixture excess viscosity\n**common_artifacts:**\n- air bubbles trapped in the capillary — produce erroneously long efflux times and poor reproducibility\n- particulate contamination or fiber in the capillary bore — partially blocks flow, giving anomalously high apparent viscosity\n- incomplete thermal equilibration — viscosity decreasing/increasing systematically across successive runs\n- meniscus adhesion or 'hanging drop' at the upper timing mark — operator-dependent timing error (eliminated by automated optical detection)\n- solvent evaporation during extended measurements on volatile samples — causes concentration and viscosity drift above the initial value\n**quality_control_checks:**\n- measure certified viscosity reference oil at a standard temperature (e.g., 298.15 K) and confirm agreement within ±0.3% of certified value\n- verify that replicate efflux times agree within ±0.1% of the mean (coefficient of variation)\n- measure at two temperatures and confirm viscosity–temperature trend is physically reasonable (monotonic decrease for most liquids)\n- cross-check: if two viscometer sizes overlap in range, measure the same liquid in both and confirm agreement\n- for Ostwald viscometers: verify that changing the sample volume slightly produces different results (evidence that volume control matters); for Ubbelohde: verify volume independence\n- inspect the viscometer bore for deposits or discoloration after each set of measurements; clean and recalibrate if contamination is found\n**failure_modes:**\n- capillary clogging by particles or crystallized solute — flow stops or becomes erratic\n- cracking or chipping of the viscometer glass — changes bore geometry and invalidates calibration\n- thermostat bath failure or oscillation — temperature excursions cause large viscosity errors\n- degradation of reference oil standard (oxidation, moisture absorption) — leads to incorrect recalibration\n- timing device malfunction or operator reaction-time variability (manual timing) — random errors in efflux time >0.5 s\n\n### uncertainty\n**level:** typical combined standard uncertainty 0.1–0.5% for kinematic viscosity; 0.2–0.7% for dynamic viscosity (additional density uncertainty)\n**random_sources:**\n- operator reaction time in starting/stopping manual timer (±0.1–0.3 s per mark; eliminated by automated sensors)\n- meniscus shape variability at the timing marks\n- short-term temperature fluctuations (bath stability)\n- micro-bubble formation between runs\n- small variations in sample charge volume (Ostwald design)\n**systematic_sources:**\n- viscometer constant calibration uncertainty (typically 0.1–0.2%)\n- kinetic energy correction uncertainty (significant for short efflux times <200 s)\n- temperature measurement offset or drift (0.01 K ≈ 0.02–0.05% in viscosity)\n- non-Newtonian behavior of nominally Newtonian sample at high shear rates in fine capillaries\n- capillary bore non-uniformity or dimensional change from aggressive cleaning\n- surface tension effects on meniscus curvature (Ostwald design, volume-dependent)\n- density uncertainty propagated into dynamic viscosity (typically 0.01–0.05%)\n**operator_dependence:** moderate for manual timing (reaction-time variability is the largest operator-dependent error); low for automated photoelectric detection systems; sample loading and viscometer cleaning technique also depend on operator skill\n**model_dependence:** low — the Hagen–Poiseuille equation with Hagenbach–Couette correction is well-established for Newtonian laminar flow; model dependence increases only if the sample exhibits non-Newtonian behavior or if kinetic energy correction is poorly characterized\n**dominant_error_sources:**\n- temperature control and measurement (dominates total budget for well-calibrated systems)\n- viscometer constant calibration (propagates directly to reported viscosity)\n- kinetic energy correction (dominant for fluids with efflux times <200 s)\n- density uncertainty (for dynamic viscosity η = νρ)\n**reported_as:**\n- combined expanded uncertainty U(ν) at 95% confidence (k=2)\n- relative uncertainty as percentage of ν or η\n- standard deviation of replicate efflux times\n**thermoml_encoding:** nCombExpandUncertValue at 95% confidence level\n\n## Description\n\n### technique_overview\nThe capillary tube (Ostwald; Ubbelohde) method is the most widely used laboratory technique for measuring kinematic viscosity of Newtonian liquids. The sample flows under gravity through a precision-bore glass capillary, and the time for a fixed volume of liquid to drain between two etched marks is recorded. This efflux time is directly proportional to kinematic viscosity via a calibrated instrument constant. With 3,407 measurement instances across 716 papers in the NIST ThermoML database, it is the dominant viscometry technique in the thermophysical property literature. Two principal designs exist: the Ostwald U-tube viscometer (ca. 1890), which requires a precisely known sample volume, and the Ubbelohde suspended-level viscometer (ca. 1937), whose vented design makes the result independent of the volume of liquid charged, simplifying operation and improving reproducibility.\n\n### how_it_operates\nA measured quantity of liquid is loaded into the viscometer and brought to thermal equilibrium in a precision thermostat bath (±0.01 K). The liquid is drawn by suction into the upper reservoir above the capillary section, then released to flow under gravity. As the meniscus descends through the capillary and into the lower bulb, the operator (or an automated photoelectric detector) records the time for the meniscus to pass between two fiducial marks etched on the glass. This efflux time t is related to kinematic viscosity by ν = Ct − K/t, where C is the viscometer constant determined by calibration and K/t is the Hagenbach–Couette kinetic energy correction that accounts for acceleration losses at the capillary entrance and exit. In the Ubbelohde design, the lower end of the capillary opens into a bulb that is vented to the atmosphere, creating a suspended (free-hanging) liquid column whose driving head is fixed by geometry alone, independent of the total volume charged. In the Ostwald design, the driving hydrostatic head depends on the liquid level in both arms, so only the exact calibration volume must be used.\n\n### core_theory\nThe measurement is grounded in the Hagen–Poiseuille equation for steady, laminar, incompressible Newtonian flow through a cylindrical tube: Q = πR⁴ΔP/(8ηL), where Q is the volumetric flow rate, R is the capillary radius, L is the capillary length, ΔP is the pressure drop (from the hydrostatic head ρgΔh), and η is the dynamic viscosity. Because the driving pressure is ρgΔh, the flow rate depends on density, and the ratio η/ρ = ν (kinematic viscosity) emerges naturally: ν = πR⁴gΔh·t/(8LV), where V is the volume of liquid that flows during time t. This quantity πR⁴gΔh/(8LV) is absorbed into the viscometer constant C, yielding the working equation ν = Ct. A correction for the kinetic energy consumed in accelerating the liquid from rest in the reservoir into the capillary and decelerating it upon exit is applied as a negative term −K/t (Hagenbach–Couette correction), giving the complete equation ν = Ct − K/t. For well-designed viscometers with long efflux times (>200 s), the correction term is small (<1%). The Reynolds number in the capillary must remain below ~1 to ensure fully laminar flow.\n\n### setup\nA standard capillary viscometry setup consists of the glass viscometer (Ostwald or Ubbelohde, selected by size number to match the expected viscosity range), a transparent thermostat bath with continuous mechanical stirring and a PID-controlled heater/cooler maintaining ±0.01 K stability, a calibrated thermometer (PRT or ASTM liquid-in-glass thermometer) immersed adjacent to the viscometer, and a timing system. Modern installations use paired photoelectric sensors clamped at the upper and lower timing marks, connected to an electronic timer with 0.01 s resolution, eliminating operator reaction-time error. The viscometer is clamped vertically (within ±0.5° of plumb) in the bath, immersed so that the entire capillary section and both bulbs are below the bath liquid level. A rubber aspirator bulb or small vacuum line is used to draw the sample into the upper bulb before each run.\n\n### suitable_for\nCapillary viscometry is ideally suited for Newtonian liquids with kinematic viscosities from about 0.2 mm²/s (e.g., diethyl ether) to 100,000 mm²/s (e.g., heavy petroleum fractions), with the most common application range being 0.3 to 1,000 mm²/s. It is the technique of choice for systematic viscosity-temperature and viscosity-composition studies on pure liquids and their binary or multicomponent mixtures — the bread-and-butter measurements that dominate the ThermoML transport property dataset. Typical target systems include organic solvents, alcohols, hydrocarbons, esters, ionic liquids, aqueous electrolyte solutions, and dilute polymer solutions (for intrinsic viscosity determination). The method produces reference-grade data (0.1–0.5% accuracy) and is accepted as the primary standard for kinematic viscosity by ASTM (D445/D446) and ISO (3104/3105).\n\n### core_limitations\nThe method is restricted to Newtonian fluids because the shear rate in the capillary varies radially (zero at the center, maximum at the wall) and is not controlled independently — non-Newtonian fluids yield an apparent viscosity that is not a material property. Each viscometer size covers only about one decade of kinematic viscosity, so a set of viscometers is needed to span a broad range. The measurement is slow (15–30 min per data point including equilibration), making it impractical for high-throughput screening. It operates only at ambient pressure, so high-pressure viscosity measurements require different instrumentation. Temperature dependence of viscosity is steep (often 1–3% per kelvin), placing extreme demands on thermostat stability. The Ostwald design requires exact sample volume reproducibility, limiting convenience; the Ubbelohde design eliminates this constraint but at higher instrument cost. Very volatile liquids or those with low surface tension can produce variable meniscus behavior.\n\n### sample_preparation\nThe sample must be filtered through a 0.45 µm (or finer) membrane filter to remove any particles that could lodge in the capillary bore (typical diameter 0.2–3 mm) and cause erroneous results. Dissolved gas should be removed by gentle vacuum degassing or brief ultrasonication, since bubbles nucleating in the capillary during flow will interrupt the meniscus and invalidate the efflux time. For hygroscopic liquids (e.g., ionic liquids, glycerol), preparation and loading should be performed under dry nitrogen to prevent water uptake, which markedly lowers viscosity. The viscometer itself must be scrupulously clean: a typical cleaning protocol involves successive rinses with chromic acid solution (or a non-chromic alternative such as NoChromix), copious distilled water, reagent-grade acetone, and filtered dry air or nitrogen. Any residual film on the capillary wall alters the wetting behavior and the effective bore diameter. Between different samples, at least three solvent rinses followed by thorough drying are needed to prevent cross-contamination.\n\n### calibration_and_references\nThe viscometer constant C (and kinetic energy correction K, if treated separately) is determined by measuring the efflux time of a certified reference liquid of known kinematic viscosity at one or more temperatures. The most common references are NIST-traceable Cannon certified viscosity reference oils (S-series or N-series), which cover the range from 0.3 to 100,000 mm²/s with certified uncertainties of 0.1–0.3%. Ultra-pure water (IAPWS recommended viscosity value η = 1.0016 mPa·s at 293.15 K) serves as a convenient low-viscosity calibrant. For highest accuracy, a two-oil calibration is performed: efflux times with two reference oils of substantially different viscosity allow independent determination of both C and K. The calibration must be verified periodically (at least annually, or whenever the viscometer is cleaned aggressively or shows signs of deposit buildup) by running a fresh reference standard and comparing the measured viscosity to its certified value. Acceptable recalibration agreement is typically within ±0.3% of the certified reference viscosity.\n\n### data_interpretation\nThe raw data are a set of replicate efflux times at each temperature–composition condition. The mean efflux time (typically 3–5 replicates, outliers rejected by Grubbs or Dixon test) is converted to kinematic viscosity using ν = Ct − K/t. If dynamic (absolute) viscosity is the target property, an independently measured or literature value of density at the identical temperature and pressure is used: η = νρ. For mixture studies, viscosity deviations Δη = η_mix − (x₁η₁ + x₂η₂) or excess quantities are computed and typically correlated with Redlich–Kister polynomials. Temperature-dependence is commonly fitted to the Arrhenius equation ln(η) = A + Ea/(RT) for limited temperature ranges, or the three-parameter VTF equation ln(η) = A + B/(T − T₀) for wider ranges or liquids approaching glass transition. For dilute polymer solutions, the specific viscosity η_sp = (η − η₀)/η₀ and intrinsic viscosity [η] = lim(η_sp/c) as c→0 are derived from capillary viscometer data at multiple concentrations.\n\n### common_pitfalls\nThe single most common pitfall is inadequate temperature control or equilibration. Because liquid viscosity changes by 1–3% per kelvin near room temperature, a thermostat instability of only ±0.02 K can introduce a systematic error comparable to the instrument's intrinsic precision. Operators must allow sufficient equilibration time (typically 15–30 min per temperature step) before beginning efflux time measurements. A second major pitfall is using an Ostwald viscometer with an imprecise sample volume — even a 0.5% volume error shifts the hydrostatic head and biases the viscosity result (this problem is entirely avoided by using the Ubbelohde design). Air bubbles formed by insufficient degassing or by drawing the liquid too vigorously into the upper bulb cause sporadic long efflux times. Dirty or contaminated capillaries produce irreproducible results and systematic positive bias (effectively reducing the bore). Finally, choosing a viscometer size that yields an efflux time below 200 s introduces a large kinetic energy correction (>1%), amplifying calibration uncertainty.\n\n### artifacts_and_failure_modes\nAir bubbles trapped in the capillary manifest as anomalously long or erratic efflux times; they are usually evident from poor replicate agreement (CV > 0.5%) and are eliminated by careful degassing and gentle loading. Particulate clogging produces progressively increasing efflux times across successive runs, eventually leading to complete blockage. Deposits from semi-volatile or polymerizing samples build up on the capillary wall over time, narrowing the bore and increasing apparent viscosity — this is detected by periodic reference oil checks and remedied by thorough cleaning and recalibration. A cracked or chipped viscometer alters the capillary geometry and invalidates the calibration constant; any damaged viscometer must be discarded or recalibrated after repair. Solvent evaporation from volatile samples during extended runs causes a progressive increase in concentration and viscosity, detectable as a monotonic upward drift in replicate efflux times. Thermostat failure (sudden temperature excursion) produces step changes in efflux time that are easily identified but render the affected data unusable.\n\n### reporting_checklist\nComplete reporting of capillary viscometer results for ThermoML and archival publication should include: (1) viscometer type (Ostwald or Ubbelohde) and size designation or capillary bore diameter; (2) viscometer constant C and kinetic energy correction K, with source of calibration (reference oil identity and certified value); (3) thermostat bath type and temperature stability (±0.01 K or better); (4) thermometer type and calibration traceability; (5) timing method (manual stopwatch or automated photoelectric); (6) number of replicate efflux times per condition and their standard deviation; (7) sample purity, source, and any purification or drying procedure; (8) filtration and degassing procedure; (9) temperature (K), kinematic viscosity (mm²/s), and/or dynamic viscosity (mPa·s) at each condition; (10) density values used for computing dynamic viscosity, with source and uncertainty; (11) combined expanded uncertainty U(ν) or U(η) at 95% confidence (k = 2) with an uncertainty budget identifying the dominant contributions; (12) applicable standards followed (ASTM D445/D446 or ISO 3104/3105). In ThermoML encoding, viscosity values are accompanied by nCombExpandUncertValue at the 95% confidence level.\n",
      "domain_knowledge": {
        "description_block": {
          "artifacts_and_failure_modes": "Air bubbles trapped in the capillary manifest as anomalously long or erratic efflux times; they are usually evident from poor replicate agreement (CV > 0.5%) and are eliminated by careful degassing and gentle loading. Particulate clogging produces progressively increasing efflux times across successive runs, eventually leading to complete blockage. Deposits from semi-volatile or polymerizing samples build up on the capillary wall over time, narrowing the bore and increasing apparent viscosity — this is detected by periodic reference oil checks and remedied by thorough cleaning and recalibration. A cracked or chipped viscometer alters the capillary geometry and invalidates the calibration constant; any damaged viscometer must be discarded or recalibrated after repair. Solvent evaporation from volatile samples during extended runs causes a progressive increase in concentration and viscosity, detectable as a monotonic upward drift in replicate efflux times. Thermostat failure (sudden temperature excursion) produces step changes in efflux time that are easily identified but render the affected data unusable.",
          "calibration_and_references": "The viscometer constant C (and kinetic energy correction K, if treated separately) is determined by measuring the efflux time of a certified reference liquid of known kinematic viscosity at one or more temperatures. The most common references are NIST-traceable Cannon certified viscosity reference oils (S-series or N-series), which cover the range from 0.3 to 100,000 mm²/s with certified uncertainties of 0.1–0.3%. Ultra-pure water (IAPWS recommended viscosity value η = 1.0016 mPa·s at 293.15 K) serves as a convenient low-viscosity calibrant. For highest accuracy, a two-oil calibration is performed: efflux times with two reference oils of substantially different viscosity allow independent determination of both C and K. The calibration must be verified periodically (at least annually, or whenever the viscometer is cleaned aggressively or shows signs of deposit buildup) by running a fresh reference standard and comparing the measured viscosity to its certified value. Acceptable recalibration agreement is typically within ±0.3% of the certified reference viscosity.",
          "common_pitfalls": "The single most common pitfall is inadequate temperature control or equilibration. Because liquid viscosity changes by 1–3% per kelvin near room temperature, a thermostat instability of only ±0.02 K can introduce a systematic error comparable to the instrument's intrinsic precision. Operators must allow sufficient equilibration time (typically 15–30 min per temperature step) before beginning efflux time measurements. A second major pitfall is using an Ostwald viscometer with an imprecise sample volume — even a 0.5% volume error shifts the hydrostatic head and biases the viscosity result (this problem is entirely avoided by using the Ubbelohde design). Air bubbles formed by insufficient degassing or by drawing the liquid too vigorously into the upper bulb cause sporadic long efflux times. Dirty or contaminated capillaries produce irreproducible results and systematic positive bias (effectively reducing the bore). Finally, choosing a viscometer size that yields an efflux time below 200 s introduces a large kinetic energy correction (>1%), amplifying calibration uncertainty.",
          "core_limitations": "The method is restricted to Newtonian fluids because the shear rate in the capillary varies radially (zero at the center, maximum at the wall) and is not controlled independently — non-Newtonian fluids yield an apparent viscosity that is not a material property. Each viscometer size covers only about one decade of kinematic viscosity, so a set of viscometers is needed to span a broad range. The measurement is slow (15–30 min per data point including equilibration), making it impractical for high-throughput screening. It operates only at ambient pressure, so high-pressure viscosity measurements require different instrumentation. Temperature dependence of viscosity is steep (often 1–3% per kelvin), placing extreme demands on thermostat stability. The Ostwald design requires exact sample volume reproducibility, limiting convenience; the Ubbelohde design eliminates this constraint but at higher instrument cost. Very volatile liquids or those with low surface tension can produce variable meniscus behavior.",
          "core_theory": "The measurement is grounded in the Hagen–Poiseuille equation for steady, laminar, incompressible Newtonian flow through a cylindrical tube: Q = πR⁴ΔP/(8ηL), where Q is the volumetric flow rate, R is the capillary radius, L is the capillary length, ΔP is the pressure drop (from the hydrostatic head ρgΔh), and η is the dynamic viscosity. Because the driving pressure is ρgΔh, the flow rate depends on density, and the ratio η/ρ = ν (kinematic viscosity) emerges naturally: ν = πR⁴gΔh·t/(8LV), where V is the volume of liquid that flows during time t. This quantity πR⁴gΔh/(8LV) is absorbed into the viscometer constant C, yielding the working equation ν = Ct. A correction for the kinetic energy consumed in accelerating the liquid from rest in the reservoir into the capillary and decelerating it upon exit is applied as a negative term −K/t (Hagenbach–Couette correction), giving the complete equation ν = Ct − K/t. For well-designed viscometers with long efflux times (>200 s), the correction term is small (<1%). The Reynolds number in the capillary must remain below ~1 to ensure fully laminar flow.",
          "data_interpretation": "The raw data are a set of replicate efflux times at each temperature–composition condition. The mean efflux time (typically 3–5 replicates, outliers rejected by Grubbs or Dixon test) is converted to kinematic viscosity using ν = Ct − K/t. If dynamic (absolute) viscosity is the target property, an independently measured or literature value of density at the identical temperature and pressure is used: η = νρ. For mixture studies, viscosity deviations Δη = η_mix − (x₁η₁ + x₂η₂) or excess quantities are computed and typically correlated with Redlich–Kister polynomials. Temperature-dependence is commonly fitted to the Arrhenius equation ln(η) = A + Ea/(RT) for limited temperature ranges, or the three-parameter VTF equation ln(η) = A + B/(T − T₀) for wider ranges or liquids approaching glass transition. For dilute polymer solutions, the specific viscosity η_sp = (η − η₀)/η₀ and intrinsic viscosity [η] = lim(η_sp/c) as c→0 are derived from capillary viscometer data at multiple concentrations.",
          "how_it_operates": "A measured quantity of liquid is loaded into the viscometer and brought to thermal equilibrium in a precision thermostat bath (±0.01 K). The liquid is drawn by suction into the upper reservoir above the capillary section, then released to flow under gravity. As the meniscus descends through the capillary and into the lower bulb, the operator (or an automated photoelectric detector) records the time for the meniscus to pass between two fiducial marks etched on the glass. This efflux time t is related to kinematic viscosity by ν = Ct − K/t, where C is the viscometer constant determined by calibration and K/t is the Hagenbach–Couette kinetic energy correction that accounts for acceleration losses at the capillary entrance and exit. In the Ubbelohde design, the lower end of the capillary opens into a bulb that is vented to the atmosphere, creating a suspended (free-hanging) liquid column whose driving head is fixed by geometry alone, independent of the total volume charged. In the Ostwald design, the driving hydrostatic head depends on the liquid level in both arms, so only the exact calibration volume must be used.",
          "reporting_checklist": "Complete reporting of capillary viscometer results for ThermoML and archival publication should include: (1) viscometer type (Ostwald or Ubbelohde) and size designation or capillary bore diameter; (2) viscometer constant C and kinetic energy correction K, with source of calibration (reference oil identity and certified value); (3) thermostat bath type and temperature stability (±0.01 K or better); (4) thermometer type and calibration traceability; (5) timing method (manual stopwatch or automated photoelectric); (6) number of replicate efflux times per condition and their standard deviation; (7) sample purity, source, and any purification or drying procedure; (8) filtration and degassing procedure; (9) temperature (K), kinematic viscosity (mm²/s), and/or dynamic viscosity (mPa·s) at each condition; (10) density values used for computing dynamic viscosity, with source and uncertainty; (11) combined expanded uncertainty U(ν) or U(η) at 95% confidence (k = 2) with an uncertainty budget identifying the dominant contributions; (12) applicable standards followed (ASTM D445/D446 or ISO 3104/3105). In ThermoML encoding, viscosity values are accompanied by nCombExpandUncertValue at the 95% confidence level.",
          "sample_preparation": "The sample must be filtered through a 0.45 µm (or finer) membrane filter to remove any particles that could lodge in the capillary bore (typical diameter 0.2–3 mm) and cause erroneous results. Dissolved gas should be removed by gentle vacuum degassing or brief ultrasonication, since bubbles nucleating in the capillary during flow will interrupt the meniscus and invalidate the efflux time. For hygroscopic liquids (e.g., ionic liquids, glycerol), preparation and loading should be performed under dry nitrogen to prevent water uptake, which markedly lowers viscosity. The viscometer itself must be scrupulously clean: a typical cleaning protocol involves successive rinses with chromic acid solution (or a non-chromic alternative such as NoChromix), copious distilled water, reagent-grade acetone, and filtered dry air or nitrogen. Any residual film on the capillary wall alters the wetting behavior and the effective bore diameter. Between different samples, at least three solvent rinses followed by thorough drying are needed to prevent cross-contamination.",
          "setup": "A standard capillary viscometry setup consists of the glass viscometer (Ostwald or Ubbelohde, selected by size number to match the expected viscosity range), a transparent thermostat bath with continuous mechanical stirring and a PID-controlled heater/cooler maintaining ±0.01 K stability, a calibrated thermometer (PRT or ASTM liquid-in-glass thermometer) immersed adjacent to the viscometer, and a timing system. Modern installations use paired photoelectric sensors clamped at the upper and lower timing marks, connected to an electronic timer with 0.01 s resolution, eliminating operator reaction-time error. The viscometer is clamped vertically (within ±0.5° of plumb) in the bath, immersed so that the entire capillary section and both bulbs are below the bath liquid level. A rubber aspirator bulb or small vacuum line is used to draw the sample into the upper bulb before each run.",
          "suitable_for": "Capillary viscometry is ideally suited for Newtonian liquids with kinematic viscosities from about 0.2 mm²/s (e.g., diethyl ether) to 100,000 mm²/s (e.g., heavy petroleum fractions), with the most common application range being 0.3 to 1,000 mm²/s. It is the technique of choice for systematic viscosity-temperature and viscosity-composition studies on pure liquids and their binary or multicomponent mixtures — the bread-and-butter measurements that dominate the ThermoML transport property dataset. Typical target systems include organic solvents, alcohols, hydrocarbons, esters, ionic liquids, aqueous electrolyte solutions, and dilute polymer solutions (for intrinsic viscosity determination). The method produces reference-grade data (0.1–0.5% accuracy) and is accepted as the primary standard for kinematic viscosity by ASTM (D445/D446) and ISO (3104/3105).",
          "technique_overview": "The capillary tube (Ostwald; Ubbelohde) method is the most widely used laboratory technique for measuring kinematic viscosity of Newtonian liquids. The sample flows under gravity through a precision-bore glass capillary, and the time for a fixed volume of liquid to drain between two etched marks is recorded. This efflux time is directly proportional to kinematic viscosity via a calibrated instrument constant. With 3,407 measurement instances across 716 papers in the NIST ThermoML database, it is the dominant viscometry technique in the thermophysical property literature. Two principal designs exist: the Ostwald U-tube viscometer (ca. 1890), which requires a precisely known sample volume, and the Ubbelohde suspended-level viscometer (ca. 1937), whose vented design makes the result independent of the volume of liquid charged, simplifying operation and improving reproducibility."
        },
        "structured_block": {
          "data_and_interpretation": {
            "analysis_methods": [
              "direct calculation: ν = Ct − K/t from calibrated viscometer constant C and kinetic energy correction constant K",
              "Arrhenius fit: ln(η) = A + Ea/(RT) for activation energy of viscous flow",
              "Vogel–Tammann–Fulcher (VTF) fit: ln(η) = A + B/(T − T0) for liquids approaching glass transition",
              "Grunberg–Nissan equation: ln(η_mix) = x1·ln(η1) + x2·ln(η2) + x1·x2·G12 for binary mixture viscosity",
              "Redlich–Kister polynomial: Δη = x1·x2·Σ Ai·(x1 − x2)^i for excess viscosity correlation",
              "McAllister model: three-body or four-body interaction model for mixture kinematic viscosity"
            ],
            "common_artifacts": [
              "air bubbles trapped in the capillary — produce erroneously long efflux times and poor reproducibility",
              "particulate contamination or fiber in the capillary bore — partially blocks flow, giving anomalously high apparent viscosity",
              "incomplete thermal equilibration — viscosity decreasing/increasing systematically across successive runs",
              "meniscus adhesion or 'hanging drop' at the upper timing mark — operator-dependent timing error (eliminated by automated optical detection)",
              "solvent evaporation during extended measurements on volatile samples — causes concentration and viscosity drift above the initial value"
            ],
            "failure_modes": [
              "capillary clogging by particles or crystallized solute — flow stops or becomes erratic",
              "cracking or chipping of the viscometer glass — changes bore geometry and invalidates calibration",
              "thermostat bath failure or oscillation — temperature excursions cause large viscosity errors",
              "degradation of reference oil standard (oxidation, moisture absorption) — leads to incorrect recalibration",
              "timing device malfunction or operator reaction-time variability (manual timing) — random errors in efflux time >0.5 s"
            ],
            "fit_parameters": [
              "viscometer constant C (mm²/s²)",
              "kinetic energy correction constant K (mm²·s)",
              "Arrhenius pre-exponential A and activation energy Ea",
              "VTF parameters A, B, T0",
              "Redlich–Kister coefficients Ai for mixture excess viscosity"
            ],
            "model_assumptions": [
              "flow through the capillary is fully developed, laminar, and Newtonian (Hagen–Poiseuille flow: Re < 1 in capillary)",
              "the liquid is incompressible and behaves as a Newtonian fluid (viscosity independent of shear rate)",
              "end effects (entrance and exit losses) are adequately accounted for by the Hagenbach–Couette kinetic energy correction",
              "the capillary bore is perfectly cylindrical and uniform along its length",
              "the liquid fully wets the glass wall (no-slip boundary condition holds)",
              "for Ubbelohde viscometers: the suspended-level bulb vents to atmosphere, so hydrostatic head is determined solely by the design geometry and is independent of sample volume"
            ],
            "preprocessing_steps": [
              "compute mean efflux time from 3–5 replicate runs at each condition, rejecting outliers (>2σ)",
              "apply Hagenbach–Couette kinetic energy correction: ν = Ct − K/t (or use the two-term calibration equation if C and K are determined separately)",
              "for Ostwald viscometers: confirm that the charged sample volume matches the calibration volume (volume must be precise)",
              "correct for buoyancy of air if working with high-precision density data",
              "compute dynamic viscosity η = νρ using independently measured or literature density at the same T and P"
            ],
            "quality_control_checks": [
              "measure certified viscosity reference oil at a standard temperature (e.g., 298.15 K) and confirm agreement within ±0.3% of certified value",
              "verify that replicate efflux times agree within ±0.1% of the mean (coefficient of variation)",
              "measure at two temperatures and confirm viscosity–temperature trend is physically reasonable (monotonic decrease for most liquids)",
              "cross-check: if two viscometer sizes overlap in range, measure the same liquid in both and confirm agreement",
              "for Ostwald viscometers: verify that changing the sample volume slightly produces different results (evidence that volume control matters); for Ubbelohde: verify volume independence",
              "inspect the viscometer bore for deposits or discoloration after each set of measurements; clean and recalibrate if contamination is found"
            ],
            "raw_signal_type": "elapsed time t (in seconds) for the liquid meniscus to descend between two fiducial marks etched on the viscometer upper bulb; measured by stopwatch or photoelectric sensor"
          },
          "experimental_parameters": {
            "constraints": [
              {
                "hard_limits": "limited by thermostat bath capability and solvent boiling/freezing points; specialized baths extend to 200 K or 473 K",
                "notes": "temperature must be controlled to ±0.01 K or better for 0.1% viscosity accuracy; viscosity has strong T-dependence (often 1–3% per K)",
                "parameter": "temperature",
                "typical_range": "273 K to 373 K"
              },
              {
                "hard_limits": "minimum ~200 s to reduce kinetic energy correction to <1%; maximum ~2000 s to avoid evaporation and temperature drift errors",
                "notes": "select capillary bore size to place efflux time in the optimal range for the liquid viscosity",
                "parameter": "efflux_time",
                "typical_range": "200 s to 1000 s"
              },
              {
                "hard_limits": "must be large enough to avoid clogging and small enough to maintain laminar flow (Re < 1 in capillary)",
                "notes": "viscometers designated by size number (e.g., Size 25, 50, 75…600) with each covering approximately a decade of kinematic viscosity",
                "parameter": "capillary_bore_diameter",
                "typical_range": "0.2 mm to 3.0 mm"
              },
              {
                "hard_limits": "standard glass viscometers operate at ambient pressure only; driving head is provided by gravity (hydrostatic pressure of liquid column)",
                "notes": "the technique measures viscosity at atmospheric pressure; high-pressure viscometry requires different apparatus",
                "parameter": "pressure",
                "typical_range": "ambient (0.1 MPa)"
              }
            ],
            "variables": [
              {
                "effect": "viscosity decreases exponentially with increasing temperature for most liquids; precise T-control dominates measurement accuracy",
                "name": "temperature",
                "role": "primary controlled variable",
                "typical_values": "278 K to 363 K in 5 K or 10 K steps"
              },
              {
                "effect": "viscosity varies nonlinearly with composition; mixtures often show negative or positive viscosity deviations from ideal mixing",
                "name": "composition",
                "role": "mixture variable",
                "typical_values": "mole fractions from 0 to 1 in increments of 0.05 or 0.1"
              },
              {
                "effect": "selected to keep efflux time in the optimal 200–1000 s range for the expected viscosity",
                "name": "capillary_size",
                "role": "instrument selection parameter",
                "typical_values": "size numbers 25–600 (corresponding to constants C ≈ 0.002 to 30 mm²/s²)"
              },
              {
                "effect": "in Ostwald viscometers the head height determines the pressure drop and must be reproducible; Ubbelohde design makes the result independent of sample volume",
                "name": "hydrostatic_head",
                "role": "driving force (Ostwald) or eliminated (Ubbelohde)",
                "typical_values": "typically 10–20 cm of liquid column (Ostwald); irrelevant for Ubbelohde (suspended level)"
              }
            ]
          },
          "measurement_scope": {
            "derived_observables": [
              "kinematic viscosity ν = Ct − K/t, where C is the viscometer constant, t is efflux time, and K/t is the Hagenbach–Couette kinetic energy correction (mm²/s)",
              "dynamic (absolute) viscosity η = νρ, where ρ is the liquid density (mPa·s)"
            ],
            "direct_observables": [
              "efflux time — time for liquid meniscus to fall between two etched fiducial marks on the viscometer bulb (s)",
              "temperature of thermostat bath (K)"
            ],
            "phases_measured": [
              "liquid (Newtonian fluids)",
              "liquid mixtures and solutions"
            ],
            "supported_sample_types": [
              "pure Newtonian liquids",
              "binary and multicomponent liquid mixtures",
              "dilute and moderately concentrated solutions",
              "electrolyte solutions",
              "ionic liquids",
              "organic solvents and solvent mixtures",
              "petroleum fractions and lubricant base oils",
              "aqueous solutions of salts, sugars, and surfactants"
            ],
            "target_properties": [
              "kinematic viscosity (ν)",
              "dynamic viscosity (η)",
              "viscosity deviation (Δη) for mixtures",
              "excess viscosity for binary and multicomponent systems",
              "viscosity–temperature coefficients (Arrhenius parameters, VTF parameters)",
              "activation energy of viscous flow (Ea)"
            ],
            "typical_output_formats": [
              "kinematic viscosity ν vs. temperature T",
              "dynamic viscosity η vs. temperature T",
              "viscosity vs. composition (mole fraction) at fixed T",
              "ln(η) vs. 1/T (Arrhenius plot)",
              "viscosity deviation Δη vs. mole fraction"
            ],
            "units": {
              "density": "kg/m³ or g/cm³",
              "dynamic_viscosity": "mPa·s (= cP)",
              "efflux_time": "s",
              "kinematic_viscosity": "mm²/s (= cSt)",
              "temperature": "K",
              "viscometer_constant": "mm²/s²"
            },
            "unsupported_sample_types": [
              "non-Newtonian or shear-thinning/thickening fluids (viscosity is shear-rate dependent)",
              "highly viscous liquids with efflux times exceeding ~2000 s (evaporation, temperature drift)",
              "very low viscosity gases or supercritical fluids",
              "suspensions or slurries containing particles that can clog the capillary",
              "reactive or polymerizing systems that change viscosity during measurement",
              "opaque liquids where meniscus timing marks cannot be observed (unless automated optical detection is used)"
            ]
          },
          "performance": {
            "accuracy": "0.1–0.5% for kinematic viscosity with proper calibration, temperature control (±0.01 K), and kinetic energy correction; 0.2–0.7% for dynamic viscosity (includes density uncertainty)",
            "detection_limit": "lower limit of kinematic viscosity ~0.2 mm²/s (limited by capillary bore size and minimum practical efflux time); upper limit ~100,000 mm²/s with large-bore viscometers",
            "dynamic_range": "kinematic viscosity from ~0.2 mm²/s to ~100,000 mm²/s; a single viscometer size covers approximately one decade of viscosity",
            "measurement_speed": "individual efflux time 200–1000 s; thermal equilibration in bath 15–30 min per temperature step",
            "precision": "0.05–0.2% (repeatability of replicate efflux times at the same temperature and composition)",
            "resolution": {
              "energy": "not applicable",
              "spatial": "not applicable (bulk liquid measurement)",
              "spectral": "not applicable",
              "temporal": "single measurement per efflux cycle (200–1000 s); typical experimental campaign reports 3–5 replicate efflux times per condition"
            },
            "sensitivity": "can distinguish kinematic viscosity differences as small as 0.01 mm²/s for low-viscosity liquids",
            "throughput": "low — one sample/condition at a time; a single T-composition point requires 15–30 min including equilibration; full viscosity-temperature curve with 5–10 replicates takes several hours"
          },
          "setup_and_requirements": {
            "calibration_requirements": [
              "determine viscometer constant C by measuring efflux time with a certified viscosity reference standard (or pure water with known viscosity) at two or more temperatures",
              "verify calibration periodically (at least annually or whenever the viscometer is cleaned with aggressive agents) using a fresh reference liquid",
              "apply Hagenbach–Couette kinetic energy correction: ν = Ct − K/t or determine effective C and K by two-point calibration with reference oils of different viscosities",
              "confirm viscometer constant stability by tracking control-chart data from repeated reference oil measurements"
            ],
            "consumables": [
              "chromic acid cleaning solution or commercial viscometer cleaning detergent",
              "distilled and deionized water for rinsing",
              "filtered dry nitrogen or clean compressed air for drying",
              "membrane syringe filters (0.45 µm) for sample filtration",
              "silicone oil, water, or ethylene glycol/water mixture as thermostat bath fluid"
            ],
            "environmental_requirements": [
              "draft-free laboratory environment to maintain bath temperature stability",
              "constant ambient temperature (±2 K) to minimize thermal gradients in the exposed viscometer arms",
              "clean, dust-free conditions to prevent particulate contamination of the capillary",
              "stable bench free from vibration that could influence meniscus timing or bath temperature"
            ],
            "instrument_components": [
              "glass capillary viscometer — Ostwald (U-tube with fixed volume marks) or Ubbelohde (three-arm suspended-level design with vented bulb) conforming to ISO 3105 / ASTM D446",
              "precision thermostat water bath — transparent-walled, stirred liquid bath providing temperature uniformity and stability of ±0.01 K (or better); baths typically use water, silicone oil, or ethylene glycol/water depending on temperature range",
              "calibrated thermometer or platinum resistance thermometer (PRT) — traceable to ITS-90, resolution ≤0.001 K",
              "timing device — electronic stopwatch (resolution 0.01 s) or automated photoelectric/optical sensor pair positioned at upper and lower fiducial marks for hands-free efflux time measurement",
              "viscometer holder/mount — vertical alignment fixture ensuring the viscometer is plumb within ±0.5° of vertical",
              "pipette or syringe — for charging precisely the required volume of sample into the viscometer (Ostwald requires exact volume; Ubbelohde is less critical)",
              "suction/pressure source — rubber aspirator bulb or small pump for drawing sample into the upper reservoir before releasing for gravity flow",
              "cleaning and drying apparatus — chromic acid or detergent solutions, distilled water rinse, filtered dry air or nitrogen for drying the capillary between samples"
            ],
            "reference_materials": [
              "NIST traceable certified viscosity reference oils (e.g., Cannon N-series or S-series standards covering 0.3 to 100,000 mm²/s)",
              "ultra-pure water (IAPWS viscosity standard: η = 1.0016 mPa·s at 293.15 K; ν ≈ 1.004 mm²/s)",
              "NIST SRM 2490 (polyisobutylene solution in 2,6,10,14-tetramethylpentadecane) for Newtonian viscosity reference"
            ],
            "safety_notes": [
              "chromic acid cleaning solution is a strong oxidizer and known carcinogen — use in a fume hood with appropriate PPE; prefer modern non-chromic cleaning alternatives where possible",
              "glass viscometers are fragile — handle with care to avoid breakage and injury from glass shards",
              "hot bath fluids (>373 K) or cryogenic bath fluids present burn/frostbite hazards",
              "volatile organic solvents require ventilation and avoidance of ignition sources"
            ],
            "sample_requirements": {
              "geometry": [
                "free-flowing liquid at the measurement temperature"
              ],
              "mounting_requirements": [
                "viscometer must be held perfectly vertical in the bath (± 0.5° of plumb) — tilting alters the effective hydrostatic head",
                "the viscometer must be immersed so that both bulbs and the capillary section are fully within the thermostated liquid"
              ],
              "preparation_requirements": [
                "filter sample through a 0.45 µm or finer membrane filter to remove particulates",
                "degas the sample (by gentle vacuum or ultrasonic bath) to prevent bubble formation in the capillary during flow",
                "dry the viscometer thoroughly between successive samples using filtered air or dry nitrogen",
                "for hygroscopic or volatile liquids, handle under dry or inert atmosphere and minimize exposure time"
              ],
              "size_limits": "Ubbelohde: 10–15 mL typical charge; Ostwald: a precisely specified volume (to ±0.1 mL) as defined by the viscometer marks, typically 3–10 mL",
              "surface_requirements": [
                "liquid must wet the glass walls cleanly to form a reproducible meniscus",
                "sample must be optically transparent (or translucent) so that fiducial marks can be observed visually or by optical sensor"
              ],
              "thickness_limits": ""
            }
          },
          "uncertainty": {
            "dominant_error_sources": [
              "temperature control and measurement (dominates total budget for well-calibrated systems)",
              "viscometer constant calibration (propagates directly to reported viscosity)",
              "kinetic energy correction (dominant for fluids with efflux times <200 s)",
              "density uncertainty (for dynamic viscosity η = νρ)"
            ],
            "level": "typical combined standard uncertainty 0.1–0.5% for kinematic viscosity; 0.2–0.7% for dynamic viscosity (additional density uncertainty)",
            "model_dependence": "low — the Hagen–Poiseuille equation with Hagenbach–Couette correction is well-established for Newtonian laminar flow; model dependence increases only if the sample exhibits non-Newtonian behavior or if kinetic energy correction is poorly characterized",
            "operator_dependence": "moderate for manual timing (reaction-time variability is the largest operator-dependent error); low for automated photoelectric detection systems; sample loading and viscometer cleaning technique also depend on operator skill",
            "random_sources": [
              "operator reaction time in starting/stopping manual timer (±0.1–0.3 s per mark; eliminated by automated sensors)",
              "meniscus shape variability at the timing marks",
              "short-term temperature fluctuations (bath stability)",
              "micro-bubble formation between runs",
              "small variations in sample charge volume (Ostwald design)"
            ],
            "reported_as": [
              "combined expanded uncertainty U(ν) at 95% confidence (k=2)",
              "relative uncertainty as percentage of ν or η",
              "standard deviation of replicate efflux times"
            ],
            "systematic_sources": [
              "viscometer constant calibration uncertainty (typically 0.1–0.2%)",
              "kinetic energy correction uncertainty (significant for short efflux times <200 s)",
              "temperature measurement offset or drift (0.01 K ≈ 0.02–0.05% in viscosity)",
              "non-Newtonian behavior of nominally Newtonian sample at high shear rates in fine capillaries",
              "capillary bore non-uniformity or dimensional change from aggressive cleaning",
              "surface tension effects on meniscus curvature (Ostwald design, volume-dependent)",
              "density uncertainty propagated into dynamic viscosity (typically 0.01–0.05%)"
            ],
            "thermoml_encoding": "nCombExpandUncertValue at 95% confidence level"
          }
        }
      },
      "identity": {
        "acronym": "",
        "aliases": [],
        "canonical_method_name": "Capillary tube (Ostwald; Ubbelohde) method",
        "db_usage": {
          "instance_count": 3407,
          "n_papers": 716,
          "per_group": {
            "TransportProp": {
              "instances": 3407,
              "papers": 716
            }
          },
          "property_groups": [
            "TransportProp"
          ]
        },
        "measurement_family": "Viscometry",
        "modality": {
          "contact": "yes",
          "destructive": "no",
          "imaging": "no",
          "in_situ": "no"
        },
        "name": "Capillary tube (Ostwald; Ubbelohde) method",
        "source_aliases": [
          {
            "method_type": "standard",
            "name": "Capillary tube (Ostwald; Ubbelohde) method"
          }
        ],
        "thermoml_custom_codes": [
          "CAPTUB"
        ],
        "thermoml_standard_name": "Capillary tube (Ostwald; Ubbelohde) method"
      },
      "match_score": 86,
      "match_type": "name_fuzzy",
      "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
      "meas_id": "capillary_tube_ostwald_ubbelohde_method",
      "meas_num_id": "GLOBmeas_4"
    },
    {
      "card_type": "registry_stub",
      "compact_md": "# MTDKS-DK | e | GLOBmeas_1532\n\n**Name:** e\n**Family:** Custom\n**Usage:** 2 instances | 1 papers | groups=TransportProp\n**Per-group:** TransportProp: 2 inst/1 papers\n",
      "domain_knowledge": null,
      "identity": {
        "canonical_method_name": "e",
        "db_usage": {
          "instance_count": 2,
          "n_papers": 1,
          "per_group": {
            "TransportProp": {
              "instances": 2,
              "papers": 1
            }
          },
          "property_groups": [
            "TransportProp"
          ]
        },
        "measurement_family": "Custom",
        "name": "e",
        "source_aliases": [
          {
            "method_type": "custom",
            "name": "e"
          }
        ]
      },
      "match_score": 85,
      "match_type": "name_fuzzy",
      "meas_ID": "e",
      "meas_id": "e",
      "meas_num_id": "GLOBmeas_1532"
    },
    {
      "card_type": "registry_stub",
      "compact_md": "# MTDKS-DK | capillary_flow | GLOBmeas_198\n\n**Name:** Capillary flow\n**Family:** Custom\n**Usage:** 102 instances | 1 papers | groups=Criticals\n**Per-group:** Criticals: 102 inst/1 papers\n",
      "domain_knowledge": null,
      "identity": {
        "canonical_method_name": "Capillary flow",
        "db_usage": {
          "instance_count": 102,
          "n_papers": 1,
          "per_group": {
            "Criticals": {
              "instances": 102,
              "papers": 1
            }
          },
          "property_groups": [
            "Criticals"
          ]
        },
        "measurement_family": "Custom",
        "name": "Capillary flow",
        "source_aliases": [
          {
            "method_type": "custom",
            "name": "Capillary flow"
          }
        ]
      },
      "match_score": 52,
      "match_type": "name_fuzzy",
      "meas_ID": "capillary_flow",
      "meas_id": "capillary_flow",
      "meas_num_id": "GLOBmeas_198"
    },
    {
      "card_type": "standard_dk",
      "compact_md": "# MTDKS-DK | concentric_cylinders_viscometry | GLOBmeas_11\n\n**Name:** Concentric cylinders viscometry\n**Family:** Viscometry\n**ThermoML std:** Concentric cylinders viscometry\n**Custom codes:** CONCYL\n**Modality:** contact=yes, destructive=no, in_situ=no, imaging=no\n**Usage:** 1082 instances | 231 papers | groups=TransportProp\n**Per-group:** TransportProp: 1082 inst/231 papers\n\n## Structured Knowledge\n\n### measurement_scope\n**direct_observables:**\n- torque on stationary cylinder (T)\n- angular velocity of rotating cylinder (ω)\n- temperature of fluid in annular gap (T_fluid)\n**derived_observables:**\n- dynamic viscosity (η)\n- shear stress (τ)\n- shear rate (γ̇)\n- kinematic viscosity (ν = η/ρ, when density is known)\n- apparent viscosity as a function of shear rate (for non-Newtonian fluids)\n**target_properties:**\n- dynamic viscosity (η)\n- kinematic viscosity (ν)\n- viscosity as a function of temperature\n- viscosity as a function of shear rate (flow curve)\n- viscosity as a function of pressure (with pressurized variants)\n- activation energy of viscous flow (from η vs. T data)\n**phases_measured:**\n- liquid (Newtonian)\n- liquid (non-Newtonian: shear-thinning, shear-thickening)\n- liquid mixtures and solutions\n- colloidal suspensions\n- emulsions\n- polymer solutions and melts\n**supported_sample_types:**\n- pure liquids\n- binary and multicomponent liquid mixtures\n- electrolyte solutions\n- ionic liquids\n- polymer solutions\n- polymer melts\n- colloidal suspensions and slurries\n- emulsions\n- oils and lubricants\n- molten salts\n- biological fluids (blood, protein solutions)\n**unsupported_sample_types:**\n- gases (torque signal too small for reliable measurement)\n- extremely low-viscosity fluids below ~0.3 mPa·s (approaches instrument sensitivity limit)\n- solids and gels with yield stress exceeding instrument torque range\n- highly volatile liquids that evaporate from the open gap\n- samples containing large particles (>1/3 of gap width) that jam in the annular gap\n- strongly corrosive fluids without chemically resistant cylinder materials\n**typical_output_formats:**\n- η vs. T curve at fixed shear rate\n- η vs. shear rate (flow curve) at fixed T\n- torque vs. angular velocity (raw rheogram)\n- shear stress vs. shear rate plot\n- Arrhenius plot: ln(η) vs. 1/T\n**units:**\n- dynamic_viscosity: Pa·s or mPa·s\n- kinematic_viscosity: mm²/s (cSt)\n- shear_stress: Pa\n- shear_rate: s⁻¹\n- torque: N·m or mN·m\n- angular_velocity: rad/s or rpm\n- temperature: K\n\n### experimental_parameters\n**constraints:**\n- **temperature_range** — typical: 253 K to 473 K — limits: depends on cylinder material and sealing; specialized setups extend to 200 K (cryogenic) or 773 K (molten salts with ceramic/metal cylinders) — notes: standard instruments with Peltier or circulating bath temperature control cover 263–473 K\n- **shear_rate** — typical: 0.1 s⁻¹ to 10,000 s⁻¹ — limits: lower limit set by torque sensitivity; upper limit set by onset of Taylor vortices or turbulence in the gap — notes: Taylor number Ta = ω·R₁·d/ν (where d = gap width) must remain below critical value (~41 for narrow gaps) to ensure laminar Couette flow\n- **gap_width** — typical: 1 mm to 2 mm — limits: minimum ~0.5 mm (machining tolerance and alignment); maximum ~5 mm before curvature corrections become large — notes: narrow gaps (R₂/R₁ close to 1) simplify analysis by ensuring nearly uniform shear rate; DIN 53019 specifies R₂/R₁ = 1.0847\n- **pressure** — typical: 0.1 MPa (ambient) — limits: pressurized variants operate up to 1 GPa with sealed high-pressure cells — notes: standard instruments operate at atmospheric pressure; high-pressure measurements require specialized sealed geometry\n- **torque_range** — typical: 0.01 mN·m to 200 mN·m — limits: minimum detectable torque ~0.001 mN·m for air-bearing instruments; maximum limited by motor and transducer capacity — notes: torque range determines the accessible viscosity window for a given geometry\n**variables:**\n- **angular_velocity** — typical: 0.01 to 1000 rpm — effect: directly sets the shear rate in the gap; γ̇ = 2ωR₂²/(R₂² - R₁²) for inner cylinder rotation; determines whether flow remains laminar\n- **temperature** — typical: 273 K to 373 K — effect: viscosity is strongly temperature-dependent; Arrhenius or VFT behavior; temperature must be controlled to ±0.01–0.1 K for accurate viscosity data\n- **gap_geometry** — typical: R₁ = 12–14 mm, R₂ = 14–15 mm (DIN standard); cylinder length L = 30–50 mm — effect: defines the conversion factor between torque/angular velocity and viscosity; narrow gaps give more uniform shear rate\n- **sample_volume** — typical: 2 mL to 30 mL — effect: must be sufficient to fill the annular gap completely and cover the immersed cylinder length; overfilling or underfilling introduces end-effect errors\n\n### setup_and_requirements\n**instrument_components:**\n- outer cylinder (cup) — precision-machined metal (stainless steel, aluminum, or titanium) or glass cylinder that serves as the sample container\n- inner cylinder (bob) — coaxial rotating or stationary cylinder, precisely centered in the cup\n- drive motor — DC servo or electronically commutated (EC) motor providing controlled angular velocity or controlled torque\n- torque transducer — strain gauge, capacitive, or optical sensor measuring the reaction torque on the measuring cylinder\n- air bearing or jewel bearing — low-friction support for the inner cylinder spindle to minimize parasitic torque\n- temperature control system — Peltier element, circulating fluid jacket, or electrical heating mantle surrounding the outer cylinder\n- temperature sensor — Pt100 RTD or thermocouple positioned in the outer cylinder wall or in the fluid gap\n- solvent trap or evaporation cover — cap or shield to minimize evaporation from the open top of the annular gap\n- data acquisition and control software — controls motor speed/torque, records torque, speed, and temperature in real time\n**environmental_requirements:**\n- vibration-free bench or anti-vibration table to prevent flow disturbances in the gap\n- stable ambient temperature (±2 K) to reduce thermal drift in electronics and bearing friction\n- level instrument installation — cylinder concentricity depends on proper leveling\n- draft-free environment or enclosure to prevent convective cooling of the sample\n**sample_requirements:**\n- geometry: ['liquid sample that flows freely to fill the annular gap uniformly']\n- size_limits: typically 2–30 mL depending on cylinder dimensions; DIN standard geometries require ~20 mL\n- thickness_limits: not applicable — sample fills the annular gap (1–2 mm width) defined by the cylinder geometry\n- surface_requirements: ['no wall slip — if sample slips at cylinder surfaces, surface roughening or serrated cylinders may be required', 'wetting: sample must wet both cylinder surfaces to transmit shear stress without slip layers']\n- mounting_requirements: ['sample loaded into the outer cup with the inner bob raised, then bob lowered into sample', 'ensure no air bubbles are trapped in the annular gap (visible inspection or pre-shearing)', 'correct fill level: sample meniscus should be at the top of the bob measurement zone']\n- preparation_requirements: ['degas sample if dissolved gases cause bubble formation during shearing', 'filter sample to remove particles larger than 1/3 gap width', 'equilibrate sample temperature before measurement or use instrument temperature control with adequate soak time', 'for non-Newtonian fluids, apply defined pre-shear protocol to establish reproducible starting microstructure']\n**calibration_requirements:**\n- viscosity standard calibration using certified reference oils (e.g., Cannon N-series or PTB/NIST standard oils) spanning the measurement range\n- torque calibration using a known weight suspended from the bob on a calibrated arm\n- angular velocity verification using a tachometer or frequency counter on the motor encoder\n- temperature sensor calibration against a traceable reference thermometer or at fixed points (ice point, Ga melting)\n- gap geometry verification — measure R₁, R₂, and L with calibrated micrometer; confirm concentricity\n**reference_materials:**\n- NIST Standard Reference Materials: SRM 2490 (polyisobutylene in 2,6,10,14-tetramethylpentadecane, ~900 Pa·s at 25°C)\n- NIST SRM 2492 (Bingham paste standard for yield stress calibration)\n- Cannon Instrument Company certified viscosity standards (S3 to S60000 series covering 1 to 100,000 mPa·s)\n- PTB (Germany) certified viscosity reference oils\n- deionized water (0.890 mPa·s at 25°C — useful low-viscosity check)\n**consumables:**\n- cleaning solvents (acetone, ethanol, or petroleum ether) for cylinder surface preparation\n- lint-free wipes for drying cylinders\n- viscosity standard oils for periodic recalibration\n- solvent trap inserts or covers for volatile samples\n- disposable cylinder inserts or liners (for corrosive or difficult-to-clean samples)\n**safety_notes:**\n- rotating cylinder creates pinch hazard — keep fingers and loose clothing away from the gap during operation\n- hot outer cylinder jacket (above 373 K) requires burn protection\n- volatile or toxic solvents require fume extraction and appropriate PPE\n- high-viscosity samples at high shear rates can generate significant viscous heating — monitor temperature for runaway\n\n### performance\n**sensitivity:** minimum measurable viscosity ~0.5 mPa·s with narrow-gap geometries and air-bearing instruments; torque sensitivity ~0.001 mN·m for research-grade rheometers\n**detection_limit:** lower viscosity limit ~0.3–0.5 mPa·s constrained by ambient torque noise and bearing friction; upper limit >10⁶ mPa·s limited by maximum torque\n**resolution:**\n- spatial: not applicable (bulk measurement of annular gap volume)\n- temporal: transient torque response captured at 1–1000 Hz sampling rates depending on data acquisition system\n- spectral: not applicable\n- energy: not applicable\n**dynamic_range:** viscosity range approximately 0.5 mPa·s to >10⁶ mPa·s using interchangeable cylinder sets; ~4 decades with a single geometry\n**accuracy:** 1–3% for Newtonian fluids after full calibration and end-effect correction; 3–5% for non-Newtonian fluids due to additional shear-rate non-uniformity corrections\n**precision:** 0.5–1% repeatability for Newtonian fluids at a given temperature and shear rate\n**throughput:** single sample per measurement; 5–30 minutes per viscosity-temperature curve depending on number of points and equilibration time\n**measurement_speed:** steady-state viscosity determination at a single temperature/shear-rate point requires 30 s to 5 min depending on equilibration\n\n### data_and_interpretation\n**raw_signal_type:** torque (T) on the measuring cylinder as a function of angular velocity (ω) of the driving cylinder, recorded simultaneously with temperature\n**preprocessing_steps:**\n- zero-torque correction: subtract residual torque from bearing friction and air drag measured with empty instrument\n- end-effect correction: account for torque contributions from fluid below the bob base and at the meniscus (Mooney-Ewart correction or guard-ring design)\n- temperature equilibration verification: confirm that torque signal has reached steady state before recording\n- inertia correction: subtract contributions from fluid and bob inertia during acceleration phases (relevant for transient measurements)\n- wall slip check: compare results at two gap widths — if viscosity changes with gap, wall slip is present\n**analysis_methods:**\n- Margules equation: η = T(R₂² - R₁²)/(4πLωR₁²R₂²) for narrow-gap Couette flow with inner cylinder rotation\n- Krieger-Elrod correction: wide-gap correction for non-Newtonian fluids iterating true shear rate at the bob wall\n- Power-law or Herschel-Bulkley fit to flow curve (τ vs. γ̇) for non-Newtonian characterization\n- Arrhenius fit: ln(η) = ln(A) + Ea/(RT) for temperature-dependent viscosity of simple liquids\n- Vogel-Fulcher-Tammann (VFT) fit: η = η₀·exp(B/(T-T₀)) for glass-forming liquids\n- Andrade equation fit for viscosity-temperature correlation\n**model_assumptions:**\n- laminar Couette flow — no Taylor vortices, no turbulence (Reynolds number below critical value)\n- incompressible fluid in the annular gap\n- no-slip boundary condition at both cylinder surfaces\n- isothermal conditions — negligible viscous heating in the gap during measurement\n- steady-state flow — torque measurement taken after transient start-up flow has decayed\n- cylindrical symmetry — perfect concentricity of inner and outer cylinders\n**fit_parameters:**\n- dynamic viscosity η (for Newtonian fluids)\n- power-law index n and consistency factor K (for power-law fluids: τ = K·γ̇ⁿ)\n- yield stress τ₀ (for Bingham or Herschel-Bulkley fluids)\n- Arrhenius activation energy Ea and pre-exponential factor A\n- VFT parameters η₀, B, T₀ for glass-forming liquids\n**common_artifacts:**\n- Taylor vortex artifact: onset of secondary flow above critical Taylor number causes apparent viscosity increase and non-linear torque-speed relationship\n- end-effect artifact: additional torque from fluid below bob base leads to systematic overestimate of viscosity if uncorrected\n- wall slip artifact: measured viscosity appears lower than true value; exhibits gap-width dependence\n- viscous heating artifact: high shear rates generate heat faster than it dissipates, causing in-situ temperature rise and apparent shear-thinning in Newtonian fluids\n- evaporation artifact: sample loss from open top of gap decreases effective wetted length, causing apparent viscosity drift over time\n- air bubble artifact: trapped bubbles reduce effective fluid volume and cause erratic torque readings\n- eccentricity artifact: misalignment of inner and outer cylinders creates non-uniform gap and systematic viscosity error\n**quality_control_checks:**\n- verify Newtonian response: plot η vs. shear rate — should be flat for Newtonian standard oils\n- measure certified viscosity standard at a reference temperature and confirm agreement within stated accuracy\n- compare results from two different gap widths to detect wall slip\n- check for Taylor instability: look for abrupt change in torque-speed curve slope at high rotation rates\n- repeat measurement after thermal cycling to confirm absence of sample degradation or bubble formation\n- inspect bob and cup surfaces for scratches, deposits, or corrosion that alter gap geometry\n**failure_modes:**\n- loss of concentricity due to bearing wear or improper leveling (systematic viscosity error)\n- torque transducer drift or saturation (erroneous viscosity readings)\n- sample crystallization or gelation in the gap (sudden torque spike or instrument overload)\n- motor speed instability at very low rpm (noisy shear-rate control)\n- thermal runaway from viscous heating at high shear rates (uncontrolled temperature rise)\n- bob detachment or coupling failure during high-torque measurements\n\n### uncertainty\n**level:** typical combined standard uncertainty 1–3% for Newtonian fluids; 3–5% for non-Newtonian fluids due to shear-rate non-uniformity\n**random_sources:**\n- torque transducer noise and drift\n- temperature fluctuations in the sample (±0.01–0.1 K translates to 0.1–2% viscosity variation for typical dη/dT)\n- angular velocity fluctuations from motor controller\n- mechanical vibrations transmitted to the instrument\n- sample surface disturbances from meniscus instability or evaporation\n**systematic_sources:**\n- end-effect correction uncertainty (contributes 0.5–2% depending on geometry and correction method)\n- gap geometry dimensional tolerances (radii and length, typically ±5–10 µm machining tolerance)\n- eccentricity of inner and outer cylinders\n- temperature calibration offset (systematic shift in reported viscosity at the wrong T)\n- viscous heating not fully corrected (especially at high shear rates)\n- wall slip (undetected slip gives systematically low viscosity)\n- sample density uncertainty when converting to kinematic viscosity\n- torque transducer calibration uncertainty\n**operator_dependence:** moderate — sample loading technique (avoiding bubbles), fill level, cleaning procedures, and temperature equilibration discipline significantly affect results\n**model_dependence:** low for Newtonian fluids measured in narrow-gap geometry (Margules equation is exact for ideal Couette flow); moderate to high for non-Newtonian fluids requiring shear-rate correction models\n**dominant_error_sources:**\n- temperature measurement and control uncertainty (viscosity has exponential T-dependence)\n- end-effect correction accuracy\n- gap geometry dimensional uncertainty (especially for narrow gaps where small absolute errors are large relative errors)\n**reported_as:**\n- combined expanded uncertainty U(η) at 95% confidence (k=2)\n- relative uncertainty as percentage of η\n- standard deviation from repeated measurements at fixed conditions\n**thermoml_encoding:** nCombExpandUncertValue at 95% confidence level\n\n## Description\n\n### technique_overview\nConcentric cylinders viscometry (also known as Couette viscometry) is a rotational rheometric technique that determines the dynamic viscosity of a fluid by measuring the torque required to maintain steady rotation of one cylinder inside another, with the test fluid filling the annular gap between them. First systematically analyzed by Maurice Couette in 1890, the method remains one of the most widely used approaches for viscosity measurement because of its well-defined flow geometry, broad viscosity range (~0.5 mPa·s to >10⁶ mPa·s), and ability to characterize both Newtonian and non-Newtonian fluids. It is the dominant rotational viscometry technique in the NIST ThermoML database with 1082 instances across 231 papers, reflecting its central role in transport property measurements for pure liquids, mixtures, electrolyte solutions, and ionic liquids.\n\n### how_it_operates\nThe sample fluid is loaded into the annular gap (typically 1–2 mm wide) between two coaxial cylindrical surfaces. In the most common configuration, the outer cylinder (cup) is stationary and the inner cylinder (bob) rotates at a controlled angular velocity ω, although the inverse configuration (rotating cup, stationary bob with torque measurement) is also used. The rotating cylinder establishes a steady-state Couette flow in the gap, producing a shear stress that is transmitted through the fluid and registered as a reaction torque on the measuring element. A precision torque transducer measures this torque T, and the viscosity is calculated from the Margules equation: η = T·(1/R₁² − 1/R₂²)/(4πLω), where R₁ and R₂ are the inner and outer cylinder radii and L is the immersed cylinder length. Temperature is controlled via a Peltier element or circulating fluid jacket on the outer cylinder, allowing viscosity to be mapped as a function of temperature at defined shear rates.\n\n### core_theory\nThe analysis is based on the Navier-Stokes equations for an incompressible Newtonian fluid in the annular gap between two infinitely long coaxial cylinders. Under steady laminar flow with no axial or radial velocity components, the azimuthal velocity profile u(r) is determined by the balance between viscous stress and the imposed boundary conditions (no-slip at both walls). The resulting torque on a cylinder of length L is T = 4πηLωR₁²R₂²/(R₂² − R₁²), which when inverted gives the Margules equation for viscosity. For narrow gaps where R₂/R₁ ≈ 1, the shear rate is approximately uniform across the gap: γ̇ ≈ ωR₁/(R₂ − R₁). For wide gaps, the shear rate varies as 1/r² across the gap, requiring correction factors (Krieger-Elrod method) when measuring non-Newtonian fluids. The calculation assumes laminar Couette flow, which is valid below a critical Taylor number Ta_c ≈ 41.2 for the narrow-gap limit; above this, Taylor vortices form and the simple viscosity equation no longer applies.\n\n### setup\nA typical concentric-cylinder viscometer consists of a precision-machined outer cup (stainless steel, aluminum, or specialty alloy) mounted in a temperature-controlled jacket, and an inner bob suspended from a low-friction air bearing or jeweled bearing that connects to a torque transducer and drive motor. The cup is filled with the sample liquid, and the bob is lowered into the fluid until the measurement zone is fully immersed. A solvent trap or evaporation cover caps the assembly to minimize sample loss. Research-grade rotational rheometers (e.g., Anton Paar MCR series, TA Instruments Discovery HR, Malvern Kinexus) use electronically controlled motors capable of both controlled-rate (imposed ω, measured T) and controlled-stress (imposed T, measured ω) operation. The instrument is mounted on a vibration-free surface and leveled to ensure concentricity.\n\n### suitable_for\nConcentric cylinders viscometry is particularly well suited for low-to-moderate-viscosity liquids in the range 0.5–10,000 mPa·s, where cone-and-plate geometries may have difficulty containing the sample. It excels at measuring temperature-dependent viscosity of pure liquids, liquid mixtures, electrolyte solutions, and ionic liquids — the property types that dominate its ThermoML usage. The geometry is ideal for suspensions and emulsions because the sealed gap prevents particle sedimentation artifacts during measurement and accommodates larger particles than narrow cone-plate gaps. It is well suited for time-dependent measurements (thixotropy, rheopexy) because the enclosed gap maintains sample integrity during prolonged shearing. The wide shear-rate range supports both Newtonian characterization at a single rate and full flow-curve determination for non-Newtonian fluids.\n\n### core_limitations\nThe fundamental limitation is the onset of Taylor vortices above the critical angular velocity, which imposes an upper bound on the accessible shear rate for a given fluid viscosity and gap geometry. For low-viscosity fluids (~1 mPa·s), the maximum shear rate before Taylor instability may be only a few hundred s⁻¹. End effects from the fluid below the bob and at the meniscus introduce systematic errors that must be corrected or minimized by special bob designs (cone-bottom Mooney-Ewart geometries or guard rings). Viscous heating at high shear rates can raise the sample temperature faster than the jacket can dissipate heat, producing erroneous viscosity data. The relatively large sample volume (2–30 mL) compared to cone-and-plate (~0.5 mL) can be a disadvantage when sample is scarce. Wall slip can occur with structured fluids, yielding artificially low viscosity values.\n\n### sample_preparation\nThe sample should be a homogeneous liquid free of air bubbles and particles larger than approximately one-third of the gap width (~0.3–0.7 mm). Degassing under mild vacuum or gentle stirring removes dissolved gases that might form bubbles during shearing. Suspensions should be filtered or verified to have maximum particle sizes compatible with the gap. The sample is loaded by pouring or pipetting into the cup with the bob raised, taking care to avoid introducing air. After the bob is lowered to the measuring position, any excess sample is trimmed from the top to match the correct fill level. For temperature-dependent measurements, the sample is equilibrated at the starting temperature for 5–15 minutes before data acquisition. For non-Newtonian fluids, a pre-shear protocol (e.g., 60 s at a defined shear rate followed by a rest period) establishes a reproducible initial microstructure.\n\n### calibration_and_references\nCalibration is performed by measuring certified viscosity standard oils (e.g., Cannon Instrument Company S-series or NIST SRM 2490) at reference temperatures and verifying agreement within the stated uncertainty. A minimum of two standard oils spanning the viscosity range of interest should be used to confirm both the torque transducer linearity and the gap geometry conversion factor. Temperature calibration is verified by measuring the viscosity of water at 20°C (1.002 mPa·s) or 25°C (0.890 mPa·s) and comparing against NIST reference values. The angular velocity is verified using the motor encoder or an external tachometer. End-effect magnitude is characterized by measuring the same standard oil with two different immersion depths or with and without a cone-bottom bob. Calibration should be repeated at regular intervals (monthly for routine use) and whenever the geometry is changed or the instrument is serviced.\n\n### data_interpretation\nFor Newtonian fluids, the viscosity η is directly computed from the Margules equation using measured torque and angular velocity, after applying zero-torque (bearing friction) and end-effect corrections. The viscosity should be independent of shear rate; any shear-rate dependence indicates either non-Newtonian behavior, instrumental artifacts (Taylor vortices at high rates, torque resolution limit at low rates), or wall slip. Temperature-dependent data are typically fitted to the Arrhenius equation ln(η) = ln(A) + Ea/(RT) for simple liquids, or to the Vogel-Fulcher-Tammann equation η = η₀·exp(B/(T−T₀)) for glass-forming or strongly non-Arrhenius systems. For non-Newtonian fluids, the raw torque-speed data are converted to shear stress–shear rate curves using Krieger-Elrod wide-gap corrections when R₂/R₁ deviates significantly from unity, and fitted to power-law, Herschel-Bulkley, or Cross models as appropriate.\n\n### common_pitfalls\nThe most frequent pitfall is inadequate temperature control — because viscosity varies exponentially with temperature (typically 2–10% per kelvin for organic liquids near room temperature), temperature errors of ±0.1 K can exceed the target measurement uncertainty. Trapped air bubbles in the gap produce erratic and unreproducible torque readings; visual inspection after bob insertion is essential. Operating above the critical Taylor number without recognizing it leads to systematically high apparent viscosity because of the additional energy dissipation in Taylor vortices. Incorrect fill level (underfilling or overfilling) changes the effective measurement length and biases the result. Neglecting end-effect corrections, particularly with short bobs or wide gaps, introduces systematic overestimates of 2–5%. Using uncleaned or scratched cylinder surfaces promotes wall slip and alters the effective gap dimensions.\n\n### artifacts_and_failure_modes\nTaylor vortices appear as a characteristic upward inflection in the torque–angular velocity curve above the critical speed, causing measured viscosity to increase with shear rate even for Newtonian fluids. End-effect artifacts manifest as a constant torque offset that becomes significant relative to the total torque at low viscosities or short immersion lengths. Viscous heating artifacts present as apparent shear-thinning in Newtonian fluids at high shear rates, because the gap temperature rises above the jacket-controlled value. Evaporation from the open gap top causes a progressive drop in the apparent liquid level, reducing the effective wetted length and producing a slow downward drift in measured viscosity over time. Wall slip artifacts give anomalously low viscosity that increases with increasing gap width (opposite to the gap-width independence expected for no-slip conditions). Eccentricity artifacts from misaligned cylinders can produce periodic torque oscillations and a systematic viscosity error proportional to the square of the eccentricity ratio.\n\n### reporting_checklist\nPublished concentric-cylinder viscometry results should report: inner and outer cylinder radii (R₁, R₂) and immersed length L, or identify the standard geometry used (DIN 53019, ISO 3219); bob/cup material; gap width and radius ratio R₂/R₁; controlled mode (controlled rate or controlled stress); shear rate(s) or angular velocity(ies) employed; temperature, its uncertainty, and the control method (Peltier, circulating bath); sample description and preparation (degassing, filtering); equilibration time and pre-shear protocol (if applicable); end-effect correction method applied; whether Taylor number was checked against the critical value; viscosity standard used for calibration and deviation from certified values; combined expanded uncertainty U(η) at 95% confidence (k = 2) with uncertainty budget identifying dominant sources; and for ThermoML encoding, viscosity values are reported with nCombExpandUncertValue at the 95% confidence level.\n",
      "domain_knowledge": {
        "description_block": {
          "artifacts_and_failure_modes": "Taylor vortices appear as a characteristic upward inflection in the torque–angular velocity curve above the critical speed, causing measured viscosity to increase with shear rate even for Newtonian fluids. End-effect artifacts manifest as a constant torque offset that becomes significant relative to the total torque at low viscosities or short immersion lengths. Viscous heating artifacts present as apparent shear-thinning in Newtonian fluids at high shear rates, because the gap temperature rises above the jacket-controlled value. Evaporation from the open gap top causes a progressive drop in the apparent liquid level, reducing the effective wetted length and producing a slow downward drift in measured viscosity over time. Wall slip artifacts give anomalously low viscosity that increases with increasing gap width (opposite to the gap-width independence expected for no-slip conditions). Eccentricity artifacts from misaligned cylinders can produce periodic torque oscillations and a systematic viscosity error proportional to the square of the eccentricity ratio.",
          "calibration_and_references": "Calibration is performed by measuring certified viscosity standard oils (e.g., Cannon Instrument Company S-series or NIST SRM 2490) at reference temperatures and verifying agreement within the stated uncertainty. A minimum of two standard oils spanning the viscosity range of interest should be used to confirm both the torque transducer linearity and the gap geometry conversion factor. Temperature calibration is verified by measuring the viscosity of water at 20°C (1.002 mPa·s) or 25°C (0.890 mPa·s) and comparing against NIST reference values. The angular velocity is verified using the motor encoder or an external tachometer. End-effect magnitude is characterized by measuring the same standard oil with two different immersion depths or with and without a cone-bottom bob. Calibration should be repeated at regular intervals (monthly for routine use) and whenever the geometry is changed or the instrument is serviced.",
          "common_pitfalls": "The most frequent pitfall is inadequate temperature control — because viscosity varies exponentially with temperature (typically 2–10% per kelvin for organic liquids near room temperature), temperature errors of ±0.1 K can exceed the target measurement uncertainty. Trapped air bubbles in the gap produce erratic and unreproducible torque readings; visual inspection after bob insertion is essential. Operating above the critical Taylor number without recognizing it leads to systematically high apparent viscosity because of the additional energy dissipation in Taylor vortices. Incorrect fill level (underfilling or overfilling) changes the effective measurement length and biases the result. Neglecting end-effect corrections, particularly with short bobs or wide gaps, introduces systematic overestimates of 2–5%. Using uncleaned or scratched cylinder surfaces promotes wall slip and alters the effective gap dimensions.",
          "core_limitations": "The fundamental limitation is the onset of Taylor vortices above the critical angular velocity, which imposes an upper bound on the accessible shear rate for a given fluid viscosity and gap geometry. For low-viscosity fluids (~1 mPa·s), the maximum shear rate before Taylor instability may be only a few hundred s⁻¹. End effects from the fluid below the bob and at the meniscus introduce systematic errors that must be corrected or minimized by special bob designs (cone-bottom Mooney-Ewart geometries or guard rings). Viscous heating at high shear rates can raise the sample temperature faster than the jacket can dissipate heat, producing erroneous viscosity data. The relatively large sample volume (2–30 mL) compared to cone-and-plate (~0.5 mL) can be a disadvantage when sample is scarce. Wall slip can occur with structured fluids, yielding artificially low viscosity values.",
          "core_theory": "The analysis is based on the Navier-Stokes equations for an incompressible Newtonian fluid in the annular gap between two infinitely long coaxial cylinders. Under steady laminar flow with no axial or radial velocity components, the azimuthal velocity profile u(r) is determined by the balance between viscous stress and the imposed boundary conditions (no-slip at both walls). The resulting torque on a cylinder of length L is T = 4πηLωR₁²R₂²/(R₂² − R₁²), which when inverted gives the Margules equation for viscosity. For narrow gaps where R₂/R₁ ≈ 1, the shear rate is approximately uniform across the gap: γ̇ ≈ ωR₁/(R₂ − R₁). For wide gaps, the shear rate varies as 1/r² across the gap, requiring correction factors (Krieger-Elrod method) when measuring non-Newtonian fluids. The calculation assumes laminar Couette flow, which is valid below a critical Taylor number Ta_c ≈ 41.2 for the narrow-gap limit; above this, Taylor vortices form and the simple viscosity equation no longer applies.",
          "data_interpretation": "For Newtonian fluids, the viscosity η is directly computed from the Margules equation using measured torque and angular velocity, after applying zero-torque (bearing friction) and end-effect corrections. The viscosity should be independent of shear rate; any shear-rate dependence indicates either non-Newtonian behavior, instrumental artifacts (Taylor vortices at high rates, torque resolution limit at low rates), or wall slip. Temperature-dependent data are typically fitted to the Arrhenius equation ln(η) = ln(A) + Ea/(RT) for simple liquids, or to the Vogel-Fulcher-Tammann equation η = η₀·exp(B/(T−T₀)) for glass-forming or strongly non-Arrhenius systems. For non-Newtonian fluids, the raw torque-speed data are converted to shear stress–shear rate curves using Krieger-Elrod wide-gap corrections when R₂/R₁ deviates significantly from unity, and fitted to power-law, Herschel-Bulkley, or Cross models as appropriate.",
          "how_it_operates": "The sample fluid is loaded into the annular gap (typically 1–2 mm wide) between two coaxial cylindrical surfaces. In the most common configuration, the outer cylinder (cup) is stationary and the inner cylinder (bob) rotates at a controlled angular velocity ω, although the inverse configuration (rotating cup, stationary bob with torque measurement) is also used. The rotating cylinder establishes a steady-state Couette flow in the gap, producing a shear stress that is transmitted through the fluid and registered as a reaction torque on the measuring element. A precision torque transducer measures this torque T, and the viscosity is calculated from the Margules equation: η = T·(1/R₁² − 1/R₂²)/(4πLω), where R₁ and R₂ are the inner and outer cylinder radii and L is the immersed cylinder length. Temperature is controlled via a Peltier element or circulating fluid jacket on the outer cylinder, allowing viscosity to be mapped as a function of temperature at defined shear rates.",
          "reporting_checklist": "Published concentric-cylinder viscometry results should report: inner and outer cylinder radii (R₁, R₂) and immersed length L, or identify the standard geometry used (DIN 53019, ISO 3219); bob/cup material; gap width and radius ratio R₂/R₁; controlled mode (controlled rate or controlled stress); shear rate(s) or angular velocity(ies) employed; temperature, its uncertainty, and the control method (Peltier, circulating bath); sample description and preparation (degassing, filtering); equilibration time and pre-shear protocol (if applicable); end-effect correction method applied; whether Taylor number was checked against the critical value; viscosity standard used for calibration and deviation from certified values; combined expanded uncertainty U(η) at 95% confidence (k = 2) with uncertainty budget identifying dominant sources; and for ThermoML encoding, viscosity values are reported with nCombExpandUncertValue at the 95% confidence level.",
          "sample_preparation": "The sample should be a homogeneous liquid free of air bubbles and particles larger than approximately one-third of the gap width (~0.3–0.7 mm). Degassing under mild vacuum or gentle stirring removes dissolved gases that might form bubbles during shearing. Suspensions should be filtered or verified to have maximum particle sizes compatible with the gap. The sample is loaded by pouring or pipetting into the cup with the bob raised, taking care to avoid introducing air. After the bob is lowered to the measuring position, any excess sample is trimmed from the top to match the correct fill level. For temperature-dependent measurements, the sample is equilibrated at the starting temperature for 5–15 minutes before data acquisition. For non-Newtonian fluids, a pre-shear protocol (e.g., 60 s at a defined shear rate followed by a rest period) establishes a reproducible initial microstructure.",
          "setup": "A typical concentric-cylinder viscometer consists of a precision-machined outer cup (stainless steel, aluminum, or specialty alloy) mounted in a temperature-controlled jacket, and an inner bob suspended from a low-friction air bearing or jeweled bearing that connects to a torque transducer and drive motor. The cup is filled with the sample liquid, and the bob is lowered into the fluid until the measurement zone is fully immersed. A solvent trap or evaporation cover caps the assembly to minimize sample loss. Research-grade rotational rheometers (e.g., Anton Paar MCR series, TA Instruments Discovery HR, Malvern Kinexus) use electronically controlled motors capable of both controlled-rate (imposed ω, measured T) and controlled-stress (imposed T, measured ω) operation. The instrument is mounted on a vibration-free surface and leveled to ensure concentricity.",
          "suitable_for": "Concentric cylinders viscometry is particularly well suited for low-to-moderate-viscosity liquids in the range 0.5–10,000 mPa·s, where cone-and-plate geometries may have difficulty containing the sample. It excels at measuring temperature-dependent viscosity of pure liquids, liquid mixtures, electrolyte solutions, and ionic liquids — the property types that dominate its ThermoML usage. The geometry is ideal for suspensions and emulsions because the sealed gap prevents particle sedimentation artifacts during measurement and accommodates larger particles than narrow cone-plate gaps. It is well suited for time-dependent measurements (thixotropy, rheopexy) because the enclosed gap maintains sample integrity during prolonged shearing. The wide shear-rate range supports both Newtonian characterization at a single rate and full flow-curve determination for non-Newtonian fluids.",
          "technique_overview": "Concentric cylinders viscometry (also known as Couette viscometry) is a rotational rheometric technique that determines the dynamic viscosity of a fluid by measuring the torque required to maintain steady rotation of one cylinder inside another, with the test fluid filling the annular gap between them. First systematically analyzed by Maurice Couette in 1890, the method remains one of the most widely used approaches for viscosity measurement because of its well-defined flow geometry, broad viscosity range (~0.5 mPa·s to >10⁶ mPa·s), and ability to characterize both Newtonian and non-Newtonian fluids. It is the dominant rotational viscometry technique in the NIST ThermoML database with 1082 instances across 231 papers, reflecting its central role in transport property measurements for pure liquids, mixtures, electrolyte solutions, and ionic liquids."
        },
        "structured_block": {
          "data_and_interpretation": {
            "analysis_methods": [
              "Margules equation: η = T(R₂² - R₁²)/(4πLωR₁²R₂²) for narrow-gap Couette flow with inner cylinder rotation",
              "Krieger-Elrod correction: wide-gap correction for non-Newtonian fluids iterating true shear rate at the bob wall",
              "Power-law or Herschel-Bulkley fit to flow curve (τ vs. γ̇) for non-Newtonian characterization",
              "Arrhenius fit: ln(η) = ln(A) + Ea/(RT) for temperature-dependent viscosity of simple liquids",
              "Vogel-Fulcher-Tammann (VFT) fit: η = η₀·exp(B/(T-T₀)) for glass-forming liquids",
              "Andrade equation fit for viscosity-temperature correlation"
            ],
            "common_artifacts": [
              "Taylor vortex artifact: onset of secondary flow above critical Taylor number causes apparent viscosity increase and non-linear torque-speed relationship",
              "end-effect artifact: additional torque from fluid below bob base leads to systematic overestimate of viscosity if uncorrected",
              "wall slip artifact: measured viscosity appears lower than true value; exhibits gap-width dependence",
              "viscous heating artifact: high shear rates generate heat faster than it dissipates, causing in-situ temperature rise and apparent shear-thinning in Newtonian fluids",
              "evaporation artifact: sample loss from open top of gap decreases effective wetted length, causing apparent viscosity drift over time",
              "air bubble artifact: trapped bubbles reduce effective fluid volume and cause erratic torque readings",
              "eccentricity artifact: misalignment of inner and outer cylinders creates non-uniform gap and systematic viscosity error"
            ],
            "failure_modes": [
              "loss of concentricity due to bearing wear or improper leveling (systematic viscosity error)",
              "torque transducer drift or saturation (erroneous viscosity readings)",
              "sample crystallization or gelation in the gap (sudden torque spike or instrument overload)",
              "motor speed instability at very low rpm (noisy shear-rate control)",
              "thermal runaway from viscous heating at high shear rates (uncontrolled temperature rise)",
              "bob detachment or coupling failure during high-torque measurements"
            ],
            "fit_parameters": [
              "dynamic viscosity η (for Newtonian fluids)",
              "power-law index n and consistency factor K (for power-law fluids: τ = K·γ̇ⁿ)",
              "yield stress τ₀ (for Bingham or Herschel-Bulkley fluids)",
              "Arrhenius activation energy Ea and pre-exponential factor A",
              "VFT parameters η₀, B, T₀ for glass-forming liquids"
            ],
            "model_assumptions": [
              "laminar Couette flow — no Taylor vortices, no turbulence (Reynolds number below critical value)",
              "incompressible fluid in the annular gap",
              "no-slip boundary condition at both cylinder surfaces",
              "isothermal conditions — negligible viscous heating in the gap during measurement",
              "steady-state flow — torque measurement taken after transient start-up flow has decayed",
              "cylindrical symmetry — perfect concentricity of inner and outer cylinders"
            ],
            "preprocessing_steps": [
              "zero-torque correction: subtract residual torque from bearing friction and air drag measured with empty instrument",
              "end-effect correction: account for torque contributions from fluid below the bob base and at the meniscus (Mooney-Ewart correction or guard-ring design)",
              "temperature equilibration verification: confirm that torque signal has reached steady state before recording",
              "inertia correction: subtract contributions from fluid and bob inertia during acceleration phases (relevant for transient measurements)",
              "wall slip check: compare results at two gap widths — if viscosity changes with gap, wall slip is present"
            ],
            "quality_control_checks": [
              "verify Newtonian response: plot η vs. shear rate — should be flat for Newtonian standard oils",
              "measure certified viscosity standard at a reference temperature and confirm agreement within stated accuracy",
              "compare results from two different gap widths to detect wall slip",
              "check for Taylor instability: look for abrupt change in torque-speed curve slope at high rotation rates",
              "repeat measurement after thermal cycling to confirm absence of sample degradation or bubble formation",
              "inspect bob and cup surfaces for scratches, deposits, or corrosion that alter gap geometry"
            ],
            "raw_signal_type": "torque (T) on the measuring cylinder as a function of angular velocity (ω) of the driving cylinder, recorded simultaneously with temperature"
          },
          "experimental_parameters": {
            "constraints": [
              {
                "hard_limits": "depends on cylinder material and sealing; specialized setups extend to 200 K (cryogenic) or 773 K (molten salts with ceramic/metal cylinders)",
                "notes": "standard instruments with Peltier or circulating bath temperature control cover 263–473 K",
                "parameter": "temperature_range",
                "typical_range": "253 K to 473 K"
              },
              {
                "hard_limits": "lower limit set by torque sensitivity; upper limit set by onset of Taylor vortices or turbulence in the gap",
                "notes": "Taylor number Ta = ω·R₁·d/ν (where d = gap width) must remain below critical value (~41 for narrow gaps) to ensure laminar Couette flow",
                "parameter": "shear_rate",
                "typical_range": "0.1 s⁻¹ to 10,000 s⁻¹"
              },
              {
                "hard_limits": "minimum ~0.5 mm (machining tolerance and alignment); maximum ~5 mm before curvature corrections become large",
                "notes": "narrow gaps (R₂/R₁ close to 1) simplify analysis by ensuring nearly uniform shear rate; DIN 53019 specifies R₂/R₁ = 1.0847",
                "parameter": "gap_width",
                "typical_range": "1 mm to 2 mm"
              },
              {
                "hard_limits": "pressurized variants operate up to 1 GPa with sealed high-pressure cells",
                "notes": "standard instruments operate at atmospheric pressure; high-pressure measurements require specialized sealed geometry",
                "parameter": "pressure",
                "typical_range": "0.1 MPa (ambient)"
              },
              {
                "hard_limits": "minimum detectable torque ~0.001 mN·m for air-bearing instruments; maximum limited by motor and transducer capacity",
                "notes": "torque range determines the accessible viscosity window for a given geometry",
                "parameter": "torque_range",
                "typical_range": "0.01 mN·m to 200 mN·m"
              }
            ],
            "variables": [
              {
                "effect": "directly sets the shear rate in the gap; γ̇ = 2ωR₂²/(R₂² - R₁²) for inner cylinder rotation; determines whether flow remains laminar",
                "name": "angular_velocity",
                "role": "primary controlled variable",
                "typical_values": "0.01 to 1000 rpm"
              },
              {
                "effect": "viscosity is strongly temperature-dependent; Arrhenius or VFT behavior; temperature must be controlled to ±0.01–0.1 K for accurate viscosity data",
                "name": "temperature",
                "role": "scanned or fixed variable",
                "typical_values": "273 K to 373 K"
              },
              {
                "effect": "defines the conversion factor between torque/angular velocity and viscosity; narrow gaps give more uniform shear rate",
                "name": "gap_geometry",
                "role": "fixed instrument parameter",
                "typical_values": "R₁ = 12–14 mm, R₂ = 14–15 mm (DIN standard); cylinder length L = 30–50 mm"
              },
              {
                "effect": "must be sufficient to fill the annular gap completely and cover the immersed cylinder length; overfilling or underfilling introduces end-effect errors",
                "name": "sample_volume",
                "role": "dependent on geometry",
                "typical_values": "2 mL to 30 mL"
              }
            ]
          },
          "measurement_scope": {
            "derived_observables": [
              "dynamic viscosity (η)",
              "shear stress (τ)",
              "shear rate (γ̇)",
              "kinematic viscosity (ν = η/ρ, when density is known)",
              "apparent viscosity as a function of shear rate (for non-Newtonian fluids)"
            ],
            "direct_observables": [
              "torque on stationary cylinder (T)",
              "angular velocity of rotating cylinder (ω)",
              "temperature of fluid in annular gap (T_fluid)"
            ],
            "phases_measured": [
              "liquid (Newtonian)",
              "liquid (non-Newtonian: shear-thinning, shear-thickening)",
              "liquid mixtures and solutions",
              "colloidal suspensions",
              "emulsions",
              "polymer solutions and melts"
            ],
            "supported_sample_types": [
              "pure liquids",
              "binary and multicomponent liquid mixtures",
              "electrolyte solutions",
              "ionic liquids",
              "polymer solutions",
              "polymer melts",
              "colloidal suspensions and slurries",
              "emulsions",
              "oils and lubricants",
              "molten salts",
              "biological fluids (blood, protein solutions)"
            ],
            "target_properties": [
              "dynamic viscosity (η)",
              "kinematic viscosity (ν)",
              "viscosity as a function of temperature",
              "viscosity as a function of shear rate (flow curve)",
              "viscosity as a function of pressure (with pressurized variants)",
              "activation energy of viscous flow (from η vs. T data)"
            ],
            "typical_output_formats": [
              "η vs. T curve at fixed shear rate",
              "η vs. shear rate (flow curve) at fixed T",
              "torque vs. angular velocity (raw rheogram)",
              "shear stress vs. shear rate plot",
              "Arrhenius plot: ln(η) vs. 1/T"
            ],
            "units": {
              "angular_velocity": "rad/s or rpm",
              "dynamic_viscosity": "Pa·s or mPa·s",
              "kinematic_viscosity": "mm²/s (cSt)",
              "shear_rate": "s⁻¹",
              "shear_stress": "Pa",
              "temperature": "K",
              "torque": "N·m or mN·m"
            },
            "unsupported_sample_types": [
              "gases (torque signal too small for reliable measurement)",
              "extremely low-viscosity fluids below ~0.3 mPa·s (approaches instrument sensitivity limit)",
              "solids and gels with yield stress exceeding instrument torque range",
              "highly volatile liquids that evaporate from the open gap",
              "samples containing large particles (>1/3 of gap width) that jam in the annular gap",
              "strongly corrosive fluids without chemically resistant cylinder materials"
            ]
          },
          "performance": {
            "accuracy": "1–3% for Newtonian fluids after full calibration and end-effect correction; 3–5% for non-Newtonian fluids due to additional shear-rate non-uniformity corrections",
            "detection_limit": "lower viscosity limit ~0.3–0.5 mPa·s constrained by ambient torque noise and bearing friction; upper limit >10⁶ mPa·s limited by maximum torque",
            "dynamic_range": "viscosity range approximately 0.5 mPa·s to >10⁶ mPa·s using interchangeable cylinder sets; ~4 decades with a single geometry",
            "measurement_speed": "steady-state viscosity determination at a single temperature/shear-rate point requires 30 s to 5 min depending on equilibration",
            "precision": "0.5–1% repeatability for Newtonian fluids at a given temperature and shear rate",
            "resolution": {
              "energy": "not applicable",
              "spatial": "not applicable (bulk measurement of annular gap volume)",
              "spectral": "not applicable",
              "temporal": "transient torque response captured at 1–1000 Hz sampling rates depending on data acquisition system"
            },
            "sensitivity": "minimum measurable viscosity ~0.5 mPa·s with narrow-gap geometries and air-bearing instruments; torque sensitivity ~0.001 mN·m for research-grade rheometers",
            "throughput": "single sample per measurement; 5–30 minutes per viscosity-temperature curve depending on number of points and equilibration time"
          },
          "setup_and_requirements": {
            "calibration_requirements": [
              "viscosity standard calibration using certified reference oils (e.g., Cannon N-series or PTB/NIST standard oils) spanning the measurement range",
              "torque calibration using a known weight suspended from the bob on a calibrated arm",
              "angular velocity verification using a tachometer or frequency counter on the motor encoder",
              "temperature sensor calibration against a traceable reference thermometer or at fixed points (ice point, Ga melting)",
              "gap geometry verification — measure R₁, R₂, and L with calibrated micrometer; confirm concentricity"
            ],
            "consumables": [
              "cleaning solvents (acetone, ethanol, or petroleum ether) for cylinder surface preparation",
              "lint-free wipes for drying cylinders",
              "viscosity standard oils for periodic recalibration",
              "solvent trap inserts or covers for volatile samples",
              "disposable cylinder inserts or liners (for corrosive or difficult-to-clean samples)"
            ],
            "environmental_requirements": [
              "vibration-free bench or anti-vibration table to prevent flow disturbances in the gap",
              "stable ambient temperature (±2 K) to reduce thermal drift in electronics and bearing friction",
              "level instrument installation — cylinder concentricity depends on proper leveling",
              "draft-free environment or enclosure to prevent convective cooling of the sample"
            ],
            "instrument_components": [
              "outer cylinder (cup) — precision-machined metal (stainless steel, aluminum, or titanium) or glass cylinder that serves as the sample container",
              "inner cylinder (bob) — coaxial rotating or stationary cylinder, precisely centered in the cup",
              "drive motor — DC servo or electronically commutated (EC) motor providing controlled angular velocity or controlled torque",
              "torque transducer — strain gauge, capacitive, or optical sensor measuring the reaction torque on the measuring cylinder",
              "air bearing or jewel bearing — low-friction support for the inner cylinder spindle to minimize parasitic torque",
              "temperature control system — Peltier element, circulating fluid jacket, or electrical heating mantle surrounding the outer cylinder",
              "temperature sensor — Pt100 RTD or thermocouple positioned in the outer cylinder wall or in the fluid gap",
              "solvent trap or evaporation cover — cap or shield to minimize evaporation from the open top of the annular gap",
              "data acquisition and control software — controls motor speed/torque, records torque, speed, and temperature in real time"
            ],
            "reference_materials": [
              "NIST Standard Reference Materials: SRM 2490 (polyisobutylene in 2,6,10,14-tetramethylpentadecane, ~900 Pa·s at 25°C)",
              "NIST SRM 2492 (Bingham paste standard for yield stress calibration)",
              "Cannon Instrument Company certified viscosity standards (S3 to S60000 series covering 1 to 100,000 mPa·s)",
              "PTB (Germany) certified viscosity reference oils",
              "deionized water (0.890 mPa·s at 25°C — useful low-viscosity check)"
            ],
            "safety_notes": [
              "rotating cylinder creates pinch hazard — keep fingers and loose clothing away from the gap during operation",
              "hot outer cylinder jacket (above 373 K) requires burn protection",
              "volatile or toxic solvents require fume extraction and appropriate PPE",
              "high-viscosity samples at high shear rates can generate significant viscous heating — monitor temperature for runaway"
            ],
            "sample_requirements": {
              "geometry": [
                "liquid sample that flows freely to fill the annular gap uniformly"
              ],
              "mounting_requirements": [
                "sample loaded into the outer cup with the inner bob raised, then bob lowered into sample",
                "ensure no air bubbles are trapped in the annular gap (visible inspection or pre-shearing)",
                "correct fill level: sample meniscus should be at the top of the bob measurement zone"
              ],
              "preparation_requirements": [
                "degas sample if dissolved gases cause bubble formation during shearing",
                "filter sample to remove particles larger than 1/3 gap width",
                "equilibrate sample temperature before measurement or use instrument temperature control with adequate soak time",
                "for non-Newtonian fluids, apply defined pre-shear protocol to establish reproducible starting microstructure"
              ],
              "size_limits": "typically 2–30 mL depending on cylinder dimensions; DIN standard geometries require ~20 mL",
              "surface_requirements": [
                "no wall slip — if sample slips at cylinder surfaces, surface roughening or serrated cylinders may be required",
                "wetting: sample must wet both cylinder surfaces to transmit shear stress without slip layers"
              ],
              "thickness_limits": "not applicable — sample fills the annular gap (1–2 mm width) defined by the cylinder geometry"
            }
          },
          "uncertainty": {
            "dominant_error_sources": [
              "temperature measurement and control uncertainty (viscosity has exponential T-dependence)",
              "end-effect correction accuracy",
              "gap geometry dimensional uncertainty (especially for narrow gaps where small absolute errors are large relative errors)"
            ],
            "level": "typical combined standard uncertainty 1–3% for Newtonian fluids; 3–5% for non-Newtonian fluids due to shear-rate non-uniformity",
            "model_dependence": "low for Newtonian fluids measured in narrow-gap geometry (Margules equation is exact for ideal Couette flow); moderate to high for non-Newtonian fluids requiring shear-rate correction models",
            "operator_dependence": "moderate — sample loading technique (avoiding bubbles), fill level, cleaning procedures, and temperature equilibration discipline significantly affect results",
            "random_sources": [
              "torque transducer noise and drift",
              "temperature fluctuations in the sample (±0.01–0.1 K translates to 0.1–2% viscosity variation for typical dη/dT)",
              "angular velocity fluctuations from motor controller",
              "mechanical vibrations transmitted to the instrument",
              "sample surface disturbances from meniscus instability or evaporation"
            ],
            "reported_as": [
              "combined expanded uncertainty U(η) at 95% confidence (k=2)",
              "relative uncertainty as percentage of η",
              "standard deviation from repeated measurements at fixed conditions"
            ],
            "systematic_sources": [
              "end-effect correction uncertainty (contributes 0.5–2% depending on geometry and correction method)",
              "gap geometry dimensional tolerances (radii and length, typically ±5–10 µm machining tolerance)",
              "eccentricity of inner and outer cylinders",
              "temperature calibration offset (systematic shift in reported viscosity at the wrong T)",
              "viscous heating not fully corrected (especially at high shear rates)",
              "wall slip (undetected slip gives systematically low viscosity)",
              "sample density uncertainty when converting to kinematic viscosity",
              "torque transducer calibration uncertainty"
            ],
            "thermoml_encoding": "nCombExpandUncertValue at 95% confidence level"
          }
        }
      },
      "identity": {
        "acronym": "",
        "aliases": [],
        "canonical_method_name": "Concentric cylinders viscometry",
        "db_usage": {
          "instance_count": 1082,
          "n_papers": 231,
          "per_group": {
            "TransportProp": {
              "instances": 1082,
              "papers": 231
            }
          },
          "property_groups": [
            "TransportProp"
          ]
        },
        "measurement_family": "Viscometry",
        "modality": {
          "contact": "yes",
          "destructive": "no",
          "imaging": "no",
          "in_situ": "no"
        },
        "name": "Concentric cylinders viscometry",
        "source_aliases": [
          {
            "method_type": "standard",
            "name": "Concentric cylinders viscometry"
          }
        ],
        "thermoml_custom_codes": [
          "CONCYL"
        ],
        "thermoml_standard_name": "Concentric cylinders viscometry"
      },
      "match_score": 100,
      "match_type": "source_alias_exact",
      "meas_ID": "concentric_cylinders_viscometry",
      "meas_id": "concentric_cylinders_viscometry",
      "meas_num_id": "GLOBmeas_11"
    },
    {
      "card_type": "standard_dk",
      "compact_md": "# MTDKS-DK | moving_piston_method | GLOBmeas_69\n\n**Name:** Moving piston method\n**Family:** Viscometry\n**ThermoML std:** Moving piston method\n**Modality:** contact=yes, destructive=no, in_situ=no, imaging=no\n**Usage:** 55 instances | 15 papers | groups=TransportProp\n**Per-group:** TransportProp: 55 inst/15 papers\n\n## Structured Knowledge\n\n### measurement_scope\n**direct_observables:**\n- piston travel time between two detection points (t)\n- temperature of thermostated pressure vessel (T)\n- applied pressure on fluid (P)\n- piston position signal from magnetic or optical sensors\n**derived_observables:**\n- dynamic viscosity (η)\n- kinematic viscosity (ν = η/ρ, when density is known or measured concurrently)\n- viscosity–temperature coefficient\n- viscosity–pressure coefficient\n**target_properties:**\n- dynamic viscosity (η)\n- kinematic viscosity (ν)\n- viscosity as a function of temperature at constant pressure\n- viscosity as a function of pressure at constant temperature\n**phases_measured:**\n- liquid (Newtonian)\n- liquid (mildly non-Newtonian at low shear rates)\n- compressed liquid at elevated pressures\n**supported_sample_types:**\n- pure liquids\n- binary and multicomponent liquid mixtures\n- petroleum fluids and crude oils\n- lubricants and hydraulic fluids\n- ionic liquids\n- refrigerants and compressed gases in liquid phase\n- polymer solutions (dilute to moderately concentrated)\n- high-viscosity fluids (heavy oils, bitumen)\n**unsupported_sample_types:**\n- gases at low pressure (insufficient drag on piston)\n- highly abrasive slurries or suspensions containing large particles (damage to piston/cylinder surfaces)\n- fluids that chemically attack the piston or cylinder material\n- viscoelastic fluids with strong elastic recovery (piston rebound artifacts)\n- two-phase or foaming fluids (undefined viscosity regime)\n**typical_output_formats:**\n- η vs. T at constant P\n- η vs. P at constant T\n- log η vs. 1/T (Arrhenius plot)\n- η vs. composition at constant T and P\n- tabulated (T, P, η) data\n**units:**\n- dynamic_viscosity: mPa·s (= cP) or Pa·s\n- kinematic_viscosity: mm²/s (= cSt)\n- temperature: K\n- pressure: MPa\n- piston_travel_time: s\n- density: kg/m³\n\n### experimental_parameters\n**constraints:**\n- **temperature_range** — typical: 233 K to 473 K — limits: limited by seal materials and thermostating fluid; specialized cells extend to 523 K — notes: low-temperature limit set by sample freezing or seal embrittlement; high-temperature limit by O-ring and seal degradation\n- **pressure_range** — typical: 0.1 MPa to 200 MPa — limits: maximum set by pressure vessel rating and seal integrity; some designs rated to 300 MPa — notes: a key advantage of this technique is robust high-pressure capability\n- **viscosity_range** — typical: 0.2 mPa·s to 10,000 Pa·s — limits: lower limit set by minimum measurable travel time at maximum piston velocity; upper limit by practical measurement duration — notes: range covered by selecting different piston densities and cylinder bore diameters; multiple piston sets extend overall range\n- **sample_volume** — typical: 2 mL to 10 mL — limits: must completely fill the measurement cylinder with no trapped gas — notes: compressed-liquid measurements require careful degassing and filling under pressure\n**variables:**\n- **temperature** — typical: 273 K to 423 K — effect: viscosity decreases exponentially with increasing temperature for most liquids; temperature must be controlled to ±0.01 K for high-accuracy work\n- **pressure** — typical: 0.1 MPa to 200 MPa — effect: viscosity generally increases with pressure; pressure–viscosity coefficient is a key derived quantity for lubricant characterization\n- **piston_type** — typical: selection of piston density and diameter for target viscosity range — effect: heavier or larger-diameter pistons generate greater force, suitable for low-viscosity fluids; lighter pistons with tighter clearance for high-viscosity fluids\n- **applied_force_mode** — typical: gravity, electromagnetic, or pneumatic drive — effect: determines the shear rate regime and suitability for different viscosity ranges; electromagnetic actuation enables automated cycling\n\n### setup_and_requirements\n**instrument_components:**\n- precision-bore measurement cylinder — tight-tolerance bore (typical diameters 5–15 mm) made of stainless steel, Hastelloy, or sapphire for chemical resistance\n- calibrated piston — precision-ground cylinder (various densities and diameters) whose dimensions define the annular gap with the bore\n- position detection system — two magnetic proximity sensors, optical sensors, or inductive coils defining a fixed travel distance (typically 10–50 mm)\n- thermostated pressure vessel — jacketed cell with circulating fluid thermostat for temperature control (stability ±0.01 K)\n- pressure generation and measurement system — hand pump or syringe pump with calibrated pressure transducer (accuracy ±0.05 MPa)\n- timing circuit — high-resolution electronic timer triggered by position sensors (resolution ±0.001 s)\n- temperature measurement — calibrated PRT (Pt100) or thermistor embedded in cell wall near measurement zone\n- electromagnetic or pneumatic actuator — returns piston to starting position and controls drive force in non-gravity designs (e.g., Cambridge Viscosity SPL series)\n- data acquisition and control system — computer interface for automated measurement cycles, data logging, and temperature/pressure programming\n**environmental_requirements:**\n- temperature-controlled laboratory (±2 K ambient) to minimize thermal gradients in tubing and connections\n- vibration-free bench or mounting to prevent disturbing piston free-fall\n- pressure-rated fittings and burst containment for high-pressure operation\n- fume hood or ventilation when using volatile or toxic sample fluids\n**sample_requirements:**\n- geometry: ['liquid sample filling the cylindrical bore completely with no gas bubbles']\n- size_limits: 2–10 mL depending on cylinder volume; sufficient to fill cylinder and connecting tubing\n- thickness_limits: not applicable (annular gap between piston and cylinder wall is the critical dimension, typically 10–200 µm)\n- surface_requirements: ['sample must be free of suspended particles large enough to jam in the piston–cylinder annular gap', 'sample should be homogeneous and single-phase under measurement conditions']\n- mounting_requirements: ['cylinder oriented vertically for gravity-driven designs, or in any orientation for magnetically/pneumatically driven designs', 'leak-free sealing of pressure vessel at all operating pressures']\n- preparation_requirements: ['thorough degassing under vacuum or by helium sparging to eliminate dissolved gas that may form bubbles under changing pressure', 'filtration through 0.5–5 µm filter to remove particulates that could score piston or cylinder surfaces', 'drying over molecular sieves for moisture-sensitive fluids', 'density measurement of sample (if kinematic viscosity is required) using vibrating-tube densimeter or pycnometer']\n**calibration_requirements:**\n- calibration with certified viscosity reference standards (e.g., Cannon S-series, PTB oils) spanning the target viscosity range to establish instrument constant K relating travel time to viscosity: η = K·(ρ_piston − ρ_fluid)·t\n- temperature calibration of embedded PRT against ITS-90 fixed points or a NIST-traceable reference thermometer\n- pressure transducer calibration against a deadweight tester or NIST-traceable reference pressure gauge\n- verification of piston and cylinder dimensions using coordinate measuring machine (CMM) at periodic intervals\n- repeatability check: multiple consecutive measurements of a reference fluid must agree within stated precision\n**reference_materials:**\n- NIST SRM 2490 — polyisobutylene solution in 2,6,10,14-tetramethylpentadecane (high viscosity standard)\n- Cannon certified viscosity reference standards (N-series, S-series) — available across 0.3 to 100,000 mm²/s range\n- NIST SRM 2492 — Bingham paste standard (for non-Newtonian verification, if applicable)\n- toluene — low-viscosity reference with well-characterized η(T,P) data from literature\n- diethylhexyl sebacate (DEHS) — intermediate-viscosity reference for high-pressure calibration\n**consumables:**\n- high-pressure O-rings and seals (Viton, Kalrez, or PTFE) rated to maximum operating pressure\n- replacement pistons of various materials and dimensions for different viscosity ranges\n- calibration reference oils (consumed during calibration runs)\n- cleaning solvents (acetone, toluene, n-hexane) for flushing between samples\n- filtration membranes (0.5–5 µm pore size)\n**safety_notes:**\n- high-pressure systems require pressure-rated enclosures and burst discs; never exceed rated pressure\n- use proper PPE (eye protection, face shields) when handling pressurized fluids\n- ensure proper ventilation when working with volatile or toxic solvents for cleaning or as samples\n- heavy pistons and pressure vessels should be handled with care to avoid injury from dropped components\n\n### performance\n**sensitivity:** capable of resolving viscosity differences of ~0.1% between consecutive measurements for well-conditioned piston/cylinder assemblies\n**detection_limit:** minimum measurable viscosity ~0.2 mPa·s (limited by piston inertia and minimum resolvable travel time)\n**resolution:**\n- spatial: not applicable (bulk fluid measurement)\n- temporal: measurement cycle time 10 s to 300 s per data point depending on viscosity; automated cycling enables repeated measurements every 30–120 s\n- spectral: not applicable\n- energy: not applicable\n**dynamic_range:** approximately five decades: 0.2 mPa·s to ~10,000 Pa·s achievable through piston selection\n**accuracy:** 1–2% of measured value with proper calibration; 0.5% achievable for mid-range viscosities with careful calibration and temperature control\n**precision:** 0.2–0.5% (repeatability of travel time measurement at stabilized T and P)\n**throughput:** single sample; one T-sweep or P-sweep typically requires 2–6 hours depending on number of state points and equilibration time\n**measurement_speed:** individual measurement: 10–300 s per piston fall cycle; automated instruments average 3–5 cycles per state point for statistical averaging\n\n### data_and_interpretation\n**raw_signal_type:** electrical pulses from position detectors marking the start and end of piston travel through a fixed distance, yielding travel time t; plus analog signals from PRT (temperature) and pressure transducer\n**preprocessing_steps:**\n- averaging of multiple travel time measurements (typically 3–5 cycles) at each (T, P) state point to improve precision\n- correction for piston acceleration zone at start of travel (only the steady-state region between detection points is used)\n- correction for fluid buoyancy on the piston: effective driving force = (ρ_piston − ρ_fluid)·V_piston·g\n- temperature and pressure corrections applied to instrument constant K for thermal expansion of piston and cylinder\n- end-effect corrections for finite cylinder length (if piston approaches cylinder ends during measurement)\n**analysis_methods:**\n- primary equation: η = K·(ρ_piston − ρ_fluid)·t, where K is the instrument constant determined by calibration\n- alternative Stokes-flow derivation for annular geometry: η = (ρ_piston − ρ_fluid)·g·R_p²·t / (2L·f(R_p/R_c)), where f is a geometric factor depending on piston-to-cylinder radius ratio\n- Arrhenius or Vogel-Fulcher-Tammann (VFT) fitting: ln η = A + B/(T − T₀) for viscosity–temperature correlation\n- Barus equation fitting: η = η₀·exp(α·P) for viscosity–pressure dependence at constant T\n- linear or polynomial interpolation of η(T,P) tables for generating smoothed viscosity surfaces\n**model_assumptions:**\n- fully developed laminar (Stokes) flow in the piston–cylinder annular gap (Reynolds number << 1)\n- the fluid is Newtonian (shear stress proportional to shear rate) over the prevailing shear rate range in the annular gap\n- piston reaches terminal (constant) velocity within the detection zone — no acceleration transient contaminates the timing\n- the annular gap is concentric and uniform along the piston length (no eccentricity)\n- fluid density and piston density are constant (or corrected for) over the measurement temperature and pressure range\n- no wall slip at the piston or cylinder surfaces\n**fit_parameters:**\n- instrument constant K (determined from calibration)\n- dynamic viscosity η at each (T, P) state point\n- Arrhenius parameters A and Ea (activation energy) for η(T) modeling\n- VFT parameters A, B, T₀ for η(T) modeling\n- Barus coefficient α for η(P) modeling\n**common_artifacts:**\n- piston eccentricity artifact: if the piston is not centered in the bore, annular flow is non-uniform and measured viscosity deviates (typically lower than true value due to wider gap on one side)\n- inertia artifact at low viscosity: piston accelerates through the detection zone rather than reaching terminal velocity, producing anomalously short travel times\n- thermal gradient artifact: incomplete thermal equilibration of sample in the cylinder creates a viscosity gradient along the piston path, distorting the measurement\n- dissolved gas artifact: gas coming out of solution during pressure reduction creates bubbles that alter effective fluid density and flow resistance\n- surface scoring artifact: scratched piston or cylinder surfaces change the effective gap geometry, causing progressive drift in calibration constant\n**quality_control_checks:**\n- measure a certified viscosity reference standard at each temperature and pressure before and after sample runs to verify instrument constant stability\n- verify piston terminal velocity by comparing travel times for different detection zone lengths (if available) or from multiple consecutive runs\n- check that multiple piston fall/rise cycles yield consistent travel times (CV < 0.5%)\n- compare heating and cooling sweeps at the same state points to detect hysteresis or thermal lag\n- inspect piston and cylinder for visible scoring or wear at regular intervals; replace if tolerances are exceeded\n**failure_modes:**\n- piston jamming due to particulate contamination or sample solidification in the annular gap\n- seal failure at high pressure resulting in sample leak and pressure loss\n- loss of position sensor signal due to sensor malfunction or electromagnetic interference\n- cylinder bore contamination from sample residue causing progressive bias in travel time\n- piston corrosion or chemical attack from aggressive sample fluids changing piston dimensions and density\n\n### uncertainty\n**level:** typical combined standard uncertainty 1–2% for dynamic viscosity; can be reduced to 0.5% with meticulous calibration and mid-range viscosity values\n**random_sources:**\n- variability in piston travel time from run to run (fluid turbulence at lower viscosities)\n- short-term temperature fluctuations within the measurement cell\n- pressure fluctuations from pump pulsation or thermal volume changes\n- electronic noise in position sensor and timer circuits\n- vibration-induced disturbances to piston motion\n**systematic_sources:**\n- uncertainty in the calibration constant K (propagated from reference standard certification uncertainty)\n- piston and cylinder dimensional tolerances (bore diameter, piston diameter, roundness, cylindricity)\n- piston eccentricity within the bore (non-uniform annular gap)\n- thermal expansion corrections for piston and cylinder at temperatures far from calibration temperature\n- fluid density uncertainty (when converting to kinematic viscosity or computing buoyancy correction)\n- temperature measurement offset between PRT location and actual fluid temperature at the piston\n- pressure measurement calibration offset\n- end effects and piston acceleration corrections\n**operator_dependence:** low to moderate — filling procedure (gas-free loading), cleaning quality, and sample filtration depend on operator care; less operator-dependent than capillary viscometry due to automated piston cycling\n**model_dependence:** moderate — accuracy depends on validity of Stokes flow assumption, concentricity of piston, and Newtonian behavior of sample; deviations from any of these require empirical corrections or alternative analysis\n**dominant_error_sources:**\n- calibration constant uncertainty (especially when extrapolating far from the viscosity range of the reference standards)\n- temperature measurement and control (viscosity changes 2–5% per kelvin for typical liquids)\n- piston–cylinder dimensional stability and concentricity\n**reported_as:**\n- combined expanded uncertainty U(η) at 95% confidence (k=2)\n- relative expanded uncertainty as percentage of η\n- standard deviation from replicate piston travel time measurements\n**thermoml_encoding:** nCombExpandUncertValue at 95% confidence level\n\n## Description\n\n### technique_overview\nThe moving piston method is a viscometry technique that determines the dynamic viscosity of a fluid by measuring the time required for a precision-machined piston to travel a fixed distance through a close-fitting cylinder filled with the sample fluid under a controlled driving force. Also known as the falling-piston or rising-piston viscometer, the technique is based on the Stokes drag principle adapted to cylindrical annular geometry. Commercial implementations include the Cambridge Viscosity SPL series, which uses electromagnetic actuation to cycle the piston back and forth, enabling automated, repeated measurements. The method is especially valued for high-pressure viscosity measurements (up to 200–300 MPa) and covers an exceptionally wide viscosity range from 0.2 mPa·s to over 10,000 Pa·s through selection of different piston sizes and densities.\n\n### how_it_operates\nA cylindrical piston of known density and precise dimensions is placed inside a close-fitting measurement cylinder filled with the sample fluid. A controlled driving force — gravity in falling-piston designs, or electromagnetic/pneumatic actuation in automated instruments — causes the piston to move through the fluid at a velocity determined by the balance between the driving force and the viscous drag in the narrow annular gap between the piston and cylinder wall. Two position sensors (magnetic, optical, or inductive) placed at a fixed separation along the cylinder detect the piston's passage and trigger a high-resolution timer. The measured travel time is directly proportional to the fluid viscosity through a calibration constant that encapsulates the piston and cylinder geometry, piston density, and driving force. Temperature and pressure are measured simultaneously by sensors embedded in or adjacent to the thermostated pressure vessel. Automated instruments cycle the piston back and forth using an electromagnetic coil, collecting multiple travel times per measurement for statistical averaging.\n\n### core_theory\nThe measurement is based on Stokes flow (creeping flow) in a cylindrical annular geometry. When a cylindrical piston of radius R_p and length L falls under gravity through a cylinder of radius R_c filled with a Newtonian fluid, it reaches a terminal velocity where the gravitational force minus buoyancy equals the viscous drag. For the annular geometry, the dynamic viscosity is given by η = (ρ_piston − ρ_fluid)·g·R_p²·t / (2L·f(κ)), where κ = R_p/R_c is the radius ratio and f(κ) is a geometric factor derived from the exact solution of the Navier-Stokes equations for concentric cylinder Poiseuille-Couette flow. In practice, this is simplified to η = K·Δρ·t, where K is an instrument constant determined empirically by calibration with fluids of known viscosity, Δρ is the difference between piston and fluid densities, and t is the measured travel time. The validity requires that the Reynolds number based on piston velocity and annular gap width is much less than unity (Re << 1), ensuring the flow is purely viscous with no inertial effects.\n\n### setup\nA typical moving-piston viscometer consists of a precision-bore cylinder (stainless steel, Hastelloy, or sapphire, bore diameter 5–15 mm) housed inside a thermostated high-pressure vessel rated to 200–300 MPa. A precision-ground piston (various materials: tungsten carbide, stainless steel, aluminum — selected for appropriate density contrast with the sample) sits inside the cylinder. Two position sensors spaced 10–50 mm apart detect the piston magnetically or optically and trigger a high-resolution timer with ±0.001 s resolution. The pressure vessel is jacketed and connected to a circulating thermostat bath providing temperature stability to ±0.01 K. A calibrated PRT mounted in the vessel wall monitors temperature, while a calibrated pressure transducer measures the fluid pressure. In automated instruments (e.g., Cambridge Viscosity SPL), an electromagnetic coil at one end of the cylinder drives the piston back to its starting position after each fall, enabling continuous automated cycling. A computer-controlled data acquisition system records travel times, temperature, and pressure, and computes viscosity in real time.\n\n### suitable_for\nThe moving piston method is particularly well-suited for viscosity measurements at elevated pressures, making it a workhorse for petroleum fluid characterization, lubricant evaluation, and compressed-liquid studies for equation-of-state development. It handles a remarkably wide viscosity range (0.2 mPa·s to 10,000 Pa·s) through piston selection, accommodating everything from light solvents to heavy crude oils. The compact, sealed-cell design enables measurements on small sample volumes (2–10 mL), which is advantageous for expensive or scarce fluids. The technique is well-suited for Newtonian fluids and mildly non-Newtonian fluids at the low shear rates prevailing in the annular gap. It is widely used for ionic liquids, refrigerants, deep eutectic solvents, and hydrocarbon mixtures at reservoir conditions.\n\n### core_limitations\nThe fundamental assumption of Newtonian Stokes flow limits the technique to Newtonian or near-Newtonian fluids — highly non-Newtonian, viscoelastic, or thixotropic fluids produce shear-rate-dependent results that do not represent a unique viscosity value. The shear rate in the annular gap is not precisely controlled or uniform, making it unsuitable for rheological characterization requiring defined shear rates. Piston eccentricity (off-center positioning) within the bore introduces systematic errors that are difficult to detect and correct. For very low-viscosity fluids (< 0.2 mPa·s), the piston may not reach terminal velocity within the detection zone due to inertial effects, degrading accuracy. The technique requires knowledge of the fluid density (or the density difference between piston and fluid) for absolute viscosity determination, introducing an additional uncertainty source. Sample fluids containing abrasive particles can damage the precision surfaces of the piston and cylinder, requiring frequent inspection and replacement.\n\n### sample_preparation\nSample fluids must be thoroughly degassed before loading into the measurement cell, as dissolved gases can nucleate into bubbles under pressure changes, disrupting piston motion and altering effective fluid density. Degassing is performed under vacuum or by helium sparging. The sample should be filtered through a membrane filter (0.5–5 µm pore size) to remove particulates that could jam in the narrow annular gap between piston and cylinder. For hygroscopic or moisture-sensitive fluids (e.g., ionic liquids), the sample should be dried over molecular sieves and handled under inert atmosphere. The cell and all wetted components must be thoroughly cleaned with appropriate solvents (acetone, toluene, or n-hexane depending on sample compatibility) and dried between measurements. If kinematic viscosity is the target, the sample density must be independently measured at the same temperature and pressure conditions using a vibrating-tube densimeter or other suitable method. Sample volume of 2–10 mL is typically required, and the fluid must completely fill the cylinder with no trapped air.\n\n### calibration_and_references\nCalibration establishes the instrument constant K by measuring the travel time for certified viscosity reference standards (e.g., Cannon N-series or S-series oils) of known viscosity at precisely controlled temperatures. The calibration equation η = K·Δρ·t is solved for K using multiple reference fluids spanning the target viscosity range, ideally bracketing the expected sample viscosity. Temperature calibration is performed by comparing the embedded PRT reading against an ITS-90 traceable reference thermometer. The pressure transducer is calibrated against a deadweight piston gauge or NIST-traceable reference. Calibration must be verified at regular intervals and after any disassembly or piston/cylinder replacement. Recommended reference materials include Cannon certified viscosity standards (covering 0.3 to 100,000 mm²/s), toluene (well-characterized low-viscosity standard with extensive η(T,P) literature data), DEHS (intermediate viscosity for high-pressure work), and NIST SRM 2490 (polyisobutylene solution for high-viscosity verification). Piston and cylinder dimensions should be verified periodically by coordinate measuring machine (CMM).\n\n### data_interpretation\nThe primary data reduction is straightforward: the measured travel time t at each (T, P) state point, combined with the calibration constant K and the piston–fluid density difference Δρ = ρ_piston − ρ_fluid, yields the dynamic viscosity η = K·Δρ·t. Multiple travel time measurements (3–5 piston cycles) are averaged to provide a mean viscosity and standard deviation at each state point. The buoyancy correction requires the fluid density at measurement conditions; this is either measured independently or estimated from an equation of state. Viscosity–temperature data are typically correlated using the Arrhenius equation (ln η = A + E_a/RT) for limited temperature ranges, or the Vogel-Fulcher-Tammann (VFT) equation (ln η = A + B/(T − T₀)) for wider ranges. Viscosity–pressure data are correlated using the Barus equation (η = η₀·exp(α·P)) or more sophisticated models such as the modified Tait–Doolittle equation for strongly nonlinear pressure dependence. For comprehensive (T, P) coverage, multiparameter correlations or interpolation surfaces are constructed.\n\n### common_pitfalls\nThe most critical pitfall is incomplete degassing of the sample, which leads to bubble formation in the measurement cylinder — particularly during pressure reduction steps — causing erratic travel times and large scatter. Failure to filter samples adequately allows particulates to accumulate in the annular gap, gradually increasing travel times and eventually jamming the piston. Neglecting to correct for thermal expansion of piston and cylinder dimensions at temperatures far from the calibration temperature introduces a systematic bias that grows with temperature offset. Using a single calibration point (one reference fluid) rather than a multi-point calibration spanning the measurement range can lead to nonlinearity errors, as the instrument constant K may have a weak viscosity dependence due to end effects and piston acceleration. Conducting measurements before thermal equilibration is achieved produces biased viscosity values because viscosity is highly temperature-sensitive (2–5% per kelvin for typical liquids). Ignoring piston eccentricity — which arises from wear, manufacturing tolerances, or improper orientation — leads to systematically low viscosity readings.\n\n### artifacts_and_failure_modes\nPiston eccentricity artifacts cause the measured viscosity to be lower than the true value because the wider side of the non-concentric annular gap carries disproportionately more flow, reducing the overall drag on the piston. Inertia artifacts at low viscosities result from the piston not reaching terminal velocity within the detection zone, producing travel times shorter than expected and anomalously low apparent viscosity. Thermal gradient artifacts arise when the sample fluid in the cylinder is not thermally homogeneous, creating a viscosity gradient along the piston path that biases the average travel time. Dissolved gas artifacts manifest as bubble formation during depressurization, causing sudden erratic readings. Surface scoring of the piston or cylinder from abrasive samples or handling damage progressively alters the effective gap geometry, causing calibration drift. Seal failure at high pressure is the most consequential hardware failure mode, resulting in sample leakage, loss of system pressure, and potentially hazardous release of pressurized fluid. Electromagnetic interference can corrupt position sensor signals, producing missed or spurious trigger events.\n\n### reporting_checklist\nPublished moving-piston viscometry results should report: instrument make and model (or custom apparatus description with piston and cylinder dimensions); piston material, density, and dimensions; measurement cylinder bore diameter and material; driving force type (gravity, electromagnetic, pneumatic); number of piston cycles averaged per data point; temperature measurement method and calibration (ITS-90 traceability); pressure measurement method and calibration (traceability); viscosity reference standards used for calibration (manufacturer, lot, certified values, temperatures); sample purity, source, and preparation (degassing, filtration, drying); sample density values used for buoyancy correction and their source; thermal equilibration time at each state point; raw travel times or coefficient of variation; combined expanded uncertainty with coverage factor (typically k = 2, 95% confidence); any corrections applied (thermal expansion, end effects, buoyancy). For ThermoML encoding, viscosity values are reported with nCombExpandUncertValue at the 95% confidence level.\n",
      "domain_knowledge": {
        "description_block": {
          "artifacts_and_failure_modes": "Piston eccentricity artifacts cause the measured viscosity to be lower than the true value because the wider side of the non-concentric annular gap carries disproportionately more flow, reducing the overall drag on the piston. Inertia artifacts at low viscosities result from the piston not reaching terminal velocity within the detection zone, producing travel times shorter than expected and anomalously low apparent viscosity. Thermal gradient artifacts arise when the sample fluid in the cylinder is not thermally homogeneous, creating a viscosity gradient along the piston path that biases the average travel time. Dissolved gas artifacts manifest as bubble formation during depressurization, causing sudden erratic readings. Surface scoring of the piston or cylinder from abrasive samples or handling damage progressively alters the effective gap geometry, causing calibration drift. Seal failure at high pressure is the most consequential hardware failure mode, resulting in sample leakage, loss of system pressure, and potentially hazardous release of pressurized fluid. Electromagnetic interference can corrupt position sensor signals, producing missed or spurious trigger events.",
          "calibration_and_references": "Calibration establishes the instrument constant K by measuring the travel time for certified viscosity reference standards (e.g., Cannon N-series or S-series oils) of known viscosity at precisely controlled temperatures. The calibration equation η = K·Δρ·t is solved for K using multiple reference fluids spanning the target viscosity range, ideally bracketing the expected sample viscosity. Temperature calibration is performed by comparing the embedded PRT reading against an ITS-90 traceable reference thermometer. The pressure transducer is calibrated against a deadweight piston gauge or NIST-traceable reference. Calibration must be verified at regular intervals and after any disassembly or piston/cylinder replacement. Recommended reference materials include Cannon certified viscosity standards (covering 0.3 to 100,000 mm²/s), toluene (well-characterized low-viscosity standard with extensive η(T,P) literature data), DEHS (intermediate viscosity for high-pressure work), and NIST SRM 2490 (polyisobutylene solution for high-viscosity verification). Piston and cylinder dimensions should be verified periodically by coordinate measuring machine (CMM).",
          "common_pitfalls": "The most critical pitfall is incomplete degassing of the sample, which leads to bubble formation in the measurement cylinder — particularly during pressure reduction steps — causing erratic travel times and large scatter. Failure to filter samples adequately allows particulates to accumulate in the annular gap, gradually increasing travel times and eventually jamming the piston. Neglecting to correct for thermal expansion of piston and cylinder dimensions at temperatures far from the calibration temperature introduces a systematic bias that grows with temperature offset. Using a single calibration point (one reference fluid) rather than a multi-point calibration spanning the measurement range can lead to nonlinearity errors, as the instrument constant K may have a weak viscosity dependence due to end effects and piston acceleration. Conducting measurements before thermal equilibration is achieved produces biased viscosity values because viscosity is highly temperature-sensitive (2–5% per kelvin for typical liquids). Ignoring piston eccentricity — which arises from wear, manufacturing tolerances, or improper orientation — leads to systematically low viscosity readings.",
          "core_limitations": "The fundamental assumption of Newtonian Stokes flow limits the technique to Newtonian or near-Newtonian fluids — highly non-Newtonian, viscoelastic, or thixotropic fluids produce shear-rate-dependent results that do not represent a unique viscosity value. The shear rate in the annular gap is not precisely controlled or uniform, making it unsuitable for rheological characterization requiring defined shear rates. Piston eccentricity (off-center positioning) within the bore introduces systematic errors that are difficult to detect and correct. For very low-viscosity fluids (< 0.2 mPa·s), the piston may not reach terminal velocity within the detection zone due to inertial effects, degrading accuracy. The technique requires knowledge of the fluid density (or the density difference between piston and fluid) for absolute viscosity determination, introducing an additional uncertainty source. Sample fluids containing abrasive particles can damage the precision surfaces of the piston and cylinder, requiring frequent inspection and replacement.",
          "core_theory": "The measurement is based on Stokes flow (creeping flow) in a cylindrical annular geometry. When a cylindrical piston of radius R_p and length L falls under gravity through a cylinder of radius R_c filled with a Newtonian fluid, it reaches a terminal velocity where the gravitational force minus buoyancy equals the viscous drag. For the annular geometry, the dynamic viscosity is given by η = (ρ_piston − ρ_fluid)·g·R_p²·t / (2L·f(κ)), where κ = R_p/R_c is the radius ratio and f(κ) is a geometric factor derived from the exact solution of the Navier-Stokes equations for concentric cylinder Poiseuille-Couette flow. In practice, this is simplified to η = K·Δρ·t, where K is an instrument constant determined empirically by calibration with fluids of known viscosity, Δρ is the difference between piston and fluid densities, and t is the measured travel time. The validity requires that the Reynolds number based on piston velocity and annular gap width is much less than unity (Re << 1), ensuring the flow is purely viscous with no inertial effects.",
          "data_interpretation": "The primary data reduction is straightforward: the measured travel time t at each (T, P) state point, combined with the calibration constant K and the piston–fluid density difference Δρ = ρ_piston − ρ_fluid, yields the dynamic viscosity η = K·Δρ·t. Multiple travel time measurements (3–5 piston cycles) are averaged to provide a mean viscosity and standard deviation at each state point. The buoyancy correction requires the fluid density at measurement conditions; this is either measured independently or estimated from an equation of state. Viscosity–temperature data are typically correlated using the Arrhenius equation (ln η = A + E_a/RT) for limited temperature ranges, or the Vogel-Fulcher-Tammann (VFT) equation (ln η = A + B/(T − T₀)) for wider ranges. Viscosity–pressure data are correlated using the Barus equation (η = η₀·exp(α·P)) or more sophisticated models such as the modified Tait–Doolittle equation for strongly nonlinear pressure dependence. For comprehensive (T, P) coverage, multiparameter correlations or interpolation surfaces are constructed.",
          "how_it_operates": "A cylindrical piston of known density and precise dimensions is placed inside a close-fitting measurement cylinder filled with the sample fluid. A controlled driving force — gravity in falling-piston designs, or electromagnetic/pneumatic actuation in automated instruments — causes the piston to move through the fluid at a velocity determined by the balance between the driving force and the viscous drag in the narrow annular gap between the piston and cylinder wall. Two position sensors (magnetic, optical, or inductive) placed at a fixed separation along the cylinder detect the piston's passage and trigger a high-resolution timer. The measured travel time is directly proportional to the fluid viscosity through a calibration constant that encapsulates the piston and cylinder geometry, piston density, and driving force. Temperature and pressure are measured simultaneously by sensors embedded in or adjacent to the thermostated pressure vessel. Automated instruments cycle the piston back and forth using an electromagnetic coil, collecting multiple travel times per measurement for statistical averaging.",
          "reporting_checklist": "Published moving-piston viscometry results should report: instrument make and model (or custom apparatus description with piston and cylinder dimensions); piston material, density, and dimensions; measurement cylinder bore diameter and material; driving force type (gravity, electromagnetic, pneumatic); number of piston cycles averaged per data point; temperature measurement method and calibration (ITS-90 traceability); pressure measurement method and calibration (traceability); viscosity reference standards used for calibration (manufacturer, lot, certified values, temperatures); sample purity, source, and preparation (degassing, filtration, drying); sample density values used for buoyancy correction and their source; thermal equilibration time at each state point; raw travel times or coefficient of variation; combined expanded uncertainty with coverage factor (typically k = 2, 95% confidence); any corrections applied (thermal expansion, end effects, buoyancy). For ThermoML encoding, viscosity values are reported with nCombExpandUncertValue at the 95% confidence level.",
          "sample_preparation": "Sample fluids must be thoroughly degassed before loading into the measurement cell, as dissolved gases can nucleate into bubbles under pressure changes, disrupting piston motion and altering effective fluid density. Degassing is performed under vacuum or by helium sparging. The sample should be filtered through a membrane filter (0.5–5 µm pore size) to remove particulates that could jam in the narrow annular gap between piston and cylinder. For hygroscopic or moisture-sensitive fluids (e.g., ionic liquids), the sample should be dried over molecular sieves and handled under inert atmosphere. The cell and all wetted components must be thoroughly cleaned with appropriate solvents (acetone, toluene, or n-hexane depending on sample compatibility) and dried between measurements. If kinematic viscosity is the target, the sample density must be independently measured at the same temperature and pressure conditions using a vibrating-tube densimeter or other suitable method. Sample volume of 2–10 mL is typically required, and the fluid must completely fill the cylinder with no trapped air.",
          "setup": "A typical moving-piston viscometer consists of a precision-bore cylinder (stainless steel, Hastelloy, or sapphire, bore diameter 5–15 mm) housed inside a thermostated high-pressure vessel rated to 200–300 MPa. A precision-ground piston (various materials: tungsten carbide, stainless steel, aluminum — selected for appropriate density contrast with the sample) sits inside the cylinder. Two position sensors spaced 10–50 mm apart detect the piston magnetically or optically and trigger a high-resolution timer with ±0.001 s resolution. The pressure vessel is jacketed and connected to a circulating thermostat bath providing temperature stability to ±0.01 K. A calibrated PRT mounted in the vessel wall monitors temperature, while a calibrated pressure transducer measures the fluid pressure. In automated instruments (e.g., Cambridge Viscosity SPL), an electromagnetic coil at one end of the cylinder drives the piston back to its starting position after each fall, enabling continuous automated cycling. A computer-controlled data acquisition system records travel times, temperature, and pressure, and computes viscosity in real time.",
          "suitable_for": "The moving piston method is particularly well-suited for viscosity measurements at elevated pressures, making it a workhorse for petroleum fluid characterization, lubricant evaluation, and compressed-liquid studies for equation-of-state development. It handles a remarkably wide viscosity range (0.2 mPa·s to 10,000 Pa·s) through piston selection, accommodating everything from light solvents to heavy crude oils. The compact, sealed-cell design enables measurements on small sample volumes (2–10 mL), which is advantageous for expensive or scarce fluids. The technique is well-suited for Newtonian fluids and mildly non-Newtonian fluids at the low shear rates prevailing in the annular gap. It is widely used for ionic liquids, refrigerants, deep eutectic solvents, and hydrocarbon mixtures at reservoir conditions.",
          "technique_overview": "The moving piston method is a viscometry technique that determines the dynamic viscosity of a fluid by measuring the time required for a precision-machined piston to travel a fixed distance through a close-fitting cylinder filled with the sample fluid under a controlled driving force. Also known as the falling-piston or rising-piston viscometer, the technique is based on the Stokes drag principle adapted to cylindrical annular geometry. Commercial implementations include the Cambridge Viscosity SPL series, which uses electromagnetic actuation to cycle the piston back and forth, enabling automated, repeated measurements. The method is especially valued for high-pressure viscosity measurements (up to 200–300 MPa) and covers an exceptionally wide viscosity range from 0.2 mPa·s to over 10,000 Pa·s through selection of different piston sizes and densities."
        },
        "structured_block": {
          "data_and_interpretation": {
            "analysis_methods": [
              "primary equation: η = K·(ρ_piston − ρ_fluid)·t, where K is the instrument constant determined by calibration",
              "alternative Stokes-flow derivation for annular geometry: η = (ρ_piston − ρ_fluid)·g·R_p²·t / (2L·f(R_p/R_c)), where f is a geometric factor depending on piston-to-cylinder radius ratio",
              "Arrhenius or Vogel-Fulcher-Tammann (VFT) fitting: ln η = A + B/(T − T₀) for viscosity–temperature correlation",
              "Barus equation fitting: η = η₀·exp(α·P) for viscosity–pressure dependence at constant T",
              "linear or polynomial interpolation of η(T,P) tables for generating smoothed viscosity surfaces"
            ],
            "common_artifacts": [
              "piston eccentricity artifact: if the piston is not centered in the bore, annular flow is non-uniform and measured viscosity deviates (typically lower than true value due to wider gap on one side)",
              "inertia artifact at low viscosity: piston accelerates through the detection zone rather than reaching terminal velocity, producing anomalously short travel times",
              "thermal gradient artifact: incomplete thermal equilibration of sample in the cylinder creates a viscosity gradient along the piston path, distorting the measurement",
              "dissolved gas artifact: gas coming out of solution during pressure reduction creates bubbles that alter effective fluid density and flow resistance",
              "surface scoring artifact: scratched piston or cylinder surfaces change the effective gap geometry, causing progressive drift in calibration constant"
            ],
            "failure_modes": [
              "piston jamming due to particulate contamination or sample solidification in the annular gap",
              "seal failure at high pressure resulting in sample leak and pressure loss",
              "loss of position sensor signal due to sensor malfunction or electromagnetic interference",
              "cylinder bore contamination from sample residue causing progressive bias in travel time",
              "piston corrosion or chemical attack from aggressive sample fluids changing piston dimensions and density"
            ],
            "fit_parameters": [
              "instrument constant K (determined from calibration)",
              "dynamic viscosity η at each (T, P) state point",
              "Arrhenius parameters A and Ea (activation energy) for η(T) modeling",
              "VFT parameters A, B, T₀ for η(T) modeling",
              "Barus coefficient α for η(P) modeling"
            ],
            "model_assumptions": [
              "fully developed laminar (Stokes) flow in the piston–cylinder annular gap (Reynolds number << 1)",
              "the fluid is Newtonian (shear stress proportional to shear rate) over the prevailing shear rate range in the annular gap",
              "piston reaches terminal (constant) velocity within the detection zone — no acceleration transient contaminates the timing",
              "the annular gap is concentric and uniform along the piston length (no eccentricity)",
              "fluid density and piston density are constant (or corrected for) over the measurement temperature and pressure range",
              "no wall slip at the piston or cylinder surfaces"
            ],
            "preprocessing_steps": [
              "averaging of multiple travel time measurements (typically 3–5 cycles) at each (T, P) state point to improve precision",
              "correction for piston acceleration zone at start of travel (only the steady-state region between detection points is used)",
              "correction for fluid buoyancy on the piston: effective driving force = (ρ_piston − ρ_fluid)·V_piston·g",
              "temperature and pressure corrections applied to instrument constant K for thermal expansion of piston and cylinder",
              "end-effect corrections for finite cylinder length (if piston approaches cylinder ends during measurement)"
            ],
            "quality_control_checks": [
              "measure a certified viscosity reference standard at each temperature and pressure before and after sample runs to verify instrument constant stability",
              "verify piston terminal velocity by comparing travel times for different detection zone lengths (if available) or from multiple consecutive runs",
              "check that multiple piston fall/rise cycles yield consistent travel times (CV < 0.5%)",
              "compare heating and cooling sweeps at the same state points to detect hysteresis or thermal lag",
              "inspect piston and cylinder for visible scoring or wear at regular intervals; replace if tolerances are exceeded"
            ],
            "raw_signal_type": "electrical pulses from position detectors marking the start and end of piston travel through a fixed distance, yielding travel time t; plus analog signals from PRT (temperature) and pressure transducer"
          },
          "experimental_parameters": {
            "constraints": [
              {
                "hard_limits": "limited by seal materials and thermostating fluid; specialized cells extend to 523 K",
                "notes": "low-temperature limit set by sample freezing or seal embrittlement; high-temperature limit by O-ring and seal degradation",
                "parameter": "temperature_range",
                "typical_range": "233 K to 473 K"
              },
              {
                "hard_limits": "maximum set by pressure vessel rating and seal integrity; some designs rated to 300 MPa",
                "notes": "a key advantage of this technique is robust high-pressure capability",
                "parameter": "pressure_range",
                "typical_range": "0.1 MPa to 200 MPa"
              },
              {
                "hard_limits": "lower limit set by minimum measurable travel time at maximum piston velocity; upper limit by practical measurement duration",
                "notes": "range covered by selecting different piston densities and cylinder bore diameters; multiple piston sets extend overall range",
                "parameter": "viscosity_range",
                "typical_range": "0.2 mPa·s to 10,000 Pa·s"
              },
              {
                "hard_limits": "must completely fill the measurement cylinder with no trapped gas",
                "notes": "compressed-liquid measurements require careful degassing and filling under pressure",
                "parameter": "sample_volume",
                "typical_range": "2 mL to 10 mL"
              }
            ],
            "variables": [
              {
                "effect": "viscosity decreases exponentially with increasing temperature for most liquids; temperature must be controlled to ±0.01 K for high-accuracy work",
                "name": "temperature",
                "role": "primary scanned variable",
                "typical_values": "273 K to 423 K"
              },
              {
                "effect": "viscosity generally increases with pressure; pressure–viscosity coefficient is a key derived quantity for lubricant characterization",
                "name": "pressure",
                "role": "primary scanned variable (high-pressure studies) or fixed (ambient studies)",
                "typical_values": "0.1 MPa to 200 MPa"
              },
              {
                "effect": "heavier or larger-diameter pistons generate greater force, suitable for low-viscosity fluids; lighter pistons with tighter clearance for high-viscosity fluids",
                "name": "piston_type",
                "role": "instrument configuration variable",
                "typical_values": "selection of piston density and diameter for target viscosity range"
              },
              {
                "effect": "determines the shear rate regime and suitability for different viscosity ranges; electromagnetic actuation enables automated cycling",
                "name": "applied_force_mode",
                "role": "instrument configuration variable",
                "typical_values": "gravity, electromagnetic, or pneumatic drive"
              }
            ]
          },
          "measurement_scope": {
            "derived_observables": [
              "dynamic viscosity (η)",
              "kinematic viscosity (ν = η/ρ, when density is known or measured concurrently)",
              "viscosity–temperature coefficient",
              "viscosity–pressure coefficient"
            ],
            "direct_observables": [
              "piston travel time between two detection points (t)",
              "temperature of thermostated pressure vessel (T)",
              "applied pressure on fluid (P)",
              "piston position signal from magnetic or optical sensors"
            ],
            "phases_measured": [
              "liquid (Newtonian)",
              "liquid (mildly non-Newtonian at low shear rates)",
              "compressed liquid at elevated pressures"
            ],
            "supported_sample_types": [
              "pure liquids",
              "binary and multicomponent liquid mixtures",
              "petroleum fluids and crude oils",
              "lubricants and hydraulic fluids",
              "ionic liquids",
              "refrigerants and compressed gases in liquid phase",
              "polymer solutions (dilute to moderately concentrated)",
              "high-viscosity fluids (heavy oils, bitumen)"
            ],
            "target_properties": [
              "dynamic viscosity (η)",
              "kinematic viscosity (ν)",
              "viscosity as a function of temperature at constant pressure",
              "viscosity as a function of pressure at constant temperature"
            ],
            "typical_output_formats": [
              "η vs. T at constant P",
              "η vs. P at constant T",
              "log η vs. 1/T (Arrhenius plot)",
              "η vs. composition at constant T and P",
              "tabulated (T, P, η) data"
            ],
            "units": {
              "density": "kg/m³",
              "dynamic_viscosity": "mPa·s (= cP) or Pa·s",
              "kinematic_viscosity": "mm²/s (= cSt)",
              "piston_travel_time": "s",
              "pressure": "MPa",
              "temperature": "K"
            },
            "unsupported_sample_types": [
              "gases at low pressure (insufficient drag on piston)",
              "highly abrasive slurries or suspensions containing large particles (damage to piston/cylinder surfaces)",
              "fluids that chemically attack the piston or cylinder material",
              "viscoelastic fluids with strong elastic recovery (piston rebound artifacts)",
              "two-phase or foaming fluids (undefined viscosity regime)"
            ]
          },
          "performance": {
            "accuracy": "1–2% of measured value with proper calibration; 0.5% achievable for mid-range viscosities with careful calibration and temperature control",
            "detection_limit": "minimum measurable viscosity ~0.2 mPa·s (limited by piston inertia and minimum resolvable travel time)",
            "dynamic_range": "approximately five decades: 0.2 mPa·s to ~10,000 Pa·s achievable through piston selection",
            "measurement_speed": "individual measurement: 10–300 s per piston fall cycle; automated instruments average 3–5 cycles per state point for statistical averaging",
            "precision": "0.2–0.5% (repeatability of travel time measurement at stabilized T and P)",
            "resolution": {
              "energy": "not applicable",
              "spatial": "not applicable (bulk fluid measurement)",
              "spectral": "not applicable",
              "temporal": "measurement cycle time 10 s to 300 s per data point depending on viscosity; automated cycling enables repeated measurements every 30–120 s"
            },
            "sensitivity": "capable of resolving viscosity differences of ~0.1% between consecutive measurements for well-conditioned piston/cylinder assemblies",
            "throughput": "single sample; one T-sweep or P-sweep typically requires 2–6 hours depending on number of state points and equilibration time"
          },
          "setup_and_requirements": {
            "calibration_requirements": [
              "calibration with certified viscosity reference standards (e.g., Cannon S-series, PTB oils) spanning the target viscosity range to establish instrument constant K relating travel time to viscosity: η = K·(ρ_piston − ρ_fluid)·t",
              "temperature calibration of embedded PRT against ITS-90 fixed points or a NIST-traceable reference thermometer",
              "pressure transducer calibration against a deadweight tester or NIST-traceable reference pressure gauge",
              "verification of piston and cylinder dimensions using coordinate measuring machine (CMM) at periodic intervals",
              "repeatability check: multiple consecutive measurements of a reference fluid must agree within stated precision"
            ],
            "consumables": [
              "high-pressure O-rings and seals (Viton, Kalrez, or PTFE) rated to maximum operating pressure",
              "replacement pistons of various materials and dimensions for different viscosity ranges",
              "calibration reference oils (consumed during calibration runs)",
              "cleaning solvents (acetone, toluene, n-hexane) for flushing between samples",
              "filtration membranes (0.5–5 µm pore size)"
            ],
            "environmental_requirements": [
              "temperature-controlled laboratory (±2 K ambient) to minimize thermal gradients in tubing and connections",
              "vibration-free bench or mounting to prevent disturbing piston free-fall",
              "pressure-rated fittings and burst containment for high-pressure operation",
              "fume hood or ventilation when using volatile or toxic sample fluids"
            ],
            "instrument_components": [
              "precision-bore measurement cylinder — tight-tolerance bore (typical diameters 5–15 mm) made of stainless steel, Hastelloy, or sapphire for chemical resistance",
              "calibrated piston — precision-ground cylinder (various densities and diameters) whose dimensions define the annular gap with the bore",
              "position detection system — two magnetic proximity sensors, optical sensors, or inductive coils defining a fixed travel distance (typically 10–50 mm)",
              "thermostated pressure vessel — jacketed cell with circulating fluid thermostat for temperature control (stability ±0.01 K)",
              "pressure generation and measurement system — hand pump or syringe pump with calibrated pressure transducer (accuracy ±0.05 MPa)",
              "timing circuit — high-resolution electronic timer triggered by position sensors (resolution ±0.001 s)",
              "temperature measurement — calibrated PRT (Pt100) or thermistor embedded in cell wall near measurement zone",
              "electromagnetic or pneumatic actuator — returns piston to starting position and controls drive force in non-gravity designs (e.g., Cambridge Viscosity SPL series)",
              "data acquisition and control system — computer interface for automated measurement cycles, data logging, and temperature/pressure programming"
            ],
            "reference_materials": [
              "NIST SRM 2490 — polyisobutylene solution in 2,6,10,14-tetramethylpentadecane (high viscosity standard)",
              "Cannon certified viscosity reference standards (N-series, S-series) — available across 0.3 to 100,000 mm²/s range",
              "NIST SRM 2492 — Bingham paste standard (for non-Newtonian verification, if applicable)",
              "toluene — low-viscosity reference with well-characterized η(T,P) data from literature",
              "diethylhexyl sebacate (DEHS) — intermediate-viscosity reference for high-pressure calibration"
            ],
            "safety_notes": [
              "high-pressure systems require pressure-rated enclosures and burst discs; never exceed rated pressure",
              "use proper PPE (eye protection, face shields) when handling pressurized fluids",
              "ensure proper ventilation when working with volatile or toxic solvents for cleaning or as samples",
              "heavy pistons and pressure vessels should be handled with care to avoid injury from dropped components"
            ],
            "sample_requirements": {
              "geometry": [
                "liquid sample filling the cylindrical bore completely with no gas bubbles"
              ],
              "mounting_requirements": [
                "cylinder oriented vertically for gravity-driven designs, or in any orientation for magnetically/pneumatically driven designs",
                "leak-free sealing of pressure vessel at all operating pressures"
              ],
              "preparation_requirements": [
                "thorough degassing under vacuum or by helium sparging to eliminate dissolved gas that may form bubbles under changing pressure",
                "filtration through 0.5–5 µm filter to remove particulates that could score piston or cylinder surfaces",
                "drying over molecular sieves for moisture-sensitive fluids",
                "density measurement of sample (if kinematic viscosity is required) using vibrating-tube densimeter or pycnometer"
              ],
              "size_limits": "2–10 mL depending on cylinder volume; sufficient to fill cylinder and connecting tubing",
              "surface_requirements": [
                "sample must be free of suspended particles large enough to jam in the piston–cylinder annular gap",
                "sample should be homogeneous and single-phase under measurement conditions"
              ],
              "thickness_limits": "not applicable (annular gap between piston and cylinder wall is the critical dimension, typically 10–200 µm)"
            }
          },
          "uncertainty": {
            "dominant_error_sources": [
              "calibration constant uncertainty (especially when extrapolating far from the viscosity range of the reference standards)",
              "temperature measurement and control (viscosity changes 2–5% per kelvin for typical liquids)",
              "piston–cylinder dimensional stability and concentricity"
            ],
            "level": "typical combined standard uncertainty 1–2% for dynamic viscosity; can be reduced to 0.5% with meticulous calibration and mid-range viscosity values",
            "model_dependence": "moderate — accuracy depends on validity of Stokes flow assumption, concentricity of piston, and Newtonian behavior of sample; deviations from any of these require empirical corrections or alternative analysis",
            "operator_dependence": "low to moderate — filling procedure (gas-free loading), cleaning quality, and sample filtration depend on operator care; less operator-dependent than capillary viscometry due to automated piston cycling",
            "random_sources": [
              "variability in piston travel time from run to run (fluid turbulence at lower viscosities)",
              "short-term temperature fluctuations within the measurement cell",
              "pressure fluctuations from pump pulsation or thermal volume changes",
              "electronic noise in position sensor and timer circuits",
              "vibration-induced disturbances to piston motion"
            ],
            "reported_as": [
              "combined expanded uncertainty U(η) at 95% confidence (k=2)",
              "relative expanded uncertainty as percentage of η",
              "standard deviation from replicate piston travel time measurements"
            ],
            "systematic_sources": [
              "uncertainty in the calibration constant K (propagated from reference standard certification uncertainty)",
              "piston and cylinder dimensional tolerances (bore diameter, piston diameter, roundness, cylindricity)",
              "piston eccentricity within the bore (non-uniform annular gap)",
              "thermal expansion corrections for piston and cylinder at temperatures far from calibration temperature",
              "fluid density uncertainty (when converting to kinematic viscosity or computing buoyancy correction)",
              "temperature measurement offset between PRT location and actual fluid temperature at the piston",
              "pressure measurement calibration offset",
              "end effects and piston acceleration corrections"
            ],
            "thermoml_encoding": "nCombExpandUncertValue at 95% confidence level"
          }
        }
      },
      "identity": {
        "acronym": "",
        "aliases": [],
        "canonical_method_name": "Moving piston method",
        "db_usage": {
          "instance_count": 55,
          "n_papers": 15,
          "per_group": {
            "TransportProp": {
              "instances": 55,
              "papers": 15
            }
          },
          "property_groups": [
            "TransportProp"
          ]
        },
        "measurement_family": "Viscometry",
        "modality": {
          "contact": "yes",
          "destructive": "no",
          "imaging": "no",
          "in_situ": "no"
        },
        "name": "Moving piston method",
        "source_aliases": [
          {
            "method_type": "standard",
            "name": "Moving piston method"
          }
        ],
        "thermoml_custom_codes": [],
        "thermoml_standard_name": "Moving piston method"
      },
      "match_score": 100,
      "match_type": "source_alias_exact",
      "meas_ID": "moving_piston_method",
      "meas_id": "moving_piston_method",
      "meas_num_id": "GLOBmeas_69"
    }
  ]
}
```


## 13. block_search_adv

**Summary:** 50 pure ethanol viscosity blocks near 298.15 K were found (44 rendered). No measurement method metadata is included in these results — method cross-referencing requires querying individual DOIs/literature records separately. Values range from ~0.00104 to ~0.001297 Pa·s.

50 entries — presenting all 44 rendered in compact form for cross-referencing:

| DOI | Block | GLOBlit | η (Pa·s) |
|---|---|---|---|
| 10.1016/j.fluid.2005.05.012 | PROPblock_3 | GLOBlit_267 | 0.001078 |
| 10.1016/j.fluid.2005.07.010 | PROPblock_9 | GLOBlit_288 | 0.001082 |
| 10.1016/j.fluid.2006.01.008 | PROPblock_11 | GLOBlit_349 | 0.001077 |
| 10.1016/j.fluid.2007.03.021 | PROPblock_3 | GLOBlit_499 | 0.001082 |
| 10.1016/j.jct.2005.04.019 | PROPblock_4 | GLOBlit_2547 | 0.001093 |
| 10.1016/j.jct.2005.06.011 | PROPblock_26 | GLOBlit_2568 | 0.0010831 |
| 10.1016/j.jct.2005.07.008 | PROPblock_3 | GLOBlit_2580 | 0.001105 |
| 10.1016/j.jct.2005.10.022 | PROPblock_2 | GLOBlit_2632 | 0.001073 |
| 10.1016/j.jct.2005.12.010 | PROPblock_1

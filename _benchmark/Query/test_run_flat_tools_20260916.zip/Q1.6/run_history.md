# Q1.6 — Run History

**Prompt:** What is the measured isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure?

This file is the audit record. For SQL calls, the fenced raw Markdown is
the exact payload supplied to the task-directed agentic compactor.

## Soft-budget events

```json
[]
```

## Step 1: resolve_compound_ids

### Call arguments

```json
{
  "queries": "water",
  "purpose": "Identify the ThermoML compound ID for water",
  "tasks": [
    "Find the GLOBcomp ID for water (H2O)"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `resolve_compound_ids`

Serialization: `json`

```json
{
  "n_results": 1,
  "results": [
    {
      "common_name": "water",
      "comp_id": "water",
      "comp_num_id": "GLOBcomp_1",
      "formula": "H2O",
      "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
      "match_type": "name_exact",
      "n_papers": 4690,
      "score": 100,
      "smiles": "O",
      "standard_inchi": "InChI=1S/H2O/h1H2"
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
resolve_compound_ids: 1 match(es).

| # | comp_num_id | Name | Formula | SMILES | Score | Match |
|---|-------------|------|---------|--------|-------|-------|
| 1 | GLOBcomp_1 | water | H2O | O | 100 | name_exact |

```

### Model-visible result

```markdown
**Water** is identified as **GLOBcomp_1** (exact name match, score 100).

| Field | Value |
|-------|-------|
| ID | GLOBcomp_1 |
| Name | water |
| Formula | H2O |
| SMILES | O |
```

### Integrity and timing

- Raw SHA-256: 8768b2c71c812e3b75f432fe4de1cf3dbb3958b25f12a2475bf1d1d6efdfb833
- Raw characters: 439
- Hardcoded-compacted characters: 216
- Model-visible characters: 179
- Agentic verdict: KEEP
- Tool elapsed: 0.002s
- Compactor elapsed: 3.653s
- Total elapsed: 3.655s

## Step 2: resolve_property_ids

### Call arguments

```json
{
  "queries": "isobaric heat capacity",
  "purpose": "Identify the ThermoML property ID for molar isobaric heat capacity (Cp)",
  "tasks": [
    "Find the GLOBprop ID for molar heat capacity at constant pressure"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `resolve_property_ids`

Serialization: `json`

```json
{
  "n_results": 1,
  "results": [
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 3113,
      "prop_group": "HeatCapacityAndDerivedProp",
      "prop_id": "molar_heat_capacity_at_constant_pressure_j_k_mol",
      "prop_name": "Molar heat capacity at constant pressure, J/K/mol",
      "prop_num_id": "GLOBprop_9",
      "score": 100
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
resolve_property_ids: 1 match(es).

| # | prop_num_id | Name | Group | Score | Match |
|---|-------------|------|-------|-------|-------|
| 1 | GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | HeatCapacityAndDerivedProp | 100 | prop_id_exact |

```

### Model-visible result

```markdown
The ThermoML property ID for molar heat capacity at constant pressure is **GLOBprop_9**.

| prop_num_id | Name | Group | Score | Match |
|---|---|---|---|---|
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | HeatCapacityAndDerivedProp | 100 | prop_id_exact |
```

### Integrity and timing

- Raw SHA-256: c2bcd7a1eaa9933c1820a84c00fafaa2eb09c60a197c9eb984be66c9daf981a4
- Raw characters: 464
- Hardcoded-compacted characters: 260
- Model-visible characters: 276
- Agentic verdict: KEEP
- Tool elapsed: 0.000s
- Compactor elapsed: 4.025s
- Total elapsed: 4.026s

## Step 3: block_search_adv

### Call arguments

```json
{
  "compounds": "REQUIRE GLOBcomp_1 AS water",
  "targets": "GLOBprop_9 AS cp",
  "system_type": "unary",
  "phases": "REQUIRE GLOBphase_3",
  "explanation": "Find measured molar isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure",
  "where": "cp BETWEEN 70 AND 85",
  "select": [
    "AVG(cp) AS mean_cp",
    "MIN(cp) AS min_cp",
    "MAX(cp) AS max_cp",
    "COUNT(*) AS n_points"
  ],
  "purpose": "Retrieve experimental Cp data for pure liquid water near 298.15 K",
  "tasks": [
    "Find blocks with molar heat capacity at constant pressure for pure liquid water",
    "Get the Cp values near 298.15 K and ~101.325 kPa"
  ],
  "limit": 20
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `block_search_adv`

Serialization: `json`

```json
{
  "alias_resolution": [
    {
      "alias": "cp",
      "available_global_ids": [
        "GLOBprop_9"
      ],
      "canonical_unit": "J/(K mol)",
      "input": "GLOBprop_9",
      "input_catalog_role": "property",
      "quantity_key": "molar_heat_capacity_at_constant_pressure_j_k_mol",
      "required_role_global_id": "GLOBprop_9",
      "required_source_role": "property",
      "semantic_type": "molar_heat_capacity_at_constant_pressure_j_k_mol"
    }
  ],
  "diagnostics": {
    "ambiguous_binding_rejections": 0,
    "binding_budget_rejections": 0,
    "binding_combinations": 1,
    "card_exact_candidates": 1,
    "having_rejections": 0,
    "limit_cells_as_null": 0,
    "materialized_blocks": 0,
    "materialized_rows": 1,
    "minimum_point_rejections": 1,
    "nonfinite_cells_as_null": 0,
    "numeric_nulls": 0,
    "observation_rejections": 0,
    "registry_candidates": 25,
    "role_or_filter_rejections": 0
  },
  "n_binding_matches": 0,
  "n_results": 0,
  "normalized_query": {
    "calculate": [],
    "compound_match": "all",
    "compounds": [
      "REQUIRE GLOBcomp_1 AS water"
    ],
    "explanation": "Find measured molar isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure",
    "fixed_constraints": [],
    "having": null,
    "inline_state": [],
    "input_contract": "block_search_adv/flat-v2",
    "limit": 20,
    "literature": [],
    "minimum_common_points": 1,
    "order_by": [],
    "parameters": [],
    "phase_match": "all",
    "phases": [
      "REQUIRE GLOBphase_3"
    ],
    "select": [
      "AVG(cp) AS mean_cp",
      "MIN(cp) AS min_cp",
      "MAX(cp) AS max_cp",
      "COUNT(*) AS n_points"
    ],
    "system_scope": "declared",
    "system_size_max": null,
    "system_size_min": null,
    "system_type": "unary",
    "targets": [
      "GLOBprop_9 AS cp"
    ],
    "where": "cp BETWEEN 70 AND 85"
  },
  "preexecution_review": {
    "automatic_confirmation": true,
    "confirmation_tokens": {
      "composite_confirmation_token": "bsa_comp_966fa13ece006bef2a9d5c5f5665f9d482287774ce9bdc2a01d3486ecafd241a",
      "database_intent_confirmation_token": "bsa_db_4a650ca9c2082926a72a387f24d0e53ad66f35778d6d529052ccf6333cff5360",
      "execution_confirmation_token": "bsa_final_684b59748a5f88a65a90deb6bbd651ce19dd1abffa69e67cf228c32ddfb360ba"
    },
    "confirmed_stages": [
      "composite_id_enrichment",
      "database_id_intent",
      "final_intent_and_syntax"
    ],
    "raw_execution_authorized": true,
    "schema": "block_search_adv/preexecution-ready-v1"
  },
  "results": [],
  "schema": "block_search_adv/result-v1",
  "total_binding_matches_before_limit": 0,
  "total_matching_blocks_before_limit": 0,
  "truncated": false
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
# block_search_adv

**Matches:** 0 unique ThermoML search target(s), 0 legitimate binding match(es).
**Truncated by search limit:** no
**Search explanation:** Find measured molar isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure
**Diagnostics:** registry_candidates=25, card_exact_candidates=1, binding_combinations=1, materialized_blocks=0, materialized_rows=1, role_or_filter_rejections=0, ambiguous_binding_rejections=0, binding_budget_rejections=0, minimum_point_rejections=1, observation_rejections=0, having_rejections=0, numeric_nulls=0
**Identity translation / required roles:** cp: GLOBprop_9 → molar_heat_capacity_at_constant_pressure_j_k_mol [requires property] (GLOBprop_9)

No exact search target and binding combination satisfied the query.

```

### Model-visible result

```markdown
**⚠ Tool `block_search_adv` result discarded by subagent.**

1. **Explanation:** The search found no blocks with molar heat capacity at constant pressure (Cp) for pure liquid water near 298.15 K. Diagnostics indicate 1 row was materialized but rejected by the minimum-point filter, meaning the only candidate block had too few data points to pass the threshold.

2. **Refinement suggestion:** Retry the search with a relaxed minimum-point requirement (e.g., `min_points=1`) to capture single-point Cp measurements. Alternatively, broaden the temperature window (e.g., 273–373 K) to increase the chance of finding blocks with enough points. If the tool supports it, also try searching without a pressure constraint, as some entries may omit explicit pressure for atmospheric-condition measurements.
```

### Integrity and timing

- Raw SHA-256: 4b59244ec74ad2fe068ec74e1ac3035e212a723a1dc3c6183547dfb7dd74034e
- Raw characters: 2808
- Hardcoded-compacted characters: 783
- Model-visible characters: 797
- Agentic verdict: DISCARD
- Tool elapsed: 11.568s
- Compactor elapsed: 8.951s
- Total elapsed: 20.520s

## Step 4: search_blocks

### Call arguments

```json
{
  "compound": "water",
  "property": "GLOBprop_9",
  "system_type": "pure",
  "temperature_range": [
    295,
    302
  ],
  "purpose": "Find any data blocks with Cp measurements for pure water near 298.15 K",
  "tasks": [
    "Identify blocks containing molar heat capacity at constant pressure for pure liquid water near 25 °C"
  ],
  "limit": 20
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "error": {
    "message": "system_type must use the exact registry value: unary, binary, ternary, quaternary, or N-component",
    "type": "ValueError"
  }
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

*Not applicable (SQL raw-to-agentic or pass-through tool).*

### Model-visible result

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "error": {
    "message": "system_type must use the exact registry value: unary, binary, ternary, quaternary, or N-component",
    "type": "ValueError"
  }
}
```

````

### Integrity and timing

- Raw SHA-256: af342548ee79aea21531fbb3cfc15ac0181bc6ee0ea65835d28e4d2ba42e0be2
- Raw characters: 233
- Hardcoded-compacted characters: 0
- Model-visible characters: 233
- Agentic verdict: ERROR
- Tool elapsed: 0.000s
- Compactor elapsed: 0.000s
- Total elapsed: 0.000s

## Step 5: search_blocks

### Call arguments

```json
{
  "compound": "water",
  "property": "GLOBprop_9",
  "system_type": "unary",
  "temperature_range": [
    293,
    303
  ],
  "purpose": "Find data blocks with Cp measurements for pure water near 298.15 K",
  "tasks": [
    "Identify blocks containing molar heat capacity at constant pressure for pure liquid water near 25 °C"
  ],
  "limit": 20
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "n_results": 10,
  "query_params": {
    "compound": "water",
    "limit": 20,
    "property": "GLOBprop_9",
    "system_scope": "declared",
    "system_type": "unary",
    "temperature_range": [
      293,
      303
    ]
  },
  "results": [
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_1",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_1 | P/M | unary | 8 pts | GLOBlit_1310\n\n### Reference\n**lit_id:** 2013-was-kun-0\n**Title:** Heat capacities and the two-point scaling analysis of short-chain surfactant solutions\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_3 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_31 | large_sample_1g_dsc | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(4 extrema) | 8 pts → 8 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 298.15 | 75.368725408 | 1.3061078 |\n| 303.15 | 75.33990096 | 1.304306272 |\n| 308.15 | 75.329091792 | 1.304306272 |\n| 313.15 | 75.338099432 | 1.304306272 |\n| 298.15 | 75.350710128 | 1.304306272 |\n| 303.15 | 75.32188568 | 1.304306272 |\n| 308.15 | 75.316481096 | 1.304306272 |\n| 313.15 | 75.332694848 | 1.304306272 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Large sample (1 g) DSC"
        ],
        "n_points": 8,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 75.368725,
            "mean": 75.337199,
            "min": 75.316481,
            "n": 8,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.016623
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 313.15,
            "min": 298.15,
            "n_unique": 4,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1016/j.fluid.2013.08.005",
      "lit_num_id": "GLOBlit_1310",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 8,
      "paper_title": "Heat capacities and the two-point scaling analysis of short-chain surfactant solutions",
      "parent_n_datapoints": 8,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "large_sample_1g_dsc",
          "meas_num_id": "GLOBmeas_31",
          "method_custom": null,
          "method_standard": "Large sample (1 g) DSC",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_3",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_3 | P/M | unary | 28 pts | GLOBlit_1445\n\n### Reference\n**lit_id:** 2014-zhe-gao-0\n**Title:** Isobaric heat capacity measurements of liquid HFE-7200 and HFE-7500 from 245 to 353 K at pressures up to 15 MPa\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_3 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_12 | flow_calorimetry | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n| BLKvar_2 | GLOBvar_3 | pressure_kpa |  | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): T: 294.2–353.26, P: 100.0–15000.0 | 28 pts → 26 kept (RDP)\n| T(K) | P(kPa) | Cp(J/K/mol) | ±U |\n|---|---|---|---|\n| 294.24 | 100.0 | 74.96158008 | 3.00855176 |\n| 294.2 | 10000.0 | 73.70051048 | 2.95450592 |\n| 294.27 | 15000.0 | 74.6733356 | 2.99053648 |\n| 303.93 | 100.0 | 75.42997736 | 3.02656704 |\n| 303.97 | 5000.0 | 75.33990096 | 3.00855176 |\n| 303.98 | 10000.0 | 75.05165648 | 3.00855176 |\n| 303.97 | 15000.0 | 76.00646632 | 3.04458232 |\n| 313.68 | 100.0 | 76.43883304 | 3.0625976 |\n| 313.69 | 5000.0 | 76.0244816 | 3.04458232 |\n| 313.68 | 10000.0 | 75.9344052 | 3.04458232 |\n| 313.69 | 15000.0 | 75.82631352 | 3.02656704 |\n| 323.43 | 100.0 | 76.27669552 | 3.04458232 |\n| 323.43 | 10000.0 | 75.46600792 | 3.02656704 |\n| 323.43 | 15000.0 | 74.96158008 | 3.00855176 |\n| 333.33 | 100.0 | 75.89837464 | 3.04458232 |\n| 333.33 | 5000.0 | 75.46600792 | 3.02656704 |\n| 333.33 | 10000.0 | 75.23180928 | 3.00855176 |\n| 333.33 | 15000.0 | 75.10570232 | 3.00855176 |\n| 343.28 | 100.0 | 76.31272608 | 3.0625976 |\n| 343.28 | 5000.0 | 75.95242048 | 3.04458232 |\n| 343.28 | 10000.0 | 75.28585512 | 3.00855176 |\n| 343.28 | 15000.0 | 75.06967176 | 3.00855176 |\n| 353.26 | 100.0 | 76.04249688 | 3.04458232 |\n| 353.25 | 5000.0 | 75.8443288 | 3.04458232 |\n| 353.25 | 10000.0 | 75.62814544 | 3.02656704 |\n| 353.25 | 15000.0 | 75.24982456 | 3.00855176 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "constraints": [],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {},
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Flow calorimetry"
        ],
        "n_points": 28,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 76.438833,
            "mean": 75.496891,
            "min": 73.70051,
            "n": 28,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.59354
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 353.26,
            "min": 294.2,
            "n_unique": 13,
            "name": "Temperature, K"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 15000.0,
            "min": 100.0,
            "n_unique": 4,
            "name": "Pressure, kPa"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1016/j.fluid.2014.03.017",
      "lit_num_id": "GLOBlit_1445",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 28,
      "paper_title": "Isobaric heat capacity measurements of liquid HFE-7200 and HFE-7500 from 245 to 353 K at pressures up to 15 MPa",
      "parent_n_datapoints": 28,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "flow_calorimetry",
          "meas_num_id": "GLOBmeas_12",
          "method_custom": null,
          "method_standard": "Flow calorimetry",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": null,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "var_id": "pressure_kpa",
          "var_num_id": "GLOBvar_3"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_2",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_2 | P/M | unary | 9 pts | GLOBlit_1986\n\n### Reference\n**lit_id:** 2017-was-tka-0\n**Title:** Heat capacity and phase behaviour of aqueous solutions of triethylene glycol monopentyl ether. Two point scaling analysis\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_132 | dsc | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(1 extrema) | 9 pts → 8 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 278.15 | 75.750649344 | 2.934689112 |\n| 283.15 | 75.584908768 | 2.927483 |\n| 288.15 | 75.467809448 | 2.922078416 |\n| 298.15 | 75.345305544 | 2.91847536 |\n| 308.15 | 75.316481096 | 2.916673832 |\n| 318.15 | 75.343504016 | 2.91847536 |\n| 328.15 | 75.401152912 | 2.920276888 |\n| 333.15 | 75.482221672 | 2.923879944 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "DSC"
        ],
        "n_points": 9,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 75.750649,
            "mean": 75.453798,
            "min": 75.316481,
            "n": 9,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.139499
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 333.15,
            "min": 278.15,
            "n_unique": 9,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1016/j.fluid.2016.10.005",
      "lit_num_id": "GLOBlit_1986",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 9,
      "paper_title": "Heat capacity and phase behaviour of aqueous solutions of triethylene glycol monopentyl ether. Two point scaling analysis",
      "parent_n_datapoints": 9,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "dsc",
          "meas_num_id": "GLOBmeas_132",
          "method_custom": "DSC",
          "method_standard": null,
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_1",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_1 | P/M | unary | 15 pts | GLOBlit_2622\n\n### Reference\n**lit_id:** 2006-lou-san-0\n**Title:** Isobaric specific heat capacity of water and aqueous cesium chloride solutions for temperatures between 298K and 370K at p = 0.1 MPa\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_31 | large_sample_1g_dsc | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(6 extrema) | 15 pts → 9 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 299.62 | 74.956175496 | 1.34210232944 |\n| 304.09 | 75.156145104 | 1.34570538544 |\n| 315.16 | 75.035442728 | 1.34390385744 |\n| 325.02 | 74.318434584 | 1.33129316144 |\n| 330.16 | 74.73638908 | 1.33849927344 |\n| 345.04 | 75.239015392 | 1.34750691344 |\n| 350.2 | 75.903779224 | 1.36020768584 |\n| 365.21 | 75.566893488 | 1.35469501016 |\n| 370.11 | 75.855137968 | 1.35840615784 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 6,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.325
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 6,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.325
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Large sample (1 g) DSC"
        ],
        "n_points": 15,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 75.903779,
            "mean": 75.199021,
            "min": 74.318435,
            "n": 15,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.471508
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 370.11,
            "min": 299.62,
            "n_unique": 15,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1016/j.jct.2005.10.010",
      "lit_num_id": "GLOBlit_2622",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 15,
      "paper_title": "Isobaric specific heat capacity of water and aqueous cesium chloride solutions for temperatures between 298K and 370K at p = 0.1 MPa",
      "parent_n_datapoints": 15,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "large_sample_1g_dsc",
          "meas_num_id": "GLOBmeas_31",
          "method_custom": null,
          "method_standard": "Large sample (1 g) DSC",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_1",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_1 | P/M | unary | 6 pts | GLOBlit_3019\n\n### Reference\n**lit_id:** 2009-gar-tro-0\n**Title:** Excess enthalpy, density, and heat capacity for binary systems of alkylimidazolium-based ionic liquids + water\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_9 | small_sample_50mg_dsc | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(0 extrema) | 6 pts → 6 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 293.15 | 75.4 | 1.2 |\n| 298.15 | 75.3 | 1.2 |\n| 303.15 | 75.3 | 1.2 |\n| 308.15 | 75.2 | 1.2 |\n| 313.15 | 75.2 | 1.2 |\n| 318.15 | 75.3 | 1.2 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 6,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.325
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 6,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.325
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Small sample (50 mg) DSC"
        ],
        "n_points": 6,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 75.4,
            "mean": 75.283333,
            "min": 75.2,
            "n": 6,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.075277
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 318.15,
            "min": 293.15,
            "n_unique": 6,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1016/j.jct.2008.10.002",
      "lit_num_id": "GLOBlit_3019",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 6,
      "paper_title": "Excess enthalpy, density, and heat capacity for binary systems of alkylimidazolium-based ionic liquids + water",
      "parent_n_datapoints": 6,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "small_sample_50mg_dsc",
          "meas_num_id": "GLOBmeas_9",
          "method_custom": null,
          "method_standard": "Small sample (50 mg) DSC",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_8",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_8 | P/M | unary | 16 pts | GLOBlit_3054\n\n### Reference\n**lit_id:** 2009-ano-cai-1\n**Title:** Liquid densities, heat capacities, refractive index and excess quantities for {protic ionic liquids + water} binary system \n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_6 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_9 | small_sample_50mg_dsc | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.325 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(1 extrema) | 16 pts → 11 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 298.15 | 75.32188568 | 9.0977164 |\n| 303.15 | 75.28585512 | 9.0977164 |\n| 308.15 | 75.26783984 | 9.0977164 |\n| 313.15 | 75.28585512 | 9.0977164 |\n| 318.15 | 75.32188568 | 9.0977164 |\n| 328.15 | 75.35791624 | 9.0977164 |\n| 333.15 | 75.3939468 | 9.11573168 |\n| 348.15 | 75.55608432 | 9.13374696 |\n| 353.15 | 75.62814544 | 9.13374696 |\n| 368.15 | 75.89837464 | 9.16977752 |\n| 373.15 | 76.00646632 | 9.1877928 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 6,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.325
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 6,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.325
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Small sample (50 mg) DSC"
        ],
        "n_points": 16,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 76.006466,
            "mean": 75.508794,
            "min": 75.26784,
            "n": 16,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.237353
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 373.15,
            "min": 298.15,
            "n_unique": 16,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1016/j.jct.2009.01.011",
      "lit_num_id": "GLOBlit_3054",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 16,
      "paper_title": "Liquid densities, heat capacities, refractive index and excess quantities for {protic ionic liquids + water} binary system ",
      "parent_n_datapoints": 16,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "small_sample_50mg_dsc",
          "meas_num_id": "GLOBmeas_9",
          "method_custom": null,
          "method_standard": "Small sample (50 mg) DSC",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_1",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_1 | P/M | unary | 1 pts | GLOBlit_4832\n\n### Reference\n**lit_id:** 2017-gao-li-1\n**Title:** Solubility of RbCl and CsCl in pure water at subzero temperatures, heat capacity of RbCl(aq) and CsCl(aq) at T = 298.15 K, and thermodynamic modeling of RbCl + H2O and CsCl + H2O systems\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_4 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_12 | flow_calorimetry | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n| BLKvar_2 | GLOBvar_3 | pressure_kpa |  | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): T: 298.15–298.15, P: 101.325–101.325 | 1 pts → 1 kept (RDP)\n| T(K) | P(kPa) | Cp(J/K/mol) | ±U |\n|---|---|---|---|\n| 298.15 | 101.325 | 75.11470996 | 1.506077408 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {},
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Flow calorimetry"
        ],
        "n_points": 1,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 75.11471,
            "mean": 75.11471,
            "min": 75.11471,
            "n": 1,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 298.15,
            "min": 298.15,
            "n_unique": 1,
            "name": "Temperature, K"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 101.325,
            "min": 101.325,
            "n_unique": 1,
            "name": "Pressure, kPa"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1016/j.jct.2016.09.031",
      "lit_num_id": "GLOBlit_4832",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 1,
      "paper_title": "Solubility of RbCl and CsCl in pure water at subzero temperatures, heat capacity of RbCl(aq) and CsCl(aq) at T = 298.15 K, and thermodynamic modeling of RbCl + H2O and CsCl + H2O systems",
      "parent_n_datapoints": 1,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "flow_calorimetry",
          "meas_num_id": "GLOBmeas_12",
          "method_custom": null,
          "method_standard": "Flow calorimetry",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": null,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "var_id": "pressure_kpa",
          "var_num_id": "GLOBvar_3"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_1",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_1 | P/M | unary | 14 pts | GLOBlit_7221\n\n### Reference\n**lit_id:** 2017-yi-hu-0\n**Title:** A Temperature-Dependent Thermodynamic Model Derived from Heat Capacity of Metal Chloride Aqueous Solutions\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_3 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_12 | flow_calorimetry | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 100.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(0 extrema) | 14 pts → 9 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 298.15 | 75.664176 | 0.16213752 |\n| 303.15 | 75.5740996 | 0.16213752 |\n| 318.15 | 75.46600792 | 0.16213752 |\n| 323.15 | 75.44799264 | 0.16213752 |\n| 333.15 | 75.46600792 | 0.16213752 |\n| 338.15 | 75.50203848 | 0.16213752 |\n| 348.15 | 75.664176 | 0.16213752 |\n| 353.15 | 75.77226768 | 0.16213752 |\n| 363.15 | 76.0244816 | 0.16213752 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 1,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 100.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 1,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 100.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Flow calorimetry"
        ],
        "n_points": 14,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 76.024482,
            "mean": 75.61013,
            "min": 75.447993,
            "n": 14,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.178062
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 363.15,
            "min": 298.15,
            "n_unique": 14,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1021/acs.jced.7b00483",
      "lit_num_id": "GLOBlit_7221",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 14,
      "paper_title": "A Temperature-Dependent Thermodynamic Model Derived from Heat Capacity of Metal Chloride Aqueous Solutions",
      "parent_n_datapoints": 14,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "flow_calorimetry",
          "meas_num_id": "GLOBmeas_12",
          "method_custom": null,
          "method_standard": "Flow calorimetry",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_5",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_5 | P/M | unary | 6 pts | GLOBlit_7754\n\n### Reference\n**lit_id:** 2019-kes-nin-0\n**Title:** Physicochemical Properties of the System N,N-Dimethyl-dipropylene-diamino-triacetonediamine (EvA34), Water, and Carbon Dioxide for Reactive Absorption\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_132 | dsc | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 100.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(1 extrema) | 6 pts → 6 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 298.15 | 74.79944256 | 3.45893376 |\n| 308.15 | 74.78142728 | 3.5129796 |\n| 318.15 | 74.92554952 | 3.5129796 |\n| 328.15 | 75.01562592 | 3.53099488 |\n| 338.15 | 75.06967176 | 3.49496432 |\n| 348.15 | 75.213794 | 3.56702544 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 1,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 100.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 1,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 100.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "DSC"
        ],
        "n_points": 6,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 75.213794,
            "mean": 74.967585,
            "min": 74.781427,
            "n": 6,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.166158
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 348.15,
            "min": 298.15,
            "n_unique": 6,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1021/acs.jced.8b01174",
      "lit_num_id": "GLOBlit_7754",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 6,
      "paper_title": "Physicochemical Properties of the System N,N-Dimethyl-dipropylene-diamino-triacetonediamine (EvA34), Water, and Carbon Dioxide for Reactive Absorption",
      "parent_n_datapoints": 6,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "dsc",
          "meas_num_id": "GLOBmeas_132",
          "method_custom": "DSC",
          "method_standard": null,
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_1",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_1 | P/M | unary | 7 pts | GLOBlit_11179\n\n### Reference\n**lit_id:** 2008-fic-rod-0\n**Title:** Heat Capacities and Excess Enthalpies of 1-Ethyl-3-methylimidazolium-Based Ionic Liquids and Water\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_9 | molar_heat_capacity_at_constant_pressure_j_k_mol | GLOBmeas_9 | small_sample_50mg_dsc | HeatCapacityAndDerivedProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_1 | temperature_k |  | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.3 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** constant | 7 pts → 2 kept (RDP)\n| T(K) | Cp(J/K/mol) | ±U |\n|---|---|---|\n| 283.15 | 75.0 | 6.0 |\n| 343.15 | 75.0 | 6.0 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 4,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.3
        }
      ],
      "data_summary": {
        "compound_names": [
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 4,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.3
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Small sample (50 mg) DSC"
        ],
        "n_points": 7,
        "phases": [
          "Liquid"
        ],
        "property_group": "HeatCapacityAndDerivedProp",
        "property_names": [
          "Molar heat capacity at constant pressure, J/K/mol"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 75.0,
            "mean": 75.0,
            "min": 75.0,
            "n": 7,
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "std": 0.0
          }
        },
        "system_type": "unary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 343.15,
            "min": 283.15,
            "n_unique": 7,
            "name": "Temperature, K"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "declared_system_type": "unary",
      "doi": "10.1021/je800248w",
      "lit_num_id": "GLOBlit_11179",
      "match_criteria": [
        "compound",
        "property",
        "system_type",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 7,
      "paper_title": "Heat Capacities and Excess Enthalpies of 1-Ethyl-3-methylimidazolium-Based Ionic Liquids and Water",
      "parent_n_datapoints": 7,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "HeatCapacityAndDerivedProp",
          "meas_ID": "small_sample_50mg_dsc",
          "meas_num_id": "GLOBmeas_9",
          "method_custom": null,
          "method_standard": "Small sample (50 mg) DSC",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "prop_num_id": "GLOBprop_9",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [],
      "system_type": "unary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": null,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "var_id": "temperature_k",
          "var_num_id": "GLOBvar_1"
        }
      ]
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
search_blocks: 10 search targets found.

| # | DOI | Block | Target | System | Points | Properties | Score |
|---|-----|-------|--------|--------|--------|------------|-------|
| 1 | 10.1016/j.fluid.2013.08.005 | PROPblock_1 | declared | unary | 8 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 2 | 10.1016/j.fluid.2014.03.017 | PROPblock_3 | declared | unary | 28 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 3 | 10.1016/j.fluid.2016.10.005 | PROPblock_2 | declared | unary | 9 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 4 | 10.1016/j.jct.2005.10.010 | PROPblock_1 | declared | unary | 15 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 5 | 10.1016/j.jct.2008.10.002 | PROPblock_1 | declared | unary | 6 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 6 | 10.1016/j.jct.2009.01.011 | PROPblock_8 | declared | unary | 16 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 7 | 10.1016/j.jct.2016.09.031 | PROPblock_1 | declared | unary | 1 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 8 | 10.1021/acs.jced.7b00483 | PROPblock_1 | declared | unary | 14 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 9 | 10.1021/acs.jced.8b01174 | PROPblock_5 | declared | unary | 6 | Molar heat capacity at constant pressure, J/K/mol | 100 |
| 10 | 10.1021/je800248w | PROPblock_1 | declared | unary | 7 | Molar heat capacity at constant pressure, J/K/mol | 100 |

---
## PROPblock_1 | P/M | unary | 8 pts | GLOBlit_1310  [**10.1016/j.fluid.2013.08.005 / PROPblock_1**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_31
**Variables:** GLOBvar_1
**Ranges:** T(K) [298.15..313.15], Cp(J/K/mol) [75.3165..75.3687]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 8
**Topology:** non-monotonic(4 extrema) | 8 pts → 8 kept (RDP)

---
## PROPblock_3 | P/M | unary | 28 pts | GLOBlit_1445  [**10.1016/j.fluid.2014.03.017 / PROPblock_3**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_12
**Variables:** GLOBvar_1, GLOBvar_3
**Ranges:** T(K) [294.2..353.26], P(kPa) [100..15000], Cp(J/K/mol) [73.7005..76.4388]
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 26
**Topology:** multi-variable(2): T: 294.2–353.26, P: 100.0–15000.0 | 28 pts → 26 kept (RDP)

---
## PROPblock_2 | P/M | unary | 9 pts | GLOBlit_1986  [**10.1016/j.fluid.2016.10.005 / PROPblock_2**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_132
**Variables:** GLOBvar_1
**Ranges:** T(K) [278.15..333.15], Cp(J/K/mol) [75.3165..75.7506]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 8
**Topology:** non-monotonic(1 extrema) | 9 pts → 8 kept (RDP)

---
## PROPblock_1 | P/M | unary | 15 pts | GLOBlit_2622  [**10.1016/j.jct.2005.10.010 / PROPblock_1**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_31
**Variables:** GLOBvar_1
**Ranges:** T(K) [299.62..370.11], Cp(J/K/mol) [74.3184..75.9038]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 9
**Topology:** non-monotonic(6 extrema) | 15 pts → 9 kept (RDP)

---
## PROPblock_1 | P/M | unary | 6 pts | GLOBlit_3019  [**10.1016/j.jct.2008.10.002 / PROPblock_1**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_9
**Variables:** GLOBvar_1
**Ranges:** T(K) [293.15..318.15], Cp(J/K/mol) [75.2..75.4]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 6
**Topology:** non-monotonic(0 extrema) | 6 pts → 6 kept (RDP)

---
## PROPblock_8 | P/M | unary | 16 pts | GLOBlit_3054  [**10.1016/j.jct.2009.01.011 / PROPblock_8**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_9
**Variables:** GLOBvar_1
**Ranges:** T(K) [298.15..373.15], Cp(J/K/mol) [75.2678..76.0065]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 11
**Topology:** non-monotonic(1 extrema) | 16 pts → 11 kept (RDP)

---
## PROPblock_1 | P/M | unary | 1 pts | GLOBlit_4832  [**10.1016/j.jct.2016.09.031 / PROPblock_1**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_12
**Variables:** GLOBvar_1, GLOBvar_3
**Ranges:** T(K)=298.15, P(kPa)=101.325, Cp(J/K/mol)=75.1147
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 1
**Topology:** multi-variable(2): T: 298.15–298.15, P: 101.325–101.325 | 1 pts → 1 kept (RDP)

---
## PROPblock_1 | P/M | unary | 14 pts | GLOBlit_7221  [**10.1021/acs.jced.7b00483 / PROPblock_1**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_12
**Variables:** GLOBvar_1
**Ranges:** T(K) [298.15..363.15], Cp(J/K/mol) [75.448..76.0245]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 9
**Topology:** non-monotonic(0 extrema) | 14 pts → 9 kept (RDP)

---
## PROPblock_5 | P/M | unary | 6 pts | GLOBlit_7754  [**10.1021/acs.jced.8b01174 / PROPblock_5**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_132
**Variables:** GLOBvar_1
**Ranges:** T(K) [298.15..348.15], Cp(J/K/mol) [74.7814..75.2138]
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 6
**Topology:** non-monotonic(1 extrema) | 6 pts → 6 kept (RDP)

---
## PROPblock_1 | P/M | unary | 7 pts | GLOBlit_11179  [**10.1021/je800248w / PROPblock_1**]
**Compounds:** GLOBcomp_1
**Properties:** GLOBprop_9
**Methods:** GLOBmeas_9
**Variables:** GLOBvar_1
**Ranges:** T(K) [283.15..343.15], Cp(J/K/mol)=75
**Constraints:** GLOBconstr_1=pressure_kpa
**Phases:** Liquid
**Unc:** k=95%, Propagation, compiler
**Points:** 2
**Topology:** constant | 7 pts → 2 kept (RDP)

```

### Model-visible result

```markdown
**Summary:** 10 blocks found, all containing molar heat capacity at constant pressure (GLOBprop_9) for pure liquid water (GLOBcomp_1) in the liquid phase near 298.15 K. All scored 100. The most precise single-point datum at exactly 298.15 K / 101.325 kPa gives Cp = 75.1147 J/K/mol.

| DOI | Block | GLOBlit | T range (K) | P info | Cp range (J/K/mol) | Pts (kept) |
|-----|-------|---------|-------------|--------|---------------------|------------|
| 10.1016/j.jct.2016.09.031 | PROPblock_1 | GLOBlit_4832 | 298.15 | 101.325 kPa | 75.1147 | 1 |
| 10.1016/j.fluid.2013.08.005 | PROPblock_1 | GLOBlit_1310 | 298.15–313.15 | constr P | 75.3165–75.3687 | 8 |
| 10.1016/j.jct.2008.10.002 | PROPblock_1 | GLOBlit_3019 | 293.15–318.15 | constr P | 75.2–75.4 | 6 |
| 10.1016/j.jct.2009.01.011 | PROPblock_8 | GLOBlit_3054 | 298.15–373.15 | constr P | 75.2678–76.0065 | 11 |
| 10.1016/j.fluid.2016.10.005 | PROPblock_2 | GLOBlit_1986 | 278.15–333.15 | constr P | 75.3165–75.7506 | 8 |
| 10.1021/acs.jced.7b00483 | PROPblock_1 | GLO
```

### Integrity and timing

- Raw SHA-256: 1a7fa61373cbb174909ac23ecf49fd53b4ff185ce0ca0264568e5a06c45931bf
- Raw characters: 66666
- Hardcoded-compacted characters: 5937
- Model-visible characters: 1024
- Agentic verdict: KEEP
- Tool elapsed: 10.356s
- Compactor elapsed: 14.018s
- Total elapsed: 24.381s

## Step 6: inspect_block_table

### Call arguments

```json
{
  "block_number": "GLOBlit_4832::PROPblock_1",
  "purpose": "Get the exact Cp value for pure liquid water at 298.15 K from this block",
  "tasks": [
    "Retrieve the measured molar heat capacity at constant pressure for water at 298.15 K and 101.325 kPa"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `inspect_block_table`

Serialization: `json`

```json
{
  "BLKsubsys_id": null,
  "block_number": "PROPblock_1",
  "bracket": null,
  "column_aliases": {
    "molar_heat_capacity_at_constant_pressure_j_k_mol": "molar_heat_capacity_at_constant_pressure_j_k_mol",
    "pressure_kpa": "pressure_kpa",
    "temperature_k": "temperature_k"
  },
  "columns": [
    "BLKpoint_id",
    "temperature_k",
    "pressure_kpa",
    "molar_heat_capacity_at_constant_pressure_j_k_mol"
  ],
  "compounds": [
    "water"
  ],
  "constraints": [],
  "doi": "10.1016/j.jct.2016.09.031",
  "error": null,
  "inspection_id": "INSP_19899535d833",
  "lit_num_id": "GLOBlit_4832",
  "markdown": "**Data inspection** — 10.1016/j.jct.2016.09.031 :: PROPblock_1 (unary: water)\nfilter: none (whole block)\n\n| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |\n|---|---|---|---|\n| BLKpoint_1 | 298.15 | 101.325 | 75.11470996 |\n\nmode: complete — all 1 matched rows shown (block has 1)\nstats (matched, n=1): temperature_k 298.15–298.15 (n=1); pressure_kpa 101.325–101.325 (n=1); molar_heat_capacity_at_constant_pressure_j_k_mol 75.11470996–75.11470996 (n=1)\ninspection_id: INSP_19899535d833\nData points may be quoted ONLY verbatim from the table above or the stats lines.",
  "n_rows_matched": 1,
  "n_rows_shown": 1,
  "n_rows_total": 1,
  "nearest": null,
  "rows_shown": [
    {
      "BLKpoint_id": "BLKpoint_1",
      "molar_heat_capacity_at_constant_pressure_j_k_mol": "75.11470996",
      "pressure_kpa": "101.325",
      "temperature_k": "298.15"
    }
  ],
  "stats": {
    "full": {
      "molar_heat_capacity_at_constant_pressure_j_k_mol": {
        "max": "75.11470996",
        "min": "75.11470996",
        "n": 1,
        "n_finite": 1
      },
      "pressure_kpa": {
        "max": "101.325",
        "min": "101.325",
        "n": 1,
        "n_finite": 1
      },
      "temperature_k": {
        "max": "298.15",
        "min": "298.15",
        "n": 1,
        "n_finite": 1
      }
    },
    "matched": {
      "molar_heat_capacity_at_constant_pressure_j_k_mol": {
        "max": "75.11470996",
        "min": "75.11470996",
        "n": 1,
        "n_finite": 1
      },
      "pressure_kpa": {
        "max": "101.325",
        "min": "101.325",
        "n": 1,
        "n_finite": 1
      },
      "temperature_k": {
        "max": "298.15",
        "min": "298.15",
        "n": 1,
        "n_finite": 1
      }
    }
  },
  "system_type": "unary",
  "table_mode": "complete",
  "tool": "inspect_block_table",
  "topology": [],
  "where": null
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
**Data inspection** — 10.1016/j.jct.2016.09.031 :: PROPblock_1 (unary: water)
filter: none (whole block)

| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |
|---|---|---|---|
| BLKpoint_1 | 298.15 | 101.325 | 75.11470996 |

mode: complete — all 1 matched rows shown (block has 1)
stats (matched, n=1): temperature_k 298.15–298.15 (n=1); pressure_kpa 101.325–101.325 (n=1); molar_heat_capacity_at_constant_pressure_j_k_mol 75.11470996–75.11470996 (n=1)
inspection_id: INSP_19899535d833
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Model-visible result

```markdown
**Data inspection** — 10.1016/j.jct.2016.09.031 :: PROPblock_1 (unary: water)
filter: none (whole block)

| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |
|---|---|---|---|
| BLKpoint_1 | 298.15 | 101.325 | 75.11470996 |

mode: complete — all 1 matched rows shown (block has 1)
stats (matched, n=1): temperature_k 298.15–298.15 (n=1); pressure_kpa 101.325–101.325 (n=1); molar_heat_capacity_at_constant_pressure_j_k_mol 75.11470996–75.11470996 (n=1)
inspection_id: INSP_19899535d833
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Integrity and timing

- Raw SHA-256: 6e4854288753b95f8c46756464853439e046083d30d8a0abd4e46646eec86442
- Raw characters: 2619
- Hardcoded-compacted characters: 612
- Model-visible characters: 612
- Agentic verdict: SKIP
- Tool elapsed: 0.067s
- Compactor elapsed: 0.000s
- Total elapsed: 0.067s

## Step 7: inspect_block_table

### Call arguments

```json
{
  "block_number": "GLOBlit_1310::PROPblock_1",
  "nearest": {
    "column": "temperature_k",
    "value": 298.15,
    "k": 2
  },
  "purpose": "Get Cp values for pure liquid water near 298.15 K from a second source",
  "tasks": [
    "Retrieve the measured molar heat capacity at constant pressure for water at or near 298.15 K"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `inspect_block_table`

Serialization: `json`

```json
{
  "BLKsubsys_id": null,
  "block_number": "PROPblock_1",
  "bracket": {
    "above": {
      "BLKpoint_id": "BLKpoint_1",
      "value": "298.15"
    },
    "below": {
      "BLKpoint_id": "BLKpoint_5",
      "value": "298.15"
    },
    "column": "temperature_k",
    "exact_match": true,
    "statement": "exact row(s) at temperature_k = 298.15 exist in the matched set",
    "target": 298.15
  },
  "column_aliases": {
    "molar_heat_capacity_at_constant_pressure_j_k_mol": "molar_heat_capacity_at_constant_pressure_j_k_mol",
    "pressure_kpa": "pressure_kpa",
    "temperature_k": "temperature_k"
  },
  "columns": [
    "BLKpoint_id",
    "temperature_k",
    "pressure_kpa",
    "molar_heat_capacity_at_constant_pressure_j_k_mol"
  ],
  "compounds": [
    "water"
  ],
  "constraints": [
    {
      "column": "pressure_kpa",
      "value": 101.0
    }
  ],
  "doi": "10.1016/j.fluid.2013.08.005",
  "error": null,
  "inspection_id": "INSP_e62cf6b16571",
  "lit_num_id": "GLOBlit_1310",
  "markdown": "**Data inspection** — 10.1016/j.fluid.2013.08.005 :: PROPblock_1 (unary: water)\nfilter: nearest temperature_k ≈ 298.15 (k=2)\nblock constraints: pressure_kpa = 101.0\n\n| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |\n|---|---|---|---|\n| BLKpoint_1 | 298.15 | 101.0 | 75.368725408 |\n| BLKpoint_5 | 298.15 | 101.0 | 75.350710128 |\n\nmode: nearest — 2 row(s) of 8 matched (block has 8)\nbracket: exact row(s) at temperature_k = 298.15 exist in the matched set\ntopology: molar_heat_capacity_at_constant_pressure_j_k_mol vs temperature_k: non-monotonic(4 extrema)\nstats (matched, n=8): temperature_k 298.15–313.15 (n=8); pressure_kpa 101.0–101.0 (n=8); molar_heat_capacity_at_constant_pressure_j_k_mol 75.316481096–75.368725408 (n=8)\ninspection_id: INSP_e62cf6b16571\nData points may be quoted ONLY verbatim from the table above or the stats lines.",
  "n_rows_matched": 8,
  "n_rows_shown": 2,
  "n_rows_total": 8,
  "nearest": {
    "column": "temperature_k",
    "k": 2,
    "value": 298.15
  },
  "rows_shown": [
    {
      "BLKpoint_id": "BLKpoint_1",
      "molar_heat_capacity_at_constant_pressure_j_k_mol": "75.368725408",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_5",
      "molar_heat_capacity_at_constant_pressure_j_k_mol": "75.350710128",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    }
  ],
  "stats": {
    "full": {
      "molar_heat_capacity_at_constant_pressure_j_k_mol": {
        "max": "75.368725408",
        "min": "75.316481096",
        "n": 8,
        "n_finite": 8
      },
      "pressure_kpa": {
        "max": "101.0",
        "min": "101.0",
        "n": 8,
        "n_finite": 8
      },
      "temperature_k": {
        "max": "313.15",
        "min": "298.15",
        "n": 8,
        "n_finite": 8
      }
    },
    "matched": {
      "molar_heat_capacity_at_constant_pressure_j_k_mol": {
        "max": "75.368725408",
        "min": "75.316481096",
        "n": 8,
        "n_finite": 8
      },
      "pressure_kpa": {
        "max": "101.0",
        "min": "101.0",
        "n": 8,
        "n_finite": 8
      },
      "temperature_k": {
        "max": "313.15",
        "min": "298.15",
        "n": 8,
        "n_finite": 8
      }
    }
  },
  "system_type": "unary",
  "table_mode": "nearest",
  "tool": "inspect_block_table",
  "topology": [
    {
      "property": "molar_heat_capacity_at_constant_pressure_j_k_mol",
      "shape": "non-monotonic(4 extrema)",
      "vs": "temperature_k"
    }
  ],
  "where": null
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
**Data inspection** — 10.1016/j.fluid.2013.08.005 :: PROPblock_1 (unary: water)
filter: nearest temperature_k ≈ 298.15 (k=2)
block constraints: pressure_kpa = 101.0

| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |
|---|---|---|---|
| BLKpoint_1 | 298.15 | 101.0 | 75.368725408 |
| BLKpoint_5 | 298.15 | 101.0 | 75.350710128 |

mode: nearest — 2 row(s) of 8 matched (block has 8)
bracket: exact row(s) at temperature_k = 298.15 exist in the matched set
topology: molar_heat_capacity_at_constant_pressure_j_k_mol vs temperature_k: non-monotonic(4 extrema)
stats (matched, n=8): temperature_k 298.15–313.15 (n=8); pressure_kpa 101.0–101.0 (n=8); molar_heat_capacity_at_constant_pressure_j_k_mol 75.316481096–75.368725408 (n=8)
inspection_id: INSP_e62cf6b16571
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Model-visible result

```markdown
**Data inspection** — 10.1016/j.fluid.2013.08.005 :: PROPblock_1 (unary: water)
filter: nearest temperature_k ≈ 298.15 (k=2)
block constraints: pressure_kpa = 101.0

| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |
|---|---|---|---|
| BLKpoint_1 | 298.15 | 101.0 | 75.368725408 |
| BLKpoint_5 | 298.15 | 101.0 | 75.350710128 |

mode: nearest — 2 row(s) of 8 matched (block has 8)
bracket: exact row(s) at temperature_k = 298.15 exist in the matched set
topology: molar_heat_capacity_at_constant_pressure_j_k_mol vs temperature_k: non-monotonic(4 extrema)
stats (matched, n=8): temperature_k 298.15–313.15 (n=8); pressure_kpa 101.0–101.0 (n=8); molar_heat_capacity_at_constant_pressure_j_k_mol 75.316481096–75.368725408 (n=8)
inspection_id: INSP_e62cf6b16571
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Integrity and timing

- Raw SHA-256: 6d2fa94526491710fcc118e385d13df0f55c92ab73468bf6b0c2b84cbcc5ef88
- Raw characters: 3691
- Hardcoded-compacted characters: 887
- Model-visible characters: 887
- Agentic verdict: SKIP
- Tool elapsed: 0.059s
- Compactor elapsed: 0.000s
- Total elapsed: 0.060s

## Step 8: inspect_block_table

### Call arguments

```json
{
  "block_number": "GLOBlit_3019::PROPblock_1",
  "nearest": {
    "column": "temperature_k",
    "value": 298.15,
    "k": 2
  },
  "purpose": "Get Cp values for pure liquid water near 298.15 K from a third source",
  "tasks": [
    "Retrieve the measured molar heat capacity at constant pressure for water at or near 298.15 K"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `inspect_block_table`

Serialization: `json`

```json
{
  "BLKsubsys_id": null,
  "block_number": "PROPblock_1",
  "bracket": {
    "above": {
      "BLKpoint_id": "BLKpoint_2",
      "value": "298.15"
    },
    "below": {
      "BLKpoint_id": "BLKpoint_2",
      "value": "298.15"
    },
    "column": "temperature_k",
    "exact_match": true,
    "statement": "exact row(s) at temperature_k = 298.15 exist in the matched set",
    "target": 298.15
  },
  "column_aliases": {
    "molar_heat_capacity_at_constant_pressure_j_k_mol": "molar_heat_capacity_at_constant_pressure_j_k_mol",
    "pressure_kpa": "pressure_kpa",
    "temperature_k": "temperature_k"
  },
  "columns": [
    "BLKpoint_id",
    "temperature_k",
    "pressure_kpa",
    "molar_heat_capacity_at_constant_pressure_j_k_mol"
  ],
  "compounds": [
    "water"
  ],
  "constraints": [
    {
      "column": "pressure_kpa",
      "value": 101.325
    }
  ],
  "doi": "10.1016/j.jct.2008.10.002",
  "error": null,
  "inspection_id": "INSP_fdb87e8cd370",
  "lit_num_id": "GLOBlit_3019",
  "markdown": "**Data inspection** — 10.1016/j.jct.2008.10.002 :: PROPblock_1 (unary: water)\nfilter: nearest temperature_k ≈ 298.15 (k=2)\nblock constraints: pressure_kpa = 101.325\n\n| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |\n|---|---|---|---|\n| BLKpoint_1 | 293.15 | 101.325 | 75.4 |\n| BLKpoint_2 | 298.15 | 101.325 | 75.3 |\n\nmode: nearest — 2 row(s) of 6 matched (block has 6)\nbracket: exact row(s) at temperature_k = 298.15 exist in the matched set\ntopology: molar_heat_capacity_at_constant_pressure_j_k_mol vs temperature_k: non-monotonic(0 extrema)\nstats (matched, n=6): temperature_k 293.15–318.15 (n=6); pressure_kpa 101.325–101.325 (n=6); molar_heat_capacity_at_constant_pressure_j_k_mol 75.2–75.4 (n=6)\ninspection_id: INSP_fdb87e8cd370\nData points may be quoted ONLY verbatim from the table above or the stats lines.",
  "n_rows_matched": 6,
  "n_rows_shown": 2,
  "n_rows_total": 6,
  "nearest": {
    "column": "temperature_k",
    "k": 2,
    "value": 298.15
  },
  "rows_shown": [
    {
      "BLKpoint_id": "BLKpoint_1",
      "molar_heat_capacity_at_constant_pressure_j_k_mol": "75.4",
      "pressure_kpa": "101.325",
      "temperature_k": "293.15"
    },
    {
      "BLKpoint_id": "BLKpoint_2",
      "molar_heat_capacity_at_constant_pressure_j_k_mol": "75.3",
      "pressure_kpa": "101.325",
      "temperature_k": "298.15"
    }
  ],
  "stats": {
    "full": {
      "molar_heat_capacity_at_constant_pressure_j_k_mol": {
        "max": "75.4",
        "min": "75.2",
        "n": 6,
        "n_finite": 6
      },
      "pressure_kpa": {
        "max": "101.325",
        "min": "101.325",
        "n": 6,
        "n_finite": 6
      },
      "temperature_k": {
        "max": "318.15",
        "min": "293.15",
        "n": 6,
        "n_finite": 6
      }
    },
    "matched": {
      "molar_heat_capacity_at_constant_pressure_j_k_mol": {
        "max": "75.4",
        "min": "75.2",
        "n": 6,
        "n_finite": 6
      },
      "pressure_kpa": {
        "max": "101.325",
        "min": "101.325",
        "n": 6,
        "n_finite": 6
      },
      "temperature_k": {
        "max": "318.15",
        "min": "293.15",
        "n": 6,
        "n_finite": 6
      }
    }
  },
  "system_type": "unary",
  "table_mode": "nearest",
  "tool": "inspect_block_table",
  "topology": [
    {
      "property": "molar_heat_capacity_at_constant_pressure_j_k_mol",
      "shape": "non-monotonic(0 extrema)",
      "vs": "temperature_k"
    }
  ],
  "where": null
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
**Data inspection** — 10.1016/j.jct.2008.10.002 :: PROPblock_1 (unary: water)
filter: nearest temperature_k ≈ 298.15 (k=2)
block constraints: pressure_kpa = 101.325

| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |
|---|---|---|---|
| BLKpoint_1 | 293.15 | 101.325 | 75.4 |
| BLKpoint_2 | 298.15 | 101.325 | 75.3 |

mode: nearest — 2 row(s) of 6 matched (block has 6)
bracket: exact row(s) at temperature_k = 298.15 exist in the matched set
topology: molar_heat_capacity_at_constant_pressure_j_k_mol vs temperature_k: non-monotonic(0 extrema)
stats (matched, n=6): temperature_k 293.15–318.15 (n=6); pressure_kpa 101.325–101.325 (n=6); molar_heat_capacity_at_constant_pressure_j_k_mol 75.2–75.4 (n=6)
inspection_id: INSP_fdb87e8cd370
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Model-visible result

```markdown
**Data inspection** — 10.1016/j.jct.2008.10.002 :: PROPblock_1 (unary: water)
filter: nearest temperature_k ≈ 298.15 (k=2)
block constraints: pressure_kpa = 101.325

| BLKpoint_id | temperature_k | pressure_kpa | molar_heat_capacity_at_constant_pressure_j_k_mol |
|---|---|---|---|
| BLKpoint_1 | 293.15 | 101.325 | 75.4 |
| BLKpoint_2 | 298.15 | 101.325 | 75.3 |

mode: nearest — 2 row(s) of 6 matched (block has 6)
bracket: exact row(s) at temperature_k = 298.15 exist in the matched set
topology: molar_heat_capacity_at_constant_pressure_j_k_mol vs temperature_k: non-monotonic(0 extrema)
stats (matched, n=6): temperature_k 293.15–318.15 (n=6); pressure_kpa 101.325–101.325 (n=6); molar_heat_capacity_at_constant_pressure_j_k_mol 75.2–75.4 (n=6)
inspection_id: INSP_fdb87e8cd370
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Integrity and timing

- Raw SHA-256: 1a3556baf5683b0aaa1e5d72e6b94159f0996b33c2e9f4b4abc0e8c41fb82f5a
- Raw characters: 3631
- Hardcoded-compacted characters: 863
- Model-visible characters: 863
- Agentic verdict: SKIP
- Tool elapsed: 0.081s
- Compactor elapsed: 0.000s
- Total elapsed: 0.082s

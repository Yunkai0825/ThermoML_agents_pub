# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 10
- **API turns:** 7
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 167.1s
- **Timed out:** False

## Answer

Now I have a comprehensive picture. Let me provide a thorough answer.

---

## Yes — Mean Ionic Activity Coefficients Have Been Measured for Aqueous LiCl at 25 °C

The ThermoML database contains **mean ionic activity coefficient (γ±)** data for the binary **lithium chloride + water** system at exactly **298.15 K** (25 °C) and **101.0 kPa**. Here is a summary of the evidence:

---

### Primary Dataset: Mean Ionic Activity Coefficient

**Source:** Zhao, Li, Zhai, Jiang & Hu, *Fluid Phase Equilib.* **382**, 127–132 (2014)
DOI: [10.1016/j.fluid.2014.08.026](https://doi.org/10.1016/j.fluid.2014.08.026)

- **Property:** Mean ionic activity coefficient of LiCl (GLOBprop_56)
- **Method:** Calculated from EMF (electromotive force) cell potential measurements (potentiometric method)
- **Block:** PROPblock_13 — 141 data points at 298.15 K, 101.0 kPa
- **Molality range:** **0.0033 to 1.5555 mol·kg⁻¹** (very dilute to moderately concentrated)
- **γ± range:** **0.7406 to 0.9425**

#### Representative Data Points (verbatim from the database):

| Molality (mol/kg) | γ± |
|---|---|
| 0.0033 | 0.9425 |
| 0.0109 | 0.9005 |
| 0.0494 | 0.8291 |
| 0.1339 | 0.7772 |
| 0.3285 | 0.7441 |
| 0.4919 | 0.7408 |
| 0.5927 | 0.7434 |
| 0.8141 | 0.7644 |
| 1.0961 | 0.7918 |
| 1.3645 | 0.8180 |
| 1.5555 | 0.8461 |

### Complementary Data: Osmotic Coefficients

Two additional sources provide **osmotic coefficient (φ)** data for binary LiCl + water at 298.15 K:

1. **Held, Reschke, Müller, Kunz & Sadowski**, *J. Chem. Thermodyn.* **68**, 1–12 (2014) — 4 points, molality 0.5–1.0 mol/kg, φ = 0.928–0.987 (vapor-pressure osmometry)
2. **A second source** (DOI: 10.1016/j.jct.2016.07.003) — 15 points, molality **0.91–4.67 mol/kg**, φ = 1.02–1.55 (isopiestic method), extending to higher concentrations

---

### Chemical Interpretation

The data beautifully illustrate the **characteristic non-monotonic behavior** of LiCl activity coefficients in water:

1. **Dilute regime (< ~0.5 mol/kg):** γ± decreases sharply from near unity (~0.94 at 0.003 m) as concentration increases, consistent with **Debye–Hückel theory** — long-range electrostatic ion–ion interactions stabilize the ions and lower their effective activity.

2. **Minimum (~0.4–0.6 mol/kg):** γ± reaches a minimum of about **0.74**, a hallmark of strong electrolytes where the transition from long-range to short-range interactions occurs.

3. **Concentrated regime (> ~0.6 mol/kg):** γ± **rises again**, reaching ~0.85 at 1.56 mol/kg. This upturn reflects **ion–solvent interactions** — Li⁺ is a very small, highly charge-dense cation that strongly hydrates water molecules, effectively reducing the "free" solvent available. This ion-pairing and hydration shell crowding drives the activity coefficient back up.

LiCl is notable among alkali halides for having particularly **strong positive deviations** at higher concentrations due to the exceptionally high charge density of Li⁺ and its strong hydration (hydration number ~4–6). The osmotic coefficient data extending to ~4.7 mol/kg (φ = 1.55) further confirm this strong non-ideal behavior at high concentrations.

The authors modeled these data using the **Pitzer**, **Modified Pitzer**, and **extended Debye–Hückel** equations, and also studied the effect of amide co-solvents (urea, N-methylformamide, DMF, DMA) on LiCl activity coefficients in ternary systems at the same temperature.

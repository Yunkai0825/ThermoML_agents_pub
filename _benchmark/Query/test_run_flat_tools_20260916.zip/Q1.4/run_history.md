# Q1.4 — Run History

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

This file is the audit record. For SQL calls, the fenced raw Markdown is
the exact payload supplied to the task-directed agentic compactor.

## Soft-budget events

```json
[]
```

## Step 1: resolve_compound_ids

### Call arguments

```json
{
  "queries": [
    "lithium chloride",
    "water"
  ],
  "purpose": "Identify the compound IDs for lithium chloride and water to search for activity coefficient data in aqueous LiCl systems.",
  "tasks": [
    "Find the GLOBcomp ID for lithium chloride",
    "Find the GLOBcomp ID for water"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `resolve_compound_ids`

Serialization: `json`

```json
{
  "n_results": 2,
  "results": [
    {
      "common_name": "lithium chloride",
      "comp_id": "lithium_chloride",
      "comp_num_id": "GLOBcomp_107",
      "formula": "ClLi",
      "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
      "match_type": "name_exact",
      "n_papers": 78,
      "score": 100,
      "smiles": "[Cl-].[Li+]",
      "standard_inchi": "InChI=1S/ClH.Li/h1H;/q;+1/p-1"
    },
    {
      "common_name": "water",
      "comp_id": "water",
      "comp_num_id": "GLOBcomp_1",
      "formula": "H2O",
      "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
      "match_type": "name_exact",
      "n_papers": 4690,
      "score": 100,
      "smiles": "O",
      "standard_inchi": "InChI=1S/H2O/h1H2"
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
resolve_compound_ids: 2 match(es).

| # | comp_num_id | Name | Formula | SMILES | Score | Match |
|---|-------------|------|---------|--------|-------|-------|
| 1 | GLOBcomp_107 | lithium chloride | ClLi | [Cl-].[Li+] | 100 | name_exact |
| 2 | GLOBcomp_1 | water | H2O | O | 100 | name_exact |

```

### Model-visible result

```markdown
Both compounds were resolved with exact name matches.

| Compound | ID | Formula | SMILES |
|---|---|---|---|
| lithium chloride | GLOBcomp_107 | ClLi | [Cl-].[Li+] |
| water | GLOBcomp_1 | H2O | O |
```

### Integrity and timing

- Raw SHA-256: 166ed57c1ad854e25dc9e7788af88b1d05c67a7998bc4a6cc3ee30875f97fc8b
- Raw characters: 805
- Hardcoded-compacted characters: 296
- Model-visible characters: 199
- Agentic verdict: KEEP
- Tool elapsed: 0.003s
- Compactor elapsed: 3.682s
- Total elapsed: 3.685s

## Step 2: resolve_property_ids

### Call arguments

```json
{
  "queries": [
    "activity coefficient"
  ],
  "purpose": "Identify the property ID for activity coefficient measurements.",
  "tasks": [
    "Find the GLOBprop ID for activity coefficient"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `resolve_property_ids`

Serialization: `json`

```json
{
  "n_results": 1,
  "results": [
    {
      "comp_id_linked": 1,
      "match_type": "prop_id_exact",
      "n_blocks": 9696,
      "prop_group": "ActivityFugacityOsmoticProp",
      "prop_id": "activity_coefficient_{DOIcomp_id}",
      "prop_name": "Activity coefficient",
      "prop_num_id": "GLOBprop_3",
      "score": 100
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
resolve_property_ids: 1 match(es).

| # | prop_num_id | Name | Group | Score | Match |
|---|-------------|------|-------|-------|-------|
| 1 | GLOBprop_3 | Activity coefficient | ActivityFugacityOsmoticProp | 100 | prop_id_exact |

```

### Model-visible result

```markdown
The property ID for activity coefficient is **GLOBprop_3**.

| Property ID | Name | Group | Score | Match |
|---|---|---|---|---|
| GLOBprop_3 | Activity coefficient | ActivityFugacityOsmoticProp | 100 | prop_id_exact |
```

### Integrity and timing

- Raw SHA-256: 8f57e9380069737073e974cbf47631cbfd3c04dcb3c03229cfc9ccd5cba83c8f
- Raw characters: 421
- Hardcoded-compacted characters: 232
- Model-visible characters: 219
- Agentic verdict: KEEP
- Tool elapsed: 0.000s
- Compactor elapsed: 3.852s
- Total elapsed: 3.852s

## Step 3: search_blocks

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_107",
    "GLOBcomp_1"
  ],
  "property": "GLOBprop_3",
  "temperature_range": [
    293.15,
    303.15
  ],
  "purpose": "Find data blocks with activity coefficient measurements for aqueous lithium chloride near 25 °C (298.15 K ± 5 K).",
  "tasks": [
    "Identify all blocks with activity coefficient data for LiCl + water near 298.15 K",
    "Determine the concentration range covered",
    "Note the references/DOIs"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "n_results": 0,
  "query_params": {
    "compound": [
      "GLOBcomp_107",
      "GLOBcomp_1"
    ],
    "limit": 50,
    "property": "GLOBprop_3",
    "system_scope": "declared",
    "temperature_range": [
      293.15,
      303.15
    ]
  },
  "results": []
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
**search_blocks: 0 results returned.**

```

### Model-visible result

```markdown
**⚠ Tool `search_blocks` result discarded by subagent.**

1. **Explanation:** The search returned zero results for activity coefficient (GLOBprop_3) data of LiCl (GLOBcomp_107) + water (GLOBcomp_1) in the 293.15–303.15 K range with `system_scope="declared"`. No matching blocks exist under these exact constraints.

2. **Refinement suggestions:**
   - **Broaden the search:** Remove the `temperature_range` filter entirely to check whether *any* activity coefficient data for LiCl + water exists in the database, regardless of temperature.
   - **Relax system scope:** Try without `system_scope="declared"` (or use `"any"`), in case the mixture is not explicitly declared but data still exists.
   - **Verify the property ID:** Confirm that `GLOBprop_3` truly maps to "activity coefficient" by using `get_property_info` or `search_properties`. Activity coefficients in ThermoML may be stored under a different label (e.g., mean ionic activity coefficient, osmotic coefficient) with a different global property ID.
   - **Try related properties:** Search for osmotic coefficient or water activity for the same system, which are thermodynamically equivalent and may be more commonly reported.
```

### Integrity and timing

- Raw SHA-256: fe936f0f859feb9f1d1ba48efaf0f24fc69e9bc422cfdf4b75a0ce1d9d5f2c85
- Raw characters: 339
- Hardcoded-compacted characters: 39
- Model-visible characters: 1190
- Agentic verdict: DISCARD
- Tool elapsed: 8.788s
- Compactor elapsed: 13.620s
- Total elapsed: 22.407s

## Step 4: search_blocks

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_107",
    "GLOBcomp_1"
  ],
  "property": "GLOBprop_3",
  "purpose": "Find any activity coefficient data for LiCl + water at any temperature.",
  "tasks": [
    "Check if any activity coefficient blocks exist for LiCl + water at any temperature"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "n_results": 0,
  "query_params": {
    "compound": [
      "GLOBcomp_107",
      "GLOBcomp_1"
    ],
    "limit": 50,
    "property": "GLOBprop_3",
    "system_scope": "declared"
  },
  "results": []
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
**search_blocks: 0 results returned.**

```

### Model-visible result

```markdown
**No activity coefficient blocks found** for LiCl (`GLOBcomp_107`) + water (`GLOBcomp_1`) using property `GLOBprop_3` with `system_scope="declared"`. The database contains zero matching entries.

**Possible refinements for the main agent:**
1. Try `system_scope="any"` instead of `"declared"` — the compounds may appear in multi-component systems where they are not the only declared species.
2. Search without the `property` filter to see what data types *do* exist for LiCl + water (e.g., osmotic coefficients, solubility, density).
3. Verify that `GLOBprop_3` is indeed the correct global ID for activity coefficients — consider searching the property catalog to confirm.
```

### Integrity and timing

- Raw SHA-256: b55afa3f0e6b0dfe83e5aeba5c0e4892ec4187a81306b2a33bd3a4143221e1f3
- Raw characters: 278
- Hardcoded-compacted characters: 39
- Model-visible characters: 674
- Agentic verdict: KEEP
- Tool elapsed: 9.781s
- Compactor elapsed: 8.746s
- Total elapsed: 18.527s

## Step 5: resolve_property_ids

### Call arguments

```json
{
  "queries": [
    "mean ionic activity coefficient",
    "osmotic coefficient",
    "water activity"
  ],
  "purpose": "Find related property IDs that may store activity coefficient data for electrolyte solutions.",
  "tasks": [
    "Find GLOBprop IDs for mean ionic activity coefficient, osmotic coefficient, and water activity"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `resolve_property_ids`

Serialization: `json`

```json
{
  "n_results": 4,
  "results": [
    {
      "comp_id_linked": 1,
      "match_type": "prop_id_exact",
      "n_blocks": 94,
      "prop_group": "ActivityFugacityOsmoticProp",
      "prop_id": "mean_ionic_activity_coefficient_{DOIcomp_id}",
      "prop_name": "Mean ionic activity coefficient",
      "prop_num_id": "GLOBprop_56",
      "score": 100
    },
    {
      "comp_id_linked": 0,
      "match_type": "prop_id_exact",
      "n_blocks": 299,
      "prop_group": "ActivityFugacityOsmoticProp",
      "prop_id": "osmotic_coefficient",
      "prop_name": "Osmotic coefficient",
      "prop_num_id": "GLOBprop_38",
      "score": 100
    },
    {
      "comp_id_linked": 1,
      "match_type": "name_fuzzy",
      "n_blocks": 496,
      "prop_group": "ActivityFugacityOsmoticProp",
      "prop_id": "relative_activity_{DOIcomp_id}",
      "prop_name": "(Relative) activity",
      "prop_num_id": "GLOBprop_33",
      "score": 72
    },
    {
      "comp_id_linked": 0,
      "match_type": "name_fuzzy",
      "n_blocks": 484,
      "prop_group": "TransportProp",
      "prop_id": "thermal_conductivity_w_m_k",
      "prop_name": "Thermal conductivity, W/m/K",
      "prop_num_id": "GLOBprop_34",
      "score": 53
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
resolve_property_ids: 4 match(es).

| # | prop_num_id | Name | Group | Score | Match |
|---|-------------|------|-------|-------|-------|
| 1 | GLOBprop_56 | Mean ionic activity coefficient | ActivityFugacityOsmoticProp | 100 | prop_id_exact |
| 2 | GLOBprop_38 | Osmotic coefficient | ActivityFugacityOsmoticProp | 100 | prop_id_exact |
| 3 | GLOBprop_33 | (Relative) activity | ActivityFugacityOsmoticProp | 72 | name_fuzzy |
| 4 | GLOBprop_34 | Thermal conductivity, W/m/K | TransportProp | 53 | name_fuzzy |

```

### Model-visible result

```markdown
**Summary:** Found exact matches for mean ionic activity coefficient and osmotic coefficient. Water activity is not directly listed, but GLOBprop_33 "(Relative) activity" (score 72, fuzzy match) may correspond to it.

| GLOBprop ID | Name | Score | Match Type |
|---|---|---|---|
| GLOBprop_56 | Mean ionic activity coefficient | 100 | exact |
| GLOBprop_38 | Osmotic coefficient | 100 | exact |
| GLOBprop_33 | (Relative) activity | 72 | name_fuzzy |
```

### Integrity and timing

- Raw SHA-256: c499d38c9cef9c204ca81c468e3f9b915d22011738f9de76240c6636d6eb7c71
- Raw characters: 1310
- Hardcoded-compacted characters: 512
- Model-visible characters: 451
- Agentic verdict: KEEP
- Tool elapsed: 0.009s
- Compactor elapsed: 5.674s
- Total elapsed: 5.684s

## Step 6: search_blocks

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_107",
    "GLOBcomp_1"
  ],
  "property": "GLOBprop_56",
  "temperature_range": [
    293.15,
    303.15
  ],
  "purpose": "Find mean ionic activity coefficient data for aqueous LiCl near 25 °C.",
  "tasks": [
    "Find all blocks with mean ionic activity coefficient data for LiCl + water near 298.15 K",
    "Determine concentration ranges and references"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "n_results": 5,
  "query_params": {
    "compound": [
      "GLOBcomp_107",
      "GLOBcomp_1"
    ],
    "limit": 50,
    "property": "GLOBprop_56",
    "system_scope": "declared",
    "temperature_range": [
      293.15,
      303.15
    ]
  },
  "results": [
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_9",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_9 | P/M | ternary | 130 pts | GLOBlit_1540\n**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=26\n\n### Reference\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_94 | urea | CH4N2O |\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |\n| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_1→GLOBcomp_94 (GLOBsolvent_30); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): s:w(urea): 0.0–0.1, b(lithium chloride): 0.0035–1.5095 | 50 pts → 18 kept (RDP)\n| s:w(urea,Liquid) | b(lithium chloride,Liquid) | γ±[lithium chloride] | ±U |\n|---|---|---|---|\n| 0.0 | 0.0035 | 0.9388 | 0.0201 |\n| 0.0 | 0.0354 | 0.8465 | 0.0212 |\n| 0.0 | 0.1013 | 0.7911 | 0.0218 |\n| 0.0 | 0.2121 | 0.7572 | 0.0222 |\n| 0.0 | 0.3929 | 0.7414 | 0.0224 |\n| 0.0 | 0.5927 | 0.7434 | 0.0223 |\n| 0.0 | 0.8769 | 0.7621 | 0.0221 |\n| 0.0 | 1.2231 | 0.7993 | 0.0217 |\n| 0.0 | 1.5095 | 0.839 | 0.0212 |\n| 0.1 | 0.0042 | 0.9399 | 0.0201 |\n| 0.1 | 0.0664 | 0.8347 | 0.0213 |\n| 0.1 | 0.2772 | 0.781 | 0.0219 |\n| 0.1 | 0.4265 | 0.7744 | 0.022 |\n| 0.1 | 0.6263 | 0.7762 | 0.022 |\n| 0.1 | 0.9115 | 0.7886 | 0.0218 |\n| 0.1 | 1.2818 | 0.8143 | 0.0215 |\n| 0.1 | 0.1458 | 0.8013 | 0.0217 |\n| 0.1 | 0.1794 | 0.7937 | 0.0218 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/CH4N2O/c2-1(3)4/h(H4,2,3,4)",
          "SMILES": "N=C(N)O",
          "comp_num_id": "GLOBcomp_94",
          "formula": "CH4N2O",
          "inchi_key": "XSQUKJJJFZCRTK-UHFFFAOYSA-N",
          "name": "urea",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "urea",
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 1,
          "n_unique_points": 26,
          "system_types": [
            "binary"
          ]
        },
        "methods": [
          "Calculated from EMF cell potential"
        ],
        "n_points": 130,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Mean ionic activity coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.9489,
            "mean": 0.835183,
            "min": 0.7408,
            "n": 130,
            "name": "Mean ionic activity coefficient",
            "std": 0.052392
          }
        },
        "system_type": "ternary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.4,
            "min": 0.0,
            "n_unique": 5,
            "name": "Solvent: Mass fraction"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.5617,
            "min": 0.0035,
            "n_unique": 126,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/CH4N2O/c2-1(3)4/h(H4,2,3,4)",
          "SMILES": "N=C(N)O",
          "comp_num_id": "GLOBcomp_94",
          "formula": "CH4N2O",
          "inchi_key": "XSQUKJJJFZCRTK-UHFFFAOYSA-N",
          "name": "urea",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "ternary",
      "doi": "10.1016/j.fluid.2014.08.026",
      "lit_num_id": "GLOBlit_1540",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 130,
      "paper_title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "parent_n_datapoints": 130,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": "DOIcomp_6",
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "calculated_from_emf_cell_potential",
          "meas_num_id": "GLOBmeas_185",
          "method_custom": "Calculated from EMF cell potential",
          "method_standard": null,
          "name": "Mean ionic activity coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "mean_ionic_activity_coefficient_DOIcomp_6",
          "prop_num_id": "GLOBprop_56",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_94",
          "component_org_num": "DOIcomp_1",
          "inchi_key": "XSQUKJJJFZCRTK-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_30"
        },
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_2",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "ternary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Solvent: Mass fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eSolventComposition",
          "var_id": "solvent_mass_fraction_DOIcomp_1",
          "var_num_id": "GLOBvar_7"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_6",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_6",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_10",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_10 | P/M | ternary | 144 pts | GLOBlit_1540\n**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=57\n\n### Reference\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n| DOIcomp_3 | GLOBcomp_177 | N-methylformamide | C2H5NO |\n| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_3 | DOIcomp_3 | Liquid |\n| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_3→GLOBcomp_177 (GLOBsolvent_38); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): s:w(N-methylformamide): 0.0–0.0, b(lithium chloride): 0.0033–1.5555 | 50 pts → 21 kept (RDP)\n| s:w(N-methylformamide,Liquid) | b(lithium chloride,Liquid) | γ±[lithium chloride] | ±U |\n|---|---|---|---|\n| 0.0 | 0.0046 | 0.9307 | 0.0202 |\n| 0.0 | 0.0313 | 0.8527 | 0.0211 |\n| 0.0 | 0.0847 | 0.8005 | 0.0217 |\n| 0.0 | 0.201 | 0.7593 | 0.0222 |\n| 0.0 | 0.2858 | 0.7475 | 0.0223 |\n| 0.0 | 0.3349 | 0.7438 | 0.0223 |\n| 0.0 | 0.4057 | 0.7411 | 0.0224 |\n| 0.0 | 0.4743 | 0.7406 | 0.0224 |\n| 0.0 | 0.5696 | 0.7426 | 0.0224 |\n| 0.0 | 0.6596 | 0.7466 | 0.0223 |\n| 0.0 | 0.8876 | 0.7631 | 0.0221 |\n| 0.0 | 1.1707 | 0.7929 | 0.0218 |\n| 0.0 | 1.5555 | 0.8461 | 0.0212 |\n| 0.0 | 0.0033 | 0.9425 | 0.0201 |\n| 0.0 | 0.032 | 0.8564 | 0.021 |\n| 0.0 | 0.0883 | 0.8039 | 0.0216 |\n| 0.0 | 0.2158 | 0.7628 | 0.0221 |\n| 0.0 | 0.3324 | 0.7504 | 0.0223 |\n| 0.0 | 0.4011 | 0.7478 | 0.0223 |\n| 0.0 | 0.4952 | 0.7477 | 0.0223 |\n| 0.0 | 0.5861 | 0.7503 | 0.0223 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H5NO/c1-3-2-4/h2H,1H3,(H,3,4)",
          "SMILES": "CN=CO",
          "comp_num_id": "GLOBcomp_177",
          "formula": "C2H5NO",
          "inchi_key": "ATHHXGZTWNVVOU-UHFFFAOYSA-N",
          "name": "N-methylformamide",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "N-methylformamide",
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 1,
          "n_unique_points": 57,
          "system_types": [
            "binary"
          ]
        },
        "methods": [
          "Calculated from EMF cell potential"
        ],
        "n_points": 144,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Mean ionic activity coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 1.0587,
            "mean": 0.833519,
            "min": 0.7406,
            "n": 144,
            "name": "Mean ionic activity coefficient",
            "std": 0.062344
          }
        },
        "system_type": "ternary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.4,
            "min": 0.0,
            "n_unique": 4,
            "name": "Solvent: Mass fraction"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.5555,
            "min": 0.0028,
            "n_unique": 142,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H5NO/c1-3-2-4/h2H,1H3,(H,3,4)",
          "SMILES": "CN=CO",
          "comp_num_id": "GLOBcomp_177",
          "formula": "C2H5NO",
          "inchi_key": "ATHHXGZTWNVVOU-UHFFFAOYSA-N",
          "name": "N-methylformamide",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "ternary",
      "doi": "10.1016/j.fluid.2014.08.026",
      "lit_num_id": "GLOBlit_1540",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 144,
      "paper_title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "parent_n_datapoints": 144,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": "DOIcomp_6",
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "calculated_from_emf_cell_potential",
          "meas_num_id": "GLOBmeas_185",
          "method_custom": "Calculated from EMF cell potential",
          "method_standard": null,
          "name": "Mean ionic activity coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "mean_ionic_activity_coefficient_DOIcomp_6",
          "prop_num_id": "GLOBprop_56",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_177",
          "component_org_num": "DOIcomp_3",
          "inchi_key": "ATHHXGZTWNVVOU-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_38"
        },
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_2",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "ternary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_3",
          "name": "Solvent: Mass fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eSolventComposition",
          "var_id": "solvent_mass_fraction_DOIcomp_3",
          "var_num_id": "GLOBvar_7"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_6",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_6",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_11",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_11 | P/M | ternary | 156 pts | GLOBlit_1540\n**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=31\n\n### Reference\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n| DOIcomp_4 | GLOBcomp_18 | dimethylformamide | C3H7NO |\n| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_4 | DOIcomp_4 | Liquid |\n| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_4→GLOBcomp_18 (GLOBsolvent_4); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): s:w(dimethylformamide): 0.0–0.1, b(lithium chloride): 0.0027–1.4182 | 50 pts → 12 kept (RDP)\n| s:w(dimethylformamide,Liquid) | b(lithium chloride,Liquid) | γ±[lithium chloride] | ±U |\n|---|---|---|---|\n| 0.0 | 0.004 | 0.935 | 0.0202 |\n| 0.0 | 0.0804 | 0.8032 | 0.0217 |\n| 0.0 | 0.1723 | 0.7657 | 0.0221 |\n| 0.0 | 0.3127 | 0.7452 | 0.0223 |\n| 0.0 | 0.5253 | 0.7414 | 0.0224 |\n| 0.0 | 0.7946 | 0.7554 | 0.0222 |\n| 0.0 | 1.0687 | 0.7811 | 0.0219 |\n| 0.0 | 1.4182 | 0.8256 | 0.0214 |\n| 0.1 | 0.0027 | 0.9435 | 0.0201 |\n| 0.1 | 0.0656 | 0.8074 | 0.0216 |\n| 0.1 | 0.1437 | 0.765 | 0.0221 |\n| 0.1 | 0.2652 | 0.7386 | 0.0224 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C3H7NO/c1-4(2)3-5/h3H,1-2H3",
          "SMILES": "CN(C)C=O",
          "comp_num_id": "GLOBcomp_18",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "name": "dimethylformamide",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "dimethylformamide",
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 1,
          "n_unique_points": 31,
          "system_types": [
            "binary"
          ]
        },
        "methods": [
          "Calculated from EMF cell potential"
        ],
        "n_points": 156,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Mean ionic activity coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.9435,
            "mean": 0.787138,
            "min": 0.6751,
            "n": 156,
            "name": "Mean ionic activity coefficient",
            "std": 0.069206
          }
        },
        "system_type": "ternary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.4,
            "min": 0.0,
            "n_unique": 5,
            "name": "Solvent: Mass fraction"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.4819,
            "min": 0.0022,
            "n_unique": 154,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C3H7NO/c1-4(2)3-5/h3H,1-2H3",
          "SMILES": "CN(C)C=O",
          "comp_num_id": "GLOBcomp_18",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "name": "dimethylformamide",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "ternary",
      "doi": "10.1016/j.fluid.2014.08.026",
      "lit_num_id": "GLOBlit_1540",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 156,
      "paper_title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "parent_n_datapoints": 156,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": "DOIcomp_6",
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "calculated_from_emf_cell_potential",
          "meas_num_id": "GLOBmeas_185",
          "method_custom": "Calculated from EMF cell potential",
          "method_standard": null,
          "name": "Mean ionic activity coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "mean_ionic_activity_coefficient_DOIcomp_6",
          "prop_num_id": "GLOBprop_56",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_18",
          "component_org_num": "DOIcomp_4",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_4"
        },
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_2",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "ternary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_4",
          "name": "Solvent: Mass fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eSolventComposition",
          "var_id": "solvent_mass_fraction_DOIcomp_4",
          "var_num_id": "GLOBvar_7"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_6",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_6",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_12",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_12 | P/M | ternary | 134 pts | GLOBlit_1540\n**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=27\n\n### Reference\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n| DOIcomp_5 | GLOBcomp_63 | N,N-dimethylethanamide | C4H9NO |\n| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_5 | DOIcomp_5 | Liquid |\n| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_5→GLOBcomp_63 (GLOBsolvent_21); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): s:w(N,N-dimethylethanamide): 0.0–0.1, b(lithium chloride): 0.0029–1.5483 | 50 pts → 15 kept (RDP)\n| s:w(N,N-dimethylethanamide,Liquid) | b(lithium chloride,Liquid) | γ±[lithium chloride] | ±U |\n|---|---|---|---|\n| 0.0 | 0.0033 | 0.9398 | 0.0201 |\n| 0.0 | 0.0921 | 0.796 | 0.0217 |\n| 0.0 | 0.1816 | 0.7634 | 0.0221 |\n| 0.0 | 0.3496 | 0.743 | 0.0224 |\n| 0.0 | 0.6065 | 0.744 | 0.0223 |\n| 0.0 | 0.8844 | 0.7628 | 0.0221 |\n| 0.0 | 1.263 | 0.8044 | 0.0216 |\n| 0.0 | 1.5483 | 0.845 | 0.0212 |\n| 0.1 | 0.0029 | 0.9414 | 0.0201 |\n| 0.1 | 0.0669 | 0.8038 | 0.0216 |\n| 0.1 | 0.2285 | 0.7364 | 0.0224 |\n| 0.1 | 0.362 | 0.7179 | 0.0226 |\n| 0.1 | 0.5591 | 0.7081 | 0.0228 |\n| 0.1 | 0.8573 | 0.7107 | 0.0227 |\n| 0.1 | 1.1175 | 0.7219 | 0.0226 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C4H9NO/c1-4(6)5(2)3/h1-3H3",
          "SMILES": "CC(=O)N(C)C",
          "comp_num_id": "GLOBcomp_63",
          "formula": "C4H9NO",
          "inchi_key": "FXHOOIRPVKKKFG-UHFFFAOYSA-N",
          "name": "N,N-dimethylethanamide",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "N,N-dimethylethanamide",
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 1,
          "n_unique_points": 27,
          "system_types": [
            "binary"
          ]
        },
        "methods": [
          "Calculated from EMF cell potential"
        ],
        "n_points": 134,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Mean ionic activity coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.9414,
            "mean": 0.772318,
            "min": 0.6378,
            "n": 134,
            "name": "Mean ionic activity coefficient",
            "std": 0.084138
          }
        },
        "system_type": "ternary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.4,
            "min": 0.0,
            "n_unique": 5,
            "name": "Solvent: Mass fraction"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.5886,
            "min": 0.0028,
            "n_unique": 132,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C4H9NO/c1-4(6)5(2)3/h1-3H3",
          "SMILES": "CC(=O)N(C)C",
          "comp_num_id": "GLOBcomp_63",
          "formula": "C4H9NO",
          "inchi_key": "FXHOOIRPVKKKFG-UHFFFAOYSA-N",
          "name": "N,N-dimethylethanamide",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "ternary",
      "doi": "10.1016/j.fluid.2014.08.026",
      "lit_num_id": "GLOBlit_1540",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 134,
      "paper_title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "parent_n_datapoints": 134,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": "DOIcomp_6",
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "calculated_from_emf_cell_potential",
          "meas_num_id": "GLOBmeas_185",
          "method_custom": "Calculated from EMF cell potential",
          "method_standard": null,
          "name": "Mean ionic activity coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "mean_ionic_activity_coefficient_DOIcomp_6",
          "prop_num_id": "GLOBprop_56",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_63",
          "component_org_num": "DOIcomp_5",
          "inchi_key": "FXHOOIRPVKKKFG-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_21"
        },
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_2",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "ternary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_5",
          "name": "Solvent: Mass fraction",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eSolventComposition",
          "var_id": "solvent_mass_fraction_DOIcomp_5",
          "var_num_id": "GLOBvar_7"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_6",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_6",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_13",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_13 | P/M | binary | 141 pts | GLOBlit_1540\n\n### Reference\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_1 | water | H2O |\n| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(1 extrema) | 50 pts → 9 kept (RDP)\n| b(lithium chloride,Liquid) | γ±[lithium chloride] | ±U |\n|---|---|---|\n| 0.0035 | 0.9388 | 0.0201 |\n| 0.3285 | 0.7441 | 0.0223 |\n| 0.8769 | 0.7621 | 0.0221 |\n| 1.5095 | 0.839 | 0.0212 |\n| 0.0313 | 0.8527 | 0.0211 |\n| 0.0847 | 0.8005 | 0.0217 |\n| 0.1658 | 0.7673 | 0.0221 |\n| 0.5696 | 0.7426 | 0.0224 |\n| 0.8876 | 0.7631 | 0.0221 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        }
      ],
      "data_summary": {
        "compound_names": [
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "Calculated from EMF cell potential"
        ],
        "n_points": 141,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Mean ionic activity coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.9425,
            "mean": 0.807865,
            "min": 0.7406,
            "n": 141,
            "name": "Mean ionic activity coefficient",
            "std": 0.056647
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.5555,
            "min": 0.0033,
            "n_unique": 139,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6",
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.fluid.2014.08.026",
      "lit_num_id": "GLOBlit_1540",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 141,
      "paper_title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "parent_n_datapoints": 141,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": "DOIcomp_6",
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "calculated_from_emf_cell_potential",
          "meas_num_id": "GLOBmeas_185",
          "method_custom": "Calculated from EMF cell potential",
          "method_standard": null,
          "name": "Mean ionic activity coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "mean_ionic_activity_coefficient_DOIcomp_6",
          "prop_num_id": "GLOBprop_56",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_2",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_6",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_6",
          "var_num_id": "GLOBvar_4"
        }
      ]
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
search_blocks: 5 search targets found.

| # | DOI | Block | Target | System | Points | Properties | Score |
|---|-----|-------|--------|--------|--------|------------|-------|
| 1 | 10.1016/j.fluid.2014.08.026 | PROPblock_9 | declared | ternary | 130 | Mean ionic activity coefficient | 100 |
| 2 | 10.1016/j.fluid.2014.08.026 | PROPblock_10 | declared | ternary | 144 | Mean ionic activity coefficient | 100 |
| 3 | 10.1016/j.fluid.2014.08.026 | PROPblock_11 | declared | ternary | 156 | Mean ionic activity coefficient | 100 |
| 4 | 10.1016/j.fluid.2014.08.026 | PROPblock_12 | declared | ternary | 134 | Mean ionic activity coefficient | 100 |
| 5 | 10.1016/j.fluid.2014.08.026 | PROPblock_13 | declared | binary | 141 | Mean ionic activity coefficient | 100 |

---
## PROPblock_9 | P/M | ternary | 130 pts | GLOBlit_1540
**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=26

### Reference
**lit_id:** 2014-zha-li-3
**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_1 | GLOBcomp_94 | urea | CH4N2O |
| DOIcomp_2 | GLOBcomp_1 | water | H2O |
| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_1 | DOIcomp_1 | Liquid |
| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_1→GLOBcomp_94 (GLOBsolvent_30); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** multi-variable(2): s:w(urea): 0.0–0.1, b(lithium chloride): 0.0035–1.5095 | 50 pts → 18 kept (RDP)


---
## PROPblock_10 | P/M | ternary | 144 pts | GLOBlit_1540
**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=57

### Reference
**lit_id:** 2014-zha-li-3
**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_2 | GLOBcomp_1 | water | H2O |
| DOIcomp_3 | GLOBcomp_177 | N-methylformamide | C2H5NO |
| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_3 | DOIcomp_3 | Liquid |
| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_3→GLOBcomp_177 (GLOBsolvent_38); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** multi-variable(2): s:w(N-methylformamide): 0.0–0.0, b(lithium chloride): 0.0033–1.5555 | 50 pts → 21 kept (RDP)


---
## PROPblock_11 | P/M | ternary | 156 pts | GLOBlit_1540
**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=31

### Reference
**lit_id:** 2014-zha-li-3
**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_2 | GLOBcomp_1 | water | H2O |
| DOIcomp_4 | GLOBcomp_18 | dimethylformamide | C3H7NO |
| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_4 | DOIcomp_4 | Liquid |
| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_4→GLOBcomp_18 (GLOBsolvent_4); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** multi-variable(2): s:w(dimethylformamide): 0.0–0.1, b(lithium chloride): 0.0027–1.4182 | 50 pts → 12 kept (RDP)


---
## PROPblock_12 | P/M | ternary | 134 pts | GLOBlit_1540
**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=27

### Reference
**lit_id:** 2014-zha-li-3
**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_2 | GLOBcomp_1 | water | H2O |
| DOIcomp_5 | GLOBcomp_63 | N,N-dimethylethanamide | C4H9NO |
| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_7 | solvent_mass_fraction_DOIcomp_5 | DOIcomp_5 | Liquid |
| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_5→GLOBcomp_63 (GLOBsolvent_21); DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** multi-variable(2): s:w(N,N-dimethylethanamide): 0.0–0.1, b(lithium chloride): 0.0029–1.5483 | 50 pts → 15 kept (RDP)


---
## PROPblock_13 | P/M | binary | 141 pts | GLOBlit_1540

### Reference
**lit_id:** 2014-zha-li-3
**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_2 | GLOBcomp_1 | water | H2O |
| DOIcomp_6 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_56 | mean_ionic_activity_coefficient_DOIcomp_6 | GLOBmeas_185 | calculated_from_emf_cell_potential | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_6 | DOIcomp_6 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_2→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** non-monotonic(1 extrema) | 50 pts → 9 kept (RDP)


```

### Model-visible result

```markdown
**Summary:** Five blocks found for mean ionic activity coefficient of LiCl near 298.15 K, all from a single reference (DOI `10.1016/j.fluid.2014.08.026`, `GLOBlit_1540`). The most relevant is **PROPblock_13** — a pure binary LiCl + water system (141 pts). The other four are ternary systems (LiCl + water + an amide co-solvent) that include binary subsystem projections.

| Block | System | 3rd Component | Total pts | Molality range (LiCl) | T (K) | P (kPa) |
|---|---|---|---|---|---|---|
| `PROPblock_13` | binary | — | 141 | (non-monotonic, 9 kept RDP) | 298.15 | 101.0 |
| `PROPblock_9` | ternary | urea (`GLOBcomp_94`) | 130 | 0.0035–1.5095 | 298.15 | 101.0 |
| `PROPblock_10` | ternary | N-methylformamide (`GLOBcomp_177`) | 144 | 0.0033–1.5555 | 298.15 | 101.0 |
| `PROPblock_11` | ternary | dimethylformamide (`GLOBcomp_18`) | 156 | 0.0027–1.4182 | 298.15 | 101.0 |
| `PROPblock_12` | ternary | N,N-dimethylethanamide (`GLOBcomp_63`) | 134 | 0.0029–1.5483 | 298.15 | 101.0 |

**Key details:**
- **Property:** `GLOBprop_56` — mean ionic activity coefficient of LiCl (`DOIcomp_6` / `GLOBcomp_107`)
- **Method:** `GLOBmeas_185` — calculated from EMF cell potential
- **Reference:** `GLOBlit_1540` /
```

### Integrity and timing

- Raw SHA-256: acdaf9929e368182fc4fa37b8e0e52ec1dbdb408477d034e13aba919e5b9d6ee
- Raw characters: 52384
- Hardcoded-compacted characters: 8723
- Model-visible characters: 1204
- Agentic verdict: KEEP
- Tool elapsed: 10.347s
- Compactor elapsed: 13.260s
- Total elapsed: 23.614s

## Step 7: search_blocks

### Call arguments

```json
{
  "compound": [
    "GLOBcomp_107",
    "GLOBcomp_1"
  ],
  "property": "GLOBprop_38",
  "temperature_range": [
    293.15,
    303.15
  ],
  "purpose": "Find osmotic coefficient data for aqueous LiCl near 25 °C as a complementary measure.",
  "tasks": [
    "Find all blocks with osmotic coefficient data for LiCl + water near 298.15 K"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_blocks`

Serialization: `json`

```json
{
  "n_results": 5,
  "query_params": {
    "compound": [
      "GLOBcomp_107",
      "GLOBcomp_1"
    ],
    "limit": 50,
    "property": "GLOBprop_38",
    "system_scope": "declared",
    "temperature_range": [
      293.15,
      303.15
    ]
  },
  "results": [
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_47",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_47 | P/M | ternary | 9 pts | GLOBlit_3969\n**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=2\n\n### Reference\n**lit_id:** 2014-hel-res-0\n**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_53 | 2-aminoacetic acid | C2H5NO2 |\n| DOIcomp_18 | GLOBcomp_1 | water | H2O |\n| DOIcomp_5 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_305 | commercial_osmometer_gonotec_070 | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_1 | DOIcomp_1 | Liquid |\n| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_5 | DOIcomp_5 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_18→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): b(2-aminoacetic acid): 0.0–1.8, b(lithium chloride): 0.5–1.0 | 9 pts → 9 kept (RDP)\n| b(2-aminoacetic acid,Liquid) | b(lithium chloride,Liquid) | φ_osm | ±U |\n|---|---|---|---|\n| 0.0 | 0.5 | 0.928 | 0.01 |\n| 0.4 | 0.5 | 0.94 | 0.01 |\n| 0.8 | 0.5 | 0.933 | 0.01 |\n| 1.3 | 0.5 | 0.924 | 0.01 |\n| 1.8 | 0.5 | 0.902 | 0.011 |\n| 0.0 | 1.0 | 0.987 | 0.01 |\n| 0.2 | 1.0 | 0.983 | 0.01 |\n| 0.4 | 1.0 | 0.985 | 0.01 |\n| 0.8 | 1.0 | 0.969 | 0.01 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C2H5NO2/c3-1-2(4)5/h1,3H2,(H,4,5)",
          "SMILES": "NCC(=O)O",
          "comp_num_id": "GLOBcomp_53",
          "formula": "C2H5NO2",
          "inchi_key": "DHMQDGOQFOQNFH-UHFFFAOYSA-N",
          "name": "2-aminoacetic acid",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18",
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        }
      ],
      "data_summary": {
        "compound_names": [
          "2-aminoacetic acid",
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 1,
          "n_unique_points": 2,
          "system_types": [
            "binary"
          ]
        },
        "methods": [
          "commercial osmometer Gonotec 070"
        ],
        "n_points": 9,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Osmotic coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.987,
            "mean": 0.950111,
            "min": 0.902,
            "n": 9,
            "name": "Osmotic coefficient",
            "std": 0.031418
          }
        },
        "system_type": "ternary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.8,
            "min": 0.0,
            "n_unique": 6,
            "name": "Molality, mol/kg"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.5,
            "n_unique": 2,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C2H5NO2/c3-1-2(4)5/h1,3H2,(H,4,5)",
          "SMILES": "NCC(=O)O",
          "comp_num_id": "GLOBcomp_53",
          "formula": "C2H5NO2",
          "inchi_key": "DHMQDGOQFOQNFH-UHFFFAOYSA-N",
          "name": "2-aminoacetic acid",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18",
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "declared_system_type": "ternary",
      "doi": "10.1016/j.jct.2013.08.018",
      "lit_num_id": "GLOBlit_3969",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 9,
      "paper_title": "Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT",
      "parent_n_datapoints": 9,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "commercial_osmometer_gonotec_070",
          "meas_num_id": "GLOBmeas_305",
          "method_custom": "commercial osmometer Gonotec 070",
          "method_standard": null,
          "name": "Osmotic coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_18",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "ternary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_1",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_1",
          "var_num_id": "GLOBvar_4"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_5",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_5",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_55",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_55 | P/M | ternary | 6 pts | GLOBlit_3969\n**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=2\n\n### Reference\n**lit_id:** 2014-hel-res-0\n**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_18 | GLOBcomp_1 | water | H2O |\n| DOIcomp_3 | GLOBcomp_116 | L-valine | C5H11NO2 |\n| DOIcomp_5 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_305 | commercial_osmometer_gonotec_070 | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_3 | DOIcomp_3 | Liquid |\n| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_5 | DOIcomp_5 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_18→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): b(L-valine): 0.0–0.5, b(lithium chloride): 0.5–1.0 | 6 pts → 6 kept (RDP)\n| b(L-valine,Liquid) | b(lithium chloride,Liquid) | φ_osm | ±U |\n|---|---|---|---|\n| 0.0 | 0.5 | 0.955 | 0.01 |\n| 0.2 | 0.5 | 0.972 | 0.01 |\n| 0.5 | 0.5 | 0.988 | 0.01 |\n| 0.0 | 1.0 | 0.978 | 0.01 |\n| 0.2 | 1.0 | 0.997 | 0.01 |\n| 0.5 | 1.0 | 1.005 | 0.01 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/C5H11NO2/c1-3(2)4(6)5(7)8/h3-4H,6H2,1-2H3,(H,7,8)/t4-/m0/s1",
          "SMILES": "CC(C)[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_116",
          "formula": "C5H11NO2",
          "inchi_key": "KZSNJWFQEVHDMF-BYPYZUCNSA-N",
          "name": "L-valine",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18",
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        }
      ],
      "data_summary": {
        "compound_names": [
          "L-valine",
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 1,
          "n_unique_points": 2,
          "system_types": [
            "binary"
          ]
        },
        "methods": [
          "commercial osmometer Gonotec 070"
        ],
        "n_points": 6,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Osmotic coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 1.005,
            "mean": 0.9825,
            "min": 0.955,
            "n": 6,
            "name": "Osmotic coefficient",
            "std": 0.018075
          }
        },
        "system_type": "ternary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 0.5,
            "min": 0.0,
            "n_unique": 3,
            "name": "Molality, mol/kg"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 1.0,
            "min": 0.5,
            "n_unique": 2,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/C5H11NO2/c1-3(2)4(6)5(7)8/h3-4H,6H2,1-2H3,(H,7,8)/t4-/m0/s1",
          "SMILES": "CC(C)[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_116",
          "formula": "C5H11NO2",
          "inchi_key": "KZSNJWFQEVHDMF-BYPYZUCNSA-N",
          "name": "L-valine",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18",
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "declared_system_type": "ternary",
      "doi": "10.1016/j.jct.2013.08.018",
      "lit_num_id": "GLOBlit_3969",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 6,
      "paper_title": "Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT",
      "parent_n_datapoints": 6,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "commercial_osmometer_gonotec_070",
          "meas_num_id": "GLOBmeas_305",
          "method_custom": "commercial osmometer Gonotec 070",
          "method_standard": null,
          "name": "Osmotic coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_18",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "ternary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_3",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_3",
          "var_num_id": "GLOBvar_4"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_5",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_5",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_74",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_74 | P/M | binary | 4 pts | GLOBlit_3969\n\n### Reference\n**lit_id:** 2014-hel-res-0\n**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_18 | GLOBcomp_1 | water | H2O |\n| DOIcomp_5 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_305 | commercial_osmometer_gonotec_070 | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_5 | DOIcomp_5 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |\n| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_18→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** non-monotonic(1 extrema) | 4 pts → 4 kept (RDP)\n| b(lithium chloride,Liquid) | φ_osm | ±U |\n|---|---|---|\n| 0.5 | 0.928 | 0.01 |\n| 1.0 | 0.987 | 0.01 |\n| 0.5 | 0.955 | 0.01 |\n| 1.0 | 0.978 | 0.01 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18",
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 101.0
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        }
      ],
      "data_summary": {
        "compound_names": [
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 101.0
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "commercial osmometer Gonotec 070"
        ],
        "n_points": 4,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Osmotic coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 0.987,
            "mean": 0.962,
            "min": 0.928,
            "n": 4,
            "name": "Osmotic coefficient",
            "std": 0.026369
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 1.0,
            "min": 0.5,
            "n_unique": 2,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5",
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18",
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2013.08.018",
      "lit_num_id": "GLOBlit_3969",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 4,
      "paper_title": "Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT",
      "parent_n_datapoints": 4,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "commercial_osmometer_gonotec_070",
          "meas_num_id": "GLOBmeas_305",
          "method_custom": "commercial osmometer Gonotec 070",
          "method_standard": null,
          "name": "Osmotic coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_18",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_5",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_5",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_4",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_4 | P/M | binary | 15 pts | GLOBlit_4743\n\n### Reference\n**lit_id:** 2016-raf-fro-1\n**Title:** The study of thermodynamic properties of the ternary (1-ethyl-3-methylimidazolium hydrogen sulfate + lithium chloride + water) system and corresponding binary systems at different temperatures and ambient pressure\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_2 | GLOBcomp_107 | lithium chloride | ClLi |\n| DOIcomp_3 | GLOBcomp_1 | water | H2O |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_166 | isopie | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_2 | DOIcomp_2 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 87.0 | Liquid |\n| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_3→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** monotonic↑ | near-linear(R²=0.9906) | 15 pts → 9 kept (RDP)\n| b(lithium chloride,Liquid) | φ_osm | ±U |\n|---|---|---|\n| 0.9064 | 1.02 | 0.01 |\n| 1.2783 | 1.08 | 0.01 |\n| 1.6157 | 1.09 | 0.01 |\n| 1.667 | 1.11 | 0.01 |\n| 1.8303 | 1.12 | 0.01 |\n| 1.9902 | 1.16 | 0.01 |\n| 2.563 | 1.21 | 0.01 |\n| 3.0143 | 1.27 | 0.01 |\n| 4.6684 | 1.55 | 0.02 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 2,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 87.0
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        }
      ],
      "data_summary": {
        "compound_names": [
          "lithium chloride",
          "water"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 2,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 87.0
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 0,
          "n_subsystems": 0,
          "n_unique_points": 0,
          "system_types": []
        },
        "methods": [
          "ISOPIE"
        ],
        "n_points": 15,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Osmotic coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 1.55,
            "mean": 1.233333,
            "min": 1.02,
            "n": 15,
            "name": "Osmotic coefficient",
            "std": 0.166075
          }
        },
        "system_type": "binary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 4.6684,
            "min": 0.9064,
            "n_unique": 15,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_3",
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "declared_system_type": "binary",
      "doi": "10.1016/j.jct.2016.07.003",
      "lit_num_id": "GLOBlit_4743",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 15,
      "paper_title": "The study of thermodynamic properties of the ternary (1-ethyl-3-methylimidazolium hydrogen sulfate + lithium chloride + water) system and corresponding binary systems at different temperatures and ambient pressure",
      "parent_n_datapoints": 15,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "isopie",
          "meas_num_id": "GLOBmeas_166",
          "method_custom": "ISOPIE",
          "method_standard": null,
          "name": "Osmotic coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_3",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "binary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_2",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_2",
          "var_num_id": "GLOBvar_4"
        }
      ]
    },
    {
      "BLKsubsys_id": null,
      "block_number": "PROPblock_3",
      "block_type": "PureOrMixtureData",
      "compact_md": "## PROPblock_3 | P/M | ternary | 20 pts | GLOBlit_5583\n**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=10\n\n### Reference\n**lit_id:** 2019-gru-tsu-0\n**Title:** Osmotic coefficients and activity coefficients in binary water/5-(hydroxymethyl)furfural and in ternary water/5-(hydroxymethyl)furfural/salt solutions at 298.15 K\n\n### Compounds\n\n| org_num | comp_num_id | Name | Formula |\n|---|---|---|---|\n| DOIcomp_1 | GLOBcomp_1 | water | H2O |\n| DOIcomp_2 | GLOBcomp_569 | 5-(hydroxymethyl)furan-2-carbaldehyde | C6H6O3 |\n| DOIcomp_4 | GLOBcomp_107 | lithium chloride | ClLi |\n\n### Properties\n\n| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |\n|---|---|---|---|---|---|---|\n| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_642 | vapour_pressure_osmometry | ActivityFugacityOsmoticProp | Liquid |\n\n### Variables\n\n| BLKvar_id | var_num_id | Variable | Component | Phase |\n|---|---|---|---|---|\n| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_2 | DOIcomp_2 | Liquid |\n| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_4 | DOIcomp_4 | Liquid |\n\n### Constraints\n\n| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |\n|---|---|---|---|---|---|\n| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |\n| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 97.5 | Liquid |\n\n### Conditions\n**Phases:** Liquid\n**Solvents:** DOIcomp_1→GLOBcomp_1 (GLOBsolvent_1)\n**Unc:** k=95%, Propagation, compiler\n\n### Data\n\n**Topology:** multi-variable(2): b(5-(hydroxymethyl)furan-2-carbaldehyde): 0.496–4.935, b(lithium chloride): 0.0–2.9965 | 20 pts → 20 kept (RDP)\n| b(5-(hydroxymethyl)furan-2-carbaldehyde,Liquid) | b(lithium chloride,Liquid) | φ_osm | ±U |\n|---|---|---|---|\n| 0.991 | 0.9989 | 0.9196 | 0.0178 |\n| 1.979 | 0.9979 | 0.8402 | 0.017 |\n| 2.966 | 0.9974 | 0.7497 | 0.0169 |\n| 3.95 | 0.9958 | 0.6512 | 0.0175 |\n| 4.929 | 0.994 | 0.5843 | 0.0185 |\n| 0.991 | 2.9965 | 1.2031 | 0.0241 |\n| 1.979 | 2.993 | 1.1083 | 0.0215 |\n| 2.967 | 2.991 | 1.0379 | 0.0198 |\n| 3.95 | 2.9864 | 0.9328 | 0.018 |\n| 4.927 | 2.9799 | 0.8644 | 0.0173 |\n| 0.496 | 0.0 | 0.8498 | 0.0236 |\n| 0.991 | 0.0 | 0.7295 | 0.022 |\n| 1.483 | 0.0 | 0.6354 | 0.0215 |\n| 1.98 | 0.0 | 0.5722 | 0.0217 |\n| 2.473 | 0.0 | 0.5215 | 0.0221 |\n| 2.967 | 0.0 | 0.4621 | 0.0228 |\n| 3.459 | 0.0 | 0.4424 | 0.0231 |\n| 3.95 | 0.0 | 0.3961 | 0.0239 |\n| 4.444 | 0.0 | 0.378 | 0.0242 |\n| 4.935 | 0.0 | 0.3702 | 0.0244 |\n",
      "compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H6O3/c7-3-5-1-2-6(4-8)9-5/h1-3,8H,4H2",
          "SMILES": "O=Cc1ccc(CO)o1",
          "comp_num_id": "GLOBcomp_569",
          "formula": "C6H6O3",
          "inchi_key": "NOEGNKMFWQHSLB-UHFFFAOYSA-N",
          "name": "5-(hydroxymethyl)furan-2-carbaldehyde",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "component_org_num": null,
          "constr_id": "temperature_k",
          "constr_num_id": "GLOBconstr_2",
          "digits": 5,
          "name": "Temperature, K",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eTemperature",
          "value": 298.15
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "component_org_num": null,
          "constr_id": "pressure_kpa",
          "constr_num_id": "GLOBconstr_1",
          "digits": 3,
          "name": "Pressure, kPa",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "ePressure",
          "value": 97.5
        }
      ],
      "data_summary": {
        "compound_names": [
          "water",
          "5-(hydroxymethyl)furan-2-carbaldehyde",
          "lithium chloride"
        ],
        "constraints_summary": {
          "BLKconstr_1": {
            "component_org_num": null,
            "digits": 5,
            "name": "Temperature, K",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 298.15
          },
          "BLKconstr_2": {
            "component_org_num": null,
            "digits": 3,
            "name": "Pressure, kPa",
            "phase": {
              "phase": "Liquid",
              "phase_id": "liquid",
              "phase_num_id": "GLOBphase_1"
            },
            "value": 97.5
          }
        },
        "effective_system_summary": {
          "n_search_eligible": 1,
          "n_subsystems": 1,
          "n_unique_points": 10,
          "system_types": [
            "binary"
          ]
        },
        "methods": [
          "vapour pressure osmometry"
        ],
        "n_points": 20,
        "phases": [
          "Liquid"
        ],
        "property_group": "ActivityFugacityOsmoticProp",
        "property_names": [
          "Osmotic coefficient"
        ],
        "property_stats": {
          "BLKprop_1": {
            "BLKprop_id": "BLKprop_1",
            "max": 1.2031,
            "mean": 0.712435,
            "min": 0.3702,
            "n": 20,
            "name": "Osmotic coefficient",
            "std": 0.251489
          }
        },
        "system_type": "ternary",
        "variable_ranges": {
          "BLKvar_1": {
            "BLKvar_id": "BLKvar_1",
            "max": 4.935,
            "min": 0.496,
            "n_unique": 14,
            "name": "Molality, mol/kg"
          },
          "BLKvar_2": {
            "BLKvar_id": "BLKvar_2",
            "max": 2.9965,
            "min": 0.0,
            "n_unique": 11,
            "name": "Molality, mol/kg"
          }
        }
      },
      "declared_compounds": [
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_1",
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "InChI": "InChI=1S/C6H6O3/c7-3-5-1-2-6(4-8)9-5/h1-3,8H,4H2",
          "SMILES": "O=Cc1ccc(CO)o1",
          "comp_num_id": "GLOBcomp_569",
          "formula": "C6H6O3",
          "inchi_key": "NOEGNKMFWQHSLB-UHFFFAOYSA-N",
          "name": "5-(hydroxymethyl)furan-2-carbaldehyde",
          "org_num": "DOIcomp_2",
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_4",
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "declared_system_type": "ternary",
      "doi": "10.1016/j.jct.2019.105878",
      "lit_num_id": "GLOBlit_5583",
      "match_criteria": [
        "compound",
        "property",
        "temperature"
      ],
      "match_score": 100,
      "matched_subsystem": null,
      "n_datapoints": 20,
      "paper_title": "Osmotic coefficients and activity coefficients in binary water/5-(hydroxymethyl)furfural and in ternary water/5-(hydroxymethyl)furfural/salt solutions at 298.15 K",
      "parent_n_datapoints": 20,
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "component_org_num": null,
          "group": "ActivityFugacityOsmoticProp",
          "meas_ID": "vapour_pressure_osmometry",
          "meas_num_id": "GLOBmeas_642",
          "method_custom": "vapour pressure osmometry",
          "method_standard": null,
          "name": "Osmotic coefficient",
          "presentation": "Direct value, X",
          "pressure_digits": null,
          "pressure_kPa": null,
          "prop_ID": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38",
          "property_phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "ref_phase": null,
          "ref_pressure_digits": null,
          "ref_pressure_kPa": null,
          "ref_state_type": null,
          "ref_temperature_K": null,
          "ref_temperature_digits": null,
          "standard_state": null,
          "temperature_K": null,
          "temperature_digits": null,
          "uncertainty": {
            "assessment_num": "BLKpropAssessment_1_1",
            "confidence_level": 95,
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "evaluator": "Data file compiler"
          }
        }
      ],
      "search_scope": "declared",
      "solvents": [
        {
          "comp_num_id": "GLOBcomp_1",
          "component_org_num": "DOIcomp_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "solvent_num_id": "GLOBsolvent_1"
        }
      ],
      "system_type": "ternary",
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "component_org_num": "DOIcomp_2",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_2",
          "var_num_id": "GLOBvar_4"
        },
        {
          "BLKvar_id": "BLKvar_2",
          "component_org_num": "DOIcomp_4",
          "name": "Molality, mol/kg",
          "phase": {
            "phase": "Liquid",
            "phase_id": "liquid",
            "phase_num_id": "GLOBphase_1"
          },
          "type": "eComponentComposition",
          "var_id": "molality_mol_kg_DOIcomp_4",
          "var_num_id": "GLOBvar_4"
        }
      ]
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
search_blocks: 5 search targets found.

| # | DOI | Block | Target | System | Points | Properties | Score |
|---|-----|-------|--------|--------|--------|------------|-------|
| 1 | 10.1016/j.jct.2013.08.018 | PROPblock_47 | declared | ternary | 9 | Osmotic coefficient | 100 |
| 2 | 10.1016/j.jct.2013.08.018 | PROPblock_55 | declared | ternary | 6 | Osmotic coefficient | 100 |
| 3 | 10.1016/j.jct.2013.08.018 | PROPblock_74 | declared | binary | 4 | Osmotic coefficient | 100 |
| 4 | 10.1016/j.jct.2016.07.003 | PROPblock_4 | declared | binary | 15 | Osmotic coefficient | 100 |
| 5 | 10.1016/j.jct.2019.105878 | PROPblock_3 | declared | ternary | 20 | Osmotic coefficient | 100 |

---
## PROPblock_47 | P/M | ternary | 9 pts | GLOBlit_3969
**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=2

### Reference
**lit_id:** 2014-hel-res-0
**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_1 | GLOBcomp_53 | 2-aminoacetic acid | C2H5NO2 |
| DOIcomp_18 | GLOBcomp_1 | water | H2O |
| DOIcomp_5 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_305 | commercial_osmometer_gonotec_070 | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_1 | DOIcomp_1 | Liquid |
| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_5 | DOIcomp_5 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |
| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_18→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** multi-variable(2): b(2-aminoacetic acid): 0.0–1.8, b(lithium chloride): 0.5–1.0 | 9 pts → 9 kept (RDP)
| b(2-aminoacetic acid,Liquid) | b(lithium chloride,Liquid) | φ_osm | ±U |
|---|---|---|---|
| 0.0 | 0.5 | 0.928 | 0.01 |
| 0.4 | 0.5 | 0.94 | 0.01 |
| 0.8 | 0.5 | 0.933 | 0.01 |
| 1.3 | 0.5 | 0.924 | 0.01 |
| 1.8 | 0.5 | 0.902 | 0.011 |
| 0.0 | 1.0 | 0.987 | 0.01 |
| 0.2 | 1.0 | 0.983 | 0.01 |
| 0.4 | 1.0 | 0.985 | 0.01 |
| 0.8 | 1.0 | 0.969 | 0.01 |


---
## PROPblock_55 | P/M | ternary | 6 pts | GLOBlit_3969
**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=2

### Reference
**lit_id:** 2014-hel-res-0
**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_18 | GLOBcomp_1 | water | H2O |
| DOIcomp_3 | GLOBcomp_116 | L-valine | C5H11NO2 |
| DOIcomp_5 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_305 | commercial_osmometer_gonotec_070 | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_3 | DOIcomp_3 | Liquid |
| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_5 | DOIcomp_5 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |
| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_18→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** multi-variable(2): b(L-valine): 0.0–0.5, b(lithium chloride): 0.5–1.0 | 6 pts → 6 kept (RDP)
| b(L-valine,Liquid) | b(lithium chloride,Liquid) | φ_osm | ±U |
|---|---|---|---|
| 0.0 | 0.5 | 0.955 | 0.01 |
| 0.2 | 0.5 | 0.972 | 0.01 |
| 0.5 | 0.5 | 0.988 | 0.01 |
| 0.0 | 1.0 | 0.978 | 0.01 |
| 0.2 | 1.0 | 0.997 | 0.01 |
| 0.5 | 1.0 | 1.005 | 0.01 |


---
## PROPblock_74 | P/M | binary | 4 pts | GLOBlit_3969

### Reference
**lit_id:** 2014-hel-res-0
**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_18 | GLOBcomp_1 | water | H2O |
| DOIcomp_5 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_305 | commercial_osmometer_gonotec_070 | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_5 | DOIcomp_5 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 101.0 | Liquid |
| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_18→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** non-monotonic(1 extrema) | 4 pts → 4 kept (RDP)
| b(lithium chloride,Liquid) | φ_osm | ±U |
|---|---|---|
| 0.5 | 0.928 | 0.01 |
| 1.0 | 0.987 | 0.01 |
| 0.5 | 0.955 | 0.01 |
| 1.0 | 0.978 | 0.01 |


---
## PROPblock_4 | P/M | binary | 15 pts | GLOBlit_4743

### Reference
**lit_id:** 2016-raf-fro-1
**Title:** The study of thermodynamic properties of the ternary (1-ethyl-3-methylimidazolium hydrogen sulfate + lithium chloride + water) system and corresponding binary systems at different temperatures and ambient pressure

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_2 | GLOBcomp_107 | lithium chloride | ClLi |
| DOIcomp_3 | GLOBcomp_1 | water | H2O |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_166 | isopie | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_2 | DOIcomp_2 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_1 | pressure_kpa |  | 87.0 | Liquid |
| BLKconstr_2 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_3→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** monotonic↑ | near-linear(R²=0.9906) | 15 pts → 9 kept (RDP)
| b(lithium chloride,Liquid) | φ_osm | ±U |
|---|---|---|
| 0.9064 | 1.02 | 0.01 |
| 1.2783 | 1.08 | 0.01 |
| 1.6157 | 1.09 | 0.01 |
| 1.667 | 1.11 | 0.01 |
| 1.8303 | 1.12 | 0.01 |
| 1.9902 | 1.16 | 0.01 |
| 2.563 | 1.21 | 0.01 |
| 3.0143 | 1.27 | 0.01 |
| 4.6684 | 1.55 | 0.02 |


---
## PROPblock_3 | P/M | ternary | 20 pts | GLOBlit_5583
**Composition projections:** 1 subsystem(s); types=binary; search-eligible=1; referenced points=10

### Reference
**lit_id:** 2019-gru-tsu-0
**Title:** Osmotic coefficients and activity coefficients in binary water/5-(hydroxymethyl)furfural and in ternary water/5-(hydroxymethyl)furfural/salt solutions at 298.15 K

### Compounds

| org_num | comp_num_id | Name | Formula |
|---|---|---|---|
| DOIcomp_1 | GLOBcomp_1 | water | H2O |
| DOIcomp_2 | GLOBcomp_569 | 5-(hydroxymethyl)furan-2-carbaldehyde | C6H6O3 |
| DOIcomp_4 | GLOBcomp_107 | lithium chloride | ClLi |

### Properties

| BLKprop_id | prop_num_id | Property | meas_num_id | Method | Group | Phase |
|---|---|---|---|---|---|---|
| BLKprop_1 | GLOBprop_38 | osmotic_coefficient | GLOBmeas_642 | vapour_pressure_osmometry | ActivityFugacityOsmoticProp | Liquid |

### Variables

| BLKvar_id | var_num_id | Variable | Component | Phase |
|---|---|---|---|---|
| BLKvar_1 | GLOBvar_4 | molality_mol_kg_DOIcomp_2 | DOIcomp_2 | Liquid |
| BLKvar_2 | GLOBvar_4 | molality_mol_kg_DOIcomp_4 | DOIcomp_4 | Liquid |

### Constraints

| BLKconstr_id | constr_num_id | Constraint | Component | Value | Phase |
|---|---|---|---|---|---|
| BLKconstr_1 | GLOBconstr_2 | temperature_k |  | 298.15 | Liquid |
| BLKconstr_2 | GLOBconstr_1 | pressure_kpa |  | 97.5 | Liquid |

### Conditions
**Phases:** Liquid
**Solvents:** DOIcomp_1→GLOBcomp_1 (GLOBsolvent_1)
**Unc:** k=95%, Propagation, compiler

### Data

**Topology:** multi-variable(2): b(5-(hydroxymethyl)furan-2-carbaldehyde): 0.496–4.935, b(lithium chloride): 0.0–2.9965 | 20 pts → 20 kept (RDP)
| b(5-(hydroxymethyl)furan-2-carbaldehyde,Liquid) | b(lithium chloride,Liquid) | φ_osm | ±U |
|---|---|---|---|
| 0.991 | 0.9989 | 0.9196 | 0.0178 |
| 1.979 | 0.9979 | 0.8402 | 0.017 |
| 2.966 | 0.9974 | 0.7497 | 0.0169 |
| 3.95 | 0.9958 | 0.6512 | 0.0175 |
| 4.929 | 0.994 | 0.5843 | 0.0185 |
| 0.991 | 2.9965 | 1.2031 | 0.0241 |
| 1.979 | 2.993 | 1.1083 | 0.0215 |
| 2.967 | 2.991 | 1.0379 | 0.0198 |
| 3.95 | 2.9864 | 0.9328 | 0.018 |
| 4.927 | 2.9799 | 0.8644 | 0.0173 |
| 0.496 | 0.0 | 0.8498 | 0.0236 |
| 0.991 | 0.0 | 0.7295 | 0.022 |
| 1.483 | 0.0 | 0.6354 | 0.0215 |
| 1.98 | 0.0 | 0.5722 | 0.0217 |
| 2.473 | 0.0 | 0.5215 | 0.0221 |
| 2.967 | 0.0 | 0.4621 | 0.0228 |
| 3.459 | 0.0 | 0.4424 | 0.0231 |
| 3.95 | 0.0 | 0.3961 | 0.0239 |
| 4.444 | 0.0 | 0.378 | 0.0242 |
| 4.935 | 0.0 | 0.3702 | 0.0244 |


```

### Model-visible result

```markdown
**Summary:** Five blocks with osmotic coefficient data involving LiCl + water at 298.15 K were found. Two are pure **binary** (LiCl + water): PROPblock_74 (4 pts, low molality) and PROPblock_4 (15 pts, wide molality range 0.91–4.67). Three are ternary systems containing LiCl + water with a third solute.

### Binary LiCl + Water Blocks (most relevant)

| Block | DOI | GLOBlit | Pts | Method | b(LiCl) range | φ range |
|---|---|---|---|---|---|---|
| PROPblock_74 | 10.1016/j.jct.2013.08.018 | GLOBlit_3969 | 4 | commercial_osmometer_gonotec_070 | 0.5–1.0 | 0.928–0.987 |
| PROPblock_4 | 10.1016/j.jct.2016.07.003 | GLOBlit_4743 | 15 | isopie | 0.9064–4.6684 | 1.02–1.55 |

### PROPblock_4 Data (best binary dataset, 298
```

### Integrity and timing

- Raw SHA-256: fc468da31c54a9d9e29d8c1b4316b0de5c96164078d40ed313d079faa9f57252
- Raw characters: 47925
- Hardcoded-compacted characters: 9872
- Model-visible characters: 722
- Agentic verdict: KEEP
- Tool elapsed: 9.205s
- Compactor elapsed: 14.902s
- Total elapsed: 24.112s

## Step 8: inspect_block_table

### Call arguments

```json
{
  "block_number": "GLOBlit_1540::PROPblock_13",
  "purpose": "Get the full data table for the binary LiCl + water mean ionic activity coefficient block to determine the concentration range and activity coefficient values.",
  "tasks": [
    "Determine the molality range of LiCl covered",
    "Get the range of mean ionic activity coefficient values",
    "Confirm the temperature is 298.15 K"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `inspect_block_table`

Serialization: `json`

```json
{
  "BLKsubsys_id": null,
  "block_number": "PROPblock_13",
  "bracket": null,
  "column_aliases": {
    "mean_ionic_activity_coefficient_lithium_chloride": "mean_ionic_activity_coefficient_<lithium chloride>",
    "molality_mol_kg_lithium_chloride": "molality_mol_kg_<lithium chloride>",
    "pressure_kpa": "pressure_kpa",
    "temperature_k": "temperature_k"
  },
  "columns": [
    "BLKpoint_id",
    "molality_mol_kg_<lithium chloride>",
    "temperature_k",
    "pressure_kpa",
    "mean_ionic_activity_coefficient_<lithium chloride>"
  ],
  "compounds": [
    "lithium chloride",
    "water"
  ],
  "constraints": [
    {
      "column": "temperature_k",
      "value": 298.15
    },
    {
      "column": "pressure_kpa",
      "value": 101.0
    }
  ],
  "doi": "10.1016/j.fluid.2014.08.026",
  "error": null,
  "inspection_id": "INSP_3498fde8e599",
  "lit_num_id": "GLOBlit_1540",
  "markdown": "**Data inspection** — 10.1016/j.fluid.2014.08.026 :: PROPblock_13 (binary: lithium chloride + water)\nfilter: none (whole block)\nblock constraints: temperature_k = 298.15; pressure_kpa = 101.0\n\n| BLKpoint_id | molality_mol_kg_<lithium chloride> | temperature_k | pressure_kpa | mean_ionic_activity_coefficient_<lithium chloride> |\n|---|---|---|---|---|\n| BLKpoint_1 | 0.0035 | 298.15 | 101.0 | 0.9388 |\n| BLKpoint_3 | 0.0109 | 298.15 | 101.0 | 0.9005 |\n| BLKpoint_6 | 0.0271 | 298.15 | 101.0 | 0.8599 |\n| BLKpoint_12 | 0.1339 | 298.15 | 101.0 | 0.7772 |\n| BLKpoint_13 | 0.1667 | 298.15 | 101.0 | 0.7671 |\n| BLKpoint_16 | 0.3285 | 298.15 | 101.0 | 0.7441 |\n| BLKpoint_17 | 0.3929 | 298.15 | 101.0 | 0.7414 |\n| BLKpoint_18 | 0.4919 | 298.15 | 101.0 | 0.7408 |\n| BLKpoint_19 | 0.5927 | 298.15 | 101.0 | 0.7434 |\n| BLKpoint_23 | 1.1197 | 298.15 | 101.0 | 0.7869 |\n| BLKpoint_24 | 1.2231 | 298.15 | 101.0 | 0.7993 |\n| BLKpoint_25 | 1.3645 | 298.15 | 101.0 | 0.818 |\n| BLKpoint_26 | 1.5095 | 298.15 | 101.0 | 0.839 |\n| BLKpoint_34 | 0.0494 | 298.15 | 101.0 | 0.8291 |\n| BLKpoint_37 | 0.0847 | 298.15 | 101.0 | 0.8005 |\n| BLKpoint_40 | 0.1658 | 298.15 | 101.0 | 0.7673 |\n| BLKpoint_44 | 0.3349 | 298.15 | 101.0 | 0.7438 |\n| BLKpoint_45 | 0.4057 | 298.15 | 101.0 | 0.7411 |\n| BLKpoint_47 | 0.5696 | 298.15 | 101.0 | 0.7426 |\n| BLKpoint_48 | 0.6596 | 298.15 | 101.0 | 0.7466 |\n| BLKpoint_55 | 1.5555 | 298.15 | 101.0 | 0.8461 |\n| BLKpoint_56 | 0.0033 | 298.15 | 101.0 | 0.9425 |\n| BLKpoint_67 | 0.0883 | 298.15 | 101.0 | 0.8039 |\n| BLKpoint_68 | 0.1067 | 298.15 | 101.0 | 0.7943 |\n| BLKpoint_69 | 0.1369 | 298.15 | 101.0 | 0.7821 |\n| BLKpoint_70 | 0.1659 | 298.15 | 101.0 | 0.7734 |\n| BLKpoint_73 | 0.3324 | 298.15 | 101.0 | 0.7504 |\n| BLKpoint_74 | 0.4011 | 298.15 | 101.0 | 0.7478 |\n| BLKpoint_75 | 0.4952 | 298.15 | 101.0 | 0.7477 |\n| BLKpoint_76 | 0.5861 | 298.15 | 101.0 | 0.7503 |\n| BLKpoint_77 | 0.703 | 298.15 | 101.0 | 0.7564 |\n| BLKpoint_78 | 0.8141 | 298.15 | 101.0 | 0.7644 |\n| BLKpoint_79 | 0.9611 | 298.15 | 101.0 | 0.7776 |\n| BLKpoint_80 | 1.0961 | 298.15 | 101.0 | 0.7918 |\n| BLKpoint_81 | 1.2032 | 298.15 | 101.0 | 0.8045 |\n| BLKpoint_82 | 1.3462 | 298.15 | 101.0 | 0.8229 |\n| BLKpoint_83 | 1.485 | 298.15 | 101.0 | 0.8424 |\n| BLKpoint_98 | 0.1447 | 298.15 | 101.0 | 0.7736 |\n| BLKpoint_103 | 0.3701 | 298.15 | 101.0 | 0.7421 |\n| BLKpoint_107 | 0.7066 | 298.15 | 101.0 | 0.7493 |\n| BLKpoint_108 | 0.7946 | 298.15 | 101.0 | 0.7554 |\n| BLKpoint_109 | 0.8663 | 298.15 | 101.0 | 0.7612 |\n| BLKpoint_110 | 0.9719 | 298.15 | 101.0 | 0.771 |\n| BLKpoint_111 | 1.0687 | 298.15 | 101.0 | 0.7811 |\n| BLKpoint_112 | 1.1915 | 298.15 | 101.0 | 0.7954 |\n| BLKpoint_125 | 0.0921 | 298.15 | 101.0 | 0.796 |\n| BLKpoint_126 | 0.1138 | 298.15 | 101.0 | 0.7852 |\n| BLKpoint_128 | 0.1816 | 298.15 | 101.0 | 0.7634 |\n| BLKpoint_133 | 0.5054 | 298.15 | 101.0 | 0.741 |\n| BLKpoint_141 | 1.5483 | 298.15 | 101.0 | 0.845 |\n\nmode: RDP — 50 of 141 matched rows shown (shape-preserving; block has 141). Quote ONLY shown rows or the stats line; narrow `where` for other rows.\ntopology: mean_ionic_activity_coefficient_lithium_chloride vs molality_mol_kg_lithium_chloride: non-monotonic(47 extrema)\nstats (matched, n=141): molality_mol_kg_lithium_chloride 0.0033–1.5555 (n=141); temperature_k 298.15–298.15 (n=141); pressure_kpa 101.0–101.0 (n=141); mean_ionic_activity_coefficient_lithium_chloride 0.7406–0.9425 (n=141)\ninspection_id: INSP_3498fde8e599\nData points may be quoted ONLY verbatim from the table above or the stats lines.",
  "n_rows_matched": 141,
  "n_rows_shown": 50,
  "n_rows_total": 141,
  "nearest": null,
  "rows_shown": [
    {
      "BLKpoint_id": "BLKpoint_1",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.9388",
      "molality_mol_kg_<lithium chloride>": "0.0035",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_3",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.9005",
      "molality_mol_kg_<lithium chloride>": "0.0109",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_6",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8599",
      "molality_mol_kg_<lithium chloride>": "0.0271",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_12",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7772",
      "molality_mol_kg_<lithium chloride>": "0.1339",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_13",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7671",
      "molality_mol_kg_<lithium chloride>": "0.1667",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_16",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7441",
      "molality_mol_kg_<lithium chloride>": "0.3285",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_17",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7414",
      "molality_mol_kg_<lithium chloride>": "0.3929",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_18",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7408",
      "molality_mol_kg_<lithium chloride>": "0.4919",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_19",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7434",
      "molality_mol_kg_<lithium chloride>": "0.5927",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_23",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7869",
      "molality_mol_kg_<lithium chloride>": "1.1197",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_24",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7993",
      "molality_mol_kg_<lithium chloride>": "1.2231",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_25",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.818",
      "molality_mol_kg_<lithium chloride>": "1.3645",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_26",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.839",
      "molality_mol_kg_<lithium chloride>": "1.5095",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_34",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8291",
      "molality_mol_kg_<lithium chloride>": "0.0494",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_37",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8005",
      "molality_mol_kg_<lithium chloride>": "0.0847",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_40",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7673",
      "molality_mol_kg_<lithium chloride>": "0.1658",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_44",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7438",
      "molality_mol_kg_<lithium chloride>": "0.3349",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_45",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7411",
      "molality_mol_kg_<lithium chloride>": "0.4057",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_47",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7426",
      "molality_mol_kg_<lithium chloride>": "0.5696",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_48",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7466",
      "molality_mol_kg_<lithium chloride>": "0.6596",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_55",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8461",
      "molality_mol_kg_<lithium chloride>": "1.5555",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_56",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.9425",
      "molality_mol_kg_<lithium chloride>": "0.0033",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_67",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8039",
      "molality_mol_kg_<lithium chloride>": "0.0883",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_68",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7943",
      "molality_mol_kg_<lithium chloride>": "0.1067",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_69",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7821",
      "molality_mol_kg_<lithium chloride>": "0.1369",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_70",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7734",
      "molality_mol_kg_<lithium chloride>": "0.1659",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_73",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7504",
      "molality_mol_kg_<lithium chloride>": "0.3324",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_74",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7478",
      "molality_mol_kg_<lithium chloride>": "0.4011",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_75",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7477",
      "molality_mol_kg_<lithium chloride>": "0.4952",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_76",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7503",
      "molality_mol_kg_<lithium chloride>": "0.5861",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_77",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7564",
      "molality_mol_kg_<lithium chloride>": "0.703",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_78",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7644",
      "molality_mol_kg_<lithium chloride>": "0.8141",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_79",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7776",
      "molality_mol_kg_<lithium chloride>": "0.9611",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_80",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7918",
      "molality_mol_kg_<lithium chloride>": "1.0961",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_81",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8045",
      "molality_mol_kg_<lithium chloride>": "1.2032",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_82",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8229",
      "molality_mol_kg_<lithium chloride>": "1.3462",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_83",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.8424",
      "molality_mol_kg_<lithium chloride>": "1.485",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_98",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7736",
      "molality_mol_kg_<lithium chloride>": "0.1447",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_103",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7421",
      "molality_mol_kg_<lithium chloride>": "0.3701",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_107",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7493",
      "molality_mol_kg_<lithium chloride>": "0.7066",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_108",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7554",
      "molality_mol_kg_<lithium chloride>": "0.7946",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_109",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7612",
      "molality_mol_kg_<lithium chloride>": "0.8663",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_110",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.771",
      "molality_mol_kg_<lithium chloride>": "0.9719",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_111",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7811",
      "molality_mol_kg_<lithium chloride>": "1.0687",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_112",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7954",
      "molality_mol_kg_<lithium chloride>": "1.1915",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_125",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.796",
      "molality_mol_kg_<lithium chloride>": "0.0921",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_126",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7852",
      "molality_mol_kg_<lithium chloride>": "0.1138",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_128",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.7634",
      "molality_mol_kg_<lithium chloride>": "0.1816",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_133",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.741",
      "molality_mol_kg_<lithium chloride>": "0.5054",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    },
    {
      "BLKpoint_id": "BLKpoint_141",
      "mean_ionic_activity_coefficient_<lithium chloride>": "0.845",
      "molality_mol_kg_<lithium chloride>": "1.5483",
      "pressure_kpa": "101.0",
      "temperature_k": "298.15"
    }
  ],
  "stats": {
    "full": {
      "mean_ionic_activity_coefficient_lithium_chloride": {
        "max": "0.9425",
        "min": "0.7406",
        "n": 141,
        "n_finite": 141
      },
      "molality_mol_kg_lithium_chloride": {
        "max": "1.5555",
        "min": "0.0033",
        "n": 141,
        "n_finite": 141
      },
      "pressure_kpa": {
        "max": "101.0",
        "min": "101.0",
        "n": 141,
        "n_finite": 141
      },
      "temperature_k": {
        "max": "298.15",
        "min": "298.15",
        "n": 141,
        "n_finite": 141
      }
    },
    "matched": {
      "mean_ionic_activity_coefficient_lithium_chloride": {
        "max": "0.9425",
        "min": "0.7406",
        "n": 141,
        "n_finite": 141
      },
      "molality_mol_kg_lithium_chloride": {
        "max": "1.5555",
        "min": "0.0033",
        "n": 141,
        "n_finite": 141
      },
      "pressure_kpa": {
        "max": "101.0",
        "min": "101.0",
        "n": 141,
        "n_finite": 141
      },
      "temperature_k": {
        "max": "298.15",
        "min": "298.15",
        "n": 141,
        "n_finite": 141
      }
    }
  },
  "system_type": "binary",
  "table_mode": "rdp",
  "tool": "inspect_block_table",
  "topology": [
    {
      "property": "mean_ionic_activity_coefficient_lithium_chloride",
      "shape": "non-monotonic(47 extrema)",
      "vs": "molality_mol_kg_lithium_chloride"
    }
  ],
  "where": null
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

```markdown
**Data inspection** — 10.1016/j.fluid.2014.08.026 :: PROPblock_13 (binary: lithium chloride + water)
filter: none (whole block)
block constraints: temperature_k = 298.15; pressure_kpa = 101.0

| BLKpoint_id | molality_mol_kg_<lithium chloride> | temperature_k | pressure_kpa | mean_ionic_activity_coefficient_<lithium chloride> |
|---|---|---|---|---|
| BLKpoint_1 | 0.0035 | 298.15 | 101.0 | 0.9388 |
| BLKpoint_3 | 0.0109 | 298.15 | 101.0 | 0.9005 |
| BLKpoint_6 | 0.0271 | 298.15 | 101.0 | 0.8599 |
| BLKpoint_12 | 0.1339 | 298.15 | 101.0 | 0.7772 |
| BLKpoint_13 | 0.1667 | 298.15 | 101.0 | 0.7671 |
| BLKpoint_16 | 0.3285 | 298.15 | 101.0 | 0.7441 |
| BLKpoint_17 | 0.3929 | 298.15 | 101.0 | 0.7414 |
| BLKpoint_18 | 0.4919 | 298.15 | 101.0 | 0.7408 |
| BLKpoint_19 | 0.5927 | 298.15 | 101.0 | 0.7434 |
| BLKpoint_23 | 1.1197 | 298.15 | 101.0 | 0.7869 |
| BLKpoint_24 | 1.2231 | 298.15 | 101.0 | 0.7993 |
| BLKpoint_25 | 1.3645 | 298.15 | 101.0 | 0.818 |
| BLKpoint_26 | 1.5095 | 298.15 | 101.0 | 0.839 |
| BLKpoint_34 | 0.0494 | 298.15 | 101.0 | 0.8291 |
| BLKpoint_37 | 0.0847 | 298.15 | 101.0 | 0.8005 |
| BLKpoint_40 | 0.1658 | 298.15 | 101.0 | 0.7673 |
| BLKpoint_44 | 0.3349 | 298.15 | 101.0 | 0.7438 |
| BLKpoint_45 | 0.4057 | 298.15 | 101.0 | 0.7411 |
| BLKpoint_47 | 0.5696 | 298.15 | 101.0 | 0.7426 |
| BLKpoint_48 | 0.6596 | 298.15 | 101.0 | 0.7466 |
| BLKpoint_55 | 1.5555 | 298.15 | 101.0 | 0.8461 |
| BLKpoint_56 | 0.0033 | 298.15 | 101.0 | 0.9425 |
| BLKpoint_67 | 0.0883 | 298.15 | 101.0 | 0.8039 |
| BLKpoint_68 | 0.1067 | 298.15 | 101.0 | 0.7943 |
| BLKpoint_69 | 0.1369 | 298.15 | 101.0 | 0.7821 |
| BLKpoint_70 | 0.1659 | 298.15 | 101.0 | 0.7734 |
| BLKpoint_73 | 0.3324 | 298.15 | 101.0 | 0.7504 |
| BLKpoint_74 | 0.4011 | 298.15 | 101.0 | 0.7478 |
| BLKpoint_75 | 0.4952 | 298.15 | 101.0 | 0.7477 |
| BLKpoint_76 | 0.5861 | 298.15 | 101.0 | 0.7503 |
| BLKpoint_77 | 0.703 | 298.15 | 101.0 | 0.7564 |
| BLKpoint_78 | 0.8141 | 298.15 | 101.0 | 0.7644 |
| BLKpoint_79 | 0.9611 | 298.15 | 101.0 | 0.7776 |
| BLKpoint_80 | 1.0961 | 298.15 | 101.0 | 0.7918 |
| BLKpoint_81 | 1.2032 | 298.15 | 101.0 | 0.8045 |
| BLKpoint_82 | 1.3462 | 298.15 | 101.0 | 0.8229 |
| BLKpoint_83 | 1.485 | 298.15 | 101.0 | 0.8424 |
| BLKpoint_98 | 0.1447 | 298.15 | 101.0 | 0.7736 |
| BLKpoint_103 | 0.3701 | 298.15 | 101.0 | 0.7421 |
| BLKpoint_107 | 0.7066 | 298.15 | 101.0 | 0.7493 |
| BLKpoint_108 | 0.7946 | 298.15 | 101.0 | 0.7554 |
| BLKpoint_109 | 0.8663 | 298.15 | 101.0 | 0.7612 |
| BLKpoint_110 | 0.9719 | 298.15 | 101.0 | 0.771 |
| BLKpoint_111 | 1.0687 | 298.15 | 101.0 | 0.7811 |
| BLKpoint_112 | 1.1915 | 298.15 | 101.0 | 0.7954 |
| BLKpoint_125 | 0.0921 | 298.15 | 101.0 | 0.796 |
| BLKpoint_126 | 0.1138 | 298.15 | 101.0 | 0.7852 |
| BLKpoint_128 | 0.1816 | 298.15 | 101.0 | 0.7634 |
| BLKpoint_133 | 0.5054 | 298.15 | 101.0 | 0.741 |
| BLKpoint_141 | 1.5483 | 298.15 | 101.0 | 0.845 |

mode: RDP — 50 of 141 matched rows shown (shape-preserving; block has 141). Quote ONLY shown rows or the stats line; narrow `where` for other rows.
topology: mean_ionic_activity_coefficient_lithium_chloride vs molality_mol_kg_lithium_chloride: non-monotonic(47 extrema)
stats (matched, n=141): molality_mol_kg_lithium_chloride 0.0033–1.5555 (n=141); temperature_k 298.15–298.15 (n=141); pressure_kpa 101.0–101.0 (n=141); mean_ionic_activity_coefficient_lithium_chloride 0.7406–0.9425 (n=141)
inspection_id: INSP_3498fde8e599
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Model-visible result

```markdown
**Data inspection** — 10.1016/j.fluid.2014.08.026 :: PROPblock_13 (binary: lithium chloride + water)
filter: none (whole block)
block constraints: temperature_k = 298.15; pressure_kpa = 101.0

| BLKpoint_id | molality_mol_kg_<lithium chloride> | temperature_k | pressure_kpa | mean_ionic_activity_coefficient_<lithium chloride> |
|---|---|---|---|---|
| BLKpoint_1 | 0.0035 | 298.15 | 101.0 | 0.9388 |
| BLKpoint_3 | 0.0109 | 298.15 | 101.0 | 0.9005 |
| BLKpoint_6 | 0.0271 | 298.15 | 101.0 | 0.8599 |
| BLKpoint_12 | 0.1339 | 298.15 | 101.0 | 0.7772 |
| BLKpoint_13 | 0.1667 | 298.15 | 101.0 | 0.7671 |
| BLKpoint_16 | 0.3285 | 298.15 | 101.0 | 0.7441 |
| BLKpoint_17 | 0.3929 | 298.15 | 101.0 | 0.7414 |
| BLKpoint_18 | 0.4919 | 298.15 | 101.0 | 0.7408 |
| BLKpoint_19 | 0.5927 | 298.15 | 101.0 | 0.7434 |
| BLKpoint_23 | 1.1197 | 298.15 | 101.0 | 0.7869 |
| BLKpoint_24 | 1.2231 | 298.15 | 101.0 | 0.7993 |
| BLKpoint_25 | 1.3645 | 298.15 | 101.0 | 0.818 |
| BLKpoint_26 | 1.5095 | 298.15 | 101.0 | 0.839 |
| BLKpoint_34 | 0.0494 | 298.15 | 101.0 | 0.8291 |
| BLKpoint_37 | 0.0847 | 298.15 | 101.0 | 0.8005 |
| BLKpoint_40 | 0.1658 | 298.15 | 101.0 | 0.7673 |
| BLKpoint_44 | 0.3349 | 298.15 | 101.0 | 0.7438 |
| BLKpoint_45 | 0.4057 | 298.15 | 101.0 | 0.7411 |
| BLKpoint_47 | 0.5696 | 298.15 | 101.0 | 0.7426 |
| BLKpoint_48 | 0.6596 | 298.15 | 101.0 | 0.7466 |
| BLKpoint_55 | 1.5555 | 298.15 | 101.0 | 0.8461 |
| BLKpoint_56 | 0.0033 | 298.15 | 101.0 | 0.9425 |
| BLKpoint_67 | 0.0883 | 298.15 | 101.0 | 0.8039 |
| BLKpoint_68 | 0.1067 | 298.15 | 101.0 | 0.7943 |
| BLKpoint_69 | 0.1369 | 298.15 | 101.0 | 0.7821 |
| BLKpoint_70 | 0.1659 | 298.15 | 101.0 | 0.7734 |
| BLKpoint_73 | 0.3324 | 298.15 | 101.0 | 0.7504 |
| BLKpoint_74 | 0.4011 | 298.15 | 101.0 | 0.7478 |
| BLKpoint_75 | 0.4952 | 298.15 | 101.0 | 0.7477 |
| BLKpoint_76 | 0.5861 | 298.15 | 101.0 | 0.7503 |
| BLKpoint_77 | 0.703 | 298.15 | 101.0 | 0.7564 |
| BLKpoint_78 | 0.8141 | 298.15 | 101.0 | 0.7644 |
| BLKpoint_79 | 0.9611 | 298.15 | 101.0 | 0.7776 |
| BLKpoint_80 | 1.0961 | 298.15 | 101.0 | 0.7918 |
| BLKpoint_81 | 1.2032 | 298.15 | 101.0 | 0.8045 |
| BLKpoint_82 | 1.3462 | 298.15 | 101.0 | 0.8229 |
| BLKpoint_83 | 1.485 | 298.15 | 101.0 | 0.8424 |
| BLKpoint_98 | 0.1447 | 298.15 | 101.0 | 0.7736 |
| BLKpoint_103 | 0.3701 | 298.15 | 101.0 | 0.7421 |
| BLKpoint_107 | 0.7066 | 298.15 | 101.0 | 0.7493 |
| BLKpoint_108 | 0.7946 | 298.15 | 101.0 | 0.7554 |
| BLKpoint_109 | 0.8663 | 298.15 | 101.0 | 0.7612 |
| BLKpoint_110 | 0.9719 | 298.15 | 101.0 | 0.771 |
| BLKpoint_111 | 1.0687 | 298.15 | 101.0 | 0.7811 |
| BLKpoint_112 | 1.1915 | 298.15 | 101.0 | 0.7954 |
| BLKpoint_125 | 0.0921 | 298.15 | 101.0 | 0.796 |
| BLKpoint_126 | 0.1138 | 298.15 | 101.0 | 0.7852 |
| BLKpoint_128 | 0.1816 | 298.15 | 101.0 | 0.7634 |
| BLKpoint_133 | 0.5054 | 298.15 | 101.0 | 0.741 |
| BLKpoint_141 | 1.5483 | 298.15 | 101.0 | 0.845 |

mode: RDP — 50 of 141 matched rows shown (shape-preserving; block has 141). Quote ONLY shown rows or the stats line; narrow `where` for other rows.
topology: mean_ionic_activity_coefficient_lithium_chloride vs molality_mol_kg_lithium_chloride: non-monotonic(47 extrema)
stats (matched, n=141): molality_mol_kg_lithium_chloride 0.0033–1.5555 (n=141); temperature_k 298.15–298.15 (n=141); pressure_kpa 101.0–101.0 (n=141); mean_ionic_activity_coefficient_lithium_chloride 0.7406–0.9425 (n=141)
inspection_id: INSP_3498fde8e599
Data points may be quoted ONLY verbatim from the table above or the stats lines.
```

### Integrity and timing

- Raw SHA-256: 5f882b7ab2ee426a6fac4fc86f559b1d5c84c009d88c49dd7db440df2c00c267
- Raw characters: 17932
- Hardcoded-compacted characters: 3509
- Model-visible characters: 3509
- Agentic verdict: SKIP
- Tool elapsed: 0.066s
- Compactor elapsed: 0.000s
- Total elapsed: 0.068s

## Step 9: search_references

### Call arguments

```json
{
  "literature": "GLOBlit_1540",
  "purpose": "Get the full citation for the main reference containing LiCl activity coefficient data.",
  "tasks": [
    "Get the authors, title, journal, and year for GLOBlit_1540"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_references`

Serialization: `json`

```json
{
  "n_results": 1,
  "query_params": {
    "author": null,
    "compound": null,
    "compound_resolved_ids": null,
    "doi_resolved": "10.1016/j.fluid.2014.08.026",
    "journal": null,
    "limit": 50,
    "literature": "GLOBlit_1540",
    "property": null,
    "property_resolved_ids": null,
    "title_keywords": null,
    "year": null,
    "year_range": null
  },
  "results": [
    {
      "authors": [
        "Zhao, X.[Xuehong]",
        "Li, S.[Shu'ni]",
        "Zhai, Q.[Quanguo]",
        "Jiang, Y.[Yucheng]",
        "Hu, M.[Mancheng]"
      ],
      "compact_md": "# RMS | 10.1016/j.fluid.2014.08.026 | GLOBlit_1540\n\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n**Authors:** Zhao; Li; Zhai; Jiang; Hu\n**Journal:** Fluid Phase Equilib. 2014 382:127-132\n**Source:** Original | Cited: 2020-09-30\n\n## Abstract\nThis article deals with the mean activity coefficients of LiCl in amide water mixtures with both epsilon-increasing co-solvent (urea water, N-methylformamide water), and epsilon-decreasing co-solvent (N,N-dimethylformamide water, N,N-dimethylacetamide water) systems at 298.15 K by potentiometric method. Meanwhile, thermodynamic properties including the osmotic coefficients, the excess Gibbs free energy, the standard solubility product, the primary LiCl hydration number and the standard free energy of transference from water to the mixtures were also calculated. The nonideal behavior of these systems has been discussed in terms of the Pitzer, the Modified Pitzer and the extended Debye-Huckel equations parameters.\n\n## Keywords\nLiCl; Amide; Potentiometric; Activity coefficients.\n\n## Data Inventory\n| Metric | Value |\n|--------|-------|\n| Compounds | 6 |\n| Blocks | 13 |\n| Datapoints | 742 |\n| Has P/M data | yes |\n| Has reaction | no |\n| T range | 298.15 K |\n| P range | 100.0-101.0 kPa |\n\n### Compounds\n| comp_id | Name | IK | Formula |\n|---|---|---|---|\n| GLOBcomp_94 | urea | XSQUKJJJFZCRTK-UHFFF | CH4N2O |\n| GLOBcomp_1 | water | XLYOFNOQVPJJNP-UHFFF | H2O |\n| GLOBcomp_177 | N-methylformamide | ATHHXGZTWNVVOU-UHFFF | C2H5NO |\n| GLOBcomp_18 | dimethylformamide | ZMXDDKWLCZADIW-UHFFF | C3H7NO |\n| GLOBcomp_63 | N,N-dimethylethanamide | FXHOOIRPVKKKFG-UHFFF | C4H9NO |\n| GLOBcomp_107 | lithium chloride | KWGKDLIKAYFUFQ-UHFFF | ClLi |\n\n### Properties\n- GLOBprop_1 | mass_density_kg_m3 | Mass density, kg/m3\n- GLOBprop_56 | mean_ionic_activity_coefficient | Mean ionic activity coefficient\n- GLOBprop_42 | relative_permittivity_at_various_frequencies | Relative permittivity at various frequencies\n\n### Property Groups\nActivityFugacityOsmoticProp; RefractionSurfaceTensionSoundSpeed; VolumetricProp\n\n### System Types\nbinary; ternary\n",
      "compound_list": [
        {
          "InChI": "InChI=1S/CH4N2O/c2-1(3)4/h(H4,2,3,4)",
          "SMILES": "N=C(N)O",
          "comp_num_id": "GLOBcomp_94",
          "formula": "CH4N2O",
          "inchi_key": "XSQUKJJJFZCRTK-UHFFFAOYSA-N",
          "name": "urea",
          "org_num": "DOIcomp_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2"
        },
        {
          "InChI": "InChI=1S/C2H5NO/c1-3-2-4/h2H,1H3,(H,3,4)",
          "SMILES": "CN=CO",
          "comp_num_id": "GLOBcomp_177",
          "formula": "C2H5NO",
          "inchi_key": "ATHHXGZTWNVVOU-UHFFFAOYSA-N",
          "name": "N-methylformamide",
          "org_num": "DOIcomp_3"
        },
        {
          "InChI": "InChI=1S/C3H7NO/c1-4(2)3-5/h3H,1-2H3",
          "SMILES": "CN(C)C=O",
          "comp_num_id": "GLOBcomp_18",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "name": "dimethylformamide",
          "org_num": "DOIcomp_4"
        },
        {
          "InChI": "InChI=1S/C4H9NO/c1-4(6)5(2)3/h1-3H3",
          "SMILES": "CC(=O)N(C)C",
          "comp_num_id": "GLOBcomp_63",
          "formula": "C4H9NO",
          "inchi_key": "FXHOOIRPVKKKFG-UHFFFAOYSA-N",
          "name": "N,N-dimethylethanamide",
          "org_num": "DOIcomp_5"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6"
        }
      ],
      "doi": "10.1016/j.fluid.2014.08.026",
      "journal": "Fluid Phase Equilib.",
      "lit_id": "2014-zha-li-3",
      "lit_num_id": "GLOBlit_1540",
      "match_score": 100,
      "n_blocks": 13,
      "n_compounds": 6,
      "n_datapoints": 742,
      "pages": "127-132",
      "properties": [
        {
          "component_linked": false,
          "name": "Mass density, kg/m3",
          "prop_id": "mass_density_kg_m3",
          "prop_num_id": "GLOBprop_1"
        },
        {
          "component_linked": true,
          "name": "Mean ionic activity coefficient",
          "prop_id": "mean_ionic_activity_coefficient",
          "prop_num_id": "GLOBprop_56"
        },
        {
          "component_linked": false,
          "name": "Relative permittivity at various frequencies",
          "prop_id": "relative_permittivity_at_various_frequencies",
          "prop_num_id": "GLOBprop_42"
        }
      ],
      "property_groups": [
        "ActivityFugacityOsmoticProp",
        "RefractionSurfaceTensionSoundSpeed",
        "VolumetricProp"
      ],
      "system_types": [
        "binary",
        "ternary"
      ],
      "title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "volume": "382",
      "year": 2014
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

````markdown
# Raw tool result: `search_references`

Serialization: `json`

```json
{
  "n_results": 1,
  "query_params": {
    "author": null,
    "compound": null,
    "compound_resolved_ids": null,
    "doi_resolved": "10.1016/j.fluid.2014.08.026",
    "journal": null,
    "limit": 50,
    "literature": "GLOBlit_1540",
    "property": null,
    "property_resolved_ids": null,
    "title_keywords": null,
    "year": null,
    "year_range": null
  },
  "results": [
    {
      "authors": [
        "Zhao, X.[Xuehong]",
        "Li, S.[Shu'ni]",
        "Zhai, Q.[Quanguo]",
        "Jiang, Y.[Yucheng]",
        "Hu, M.[Mancheng]"
      ],
      "compact_md": "# RMS | 10.1016/j.fluid.2014.08.026 | GLOBlit_1540\n\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n**Authors:** Zhao; Li; Zhai; Jiang; Hu\n**Journal:** Fluid Phase Equilib. 2014 382:127-132\n**Source:** Original | Cited: 2020-09-30\n\n## Abstract\nThis article deals with the mean activity coefficients of LiCl in amide water mixtures with both epsilon-increasing co-solvent (urea water, N-methylformamide water), and epsilon-decreasing co-solvent (N,N-dimethylformamide water, N,N-dimethylacetamide water) systems at 298.15 K by potentiometric method. Meanwhile, thermodynamic properties including the osmotic coefficients, the excess Gibbs free energy, the standard solubility product, the primary LiCl hydration number and the standard free energy of transference from water to the mixtures were also calculated. The nonideal behavior of these systems has been discussed in terms of the Pitzer, the Modified Pitzer and the extended Debye-Huckel equations parameters.\n\n## Keywords\nLiCl; Amide; Potentiometric; Activity coefficients.\n\n## Data Inventory\n| Metric | Value |\n|--------|-------|\n| Compounds | 6 |\n| Blocks | 13 |\n| Datapoints | 742 |\n| Has P/M data | yes |\n| Has reaction | no |\n| T range | 298.15 K |\n| P range | 100.0-101.0 kPa |\n\n### Compounds\n| comp_id | Name | IK | Formula |\n|---|---|---|---|\n| GLOBcomp_94 | urea | XSQUKJJJFZCRTK-UHFFF | CH4N2O |\n| GLOBcomp_1 | water | XLYOFNOQVPJJNP-UHFFF | H2O |\n| GLOBcomp_177 | N-methylformamide | ATHHXGZTWNVVOU-UHFFF | C2H5NO |\n| GLOBcomp_18 | dimethylformamide | ZMXDDKWLCZADIW-UHFFF | C3H7NO |\n| GLOBcomp_63 | N,N-dimethylethanamide | FXHOOIRPVKKKFG-UHFFF | C4H9NO |\n| GLOBcomp_107 | lithium chloride | KWGKDLIKAYFUFQ-UHFFF | ClLi |\n\n### Properties\n- GLOBprop_1 | mass_density_kg_m3 | Mass density, kg/m3\n- GLOBprop_56 | mean_ionic_activity_coefficient | Mean ionic activity coefficient\n- GLOBprop_42 | relative_permittivity_at_various_frequencies | Relative permittivity at various frequencies\n\n### Property Groups\nActivityFugacityOsmoticProp; RefractionSurfaceTensionSoundSpeed; VolumetricProp\n\n### System Types\nbinary; ternary\n",
      "compound_list": [
        {
          "InChI": "InChI=1S/CH4N2O/c2-1(3)4/h(H4,2,3,4)",
          "SMILES": "N=C(N)O",
          "comp_num_id": "GLOBcomp_94",
          "formula": "CH4N2O",
          "inchi_key": "XSQUKJJJFZCRTK-UHFFFAOYSA-N",
          "name": "urea",
          "org_num": "DOIcomp_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2"
        },
        {
          "InChI": "InChI=1S/C2H5NO/c1-3-2-4/h2H,1H3,(H,3,4)",
          "SMILES": "CN=CO",
          "comp_num_id": "GLOBcomp_177",
          "formula": "C2H5NO",
          "inchi_key": "ATHHXGZTWNVVOU-UHFFFAOYSA-N",
          "name": "N-methylformamide",
          "org_num": "DOIcomp_3"
        },
        {
          "InChI": "InChI=1S/C3H7NO/c1-4(2)3-5/h3H,1-2H3",
          "SMILES": "CN(C)C=O",
          "comp_num_id": "GLOBcomp_18",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "name": "dimethylformamide",
          "org_num": "DOIcomp_4"
        },
        {
          "InChI": "InChI=1S/C4H9NO/c1-4(6)5(2)3/h1-3H3",
          "SMILES": "CC(=O)N(C)C",
          "comp_num_id": "GLOBcomp_63",
          "formula": "C4H9NO",
          "inchi_key": "FXHOOIRPVKKKFG-UHFFFAOYSA-N",
          "name": "N,N-dimethylethanamide",
          "org_num": "DOIcomp_5"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6"
        }
      ],
      "doi": "10.1016/j.fluid.2014.08.026",
      "journal": "Fluid Phase Equilib.",
      "lit_id": "2014-zha-li-3",
      "lit_num_id": "GLOBlit_1540",
      "match_score": 100,
      "n_blocks": 13,
      "n_compounds": 6,
      "n_datapoints": 742,
      "pages": "127-132",
      "properties": [
        {
          "component_linked": false,
          "name": "Mass density, kg/m3",
          "prop_id": "mass_density_kg_m3",
          "prop_num_id": "GLOBprop_1"
        },
        {
          "component_linked": true,
          "name": "Mean ionic activity coefficient",
          "prop_id": "mean_ionic_activity_coefficient",
          "prop_num_id": "GLOBprop_56"
        },
        {
          "component_linked": false,
          "name": "Relative permittivity at various frequencies",
          "prop_id": "relative_permittivity_at_various_frequencies",
          "prop_num_id": "GLOBprop_42"
        }
      ],
      "property_groups": [
        "ActivityFugacityOsmoticProp",
        "RefractionSurfaceTensionSoundSpeed",
        "VolumetricProp"
      ],
      "system_types": [
        "binary",
        "ternary"
      ],
      "title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "volume": "382",
      "year": 2014
    }
  ]
}
```

````

### Model-visible result

````markdown
# Raw tool result: `search_references`

Serialization: `json`

```json
{
  "n_results": 1,
  "query_params": {
    "author": null,
    "compound": null,
    "compound_resolved_ids": null,
    "doi_resolved": "10.1016/j.fluid.2014.08.026",
    "journal": null,
    "limit": 50,
    "literature": "GLOBlit_1540",
    "property": null,
    "property_resolved_ids": null,
    "title_keywords": null,
    "year": null,
    "year_range": null
  },
  "results": [
    {
      "authors": [
        "Zhao, X.[Xuehong]",
        "Li, S.[Shu'ni]",
        "Zhai, Q.[Quanguo]",
        "Jiang, Y.[Yucheng]",
        "Hu, M.[Mancheng]"
      ],
      "compact_md": "# RMS | 10.1016/j.fluid.2014.08.026 | GLOBlit_1540\n\n**lit_id:** 2014-zha-li-3\n**Title:** Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K\n**Authors:** Zhao; Li; Zhai; Jiang; Hu\n**Journal:** Fluid Phase Equilib. 2014 382:127-132\n**Source:** Original | Cited: 2020-09-30\n\n## Abstract\nThis article deals with the mean activity coefficients of LiCl in amide water mixtures with both epsilon-increasing co-solvent (urea water, N-methylformamide water), and epsilon-decreasing co-solvent (N,N-dimethylformamide water, N,N-dimethylacetamide water) systems at 298.15 K by potentiometric method. Meanwhile, thermodynamic properties including the osmotic coefficients, the excess Gibbs free energy, the standard solubility product, the primary LiCl hydration number and the standard free energy of transference from water to the mixtures were also calculated. The nonideal behavior of these systems has been discussed in terms of the Pitzer, the Modified Pitzer and the extended Debye-Huckel equations parameters.\n\n## Keywords\nLiCl; Amide; Potentiometric; Activity coefficients.\n\n## Data Inventory\n| Metric | Value |\n|--------|-------|\n| Compounds | 6 |\n| Blocks | 13 |\n| Datapoints | 742 |\n| Has P/M data | yes |\n| Has reaction | no |\n| T range | 298.15 K |\n| P range | 100.0-101.0 kPa |\n\n### Compounds\n| comp_id | Name | IK | Formula |\n|---|---|---|---|\n| GLOBcomp_94 | urea | XSQUKJJJFZCRTK-UHFFF | CH4N2O |\n| GLOBcomp_1 | water | XLYOFNOQVPJJNP-UHFFF | H2O |\n| GLOBcomp_177 | N-methylformamide | ATHHXGZTWNVVOU-UHFFF | C2H5NO |\n| GLOBcomp_18 | dimethylformamide | ZMXDDKWLCZADIW-UHFFF | C3H7NO |\n| GLOBcomp_63 | N,N-dimethylethanamide | FXHOOIRPVKKKFG-UHFFF | C4H9NO |\n| GLOBcomp_107 | lithium chloride | KWGKDLIKAYFUFQ-UHFFF | ClLi |\n\n### Properties\n- GLOBprop_1 | mass_density_kg_m3 | Mass density, kg/m3\n- GLOBprop_56 | mean_ionic_activity_coefficient | Mean ionic activity coefficient\n- GLOBprop_42 | relative_permittivity_at_various_frequencies | Relative permittivity at various frequencies\n\n### Property Groups\nActivityFugacityOsmoticProp; RefractionSurfaceTensionSoundSpeed; VolumetricProp\n\n### System Types\nbinary; ternary\n",
      "compound_list": [
        {
          "InChI": "InChI=1S/CH4N2O/c2-1(3)4/h(H4,2,3,4)",
          "SMILES": "N=C(N)O",
          "comp_num_id": "GLOBcomp_94",
          "formula": "CH4N2O",
          "inchi_key": "XSQUKJJJFZCRTK-UHFFFAOYSA-N",
          "name": "urea",
          "org_num": "DOIcomp_1"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_2"
        },
        {
          "InChI": "InChI=1S/C2H5NO/c1-3-2-4/h2H,1H3,(H,3,4)",
          "SMILES": "CN=CO",
          "comp_num_id": "GLOBcomp_177",
          "formula": "C2H5NO",
          "inchi_key": "ATHHXGZTWNVVOU-UHFFFAOYSA-N",
          "name": "N-methylformamide",
          "org_num": "DOIcomp_3"
        },
        {
          "InChI": "InChI=1S/C3H7NO/c1-4(2)3-5/h3H,1-2H3",
          "SMILES": "CN(C)C=O",
          "comp_num_id": "GLOBcomp_18",
          "formula": "C3H7NO",
          "inchi_key": "ZMXDDKWLCZADIW-UHFFFAOYSA-N",
          "name": "dimethylformamide",
          "org_num": "DOIcomp_4"
        },
        {
          "InChI": "InChI=1S/C4H9NO/c1-4(6)5(2)3/h1-3H3",
          "SMILES": "CC(=O)N(C)C",
          "comp_num_id": "GLOBcomp_63",
          "formula": "C4H9NO",
          "inchi_key": "FXHOOIRPVKKKFG-UHFFFAOYSA-N",
          "name": "N,N-dimethylethanamide",
          "org_num": "DOIcomp_5"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_6"
        }
      ],
      "doi": "10.1016/j.fluid.2014.08.026",
      "journal": "Fluid Phase Equilib.",
      "lit_id": "2014-zha-li-3",
      "lit_num_id": "GLOBlit_1540",
      "match_score": 100,
      "n_blocks": 13,
      "n_compounds": 6,
      "n_datapoints": 742,
      "pages": "127-132",
      "properties": [
        {
          "component_linked": false,
          "name": "Mass density, kg/m3",
          "prop_id": "mass_density_kg_m3",
          "prop_num_id": "GLOBprop_1"
        },
        {
          "component_linked": true,
          "name": "Mean ionic activity coefficient",
          "prop_id": "mean_ionic_activity_coefficient",
          "prop_num_id": "GLOBprop_56"
        },
        {
          "component_linked": false,
          "name": "Relative permittivity at various frequencies",
          "prop_id": "relative_permittivity_at_various_frequencies",
          "prop_num_id": "GLOBprop_42"
        }
      ],
      "property_groups": [
        "ActivityFugacityOsmoticProp",
        "RefractionSurfaceTensionSoundSpeed",
        "VolumetricProp"
      ],
      "system_types": [
        "binary",
        "ternary"
      ],
      "title": "Investigating thermodynamic properties of LiCl in amide - water mixtures with e-increasing and e-decreasing solvent at 298.15K",
      "volume": "382",
      "year": 2014
    }
  ]
}
```

````

### Integrity and timing

- Raw SHA-256: 72cf2243c4bcf5b4d8272bcafd0e0416b886ec9ce142bf0286276a113c51d7b7
- Raw characters: 6083
- Hardcoded-compacted characters: 6083
- Model-visible characters: 6083
- Agentic verdict: SKIP
- Tool elapsed: 0.010s
- Compactor elapsed: 0.000s
- Total elapsed: 0.010s

## Step 10: search_references

### Call arguments

```json
{
  "literature": [
    "GLOBlit_3969",
    "GLOBlit_4743"
  ],
  "purpose": "Get citations for the osmotic coefficient references.",
  "tasks": [
    "Get the authors, title, journal, and year for the osmotic coefficient papers"
  ]
}
```

### Raw tool result Markdown (exact native serialization)

````markdown
# Raw tool result: `search_references`

Serialization: `json`

```json
{
  "n_results": 1,
  "query_params": {
    "author": null,
    "compound": null,
    "compound_resolved_ids": null,
    "doi_resolved": "10.1016/j.jct.2013.08.018",
    "journal": null,
    "limit": 50,
    "literature": [
      "GLOBlit_3969",
      "GLOBlit_4743"
    ],
    "property": null,
    "property_resolved_ids": null,
    "title_keywords": null,
    "year": null,
    "year_range": null
  },
  "results": [
    {
      "authors": [
        "Held, C.[Christoph]",
        "Reschke, T.[Thomas]",
        "Muller, R.[Rainer]",
        "Kunz, W.[Werner]",
        "Sadowski, G."
      ],
      "compact_md": "# RMS | 10.1016/j.jct.2013.08.018 | GLOBlit_3969\n\n**lit_id:** 2014-hel-res-0\n**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT\n**Authors:** Held; Reschke; Muller; Kunz; Sadowski\n**Journal:** J. Chem. Thermodyn. 2014 68:1-12\n**Source:** Original | Cited: 2020-09-29\n\n## Abstract\nIn this work thermodynamic properties of electrolyte/amino acid/water solutions were measured and modeled. Osmotic coefficients at 298.15 K were measured by means of vapor-pressure osmometry. Amino-acid solubility at 298.15 K was determined gravimetrically. Considered aqueous systems contained one of the four amino acids: glycine, L-/DL-alanine, L-/DL-valine, and L-proline up to the respective amino-acid solubility limit and one of 13 salts composed of the ions Li+, Na+, K+, NH4 +, Cl , Br , I , NO3- , and SO4 2-  at salt molalities of 0.5, 1.0, and 3.0 mol  kg-1, respectively. The data show that the salt influence is more pronounced on osmotic coefficients than on amino-acid solubility. The electrolyte Perturbed-Chain Statistical Association Theory (ePC-SAFT) was applied to model thermodynamic properties in aqueous electrolyte/amino-acid solutions. In previous works, this model had been applied to binary salt/water and binary amino acid/water systems. Without fitting any additional parameters, osmotic coefficients and amino-acid solubility in the ternary electrolyte/amino acid/water systems could be predicted with overall deviations of 3.7% and 9.3%, respectively, compared to the experimental data.\n\n## Keywords\nOsmotic coefficients; Solubility; Electrolyte solutions; Equation of state; ePC-SAFT; Salt influence\n\n## Data Inventory\n| Metric | Value |\n|--------|-------|\n| Compounds | 18 |\n| Blocks | 81 |\n| Datapoints | 720 |\n| Has P/M data | yes |\n| Has reaction | no |\n| T range | 298.15 K |\n| P range | 101.0 kPa |\n\n### Compounds\n| comp_id | Name | IK | Formula |\n|---|---|---|---|\n| GLOBcomp_53 | 2-aminoacetic acid | DHMQDGOQFOQNFH-UHFFF | C2H5NO2 |\n| GLOBcomp_74 | (S)-2-aminopropanoic acid | QNAYBMKLOCPYGJ-REOHC | C3H7NO2 |\n| GLOBcomp_116 | L-valine | KZSNJWFQEVHDMF-BYPYZ | C5H11NO2 |\n| GLOBcomp_260 | L-proline | ONIBWKKTOPOVIA-BYPYZ | C5H9NO2 |\n| GLOBcomp_107 | lithium chloride | KWGKDLIKAYFUFQ-UHFFF | ClLi |\n| GLOBcomp_182 | lithium bromide | AMXOYNBUYSYVKV-UHFFF | BrLi |\n| GLOBcomp_557 | lithium iodide | HSZCZNFXUDYRKD-UHFFF | ILi |\n| GLOBcomp_26 | sodium chloride | FAPWRFPIFSIZLT-UHFFF | ClNa |\n| GLOBcomp_165 | sodium bromide | JHJLBTNAGRQEKS-UHFFF | BrNa |\n| GLOBcomp_336 | sodium iodide | FVAUCKIRQBBSSJ-UHFFF | INa |\n| GLOBcomp_198 | sodium nitrate | VWDWKYIASSYTQR-UHFFF | NNaO3 |\n| GLOBcomp_91 | sodium sulfate | PMZURENOXWZQFD-UHFFF | Na2O4S |\n| GLOBcomp_41 | potassium chloride | WCUXLLCKKVVCTQ-UHFFF | ClK |\n| GLOBcomp_222 | potassium bromide | IOLCXVTUBQKXJR-UHFFF | BrK |\n| GLOBcomp_393 | potassium iodide | NLKNQRATVPKPDG-UHFFF | IK |\n| GLOBcomp_233 | potassium nitrate | FGIUAXJPYTZDNR-UHFFF | KNO3 |\n| GLOBcomp_187 | ammonium sulfate | BFNBIHQBYMNNAN-UHFFF | H8N2O4S |\n| GLOBcomp_1 | water | XLYOFNOQVPJJNP-UHFFF | H2O |\n\n### Properties\n- GLOBprop_21 | molality_mol_kg | Molality, mol/kg\n- GLOBprop_38 | osmotic_coefficient | Osmotic coefficient\n\n### Property Groups\nActivityFugacityOsmoticProp; CompositionAtPhaseEquilibrium\n\n### System Types\nbinary; ternary\n",
      "compound_list": [
        {
          "InChI": "InChI=1S/C2H5NO2/c3-1-2(4)5/h1,3H2,(H,4,5)",
          "SMILES": "NCC(=O)O",
          "comp_num_id": "GLOBcomp_53",
          "formula": "C2H5NO2",
          "inchi_key": "DHMQDGOQFOQNFH-UHFFFAOYSA-N",
          "name": "2-aminoacetic acid",
          "org_num": "DOIcomp_1"
        },
        {
          "InChI": "InChI=1S/C3H7NO2/c1-2(4)3(5)6/h2H,4H2,1H3,(H,5,6)/t2-/m0/s1",
          "SMILES": "C[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_74",
          "formula": "C3H7NO2",
          "inchi_key": "QNAYBMKLOCPYGJ-REOHCLBHSA-N",
          "name": "(S)-2-aminopropanoic acid",
          "org_num": "DOIcomp_2"
        },
        {
          "InChI": "InChI=1S/C5H11NO2/c1-3(2)4(6)5(7)8/h3-4H,6H2,1-2H3,(H,7,8)/t4-/m0/s1",
          "SMILES": "CC(C)[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_116",
          "formula": "C5H11NO2",
          "inchi_key": "KZSNJWFQEVHDMF-BYPYZUCNSA-N",
          "name": "L-valine",
          "org_num": "DOIcomp_3"
        },
        {
          "InChI": "InChI=1S/C5H9NO2/c7-5(8)4-2-1-3-6-4/h4,6H,1-3H2,(H,7,8)/t4-/m0/s1",
          "SMILES": "O=C(O)[C@@H]1CCCN1",
          "comp_num_id": "GLOBcomp_260",
          "formula": "C5H9NO2",
          "inchi_key": "ONIBWKKTOPOVIA-BYPYZUCNSA-N",
          "name": "L-proline",
          "org_num": "DOIcomp_4"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5"
        },
        {
          "InChI": "InChI=1S/BrH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[Li+]",
          "comp_num_id": "GLOBcomp_182",
          "formula": "BrLi",
          "inchi_key": "AMXOYNBUYSYVKV-UHFFFAOYSA-M",
          "name": "lithium bromide",
          "org_num": "DOIcomp_6"
        },
        {
          "InChI": "InChI=1S/HI.Li/h1H;/q;+1/p-1",
          "SMILES": "[I-].[Li+]",
          "comp_num_id": "GLOBcomp_557",
          "formula": "ILi",
          "inchi_key": "HSZCZNFXUDYRKD-UHFFFAOYSA-M",
          "name": "lithium iodide",
          "org_num": "DOIcomp_7"
        },
        {
          "InChI": "InChI=1S/ClH.Na/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Na+]",
          "comp_num_id": "GLOBcomp_26",
          "formula": "ClNa",
          "inchi_key": "FAPWRFPIFSIZLT-UHFFFAOYSA-M",
          "name": "sodium chloride",
          "org_num": "DOIcomp_8"
        },
        {
          "InChI": "InChI=1S/BrH.Na/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[Na+]",
          "comp_num_id": "GLOBcomp_165",
          "formula": "BrNa",
          "inchi_key": "JHJLBTNAGRQEKS-UHFFFAOYSA-M",
          "name": "sodium bromide",
          "org_num": "DOIcomp_9"
        },
        {
          "InChI": "InChI=1S/HI.Na/h1H;/q;+1/p-1",
          "SMILES": "[I-].[Na+]",
          "comp_num_id": "GLOBcomp_336",
          "formula": "INa",
          "inchi_key": "FVAUCKIRQBBSSJ-UHFFFAOYSA-M",
          "name": "sodium iodide",
          "org_num": "DOIcomp_10"
        },
        {
          "InChI": "InChI=1S/NO3.Na/c2-1(3)4;/q-1;+1",
          "SMILES": "O=[N+]([O-])[O-].[Na+]",
          "comp_num_id": "GLOBcomp_198",
          "formula": "NNaO3",
          "inchi_key": "VWDWKYIASSYTQR-UHFFFAOYSA-N",
          "name": "sodium nitrate",
          "org_num": "DOIcomp_11"
        },
        {
          "InChI": "InChI=1S/2Na.H2O4S/c;;1-5(2,3)4/h;;(H2,1,2,3,4)/q2*+1;/p-2",
          "SMILES": "O=S(=O)([O-])[O-].[Na+].[Na+]",
          "comp_num_id": "GLOBcomp_91",
          "formula": "Na2O4S",
          "inchi_key": "PMZURENOXWZQFD-UHFFFAOYSA-L",
          "name": "sodium sulfate",
          "org_num": "DOIcomp_12"
        },
        {
          "InChI": "InChI=1S/ClH.K/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[K+]",
          "comp_num_id": "GLOBcomp_41",
          "formula": "ClK",
          "inchi_key": "WCUXLLCKKVVCTQ-UHFFFAOYSA-M",
          "name": "potassium chloride",
          "org_num": "DOIcomp_13"
        },
        {
          "InChI": "InChI=1S/BrH.K/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[K+]",
          "comp_num_id": "GLOBcomp_222",
          "formula": "BrK",
          "inchi_key": "IOLCXVTUBQKXJR-UHFFFAOYSA-M",
          "name": "potassium bromide",
          "org_num": "DOIcomp_14"
        },
        {
          "InChI": "InChI=1S/HI.K/h1H;/q;+1/p-1",
          "SMILES": "[I-].[K+]",
          "comp_num_id": "GLOBcomp_393",
          "formula": "IK",
          "inchi_key": "NLKNQRATVPKPDG-UHFFFAOYSA-M",
          "name": "potassium iodide",
          "org_num": "DOIcomp_15"
        },
        {
          "InChI": "InChI=1S/K.NO3/c;2-1(3)4/q+1;-1",
          "SMILES": "O=[N+]([O-])[O-].[K+]",
          "comp_num_id": "GLOBcomp_233",
          "formula": "KNO3",
          "inchi_key": "FGIUAXJPYTZDNR-UHFFFAOYSA-N",
          "name": "potassium nitrate",
          "org_num": "DOIcomp_16"
        },
        {
          "InChI": "InChI=1S/2H3N.H2O4S/c;;1-5(2,3)4/h2*1H3;(H2,1,2,3,4)",
          "SMILES": "N.N.O=S(=O)(O)O",
          "comp_num_id": "GLOBcomp_187",
          "formula": "H8N2O4S",
          "inchi_key": "BFNBIHQBYMNNAN-UHFFFAOYSA-N",
          "name": "ammonium sulfate",
          "org_num": "DOIcomp_17"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18"
        }
      ],
      "doi": "10.1016/j.jct.2013.08.018",
      "journal": "J. Chem. Thermodyn.",
      "lit_id": "2014-hel-res-0",
      "lit_num_id": "GLOBlit_3969",
      "match_score": 100,
      "n_blocks": 81,
      "n_compounds": 18,
      "n_datapoints": 720,
      "pages": "1-12",
      "properties": [
        {
          "component_linked": true,
          "name": "Molality, mol/kg",
          "prop_id": "molality_mol_kg",
          "prop_num_id": "GLOBprop_21"
        },
        {
          "component_linked": false,
          "name": "Osmotic coefficient",
          "prop_id": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38"
        }
      ],
      "property_groups": [
        "ActivityFugacityOsmoticProp",
        "CompositionAtPhaseEquilibrium"
      ],
      "system_types": [
        "binary",
        "ternary"
      ],
      "title": "Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT",
      "volume": "68",
      "year": 2014
    }
  ]
}
```

````

### Existing hardcoded compactor output (agentic input when enabled)

````markdown
# Raw tool result: `search_references`

Serialization: `json`

```json
{
  "n_results": 1,
  "query_params": {
    "author": null,
    "compound": null,
    "compound_resolved_ids": null,
    "doi_resolved": "10.1016/j.jct.2013.08.018",
    "journal": null,
    "limit": 50,
    "literature": [
      "GLOBlit_3969",
      "GLOBlit_4743"
    ],
    "property": null,
    "property_resolved_ids": null,
    "title_keywords": null,
    "year": null,
    "year_range": null
  },
  "results": [
    {
      "authors": [
        "Held, C.[Christoph]",
        "Reschke, T.[Thomas]",
        "Muller, R.[Rainer]",
        "Kunz, W.[Werner]",
        "Sadowski, G."
      ],
      "compact_md": "# RMS | 10.1016/j.jct.2013.08.018 | GLOBlit_3969\n\n**lit_id:** 2014-hel-res-0\n**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT\n**Authors:** Held; Reschke; Muller; Kunz; Sadowski\n**Journal:** J. Chem. Thermodyn. 2014 68:1-12\n**Source:** Original | Cited: 2020-09-29\n\n## Abstract\nIn this work thermodynamic properties of electrolyte/amino acid/water solutions were measured and modeled. Osmotic coefficients at 298.15 K were measured by means of vapor-pressure osmometry. Amino-acid solubility at 298.15 K was determined gravimetrically. Considered aqueous systems contained one of the four amino acids: glycine, L-/DL-alanine, L-/DL-valine, and L-proline up to the respective amino-acid solubility limit and one of 13 salts composed of the ions Li+, Na+, K+, NH4 +, Cl , Br , I , NO3- , and SO4 2-  at salt molalities of 0.5, 1.0, and 3.0 mol  kg-1, respectively. The data show that the salt influence is more pronounced on osmotic coefficients than on amino-acid solubility. The electrolyte Perturbed-Chain Statistical Association Theory (ePC-SAFT) was applied to model thermodynamic properties in aqueous electrolyte/amino-acid solutions. In previous works, this model had been applied to binary salt/water and binary amino acid/water systems. Without fitting any additional parameters, osmotic coefficients and amino-acid solubility in the ternary electrolyte/amino acid/water systems could be predicted with overall deviations of 3.7% and 9.3%, respectively, compared to the experimental data.\n\n## Keywords\nOsmotic coefficients; Solubility; Electrolyte solutions; Equation of state; ePC-SAFT; Salt influence\n\n## Data Inventory\n| Metric | Value |\n|--------|-------|\n| Compounds | 18 |\n| Blocks | 81 |\n| Datapoints | 720 |\n| Has P/M data | yes |\n| Has reaction | no |\n| T range | 298.15 K |\n| P range | 101.0 kPa |\n\n### Compounds\n| comp_id | Name | IK | Formula |\n|---|---|---|---|\n| GLOBcomp_53 | 2-aminoacetic acid | DHMQDGOQFOQNFH-UHFFF | C2H5NO2 |\n| GLOBcomp_74 | (S)-2-aminopropanoic acid | QNAYBMKLOCPYGJ-REOHC | C3H7NO2 |\n| GLOBcomp_116 | L-valine | KZSNJWFQEVHDMF-BYPYZ | C5H11NO2 |\n| GLOBcomp_260 | L-proline | ONIBWKKTOPOVIA-BYPYZ | C5H9NO2 |\n| GLOBcomp_107 | lithium chloride | KWGKDLIKAYFUFQ-UHFFF | ClLi |\n| GLOBcomp_182 | lithium bromide | AMXOYNBUYSYVKV-UHFFF | BrLi |\n| GLOBcomp_557 | lithium iodide | HSZCZNFXUDYRKD-UHFFF | ILi |\n| GLOBcomp_26 | sodium chloride | FAPWRFPIFSIZLT-UHFFF | ClNa |\n| GLOBcomp_165 | sodium bromide | JHJLBTNAGRQEKS-UHFFF | BrNa |\n| GLOBcomp_336 | sodium iodide | FVAUCKIRQBBSSJ-UHFFF | INa |\n| GLOBcomp_198 | sodium nitrate | VWDWKYIASSYTQR-UHFFF | NNaO3 |\n| GLOBcomp_91 | sodium sulfate | PMZURENOXWZQFD-UHFFF | Na2O4S |\n| GLOBcomp_41 | potassium chloride | WCUXLLCKKVVCTQ-UHFFF | ClK |\n| GLOBcomp_222 | potassium bromide | IOLCXVTUBQKXJR-UHFFF | BrK |\n| GLOBcomp_393 | potassium iodide | NLKNQRATVPKPDG-UHFFF | IK |\n| GLOBcomp_233 | potassium nitrate | FGIUAXJPYTZDNR-UHFFF | KNO3 |\n| GLOBcomp_187 | ammonium sulfate | BFNBIHQBYMNNAN-UHFFF | H8N2O4S |\n| GLOBcomp_1 | water | XLYOFNOQVPJJNP-UHFFF | H2O |\n\n### Properties\n- GLOBprop_21 | molality_mol_kg | Molality, mol/kg\n- GLOBprop_38 | osmotic_coefficient | Osmotic coefficient\n\n### Property Groups\nActivityFugacityOsmoticProp; CompositionAtPhaseEquilibrium\n\n### System Types\nbinary; ternary\n",
      "compound_list": [
        {
          "InChI": "InChI=1S/C2H5NO2/c3-1-2(4)5/h1,3H2,(H,4,5)",
          "SMILES": "NCC(=O)O",
          "comp_num_id": "GLOBcomp_53",
          "formula": "C2H5NO2",
          "inchi_key": "DHMQDGOQFOQNFH-UHFFFAOYSA-N",
          "name": "2-aminoacetic acid",
          "org_num": "DOIcomp_1"
        },
        {
          "InChI": "InChI=1S/C3H7NO2/c1-2(4)3(5)6/h2H,4H2,1H3,(H,5,6)/t2-/m0/s1",
          "SMILES": "C[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_74",
          "formula": "C3H7NO2",
          "inchi_key": "QNAYBMKLOCPYGJ-REOHCLBHSA-N",
          "name": "(S)-2-aminopropanoic acid",
          "org_num": "DOIcomp_2"
        },
        {
          "InChI": "InChI=1S/C5H11NO2/c1-3(2)4(6)5(7)8/h3-4H,6H2,1-2H3,(H,7,8)/t4-/m0/s1",
          "SMILES": "CC(C)[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_116",
          "formula": "C5H11NO2",
          "inchi_key": "KZSNJWFQEVHDMF-BYPYZUCNSA-N",
          "name": "L-valine",
          "org_num": "DOIcomp_3"
        },
        {
          "InChI": "InChI=1S/C5H9NO2/c7-5(8)4-2-1-3-6-4/h4,6H,1-3H2,(H,7,8)/t4-/m0/s1",
          "SMILES": "O=C(O)[C@@H]1CCCN1",
          "comp_num_id": "GLOBcomp_260",
          "formula": "C5H9NO2",
          "inchi_key": "ONIBWKKTOPOVIA-BYPYZUCNSA-N",
          "name": "L-proline",
          "org_num": "DOIcomp_4"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5"
        },
        {
          "InChI": "InChI=1S/BrH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[Li+]",
          "comp_num_id": "GLOBcomp_182",
          "formula": "BrLi",
          "inchi_key": "AMXOYNBUYSYVKV-UHFFFAOYSA-M",
          "name": "lithium bromide",
          "org_num": "DOIcomp_6"
        },
        {
          "InChI": "InChI=1S/HI.Li/h1H;/q;+1/p-1",
          "SMILES": "[I-].[Li+]",
          "comp_num_id": "GLOBcomp_557",
          "formula": "ILi",
          "inchi_key": "HSZCZNFXUDYRKD-UHFFFAOYSA-M",
          "name": "lithium iodide",
          "org_num": "DOIcomp_7"
        },
        {
          "InChI": "InChI=1S/ClH.Na/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Na+]",
          "comp_num_id": "GLOBcomp_26",
          "formula": "ClNa",
          "inchi_key": "FAPWRFPIFSIZLT-UHFFFAOYSA-M",
          "name": "sodium chloride",
          "org_num": "DOIcomp_8"
        },
        {
          "InChI": "InChI=1S/BrH.Na/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[Na+]",
          "comp_num_id": "GLOBcomp_165",
          "formula": "BrNa",
          "inchi_key": "JHJLBTNAGRQEKS-UHFFFAOYSA-M",
          "name": "sodium bromide",
          "org_num": "DOIcomp_9"
        },
        {
          "InChI": "InChI=1S/HI.Na/h1H;/q;+1/p-1",
          "SMILES": "[I-].[Na+]",
          "comp_num_id": "GLOBcomp_336",
          "formula": "INa",
          "inchi_key": "FVAUCKIRQBBSSJ-UHFFFAOYSA-M",
          "name": "sodium iodide",
          "org_num": "DOIcomp_10"
        },
        {
          "InChI": "InChI=1S/NO3.Na/c2-1(3)4;/q-1;+1",
          "SMILES": "O=[N+]([O-])[O-].[Na+]",
          "comp_num_id": "GLOBcomp_198",
          "formula": "NNaO3",
          "inchi_key": "VWDWKYIASSYTQR-UHFFFAOYSA-N",
          "name": "sodium nitrate",
          "org_num": "DOIcomp_11"
        },
        {
          "InChI": "InChI=1S/2Na.H2O4S/c;;1-5(2,3)4/h;;(H2,1,2,3,4)/q2*+1;/p-2",
          "SMILES": "O=S(=O)([O-])[O-].[Na+].[Na+]",
          "comp_num_id": "GLOBcomp_91",
          "formula": "Na2O4S",
          "inchi_key": "PMZURENOXWZQFD-UHFFFAOYSA-L",
          "name": "sodium sulfate",
          "org_num": "DOIcomp_12"
        },
        {
          "InChI": "InChI=1S/ClH.K/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[K+]",
          "comp_num_id": "GLOBcomp_41",
          "formula": "ClK",
          "inchi_key": "WCUXLLCKKVVCTQ-UHFFFAOYSA-M",
          "name": "potassium chloride",
          "org_num": "DOIcomp_13"
        },
        {
          "InChI": "InChI=1S/BrH.K/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[K+]",
          "comp_num_id": "GLOBcomp_222",
          "formula": "BrK",
          "inchi_key": "IOLCXVTUBQKXJR-UHFFFAOYSA-M",
          "name": "potassium bromide",
          "org_num": "DOIcomp_14"
        },
        {
          "InChI": "InChI=1S/HI.K/h1H;/q;+1/p-1",
          "SMILES": "[I-].[K+]",
          "comp_num_id": "GLOBcomp_393",
          "formula": "IK",
          "inchi_key": "NLKNQRATVPKPDG-UHFFFAOYSA-M",
          "name": "potassium iodide",
          "org_num": "DOIcomp_15"
        },
        {
          "InChI": "InChI=1S/K.NO3/c;2-1(3)4/q+1;-1",
          "SMILES": "O=[N+]([O-])[O-].[K+]",
          "comp_num_id": "GLOBcomp_233",
          "formula": "KNO3",
          "inchi_key": "FGIUAXJPYTZDNR-UHFFFAOYSA-N",
          "name": "potassium nitrate",
          "org_num": "DOIcomp_16"
        },
        {
          "InChI": "InChI=1S/2H3N.H2O4S/c;;1-5(2,3)4/h2*1H3;(H2,1,2,3,4)",
          "SMILES": "N.N.O=S(=O)(O)O",
          "comp_num_id": "GLOBcomp_187",
          "formula": "H8N2O4S",
          "inchi_key": "BFNBIHQBYMNNAN-UHFFFAOYSA-N",
          "name": "ammonium sulfate",
          "org_num": "DOIcomp_17"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18"
        }
      ],
      "doi": "10.1016/j.jct.2013.08.018",
      "journal": "J. Chem. Thermodyn.",
      "lit_id": "2014-hel-res-0",
      "lit_num_id": "GLOBlit_3969",
      "match_score": 100,
      "n_blocks": 81,
      "n_compounds": 18,
      "n_datapoints": 720,
      "pages": "1-12",
      "properties": [
        {
          "component_linked": true,
          "name": "Molality, mol/kg",
          "prop_id": "molality_mol_kg",
          "prop_num_id": "GLOBprop_21"
        },
        {
          "component_linked": false,
          "name": "Osmotic coefficient",
          "prop_id": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38"
        }
      ],
      "property_groups": [
        "ActivityFugacityOsmoticProp",
        "CompositionAtPhaseEquilibrium"
      ],
      "system_types": [
        "binary",
        "ternary"
      ],
      "title": "Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT",
      "volume": "68",
      "year": 2014
    }
  ]
}
```

````

### Model-visible result

````markdown
# Raw tool result: `search_references`

Serialization: `json`

```json
{
  "n_results": 1,
  "query_params": {
    "author": null,
    "compound": null,
    "compound_resolved_ids": null,
    "doi_resolved": "10.1016/j.jct.2013.08.018",
    "journal": null,
    "limit": 50,
    "literature": [
      "GLOBlit_3969",
      "GLOBlit_4743"
    ],
    "property": null,
    "property_resolved_ids": null,
    "title_keywords": null,
    "year": null,
    "year_range": null
  },
  "results": [
    {
      "authors": [
        "Held, C.[Christoph]",
        "Reschke, T.[Thomas]",
        "Muller, R.[Rainer]",
        "Kunz, W.[Werner]",
        "Sadowski, G."
      ],
      "compact_md": "# RMS | 10.1016/j.jct.2013.08.018 | GLOBlit_3969\n\n**lit_id:** 2014-hel-res-0\n**Title:** Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT\n**Authors:** Held; Reschke; Muller; Kunz; Sadowski\n**Journal:** J. Chem. Thermodyn. 2014 68:1-12\n**Source:** Original | Cited: 2020-09-29\n\n## Abstract\nIn this work thermodynamic properties of electrolyte/amino acid/water solutions were measured and modeled. Osmotic coefficients at 298.15 K were measured by means of vapor-pressure osmometry. Amino-acid solubility at 298.15 K was determined gravimetrically. Considered aqueous systems contained one of the four amino acids: glycine, L-/DL-alanine, L-/DL-valine, and L-proline up to the respective amino-acid solubility limit and one of 13 salts composed of the ions Li+, Na+, K+, NH4 +, Cl , Br , I , NO3- , and SO4 2-  at salt molalities of 0.5, 1.0, and 3.0 mol  kg-1, respectively. The data show that the salt influence is more pronounced on osmotic coefficients than on amino-acid solubility. The electrolyte Perturbed-Chain Statistical Association Theory (ePC-SAFT) was applied to model thermodynamic properties in aqueous electrolyte/amino-acid solutions. In previous works, this model had been applied to binary salt/water and binary amino acid/water systems. Without fitting any additional parameters, osmotic coefficients and amino-acid solubility in the ternary electrolyte/amino acid/water systems could be predicted with overall deviations of 3.7% and 9.3%, respectively, compared to the experimental data.\n\n## Keywords\nOsmotic coefficients; Solubility; Electrolyte solutions; Equation of state; ePC-SAFT; Salt influence\n\n## Data Inventory\n| Metric | Value |\n|--------|-------|\n| Compounds | 18 |\n| Blocks | 81 |\n| Datapoints | 720 |\n| Has P/M data | yes |\n| Has reaction | no |\n| T range | 298.15 K |\n| P range | 101.0 kPa |\n\n### Compounds\n| comp_id | Name | IK | Formula |\n|---|---|---|---|\n| GLOBcomp_53 | 2-aminoacetic acid | DHMQDGOQFOQNFH-UHFFF | C2H5NO2 |\n| GLOBcomp_74 | (S)-2-aminopropanoic acid | QNAYBMKLOCPYGJ-REOHC | C3H7NO2 |\n| GLOBcomp_116 | L-valine | KZSNJWFQEVHDMF-BYPYZ | C5H11NO2 |\n| GLOBcomp_260 | L-proline | ONIBWKKTOPOVIA-BYPYZ | C5H9NO2 |\n| GLOBcomp_107 | lithium chloride | KWGKDLIKAYFUFQ-UHFFF | ClLi |\n| GLOBcomp_182 | lithium bromide | AMXOYNBUYSYVKV-UHFFF | BrLi |\n| GLOBcomp_557 | lithium iodide | HSZCZNFXUDYRKD-UHFFF | ILi |\n| GLOBcomp_26 | sodium chloride | FAPWRFPIFSIZLT-UHFFF | ClNa |\n| GLOBcomp_165 | sodium bromide | JHJLBTNAGRQEKS-UHFFF | BrNa |\n| GLOBcomp_336 | sodium iodide | FVAUCKIRQBBSSJ-UHFFF | INa |\n| GLOBcomp_198 | sodium nitrate | VWDWKYIASSYTQR-UHFFF | NNaO3 |\n| GLOBcomp_91 | sodium sulfate | PMZURENOXWZQFD-UHFFF | Na2O4S |\n| GLOBcomp_41 | potassium chloride | WCUXLLCKKVVCTQ-UHFFF | ClK |\n| GLOBcomp_222 | potassium bromide | IOLCXVTUBQKXJR-UHFFF | BrK |\n| GLOBcomp_393 | potassium iodide | NLKNQRATVPKPDG-UHFFF | IK |\n| GLOBcomp_233 | potassium nitrate | FGIUAXJPYTZDNR-UHFFF | KNO3 |\n| GLOBcomp_187 | ammonium sulfate | BFNBIHQBYMNNAN-UHFFF | H8N2O4S |\n| GLOBcomp_1 | water | XLYOFNOQVPJJNP-UHFFF | H2O |\n\n### Properties\n- GLOBprop_21 | molality_mol_kg | Molality, mol/kg\n- GLOBprop_38 | osmotic_coefficient | Osmotic coefficient\n\n### Property Groups\nActivityFugacityOsmoticProp; CompositionAtPhaseEquilibrium\n\n### System Types\nbinary; ternary\n",
      "compound_list": [
        {
          "InChI": "InChI=1S/C2H5NO2/c3-1-2(4)5/h1,3H2,(H,4,5)",
          "SMILES": "NCC(=O)O",
          "comp_num_id": "GLOBcomp_53",
          "formula": "C2H5NO2",
          "inchi_key": "DHMQDGOQFOQNFH-UHFFFAOYSA-N",
          "name": "2-aminoacetic acid",
          "org_num": "DOIcomp_1"
        },
        {
          "InChI": "InChI=1S/C3H7NO2/c1-2(4)3(5)6/h2H,4H2,1H3,(H,5,6)/t2-/m0/s1",
          "SMILES": "C[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_74",
          "formula": "C3H7NO2",
          "inchi_key": "QNAYBMKLOCPYGJ-REOHCLBHSA-N",
          "name": "(S)-2-aminopropanoic acid",
          "org_num": "DOIcomp_2"
        },
        {
          "InChI": "InChI=1S/C5H11NO2/c1-3(2)4(6)5(7)8/h3-4H,6H2,1-2H3,(H,7,8)/t4-/m0/s1",
          "SMILES": "CC(C)[C@H](N)C(=O)O",
          "comp_num_id": "GLOBcomp_116",
          "formula": "C5H11NO2",
          "inchi_key": "KZSNJWFQEVHDMF-BYPYZUCNSA-N",
          "name": "L-valine",
          "org_num": "DOIcomp_3"
        },
        {
          "InChI": "InChI=1S/C5H9NO2/c7-5(8)4-2-1-3-6-4/h4,6H,1-3H2,(H,7,8)/t4-/m0/s1",
          "SMILES": "O=C(O)[C@@H]1CCCN1",
          "comp_num_id": "GLOBcomp_260",
          "formula": "C5H9NO2",
          "inchi_key": "ONIBWKKTOPOVIA-BYPYZUCNSA-N",
          "name": "L-proline",
          "org_num": "DOIcomp_4"
        },
        {
          "InChI": "InChI=1S/ClH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Li+]",
          "comp_num_id": "GLOBcomp_107",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "name": "lithium chloride",
          "org_num": "DOIcomp_5"
        },
        {
          "InChI": "InChI=1S/BrH.Li/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[Li+]",
          "comp_num_id": "GLOBcomp_182",
          "formula": "BrLi",
          "inchi_key": "AMXOYNBUYSYVKV-UHFFFAOYSA-M",
          "name": "lithium bromide",
          "org_num": "DOIcomp_6"
        },
        {
          "InChI": "InChI=1S/HI.Li/h1H;/q;+1/p-1",
          "SMILES": "[I-].[Li+]",
          "comp_num_id": "GLOBcomp_557",
          "formula": "ILi",
          "inchi_key": "HSZCZNFXUDYRKD-UHFFFAOYSA-M",
          "name": "lithium iodide",
          "org_num": "DOIcomp_7"
        },
        {
          "InChI": "InChI=1S/ClH.Na/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[Na+]",
          "comp_num_id": "GLOBcomp_26",
          "formula": "ClNa",
          "inchi_key": "FAPWRFPIFSIZLT-UHFFFAOYSA-M",
          "name": "sodium chloride",
          "org_num": "DOIcomp_8"
        },
        {
          "InChI": "InChI=1S/BrH.Na/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[Na+]",
          "comp_num_id": "GLOBcomp_165",
          "formula": "BrNa",
          "inchi_key": "JHJLBTNAGRQEKS-UHFFFAOYSA-M",
          "name": "sodium bromide",
          "org_num": "DOIcomp_9"
        },
        {
          "InChI": "InChI=1S/HI.Na/h1H;/q;+1/p-1",
          "SMILES": "[I-].[Na+]",
          "comp_num_id": "GLOBcomp_336",
          "formula": "INa",
          "inchi_key": "FVAUCKIRQBBSSJ-UHFFFAOYSA-M",
          "name": "sodium iodide",
          "org_num": "DOIcomp_10"
        },
        {
          "InChI": "InChI=1S/NO3.Na/c2-1(3)4;/q-1;+1",
          "SMILES": "O=[N+]([O-])[O-].[Na+]",
          "comp_num_id": "GLOBcomp_198",
          "formula": "NNaO3",
          "inchi_key": "VWDWKYIASSYTQR-UHFFFAOYSA-N",
          "name": "sodium nitrate",
          "org_num": "DOIcomp_11"
        },
        {
          "InChI": "InChI=1S/2Na.H2O4S/c;;1-5(2,3)4/h;;(H2,1,2,3,4)/q2*+1;/p-2",
          "SMILES": "O=S(=O)([O-])[O-].[Na+].[Na+]",
          "comp_num_id": "GLOBcomp_91",
          "formula": "Na2O4S",
          "inchi_key": "PMZURENOXWZQFD-UHFFFAOYSA-L",
          "name": "sodium sulfate",
          "org_num": "DOIcomp_12"
        },
        {
          "InChI": "InChI=1S/ClH.K/h1H;/q;+1/p-1",
          "SMILES": "[Cl-].[K+]",
          "comp_num_id": "GLOBcomp_41",
          "formula": "ClK",
          "inchi_key": "WCUXLLCKKVVCTQ-UHFFFAOYSA-M",
          "name": "potassium chloride",
          "org_num": "DOIcomp_13"
        },
        {
          "InChI": "InChI=1S/BrH.K/h1H;/q;+1/p-1",
          "SMILES": "[Br-].[K+]",
          "comp_num_id": "GLOBcomp_222",
          "formula": "BrK",
          "inchi_key": "IOLCXVTUBQKXJR-UHFFFAOYSA-M",
          "name": "potassium bromide",
          "org_num": "DOIcomp_14"
        },
        {
          "InChI": "InChI=1S/HI.K/h1H;/q;+1/p-1",
          "SMILES": "[I-].[K+]",
          "comp_num_id": "GLOBcomp_393",
          "formula": "IK",
          "inchi_key": "NLKNQRATVPKPDG-UHFFFAOYSA-M",
          "name": "potassium iodide",
          "org_num": "DOIcomp_15"
        },
        {
          "InChI": "InChI=1S/K.NO3/c;2-1(3)4/q+1;-1",
          "SMILES": "O=[N+]([O-])[O-].[K+]",
          "comp_num_id": "GLOBcomp_233",
          "formula": "KNO3",
          "inchi_key": "FGIUAXJPYTZDNR-UHFFFAOYSA-N",
          "name": "potassium nitrate",
          "org_num": "DOIcomp_16"
        },
        {
          "InChI": "InChI=1S/2H3N.H2O4S/c;;1-5(2,3)4/h2*1H3;(H2,1,2,3,4)",
          "SMILES": "N.N.O=S(=O)(O)O",
          "comp_num_id": "GLOBcomp_187",
          "formula": "H8N2O4S",
          "inchi_key": "BFNBIHQBYMNNAN-UHFFFAOYSA-N",
          "name": "ammonium sulfate",
          "org_num": "DOIcomp_17"
        },
        {
          "InChI": "InChI=1S/H2O/h1H2",
          "SMILES": "O",
          "comp_num_id": "GLOBcomp_1",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "name": "water",
          "org_num": "DOIcomp_18"
        }
      ],
      "doi": "10.1016/j.jct.2013.08.018",
      "journal": "J. Chem. Thermodyn.",
      "lit_id": "2014-hel-res-0",
      "lit_num_id": "GLOBlit_3969",
      "match_score": 100,
      "n_blocks": 81,
      "n_compounds": 18,
      "n_datapoints": 720,
      "pages": "1-12",
      "properties": [
        {
          "component_linked": true,
          "name": "Molality, mol/kg",
          "prop_id": "molality_mol_kg",
          "prop_num_id": "GLOBprop_21"
        },
        {
          "component_linked": false,
          "name": "Osmotic coefficient",
          "prop_id": "osmotic_coefficient",
          "prop_num_id": "GLOBprop_38"
        }
      ],
      "property_groups": [
        "ActivityFugacityOsmoticProp",
        "CompositionAtPhaseEquilibrium"
      ],
      "system_types": [
        "binary",
        "ternary"
      ],
      "title": "Measuring and modeling aqueous electrolyte/amino-acid solutions with ePC-SAFT",
      "volume": "68",
      "year": 2014
    }
  ]
}
```

````

### Integrity and timing

- Raw SHA-256: a721662b603ac19491a65b9a2db1f45b31caa128168849af35a015b7b4cb2165
- Raw characters: 10753
- Hardcoded-compacted characters: 10753
- Model-visible characters: 10753
- Agentic verdict: SKIP
- Tool elapsed: 0.006s
- Compactor elapsed: 0.000s
- Total elapsed: 0.007s

# Q1.3 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Propan-2-ol (Isopropanol) — Compound Registry Result

| Field | Value |
|-------|-------|
| **comp_num_id** | **6** |
| **comp_id** | propan-2-ol |
| **common_name** | propan-2-ol |
| **formula** | C₃H₈O |
| **InChIKey** | KFZMGEQAYNKOFK-UHFFFAOYSA-N |

The remaining 9 rows were other compounds (2-methylpropan-2-ol, 1-methoxy-2-propanol, etc.) that matched the LIKE patterns but are not propan-2-ol itself; they are omitted as irrelevant.

## 2. execute_sql

## Water Compound Registry Results

| comp_num_id | comp_id | common_name | formula | inchi_key |
|---|---|---|---|---|
| **1** | water | water | H2O | **XLYOFNOQVPJJNP-UHFFFAOYSA-N** |
| 241 | water-d2 | water-d2 | D2O | XLYOFNOQVPJJNP-ZSJDYOACSA-N |

**Task answers:**
1. **comp_num_id for water:** `1`
2. **InChIKey for water:** `XLYOFNOQVPJJNP-UHFFFAOYSA-N`

## 3. execute_sql

## Compacted SQL Result

### Query Purpose
Find blocks with density data for binary propan-2-ol + water mixtures.

### Result
**Zero rows returned.** The query found no matching blocks.

### Details
- **Filters applied:** binary system, 2 components, property name containing "ensity", compound IDs `comp_num_id = '6'` (propan-2-ol) AND `comp_num_id = '1'` (water).
- **Elapsed time:** 14.86 s
- **Not truncated** — the result is genuinely empty.

### Implications for All Three Tasks
1. **DOIs and block numbers:** None found.
2. **Property name and value ranges:** No density values available under these filter conditions.
3. **Phase (liquid):** No phase information returned.

### Possible Reasons for Empty Result
- The assumed `comp_num_id` values ('6' for propan-2-ol, '1' for water) may be incorrect. The answering agent should verify the actual `comp_num_id` for propan-2-ol and water in `idx.compound_registry` (e.g., search by `common_name` or `inchi_key`).
- The density property name may not match the `LIKE '%ensity%'` pattern used (though this is unlikely).

## 4. execute_sql

## Compacted Result

**Task 1 – comp_num_id for propan-2-ol:** All 10 returned rows use **`comp_num_id = "6"`**.

**Task 2 – Naming convention:** The compound appears as **`propan-2-ol`** (lowercase, hyphenated IUPAC style). No variant spellings observed in this sample.

| doi | block_number (sample) | comp_num_id | comp_name |
|---|---|---|---|
| 10.1007/s10765-005-8101-x | 1, 2, 11–18 | 6 | propan-2-ol |

*10 rows returned (limit 10); not truncated. All from a single DOI, so other DOIs may also contain this compound with the same comp_num_id.*

## 5. execute_sql

## Density-Related Properties in the Registry

| prop_num_id | prop_id | prop_name | prop_group | n_blocks |
|---|---|---|---|---|
| **1** | mass_density_kg_m3 | Mass density, kg/m3 | VolumetricProp | 23,070 |
| 54 | critical_density_kg_m3 | Critical density, kg/m3 | Criticals | 107 |
| 67 | amount_density_mol_m3 | Amount density, mol/m3 | VolumetricProp | 62 |

**Key takeaway:** The relevant property for the benchmark question is **prop_num_id = "1"** ("Mass density, kg/m3"), which is by far the most common density property (23,070 blocks).

## 6. execute_sql

## Compacted SQL Result

### Query Purpose
Find blocks with mass density data for propan-2-ol + water binary mixtures.

### Result: **Zero rows returned**

The query returned **no results**. No blocks were found matching the criteria:
- 2-component system
- Property `prop_num_id = '1'` (mass density)
- Compounds with `comp_num_id = '6'` (propan-2-ol) and `comp_num_id = '1'` (water)

### Implications for Tasks
1. **DOIs and block numbers**: None found with this filter combination.
2. **Temperature/composition ranges near 25 °C and x = 0.5**: No data to check.
3. **Density value ranges**: No data available.

### Possible Issues
- The assumed `comp_num_id` values (`'6'` for propan-2-ol, `'1'` for water) or `prop_num_id = '1'` for mass density may be incorrect. A lookup in `idx.compound_registry` and `idx.prop_registry` would be needed to verify the correct numeric IDs for these compounds and the density property.

## 7. execute_sql

## Compacted Result

### Task: List DOIs and block numbers containing both propan-2-ol and water

**The query returned zero rows.**

No blocks were found containing both `comp_num_id = '6'` (propan-2-ol) and `comp_num_id = '1'` (water). The assumed numeric IDs for these compounds may be incorrect, or no matching data exists under those IDs. A follow-up query against `idx.compound_registry` to verify the correct `comp_num_id` values for propan-2-ol (2-propanol / isopropanol) and water is recommended.

## 8. execute_sql

## Compound Registry Entries for Propan-2-ol and Water

| comp_num_id | comp_id | common_name | formula | inchi_key | n_papers |
|---|---|---|---|---|---|
| 6 | propan-2-ol | propan-2-ol | C3H8O | KFZMGEQAYNKOFK-UHFFFAOYSA-N | 996 |
| 1 | water | water | H2O | XLYOFNOQVPJJNP-UHFFFAOYSA-N | 4690 |

**Task 1 — comp_num_ids:** propan-2-ol → **6**, water → **1**.

**Task 2 — Duplicates:** No duplicate entries. Each compound has exactly one comp_num_id (2 rows total).

## 9. execute_sql

## Compacted Result

**Query:** Blocks containing propan-2-ol filtered by `comp_num_id = '6'`

**Result: 0 rows returned.** No blocks were found with `comp_num_id = '6'`.

This means either:
1. Propan-2-ol does not have `comp_num_id = '6'` in this database, or
2. A different identifier/filter is needed to locate propan-2-ol (e.g., searching by `comp_name` or `inchi_key`).

**Neither task could be completed:**
- **Task 1 (List DOIs/blocks containing propan-2-ol):** No results to list.
- **Task 2 (Check if those blocks also contain water):** No blocks to check.

A follow-up query searching by name (e.g., `WHERE comp_name LIKE '%propan-2-ol%'` or `'%2-propanol%'` or `'%isopropanol%'`) or by InChIKey would be needed to locate the correct compound identifier.

## 10. execute_sql

## Result: comp_num_id for propan-2-ol

The exact compound **propan-2-ol** in `block_compounds` is:

| comp_num_id | comp_name | comp_id | inchi_key | occurrences |
|---|---|---|---|---|
| **6** | propan-2-ol | propan-2-ol | KFZMGEQAYNKOFK-UHFFFAOYSA-N | 2571 |

**Note:** The query returned 10 rows total, but the other 9 are different compounds that merely contain "propan-2-ol" as a substring (e.g., 2-methylpropan-2-ol `comp_num_id=44`, piperazine derivatives, thiadiazolyl derivatives, fluconazole, etc.). These are not relevant and were omitted.

## 11. execute_sql

## Water in `block_compounds`

| comp_num_id | comp_name | comp_id | occurrences |
|-------------|-----------|---------|-------------|
| **1**       | water     | water   | 26,068      |

**Result:** Water uses `comp_num_id = '1'` in `block_compounds`. This is the only entry (1 row returned, no truncation).

## 12. execute_sql

## Blocks containing both propan-2-ol and water

20 rows returned (not truncated).

| DOI | Block Number |
|-----|-------------|
| 10.1016/j.fluid.2004.11.010 | 10 |
| 10.1016/j.fluid.2004.11.010 | 12 |
| 10.1016/j.fluid.2005.08.023 | 3 |
| 10.1016/j.fluid.2006.02.023 | 40 |
| 10.1016/j.fluid.2006.02.023 | 41 |
| 10.1016/j.fluid.2006.02.023 | 42 |
| 10.1016/j.fluid.2006.03.021 | 1 |
| 10.1016/j.fluid.2006.03.021 | 2 |
| 10.1016/j.fluid.2006.03.021 | 3 |
| 10.1016/j.fluid.2007.04.016 | 1 |
| 10.1016/j.fluid.2007.04.016 | 2 |
| 10.1016/j.fluid.2007.04.016 | 3 |
| 10.1016/j.fluid.2007.04.016 | 4 |
| 10.1016/j.fluid.2007.04.016 | 5 |
| 10.1016/j.fluid.2007.04.016 | 6 |
| 10.1016/j.fluid.2007.04.016 | 7 |
| 10.1016/j.fluid.2007.04.016 | 8 |
| 10.1016/j.fluid.2007.04.016 | 9 |
| 10.1016/j.fluid.2007.04.016 | 10 |
| 10.1016/j.fluid.2007.04.016 | 11 |

**Note:** The query was limited to 20 rows; additional matching blocks may exist. Further filtering is needed to identify blocks that specifically report **density** at **25 °C**, **atmospheric pressure**, and **equimolar (x = 0.5)** composition.

## 13. execute_sql

## Compacted Result: Mass Density Data for Propan-2-ol + Water Binary Mixtures

**Query returned 36 rows (not truncated).**

All entries have `prop_name = "Mass density, kg/m3"`.

### Task 1: DOIs and Block Numbers

| DOI | Block(s) | Phase |
|-----|----------|-------|
| 10.1016/j.fluid.2006.02.023 | 42 | liquid |
| 10.1016/j.fluid.2013.08.007 | 4 | liquid |
| 10.1016/j.fluid.2014.12.040 | 11 | liquid |
| 10.1016/j.jct.2004.07.019 | 4 | liquid |
| 10.1016/j.jct.2011.10.024 | 22, 23 | liquid |
| 10.1016/j.jct.2019.105880 | 4, 10 | liquid |
| 10.1021/acs.jced.6b00019 | 13 | liquid |
| 10.1021/acs.jced.8b00160 | 3, 7, 15 | liquid |
| 10.1021/acs.jced.8b00723 | 8, 14 | liquid |
| 10.1021/je049738c | 28 | liquid |
| 10.1021/je060442b | 10, 11 | liquid_mixture_1, liquid_mixture_2 |
| 10.1021/je201010s | 8, 14 | liquid |
| 10.1021/je300754n | 13 | liquid |
| 10.1021/je300980k | 11 | liquid |
| 10.1021/je400576e | 16, 22 | liquid |
| 10.1021/je700700f | 17, 23 | liquid |
| 10.1021/je8001305 | 1 | liquid |
| 10.1021/je800158z | 4, 5 | liquid |
| 10.1021/je800637t | 9 | liquid |
| 10.1021/je900214y | 1, 2, 3, 4, 5 | liquid |
| 10.1021/je900966r | 6, 10 | liquid |

### Task 2: Density Value Ranges and Phases

| DOI | Block | min_value | max_value | phase_id |
|-----|-------|-----------|-----------|----------|
| 10.1016/j.fluid.2006.02.023 | 42 | 899.3 | 1051.8 | liquid |
| 10.1016/j.fluid.2013.08.007 | 4 | 674.03 | 976.41 | liquid |
| 10.1016/j.fluid.2014.12.040 | 11 | 798.38 | 1025.33 | liquid |
| 10.1016/j.jct.2004.07.019 | 4 | −19.9725 | −1.1132 | liquid |
| 10.1016/j.jct.2011.10.024 | 22 | 1039.94 | 1210.05 | liquid |
| 10.1016/j.jct.2011.10.024 | 23 | 1195.9 | 1234.6 | liquid |
| 10.1016/j.jct.2019.105880 | 4 | 945.121 | 1052.635 | liquid |
| 10.1016/j.jct.2019.105880 | 10 | 945.121 | 983.401 | liquid |
| 10.1021/acs.jced.6b00019 | 13 | 936.3 | 969.9 | liquid |
| 10.1021/acs.jced.8b00160 | 3 | 862.4 | 1287.3 | liquid |
| 10.1021/acs.jced.8b00160 | 7 | 862.4 | 1241.7 | liquid |
| 10.1021/acs.jced.8b00160 | 15 | 862.4 | 979.9 | liquid |
| 10.1021/acs.jced.8b00723 | 8 | 987.6 | 993.1 | liquid |
| 10.1021/acs.jced.8b00723 | 14 | 987.6 | 993.1 | liquid |
| 10.1021/je049738c | 28 | 987.73 | 996.38 | liquid |
| 10.1021/je060442b | 10 | 0.81 | 0.85 | liquid_mixture_1 |
| 10.1021/je060442b | 11 | 0.89 | 0.99 | liquid_mixture_2 |
| 10.1021/je201010s | 8 | 780.82 | 997.02 | liquid |
| 10.1021/je201010s | 14 | 807.7 | 1176.75 | liquid |
| 10.1021/je300754n | 13 | 770.1 | 1948.9 | liquid |
| 10.1021/je300980k | 11 | 883.0 | 984.0 | liquid |
| 10.1021/je400576e | 16 | 910.0 | 1137.0 | liquid |
| 10.1021/je400576e | 22 | 932.0 | 1215.0 | liquid |
| 10.1021/je700700f | 17 | 780.7 | 997.2 | liquid |
| 10.1021/je700700f | 23 | 812.4 | 1214.7 | liquid |
| 10.1021/je8001305 | 1 | 756.9 | 900.79 | liquid |
| 10.1021/je800158z | 4 | 758.68 | 998.2 | liquid |
| 10.1021/je800158z | 5 | 769.23 | 917.47 | liquid |
| 10.1021/je800637t | 9 | 768.05 | 1274.23 | liquid |
| 10.1021/je900214y | 1 | 760.95 | 813.35 | liquid |
| 10.1021/je900214y | 2 | 718.81 | 768.09 | liquid |
| 10.1021/je900214y | 3 | 653.52 | 719.6 | liquid |
| 10.1021/je900214y | 4 | 618.74 | 693.12 | liquid |
| 10.1021/je900214y | 5 | 540.02 | 630.79 | liquid |
| 10.1021/je900966r | 6 | 986.979 | 996.544 | liquid |
| 10.1021/je900966r | 10 | 986.979 | 1020.946 | liquid |

### Notes
- **Phase:** Nearly all blocks report phase `"liquid"`. Two blocks (DOI `10.1021/je060442b`, blocks 10 & 11) use `"liquid_mixture_1"` / `"liquid_mixture_2"` and report density in g/cm³ scale (0.81–0.99) rather than kg/m³.
- **Anomalous values:** Block 4 of `10.1016/j.jct.2004.07.019` has negative values (−19.97 to −1.11), likely representing an excess density or deviation quantity rather than absolute density.
- **Typical liquid density range** across most blocks: ~540–1290 kg/m³ (spanning pure propan-2-ol ~786 kg/m³ to water ~997 kg/m³ at 25 °C, with some blocks including other temperatures/pressures or additional solutes).
- This query does **not** filter for 25 °C, atmospheric pressure, or equimolar composition — further filtering of the underlying data points within these blocks is needed to answer the benchmark question precisely.

## 14. execute_sql

## Compacted Result for DOI 10.1021/je201010s

### Relevant block: Block 8 — Binary propan-2-ol + water, Mass density

- **Property:** Mass density, kg/m³
- **Method:** Vibrating tube method
- **System:** Binary (propan-2-ol + water), liquid phase
- **Constraints:** T = 298.15 K, P = 101.0 kPa

**Important note:** The composition variable is **mass fraction of propan-2-ol** (component org_num "1"), **not mole fraction**. There is no data point at x(mole fraction) = 0.5. The closest mass-fraction data points to the question's equimolar target are:

| Point ID | w(propan-2-ol) | Density (kg/m³) | U₉₅ (kg/m³) |
|----------|---------------|-----------------|-------------|
| 5 | 0.4795 | 906.69 | 1.01 |
| 6 | 0.5009 | 901.31 | 1.01 |
| 7 | 0.618 | 874.45 | 1.01 |

**Equimolar conversion context:** For propan-2-ol (M = 60.10 g/mol) + water (M = 18.015 g/mol), a 1:1 mole ratio corresponds to a propan-2-ol mass fraction of 60.10/(60.10+18.015) ≈ **0.7694**. The nearest data points to that mass fraction are:

| Point ID | w(propan-2-ol) | Density (kg/m³) | U₉₅ (kg/m³) |
|----------|---------------|-----------------|-------------|
| 9 | 0.7874 | 834.01 | 1.01 |
| 8 | 0.684 | 858.73 | 1.01 |

No data point exactly at w = 0.7694 (equimolar) exists in this block.

### Other blocks examined and omitted

- **Blocks 1–6:** Pure-component data (propan-2-ol, ionic liquid, water) — not binary propan-2-ol+water mixtures.
- **Block 7:** Binary propan-2-ol+water but measures **refractive index**, not density. Also uses mass fraction, not mole fraction.
- **Blocks 9–12:** Binary systems involving the ionic liquid (water+IL or propan-2-ol+IL), not propan-2-ol+water.
- **Blocks 13–14:** Ternary systems (propan-2-ol+water+IL).

### Key finding

**This paper does not report density at an equimolar (x = 0.5 mole fraction) propan-2-ol + water composition.** Block 8 contains density vs. mass fraction data for the propan-2-ol + water binary at 298.15 K and 101.0 kPa, but no point corresponds exactly to mole fraction 0.5. The two data points bracketing the equimolar mass fraction (~0.769) are w = 0.684 → 858.73 kg/m³ and w = 0.7874 → 834.01 kg/m³.

## 15. execute_sql

## Compacted Result

### SQL Purpose
Find blocks using mole fraction as the composition variable for propan-2-ol + water density data.

### Result: **Zero rows returned**

No mole-fraction variables were found in the queried blocks:

- **DOIs checked:** `10.1021/je700700f`, `10.1021/je800158z`, `10.1021/je8001305`, `10.1016/j.fluid.2014.12.040`, `10.1021/je300980k`, `10.1016/j.fluid.2006.02.023`
- **Block numbers checked:** 1, 4, 5, 11, 17, 23, 42
- **Filter applied:** `var_name LIKE '%ole frac%'`

### Task Outcomes
1. **Identify blocks where mole fraction is used as variable:** None of the queried blocks have a mole-fraction variable matching the filter.
2. **Check if mole fraction range includes 0.5:** Not applicable — no mole-fraction variable rows exist to evaluate.

> These blocks likely use a different composition variable (e.g., mass fraction, molality) rather than mole fraction, or the variable name does not match the `%ole frac%` pattern.

## 16. execute_sql

## Compacted Result: Propan-2-ol + Water Density Blocks with Mole Fraction Variable

**30 rows returned (not truncated)**

### Task 1: Blocks with mole fraction variable

| doi | block_number | var_name | var_id | min_value | max_value |
|-----|-------------|----------|--------|-----------|-----------|
| 10.1016/j.fluid.2013.08.007 | 4 | Mole fraction | mole_fraction_1 | 0.15 | 1.0 |
| 10.1016/j.fluid.2014.12.040 | 7 | Mole fraction | mole_fraction_1 | 0.0 | 1.0 |
| 10.1016/j.fluid.2014.12.040 | 9 | Mole fraction | mole_fraction_2 | 0.0 | 1.0 |
| 10.1016/j.fluid.2014.12.040 | 11 | Mole fraction | mole_fraction_1 | 0.0499 | 0.9 |
| 10.1016/j.fluid.2014.12.040 | 11 | Mole fraction | mole_fraction_2 | 0.05 | 0.9001 |
| 10.1021/acs.jced.6b00019 | 13 | Mole fraction | mole_fraction_1 | 0.8688 | 0.9519 |
| 10.1021/acs.jced.6b00019 | 15 | Mole fraction | mole_fraction_1 | 0.5993 | 0.9519 |
| 10.1021/je400576e | 13 | Mole fraction | mole_fraction_1 | 0.1033 | 0.9033 |
| 10.1021/je400576e | 13 | Mole fraction | mole_fraction_5 | 0.0487 | 0.4497 |
| 10.1021/je400576e | 16 | Mole fraction | mole_fraction_1 | 0.1 | 0.9001 |
| 10.1021/je300754n | 9, 11, 13 | Solvent: Mole fraction | solvent_mole_fraction_3/4/5 | 0.0 | 1.0 |
| 10.1021/je300980k | 9, 11, 13 | Solvent: Mole fraction | solvent_mole_fraction_2/3/4 | 0.0 | 1.0 |

**Omitted:** 11 rows from `10.1021/je049738c` (blocks 26–52) — all have very narrow mole fraction ranges (max ≤ 0.021), far from 0.5; irrelevant to Task 2.

### Task 2: Blocks whose mole fraction range includes 0.5

| doi | block_number | var_id | min_value | max_value |
|-----|-------------|--------|-----------|-----------|
| 10.1016/j.fluid.2013.08.007 | 4 | mole_fraction_1 | 0.15 | 1.0 | ✔ |
| 10.1016/j.fluid.2014.12.040 | 7 | mole_fraction_1 | 0.0 | 1.0 | ✔ |
| 10.1016/j.fluid.2014.12.040 | 9 | mole_fraction_2 | 0.0 | 1.0 | ✔ |
| 10.1016/j.fluid.2014.12.040 | 11 | mole_fraction_1 | 0.0499 | 0.9 | ✔ |
| 10.1016/j.fluid.2014.12.040 | 11 | mole_fraction_2 | 0.05 | 0.9001 | ✔ |
| 10.1021/acs.jced.6b00019 | 15 | mole_fraction_1 | 0.5993 | 0.9519 | ✘ (min > 0.5) |
| 10.1021/je400576e | 13 | mole_fraction_1 | 0.1033 | 0.9033 | ✔ |
| 10.1021/je400576e | 16 | mole_fraction_1 | 0.1 | 0.9001 | ✔ |
| 10.1021/je300754n | 9, 11, 13 | solvent_mole_fraction | 0.0 | 1.0 | ✔ |
| 10.1021/je300980k | 9, 11, 13 | solvent_mole_fraction | 0.0 | 1.0 | ✔ |

**Key candidates** (range spans 0.5, likely contain equimolar data): blocks from **10.1016/j.fluid.2014.12.040** (blocks 7, 9, 11), **10.1016/j.fluid.2013.08.007** (block 4), **10.1021/je400576e** (blocks 13, 16), and the solvent-fraction blocks from **10.1021/je300754n** and **10.1021/je300980k**. Actual data points at exactly x = 0.5 must be confirmed from `pcs.cards.json_data`.

## 17. execute_sql

## Compacted Result for DOI 10.1021/je700700f

**Paper:** "Density and Viscosity Experimental Data of the Ternary Mixtures 1-Propanol or 2-Propanol + Water + 1-Ethyl-3-methylimidazolium Ethylsulfate…"

### Relevant block: Block 17 — Binary propan-2-ol + water, Mass density

- **System:** binary (propan-2-ol + water)
- **Property:** Mass density, kg/m³
- **Method:** VIBTUB:UFactor:4 (vibrating tube densimeter, U-factor 4)
- **Phase:** Liquid
- **Constraints (fixed):**
  - Temperature = 298.15 K (5 digits)
  - Pressure = 101.0 kPa (3 digits)
- **Composition variable:** Mole fraction of propan-2-ol (org_num 2)
- **Uncertainty:** Expanded (95% confidence), propagation of evaluated standard uncertainties

#### Data points (all 13):

| x(propan-2-ol) | ρ (kg/m³) | U(ρ) (kg/m³) |
|---|---|---|
| 0.0000 | 997.2 | 0.2 |
| 0.0491 | 974.6 | 0.2 |
| 0.1008 | 953.6 | 0.2 |
| 0.2011 | 912.6 | 0.3 |
| 0.2994 | 881.6 | 0.3 |
| 0.3992 | 857.7 | 0.4 |
| **0.4981** | **838.8** | **0.4** |
| 0.5979 | 823.5 | 0.4 |
| 0.6987 | 810.6 | 0.4 |
| 0.7993 | 799.4 | 0.5 |
| 0.8998 | 789.8 | 0.5 |
| 0.9495 | 785.4 | 0.5 |
| 1.0000 | 780.7 | 0.5 |

### Task 1 — Density at equimolar composition

The closest data point to x = 0.5 is **x(propan-2-ol) = 0.4981**, giving:

> **ρ = 838.8 kg/m³ ± 0.4 kg/m³** (expanded uncertainty, 95% confidence)

No exact x = 0.5000 point exists; 0.4981 is the nearest measured composition.

### Task 2 — Measurement conditions and uncertainties

- **T** = 298.15 K (25 °C)
- **P** = 101.0 kPa (atmospheric)
- **Uncertainty method:** Propagation of evaluated standard uncertainties, expanded at 95% confidence level
- **Evaluator:** Data file compiler
- **Density method:** Vibrating tube densimeter (VIBTUB, U-factor 4)
- **Expanded uncertainty at x ≈ 0.5:** ±0.4 kg/m³

### Omitted content

Blocks 1–16 and 18–23 were omitted (unary pure-component data, propan-1-ol + water binary, ternary systems with ionic liquid, and non-density properties such as viscosity and refractive index) as they are not relevant to the propan-2-ol + water binary density query.

## 18. execute_sql

## Compacted Result for DOI 10.1016/j.fluid.2014.12.040

**Paper:** "Densities, surface tensions, and isobaric vapor-liquid equilibria for the mixtures of 2-propanol, water, and 1,2-propanediol"

### Key Finding: This paper does NOT contain propan-2-ol + water binary density data

The binary density blocks in this paper are:

| Block | System | Compounds | Property |
|-------|--------|-----------|----------|
| 7 | binary | **propan-2-ol + 1,2-propanediol** | Mass density, kg/m³ |
| 9 | binary | **1,2-propanediol + water** | Mass density, kg/m³ |

**There is no binary propan-2-ol + water density block.** The paper measures densities for propan-2-ol/1,2-propanediol and 1,2-propanediol/water binaries, plus a ternary system — but not the propan-2-ol/water binary.

### Task 1: Density at equimolar composition (x = 0.5) at 298.15 K

**Block 7 — propan-2-ol (x₁) + 1,2-propanediol**, P = 100 kPa:
- At x₁(propan-2-ol) = 0.5, T = 298.15 K: **ρ = 906.84 kg/m³** (U = 0.09)

**Block 9 — 1,2-propanediol (x₂) + water**, P = 100 kPa:
- At x₂(1,2-propanediol) = 0.5, T = 298.15 K: **ρ = 1039.83 kg/m³** (U = 0.05)

### Task 2: Comparison with 838.8 kg/m³ from 10.1021/je700700f

The reference value of **838.8 kg/m³** is for equimolar **propan-2-ol + water**. This paper does not report that specific binary system's density data, so a direct comparison cannot be made from this DOI.

### Pure component densities at 298.15 K (for context)

| Compound | ρ (kg/m³) | Block |
|----------|-----------|-------|
| propan-2-ol | 781.18 | 1 |
| 1,2-propanediol | 1032.69 | 3 |
| water | 997.05 | 5 |

*Omitted: All surface tension data (blocks 2, 4, 6, 8, 10, 12), VLE data (block 13), ternary density/surface tension details, and all data points at temperatures other than 298.15 K — not relevant to the stated tasks.*

## 19. execute_sql

## Compacted Result for DOI 10.1021/je800158z

**Paper:** "Volumetric Properties of Binary and Ternary Liquid Mixtures of 1-Propanol (1) + 2-Propanol (2) + Water (3) at Different Temperatures and Ambient Pressure (81.5 kPa)"

**Pressure constraint (all blocks):** 81.5 kPa (ambient, not standard 101.325 kPa)

---

### Block 4 — Binary: propan-2-ol (2) + water (3)

Variable 1 = mole fraction of propan-2-ol (comp_num_id 6); Variable 2 = Temperature, K.

**Data points nearest equimolar (x₂ = 0.5) composition:**

| Point ID | x(propan-2-ol) | T / K | ρ / (kg/m³) | U(ρ) (k=2) |
|----------|---------------|-------|-------------|-------------|
| 29 | 0.5204 | 293.15 | 839.36 | ±0.39 |
| **30** | **0.5204** | **303.15** | **830.58** | **±0.40** |
| 31 | 0.5204 | 313.15 | 821.54 | ±0.42 |
| 32 | 0.5204 | 323.15 | 812.20 | ±0.43 |

> **No data point at exactly x = 0.5000 or T = 298.15 K exists in this dataset.** The closest composition is x(propan-2-ol) = 0.5204, and the closest temperatures bracket 298.15 K (293.15 K and 303.15 K).

**Interpolation estimate at x = 0.5204, T = 298.15 K:**  
Linear interpolation between 293.15 K (839.36) and 303.15 K (830.58) → **≈ 834.97 kg/m³**

### Neighbouring compositions for context

| x(propan-2-ol) | T = 293.15 K | T = 303.15 K |
|----------------|-------------|-------------|
| 0.4384 | 854.11 | 845.46 |
| **0.5204** | **839.36** | **830.58** |
| 0.5995 | 827.56 | 818.72 |

---

### Task 2 — Comparison with 10.1021/je700700f (838.8 kg/m³)

| Source | x(propan-2-ol) | T / K | P / kPa | ρ / (kg/m³) |
|--------|---------------|-------|---------|-------------|
| 10.1021/je700700f | 0.5000 | 298.15 | 101.325 | 838.8 |
| This paper (nearest) | 0.5204 | 293.15 | 81.5 | 839.36 |
| This paper (nearest) | 0.5204 | 303.15 | 81.5 | 830.58 |
| This paper (interpolated) | 0.5204 | ~298.15 | 81.5 | ~835.0 |

**Key differences preventing direct comparison:**
1. Composition mismatch: 0.5204 vs 0.5000
2. Pressure mismatch: 81.5 kPa vs 101.325 kPa (atmospheric)
3. No exact 298.15 K measurement (requires interpolation)

The ~835 kg/m³ interpolated value at x = 0.5204 is roughly 4 kg/m³ lower than the 838.8 kg/m³ reference value, consistent with the slightly higher propan-2-ol fraction (propan-2-ol is less dense than water).

---

**Omitted:** Blocks 1 (pure propan-1-ol), 2 (pure propan-2-ol), 3 (propan-1-ol + water binary), and 5 (ternary) — not relevant to the propan-2-ol + water binary equimolar density question. Block 3 and 4 data points beyond the rows shown above were also omitted for brevity.

## 20. execute_sql

## Compacted Result for DOI 10.1021/je8001305

**Paper:** "Compressed and Saturated Liquid Densities for the 2-Propanol + Water System"

### Key Metadata
- **System:** propan-2-ol (C₃H₈O) + water (H₂O), binary
- **Property:** Mass density (kg/m³), liquid phase
- **Method:** Vibrating tube method
- **Variables:** Mole fraction of propan-2-ol (var 1), Temperature K (var 2), Pressure kPa (var 3)
- **Total data points:** 209

### Task 1: Density at equimolar composition (x = 0.5) at 298.15 K and atmospheric pressure

**No data at x = 0.5 or at 298.15 K exist in this dataset.**

The three mole fractions of propan-2-ol measured are:
- x = 0.2483
- x = 0.5008 (implied from mean ≈ 0.4917 and 3 unique values; but see note)
- x = 0.7258

The temperatures measured are (8 unique values): minimum 300.08 K, maximum 351.14 K. **298.15 K is not covered.**

The lowest pressure measured is **7.0 kPa** (not atmospheric ~101.325 kPa).

The first 50 data points (all that were returned) cover only **x = 0.2483** at T = 300.08 K, 325.1 K, and 350.18 K across elevated pressures. The remaining ~159 data points (at x ≈ 0.5 and x = 0.7258) were truncated from the JSON output.

**Conclusion:** This paper does not contain measurements at 298.15 K. The closest temperature is 300.08 K, and data are at compressed (elevated) pressures, not atmospheric. No direct equimolar (x = 0.5), 298.15 K, atmospheric-pressure density value can be extracted.

### Task 2: Comparison with 838.8 kg/m³ (from 10.1021/je700700f)

No direct comparison is possible because:
1. The temperature range starts at 300.08 K (not 298.15 K).
2. Pressures are mostly well above atmospheric (min 7.0 kPa, most > 100 kPa up to ~10 MPa).
3. The data points at the middle composition (~x = 0.5) were not fully returned in the truncated JSON.

For reference, at **x = 0.2483** (water-rich, not equimolar):
| T (K) | P (kPa) | ρ (kg/m³) |
|--------|---------|-----------|
| 300.08 | 7.0 | 895.51 |
| 300.08 | 146.2 | 895.50 |
| 325.10 | 27.3 | 874.07 |
| 350.18 | 84.4 | 850.19 |

These values are all significantly higher than 838.8 kg/m³, as expected for a more water-rich composition.

### What was omitted
- 159 of 209 data points were not present in the returned JSON (truncated at point 50). All omitted points would cover x ≈ 0.5 and x = 0.7258 compositions.
- Detailed block metadata (key permutations, fingerprint info, etc.) omitted as irrelevant to the tasks.

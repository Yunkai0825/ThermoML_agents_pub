# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 20
- **API turns:** 18
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 387.0s
- **Timed out:** False

## Answer

I now have sufficient evidence to provide a comprehensive answer. Here is the summary:

---

## Density of an Equimolar Propan-2-ol + Water Liquid Mixture at 25 °C and Atmospheric Pressure

### Database Evidence

The most directly relevant measurement comes from the ThermoML database:

**Source:** DOI [10.1021/je700700f](https://doi.org/10.1021/je700700f)
- **System:** Binary propan-2-ol + water (liquid phase)
- **Composition:** x(propan-2-ol) = **0.4981** (essentially equimolar)
- **Temperature:** 298.15 K (25 °C)
- **Pressure:** 101.0 kPa (atmospheric)
- **Method:** Vibrating tube densimeter

> **Measured density: ρ = 838.8 ± 0.4 kg/m³** (expanded uncertainty at 95% confidence)

This corresponds to approximately **0.8388 g/cm³**.

### Corroboration

A second paper (DOI [10.1021/je800158z](https://doi.org/10.1021/je800158z)) measured the same system at a nearby composition (x = 0.5204) and bracketing temperatures (293.15 K and 303.15 K) at 81.5 kPa. Interpolating to 298.15 K gives ~835 kg/m³ at x = 0.5204, which is consistent with the reference value when accounting for the slightly higher propan-2-ol content (which lowers the density).

### Chemical Interpretation

The density of **838.8 kg/m³** for the equimolar mixture lies between the pure component values at 25 °C:
- Pure water: ~997 kg/m³
- Pure propan-2-ol: ~781 kg/m³

However, the mixture density is **not** a simple linear average of the pure components (which would be ~889 kg/m³ by mole-fraction weighting). The equimolar mixture is significantly **less dense** than the linear interpolation would predict, reflecting a **positive excess volume** (volume expansion upon mixing). This is characteristic of the propan-2-ol + water system, where the disruption of water's hydrogen-bonding network by the hydrophobic isopropyl group leads to less efficient molecular packing compared to the pure liquids. The excess volume is most pronounced in the alcohol-rich region, which is why the measured density (838.8 kg/m³) falls well below the ideal mixing prediction.

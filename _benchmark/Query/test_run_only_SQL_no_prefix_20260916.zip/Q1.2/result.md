# Q1.2 — Result

**Prompt:** For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 6
- **API turns:** 7
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 157.9s
- **Timed out:** False

## Answer

Excellent! All blocks cover the equimolar composition. Here is a comprehensive answer:

---

## Thermophysical Properties Measured for an Equimolar Liquid Mixture of Hexane + Ethanol near 25 °C

Based on the ThermoML database, **eight distinct thermophysical properties** have been measured for the binary liquid mixture of **hexane (C₆H₁₄) + ethanol (C₂H₆O)** at or near **25 °C (298.15 K)**, with composition ranges that include the equimolar (x ≈ 0.5) point. They span four property groups:

### Volumetric Properties
| Property | Units | Source DOI(s) |
|----------|-------|---------------|
| **Mass density** | kg/m³ | 10.1016/j.jct.2007.02.008; 10.1021/je800925v |
| **Excess molar volume** | m³/mol | 10.1016/j.fluid.2005.08.001 |

### Energy / Mixing Properties
| Property | Units | Source DOI |
|----------|-------|-----------|
| **Excess molar enthalpy (enthalpy of mixing)** | kJ/mol | 10.1016/j.fluid.2005.08.001 |

### Transport Properties
| Property | Units | Source DOI |
|----------|-------|-----------|
| **Viscosity** | Pa·s | 10.1021/je800925v |
| **Binary diffusion coefficient** | m²/s | 10.1021/je0497303 |

### Refraction, Surface Tension & Sound Speed
| Property | Units | Source DOI |
|----------|-------|-----------|
| **Refractive index (Na D-line)** | dimensionless | 10.1016/j.jct.2007.02.008 |
| **Speed of sound** | m/s | 10.1016/j.jct.2007.02.008 |
| **Surface tension (liquid–gas)** | N/m | 10.1021/je700215z |

### Chemical Insight

Hexane + ethanol is a classic **non-ideal mixture** — hexane is a nonpolar hydrocarbon while ethanol is a polar, hydrogen-bonding molecule. This strong dissimilarity is reflected in the measured properties:

- **Positive excess molar enthalpy (Hᴱ)** and **positive excess molar volume (Vᴱ)** are expected, indicating that mixing is endothermic and expansive — energy is required to break ethanol's hydrogen-bond network, and the unlike molecular interactions are weaker than the like–like ones.
- **Viscosity** deviations from ideal mixing are typically negative for such systems, since the disruption of ethanol's H-bond structure reduces the mixture's resistance to flow relative to a linear interpolation.
- **Diffusion coefficients** in this system are composition-dependent and reflect the changing microstructure from ethanol-rich (clustered H-bond networks) to hexane-rich (dispersive interactions).
- **Surface tension** and **refractive index** vary non-linearly with composition, with hexane's lower surface tension and refractive index pulling the mixture values down relative to pure ethanol.

All data are reported for the **liquid phase**, across **5 distinct publications** and **9 data blocks**, with mole fraction ranges spanning the full 0–1 composition range (confirming coverage of the equimolar point).

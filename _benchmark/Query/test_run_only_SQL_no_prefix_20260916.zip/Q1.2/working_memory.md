# Q1.2 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Compound Registry Results for Hexane and Ethanol

| comp_num_id | comp_id | common_name | formula | inchi_key |
|---|---|---|---|---|
| **2** | ethanol | ethanol | C2H6O | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |
| **12** | hexane | hexane | C6H14 | VLKZOEOYAKHREP-UHFFFAOYSA-N |

### Key identifiers
- **Ethanol**: `comp_num_id = 2`, InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`
- **Hexane** (n-hexane): `comp_num_id = 12`, InChIKey `VLKZOEOYAKHREP-UHFFFAOYSA-N`

### Omitted rows (5)
Five other compounds matched the formula filters but are not the target compounds: 2,2-dimethylbutane (174), 2,3-dimethylbutane (690), 2-methylpentane (401), 3-methylpentane (125) — all C6H14 isomers — and dimethyl ether (143, C2H6O). These were excluded as irrelevant branched/isomeric matches.

## 2. execute_sql

## Compacted SQL Result

### Query
Find all binary mixture data blocks containing both hexane (`comp_num_id=12`) and ethanol (`comp_num_id=2`).

### Result: **Zero rows returned**

The query returned **no matching blocks**. No binary hexane + ethanol data blocks were found in `idx.block_index` using the filter `comp_num_id = '2'` (ethanol) and `comp_num_id = '12'` (hexane).

### Implications for all three tasks

| Task | Status |
|---|---|
| List all binary hexane+ethanol blocks | **None found** |
| Identify DOIs and block numbers for further property lookup | **No DOIs/blocks available** |
| Check variable/constraint ranges for temperature near 298 K | **Not applicable — no blocks to inspect** |

### Possible reasons for empty result
- The `comp_num_id` values used (`'2'` for ethanol, `'12'` for hexane) may not be the correct identifiers in this database. The answering agent should verify by querying `idx.compound_registry` for hexane and ethanol (e.g., by `common_name` or `inchi_key`) to confirm the actual `comp_num_id` values before concluding that no data exist.

## 3. execute_sql

## Compacted Result

### Task 1: DOI / block pairs for hexane + ethanol mixtures

50 rows returned (query limit reached — there may be additional blocks beyond these).

| DOI | Block number(s) |
|-----|-----------------|
| 10.1016/j.fluid.2005.08.001 | 5, 6, 15, 16 |
| 10.1016/j.fluid.2007.04.011 | 1, 2, 3, 4 |
| 10.1016/j.fluid.2008.06.003 | 11, 12 |
| 10.1016/j.fluid.2009.08.016 | 3, 4 |
| 10.1016/j.fluid.2009.12.016 | 3 |
| 10.1016/j.fluid.2010.05.006 | 3 |
| 10.1016/j.fluid.2011.11.009 | 1 |
| 10.1016/j.fluid.2012.10.004 | 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24 |
| 10.1016/j.fluid.2013.06.018 | 12, 14 |
| 10.1016/j.fluid.2013.10.060 | 13, 14, 15, 16 |
| 10.1016/j.fluid.2018.07.013 | 3, 4, 16 |
| 10.1016/j.jct.2007.02.008 | 22, 23, 24 |
| 10.1016/j.jct.2012.06.028 | 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 |

**Total: 50 rows across 13 distinct DOIs.**

### Task 2: Compound name confirmation

In every returned row:
- **comp1** (InChIKey `VLKZOEOYAKHREP-UHFFFAOYSA-N`) = **"hexane"**
- **comp2** (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`) = **"ethanol"**

Names are consistent across all 50 rows — confirmed as hexane and ethanol.

### Note
The query was capped at `LIMIT 50` and returned exactly 50 rows, so **additional hexane + ethanol blocks likely exist** beyond those listed. A follow-up query without the limit (or with a higher limit) would be needed for completeness. Property information for these blocks was not retrieved in this query.

## 4. execute_sql

## Compacted Result: Hexane + Ethanol Binary Mixture Properties near 25 °C

**9 rows returned (not truncated). All phases are liquid.**

### Distinct Properties by Group

| Property Name | Property Group | phase_id | DOI(s) |
|---|---|---|---|
| Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | ExcessPartialApparentEnergyProp | liquid | 10.1016/j.fluid.2005.08.001 |
| Refractive index (Na D-line) | RefractionSurfaceTensionSoundSpeed | liquid | 10.1016/j.jct.2007.02.008 |
| Speed of sound, m/s | RefractionSurfaceTensionSoundSpeed | liquid | 10.1016/j.jct.2007.02.008 |
| Surface tension liquid-gas, N/m | RefractionSurfaceTensionSoundSpeed | liquid | 10.1021/je700215z |
| Binary diffusion coefficient, m2/s | TransportProp | liquid | 10.1021/je0497303 |
| Viscosity, Pa·s | TransportProp | liquid | 10.1021/je800925v |
| Excess molar volume, m3/mol | VolumetricProp | liquid | 10.1016/j.fluid.2005.08.001 |
| Mass density, kg/m3 | VolumetricProp | liquid | 10.1016/j.jct.2007.02.008, 10.1021/je800925v |

### Notes
- **8 distinct property names** across **4 property groups**.
- Mass density appears in two separate DOIs (with slightly different value ranges: 650.4–789.3 vs 655.3–790.2 kg/m³; 39 vs 103 data points).
- All measured phases are **liquid**; no other phases appear.
- **5 distinct DOIs** contribute data.

## 5. execute_sql

## Compacted Result

### All distinct properties for hexane + ethanol (liquid phase) near 25 °C (297–299 K or constrained 293–303 K)

**All 8 properties are liquid phase (`phase_id = "liquid"`).**

| Property | Group | n_blocks | DOI(s) |
|---|---|---|---|
| Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | ExcessPartialApparentEnergyProp | 1 | 10.1016/j.fluid.2005.08.001 |
| Refractive index (Na D-line) | RefractionSurfaceTensionSoundSpeed | 1 | 10.1016/j.jct.2007.02.008 |
| Speed of sound, m/s | RefractionSurfaceTensionSoundSpeed | 1 | 10.1016/j.jct.2007.02.008 |
| Surface tension liquid-gas, N/m | RefractionSurfaceTensionSoundSpeed | 1 | 10.1021/je700215z |
| Binary diffusion coefficient, m2/s | TransportProp | 1 | 10.1021/je0497303 |
| Viscosity, Pa·s | TransportProp | 1 | 10.1021/je800925v |
| Excess molar volume, m3/mol | VolumetricProp | 1 | 10.1016/j.fluid.2005.08.001 |
| Mass density, kg/m3 | VolumetricProp | 2 | 10.1016/j.jct.2007.02.008, 10.1021/je800925v |

### Summary
- **8 distinct properties** across **5 distinct DOIs**.
- **All entries are liquid phase** — no other phase appears.
- Result was **not truncated** (8 rows total).

## 6. execute_sql

## Mole-Fraction Variable Ranges for Hexane + Ethanol Blocks near 298 K

All 9 rows returned; no truncation.

Every block's mole-fraction range **spans x = 0.5**, confirming equimolar composition is covered.

| DOI | Block | var_name | min_value | max_value | n_unique |
|-----|-------|----------|-----------|-----------|----------|
| 10.1016/j.fluid.2005.08.001 | 5 | Mole fraction | 0.0544 | 0.9528 | 17 |
| 10.1016/j.fluid.2005.08.001 | 6 | Mole fraction | 0.0417 | 0.9497 | 23 |
| 10.1016/j.jct.2007.02.008 | 22 | Mole fraction | 0.0 | 1.0 | 13 |
| 10.1016/j.jct.2007.02.008 | 23 | Mole fraction | 0.0 | 1.0 | 13 |
| 10.1016/j.jct.2007.02.008 | 24 | Mole fraction | 0.0 | 1.0 | 13 |
| 10.1021/je0497303 | 8 | Mole fraction | 0.0 | 1.0 | 9 |
| 10.1021/je700215z | 5 | Mole fraction | 0.0855 | 0.932 | 11 |
| 10.1021/je800925v | 9 | Mole fraction | 0.0 | 1.0 | 11 |
| 10.1021/je800925v | 10 | Mole fraction | 0.0 | 1.0 | 11 |

### Summary per task

1. **x = 0.5 spanned?** Yes — every block has min_value < 0.5 and max_value > 0.5.
2. **Which blocks have composition as a variable covering equimolar?** All 9 blocks across 4 DOIs listed above qualify (5 blocks span the full 0–1 range; the remaining 4 span at least ~0.04–0.95).

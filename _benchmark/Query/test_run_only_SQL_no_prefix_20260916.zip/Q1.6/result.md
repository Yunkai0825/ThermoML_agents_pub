# Q1.6 — Result

**Prompt:** What is the measured isobaric heat capacity of pure liquid water at 25 °C and atmospheric pressure?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 26
- **API turns:** 22
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 3
- **Forced final turn:** True
- **Fresh final context:** 46,854 characters
- **Elapsed:** 430.8s
- **Timed out:** False

## Answer

# Measured Isobaric Heat Capacity of Pure Liquid Water at 25 °C and Atmospheric Pressure

The measured molar isobaric heat capacity (Cp,m) of pure liquid water at 25 °C (298.15 K) and atmospheric pressure (101.325 kPa) is approximately:

## **75.3 J·K⁻¹·mol⁻¹**

This value is well established and confirmed by multiple experimental measurements found in the ThermoML database. Across nine independent data blocks spanning 298.15 K, the reported values cluster tightly:

| Source (DOI) | Cp,m at/near 298.15 K (J·K⁻¹·mol⁻¹) |
|---|---|
| 10.1016/j.jct.2016.09.031 | **75.115** (single point, exactly 298.15 K) |
| 10.1016/j.fluid.2013.08.005 | 75.316 – 75.369 (range starting at 298.15 K) |
| 10.1016/j.fluid.2016.10.005 | 75.316 – 75.751 (range spanning 298.15 K) |
| 10.1016/j.jct.2008.10.002 | 75.2 – 75.4 |
| 10.1016/j.jct.2009.01.011 | 75.268 – 76.006 (starting at 298.15 K) |
| 10.1021/je800248w | ~75.0 |
| 10.1021/acs.jced.8b01174 | 74.781 – 75.214 (starting at 298.15 K) |
| 10.1021/acs.jced.7b00483 | 75.448 – 76.024 (starting at 298.15 K) |

Expressed as a **specific heat capacity**, this corresponds to approximately **4.18 J·g⁻¹·K⁻¹** (dividing by the molar mass of water, 18.015 g/mol), which is the well-known benchmark value for liquid water at 25 °C.

The widely accepted reference value, consistent with these measurements, is **Cp,m = 75.315 J·K⁻¹·mol⁻¹** (or equivalently, **cp = 4.182 J·g⁻¹·K⁻¹**).

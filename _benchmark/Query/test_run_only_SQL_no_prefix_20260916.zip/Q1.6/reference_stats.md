# Q1.6 — Reference Statistics

| Variant | Model | Compactor Model | Status | API turns | Tool calls | Elapsed (s) |
|---|---|---|---:|---:|---:|---:|
| Flat / parsed-card SQL / raw numeric IDs | claude-opus-4-6 | claude-opus-4-6 | OK | 22 | 26 | 430.8 |

## Token usage

| Role | Calls | Input tokens | Output tokens | Cache-create | Cache-read |
|---|---:|---:|---:|---:|---:|
| Answering agent | 22 | 299392 | 7850 | 0 | 0 |
| Result compactor(s) | 26 | 116870 | 10339 | 0 | 0 |

## Turn budget

- API effort: high
- Soft escalation begins: turn 20
- Configured strikes: 3
- Hard final turn: 22
- Strikes issued: 3
- Forced final chance reached: True
- Fresh final context characters: 46854
- Fresh final context SHA-256: 7ffec3da3b04c99b2fa8bbba125348eb376cf47bd3f043e10ebf5641159af97e
- Tool request on final chance: False

# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 23
- **API turns:** 21
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 2
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 324.5s
- **Timed out:** False

## Answer

Based on my thorough investigation of the ThermoML database, I can now provide a definitive answer.

---

## Activity Coefficients for Aqueous Lithium Chloride near 25 °C

### Database Evidence

After an exhaustive search of the ThermoML database, **no activity coefficient measurements for aqueous lithium chloride (LiCl) are present in this dataset**. Specifically:

- **Lithium chloride** is well-represented in the database (comp_num_id = 107, InChIKey: KWGKDLIKAYFUFQ-UHFFFAOYSA-M), appearing across ~30 DOIs.
- However, the properties measured for LiCl in ThermoML are limited to:
  - **Volumetric properties** (mass density)
  - **Transport properties** (viscosity, electrical conductivity)
  - **Refractive index**
  - **Phase equilibrium compositions** (solubility, mole/mass fractions, molality)
  - **Calorimetric properties** (heat capacity, enthalpy of solution/reaction)
- **No activity coefficients** (neither mean ionic activity coefficient, osmotic coefficient, nor relative activity) were found in any block containing LiCl.

### General Chemical Knowledge

Despite the absence in ThermoML, activity coefficients for aqueous LiCl are among the **most extensively studied** in electrolyte solution chemistry:

1. **Classic measurements** by Robinson & Stokes (1959) and Hamer & Wu (1972) provide mean ionic activity coefficients (γ±) for LiCl(aq) at 25 °C over a very wide molality range, typically from **~0.001 mol/kg up to ~6 mol/kg** (and in some studies up to saturation near ~19.9 mol/kg).

2. **At 25 °C**, the mean ionic activity coefficient γ± of LiCl shows characteristic behavior:
   - It **decreases** from unity at infinite dilution due to Debye-Hückel electrostatic screening.
   - It passes through a **minimum** around ~0.5–1 mol/kg.
   - It then **increases sharply** at higher concentrations due to strong Li⁺ hydration effects, reaching values well above 1 (e.g., γ± ≈ 1.96 at 3 mol/kg, and much higher at saturation).

3. LiCl is notable for having **unusually large** activity coefficients at high concentration compared to other alkali halides, reflecting the very strong hydration of the small Li⁺ ion.

### Summary

While the ThermoML database does not contain activity coefficient data for aqueous LiCl, such measurements are extensively available in the broader literature, covering concentrations from dilute (~0.001 mol/kg) to near-saturation (~6–20 mol/kg) at 25 °C. The absence from ThermoML likely reflects the fact that the classic reference datasets for this system predate the ThermoML digitization effort.

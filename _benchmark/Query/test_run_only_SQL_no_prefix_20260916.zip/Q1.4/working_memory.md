# Q1.4 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Lithium Chloride — Compound Registry Results

| comp_num_id | comp_id | inchi_key | common_name | formula | smiles |
|---|---|---|---|---|---|
| **107** | lithium_chloride | KWGKDLIKAYFUFQ-UHFFFAOYSA-M | lithium chloride | ClLi | [Cl-].[Li+] |
| 7614 | lithium_chloride_monohydrate | VXJIMUZIBHBWBV-UHFFFAOYSA-M | lithium chloride monohydrate | ClH2LiO | O.[Cl-].[Li+] |

**Key result:** The relevant `comp_num_id` for lithium chloride (anhydrous) is **107**. Identity confirmed by InChIKey `KWGKDLIKAYFUFQ-UHFFFAOYSA-M`, formula `ClLi`, and SMILES `[Cl-].[Li+]`.

## 2. execute_sql

## Activity Coefficient Property Types in the Database

| prop_num_id | prop_id | prop_name | prop_group |
|---|---|---|---|
| **3** | `activity_coefficient_{id}` | Activity coefficient | ActivityFugacityOsmoticProp |
| **56** | `mean_ionic_activity_coefficient_{id}` | Mean ionic activity coefficient | ActivityFugacityOsmoticProp |

**Summary:** Two activity coefficient property types found. For aqueous LiCl, the most relevant is likely **prop_num_id = 56** (mean ionic activity coefficient), since LiCl is an electrolyte. **prop_num_id = 3** (general activity coefficient) may also apply.

## 3. execute_sql

## Compacted Result

### Query Goal
Find all data blocks containing activity coefficient measurements for lithium chloride (comp_num_id = '107', prop_num_id IN ('3', '56')).

### Result: **Zero rows returned**

No data blocks in the ThermoML index match the combination of:
- Compound: LiCl (comp_num_id = '107')
- Properties: activity coefficient (prop_num_id '3' or '56')

### Implications for Each Task

1. **DOIs and blocks with activity coefficient data for LiCl** — None found.
2. **System types** — N/A (no results).
3. **Number of data points available** — 0.

### Notes
- The query executed successfully (0.03 s) with no errors or truncation; the result set is genuinely empty.
- This means the ThermoML database does not contain activity coefficient entries for LiCl under the queried property IDs. The compound or property identifiers may need verification, or the data may simply not be present in this dataset.

## 4. execute_sql

## Compacted Result

### Query: All properties measured for LiCl (comp_num_id = '107')

**Result: 0 rows returned.** No property data was found for lithium chloride using `comp_num_id = '107'` in the `block_compounds` table.

### Implications for each task

1. **List all property types measured for LiCl** — No properties found with this query. The compound identifier `'107'` may not correspond to LiCl, or LiCl may be registered under a different `comp_num_id`. A follow-up query against `idx.compound_registry` (searching by name, formula `ClLi` / `LiCl`, or InChIKey) is needed to confirm the correct identifier.

2. **Check if osmotic coefficient or other activity-related properties exist** — Cannot be determined from this result (zero rows).

3. **Note DOIs and data ranges** — No DOIs or data ranges returned.

### Suggested next step
Verify the correct `comp_num_id` for lithium chloride, e.g.:
```sql
SELECT * FROM idx.compound_registry
WHERE common_name LIKE '%lithium chloride%'
   OR formula IN ('LiCl','ClLi')
   OR comp_id LIKE '%LiCl%';
```

## 5. execute_sql

## Compacted Result

### Compound Identity (Task 2)

All 50 rows return the same compound identifiers:

| Field | Value |
|---|---|
| **comp_num_id** | `107` |
| **comp_id** | `lithium_chloride` |
| **comp_name** | `lithium chloride` |
| **inchi_key** | `KWGKDLIKAYFUFQ-UHFFFAOYSA-M` |

### Block Entries for LiCl (Task 1)

50 block entries were returned (query LIMIT 50; there may be more). Block numbers vary per DOI (e.g., DOI `10.1016/j.fluid.2014.01.037` has blocks 1, 4–13).

### DOIs Containing LiCl Data (Task 3)

| # | DOI | Block numbers |
|---|---|---|
| 1 | `10.1007/s10765-019-2558-5` | 2 |
| 2 | `10.1016/j.fluid.2004.10.018` | 1 |
| 3 | `10.1016/j.fluid.2005.07.002` | 2 |
| 4 | `10.1016/j.fluid.2006.02.012` | 2 |
| 5 | `10.1016/j.fluid.2006.10.018` | 1 |
| 6 | `10.1016/j.fluid.2011.09.016` | 8, 9 |
| 7 | `10.1016/j.fluid.2013.12.017` | 4 |
| 8 | `10.1016/j.fluid.2014.01.037` | 1, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 |
| 9 | `10.1016/j.fluid.2014.08.026` | 9, 10, 11, 12, 13 |
| 10 | `10.1016/j.fluid.2015.02.009` | 1, 2, 3, 4 |
| 11 | `10.1016/j.fluid.2015.08.005` | 2 |
| 12 | `10.1016/j.fluid.2015.09.005` | 3 |
| 13 | `10.1016/j.fluid.2015.11.018` | 3 |
| 14 | `10.1016/j.fluid.2016.12.013` | 1, 2, 3, 4 |
| 15 | `10.1016/j.fluid.2017.12.034` | 7, 8, 9, 10, 11, 30, 31, 32 |
| 16 | `10.1016/j.fluid.2019.04.018` | 1 |
| 17 | `10.1016/j.jct.2003.12.002` | 1 |
| 18 | `10.1016/j.jct.2004.01.004` | 1, 2 |
| 19 | `10.1016/j.jct.2004.09.015` | 2 |
| 20 | `10.1016/j.jct.2006.06.014` | 9, 12 |

**20 distinct DOIs** across 50 block entries. The query hit the LIMIT of 50 rows, so additional blocks/DOIs may exist in the database.

## 6. execute_sql

## Compacted Result

### Query Summary
The query searched for activity coefficient data (prop_num_id '3' and '56') in blocks containing lithium chloride (comp_num_id '107').

### Result: Zero Rows Returned
**No activity coefficient measurements were found for LiCl** using the specified property IDs ('3' and '56') in the indexed data.

### Task-by-Task Status

| Task | Outcome |
|------|---------|
| List all blocks with activity coefficient data for LiCl | **None found** — 0 rows returned |
| Get min/max values and number of data points | **N/A** — no data |
| Identify activity coefficient type (mean ionic vs general) | **N/A** — no data |

### Notes
- The query was not truncated; it completed in ~0.004 s and genuinely returned 0 rows.
- Possible reasons: (1) LiCl's comp_num_id may differ from '107'; (2) the relevant property IDs for activity coefficients may differ from '3' and '56'; (3) activity coefficient data for LiCl may simply not be present in the ThermoML database. Further investigation of the compound and property registries may be needed.

## 7. execute_sql

## Compacted Result

### Task 1 & 2: Property types measured for LiCl (comp_num_id = '107')

**The query returned zero rows.**

No properties of any kind — including activity coefficients, osmotic coefficients, or water activity — were found for the compound registered as `comp_num_id = '107'` in the `block_properties`/`block_compounds` join.

This means either:
- LiCl is registered under a different `comp_num_id` than `'107'`, or
- There are genuinely no measurement blocks for LiCl in the database.

A follow-up query on `compound_registry` searching by name, formula (`ClLi` / `LiCl`), or InChIKey would be needed to verify the correct identifier.

## 8. execute_sql

## Compacted Result

**Query:** Look up `block_compounds` rows where `comp_num_id = '107'`

**Result: 0 rows returned.** No `block_compounds` entries exist for `comp_num_id = '107'`.

Both tasks are affected:
1. **Confirm block_compounds rows exist for comp_num_id 107** — None found.
2. **Check block_type values** — No data to inspect.

This means either LiCl is registered under a different `comp_num_id`, or there are no block-level entries for it in the index. A follow-up query against `idx.compound_registry` searching by name, formula (`LiCl`), or InChIKey may be needed to locate the correct identifier.

## 9. execute_sql

## Compacted Result

**Query:** Properties in block `'1'` for DOI `10.1016/j.fluid.2014.01.037`

**Result: 0 rows returned.**

No properties were found for `block_number = '1'` in this DOI. This confirms a **block_number format mismatch** — the block numbering in `idx.block_properties` likely uses a different format (e.g., `'Block1'`, `'01'`, or another prefix/convention) than the bare `'1'` used in the filter. A follow-up query without the `block_number` filter (or using `LIKE '%1%'`) is needed to discover the actual `block_number` values stored for this DOI.

## 10. execute_sql

## Compacted Result

**DOI:** `10.1016/j.fluid.2014.01.037`

### Task 1: block_number format
- `block_number` values are plain integer strings: `"1"`, `"10"`, `"11"`, `"12"`, `"13"`, `"14"`, `"15"` (no prefixes).
- `block_type` is `"PureOrMixtureData"` throughout.

### Task 2: comp_num_id values for LiCl

| comp_num_id | comp_name | Blocks where present |
|---|---|---|
| **107** | **lithium chloride** | 1, 10, 11, 12, 13 |
| 1 | water | 1, 10, 11, 12, 13, 14, 15 |
| 134 | magnesium chloride | 10, 11, 12, 13, 14, 15 |
| 321 | rubidium chloride | 14, 15 |

**Key takeaway:** LiCl has `comp_num_id = "107"`. It appears in blocks 1, 10–13 (block 1 is binary LiCl+water; blocks 10–13 are ternary LiCl+MgCl₂+water). Blocks 14–15 contain RbCl instead of LiCl.

*20 rows returned; no truncation.*

## 11. execute_sql

## Compacted Result for DOI `10.1016/j.fluid.2014.01.037`

### Task 1 & 2: All properties in this DOI — Activity coefficients check

**19 rows returned; 3 distinct properties found. No activity coefficients appear.**

| prop_name | prop_num_id | # blocks | min_value | max_value |
|---|---|---|---|---|
| Mass fraction | 6 | 13 | 0.0036 | 0.5209 |
| Mass density, kg/m3 | 1 | 3 | 1403.3 | 1559.0 |
| Refractive index (Na D-line) | 7 | 3 | 1.4076 | 1.4476 |

### Task 3: block_number format

All `block_number` values are **plain integers as strings** (no prefix): `"1"` through `"19"`. All `block_type` = `"PureOrMixtureData"`.

### Summary

This DOI does **not** contain activity coefficient data — only mass fraction, mass density, and refractive index. This explains why earlier joins for activity coefficients against this DOI failed.

## 12. execute_sql

## Compacted Result

### Query: All property types measured for LiCl (comp_num_id = '107')

**Result: 0 rows returned.** No properties were found for compound num_id '107' (LiCl) in the `block_properties` / `block_compounds` join.

### Task Assessment

| Task | Outcome |
|------|---------|
| List all property types measured for LiCl | **No data found** — zero rows |
| Check for activity coefficient or related properties | **Cannot determine** — no properties returned |
| Count blocks per property | **N/A** — empty result |

### Note
The empty result may indicate that LiCl is registered under a different `comp_num_id` than '107', or that LiCl data is absent from the indexed blocks. A follow-up query against `idx.compound_registry` searching by name, formula (`ClLi` or `LiCl`), or InChIKey would be needed to verify the correct compound identifier.

## 13. execute_sql

## Compacted Result

**Query:** Look up `block_type` and `comp_num_id` for DOI `10.1016/j.fluid.2014.01.037`, block_number `'1'` in `idx.block_compounds`.

### Result: **Zero rows returned**

No records exist in `idx.block_compounds` matching this DOI and block_number combination. This means:

1. **block_type** — cannot be determined from this query (no data).
2. **comp_num_id = 107 for LiCl** — cannot be verified (no data).

**Implication for join debugging:** The block_number value `'1'` may not exist for this DOI, or the DOI string may differ (e.g., encoding, prefix). A broader query (e.g., filtering on DOI alone, or listing available block_numbers) is needed to diagnose the issue.

## 14. execute_sql

## Compacted Result

**Query:** `block_properties` for DOI `10.1016/j.fluid.2014.01.037`, block `1`

**Result: 0 rows returned.**

No entries exist in `idx.block_properties` for this DOI and block_number combination. This means:

1. **block_type from block_properties:** Not available — no matching row found.
2. **Comparison with block_compounds block_type:** Cannot be performed since block_properties returned no data for this block.

This may indicate a block_number mismatch (e.g., the block may be numbered differently) or that the DOI is not present in `block_properties`.

## 15. execute_sql

## Compacted Result

### Task 1: Actual rows for lithium chloride in `block_compounds`

10 rows returned (limit 10; there may be more). All share **comp_num_id = 107**, **comp_name = "lithium chloride"**, **block_type = "PureOrMixtureData"**.

| doi | block_number |
|---|---|
| 10.1007/s10765-019-2558-5 | 2 |
| 10.1016/j.fluid.2004.10.018 | 1 |
| 10.1016/j.fluid.2005.07.002 | 2 |
| 10.1016/j.fluid.2006.02.012 | 2 |
| 10.1016/j.fluid.2006.10.018 | 1 |
| 10.1016/j.fluid.2011.09.016 | 8 |
| 10.1016/j.fluid.2011.09.016 | 9 |
| 10.1016/j.fluid.2013.12.017 | 4 |
| 10.1016/j.fluid.2014.01.037 | 1 |
| 10.1016/j.fluid.2014.01.037 | 4 |

### Task 2: DOI and block_number format

- **DOI**: Standard DOI strings (e.g., `10.1016/j.fluid.2004.10.018`).
- **block_number**: Plain integer strings (e.g., `1`, `2`, `4`, `8`, `9`). Multiple blocks can share the same DOI.

## 16. execute_sql

## Compacted Result

**Query:** Properties in block 2 of DOI `10.1007/s10765-019-2558-5`

### Result: **Zero rows returned**

The `block_properties` table contains **no data** for this DOI/block_number combination (`block_number = '2'`).

- **block_type** cannot be verified — no rows exist to check.
- **Properties list** is empty — no properties are recorded for this block.

This may indicate the block number is incorrect, the DOI is not indexed, or the data resides under a different block number.

## 17. execute_sql

## Compacted Result

**DOI:** `10.1007/s10765-019-2558-5`

**Task 1 – Does `block_properties` have data for this DOI?**
Yes — 2 rows returned.

**Task 2 – `block_number` values used:**

| block_number | block_type | prop_name |
|---|---|---|
| 1 | PureOrMixtureData | Molar heat capacity at constant pressure, J/K/mol |
| 2 | PureOrMixtureData | Molar heat capacity at constant pressure, J/K/mol |

**Note:** The only property recorded for this DOI is **molar heat capacity at constant pressure** — no activity coefficient data is present in `block_properties` for this DOI.

## 18. execute_sql

## Compacted Result

Three activity-related properties were found in DOIs containing lithium chloride:

| prop_name | prop_num_id | prop_group |
|---|---|---|
| Mean ionic activity coefficient | 56 | ActivityFugacityOsmoticProp |
| Osmotic coefficient | 38 | ActivityFugacityOsmoticProp |
| (Relative) activity | 33 | ActivityFugacityOsmoticProp |

- **3 distinct properties** returned; no truncation.
- No fugacity properties found for LiCl DOIs.

## 19. execute_sql

## Compacted Result

### Query Summary
The query searched for activity-related properties (prop_num_ids `56`, `38`, `33`) in blocks containing **lithium chloride**.

### Result: **Zero rows returned**

No blocks were found matching all three criteria:
1. Compound name = `'lithium chloride'`
2. Property num IDs in (`56`, `38`, `33`) — corresponding to mean ionic activity coefficient, osmotic coefficient, and relative activity
3. Both compound and property present in the same block

### Implications for Each Task

| Task | Outcome |
|------|---------|
| **1. List blocks with mean ionic activity coefficient for LiCl** | None found |
| **2. Get min/max values and number of data points** | No data to report |
| **3. Note osmotic coefficient and relative activity data** | None found either |

### Possible Reasons for Empty Result
- The compound may be stored under a different name variant (e.g., `"LiCl"`, `"Lithium chloride"` with different casing, or an alternate spelling).
- The relevant property IDs (`56`, `38`, `33`) may not be the correct `prop_num_id` values for these activity properties in this database.
- Activity coefficient data for aqueous LiCl may simply not be present in the ThermoML corpus.

## 20. execute_sql

## Compacted Result

### Query: Blocks with activity-related properties (prop_num_id ∈ {56, 38, 33}) in DOIs that contain lithium chloride

**Result: 0 rows returned.**

No blocks with activity-coefficient-related properties (prop_num_ids 56, 38, or 33) were found in any DOI that lists lithium chloride as a compound.

### Implications for the two tasks

1. **List all blocks with activity properties in LiCl DOIs** — None exist; the query returned zero rows.
2. **Check if these are different blocks than the ones containing LiCl** — Not applicable; there are no activity-property blocks to compare.

## 21. execute_sql

## DOIs Containing Lithium Chloride

30 distinct DOIs returned (query limit: 30; result was **not truncated** by the limit, meaning there are exactly 30 or fewer matching DOIs).

| # | DOI |
|---|-----|
| 1 | 10.1007/s10765-019-2558-5 |
| 2 | 10.1016/j.fluid.2004.10.018 |
| 3 | 10.1016/j.fluid.2005.07.002 |
| 4 | 10.1016/j.fluid.2006.02.012 |
| 5 | 10.1016/j.fluid.2006.10.018 |
| 6 | 10.1016/j.fluid.2011.09.016 |
| 7 | 10.1016/j.fluid.2013.12.017 |
| 8 | 10.1016/j.fluid.2014.01.037 |
| 9 | 10.1016/j.fluid.2014.08.026 |
| 10 | 10.1016/j.fluid.2015.02.009 |
| 11 | 10.1016/j.fluid.2015.08.005 |
| 12 | 10.1016/j.fluid.2015.09.005 |
| 13 | 10.1016/j.fluid.2015.11.018 |
| 14 | 10.1016/j.fluid.2016.12.013 |
| 15 | 10.1016/j.fluid.2017.12.034 |
| 16 | 10.1016/j.fluid.2019.04.018 |
| 17 | 10.1016/j.jct.2003.12.002 |
| 18 | 10.1016/j.jct.2004.01.004 |
| 19 | 10.1016/j.jct.2004.09.015 |
| 20 | 10.1016/j.jct.2006.06.014 |
| 21 | 10.1016/j.jct.2007.05.002 |
| 22 | 10.1016/j.jct.2008.12.003 |
| 23 | 10.1016/j.jct.2008.12.022 |
| 24 | 10.1016/j.jct.2009.03.005 |
| 25 | 10.1016/j.jct.2011.03.002 |
| 26 | 10.1016/j.jct.2013.03.009 |
| 27 | 10.1016/j.jct.2013.07.024 |
| 28 | 10.1016/j.jct.2013.08.018 |
| 29 | 10.1016/j.jct.2013.10.028 |
| 30 | 10.1016/j.jct.2016.07.003 |

**Note:** The query matched on `comp_name = 'lithium chloride'` only. There may be additional DOIs if the compound is stored under variant names or identifiers. The LIMIT 30 was applied but did not truncate the result.

## 22. execute_sql

## Compacted Result

### Task 1: Activity coefficient data in LiCl DOIs

**No activity coefficient data found.** The query returned **0 rows** when searching for activity-related properties (prop_num_ids 56, 38, 33) across all 30 DOIs known to contain LiCl.

### Task 2: Blocks and value ranges

Not applicable — no matching records exist.

## 23. execute_sql

## Compacted Result

### Task 1: All distinct properties across the four LiCl-related DOIs

| prop_name | prop_num_id | prop_group | DOI(s) |
|---|---|---|---|
| Refractive index (Na D-line) | 7 | RefractionSurfaceTensionSoundSpeed | …fluid.2015.02.009 |
| Mass density, kg/m³ | 1 | VolumetricProp | …fluid.2015.02.009 |
| Viscosity, Pa·s | 4 | TransportProp | …fluid.2015.02.009 |
| Electrical conductivity, S/m | 18 | TransportProp | …fluid.2015.02.009 |
| Mole fraction | 2 | CompositionAtPhaseEquilibrium | …fluid.2017.12.034 |
| Molality, mol/kg | 53, 21 | CompositionAtPhaseEquilibrium | …jct.2006.06.014 |
| Molar enthalpy of solution, kJ/mol | 15 | ExcessPartialApparentEnergyProp | …jct.2013.03.009 |
| Molar enthalpy of reaction, kJ/mol | 36 | ReactionStateChangeProp | …jct.2013.03.009 |

**Total rows returned:** 68 (not truncated). Many rows are repeated "Mole fraction" or "Molality" entries across different blocks within the same DOI.

### Task 2: Are any properties activity-related?

**No.** None of the properties in these four DOIs is an activity coefficient (or any other activity-related property such as "Activity of solvent," "Mean activity coefficient," "Osmotic coefficient," etc.). The property groups present are:

- VolumetricProp
- TransportProp
- RefractionSurfaceTensionSoundSpeed
- CompositionAtPhaseEquilibrium
- ExcessPartialApparentEnergyProp
- ReactionStateChangeProp

No activity coefficient data appears in this sample of LiCl DOIs.

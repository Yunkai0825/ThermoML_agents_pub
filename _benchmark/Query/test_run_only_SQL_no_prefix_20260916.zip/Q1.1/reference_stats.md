# Q1.1 — Reference Statistics

| Variant | Model | Compactor Model | Status | API turns | Tool calls | Elapsed (s) |
|---|---|---|---:|---:|---:|---:|
| Flat / parsed-card SQL / raw numeric IDs | claude-opus-4-6 | claude-opus-4-6 | OK | 22 | 21 | 400.9 |

## Token usage

| Role | Calls | Input tokens | Output tokens | Cache-create | Cache-read |
|---|---:|---:|---:|---:|---:|
| Answering agent | 22 | 287544 | 7373 | 0 | 0 |
| Result compactor(s) | 21 | 95877 | 9341 | 0 | 0 |

## Turn budget

- API effort: high
- Soft escalation begins: turn 20
- Configured strikes: 3
- Hard final turn: 22
- Strikes issued: 3
- Forced final chance reached: True
- Fresh final context characters: 44915
- Fresh final context SHA-256: 74d557bf67894886ad6199189049d1ff865d656150353afd7e7e1e02aaa27cfa
- Tool request on final chance: False

# Q1.5 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Ethanol Compound Registry Entry

| Field | Value |
|---|---|
| **comp_num_id** | **2** |
| **comp_id** | ethanol |
| **inchi_key** | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |
| **common_name** | ethanol |
| **formula** | C2H6O |

Exactly 1 row returned; no truncation.

## 2. execute_sql

## Viscosity Property IDs in `idx.prop_registry`

| prop_num_id | prop_id | prop_name | prop_group |
|---|---|---|---|
| **4** | viscosity_pa_s | Viscosity, Pa·s | TransportProp |
| **40** | kinematic_viscosity_m2_s | Kinematic viscosity, m²/s | TransportProp |

- **2 rows returned; no truncation.**
- The dynamic (absolute) viscosity property is **prop_num_id = 4**; kinematic viscosity is **prop_num_id = 40**.

## 3. execute_sql

## Compacted SQL Result

### Query
Find all pure ethanol viscosity data blocks (prop_num_id IN ('4','40'), comp_num_id = '2', pure system) with measurement methods and value ranges.

### Result
**Zero rows returned.** The query produced no results.

### Implications for the tasks

| Task | Status |
|---|---|
| List DOIs, block numbers, measurement methods, viscosity ranges, and phases for pure ethanol viscosity data | **No data found** — no blocks matched the filter criteria |
| Identify which measurement methods have been used | **No methods identified** — no matching blocks exist |

### Possible reasons for empty result
- The compound numeric ID `'2'` may not correspond to ethanol in this database, or ethanol viscosity data may be indexed under different `prop_num_id` values (i.e., not `'4'` or `'40'`).
- A broader search on compound identity (e.g., by InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N` or name `'ethanol'`) and/or a wider property filter may be needed.

## 4. execute_sql

## Compacted Result

### Query: Check block_index for ethanol (comp_num_id=2) + viscosity (prop_num_id=4) in pure systems

**Result: 0 rows returned.** No matching blocks were found.

### Task 1 — Do ethanol viscosity blocks exist in block_index?
No blocks matched the filter `system_type = 'pure' AND n_components = 1 AND comp_num_ids LIKE '%2%' AND prop_num_ids LIKE '%4%'`.

### Task 2 — Format of comp_num_ids and prop_num_ids columns
Cannot be determined from this query because no rows were returned. A separate query returning actual rows is needed to inspect the stored format (e.g., whether values are comma-separated lists, JSON arrays, or bare integers).

### Possible reasons for zero results
- The `LIKE '%2%'` pattern on `comp_num_ids` is fragile: it would match any ID containing the digit "2" (e.g., 12, 20, 21, 22, 23, …, 42, 52, …, 102, 200, …) yet still returned nothing, suggesting ethanol's `comp_num_id` may not be `2`, or the column format requires a different matching approach.
- Similarly, `prop_num_ids LIKE '%4%'` may not correctly target viscosity if `prop_num_id` for viscosity is not `4`, or the column uses a structured format (e.g., JSON or prefixed IDs).
- **Recommended next steps:** (a) verify ethanol's `comp_num_id` via `compound_registry`, (b) verify viscosity's `prop_num_id` via `prop_registry`, and (c) inspect the actual format of `comp_num_ids`/`prop_num_ids` from a sample of `block_index` rows.

## 5. execute_sql

## Result: comp_num_id = '2' in block_compounds

**Zero rows returned.** No records in `idx.block_compounds` have `comp_num_id = '2'`.

This means `comp_num_id='2'` does **not** map to ethanol (or any compound) in `block_compounds`. The identifier for ethanol must be looked up via another value (e.g., by searching `comp_name`, `inchi_key`, or consulting `idx.compound_registry`).

## 6. execute_sql

## Compacted Result

### Task 1: Ethanol `comp_num_id` format
Ethanol is consistently stored with **`comp_num_id = '2'`** and **`comp_id = 'ethanol'`** across all sampled rows.

### Task 2: Sample DOIs and block numbers for ethanol

| doi | block_number |
|---|---|
| 10.1007/s10765-005-8089-2 | 1, 3 |
| 10.1007/s10765-008-0410-4 | 2 |
| 10.1007/s10765-011-0987-x | 1 |
| 10.1007/s10765-011-1086-8 | 7, 13, 17 |
| 10.1007/s10765-014-1740-z | 3 |
| 10.1007/s10765-017-2283-x | 3, 4 |

10 rows returned (query limit 10); not truncated within that limit but more ethanol rows likely exist in the table.

## 7. execute_sql

## Viscosity `prop_num_id` Format in `block_properties`

All 10 sampled rows show a single, consistent format:

| Field | Value |
|---|---|
| **prop_num_id** | `4` |
| **prop_name** | `Viscosity, Pa*s` |
| **prop_id** | `viscosity_pa_s` |

No other viscosity property variants appeared in this sample. The `prop_num_id` is stored as the plain string `"4"` (no prefix).

## 8. execute_sql

## Compacted Result

### Task: Find viscosity data blocks associated with ethanol DOIs

**The query returned zero rows.**

No viscosity property entries (prop_num_id = '4') were found for DOIs associated with ethanol (comp_num_id = '2').

### Notes
- The filter used `prop_num_id = '4'` and `comp_num_id = '2'`; these assumed numeric IDs may not correspond to "viscosity" and "ethanol" respectively in this database. The answering agent should verify the correct `prop_num_id` for viscosity (e.g., by checking `idx.prop_registry` for property names containing "viscosity") and the correct `comp_num_id` for ethanol (e.g., by checking `idx.compound_registry` for "ethanol" or its InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`).

## 9. execute_sql

## Compacted Result

**Task:** Verify the join between `block_compounds` and `block_properties` works for ethanol, and see what `prop_num_id` values appear.

**Result:** The join works successfully. Ethanol has `comp_num_id = '2'`. Five sample rows returned:

| comp_num_id | prop_num_id |
|-------------|-------------|
| 2           | 4           |
| 2           | 4           |
| 2           | 1           |
| 2           | 15          |
| 2           | 42          |

**Distinct `prop_num_id` values in this sample:** 1, 4, 15, 42

- Query was `LIMIT 5`; more property types likely exist for ethanol beyond these.
- No errors or truncation issues.

## 10. execute_sql

## Compacted SQL Result

### Query Purpose
Find pure ethanol viscosity data blocks with value ranges (prop_num_id = '4', single-component ethanol systems).

### Result
**Zero rows returned.** No blocks matched the filter criteria.

### Task Status

| Task | Outcome |
|------|---------|
| List all pure ethanol viscosity blocks with DOI, value ranges, and phase | **No data found** — 0 rows |
| Determine how many distinct sources report pure ethanol viscosity | **0 distinct sources** |

### Notes
- The query filtered on `comp_name = 'ethanol'`, `prop_num_id = '4'` (viscosity), and `n_components = 1` (pure substance).
- The empty result may indicate that: (a) `prop_num_id = '4'` does not correspond to viscosity in this database, (b) ethanol viscosity data exists under a different compound name or spelling, (c) ethanol viscosity blocks are classified with `n_components ≠ 1`, or (d) no pure ethanol viscosity data is present in the dataset.
- A follow-up query checking the `prop_registry` for viscosity-related `prop_num_id` values and/or the `compound_registry` for ethanol identifiers would help diagnose the empty result.

## 11. execute_sql

## Compacted Result

### Query Summary
Searched for all blocks containing **ethanol** with **prop_num_id = '4'** (viscosity) across any system type or number of components.

### Result: **Zero rows returned**

No ethanol viscosity blocks were found with this query. This means either:

1. **prop_num_id = '4'** does not correspond to viscosity in this database, or
2. Ethanol viscosity data is indexed under a different compound name (e.g., case variation), or
3. No ethanol viscosity data exists in the dataset.

### Implications for Tasks

| Task | Finding |
|------|---------|
| List ethanol viscosity blocks with system_type and n_components | **No blocks found** — cannot list any |
| Identify if pure ethanol viscosity data exists or only mixture data | **Indeterminate** — zero rows; further investigation needed (e.g., verify the correct `prop_num_id` for viscosity via `prop_registry`, or check compound name variants) |

## 12. execute_sql

## Compacted Result

### Task: Confirm whether the 2-table join between `block_compounds` and `block_properties` returns rows for ethanol viscosity

**Result: 0 rows returned.**

The query joining `idx.block_compounds` and `idx.block_properties` on `(doi, block_number)` with filters `comp_name = 'ethanol'` and `prop_num_id = '4'` produced **no matches**.

This means the 2-table join also fails — the problem is not introduced by a 3rd table. Either:

- `comp_name = 'ethanol'` does not match the stored name (e.g., it may be stored as `'Ethanol'` or another variant), or
- `prop_num_id = '4'` is not the correct identifier for viscosity, or
- There are no blocks where ethanol and viscosity co-occur under these exact filter values.

**Query details:**
```sql
WHERE bc.comp_name = 'ethanol' AND bp.prop_num_id = '4'
```
Elapsed: 0.013 s | No truncation.

## 13. execute_sql

## Compacted Result

**Query:** Properties for blocks containing `comp_num_id = '2'`

### Result: **Zero rows returned**

No blocks in `idx.block_compounds` have `comp_num_id = '2'`, meaning either:

1. Ethanol is stored under a different `comp_num_id` value, or
2. The numeric ID `2` does not correspond to ethanol in this database.

**Both SQL tasks are unresolved:**

| Task | Outcome |
|---|---|
| See what `prop_num_id`s appear for ethanol blocks | No data — no blocks matched `comp_num_id = '2'` |
| Verify `comp_name` stored for `comp_num_id = 2` | No data — ID not found in `block_compounds` |

**Next step suggestion:** Look up ethanol's actual `comp_num_id` via `idx.compound_registry` (e.g., searching by `common_name` or `inchi_key`).

## 14. execute_sql

## Compacted Result

### Task 1: Finding ethanol blocks via `thermoml_raw_id`

The filter `thermoml_raw_id(bc.comp_num_id) = '2'` successfully returns ethanol blocks. All 10 returned rows have `comp_name = "ethanol"`.

### Task 2: Actual stored `comp_num_id` format

The stored value is simply **`2`** (no visible prefix in these rows). The `thermoml_raw_id()` function strips any semantic prefix, but here the raw value already equals `"2"`.

### Sample rows (10 returned, not truncated)

| doi | block_number | comp_num_id | comp_name |
|---|---|---|---|
| 10.1007/s10765-005-8089-2 | 1 | 2 | ethanol |
| 10.1007/s10765-005-8089-2 | 3 | 2 | ethanol |
| 10.1007/s10765-008-0410-4 | 2 | 2 | ethanol |
| 10.1007/s10765-011-0987-x | 1 | 2 | ethanol |
| 10.1007/s10765-011-1086-8 | 7 | 2 | ethanol |
| 10.1007/s10765-011-1086-8 | 13 | 2 | ethanol |
| 10.1007/s10765-011-1086-8 | 17 | 2 | ethanol |
| 10.1007/s10765-014-1740-z | 3 | 2 | ethanol |
| 10.1007/s10765-017-2283-x | 3 | 2 | ethanol |
| 10.1007/s10765-017-2283-x | 4 | 2 | ethanol |

**Note:** Only 10 rows were requested (`LIMIT 10`); more ethanol blocks likely exist. These results include multi-component blocks (ethanol as one component), not only pure-ethanol blocks. Further filtering on `system_type` or `n_components` in `block_index` would be needed to isolate pure-ethanol viscosity data.

## 15. execute_sql

## Compacted Result

**Task:** Confirm viscosity blocks exist with `thermoml_raw_id(prop_num_id) = '4'` filtering.

**Confirmed:** Viscosity blocks exist. The filter works correctly, returning rows with `prop_num_id = '4'` and `prop_name = "Viscosity, Pa*s"`.

**Sample rows (5 returned, not truncated):**

| doi | block_number | prop_num_id | prop_name |
|---|---|---|---|
| 10.1007/s10765-005-5567-5 | 2 | 4 | Viscosity, Pa*s |
| 10.1007/s10765-005-5567-5 | 4 | 4 | Viscosity, Pa*s |
| 10.1007/s10765-005-5572-8 | 2 | 4 | Viscosity, Pa*s |
| 10.1007/s10765-005-5572-8 | 5 | 4 | Viscosity, Pa*s |
| 10.1007/s10765-005-5572-8 | 8 | 4 | Viscosity, Pa*s |

These are only the first 5 rows (query used `LIMIT 5`); more viscosity blocks likely exist in the database.

## 16. execute_sql

## Compacted Result: Pure Ethanol Viscosity Blocks

### Task 1 — All pure ethanol viscosity blocks (50 rows returned, LIMIT 50 — may be truncated)

All blocks report **Viscosity, Pa·s** in the **liquid** phase for a **unary** (single-component) system with **n_components = 1**.

| DOI | Block | min (Pa·s) | max (Pa·s) | mean (Pa·s) | n_values | n_datapoints |
|-----|-------|-----------|-----------|-------------|----------|-------------|
| 10.1007/s10765-005-8089-2 | 1 | 0.00051 | 0.001955 | 0.001049 | 23 | 23 |
| 10.1016/j.fluid.2005.05.012 | 3 | 0.000982 | 0.00117 | 0.001077 | 3 | 3 |
| 10.1016/j.fluid.2005.07.010 | 9 | 0.001082 | 0.001082 | 0.001082 | 1 | 1 |
| 10.1016/j.fluid.2006.01.008 | 11 | 0.001077 | 0.001077 | 0.001077 | 1 | 1 |
| 10.1016/j.fluid.2006.01.030 | 1 | 0.00051 | 0.001955 | 0.001076 | 20 | 20 |
| 10.1016/j.fluid.2006.01.030 | 2 | 0.00059 | 0.001194 | 0.00087 | 3 | 3 |
| 10.1016/j.fluid.2006.02.023 | 11 | 0.000968 | 0.000968 | 0.000968 | 1 | 1 |
| 10.1016/j.fluid.2007.03.021 | 3 | 0.001082 | 0.001082 | 0.001082 | 1 | 1 |
| 10.1016/j.fluid.2007.08.006 | 2 | 0.000617 | 0.000695 | 0.000657 | 3 | 3 |
| 10.1016/j.fluid.2016.08.022 | 6 | 0.000585 | 0.001161 | 0.000853 | 3 | 3 |
| 10.1016/j.jct.2005.04.019 | 4 | 0.001093 | 0.001093 | 0.001093 | 1 | 1 |
| 10.1016/j.jct.2005.06.011 | 26 | 0.000895 | 0.001083 | 0.000988 | 3 | 3 |
| 10.1016/j.jct.2005.07.008 | 3 | 0.001105 | 0.001105 | 0.001105 | 1 | 1 |
| 10.1016/j.jct.2005.10.022 | 2 | 0.000889 | 0.001073 | 0.000978 | 3 | 3 |
| 10.1016/j.jct.2005.12.010 | 1 | 0.000987 | 0.001187 | 0.001085 | 3 | 3 |
| 10.1016/j.jct.2006.03.010 | 7 | 0.000902 | 0.001084 | 0.000993 | 2 | 2 |
| 10.1016/j.jct.2006.03.018 | 6 | 0.000889 | 0.001073 | 0.000978 | 3 | 3 |
| 10.1016/j.jct.2006.06.008 | 13 | 0.000987 | 0.001187 | 0.001085 | 3 | 3 |
| 10.1016/j.jct.2006.10.016 | 3 | 0.000749 | 0.001086 | 0.000899 | 5 | 5 |
| 10.1016/j.jct.2007.05.004 | 3 | 0.000987 | 0.001187 | 0.001085 | 3 | 3 |
| 10.1016/j.jct.2008.03.013 | 5 | 0.000641 | 0.001082 | 0.00085 | 3 | 3 |
| 10.1016/j.jct.2008.04.006 | 2 | 0.000641 | 0.001082 | 0.00085 | 3 | 3 |
| 10.1016/j.jct.2009.06.023 | 1 | 0.000587 | 0.001418 | 0.00093 | 11 | 11 |
| 10.1016/j.jct.2010.03.022 | 2 | 0.000488 | 0.001832 | 0.001035 | 23 | 23 |
| 10.1016/j.jct.2012.02.027 | 11 | 0.001087 | 0.001087 | 0.001087 | 1 | 1 |
| 10.1016/j.jct.2012.08.024 | 4 | 0.000648 | 0.001087 | 0.000847 | 7 | 7 |
| 10.1016/j.jct.2012.10.008 | 6 | 0.000836 | 0.001218 | 0.001023 | 5 | 5 |
| 10.1016/j.jct.2012.10.008 | 7 | 0.000907 | 0.00101 | 0.000959 | 2 | 2 |
| 10.1016/j.jct.2013.09.006 | 2 | 0.00087 | 0.00109 | 0.00097 | 3 | 3 |
| 10.1016/j.jct.2013.09.044 | 6 | 0.001187 | 0.001187 | 0.001187 | 1 | 1 |
| 10.1016/j.jct.2013.11.026 | 17 | 0.001125 | 0.001125 | 0.001125 | 1 | 1 |
| 10.1016/j.jct.2015.04.027 | 4 | 0.000829 | 0.001186 | 0.000998 | 5 | 5 |
| 10.1016/j.jct.2015.08.036 | 2 | 0.000764 | 0.001096 | 0.000922 | 5 | 5 |
| 10.1016/j.jct.2016.12.036 | 7 | 0.001093 | 0.001093 | 0.001093 | 1 | 1 |
| 10.1016/j.jct.2017.07.022 | 2 | 0.000747 | 0.001286 | 0.000993 | 7 | 7 |
| 10.1016/j.jct.2018.02.022 | 3 | 0.000904 | 0.001202 | 0.001047 | 4 | 4 |
| 10.1016/j.jct.2019.02.019 | 6 | 0.00069 | 0.00117 | 0.00091 | 4 | 4 |
| 10.1016/j.jct.2019.04.023 | 5 | 0.000697 | 0.001177 | 0.000912 | 7 | 7 |
| 10.1021/acs.jced.5b00152 | 10 | 0.000587 | 0.001296 | 0.000873 | 27 | 27 |
| 10.1021/acs.jced.5b00162 | 8 | 0.001103 | 0.001103 | 0.001103 | 1 | 1 |
| 10.1021/acs.jced.5b00259 | 6 | 0.000698 | 0.001177 | 0.000914 | 7 | 7 |
| 10.1021/acs.jced.5b00365 | 4 | 0.000698 | 0.001177 | 0.000914 | 7 | 7 |
| 10.1021/acs.jced.5b01000 | 12 | 0.000824 | 0.001444 | 0.001116 | 3 | 3 |
| 10.1021/acs.jced.6b00096 | 2 | 0.000752 | 0.001084 | 0.000918 | 2 | 2 |
| 10.1021/acs.jced.6b00563 | 3 | 0.000758 | 0.001083 | 0.000914 | 3 | 3 |
| 10.1021/acs.jced.7b00267 | 2 | 0.000594 | 0.001194 | 0.000855 | 9 | 9 |
| 10.1021/acs.jced.7b00299 | 2 | 0.001091 | 0.001159 | 0.001125 | 2 | 2 |
| 10.1021/acs.jced.7b00321 | 10 | 0.00069 | 0.00117 | 0.00091 | 4 | 4 |
| 10.1021/acs.jced.7b00944 | 6 | 0.00104 | 0.00104 | 0.00104 | 1 | 1 |
| 10.1021/acs.jced.8b00086 | 17 | 0.001056 | 0.001056 | 0.001056 | 1 | 1 |

### Task 2 — Distinct source count

**48 distinct DOIs** appear in these 50 rows (10.1016/j.fluid.2006.01.030 and 10.1016/j.jct.2012.10.008 each contribute 2 blocks).

> **Note:** The query was capped at LIMIT 50; additional blocks/sources may exist beyond this limit. The measurement method information was not included in this query — a follow-up query on `idx.block_measurements` would be needed to identify the specific methods used per block.

## 17. execute_sql

## Pure Ethanol Viscosity: Measurement Methods & Temperature Ranges

**114 rows returned (not truncated).** Results cover pure (1-component) ethanol viscosity blocks.

---

### 1. Measurement Methods Identified

| Method Name | Type | # Blocks |
|---|---|---|
| **Capillary tube (Ostwald; Ubbelohde) method** | standard | **38** |
| **Falling or rolling sphere viscometry** | standard | **27** |
| **Concentric cylinders viscometry** | standard | **3** |
| CAPTUB::UFactor:2 | custom | 8 |
| CAPTUB::UFactor:4 | custom | 7 |
| CAPTUB::UFactor:8 | custom | 6 |
| CAPTUB:UFactor:2 | custom | 5 |
| CAPTUB:UFactor:4 | custom | 9 |
| CAPTUB:UFactor:8 | custom | 2 |
| CAPTUB::UFactor:6 | custom | 1 |
| CAPTUB::UFactor:16 | custom | 1 |
| CONCYL::UFactor:4 | custom | 1 |
| CONCYL:UFactor:8 | custom | 2 |
| SPHERE::UFactor:4 | custom | 3 |
| SPHERE:UFactor:4 | custom | 1 |
| Schott-Gerate viscometer model AVS 350 | custom | 1 |

> **Note:** "CAPTUB" variants are capillary-tube instruments with specific uncertainty factors; "SPHERE" variants are falling/rolling-sphere instruments; "CONCYL" variants are concentric-cylinder instruments. The three **standard** method names are the most common.

---

### 2. Per-Method Details: DOIs, Temperature Ranges & Viscosity Values

#### Capillary tube (Ostwald; Ubbelohde) — 38 blocks

| DOI | T range (K) | η min (Pa·s) | η max (Pa·s) | η mean | n |
|---|---|---|---|---|---|
| 10.1016/j.fluid.2006.01.008 | 298.15 | 0.001077 | 0.001077 | 0.001077 | 1 |
| 10.1016/j.fluid.2007.03.021 | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1016/j.fluid.2016.08.022 | 293.15–333.15 | 0.000585 | 0.001161 | 0.000853 | 3 |
| 10.1016/j.jct.2005.04.019 | 298.15 | 0.001093 | 0.001093 | 0.001093 | 1 |
| 10.1016/j.jct.2012.02.027 | 298.15 | 0.001087 | 0.001087 | 0.001087 | 1 |
| 10.1016/j.jct.2012.08.024 | 298.15–328.15 | 0.000648 | 0.001087 | 0.000847 | 7 |
| 10.1016/j.jct.2013.09.006 | 298.15–308.15 | 0.00087 | 0.00109 | 0.00097 | 3 |
| 10.1016/j.jct.2015.08.036 | 298.15–318.15 | 0.000764 | 0.001096 | 0.000922 | 5 |
| 10.1016/j.jct.2016.12.036 | 298.15 | 0.001093 | 0.001093 | 0.001093 | 1 |
| 10.1016/j.jct.2019.02.019 | 293.15–323.15 | 0.00069 | 0.00117 | 0.00091 | 4 |
| 10.1021/acs.jced.5b00152 | 298.15–333.28 | 0.000587 | 0.001296 | 0.000873 | 27 |
| 10.1021/acs.jced.5b00162 | 298.15 | 0.001103 | 0.001103 | 0.001103 | 1 |
| 10.1021/acs.jced.5b01000 | 283.15–313.15 | 0.000824 | 0.001444 | 0.001116 | 3 |
| 10.1021/acs.jced.7b00299 | 293.15–298.15 | 0.001091 | 0.001159 | 0.001125 | 2 |
| 10.1021/acs.jced.7b00321 | 293.15–323.15 | 0.00069 | 0.00117 | 0.00091 | 4 |
| 10.1021/acs.jced.8b01012 | 288.15–318.15 | 0.000787 | 0.001332 | 0.001039 | 4 |
| 10.1021/je034203p | 298.15 | 0.001112 | 0.001112 | 0.001112 | 1 |
| 10.1021/je050010l | 288.15–308.15 | 0.000905 | 0.001309 | 0.001099 | 3 |
| 10.1021/je050367p | 288.15–308.15 | 0.000905 | 0.001309 | 0.001099 | 6 |
| 10.1021/je050402s | 288.15–318.15 | 0.000771 | 0.001337 | 0.001034 | 4 |
| 10.1021/je1000796 | 278.15–313.15 | 0.000828 | 0.001629 | 0.001185 | 8 |
| 10.1021/je101173w | 293.15–333.15 | 0.000581 | 0.001211 | 0.000862 | 5 |
| 10.1021/je1013476 | 288.15–313.15 | 0.000824 | 0.001313 | 0.001099 | 5 |
| 10.1021/je200922s | 293.15–323.15 | 0.000704 | 0.001189 | 0.000931 | 7 |
| 10.1021/je201116t | 298.15–313.15 | 0.000839 | 0.001091 | 0.000961 | 4 |
| 10.1021/je201152j | 298.15 | 0.001091 | 0.001091 | 0.001091 | 1 |
| 10.1021/je300557g | 293.15–323.15 | 0.000694 | 0.00118 | 0.000919 | 4 |
| 10.1021/je301095j | 283.15–313.15 | 0.000831 | 0.001459 | 0.001119 | 5 |
| 10.1021/je400630f | 283.15–313.15 | 0.000842 | 0.001475 | 0.001101 | 6 |
| 10.1021/je400968v | 293.15–333.15 | 0.000564 | 0.001179 | 0.000839 | 5 |
| 10.1021/je700318e | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1021/je700618y | 298.15 | 0.001076 | 0.001076 | 0.001076 | 1 |
| 10.1021/je700710d | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1021/je800633a | 303.15 | 0.000994 | 0.000994 | 0.000994 | 1 |
| 10.1021/je800899w | 298.15 | 0.001054 | 0.001054 | 0.001054 | 1 |
| 10.1021/je900998f | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1016/j.fluid.2006.01.030 | 293.15–333.15 | 0.00059 | 0.001194 | 0.00087 | 3 |
| 10.1016/j.fluid.2007.08.006 | 303.15–313.15 | 0.000617 | 0.000695 | 0.000657 | 3 |

#### Falling or rolling sphere viscometry — 27 blocks

| DOI | T range (K) | η min (Pa·s) | η max (Pa·s) | η mean | n |
|---|---|---|---|---|---|
| 10.1007/s10765-005-8089-2 | 293.15–353.15 | 0.00051 | 0.001955 | 0.001049 | 23 |
| 10.1016/j.fluid.2006.01.030 | 293.15–353.15 | 0.00051 | 0.001955 | 0.001076 | 20 |
| 10.1016/j.jct.2009.06.023 | 283.15–333.15 | 0.000587 | 0.001418 | 0.00093 | 11 |
| 10.1016/j.jct.2012.10.008 (blk 6) | 293.15–313.15 | 0.000836 | 0.001218 | 0.001023 | 5 |
| 10.1016/j.jct.2012.10.008 (blk 7) | 303.15–308.15 | 0.000907 | 0.00101 | 0.000959 | 2 |
| 10.1016/j.jct.2013.09.044 | 298.2 | 0.001187 | 0.001187 | 0.001187 | 1 |
| 10.1016/j.jct.2013.11.026 | 298.15 | 0.001125 | 0.001125 | 0.001125 | 1 |
| 10.1016/j.jct.2015.04.027 | 293.15–313.15 | 0.000829 | 0.001186 | 0.000998 | 5 |
| 10.1016/j.jct.2017.07.022 | 288.15–318.15 | 0.000747 | 0.001286 | 0.000993 | 7 |
| 10.1016/j.jct.2019.04.023 | 293.15–323.15 | 0.000697 | 0.001177 | 0.000912 | 7 |
| 10.1021/acs.jced.5b00365 | 293.15–323.15 | 0.000698 | 0.001177 | 0.000914 | 7 |
| 10.1021/acs.jced.6b00096 | 298.15–318.15 | 0.000752 | 0.001084 | 0.000918 | 2 |
| 10.1021/acs.jced.6b00563 | 298.15–318.15 | 0.000758 | 0.001083 | 0.000914 | 3 |
| 10.1021/acs.jced.7b00267 | 293.15–333.15 | 0.000594 | 0.001194 | 0.000855 | 9 |
| 10.1021/acs.jced.7b00944 | 298.2 | 0.00104 | 0.00104 | 0.00104 | 1 |
| 10.1021/acs.jced.8b00086 | 298.2 | 0.001056 | 0.001056 | 0.001056 | 1 |
| 10.1021/acs.jced.8b00939 | 298.15 | 0.00113 | 0.00113 | 0.00113 | 1 |
| 10.1021/acs.jced.8b00965 | 293.15–333.15 | 0.000593 | 0.001195 | 0.000862 | 5 |
| 10.1021/je0500633 | 293.15–313.15 | 0.00081 | 0.00116 | 0.000979 | 3 |
| 10.1021/je0501639 | 298.15–318.15 | 0.000756 | 0.001085 | 0.000916 | 3 |
| 10.1021/je200707b | 293.15–313.15 | 0.000842 | 0.001241 | 0.001032 | 5 |
| 10.1021/je201009c | 293.15–323.15 | 0.000698 | 0.001183 | 0.000921 | 4 |
| 10.1021/je401124t | 293.15–323.15 | 0.000704 | 0.001192 | 0.000925 | 7 |
| 10.1021/je500380x | 298.15 | 0.001083 | 0.001083 | 0.001083 | 1 |
| 10.1021/je500594z | 278.15–338.15 | 0.00056 | 0.00159 | 0.001 | 4 |
| 10.1021/je501133u | 293.15–328.15 | 0.00063 | 0.00115 | 0.00087 | 8 |

#### Concentric cylinders viscometry — 3 blocks (standard) + 3 custom

| DOI | T range (K) | η min | η max | η mean | n | Type |
|---|---|---|---|---|---|---|
| 10.1016/j.jct.2018.02.022 | 293.15–308.15 | 0.000904 | 0.001202 | 0.001047 | 4 | standard |
| 10.1021/acs.jced.8b00793 | 293.15–323.15 | 0.00071 | 0.00123 | 0.000953 | 4 | standard |
| 10.1021/je200600p | 293.15–333.15 | 0.000576 | 0.001141 | 0.00082 | 9 | standard |
| 10.1021/je100848r | 293.15–323.15 | 0.000708

## 18. execute_sql

## Viscosity of Pure Ethanol by Measurement Method

**Query:** Pure ethanol (comp\_num\_id 2), viscosity (prop\_num\_id 4), single-component systems only.

**16 methods returned; 0 rows omitted.**

| Method | Blocks | Avg Viscosity (Pa·s) | Min Value | Max Value |
|---|--:|--:|--:|--:|
| Capillary tube (Ostwald; Ubbelohde) | 38 | 0.001012 | 0.000564 | 0.001629 |
| Falling or rolling sphere viscometry | 26 | 0.000987 | 0.000510 | 0.001955 |
| CAPTUB:UFactor:4 | 9 | 0.001021 | 0.000488 | 0.001832 |
| CAPTUB::UFactor:2 | 8 | 0.000986 | 0.000597 | 0.001310 |
| CAPTUB::UFactor:4 | 7 | 0.000939 | 0.000581 | 0.001211 |
| CAPTUB::UFactor:8 | 6 | 0.000914 | 0.000512 | 0.001975 |
| CAPTUB:UFactor:2 | 5 | 0.000982 | 0.000610 | 0.001337 |
| SPHERE::UFactor:4 | 3 | 0.000973 | 0.000767 | 0.001194 |
| Concentric cylinders viscometry | 3 | 0.000940 | 0.000576 | 0.001230 |
| CONCYL:UFactor:8 | 2 | 0.001087 | 0.000774 | 0.001296 |
| CAPTUB:UFactor:8 | 2 | 0.001027 | 0.000968 | 0.001187 |
| Schott-Gerate viscometer AVS 350 | 1 | 0.000978 | 0.000889 | 0.001073 |
| SPHERE:UFactor:4 | 1 | 0.000914 | 0.000698 | 0.001177 |
| CONCYL::UFactor:4 | 1 | 0.000937 | 0.000708 | 0.001180 |
| CAPTUB::UFactor:6 | 1 | 0.000899 | 0.000749 | 0.001086 |
| CAPTUB::UFactor:16 | 1 | 0.000978 | 0.000889 | 0.001073 |

### Key comparisons

- **Most-used methods:** Capillary tube (Ostwald/Ubbelohde) with 38 blocks and falling/rolling sphere with 26 blocks dominate the dataset.
- **Average viscosity agreement:** All methods cluster tightly around ~0.00091–0.00109 Pa·s, with the two most-reported named methods agreeing within ~2.5 % (0.001012 vs 0.000987 Pa·s).
- **Coded variants** (e.g., CAPTUB:UFactor:N, SPHERE::UFactor:N) represent capillary-tube or sphere methods with different uncertainty factors; their averages remain consistent with the named methods.
- **Concentric cylinders viscometry** (3 blocks) reports a slightly lower average (0.000940 Pa·s).
- **Broadest range:** Falling/rolling sphere (0.000510–0.001955) and CAPTUB::UFactor:8 (0.000512–0.001975), reflecting measurements over wider temperature spans beyond 25 °C.

## 19. execute_sql

## Viscosity of Pure Liquid Ethanol near 25 °C — Single-Point Measurements by Method

**Query details:** Pure ethanol (comp_num_id 2), viscosity (prop_num_id 4), 1-component system, temperature 296–300 K, single data-point blocks. 19 rows returned (no truncation).

### Capillary tube (Ostwald / Ubbelohde) method — 13 measurements

| DOI | Block | Viscosity (Pa·s) |
|-----|:-----:|------------------:|
| 10.1021/je800899w | 6 | 0.001054 |
| 10.1021/je700618y | 6 | 0.001076 |
| 10.1016/j.fluid.2006.01.008 | 11 | 0.001077 |
| 10.1016/j.fluid.2007.03.021 | 3 | 0.001082 |
| 10.1021/je700318e | 2 | 0.001082 |
| 10.1021/je700710d | 2 | 0.001082 |
| 10.1021/je900998f | 2 | 0.001082 |
| 10.1016/j.jct.2012.02.027 | 11 | 0.001087 |
| 10.1021/je201152j | 7 | 0.001091 |
| 10.1016/j.jct.2005.04.019 | 4 | 0.001093 |
| 10.1016/j.jct.2016.12.036 | 7 | 0.001093 |
| 10.1021/acs.jced.5b00162 | 8 | 0.001103 |
| 10.1021/je034203p | 7 | 0.001112 |

**Range:** 0.001054 – 0.001112 Pa·s

### Falling or rolling sphere viscometry — 6 measurements

| DOI | Block | Viscosity (Pa·s) |
|-----|:-----:|------------------:|
| 10.1021/acs.jced.7b00944 | 6 | 0.001040 |
| 10.1021/acs.jced.8b00086 | 17 | 0.001056 |
| 10.1021/je500380x | 4 | 0.001083 |
| 10.1016/j.jct.2013.11.026 | 17 | 0.001125 |
| 10.1021/acs.jced.8b00939 | 12 | 0.001130 |
| 10.1016/j.jct.2013.09.044 | 6 | 0.001187 |

**Range:** 0.001040 – 0.001187 Pa·s

### Cross-method comparison

| Method | N | Min (Pa·s) | Max (Pa·s) | Spread |
|--------|:-:|----------:|----------:|-------:|
| Capillary tube (Ostwald/Ubbelohde) | 13 | 0.001054 | 0.001112 | 5.5 % |
| Falling / rolling sphere | 6 | 0.001040 | 0.001187 | 14.1 % |

**Note:** No results were returned for "Concentric cylinders viscometry" (the third method filtered for). All values are mean_value from single-point blocks for pure ethanol near 298.15 K.

## 20. execute_sql

## Concentric Cylinder Viscometry Blocks Spanning 298.15 K for Pure Ethanol

**Task: Identify if any concentric cylinder blocks include 298.15 K data**

**Result: Yes — 3 blocks found.**

| DOI | Block Number | Method |
|-----|-------------|--------|
| 10.1016/j.jct.2018.02.022 | 3 | Concentric cylinders viscometry |
| 10.1021/acs.jced.8b00793 | 2 | Concentric cylinders viscometry |
| 10.1021/je200600p | 3 | Concentric cylinders viscometry |

All three blocks are single-component (pure ethanol), have more than one data point, and their temperature variable range spans 298.15 K.

## 21. execute_sql

## Compacted Result

**Query:** Extract data points from block 3 (concentric cylinder viscometry) of DOI `10.1021/je200600p` for pure ethanol viscosity at 298.15 K.

**Result: 0 rows returned.**

No data points were found for `block_number = '3'` in this DOI. Possible reasons:
- The block number may be stored differently (e.g., as an integer rather than string `'3'`, or with a prefix).
- The block numbering or structure in `json_data` may not match the expected value.

**JSON structure note:** The query attempted to access `$.blocks[].data_points[].variable_values` and `$.blocks[].data_points[].property_values`, but since no rows were returned, the actual data structure for this DOI/block could not be confirmed.

**No viscosity value at 298.15 K was extracted from this query.**

## 22. execute_sql

## JSON Structure of `pcs.cards` Blocks for DOI `10.1021/je200600p`

The result returned 1 row. The `$.blocks` value is a JSON **array of objects**. The preview (first 2000 chars) reveals the structure of the first block:

### Block-level keys

| Key | Example value / type |
|---|---|
| `block_number` | `"1"` |
| `block_type` | `"PureOrMixtureData"` |
| `system_type` | `"unary"` |
| `blocktype_num_id` | `"2"` |
| `compounds` | Array of compound objects |
| `properties` | Array of property objects |
| `solvents` | `[]` |
| `variables` | Array of variable objects |
| `constraints` | Array of constraint objects |
| `data_summary` | Object (truncated in preview) |

**Note:** The preview was truncated at 2000 chars, so `data_points` (the key needed for actual measured values) was **not visible**. It likely appears later in the JSON. The expected path based on schema docs is:

```
$.blocks[N].data_points[M].variable_values
$.blocks[N].data_points[M].property_values
```

### Key sub-structures seen

**compounds[]**
- `org_num`, `comp_num_id`, `inchi_key`, `name`, `formula`, `InChI`, `SMILES`, `sample_num`

**properties[]**
- `id`, `prop_num_id`, `prop_ID` (e.g. `"viscosity_pa_s"`), `name` (e.g. `"Viscosity, Pa*s"`), `group` (`"TransportProp"`)
- `method_standard` (e.g. `"Concentric cylinders viscometry"`), `meas_num_id`, `meas_ID`
- `presentation`, `property_phase` (with `phase`, `phase_num_id`, `phase_id`)
- `uncertainty` (with `evaluation_method`, `confidence_level`, `assessment_num`)

**variables[]**
- `id`, `var_num_id`, `var_id` (e.g. `"temperature_k"`), `type`, `name` (e.g. `"Temperature, K"`)
- `phase`, `component_org_num`

**constraints[]**
- `id`, `constr_num_id`, `constr_id` (e.g. `"pressure_kpa"`), `type`, `name`, `value` (e.g. `101.325`), `digits`

### Implication for data extraction

To get actual viscosity values and temperatures, query deeper into the JSON using paths like:

```sql
json_extract(json_data, '$.blocks[0].data_points[0].variable_values')
json_extract(json_data, '$.blocks[0].data_points[0].property_values')
```

or use `json_each()` to iterate over `$.blocks` and then over each block's `data_points` array.

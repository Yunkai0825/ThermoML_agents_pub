# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 9
- **API turns:** 10
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 205.7s
- **Timed out:** False

## Answer

I now have a very clear and consistent picture from multiple sources. Let me provide the comprehensive answer.

## Density of Equimolar Propan-2-ol + Water at 25 °C and Atmospheric Pressure

### Direct Measurement from ThermoML

The most direct measurement comes from:

> **DOI: 10.1021/je700700f** — Block PROPblock_17
> - **Conditions:** T = 298.15 K (25 °C), P = 101 kPa (atmospheric), liquid phase
> - **Composition:** Mole fraction of propan-2-ol = **0.4981** (essentially equimolar)
> - **Density: 838.8 ± 0.4 kg/m³**

### Corroboration from Other Sources

Two additional ThermoML datasets confirm this value:

| Source (DOI) | Composition basis | Nearest point | T (K) | Density (kg/m³) | Notes |
|---|---|---|---|---|---|
| **10.1021/je700700f** | x(propan-2-ol) = 0.4981 | Direct | 298.15 | **838.8 ± 0.4** | Best match |
| **10.1021/je800158z** | x(propan-2-ol) = 0.5204 | Bracketing | 293.15 / 303.15 | 839.36 / 830.58 | Interpolation to 298.15 K gives ~835 kg/m³ (slightly lower because x > 0.5) |
| **10.1021/je201010s** | w(propan-2-ol) = 0.6840–0.7874 | Interpolation | 298.15 | ~838–839 | Equimolar ≈ w = 0.769; interpolated value matches well |

All three independent datasets converge on the same value, giving high confidence.

### Answer

**The density of an equimolar (x = 0.5) propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure is approximately 838.8 kg/m³ (≈ 0.839 g/cm³).**

### Chemical Insight

This density is notably **lower than pure water** (997 kg/m³) but **higher than pure propan-2-ol** (~781 kg/m³), as expected for a mixture. The equimolar mixture is actually quite rich in propan-2-ol by mass (~77 wt%) because propan-2-ol (M = 60.1 g/mol) is much heavier per molecule than water (M = 18.0 g/mol).

The propan-2-ol + water system is well known for exhibiting **negative excess volumes** (volume contraction upon mixing), driven by hydrogen bonding reorganization. The measured density of ~839 kg/m³ is slightly *higher* than what a simple linear (ideal) mixing rule would predict from the pure-component densities, consistent with this volume contraction — the strong hydrogen bonding between water and the hydroxyl group of propan-2-ol leads to a more compact packing than ideal mixing would suggest.

# Q1.3 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Compound Registry Results

| comp_num_id | comp_id | common_name | formula | smiles | inchi_key |
|---|---|---|---|---|---|
| **GLOBcomp_1** | water | water | H2O | O | XLYOFNOQVPJJNP-UHFFFAOYSA-N |
| **GLOBcomp_6** | propan-2-ol | propan-2-ol | C3H8O | CC(C)O | KFZMGEQAYNKOFK-UHFFFAOYSA-N |

**Task summary:**
1. **Propan-2-ol / isopropanol:** `comp_num_id = GLOBcomp_6`
2. **Water:** `comp_num_id = GLOBcomp_1`

*Note: One additional row (GLOBcomp_5, propan-1-ol) was returned due to the shared formula C3H8O but is not relevant and was omitted.*

## 2. execute_sql

## Density data blocks for binary propan-2-ol + water mixtures

**12 rows returned (not truncated). All are binary, liquid-phase, "Mass density, kg/m³".**

| DOI | Block | N pts | min (kg/m³) | max (kg/m³) | mean (kg/m³) | phase |
|-----|-------|------:|------------:|------------:|--------------:|-------|
| 10.1016/j.fluid.2013.08.007 | PROPblock_4 | 1110 | 674.03 | 976.41 | 826.76 | liquid |
| 10.1016/j.jct.2004.07.019 | PROPblock_4 | 529 | −19.9725 | −1.1132 | −5.92 | liquid |
| 10.1016/j.jct.2019.105880 | PROPblock_10 | 12 | 945.121 | 983.401 | 966.38 | liquid |
| 10.1021/acs.jced.6b00019 | PROPblock_13 | 6 | 936.3 | 969.9 | 954.0 | liquid |
| 10.1021/acs.jced.8b00160 | PROPblock_15 | 18 | 862.4 | 979.9 | 926.97 | liquid |
| 10.1021/acs.jced.8b00723 | PROPblock_14 | 3 | 987.6 | 993.1 | 990.83 | liquid |
| 10.1021/je049738c | PROPblock_28 | 8 | 987.73 | 996.38 | 992.94 | liquid |
| 10.1021/je201010s | PROPblock_8 | 17 | 780.82 | 997.02 | 859.97 | liquid |
| 10.1021/je700700f | PROPblock_17 | 13 | 780.7 | 997.2 | 861.96 | liquid |
| 10.1021/je8001305 | PROPblock_1 | 209 | 756.9 | 900.79 | 826.35 | liquid |
| 10.1021/je800158z | PROPblock_4 | 56 | 758.68 | 998.2 | 854.48 | liquid |
| 10.1021/je900966r | PROPblock_6 | 30 | 986.979 | 996.544 | 992.11 | liquid |

### Notes
- **Property:** All rows report `mass_density_kg_m3` ("Mass density, kg/m³"), phase = **liquid**.
- **Anomalous block:** `10.1016/j.jct.2004.07.019 / PROPblock_4` shows negative values (−19.97 to −1.11), suggesting these are likely **excess density** or deviation values rather than absolute densities, despite sharing the same property label.
- These blocks span various temperature/pressure ranges; the query did not filter to 25 °C / 1 atm or equimolar composition — further filtering of the actual data points (in `pcs.cards.json_data`) is needed to extract the specific equimolar, 25 °C, atmospheric-pressure density value.

## 3. execute_sql

## Variable Ranges for Candidate Density Blocks

### Summary by Block

| DOI | Block | Temperature (K) | Composition Variable | Comp. Min | Comp. Max | T includes 298.15 K? | Comp. includes 0.5? |
|-----|-------|-----------------|---------------------|-----------|-----------|----------------------|---------------------|
| 10.1016/j.fluid.2013.08.007 | PROPblock_4 | 313.15–403.15 | Mole fraction | 0.15 | 1.0 | **No** (min 313.15) | Yes |
| 10.1021/acs.jced.8b00160 | PROPblock_15 | 298.15–318.15 | Mass fraction | 0.1 | 0.6 | **Yes** | Unclear (mass fr. ≠ mole fr.) |
| 10.1021/je201010s | PROPblock_8 | *(no T variable)* | Mass fraction | 0.0 | 1.0 | Unknown (T may be constraint) | Unclear (mass fr.) |
| 10.1021/je700700f | PROPblock_17 | *(no T variable)* | Mole fraction | 0.0 | 1.0 | Unknown (T may be constraint) | **Yes** |
| 10.1021/je800158z | PROPblock_4 | 293.15–323.15 | Mole fraction | 0.0 | 1.0 | **Yes** (range spans it) | **Yes** |
| 10.1021/je8001305 | PROPblock_1 | 300.08–351.14 | Mole fraction | 0.2483 | 0.7258 | **No** (min 300.08) | Yes |

### Best Candidates for Equimolar (x = 0.5) at 25 °C (298.15 K)

1. **10.1021/je800158z, PROPblock_4** — Strongest candidate: T range (293.15–323.15 K) includes 298.15 K; mole fraction range (0.0–1.0, 14 unique values) very likely includes 0.5.

2. **10.1021/je700700f, PROPblock_17** — Good candidate: mole fraction 0.0–1.0 (13 values) includes 0.5; temperature not listed as a variable (may be fixed at 298.15 K via constraint — needs verification).

3. **10.1021/je201010s, PROPblock_8** — Possible but uses mass fraction (not directly mole fraction); temperature absent as variable (may be constrained — needs verification).

### Notes
- Blocks without a temperature variable may have temperature set as a block constraint; those need separate lookup.
- Mass-fraction blocks (je201010s, acs.jced.8b00160) require conversion to confirm whether any data point corresponds to equimolar composition.

## 4. execute_sql

## Block Constraints for Candidate Blocks

6 rows returned (not truncated).

| doi | block_number | constr_name | constr_id | value |
|-----|-------------|-------------|-----------|-------|
| 10.1021/acs.jced.8b00160 | PROPblock_15 | Pressure, kPa | pressure_kpa | 100.0 |
| 10.1021/je201010s | PROPblock_8 | Pressure, kPa | pressure_kpa | 101.0 |
| 10.1021/je201010s | PROPblock_8 | Temperature, K | temperature_k | **298.15** |
| 10.1021/je700700f | PROPblock_17 | Pressure, kPa | pressure_kpa | 101.0 |
| 10.1021/je700700f | PROPblock_17 | Temperature, K | temperature_k | **298.15** |
| 10.1021/je800158z | PROPblock_4 | Pressure, kPa | pressure_kpa | 81.5 |

### Task 1 — Temperature constrained at 298.15 K?
- **je700700f / PROPblock_17**: ✔ Temperature constrained at **298.15 K**
- **je201010s / PROPblock_8**: ✔ Temperature constrained at **298.15 K**

### Task 2 — Pressure constraints for all candidate blocks
| Block | Pressure (kPa) | Notes |
|-------|----------------|-------|
| je700700f / PROPblock_17 | 101.0 | ≈ atmospheric |
| je201010s / PROPblock_8 | 101.0 | ≈ atmospheric |
| acs.jced.8b00160 / PROPblock_15 | 100.0 | ≈ atmospheric |
| je800158z / PROPblock_4 | **81.5** | **Below atmospheric** — no temperature constraint listed (T may be a variable in this block) |

## 5. execute_sql

## Compacted Result

### Key findings for equimolar (x ≈ 0.5) propan-2-ol + water density at 298.15 K

**Composition variable:** Mole fraction (BLKvar_1 ranges 0 → 1, with values like 0.4981, 0.5009 — consistent with mole fraction of propan-2-ol).

#### Data points nearest x = 0.5

| DOI | Block | x (mole fraction) | Density (kg/m³) | Expanded uncertainty (kg/m³) |
|---|---|---|---|---|
| 10.1021/je700700f | PROPblock_17 | **0.4981** | **838.8** | 0.4 |
| 10.1021/je201010s | PROPblock_8 | 0.4795 | 906.69 | 1.01 |
| 10.1021/je201010s | PROPblock_8 | **0.5009** | **901.31** | 1.01 |

> **Note:** The two sources give very different density values near x = 0.5 (~839 vs ~901 kg/m³). The je201010s block likely uses **mass fraction** rather than mole fraction (despite the variable label), because its x = 0 value (997.02) and x = 1 value (780.82) match pure water and pure propan-2-ol densities, and the density at "0.5" (~901) is consistent with mass-fraction = 0.5 rather than mole-fraction = 0.5. The je700700f/PROPblock_17 block similarly spans 0→1 with endpoint densities of 997.2 and 780.7 kg/m³, but its value at x = 0.4981 (838.8 kg/m³) is consistent with **mole fraction** = 0.5.

### Bracketing data for interpolation (je201010s, if mass fraction)

| x | Density (kg/m³) |
|---|---|
| 0.4795 | 906.69 |
| 0.5009 | 901.31 |

### Bracketing data for interpolation (je700700f, if mole fraction)

| x | Density (kg/m³) |
|---|---|
| 0.3992 → 0.4981 → 0.5979 | 857.7 → **838.8** → 823.5 |

### What was omitted
- 1 row from je700700f/PROPblock_8 (viscosity data, not density, with two variables T=298.15 K and P=101 kPa — value 0.00089, irrelevant to density task).
- Rows far from x = 0.5 in both blocks were retained above only as endpoint checks; full series (31 rows total, no truncation) are available.

## 6. execute_sql

## Variable Definitions for Both Blocks

| DOI | Block | var_id | var_name | component_org_num | min | max | n_unique |
|-----|-------|--------|----------|-------------------|-----|-----|----------|
| 10.1021/je201010s | PROPblock_8 | mass_fraction_DOIcomp_1 | **Mass fraction** | DOIcomp_1 | 0.0 | 1.0 | 17 |
| 10.1021/je700700f | PROPblock_17 | mole_fraction_DOIcomp_2 | **Mole fraction** | DOIcomp_2 | 0.0 | 1.0 | 13 |

### Key Finding

The two blocks use **different composition variables**:

- **je700700f / PROPblock_17** uses **mole fraction** (of component 2)
- **je201010s / PROPblock_8** uses **mass fraction** (of component 1)

This confirms that any apparent discrepancy in the composition value at which density is reported (e.g., x = 0.5 in one vs. the other) could be due to **mole fraction vs. mass fraction** — an equimolar mixture (mole fraction = 0.5) does **not** correspond to a mass fraction of 0.5 for propan-2-ol + water.

## 7. execute_sql

## Component Identification for Each Block

| DOI | Block | org_num | comp_name | comp_num_id |
|-----|-------|---------|-----------|-------------|
| 10.1021/je201010s | PROPblock_8 | DOIcomp_1 | propan-2-ol | GLOBcomp_6 |
| 10.1021/je201010s | PROPblock_8 | DOIcomp_3 | water | GLOBcomp_1 |
| 10.1021/je700700f | PROPblock_17 | DOIcomp_2 | propan-2-ol | GLOBcomp_6 |
| 10.1021/je700700f | PROPblock_17 | DOIcomp_3 | water | GLOBcomp_1 |

### Summary

- **je201010s / PROPblock_8**: **DOIcomp_1** = propan-2-ol; **DOIcomp_3** = water
- **je700700f / PROPblock_17**: **DOIcomp_2** = propan-2-ol; **DOIcomp_3** = water

This means any mole-fraction variable linked to `DOIcomp_1` (je201010s) or `DOIcomp_2` (je700700f) refers to the propan-2-ol composition. An equimolar mixture corresponds to a mole fraction of 0.5 for that component.

## 8. execute_sql

## Compacted Result — je800158z / PROPblock_4

**Source:** DOI `10.1021/je800158z`, block `PROPblock_4`

**Variables:**
- `BLKvar_1` = mole fraction of propan-2-ol (x)
- `BLKvar_2` = temperature (K)

**Property:** `BLKprop_1` = density (kg/m³)

### Key finding: Nearest data point to x = 0.5 at T ≈ 298.15 K

This dataset does **not** contain T = 298.15 K; the available temperatures are 293.15, 303.15, 313.15, and 323.15 K. The closest mole fraction to 0.5 is **x = 0.5204**.

| x (propan-2-ol) | T (K) | Density (kg/m³) | Expanded uncertainty |
|---|---|---|---|
| 0.5204 | 293.15 | 839.36 | ±0.39 |
| **0.5204** | **303.15** | **830.58** | **±0.40** |
| 0.5204 | 313.15 | 821.54 | ±0.42 |
| 0.5204 | 323.15 | 812.20 | ±0.43 |

By interpolation between 293.15 K and 303.15 K, the density at 298.15 K would fall between **839.36** and **830.58** kg/m³ (roughly ~835 kg/m³).

### Comparison with je700700f

| Source | x | T (K) | Density (kg/m³) |
|---|---|---|---|
| je700700f | 0.4981 | 298.15 | 838.8 |
| je800158z | 0.5204 | 293.15 | 839.36 |
| je800158z | 0.5204 | 303.15 | 830.58 |

The je700700f value of **838.8 kg/m³** at x = 0.4981 and 298.15 K is consistent with the je800158z data (x = 0.5204 is slightly more propan-2-ol-rich, which lowers density; the interpolated 298.15 K value at x = 0.5204 would be ~835 kg/m³, slightly lower as expected).

### Omitted data

Rows for mole fractions far from 0.5 (x = 0.0, 0.0399, 0.1197, 0.2017, 0.28, 0.359, 0.4384, 0.6801, 0.7552, 0.8403, 0.9225) were omitted as not directly relevant to the equimolar comparison. The flanking composition **x = 0.4384** is included below for bracketing:

| x | T (K) | Density (kg/m³) | Uncertainty |
|---|---|---|---|
| 0.4384 | 293.15 | 854.11 | ±0.37 |
| 0.4384 | 303.15 | 845.46 | ±0.38 |

**Note:** The result returned 50 rows (not truncated). No row at exactly T = 298.15 K exists in this block.

## 9. execute_sql

## Compacted Result — DOI 10.1021/je201010s, PROPblock_8

**Source:** 17 data points (all rows returned, no truncation).

**Variable (BLKvar_1):** Mass fraction of propan-2-ol
**Property (BLKprop_1):** Density (kg/m³), with expanded uncertainty

| Mass fraction | Density (kg/m³) | Uncertainty (kg/m³) |
|:---:|:---:|:---:|
| 0.0000 | 997.02 | 1.00 |
| 0.0915 | 982.05 | 1.00 |
| 0.2131 | 960.29 | 1.00 |
| 0.3299 | 936.93 | 1.00 |
| 0.4795 | 906.69 | 1.01 |
| 0.5009 | 901.31 | 1.01 |
| 0.6180 | 874.45 | 1.01 |
| 0.6840 | 858.73 | 1.01 |
| **0.7874** | **834.01** | **1.01** |
| 0.8788 | 811.99 | 1.01 |
| 0.8976 | 807.44 | 1.01 |
| 0.9154 | 803.01 | 1.01 |
| 0.9311 | 799.05 | 1.01 |
| 0.9502 | 794.22 | 1.01 |
| 0.9752 | 787.71 | 1.01 |
| 0.9895 | 783.80 | 1.01 |
| 1.0000 | 780.82 | 1.01 |

### Task 1 — Density near equimolar composition (mass fraction ≈ 0.769)

The closest measured mass fraction is **0.7874** (target 0.769). The corresponding density is **834.01 kg/m³** (± 1.01 kg/m³). The next-lower mass fraction is 0.6840 (density 858.73 kg/m³). Linear interpolation between these two points at w = 0.769 would give ≈ 838.8 kg/m³.

### Task 2 — Comparison with je700700f value

The je700700f reference value is **838.8 kg/m³** at mole fraction 0.4981 (≈ equimolar). An interpolated value from this dataset at w ≈ 0.769 yields a density very close to 838.8 kg/m³, consistent with the je700700f measurement. The nearest directly measured point (w = 0.7874) gives 834.01 kg/m³, which is slightly lower because its mass fraction (and hence mole fraction of propan-2-ol) is slightly higher than equimolar.

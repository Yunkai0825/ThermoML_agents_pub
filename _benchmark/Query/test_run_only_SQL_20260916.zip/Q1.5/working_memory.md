# Q1.5 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Ethanol Compound Registry Entry

| Field | Value |
|---|---|
| **comp_num_id** | `GLOBcomp_2` |
| **comp_id** | `ethanol` |
| **InChIKey** | `LFQSCWFLJHTTHZ-UHFFFAOYSA-N` |
| **common_name** | ethanol |
| **formula** | C2H6O |
| **SMILES** | `CCO` |

Exactly 1 row returned; no truncation.

## 2. execute_sql

## Viscosity Property Registry Entries

| prop_num_id | prop_id | prop_name | prop_group |
|---|---|---|---|
| **GLOBprop_4** | viscosity_pa_s | Viscosity, Pa·s | TransportProp |
| **GLOBprop_40** | kinematic_viscosity_m2_s | Kinematic viscosity, m²/s | TransportProp |

**Summary:** Only 2 viscosity-related properties exist in the registry (no truncation). **GLOBprop_4** corresponds to dynamic viscosity (Pa·s) and **GLOBprop_40** to kinematic viscosity (m²/s). For pure liquid ethanol viscosity measurements, **GLOBprop_4** is the primary target.

## 3. execute_sql

## Compacted SQL Result

### Query Purpose
Find all pure ethanol viscosity data blocks with their measurement methods and reported value ranges.

### Result: **Zero rows returned**

The query returned **no results** for pure ethanol viscosity data. This means that under the filter conditions used:

- **Compound**: `GLOBcomp_2` (ethanol)
- **Property**: name containing "iscosity"
- **System**: `pure` with `n_components = 1`

…no matching blocks exist in the `idx` tables.

### Implications for Each Task

| Task | Status |
|------|--------|
| List all DOIs and blocks with pure ethanol viscosity data | **No data found** |
| Identify measurement methods used | **No data found** |
| Get min/max/mean viscosity values reported | **No data found** |
| Note the phase (liquid) | **No data found** |

### Possible Reasons
- Ethanol's `comp_num_id` may not be `GLOBcomp_2`; the compound identifier should be verified against `idx.compound_registry` (e.g., searching by name `'ethanol'` or InChIKey).
- Viscosity data for ethanol may exist in multi-component blocks (mixtures) rather than pure-compound blocks, or the property name may differ from the `%iscosity%` pattern used.

## 4. execute_sql

## Compacted Result: Pure Ethanol Dynamic Viscosity Blocks

**Query:** Pure liquid ethanol (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`), property `GLOBprop_4` (Viscosity, Pa·s), single-component systems.

**Result:** 50 rows returned (LIMIT 50 reached — more data may exist).

### Key findings

- **system_type:** All 50 rows = `"unary"` (pure component)
- **n_components:** All = 1
- **phase_id:** All = `"liquid"`
- **Property:** All = `"Viscosity, Pa*s"`

### Value ranges across all 50 blocks

| Statistic | min_value (Pa·s) | max_value (Pa·s) | mean_value (Pa·s) |
|---|---|---|---|
| Lowest seen | 0.000488 | 0.000695 | 0.000657 |
| Highest seen | 0.001125 | 0.001955 | 0.001125 |

Most blocks report mean viscosities in the range **~0.00085–0.00110 Pa·s** (0.85–1.10 mPa·s), consistent with ethanol near 25 °C.

### All 50 blocks (DOI, block, min/max/mean viscosity in Pa·s, n_values)

| DOI | block | min | max | mean | n |
|---|---|---|---|---|---|
| 10.1007/s10765-005-8089-2 | PROPblock_1 | 0.00051 | 0.001955 | 0.001049 | 23 |
| 10.1016/j.fluid.2005.05.012 | PROPblock_3 | 0.000982 | 0.00117 | 0.001077 | 3 |
| 10.1016/j.fluid.2005.07.010 | PROPblock_9 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1016/j.fluid.2006.01.008 | PROPblock_11 | 0.001077 | 0.001077 | 0.001077 | 1 |
| 10.1016/j.fluid.2006.01.030 | PROPblock_1 | 0.00051 | 0.001955 | 0.001076 | 20 |
| 10.1016/j.fluid.2006.01.030 | PROPblock_2 | 0.00059 | 0.001194 | 0.00087 | 3 |
| 10.1016/j.fluid.2006.02.023 | PROPblock_11 | 0.000968 | 0.000968 | 0.000968 | 1 |
| 10.1016/j.fluid.2007.03.021 | PROPblock_3 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1016/j.fluid.2007.08.006 | PROPblock_2 | 0.000617 | 0.000695 | 0.000657 | 3 |
| 10.1016/j.fluid.2016.08.022 | PROPblock_6 | 0.000585 | 0.001161 | 0.000853 | 3 |
| 10.1016/j.jct.2005.04.019 | PROPblock_4 | 0.001093 | 0.001093 | 0.001093 | 1 |
| 10.1016/j.jct.2005.06.011 | PROPblock_26 | 0.000895 | 0.001083 | 0.000988 | 3 |
| 10.1016/j.jct.2005.07.008 | PROPblock_3 | 0.001105 | 0.001105 | 0.001105 | 1 |
| 10.1016/j.jct.2005.10.022 | PROPblock_2 | 0.000889 | 0.001073 | 0.000978 | 3 |
| 10.1016/j.jct.2005.12.010 | PROPblock_1 | 0.000987 | 0.001187 | 0.001085 | 3 |
| 10.1016/j.jct.2006.03.010 | PROPblock_7 | 0.000902 | 0.001084 | 0.000993 | 2 |
| 10.1016/j.jct.2006.03.018 | PROPblock_6 | 0.000889 | 0.001073 | 0.000978 | 3 |
| 10.1016/j.jct.2006.06.008 | PROPblock_13 | 0.000987 | 0.001187 | 0.001085 | 3 |
| 10.1016/j.jct.2006.10.016 | PROPblock_3 | 0.000749 | 0.001086 | 0.000899 | 5 |
| 10.1016/j.jct.2007.05.004 | PROPblock_3 | 0.000987 | 0.001187 | 0.001085 | 3 |
| 10.1016/j.jct.2008.03.013 | PROPblock_5 | 0.000641 | 0.001082 | 0.00085 | 3 |
| 10.1016/j.jct.2008.04.006 | PROPblock_2 | 0.000641 | 0.001082 | 0.00085 | 3 |
| 10.1016/j.jct.2009.06.023 | PROPblock_1 | 0.000587 | 0.001418 | 0.00093 | 11 |
| 10.1016/j.jct.2010.03.022 | PROPblock_2 | 0.000488 | 0.001832 | 0.001035 | 23 |
| 10.1016/j.jct.2012.02.027 | PROPblock_11 | 0.001087 | 0.001087 | 0.001087 | 1 |
| 10.1016/j.jct.2012.08.024 | PROPblock_4 | 0.000648 | 0.001087 | 0.000847 | 7 |
| 10.1016/j.jct.2012.10.008 | PROPblock_6 | 0.000836 | 0.001218 | 0.001023 | 5 |
| 10.1016/j.jct.2012.10.008 | PROPblock_7 | 0.000907 | 0.00101 | 0.000959 | 2 |
| 10.1016/j.jct.2013.09.006 | PROPblock_2 | 0.00087 | 0.00109 | 0.00097 | 3 |
| 10.1016/j.jct.2013.09.044 | PROPblock_6 | 0.001187 | 0.001187 | 0.001187 | 1 |
| 10.1016/j.jct.2013.11.026 | PROPblock_17 | 0.001125 | 0.001125 | 0.001125 | 1 |
| 10.1016/j.jct.2015.04.027 | PROPblock_4 | 0.000829 | 0.001186 | 0.000998 | 5 |
| 10.1016/j.jct.2015.08.036 | PROPblock_2 | 0.000764 | 0.001096 | 0.000922 | 5 |
| 10.1016/j.jct.2016.12.036 | PROPblock_7 | 0.001093 | 0.001093 | 0.001093 | 1 |
| 10.1016/j.jct.2017.07.022 | PROPblock_2 | 0.000747 | 0.001286 | 0.000993 | 7 |
| 10.1016/j.jct.2018.02.022 | PROPblock_3 | 0.000904 | 0.001202 | 0.001047 | 4 |
| 10.1016/j.jct.2019.02.019 | PROPblock_6 | 0.00069 | 0.00117 | 0.00091 | 4 |
| 10.1016/j.jct.2019.04.023 | PROPblock_5 | 0.000697 | 0.001177 | 0.000912 | 7 |
| 10.1021/acs.jced.5b00152 | PROPblock_10 | 0.000587 | 0.001296 | 0.000873 | 27 |
| 10.1021/acs.jced.5b00162 | PROPblock_8 | 0.001103 | 0.001103 | 0.001103 | 1 |
| 10.1021/acs.jced.5b00259 | PROPblock_6 | 0.000698 | 0.001177 | 0.000914 | 7 |
| 10.1021/acs.jced.5b00365 | PROPblock_4 | 0.000698 | 0.001177 | 0.000914 | 7 |
| 10.1021/acs.jced.5b01000 | PROPblock_12 | 0.000824 | 0.001444 | 0.001116 | 3 |
| 10.1021/acs.jced.6b00096 | PROPblock_2 | 0.000752 | 0.001084 | 0.000918 | 2 |
| 10.1021/acs.jced.6b00563 | PROPblock_3 | 0.000758 | 0.001083 | 0.000914 | 3 |
| 10.1021/acs.jced.7b00267 | PROPblock_2 | 0.000594 | 0.001194 | 0.000855 | 9 |
| 10.1021/acs.jced.7b00299 | PROPblock_2 | 0.001091 | 0.001159 | 0.001125 | 2 |
| 10.1021/acs.jced.7b00321 | PROPblock_10 | 0.00069 | 0.00117 | 0.00091 | 4 |
| 10.1021/acs.jced.7b00944 | PROPblock_6 | 0.00104 | 0.00104 | 0.00104 | 1 |
| 10.1021/acs.jced.8b00086 | PROPblock_17 | 0.001056 | 0.001056 | 0.001056 | 1 |

**Note:** The query hit the LIMIT of 50 rows; additional blocks likely exist. Measurement method information was not included in this query (would require joining `block_measurements`).

## 5. execute_sql

## Compacted Result: Pure Ethanol Viscosity Blocks via `compound_system`

### Filtering Notes
- 50 rows returned (limit reached; there may be more matching rows).
- **Removed 28 rows** where `compound_system` was not `"ethanol"` (matched methanol, diethanolamine, 2-isopropoxyethanol, and other compounds containing "ethanol" in their name). Only pure ethanol rows retained.
- All rows are `system_type = "unary"`, `n_components = 1`, property = **"Viscosity, Pa·s"** (`GLOBprop_4`).

### Pure Ethanol Viscosity Blocks (18 rows)

| DOI | block_number | min (Pa·s) | max (Pa·s) | n_values |
|-----|-------------|-----------|-----------|----------|
| 10.1007/s10765-005-8089-2 | PROPblock_1 | 0.000510 | 0.001955 | 23 |
| 10.1016/j.fluid.2005.05.012 | PROPblock_3 | 0.000982 | 0.001170 | 3 |
| 10.1016/j.fluid.2005.07.010 | PROPblock_9 | 0.001082 | 0.001082 | 1 |
| 10.1016/j.fluid.2006.01.008 | PROPblock_11 | 0.001077 | 0.001077 | 1 |
| 10.1016/j.fluid.2006.01.030 | PROPblock_1 | 0.000510 | 0.001955 | 20 |
| 10.1016/j.fluid.2006.01.030 | PROPblock_2 | 0.000590 | 0.001194 | 3 |
| 10.1016/j.fluid.2006.02.023 | PROPblock_11 | 0.000968 | 0.000968 | 1 |
| 10.1016/j.fluid.2007.03.021 | PROPblock_3 | 0.001082 | 0.001082 | 1 |
| 10.1016/j.fluid.2007.08.006 | PROPblock_2 | 0.000617 | 0.000695 | 3 |
| 10.1016/j.fluid.2016.08.022 | PROPblock_6 | 0.000585 | 0.001161 | 3 |
| 10.1016/j.jct.2005.04.019 | PROPblock_4 | 0.001093 | 0.001093 | 1 |
| 10.1016/j.jct.2005.06.011 | PROPblock_26 | 0.000895 | 0.001083 | 3 |
| 10.1016/j.jct.2005.07.008 | PROPblock_3 | 0.001105 | 0.001105 | 1 |
| 10.1016/j.jct.2005.10.022 | PROPblock_2 | 0.000889 | 0.001073 | 3 |
| 10.1016/j.jct.2005.12.010 | PROPblock_1 | 0.000987 | 0.001187 | 3 |
| 10.1016/j.jct.2006.03.010 | PROPblock_7 | 0.000902 | 0.001084 | 2 |
| 10.1016/j.jct.2006.03.018 | PROPblock_6 | 0.000889 | 0.001073 | 3 |
| 10.1016/j.jct.2006.06.008 | PROPblock_13 | 0.000987 | 0.001187 | 3 |
| 10.1016/j.jct.2006.10.016 | PROPblock_3 | 0.000749 | 0.001086 | 5 |
| 10.1016/j.jct.2007.05.004 | PROPblock_3 | 0.000987 | 0.001187 | 3 |
| 10.1016/j.jct.2008.03.013 | PROPblock_5 | 0.000641 | 0.001082 | 3 |
| 10.1016/j.jct.2008.04.006 | PROPblock_2 | 0.000641 | 0.001082 | 3 |

### Summary
- **15 unique DOIs** report pure ethanol viscosity across **22 blocks**.
- Values near 25 °C cluster around **~0.001 Pa·s (1.0 mPa·s)**, consistent with the well-known literature value.
- Broader temperature-range datasets (e.g., DOI `10.1007/s10765-005-8089-2`, `10.1016/j.fluid.2006.01.030`) span ~0.0005–0.002 Pa·s.
- **Measurement methods** were not returned by this query; the `block_measurements` table would need to be joined for method details.
- Result was truncated at 50 rows; additional ethanol blocks may exist beyond this limit.

## 6. execute_sql

## Measurement Methods for Pure Ethanol Viscosity

16 distinct method entries were found across the database. These group into a few core techniques with various custom sub-variants.

### Standard Methods

| Method Name | Method Type | meas_num_id | Blocks | Example DOIs (selected) |
|---|---|---|---:|---|
| Capillary tube (Ostwald; Ubbelohde) | standard | GLOBmeas_4 | 38 | 10.1021/je034203p, 10.1016/j.fluid.2006.01.008, 10.1021/acs.jced.5b00152 |
| Falling or rolling sphere viscometry | standard | GLOBmeas_8 | 26 | 10.1007/s10765-005-8089-2, 10.1021/je0500633, 10.1021/acs.jced.6b00096 |
| Concentric cylinders viscometry | standard | GLOBmeas_11 | 3 | 10.1016/j.jct.2018.02.022, 10.1021/acs.jced.8b00793, 10.1021/je200600p |

### Custom / Instrument-Specific Variants

| Method Name | meas_num_id | Blocks | Example DOIs (selected) |
|---|---|---:|---|
| CAPTUB:UFactor:4 | GLOBmeas_142 | 9 | 10.1021/je049808f, 10.1016/j.fluid.2005.07.010 |
| CAPTUB::UFactor:2 | GLOBmeas_140 | 8 | 10.1021/je0342825, 10.1016/j.jct.2005.06.011 |
| CAPTUB::UFactor:4 | GLOBmeas_142 | 7 | 10.1021/je049556i, 10.1021/je100671v |
| CAPTUB::UFactor:8 | GLOBmeas_165 | 6 | 10.1021/je800150h, 10.1016/j.jct.2008.03.013 |
| CAPTUB:UFactor:2 | GLOBmeas_140 | 5 | 10.1021/je030226s, 10.1016/j.fluid.2005.05.012 |
| SPHERE::UFactor:4 | GLOBmeas_234 | 3 | 10.1021/je0341413, 10.1021/je0500025 |
| CAPTUB:UFactor:8 | GLOBmeas_165 | 2 | 10.1016/j.fluid.2006.02.023, 10.1016/j.jct.2005.12.010 |
| CONCYL:UFactor:8 | GLOBmeas_284 | 2 | 10.1021/je100687x, 10.1021/je800925v |
| CAPTUB::UFactor:16 | GLOBmeas_205 | 1 | 10.1016/j.jct.2006.03.018 |
| CAPTUB::UFactor:6 | GLOBmeas_271 | 1 | 10.1016/j.jct.2006.10.016 |
| CONCYL::UFactor:4 | GLOBmeas_216 | 1 | 10.1021/je100848r |
| SPHERE:UFactor:4 | GLOBmeas_234 | 1 | 10.1021/acs.jced.5b00259 |
| Schott-Gerate viscometer model AVS 350 | GLOBmeas_497 | 1 | 10.1016/j.jct.2005.10.022 |

### Summary by Core Technique

| Core Technique | Total Blocks (standard + custom variants) |
|---|---:|
| Capillary tube (CAPTUB) | 38 + 39 custom = **77** |
| Falling/rolling sphere (SPHERE) | 26 + 4 custom = **30** |
| Concentric cylinders (CONCYL) | 3 + 3 custom = **6** |
| Schott-Gerate AVS 350 | **1** |

**Notes:** All 16 rows from the query are preserved. Full DOI lists (up to 38 per row) are available in the raw result; only a few examples are shown per row above. The custom "UFactor" variants (e.g., CAPTUB::UFactor:4) represent the same underlying technique with different uncertainty-factor metadata.

## 7. execute_sql

## Compacted Result: Ethanol Viscosity by Standard Method near 25 °C (298.15 K)

**67 rows returned (not truncated).** Three standard methods found. All viscosity values are in Pa·s. Temperature variable is "Temperature, K."

---

### 1. Capillary tube (Ostwald; Ubbelohde) method — 38 blocks

#### Blocks with T range including ~298 K

| DOI | block | T_min (K) | T_max (K) | η_min | η_max | η_mean | n |
|-----|-------|-----------|-----------|-------|-------|--------|---|
| 10.1016/j.fluid.2006.01.008 | PROPblock_11 | 298.15 | 298.15 | 0.001077 | 0.001077 | 0.001077 | 1 |
| 10.1016/j.fluid.2006.01.030 | PROPblock_2 | 293.15 | 333.15 | 0.00059 | 0.001194 | 0.00087 | 3 |
| 10.1016/j.fluid.2007.03.021 | PROPblock_3 | 298.15 | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1016/j.fluid.2016.08.022 | PROPblock_6 | 293.15 | 333.15 | 0.000585 | 0.001161 | 0.000853 | 3 |
| 10.1016/j.jct.2005.04.019 | PROPblock_4 | 298.15 | 298.15 | 0.001093 | 0.001093 | 0.001093 | 1 |
| 10.1016/j.jct.2012.02.027 | PROPblock_11 | 298.15 | 298.15 | 0.001087 | 0.001087 | 0.001087 | 1 |
| 10.1016/j.jct.2012.08.024 | PROPblock_4 | 298.15 | 328.15 | 0.000648 | 0.001087 | 0.000847 | 7 |
| 10.1016/j.jct.2013.09.006 | PROPblock_2 | 298.15 | 308.15 | 0.00087 | 0.00109 | 0.00097 | 3 |
| 10.1016/j.jct.2015.08.036 | PROPblock_2 | 298.15 | 318.15 | 0.000764 | 0.001096 | 0.000922 | 5 |
| 10.1016/j.jct.2016.12.036 | PROPblock_7 | 298.15 | 298.15 | 0.001093 | 0.001093 | 0.001093 | 1 |
| 10.1016/j.jct.2019.02.019 | PROPblock_6 | 293.15 | 323.15 | 0.00069 | 0.00117 | 0.00091 | 4 |
| 10.1021/acs.jced.5b00152 | PROPblock_10 | 298.149 | 333.279 | 0.000587 | 0.001296 | 0.000873 | 27 |
| 10.1021/acs.jced.5b00162 | PROPblock_8 | 298.15 | 298.15 | 0.001103 | 0.001103 | 0.001103 | 1 |
| 10.1021/acs.jced.5b01000 | PROPblock_12 | 283.15 | 313.15 | 0.000824 | 0.001444 | 0.001116 | 3 |
| 10.1021/acs.jced.7b00299 | PROPblock_2 | 293.15 | 298.15 | 0.001091 | 0.001159 | 0.001125 | 2 |
| 10.1021/acs.jced.7b00321 | PROPblock_10 | 293.15 | 323.15 | 0.00069 | 0.00117 | 0.00091 | 4 |
| 10.1021/acs.jced.8b01012 | PROPblock_6 | 288.15 | 318.15 | 0.000787 | 0.001332 | 0.001039 | 4 |
| 10.1021/je034203p | PROPblock_7 | 298.15 | 298.15 | 0.001112 | 0.001112 | 0.001112 | 1 |
| 10.1021/je050010l | PROPblock_5 | 288.15 | 308.15 | 0.000905 | 0.001309 | 0.001099 | 3 |
| 10.1021/je050367p | PROPblock_5 | 288.15 | 308.15 | 0.000905 | 0.001309 | 0.001099 | 6 |
| 10.1021/je050402s | PROPblock_13 | 288.15 | 318.15 | 0.000771 | 0.001337 | 0.001034 | 4 |
| 10.1021/je1000796 | PROPblock_3 | 278.15 | 313.15 | 0.000828 | 0.001629 | 0.001185 | 8 |
| 10.1021/je101173w | PROPblock_1 | 293.15 | 333.15 | 0.000581 | 0.001211 | 0.000862 | 5 |
| 10.1021/je1013476 | PROPblock_3 | 288.15 | 313.15 | 0.000824 | 0.001313 | 0.001099 | 5 |
| 10.1021/je200922s | PROPblock_3 | 293.15 | 323.15 | 0.000704 | 0.001189 | 0.000931 | 7 |
| 10.1021/je201116t | PROPblock_5 | 298.15 | 313.15 | 0.000839 | 0.001091 | 0.000961 | 4 |
| 10.1021/je201152j | PROPblock_7 | 298.15 | 298.15 | 0.001091 | 0.001091 | 0.001091 | 1 |
| 10.1021/je300557g | PROPblock_3 | 293.15 | 323.15 | 0.000694 | 0.00118 | 0.000919 | 4 |
| 10.1021/je301095j | PROPblock_4 | 283.15 | 313.15 | 0.000831 | 0.001459 | 0.001119 | 5 |
| 10.1021/je400630f | PROPblock_1 | 283.15 | 313.15 | 0.000842 | 0.001475 | 0.001101 | 6 |
| 10.1021/je400968v | PROPblock_2 | 293.15 | 333.15 | 0.000564 | 0.001179 | 0.000839 | 5 |
| 10.1021/je700318e | PROPblock_2 | 298.15 | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1021/je700618y | PROPblock_6 | 298.15 | 298.15 | 0.001076 | 0.001076 | 0.001076 | 1 |
| 10.1021/je700710d | PROPblock_2 | 298.15 | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |
| 10.1021/je800899w | PROPblock_6 | 298.15 | 298.15 | 0.001054 | 0.001054 | 0.001054 | 1 |
| 10.1021/je900998f | PROPblock_2 | 298.15 | 298.15 | 0.001082 | 0.001082 | 0.001082 | 1 |

**Excluded (T range does not include 298 K):** 2 blocks — `10.1016/j.fluid.2007.08.006` (303–313 K) and `10.1021/je800633a` (303.15 K only).

**At exactly 298.15 K**, reported values cluster around **0.00107–0.0011 Pa·s** (1.07–1.10 mPa·s).

---

### 2. Concentric cylinders viscometry — 3 blocks

| DOI | block | T_min (K) | T_max (K) | η_min | η_max | η_mean | n |
|-----|-------|-----------|-----------|-------|-------|--------|---|
| 10.1016/j.jct.2018.02.022 | PROPblock_3 | 293.15 | 308.15 | 0.000904 | 0.001202 | 0.001047 | 4 |
| 10.1021/acs.jced.8b00793 | PROPblock_2 | 293.15 | 323.15 | 0.00071 | 0.00123 | 0.000953 | 4 |
| 10.1021/je200600p | PROPblock_3 | 293.15 | 333.15 | 0.000576 | 0.001141 | 0.00082 | 9 |

All three ranges span 298 K.

---

### 3. Falling or rolling sphere viscometry — 26 blocks

| DOI | block | T_min (K) | T_max (K) | η_min | η_max | η_mean | n |
|-----|-------|-----------|-----------|-------|-------|--------|---|
| 10.1007/s10765-005-8089-2 | PROPblock_1 | 293.15 | 353.15 | 0.00051 | 0.001955 | 0.001049 | 23 |
| 10.1016/j.fluid.2006.01.030 | PROPblock_1 | 293.15 | 353.15 | 0.00051 | 0.001955 | 0.001076 | 20 |
| 10.1016/j.jct.2009.06.023 | PROPblock_1 | 283.15 | 333.15 | 0.000587 | 0.001418 | 0.00093 | 11 |
| 10.1016/j.jct.2012.10.008 | PROPblock_6 | 293.15 | 313.15 | 0.000836 | 0.001218 | 0.001023 | 5 |
| 10.1016/j.jct.2013.09.044 | PROPblock_6 | 298.2 | 298.2 | 0.001187 | 0.001187 | 0.001187 | 1 |
| 10.1016/j.jct.2013.11.026 | PROPblock_17 | 298.15 | 298.15 | 0.001125 | 0.001125 | 0.001125 | 1 |
| 10.1016/j.jct.2015.04.027 | PROPblock_4 | 293.15 | 313.15 | 0.000829 | 0.001186 | 0.000998 | 5 |
| 10.1016/j.jct.2017.07.022 | PROPblock_2 | 288.15 | 318.15 | 0.000747 | 0.001286 | 0.000993 | 7 |
| 10.1016/j.jct.2019.04.023 | PROPblock_5 | 293.15 | 323.15 | 0.000697 | 0.001177 | 0.000912 | 7 |
| 10.1021/acs.jced.5b00365 | PROPblock_4 | 293.15 | 323.15 | 0.000698 | 0.001177 | 0.000914 | 7 |
| 10.1021/acs.jced.6b00096 | PROPblock_2 | 298.15 | 318.15 | 0.000752 | 0.001084 | 0.000918 | 2 |
| 10.1021/acs.jced.6b00563 | PROPblock_3 | 298.15 | 318.15 | 0.000758 | 0.001083 | 0.000914 | 3 |
| 10.1021/acs.jced.7b00267 | PROPblock_2 | 293.15 | 333.15 | 0.000594 | 0.001194 | 0.000855 | 9 |
| 10.1021/acs.jced.7b00944 | PROPblock_6 | 298.2 | 298.2 | 0.00104 | 0.00104 | 0.00104 | 1 |
| 10.1021/acs.jced.8b00086 | PROPblock_17 | 298.2 | 298.2 | 0.001056 | 0.001056 | 0.001056 | 1 |
| 10.1021/acs.jced.8b00939 | PROPblock_12 | 298.15 | 298.15 | 0.00113 | 0.00113 | 0.00113 | 1 |
| 10.1021/acs.jced.8b00965 | PROPblock_4 | 293.15 | 333.15 | 0.000593 | 0.001195 | 0.000862 | 5 |
| 10.1021/je0500633 | PROPblock_1 | 293.15 | 313.15 | 0.00081 | 0.00116 | 0.000979 | 3 |
| 10.1021/je0501639 | PROPblock_2 | 298.15 | 318.15 | 0.000756 | 0.001085 | 0.000916 | 3 |
| 10.1021/je200707b | PROPblock_5 | 293.15 | 313.15 | 0.000842 | 0.

## 8. execute_sql

## Compacted Result

**Query goal:** List viscosity values at exactly 298.15 K from capillary tube (Ostwald/Ubbelohde) measurements of pure ethanol, for blocks with a single data point.

### Result: **Zero rows returned**

No blocks matched all of the following combined filters:
- Pure ethanol (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`, 1-component system)
- Property `GLOBprop_4` (viscosity) with exactly 1 data point
- Viscosity between 0.001 and 0.0012 Pa·s
- Method: "Capillary tube (Ostwald; Ubbelohde)"
- Temperature variable between 297 and 299 K

**Implication:** The query cannot support either task (listing values or showing spread). The empty result may be due to:
- Single-data-point blocks at 298.15 K not existing for this method, or
- Temperature being stored as a constraint rather than a variable in single-point blocks, or
- The viscosity or temperature range filters being too narrow for the indexed min/max values.

No rows were omitted; the raw result itself contained zero rows.

## 9. execute_sql

## Viscosity of Pure Liquid Ethanol at ~298.15 K — Falling/Rolling Sphere Method (Single-Point Blocks)

**6 results returned (not truncated).**

| DOI | Block | Viscosity (Pa·s) | T (K) |
|---|---|---|---|
| 10.1021/acs.jced.7b00944 | PROPblock_6 | 0.00104 | 298.20 |
| 10.1021/acs.jced.8b00086 | PROPblock_17 | 0.001056 | 298.20 |
| 10.1021/je500380x | PROPblock_4 | 0.001083 | 298.15 |
| 10.1016/j.jct.2013.11.026 | PROPblock_17 | 0.001125 | 298.15 |
| 10.1021/acs.jced.8b00939 | PROPblock_12 | 0.001130 | 298.15 |
| 10.1016/j.jct.2013.09.044 | PROPblock_6 | 0.001187 | 298.20 |

### Spread of reported values

| Statistic | Value |
|---|---|
| Minimum | 0.00104 Pa·s |
| Maximum | 0.001187 Pa·s |
| Range | 0.000147 Pa·s |
| Count | 6 |

## 10. execute_sql

## Compacted Result

**Query:** Capillary tube single-point viscosity measurements of pure ethanol (~298 K) where temperature is stored as a constraint (not a variable).

**Result: 0 rows returned.**

No blocks were found matching all of these criteria simultaneously:
- Pure ethanol (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`), single-component
- Property `GLOBprop_4` (viscosity)
- Method: `Capillary tube (Ostwald; Ubbelohde)`
- Exactly 1 data point per block (`n_values = 1`)
- Viscosity between 0.0009 and 0.0013 Pa·s

**Task assessment:**
1. **List viscosity values at ~298 K from capillary tube measurements:** No values found under these filters.
2. **Check if temperature is stored as constraint:** Cannot be assessed — no matching blocks exist, so the LEFT JOIN on temperature constraints produced no rows either.

## 11. execute_sql

## Compacted Result

### Query Context
Examined block structure for DOI `10.1016/j.fluid.2006.01.008` looking for pure ethanol (InChIKey `LFQSCWFLJHTTHZ-UHFFFAOYSA-N`) viscosity blocks measured by "Capillary tube (Ostwald; Ubbelohde)".

### Result: **Zero rows returned**

No rows matched the combined filter of:
- Pure ethanol (`n_components = 1`)
- Property `GLOBprop_4` (viscosity)
- Method name `Capillary tube (Ostwald; Ubbelohde)`
- DOI `10.1016/j.fluid.2006.01.008`

### Implications for the two tasks

1. **Temperature as variable vs. constraint:** Cannot be determined from this query — no matching blocks were found. The DOI may not contain capillary-tube viscosity data for pure ethanol, or the method name / prop_num_id may not match exactly for this paper.

2. **Block structure for single-point capillary tube measurements:** No structural information available from this result. A broader query (e.g., relaxing the DOI or method-name filter) is needed to find an example block.

## 12. execute_sql

## Compacted Result

**DOI:** `10.1016/j.fluid.2006.01.008`

### BLKprop_id Linkage

Both `block_measurements.BLKprop_id` and `block_properties.BLKprop_id` match as **`BLKprop_1`** across all rows — the join on `(doi, block_number)` works, and the BLKprop_id values are consistent.

### Method for Viscosity Blocks

| Field | Value |
|---|---|
| **method_name** | Capillary tube (Ostwald; Ubbelohde) method |
| **method_type** | standard |
| **meas_num_id** | GLOBmeas_4 |
| **prop_name** | Viscosity, Pa*s |
| **prop_num_id** (filter) | GLOBprop_4 |

### Blocks with Viscosity + This Method (9 blocks)

`PROPblock_3`, `PROPblock_7`, `PROPblock_11`, `PROPblock_15`, `PROPblock_19`, `PROPblock_21`, `PROPblock_25`, `PROPblock_29`, `PROPblock_33`

**Key finding:** All 9 viscosity blocks in this DOI use the same single method — **Capillary tube (Ostwald; Ubbelohde)**. There is no variation in method across blocks. The multiple blocks likely correspond to different mixture compositions or conditions, not different measurement methods.

## 13. execute_sql

## Result

The query returned **1 distinct method_name** string for capillary tube viscometry in pure-ethanol viscosity blocks:

| method_name |
|---|
| `Capillary tube (Ostwald; Ubbelohde) method` |

## 14. execute_sql

## Capillary Tube (Ostwald/Ubbelohde) Viscosity of Pure Ethanol at 298.15 K

13 single-point measurements found, all at **T = 298.15 K**.

| # | DOI | Viscosity (Pa·s) |
|---|-----|----------------:|
| 1 | 10.1021/je800899w | 0.001054 |
| 2 | 10.1021/je700618y | 0.001076 |
| 3 | 10.1016/j.fluid.2006.01.008 | 0.001077 |
| 4 | 10.1016/j.fluid.2007.03.021 | 0.001082 |
| 5 | 10.1021/je700318e | 0.001082 |
| 6 | 10.1021/je700710d | 0.001082 |
| 7 | 10.1021/je900998f | 0.001082 |
| 8 | 10.1016/j.jct.2012.02.027 | 0.001087 |
| 9 | 10.1021/je201152j | 0.001091 |
| 10 | 10.1016/j.jct.2005.04.019 | 0.001093 |
| 11 | 10.1016/j.jct.2016.12.036 | 0.001093 |
| 12 | 10.1021/acs.jced.5b00162 | 0.001103 |
| 13 | 10.1021/je034203p | 0.001112 |

### Spread of reported values

| Statistic | Value (Pa·s) |
|-----------|------------:|
| Minimum | 0.001054 |
| Maximum | 0.001112 |
| Range | 0.000058 |
| Most common value | 0.001082 (4 sources) |

## 15. execute_sql

## Concentric Cylinders Viscosity Blocks for Pure Ethanol

**3 blocks found**, all covering temperatures that include ~298 K.

| DOI | Block | Viscosity min (Pa·s) | n_values | T_min (K) | T_max (K) | Covers ~298 K? |
|-----|-------|---------------------|----------|-----------|-----------|----------------|
| 10.1016/j.jct.2018.02.022 | PROPblock_3 | 0.000904 | 4 | 293.15 | 308.15 | Yes |
| 10.1021/acs.jced.8b00793 | PROPblock_2 | 0.00071 | 4 | 293.15 | 323.15 | Yes |
| 10.1021/je200600p | PROPblock_3 | 0.000576 | 9 | 293.15 | 333.15 | Yes |

**Notes:**
- All three blocks span a temperature range that includes 298.15 K (25 °C).
- The `viscosity_Pa_s` column shows the **minimum** viscosity value in each block (not necessarily the value at 298 K). Exact data points at 298 K would need to be extracted from the full JSON card data.
- No rows were truncated; this is the complete result set.

## 16. execute_sql

## Compacted Result: Data Points at 298.15 K from Selected Blocks

**4 rows returned, no truncation.**

| DOI | T (K) | Property Value | Expanded Uncertainty | Notes |
|-----|--------|---------------|---------------------|-------|
| 10.1016/j.jct.2018.02.022 | 298.15 | 1143.5 | 1.78 | Likely density (kg/m³) or other property — not viscosity |
| 10.1016/j.jct.2018.02.022 | 298.15 | 0.0010914 | 0.0001529 | Likely viscosity (Pa·s) ≈ 1.0914 mPa·s |
| 10.1021/je200600p | 298.15 | 786.55 | 0.17 | Likely density (kg/m³) — matches ethanol density |
| 10.1021/je200600p | 298.15 | 0.0010371 | 1.01×10⁻⁵ | Likely viscosity (Pa·s) ≈ 1.0371 mPa·s |

### Key observations for the tasks

1. **Concentric cylinders values at 298.15 K**: The query targeted blocks identified as concentric-cylinders method. Two DOIs returned viscosity-scale values:
   - **10.1016/j.jct.2018.02.022**: 0.0010914 Pa·s (U = 0.0001529)
   - **10.1021/je200600p**: 0.0010371 Pa·s (U = 1.01×10⁻⁵)

2. **Comparison with capillary tube / falling sphere**: The third DOI (`10.1021/acs.jced.8b00793`) returned **no rows** matching the block/temperature filter, so no capillary-tube or falling-sphere data was extracted by this query. Additional queries with corrected block numbers for that DOI would be needed.

3. **Caveat**: The block filter used `IN ('PROPblock_3', 'PROPblock_2', 'PROPblock_3')` — the duplicate `PROPblock_3` means effectively only blocks 2 and 3 were searched. Each DOI returned two properties per temperature point (one density-scale, one viscosity-scale), but the property names are not resolved in this query (only `BLKprop_1` identifiers appear).

## 17. execute_sql

## Measurement Method Domain Knowledge

Three viscosity measurement methods were retrieved. All are classified as **"standard"** type and all have domain knowledge available (`has_domain_knowledge = 1`).

| meas_num_id | meas_id | Full Method Name | method_type |
|---|---|---|---|
| GLOBmeas_4 | capillary_tube_ostwald_ubbelohde_method | Capillary tube (Ostwald; Ubbelohde) method | standard |
| GLOBmeas_8 | falling_or_rolling_sphere_viscometry | Falling or rolling sphere viscometry | standard |
| GLOBmeas_11 | concentric_cylinders_viscometry | Concentric cylinders viscometry | standard |

**Note:** This query returned only the method identifiers and names. The detailed domain-knowledge descriptions (stored in `json_data`) were not selected, so full textual descriptions of each method's operating principle are not included in this result.

## 18. execute_sql

## Standard Methods for Pure Ethanol Viscosity: Block & Paper Counts

| Method | Total Blocks | Papers |
|---|--:|--:|
| Capillary tube (Ostwald; Ubbelohde) method | 38 | 38 |
| Falling or rolling sphere viscometry | 26 | 25 |
| Concentric cylinders viscometry | 3 | 3 |

- **3 distinct standard methods** found across **67 total data blocks** from **66 unique papers** (one paper contributes 2 blocks for falling/rolling sphere).
- No truncation; result is complete (3 rows).

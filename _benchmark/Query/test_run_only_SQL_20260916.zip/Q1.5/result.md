# Q1.5 — Result

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

- **Status:** OK
- **Effort:** high
- **Tool calls:** 18
- **API turns:** 15
- **Soft-budget threshold:** turn 20
- **Budget strikes issued:** 0
- **Forced final turn:** False
- **Fresh final context:** 0 characters
- **Elapsed:** 406.4s
- **Timed out:** False

## Answer

Now I have all the evidence needed. Let me compile the comprehensive answer.

---

## Viscosity of Pure Liquid Ethanol near 25 °C: Methods and Reported Values

### Overview

The ThermoML database contains **67 data blocks** from **66 published papers** reporting the dynamic viscosity (Pa·s) of pure liquid ethanol, measured using **three distinct standard methods**. The well-established literature value for ethanol viscosity at 25 °C (298.15 K) is approximately **1.08 mPa·s (0.00108 Pa·s)**, and the database values cluster tightly around this figure.

---

### The Three Measurement Methods

#### 1. Capillary Tube (Ostwald / Ubbelohde) Viscometry
- **Principle:** Measures the time for a fixed volume of liquid to flow through a narrow-bore glass capillary under gravity. The Ubbelohde variant uses a suspended-level design that makes the measurement independent of the total sample volume. Viscosity is calculated from the flow time using the Hagen–Poiseuille equation (with kinetic energy corrections).
- **Prevalence:** **38 data blocks from 38 papers** — the most widely used method.
- **Values at 298.15 K (13 single-point measurements):**

| Viscosity (mPa·s) | DOI |
|---:|---|
| 1.054 | 10.1021/je800899w |
| 1.076 | 10.1021/je700618y |
| 1.077 | 10.1016/j.fluid.2006.01.008 |
| 1.082 | 10.1016/j.fluid.2007.03.021 |
| 1.082 | 10.1021/je700318e |
| 1.082 | 10.1021/je700710d |
| 1.082 | 10.1021/je900998f |
| 1.087 | 10.1016/j.jct.2012.02.027 |
| 1.091 | 10.1021/je201152j |
| 1.093 | 10.1016/j.jct.2005.04.019 |
| 1.093 | 10.1016/j.jct.2016.12.036 |
| 1.103 | 10.1021/acs.jced.5b00162 |
| 1.112 | 10.1021/je034203p |

- **Range:** 1.054 – 1.112 mPa·s (spread of only 0.058 mPa·s)
- **Most common value:** 1.082 mPa·s (reported by 4 independent sources)

#### 2. Falling or Rolling Sphere (Ball) Viscometry
- **Principle:** A sphere (typically steel or glass) falls or rolls through the liquid in a calibrated tube. The terminal velocity is governed by the balance between gravity, buoyancy, and viscous drag (Stokes' law). Modern instruments (e.g., Anton Paar Lovis or AMVn rolling-ball viscometers) automate this measurement at controlled temperatures and pressures.
- **Prevalence:** **26 data blocks from 25 papers** — the second most common method.
- **Values at ~298.15 K (6 single-point measurements):**

| Viscosity (mPa·s) | T (K) | DOI |
|---:|---:|---|
| 1.040 | 298.20 | 10.1021/acs.jced.7b00944 |
| 1.056 | 298.20 | 10.1021/acs.jced.8b00086 |
| 1.083 | 298.15 | 10.1021/je500380x |
| 1.125 | 298.15 | 10.1016/j.jct.2013.11.026 |
| 1.130 | 298.15 | 10.1021/acs.jced.8b00939 |
| 1.187 | 298.20 | 10.1016/j.jct.2013.09.044 |

- **Range:** 1.040 – 1.187 mPa·s (spread of 0.147 mPa·s)
- **Note:** The spread is wider than for capillary tube measurements, which may reflect differences in instrument calibration, sample purity, or the inherent sensitivity of the rolling-ball technique to surface effects.

#### 3. Concentric Cylinders (Couette / Rotational) Viscometry
- **Principle:** The liquid fills the annular gap between two coaxial cylinders; one cylinder rotates while the other is stationary. The torque required to maintain a given rotation rate (or the resulting rotation rate at a given torque) is directly proportional to the viscosity. This method is especially suited for higher-viscosity fluids but is also used for low-viscosity liquids.
- **Prevalence:** **3 data blocks from 3 papers** — the least common method for ethanol.
- **Values at 298.15 K (extracted from JSON):**

| Viscosity (mPa·s) | Expanded Uncertainty | DOI |
|---:|---:|---|
| 1.037 | ±0.010 | 10.1021/je200600p |
| 1.091 | ±0.153 | 10.1016/j.jct.2018.02.022 |

- The larger uncertainty in the second measurement is notable and may reflect the lower precision of rotational viscometry for low-viscosity fluids like ethanol.

---

### Comparison Across Methods

| Method | Papers | Blocks | η at 298.15 K (mPa·s) | Typical Range |
|---|--:|--:|---|---|
| Capillary tube (Ubbelohde) | 38 | 38 | **1.054 – 1.112** | Tight clustering around 1.08 |
| Falling/rolling sphere | 25 | 26 | **1.040 – 1.187** | Wider spread |
| Concentric cylinders | 3 | 3 | **1.037 – 1.091** | Limited data |

### Chemical & Physical Insights

1. **Excellent inter-method agreement:** All three fundamentally different techniques converge on a viscosity of approximately **1.08 ± 0.04 mPa·s** at 25 °C, confirming ethanol as a reliable calibration/reference liquid.

2. **Capillary viscometry dominates:** The Ubbelohde capillary viscometer is the gold standard for low-viscosity Newtonian liquids. Its prevalence (57% of all blocks) reflects its simplicity, high precision, and well-understood corrections. The remarkably tight clustering (±2.7% around the median) demonstrates excellent reproducibility.

3. **Falling-ball viscometry shows more scatter:** The wider spread (±7%) may arise from: (a) sensitivity to sphere surface quality and alignment, (b) different instrument models with varying calibration protocols, and (c) the fact that some measurements were at 298.20 K rather than exactly 298.15 K.

4. **Temperature sensitivity:** Ethanol's viscosity is strongly temperature-dependent near 25 °C. Across the broader datasets, values range from ~0.5 mPa·s at 50–60 °C to ~1.9 mPa·s near 0 °C, reflecting the disruption of hydrogen-bonding networks with increasing temperature. Even a 0.05 K difference can shift the viscosity by ~0.001 mPa·s.

5. **Molecular origin:** Ethanol's viscosity (~1.08 mPa·s) is slightly higher than water (~0.89 mPa·s) at 25 °C despite its lower density, because ethanol molecules form extensive hydrogen-bonding chains through their –OH groups while also experiencing van der Waals interactions along their ethyl chains. This dual interaction mechanism creates additional resistance to flow.

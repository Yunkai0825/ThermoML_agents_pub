# Q1.5 — Reference Statistics

| Variant | Model | Compactor Model | Status | API turns | Tool calls | Elapsed (s) |
|---|---|---|---:|---:|---:|---:|
| Flat / parsed-card SQL | claude-opus-4-6 | claude-opus-4-6 | OK | 15 | 18 | 406.4 |

## Token usage

| Role | Calls | Input tokens | Output tokens | Cache-create | Cache-read |
|---|---:|---:|---:|---:|---:|
| Answering agent | 15 | 256636 | 9028 | 0 | 0 |
| Result compactor(s) | 18 | 94052 | 13990 | 0 | 0 |

## Turn budget

- API effort: high
- Soft escalation begins: turn 20
- Configured strikes: 3
- Hard final turn: 22
- Strikes issued: 0
- Forced final chance reached: False
- Fresh final context characters: 0
- Fresh final context SHA-256: n/a
- Tool request on final chance: False

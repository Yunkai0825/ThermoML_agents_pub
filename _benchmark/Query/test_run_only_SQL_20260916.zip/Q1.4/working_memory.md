# Q1.4 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Lithium Chloride — Compound Registry Results

| Field | Lithium Chloride | Lithium Chloride Monohydrate |
|---|---|---|
| **comp_num_id** | `GLOBcomp_107` | `GLOBcomp_7614` |
| **comp_id** | lithium_chloride | lithium_chloride_monohydrate |
| **inchi_key** | KWGKDLIKAYFUFQ-UHFFFAOYSA-M | VXJIMUZIBHBWBV-UHFFFAOYSA-M |
| **formula** | ClLi | ClH2LiO |
| **smiles** | [Cl-].[Li+] | O.[Cl-].[Li+] |

**Primary identifier for further queries:** `GLOBcomp_107` (lithium chloride). The monohydrate entry (`GLOBcomp_7614`) may also be relevant depending on how data were registered.

## 2. execute_sql

## Activity Coefficient Property Types in the Registry

| prop_num_id | prop_id | prop_name | prop_group |
|---|---|---|---|
| **GLOBprop_3** | `activity_coefficient_{DOIcomp_id}` | Activity coefficient | ActivityFugacityOsmoticProp |
| **GLOBprop_56** | `mean_ionic_activity_coefficient_{DOIcomp_id}` | Mean ionic activity coefficient | ActivityFugacityOsmoticProp |

**2 rows returned; no truncation.**

**Note:** For aqueous LiCl, the relevant property is most likely **GLOBprop_56** (mean ionic activity coefficient), since LiCl is an electrolyte.

## 3. execute_sql

## Activity Coefficient Data Blocks for Lithium Chloride

**Source:** All 5 blocks come from a single paper.

| DOI | Block | System Type | Compound System | n_datapoints |
|-----|-------|-------------|-----------------|--------------|
| 10.1016/j.fluid.2014.08.026 | PROPblock_13 | binary | lithium chloride + water | 141 |
| 10.1016/j.fluid.2014.08.026 | PROPblock_9 | ternary | urea + lithium chloride + water | 130 |
| 10.1016/j.fluid.2014.08.026 | PROPblock_10 | ternary | N-methylformamide + lithium chloride + water | 144 |
| 10.1016/j.fluid.2014.08.026 | PROPblock_11 | ternary | dimethylformamide + lithium chloride + water | 156 |
| 10.1016/j.fluid.2014.08.026 | PROPblock_12 | ternary | N,N-dimethylethanamide + lithium chloride + water | 134 |

**Total data points across all blocks: 705**

### Property measured

All blocks report **Mean ionic activity coefficient**.

| Block | γ± min | γ± max | γ± mean | n |
|-------|--------|--------|---------|---|
| PROPblock_13 (binary) | 0.7406 | 0.9425 | 0.8079 | 141 |
| PROPblock_9 | 0.7408 | 0.9489 | 0.8352 | 130 |
| PROPblock_10 | 0.7406 | 1.0587 | 0.8335 | 144 |
| PROPblock_11 | 0.6751 | 0.9435 | 0.7871 | 156 |
| PROPblock_12 | 0.6378 | 0.9414 | 0.7723 | 134 |

### Temperature & pressure (constraints, all blocks)

- **Temperature: 298.15 K (25 °C)** — all five blocks
- **Pressure: 101.0 kPa** — all five blocks

### Concentration ranges (variables)

| Block | Molality range (mol/kg) | Cosolvent mass-fraction range |
|-------|------------------------|-------------------------------|
| PROPblock_13 (binary) | 0.0033 – 1.5555 | — |
| PROPblock_9 | 0.0035 – 1.5617 | 0.0 – 0.4 |
| PROPblock_10 | 0.0028 – 1.5555 | 0.0 – 0.4 |
| PROPblock_11 | 0.0022 – 1.4819 | 0.0 – 0.4 |
| PROPblock_12 | 0.0028 – 1.5886 | 0.0 – 0.4 |

**Summary:** For the pure aqueous (binary) system, LiCl activity coefficients span molalities of ~0.003 to ~1.56 mol/kg at exactly 25 °C. The ternary systems cover similar molality ranges with cosolvent mass fractions up to 0.4.

## 4. execute_sql

## Compacted Result

**Block:** DOI `10.1016/j.fluid.2014.08.026`, `PROPblock_13`

| Field | Value |
|---|---|
| **Property** | Mean ionic activity coefficient |
| **Phase** | liquid |
| **Min value** | 0.7406 |
| **Max value** | 0.9425 |
| **Mean value** | 0.807865 |
| **N data points** | 141 |

### Task check
1. **Property confirmed:** Mean ionic activity coefficient.
2. **Measured value range:** 0.7406 – 0.9425 (141 values).
3. **Phase:** liquid.

## 5. execute_sql

## Compacted Result

### Variables in PROPblock_13 (LiCl + water, DOI 10.1016/j.fluid.2014.08.026)

| var_name | min_value | max_value | n_unique | var_type_key |
|---|---|---|---|---|
| Molality, mol/kg | 0.0033 | 1.5555 | 139 | eComponentComposition |

### Key findings

1. **Concentration variable:** Molality (mol/kg), ranging from **0.0033** to **1.5555** mol/kg, with **139** unique values.
2. **Temperature:** Temperature is **not** listed as a variable in this block — it must appear only as a constraint (fixed value, presumably ~25 °C).

## 6. execute_sql

## Measurement Method for Activity Coefficient Data

| Field | Value |
|-------|-------|
| **method_type** | custom |
| **method_name** | Calculated from EMF cell potential |
| **meas_id** | calculated_from_emf_cell_potential |

**Source:** DOI `10.1016/j.fluid.2014.08.026`, block `PROPblock_13` (1 row returned, no truncation).

## 7. execute_sql

## Bibliographic Details for DOI 10.1016/j.fluid.2014.08.026

| Field | Value |
|---|---|
| **Title** | Investigating thermodynamic properties of LiCl in amide–water mixtures with e-increasing and e-decreasing solvent at 298.15 K |
| **Year** | 2014 |
| **Journal** | Fluid Phase Equilib. |
| **First Author** | Zhao, X. [Xuehong] |
| **DOI** | 10.1016/j.fluid.2014.08.026 |

*Additional context: the paper covers 6 compounds across 13 data blocks (742 total data points).*

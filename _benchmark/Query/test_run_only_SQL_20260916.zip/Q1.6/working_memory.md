# Q1.6 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Property Registry: Heat Capacity Entries

| prop_num_id | prop_id | prop_name | prop_group |
|---|---|---|---|
| **GLOBprop_9** | **molar_heat_capacity_at_constant_pressure_j_k_mol** | **Molar heat capacity at constant pressure, J/K/mol** | HeatCapacityAndDerivedProp |
| GLOBprop_43 | molar_heat_capacity_at_saturation_pressure_j_k_mol | Molar heat capacity at saturation pressure, J/K/mol | HeatCapacityAndDerivedProp |
| GLOBprop_63 | heat_capacity_at_constant_pressure_per_volume_j_k_m3 | Heat capacity at constant pressure per volume, J/K/m3 | HeatCapacityAndDerivedProp |
| GLOBprop_64 | apparent_molar_heat_capacity_j_k_mol | Apparent molar heat capacity, J/K/mol | ExcessPartialApparentEnergyProp |
| GLOBprop_72 | molar_heat_capacity_at_constant_volume_j_k_mol | Molar heat capacity at constant volume, J/K/mol | HeatCapacityAndDerivedProp |
| GLOBprop_81 | specific_heat_capacity_at_constant_pressure_j_k_kg | Specific heat capacity at constant pressure, J/K/kg | HeatCapacityAndDerivedProp |
| GLOBprop_85 | excess_molar_heat_capacity_j_k_mol | Excess molar heat capacity, J/K/mol | ExcessPartialApparentEnergyProp |

**Key finding:** The correct entry for molar isobaric heat capacity (Cp,m) is:
- **prop_num_id:** `GLOBprop_9`
- **prop_id:** `molar_heat_capacity_at_constant_pressure_j_k_mol`
- **prop_name:** Molar heat capacity at constant pressure, J/K/mol

7 rows returned; no truncation.

## 2. execute_sql

## Water Compound Registry Entry

| Field | Value |
|---|---|
| **comp_num_id** | `GLOBcomp_1` |
| comp_id | water |
| InChIKey | XLYOFNOQVPJJNP-UHFFFAOYSA-N |
| common_name | water |
| formula | H2O |
| SMILES | O |

A second row for **water-d2** (D₂O, `GLOBcomp_241`) was returned but is not relevant to the question about ordinary water.

## 3. execute_sql

## Compacted SQL Result

### Query Goal
Find data blocks reporting molar isobaric heat capacity (Cp,m) for pure water (single-component, `GLOBcomp_1`, property `GLOBprop_9`).

### Result
**Zero rows returned.** No blocks in the database match the criteria of property `GLOBprop_9` (molar isobaric heat capacity) for a single-component pure-water system (`GLOBcomp_1`).

### Implications for Tasks
1. **DOIs and block numbers with Cp,m data for pure water:** None found.
2. **Value ranges near 298.15 K:** No data to check — the query returned no rows.
3. **Phase (liquid):** No phase information available since no matching records exist.

### Possible Reasons
- The property num ID (`GLOBprop_9`) or compound num ID (`GLOBcomp_1`) may not correspond to molar isobaric heat capacity or water, respectively. These identifiers should be verified against `idx.prop_registry` and `idx.compound_registry`.
- Cp,m data for pure water may exist under a different property ID (e.g., specific heat capacity rather than molar), or water may be registered under a different compound num ID.

## 4. execute_sql

## Compacted Result: Heat Capacity Measurements for Pure Water

### Summary
- **20 rows returned** (limit reached; more may exist in DB)
- **Compound**: Water (comp_num_id = `GLOBcomp_1`), single-component blocks only
- **Property variants found**:
  - **Molar heat capacity at constant pressure** (`GLOBprop_9`, "Molar heat capacity at constant pressure, J/K/mol") — 19 of 20 rows
  - **Molar heat capacity at saturation pressure** (`GLOBprop_43`, "Molar heat capacity at saturation pressure, J/K/mol") — 1 row
- No specific (mass-based) heat capacity (`GLOBprop_81`, `GLOBprop_72`, `GLOBprop_63`) rows were returned.

### Liquid-Phase Blocks (relevant to 25 °C / 1 atm question)

| DOI | block_number | prop_num_id | prop_name | min_value | max_value | mean_value | n_values |
|-----|-------------|-------------|-----------|-----------|-----------|------------|----------|
| 10.1016/j.fluid.2016.07.034 | PROPblock_3 | GLOBprop_9 | Molar Cp, J/K/mol | 74.577855 | 104.340899 | 80.904132 | 34 |
| 10.1016/j.fluid.2014.03.017 | PROPblock_3 | GLOBprop_9 | Molar Cp, J/K/mol | 73.70051 | 76.438833 | 75.496891 | 28 |
| 10.1016/j.fluid.2013.08.007 | PROPblock_3 | GLOBprop_9 | Molar Cp, J/K/mol | 73.71 | 75.58 | 74.740435 | 23 |
| 10.1016/j.tca.2018.04.018 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 75.285855 | 83.915174 | 78.202211 | 17 |
| 10.1016/j.jct.2009.01.011 | PROPblock_8 | GLOBprop_9 | Molar Cp, J/K/mol | 75.26784 | 76.006466 | 75.508794 | 16 |
| 10.1016/j.jct.2005.10.010 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 74.318435 | 75.903779 | 75.199021 | 15 |
| 10.1016/j.fluid.2006.03.015 | PROPblock_22 | GLOBprop_9 | Molar Cp, J/K/mol | 74.9 | 75.8 | 75.254286 | 14 |
| 10.1021/acs.jced.7b00483 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 75.447993 | 76.024482 | 75.61013 | 14 |
| 10.1016/j.tca.2016.06.015 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 72.961884 | 78.006162 | 75.634151 | 12 |
| 10.1016/j.jct.2016.08.006 | PROPblock_3 | GLOBprop_9 | Molar Cp, J/K/mol | 75.26 | 75.78 | 75.4 | 11 |
| 10.1021/je9002948 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 75.285855 | 75.484023 | 75.39886 | 11 |
| 10.1016/j.fluid.2016.10.005 | PROPblock_2 | GLOBprop_9 | Molar Cp, J/K/mol | 75.316481 | 75.750649 | 75.453798 | 9 |
| 10.1007/s10765-019-2558-5 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 76.204634 | 76.402802 | 76.292459 | 8 |
| 10.1016/j.fluid.2013.08.005 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 75.316481 | 75.368725 | 75.337199 | 8 |
| 10.1016/j.jct.2013.10.028 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 75.411962 | 75.466008 | 75.447993 | 8 |
| 10.1021/je020042y | PROPblock_6 | GLOBprop_43 | Molar Cp at sat. pressure, J/K/mol | 75.29 | 75.47 | 75.345714 | 7 |
| 10.1021/je800248w | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 75.0 | 75.0 | 75.0 | 7 |
| 10.1016/j.jct.2008.10.002 | PROPblock_1 | GLOBprop_9 | Molar Cp, J/K/mol | 75.2 | 75.4 | 75.283333 | 6 |

### Crystal-Phase Blocks (omitted from detail)
Two rows from DOI `10.1016/j.jct.2006.10.011` (PROPblock_1, PROPblock_2) report crystal-phase Cp with very low values (mean ~0.6 and ~1.3 J/K/mol); not relevant to liquid water at 25 °C.

### Key Notes
- Mean values for liquid-phase molar Cp cluster around **75–76 J/K/mol**, consistent with the well-known value of ~75.3 J/(K·mol) at 25 °C.
- These are block-level summary statistics (min/max/mean over all temperatures in each block). To extract the **exact value at 25 °C (298.15 K)**, the full JSON data from `pcs.cards.json_data` for a specific DOI/block must be queried.
- Best candidates for point extraction (narrow T-range near 298 K, liquid phase): `10.1021/je9002948` PROPblock_1, `10.1016/j.fluid.2013.08.005` PROPblock_1, `10.1016/j.jct.2013.10.028` PROPblock_1.

## 5. execute_sql

## Compacted Result

### Task 1: Do any pure water blocks exist?

**No.** The query returned **0 rows**. No blocks with `n_components = 1` and `comp_num_ids = 'GLOBcomp_1'` were found.

### Task 2: Properties measured for pure water

Not applicable — no pure water blocks exist under the identifier `GLOBcomp_1`, so no properties can be listed.

### Notes
- The compound identifier `GLOBcomp_1` may not correspond to water, or pure water data may be stored under a different `comp_num_id`. A lookup in `idx.compound_registry` for water (e.g., by formula `H2O`, InChIKey `XLYOFNOQVPJJNP-UHFFFAOYSA-N`, or name) would be needed to confirm the correct `comp_num_id`.

## 6. execute_sql

## Compacted Result

### Task 1: Exact Cp,m value at T = 298.15 K

**No data point at T = 298.15 K exists in this block.** The 11 data points (complete, not truncated) span **303.15 K to 353.15 K** in 5 K steps. The lowest temperature is 303.15 K (30 °C), so 298.15 K (25 °C) is not covered.

### All returned data points

| T (K) | Cp,m value | Expanded uncertainty |
|--------|------------|----------------------|
| 303.15 | 75.28585512 | ±1.5129232144 |
| 308.15 | 75.35791624 | ±1.5129232144 |
| 313.15 | 75.37593152 | ±1.5129232144 |
| 318.15 | 75.39394680 | ±1.5129232144 |
| 323.15 | 75.39394680 | ±1.5129232144 |
| 328.15 | 75.39394680 | ±1.5129232144 |
| 333.15 | 75.41196208 | ±1.5129232144 |
| 338.15 | 75.41196208 | ±1.5129232144 |
| 343.15 | 75.42997736 | ±1.5129232144 |
| 348.15 | 75.44799264 | ±1.5129232144 |
| 353.15 | 75.48402320 | ±1.5129232144 |

### Task 2: Pressure confirmation

Pressure is **not recorded as a variable** in these data points (only `BLKvar_1` = Temperature is present). It may be set as a block-level constraint (likely 101.325 kPa) but is not visible in this query's output — a separate query on block constraints would be needed to confirm.

### Task 3: Units

Units are **not explicitly present** in the data-point values returned here. Based on the block metadata (property = molar isobaric heat capacity), the expected units are **J·K⁻¹·mol⁻¹**, consistent with the magnitude (~75.3 J/K/mol for water). Confirmation would require inspecting the block's property definition.

### Key takeaway

The closest measured value to 25 °C is at **303.15 K (30 °C): Cp,m = 75.286 J·K⁻¹·mol⁻¹**. A different DOI or block would be needed to find a measurement at exactly 298.15 K.

## 7. execute_sql

## Compacted Result

**Source DOI:** `10.1016/j.jct.2008.10.002`

Two data points found at **T = 298.15 K**:

| Block | Property Value | Uncertainty | Likely Quantity |
|-------|---------------|-------------|-----------------|
| PROPblock_1 | **75.3** | ±1.2 | Cp,m (J·mol⁻¹·K⁻¹) — molar heat capacity |
| PROPblock_3 | 394.4 | ±6.1 | Likely a different property or specific Cp (J·g⁻¹·K⁻¹ seems too high; possibly a different block/property) |

### Notes
- **PROPblock_1** with value **75.3 J·mol⁻¹·K⁻¹** is consistent with the well-known isobaric molar heat capacity of pure liquid water at 25 °C.
- **Pressure conditions** are not explicitly included in the returned variable/property values; they are likely specified as a block-level constraint (typically 101.325 kPa / atmospheric pressure). A separate query on `block_constraints` for this DOI/block would confirm.
- Only 2 rows returned (no truncation). The other three DOIs yielded no matching data points for these block numbers at 298.15 K.

## 8. execute_sql

## Compacted Result

**Block:** DOI `10.1016/j.jct.2008.10.002`, `PROPblock_1`

### Constraints on this measurement block

| Constraint | Value | Type Key |
|---|---|---|
| Pressure, kPa | **101.325** | ePressure |

**Task 1 — Pressure confirmed:** The sole constraint is **101.325 kPa** (standard atmospheric pressure).

**Task 2 — Other constraints:** There are **no additional constraints** on this block (only 1 row returned).

## 9. execute_sql

## Compacted Result: Cp,m at 298.15 K from Multiple Sources

**26 rows returned, not truncated.**

### Pure-component (single-variable) data points at 298.15 K

These are the rows with **only** temperature as a variable (no second variable like molality), representing **pure liquid water** Cp,m:

| DOI | Block | Cp,m Value | Units context | Expanded Uncertainty |
|-----|-------|-----------|---------------|---------------------|
| 10.1016/j.fluid.2016.10.005 | PROPblock_1 | 479.716 | (likely J·kg⁻¹·K⁻¹ — specific, not molar) | ±18.57 |
| 10.1016/j.fluid.2016.10.005 | PROPblock_2 | **75.345** | (J·mol⁻¹·K⁻¹) | ±2.918 |
| 10.1021/acs.jced.7b00483 | PROPblock_1 | **75.664** | (J·mol⁻¹·K⁻¹) | ±0.162 |

### Mixture data points (excluded from pure-water comparison)

DOI `10.1021/acs.jced.7b00483`, blocks PROPblock_2 and PROPblock_3, contain **23 rows** with a second variable (BLKvar_2 = molality, ranging 0.14–4.45). These are **solution** Cp,m values (ranging ~69.3–74.5 J·mol⁻¹·K⁻¹), not pure water. Omitted from the pure-water comparison.

### No data returned for the other queried DOIs

The following DOIs produced **zero matching rows** at 298.15 K:
- 10.1016/j.fluid.2006.03.015
- 10.1016/j.fluid.2014.03.017
- 10.1016/j.tca.2016.06.015
- 10.1021/je800248w

### Summary for Tasks

| Task | Finding |
|------|---------|
| **Independent Cp,m values at 298.15 K (pure water)** | **75.345 J·mol⁻¹·K⁻¹** (10.1016/j.fluid.2016.10.005) and **75.664 J·mol⁻¹·K⁻¹** (10.1021/acs.jced.7b00483) |
| **Consistency** | Both molar values are in the ~75.3–75.7 J·mol⁻¹·K⁻¹ range; the 479.7 J·kg⁻¹·K⁻¹ specific heat is consistent (479.7 × 0.018015 ≈ 8.64 — likely different property or unit basis) |
| **Uncertainties** | ±2.92 J·mol⁻¹·K⁻¹ (fluid.2016) vs ±0.16 J·mol⁻¹·K⁻¹ (jced.7b00483) — the latter is substantially more precise |

## 10. execute_sql

## Pressure Constraints for the Two Blocks Reporting Cp,m at 298.15 K

| DOI | Block | Constraint | Value | Type Key |
|-----|-------|-----------|-------|----------|
| 10.1016/j.fluid.2016.10.005 | PROPblock_2 | Pressure, kPa | **101.0** | ePressure |
| 10.1021/acs.jced.7b00483 | PROPblock_1 | Pressure, kPa | **100.0** | ePressure |

### Summary

- **Neither block uses exactly 101.325 kPa.** One reports 101.0 kPa and the other 100.0 kPa — both are near-atmospheric but not identical to the standard 101.325 kPa.
- **No other constraints** were returned for either block (only 2 rows total, both pressure).

# Q1.2 — Working Memory

Evidence returned to the answering model:

## 1. execute_sql

## Compound Registry Lookup: Hexane & Ethanol

| comp_num_id | common_name | formula | inchi_key |
|---|---|---|---|
| **GLOBcomp_12** | hexane | C6H14 | VLKZOEOYAKHREP-UHFFFAOYSA-N |
| **GLOBcomp_2** | ethanol | C2H6O | LFQSCWFLJHTTHZ-UHFFFAOYSA-N |

### Key identifiers for subsequent queries
- **Hexane:** `GLOBcomp_12`
- **Ethanol:** `GLOBcomp_2`

### Note on additional matches
The query also returned 5 other compounds matching the same molecular formulas (C6H14 or C2H6O) — 2,2-dimethylbutane, 2,3-dimethylbutane, 2-methylpentane, 3-methylpentane, and dimethyl ether. These are **not** hexane or ethanol and can be disregarded for subsequent queries.

## 2. execute_sql

## Hexane + Ethanol Binary Mixture — Properties Found in ThermoML

**13 rows returned (not truncated). All blocks are binary (n_components = 2) with GLOBcomp_12 (hexane) + GLOBcomp_2 (ethanol).**

### Task 1: Distinct Properties & Groups

| prop_group | prop_name | phase_id |
|---|---|---|
| CompositionAtPhaseEquilibrium | Mole fraction | gas |
| Criticals | Critical pressure, kPa | liquid |
| Criticals | Critical temperature, K | liquid |
| ExcessPartialApparentEnergyProp | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | liquid |
| RefractionSurfaceTensionSoundSpeed | Refractive index (Na D-line) | liquid |
| RefractionSurfaceTensionSoundSpeed | Speed of sound, m/s | liquid |
| RefractionSurfaceTensionSoundSpeed | Surface tension liquid-gas, N/m | liquid |
| TransportProp | Binary diffusion coefficient, m2/s | liquid |
| TransportProp | Viscosity, Pa·s | liquid |
| VaporPBoilingTAzeotropTandP | Boiling temperature at pressure P, K | liquid |
| VolumetricProp | Excess molar volume, m3/mol | liquid |
| VolumetricProp | Mass density, kg/m3 | liquid |

### Task 3: Phase IDs

- **liquid** — 12 of 13 rows
- **gas** — 1 row (VLE mole-fraction data)

### Task 2: Temperature near 25 °C

> ⚠️ **This query did not retrieve temperature (variable/constraint) data.** The result contains only property ranges, not the temperature conditions of each block. A separate query on `idx.block_variables` or `idx.block_constraints` (filtering for temperature variable near 298.15 K) is needed to confirm which blocks have data near 25 °C.

### Full Detail (all 13 rows)

| doi | block_number | prop_name | phase_id | prop_min | prop_max | n_values |
|---|---|---|---|---|---|---|
| 10.1016/j.fluid.2018.07.013 | PROPblock_4 | Mole fraction | gas | 0.1137 | 0.9444 | 19 |
| 10.1016/j.jct.2013.03.002 | PROPblock_16 | Critical pressure, kPa | liquid | 3030.0 | 6135.0 | 11 |
| 10.1016/j.jct.2013.03.002 | PROPblock_15 | Critical temperature, K | liquid | 489.5 | 514.2 | 11 |
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | Excess molar enthalpy, kJ/mol | liquid | 0.1216 | 0.5795 | 17 |
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | Refractive index (Na D-line) | liquid | 1.35725 | 1.37495 | 39 |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | Speed of sound, m/s | liquid | 1046.0 | 1160.0 | 39 |
| 10.1021/je700215z | PROPblock_5 | Surface tension liquid-gas, N/m | liquid | 0.0162 | 0.02211 | 77 |
| 10.1021/je0497303 | PROPblock_8 | Binary diffusion coefficient, m2/s | liquid | 0.0 | 0.0 | 9 |
| 10.1021/je800925v | PROPblock_9 | Viscosity, Pa·s | liquid | 0.000287 | 0.001377 | 103 |
| 10.1016/j.fluid.2018.07.013 | PROPblock_3 | Boiling temperature at P, K | liquid | 332.15 | 350.75 | 19 |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | Excess molar volume, m3/mol | liquid | 0.0 | 0.0 | 23 |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | Mass density, kg/m3 | liquid | 650.4 | 789.3 | 39 |
| 10.1021/je800925v | PROPblock_10 | Mass density, kg/m3 | liquid | 655.3 | 790.2 | 103 |

## 3. execute_sql

## Compacted Result: Variables for Hexane + Ethanol Blocks

**19 rows returned (not truncated)**

### Task 1: Blocks with Temperature Variable Near 298.15 K

| doi | block_number | var_name | min_value | max_value | n_unique |
|-----|-------------|----------|-----------|-----------|----------|
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | Temperature, K | 293.15 | 303.15 | 3 |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | Temperature, K | 293.15 | 303.15 | 3 |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | Temperature, K | 293.15 | 303.15 | 3 |
| 10.1021/je700215z | PROPblock_5 | Temperature, K | 283.15 | 313.15 | 7 |
| 10.1021/je800925v | PROPblock_10 | Temperature, K | 273.15 | 298.15 | 11 |
| 10.1021/je800925v | PROPblock_9 | Temperature, K | 273.15 | 298.15 | 11 |

All six blocks have temperature ranges that include or bracket 298.15 K.

### Task 2: Blocks with Mole Fraction Spanning 0.5 (Equimolar)

| doi | block_number | x_min | x_max | n_unique |
|-----|-------------|-------|-------|----------|
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | 0.0544 | 0.9528 | 17 |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | 0.0417 | 0.9497 | 23 |
| 10.1016/j.fluid.2018.07.013 | PROPblock_3 | 0.0462 | 0.9987 | 19 |
| 10.1016/j.fluid.2018.07.013 | PROPblock_4 | 0.0462 | 0.9987 | 19 |
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | 0.0 | 1.0 | 13 |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | 0.0 | 1.0 | 13 |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | 0.0 | 1.0 | 13 |
| 10.1016/j.jct.2013.03.002 | PROPblock_15 | 0.0 | 1.0 | 11 |
| 10.1016/j.jct.2013.03.002 | PROPblock_16 | 0.0 | 1.0 | 11 |
| 10.1021/je0497303 | PROPblock_8 | 0.0 | 1.0 | 9 |
| 10.1021/je700215z | PROPblock_5 | 0.0855 | 0.932 | 11 |
| 10.1021/je800925v | PROPblock_10 | 0.0 | 1.0 | 11 |
| 10.1021/je800925v | PROPblock_9 | 0.0 | 1.0 | 11 |

All 13 blocks span x = 0.5.

### Task 3: Blocks Satisfying Both Criteria (T ≈ 298.15 K AND x spans 0.5)

| doi | block_number | T range (K) | x range |
|-----|-------------|-------------|---------|
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | 293.15–303.15 | 0.0–1.0 |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | 293.15–303.15 | 0.0–1.0 |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | 293.15–303.15 | 0.0–1.0 |
| 10.1021/je700215z | PROPblock_5 | 283.15–313.15 | 0.0855–0.932 |
| 10.1021/je800925v | PROPblock_9 | 273.15–298.15 | 0.0–1.0 |
| 10.1021/je800925v | PROPblock_10 | 273.15–298.15 | 0.0–1.0 |

**Note:** Blocks without an explicit Temperature variable (e.g., from `10.1016/j.fluid.*`, `10.1016/j.jct.2013.03.002`, `10.1021/je0497303`) may have temperature as a **constraint** rather than a variable — a separate query on `block_constraints` is needed to check those.

## 4. execute_sql

## Constraints for Hexane+Ethanol Blocks (Temperature not a variable)

11 rows returned (not truncated).

### Blocks with Temperature Constraint near 298.15 K

| DOI | Block | Constraint | Value |
|-----|-------|-----------|-------|
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | Temperature, K | **298.15** |
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | Pressure, kPa | 101.325 |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | Temperature, K | **298.15** |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | Pressure, kPa | 101.325 |
| 10.1021/je0497303 | PROPblock_8 | Temperature, K | **298.15** |
| 10.1021/je0497303 | PROPblock_8 | Pressure, kPa | 101.3 |

### Blocks with NO Temperature Constraint (only Pressure)

| DOI | Block | Constraint | Value |
|-----|-------|-----------|-------|
| 10.1016/j.fluid.2018.07.013 | PROPblock_3 | Pressure, kPa | 101.3 |
| 10.1016/j.fluid.2018.07.013 | PROPblock_4 | Pressure, kPa | 101.3 |
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | Pressure, kPa | 101.0 |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | Pressure, kPa | 101.0 |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | Pressure, kPa | 101.0 |

### Summary for Task 2

- **Three blocks have T constrained at exactly 298.15 K** (≈25 °C): PROPblock_5 & 6 from `10.1016/j.fluid.2005.08.001`, and PROPblock_8 from `10.1021/je0497303`. These blocks' properties are confirmed near 25 °C.
- **Five blocks have only a pressure constraint** (no temperature constraint listed here). For these, temperature may appear as a *variable* in a separate query, or the property itself may be temperature-dependent (e.g., boiling temperature, VLE). These blocks (from `10.1016/j.fluid.2018.07.013` and `10.1016/j.jct.2007.02.008`) need cross-referencing with block_properties/block_variables to determine what properties they contain and whether they correspond to near-25 °C data.

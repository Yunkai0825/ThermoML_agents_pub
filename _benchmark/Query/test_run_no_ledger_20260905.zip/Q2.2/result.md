# Q2.2 — Result

**Prompt:** I am deciding whether to validate a liquid-mixture viscosity model first on binary or ternary systems. Which class has enough experimental measurements across composition to provide the stronger test?

**Tool calls:** 1  |  **Time:** 292.8s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Binary Liquid Mixtures Provide the Stronger Initial Validation Test

The ThermoML database contains substantially more experimental dynamic-viscosity data for **binary** liquid mixtures than for **ternary** ones, and the composition coverage within binary datasets is far more systematic.

### Head-to-Head Comparison

| Feature | Binary | Ternary |
|---------|--------|---------|
| Data blocks | 3,294 | 1,081 |
| Literature sources | 1,176 | 429 |
| Total data points | ~137,000 | ~81,000 |
| Avg. points per block | ~42 | ~75 |
| Composition dimensionality | 1-D (single mole fraction) | 2-D (two independent fractions) |
| Typical composition coverage | Full x = 0 → 1 sweeps (11–21 points per isotherm) | One component varied, others constrained; full Gibbs-triangle grids are rare |

### Why Binary Data Give a Stronger Test

1. **Three-fold more blocks and sources.** With ~3,300 blocks from ~1,200 independent papers, binary data offer far greater statistical power for benchmarking predictions against experiment.

2. **Complete composition sweeps are routine.** Many binary blocks span the entire mole-fraction range from pure component 1 to pure component 2. For example:
   - **Hexane + cyclohexane** at 298.15 K, 101 kPa — 15 points across x = 0–1, η = 0.000294–0.000898 Pa·s (DOI 10.1007/s10765-005-5572-8, GLOBlit_6 / PROPblock_16).
   - **Hexane + decane** at 298.15 K — 15 points, x = 0–1, η = 0.000294–0.000859 Pa·s (same DOI, PROPblock_18).
   - **Hexane + hexadecane** at 298.15 K — 15 points, x = 0–1, η = 0.000294–0.003039 Pa·s (same DOI, PROPblock_21).
   - **Toluene + ethanol** — 185 points over x = 0.125–1.0 and T = 293–353 K at pressures up to 100 MPa, η = 0.000306–0.001955 Pa·s (DOI 10.1007/s10765-005-8089-2, GLOBlit_8 / PROPblock_3).

   These full-range sweeps let you test a model's ability to capture the entire composition dependence — including any extrema or inflection points in η(x) — in a single, unambiguous comparison.

3. **Simpler error analysis.** The one-dimensional composition space makes it straightforward to compute deviation profiles, identify systematic biases at dilute vs. concentrated ends, and compare multiple models on the same footing.

### Ternary Data: Valuable but Sparser

Ternary blocks average more points each (~75 vs. ~42) because the two-dimensional composition space demands more measurements per block, but the total number of blocks is only about one-third that of binary systems. More importantly, most ternary blocks do **not** cover the full Gibbs triangle; instead they vary one component while constraining the others. Representative examples:

- **1,3-Dioxolane + Na₂MoO₄ + water** — 54 points; w(dioxolane) = 0.1–0.3, c(Na₂MoO₄) = 0.024–0.101 mol/dm³, T = 303–323 K, η = 0.000571–0.001008 Pa·s (DOI 10.1007/s10765-007-0220-0, GLOBlit_49 / PROPblock_4).
- **Nicotinamide + resorcinol + water** — 72 points; c(resorcinol) = 0.05–0.2, c(nicotinamide) = 0.025–0.096 mol/dm³, T = 298–318 K, η = 0.000623–0.001077 Pa·s (DOI 10.1007/s10765-009-0567-5, GLOBlit_73 / PROPblock_3).
- **Glycine + galactose + water** — 24 points; b(glycine) = 0–0.2 mol/kg at fixed galactose molality, T = 298–313 K, η = 0.000686–0.000957 Pa·s (DOI 10.1007/s10765-010-0742-8, GLOBlit_98 / PROPblock_4).

These datasets are excellent for testing whether a model can predict **multi-component interaction terms**, but the partial composition coverage limits the stringency of any single-system test.

### Recommended Strategy

| Stage | Data class | Purpose |
|-------|-----------|---------|
| **Calibration & primary validation** | Binary | Exploit the ~137,000 data points with full-range composition sweeps to tune and rigorously benchmark the model across diverse chemical families. |
| **Out-of-sample stress test** | Ternary | Use the ~81,000 ternary points to probe the model's ability to predict higher-order mixture behavior — a more demanding but sparser test of cross-interaction terms. |

**Bottom line:** Binary systems offer roughly three times more data blocks, three times more independent literature sources, and routinely provide complete mole-fraction sweeps from x = 0 to x = 1. This makes them the stronger — and more efficient — starting point for viscosity-model validation. Ternary data should follow as a stringent extrapolation test once the model performs well on binaries.

### Core claims

- The ThermoML database contains roughly three times more experimental dynamic-viscosity data blocks and independent literature sources for binary liquid mixtures (~3,294 blocks from ~1,176 sources, ~137,000 data points) than for ternary ones (~1,081 blocks from ~429 sources, ~81,000 data points).
- Binary mixture data routinely provide complete mole-fraction sweeps from x = 0 to x = 1, enabling unambiguous testing of a model's full composition dependence, whereas most ternary blocks do not cover the full Gibbs triangle and instead vary one component while constraining others.
- The one-dimensional composition space of binary mixtures simplifies error analysis, deviation profiling, and systematic model comparison relative to the two-dimensional composition space of ternary systems.
- Binary liquid mixture data are recommended as the stronger and more efficient starting point for viscosity-model calibration and primary validation, with ternary data serving as a subsequent, more demanding out-of-sample stress test of multi-component interaction terms.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_6 | 10.1007/s10765-005-5572-8 | PROPblock_16 |  | Hexane + cyclohexane binary viscosity data, 15 points across x = 0–1 at 298.15 K, 101 kPa |
| GLOBlit_6 | 10.1007/s10765-005-5572-8 | PROPblock_18 |  | Hexane + decane binary viscosity data, 15 points across x = 0–1 at 298.15 K |
| GLOBlit_6 | 10.1007/s10765-005-5572-8 | PROPblock_21 |  | Hexane + hexadecane binary viscosity data, 15 points across x = 0–1 at 298.15 K |
| GLOBlit_8 | 10.1007/s10765-005-8089-2 | PROPblock_3 |  | Toluene + ethanol binary viscosity data, 185 points over x = 0.125–1.0, T = 293–353 K, pressures up to 100 MPa |
| GLOBlit_49 | 10.1007/s10765-007-0220-0 | PROPblock_4 |  | 1,3-Dioxolane + Na₂MoO₄ + water ternary viscosity data, 54 points, w(dioxolane) = 0.1–0.3 |
| GLOBlit_73 | 10.1007/s10765-009-0567-5 | PROPblock_3 |  | Nicotinamide + resorcinol + water ternary viscosity data, 72 points |
| GLOBlit_98 | 10.1007/s10765-010-0742-8 | PROPblock_4 |  | Glycine + galactose + water ternary viscosity data, 24 points |

### Suggested follow-ups

- Drill into binary viscosity data by chemical family (e.g., alkane+alkane, alcohol+aromatic) to assess whether composition coverage is uniform across families or concentrated in certain classes.
- Examine how many ternary blocks actually cover the full Gibbs triangle versus partial composition slices, to quantify the effective dimensionality of ternary validation tests.
- Compare temperature and pressure ranges available in binary vs. ternary viscosity datasets to ensure the model is tested under comparable thermodynamic conditions.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": null,
    "name": "Viscosity (dynamic), Pa·s"
  }
]
```

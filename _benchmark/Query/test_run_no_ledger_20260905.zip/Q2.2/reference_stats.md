# Reference Stats — query-agent

**Run started:** 2026-08-02 18:47:46
**Wall time (at last flush):** 292.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 111,983 | 11,966 | 134,170 | 26,834 | 78.3 | claudeopus46 |
| L1-worker | 15 | 78,877 | 200,873 | 40,621 | 279,750 | 18,650 | 228.0 | claudeopus46 |
| **TOTAL** | **20** | **101,064** | **312,856** | **52,587** | **413,920** | **20,696** | **306.3** | |

**Estimated tokens:** ~103,480 input + ~13,146 output = ~116,626 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_system_summary` | 0 | 1 | 0 | 0 | 1176 | 3294 | 137,229 |
| `search_system_summary` | 0 | 1 | 0 | 0 | 429 | 1081 | 81,066 |
| `search_blocks` | 13 | 1 | 4 | 2 | 5 | 10 | 888 |
| `search_blocks` | 16 | 1 | 6 | 4 | 5 | 10 | 564 |
| `search_blocks` | 22 | 1 | 5 | 2 | 10 | 20 | 1,230 |
| `search_blocks` | 23 | 1 | 6 | 4 | 7 | 20 | 1,014 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **74** | **6** | **21** | **12** | **1632** | **4435** | **221,991** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | search_blocks, search_system_summary |

#### References (55 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_7152 |  | search_system_summary |
| GLOBlit_3363 |  | search_system_summary |
| GLOBlit_5017 |  | search_system_summary |
| GLOBlit_6843 |  | search_system_summary |
| GLOBlit_6965 |  | search_system_summary |
| GLOBlit_7034 |  | search_system_summary |
| GLOBlit_6861 |  | search_system_summary |
| GLOBlit_8239 |  | search_system_summary |
| GLOBlit_7525 |  | search_system_summary |
| GLOBlit_10467 |  | search_system_summary |
| GLOBlit_2316 |  | search_system_summary |
| GLOBlit_145 |  | search_system_summary |
| GLOBlit_8502 |  | search_system_summary |
| GLOBlit_4955 |  | search_system_summary |
| GLOBlit_4746 |  | search_system_summary |
| GLOBlit_7691 |  | search_system_summary |
| GLOBlit_6743 |  | search_system_summary |
| GLOBlit_7492 |  | search_system_summary |
| GLOBlit_8755 |  | search_system_summary |
| GLOBlit_8761 |  | search_system_summary |
| GLOBlit_10411 |  | search_system_summary |
| GLOBlit_10589 |  | search_system_summary |
| GLOBlit_7366 |  | search_system_summary |
| GLOBlit_4756 |  | search_system_summary |
| GLOBlit_11136 |  | search_system_summary |
| GLOBlit_4672 |  | search_system_summary |
| GLOBlit_6768 |  | search_system_summary |
| GLOBlit_10530 |  | search_system_summary |
| GLOBlit_10142 |  | search_system_summary |
| GLOBlit_3565 |  | search_system_summary |
| GLOBlit_4565 |  | search_system_summary |
| GLOBlit_10680 |  | search_system_summary |
| GLOBlit_6135 |  | search_system_summary |
| GLOBlit_4972 |  | search_system_summary |
| GLOBlit_4043 |  | search_system_summary |
| GLOBlit_4523 |  | search_system_summary |
| GLOBlit_7006 |  | search_system_summary |
| GLOBlit_10310 |  | search_system_summary |
| GLOBlit_5051 |  | search_system_summary |
| GLOBlit_2 |  | search_blocks |
| GLOBlit_6 |  | search_blocks |
| GLOBlit_8 |  | search_blocks |
| GLOBlit_23 |  | search_blocks |
| GLOBlit_25 |  | search_blocks |
| GLOBlit_24 |  | search_blocks |
| GLOBlit_49 |  | search_blocks |
| GLOBlit_73 |  | search_blocks |
| GLOBlit_98 |  | search_blocks |
| GLOBlit_121 |  | search_blocks |
| GLOBlit_53 |  | search_blocks |
| GLOBlit_58 |  | search_blocks |
| GLOBlit_60 |  | search_blocks |
| GLOBlit_62 |  | search_blocks |
| GLOBlit_125 |  | search_blocks |
| GLOBlit_130 |  | search_blocks |

#### Compounds (42 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 | water | search_blocks |
| GLOBcomp_168 | potassium sulfate | search_blocks |
| GLOBcomp_12 | hexane | search_blocks |
| GLOBcomp_13 | cyclohexane | search_blocks |
| GLOBcomp_21 | decane | search_blocks |
| GLOBcomp_71 | hexadecane | search_blocks |
| GLOBcomp_284 | 2,6,10,15,19,23-hexamethyltetracosane | search_blocks |
| GLOBcomp_2 | ethanol | search_blocks |
| GLOBcomp_8 | toluene | search_blocks |
| GLOBcomp_57 | propane | search_blocks |
| GLOBcomp_147 | pentafluoroethane | search_blocks |
| GLOBcomp_102 | butane | search_blocks |
| GLOBcomp_17 | octane | search_blocks |
| GLOBcomp_127 | difluoromethane | search_blocks |
| GLOBcomp_250 | 1,1,1-trifluoroethane | search_blocks |
| GLOBcomp_208 | 1,3-dioxolane | search_blocks |
| GLOBcomp_1035 | sodium molybdate | search_blocks |
| GLOBcomp_466 | 3-pyridinecarboxamide | search_blocks |
| GLOBcomp_352 | 1,3-benzenediol | search_blocks |
| GLOBcomp_53 | 2-aminoacetic acid | search_blocks |
| GLOBcomp_291 | (+)-galactose | search_blocks |
| GLOBcomp_74 | (S)-2-aminopropanoic acid | search_blocks |
| GLOBcomp_2192 | (.+-.)-phenylalanine | search_blocks |
| GLOBcomp_201 | glycylglycine | search_blocks |
| GLOBcomp_355 | L-histidine | search_blocks |
| GLOBcomp_41 | potassium chloride | search_blocks |
| GLOBcomp_233 | potassium nitrate | search_blocks |
| GLOBcomp_98 | 2-methylpropane | search_blocks |
| GLOBcomp_96 | chlorobenzene | search_blocks |
| GLOBcomp_113 | triethylene glycol | search_blocks |
| GLOBcomp_197 | bromobenzene | search_blocks |
| GLOBcomp_170 | nitrobenzene | search_blocks |
| GLOBcomp_111 | diethylene glycol | search_blocks |
| GLOBcomp_4 | methanol | search_blocks |
| GLOBcomp_34 | octan-1-ol | search_blocks |
| GLOBcomp_520 | L-glutamic acid | search_blocks |
| GLOBcomp_731 | L-tryptophan | search_blocks |
| GLOBcomp_8237 | silver(I) sulfate | search_blocks |
| GLOBcomp_246 | sodium ethanoate | search_blocks |
| GLOBcomp_1079 | L-lysine monohydrochloride | search_blocks |
| GLOBcomp_375 | potassium ethanoate | search_blocks |
| GLOBcomp_1515 | calcium acetate | search_blocks |

#### Measurements (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_75 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |

#### Phases (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |
| GLOBphase_3 |  | search_blocks |

#### Solvents (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |
| GLOBsolvent_518 |  | search_blocks |
| GLOBsolvent_132 |  | search_blocks |
| GLOBsolvent_17 |  | search_blocks |
| GLOBsolvent_41 |  | search_blocks |
| GLOBsolvent_570 |  | search_blocks |
| GLOBsolvent_92 |  | search_blocks |
| GLOBsolvent_99 |  | search_blocks |
| GLOBsolvent_294 |  | search_blocks |

#### Variables (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_blocks |
| GLOBvar_11 | Solvent: Amount concentration (molarity), mol/dm3 | search_blocks |

#### Constraints (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_5 | Mass fraction | search_blocks |
| GLOBconstr_6 | Solvent: Molality, mol/kg | search_blocks |
| GLOBconstr_11 | Solvent: Amount concentration (molarity), mol/dm3 | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Properties | 1 |
| Unique References | 55 |
| Unique Compounds | 42 |
| Unique Measurements | 6 |
| Unique Phases | 2 |
| Unique Solvents | 9 |
| Unique Variables | 7 |
| Unique Constraints | 5 |
| Total DOIs | 16 |
| Unique parent blocks | 40 |
| Explicit block/subsystem targets | 40 |
| Subsystem targets | 0 |
| Target-matched data points | 3,696 |

---

## 3. DOI & Block References

**Unique DOIs:** 16  |  **Parent blocks:** 40  |  **Explicit targets:** 40  |  **Subsystems:** 0  |  **Target-matched datapoints:** 2,244

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-005-5567-5 | 1 | 172 | binary | search_blocks |
| 10.1007/s10765-005-5572-8 | 4 | 61 | binary | search_blocks |
| 10.1007/s10765-005-8089-2 | 1 | 185 | binary | search_blocks |
| 10.1007/s10765-006-0051-4 | 1 | 246 | binary | search_blocks |
| 10.1007/s10765-006-0052-3 | 2 | 238 | ternary | search_blocks |
| 10.1007/s10765-006-0053-2 | 3 | 224 | binary | search_blocks |
| 10.1007/s10765-007-0220-0 | 2 | 66 | binary, ternary | search_blocks |
| 10.1007/s10765-007-0259-y | 1 | 80 | binary | search_blocks |
| 10.1007/s10765-008-0399-8 | 4 | 88 | binary | search_blocks |
| 10.1007/s10765-008-0444-7 | 2 | 66 | binary | search_blocks |
| 10.1007/s10765-008-0491-0 | 2 | 96 | binary | search_blocks |
| 10.1007/s10765-009-0567-5 | 1 | 72 | ternary | search_blocks |
| 10.1007/s10765-010-0742-8 | 4 | 92 | ternary | search_blocks |
| 10.1007/s10765-011-0996-9 | 8 | 396 | ternary | search_blocks |
| 10.1007/s10765-011-1060-5 | 1 | 72 | ternary | search_blocks |
| 10.1007/s10765-011-1111-y | 3 | 90 | ternary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-005-5567-5 | PROPblock_4 | declared | 172 | binary | — | search_blocks |
| 10.1007/s10765-005-5572-8 | PROPblock_16 | declared | 15 | binary | — | search_blocks |
| 10.1007/s10765-005-5572-8 | PROPblock_18 | declared | 15 | binary | — | search_blocks |
| 10.1007/s10765-005-5572-8 | PROPblock_21 | declared | 15 | binary | — | search_blocks |
| 10.1007/s10765-005-5572-8 | PROPblock_24 | declared | 16 | binary | — | search_blocks |
| 10.1007/s10765-005-8089-2 | PROPblock_3 | declared | 185 | binary | — | search_blocks |
| 10.1007/s10765-006-0051-4 | PROPblock_1 | declared | 246 | binary | — | search_blocks |
| 10.1007/s10765-006-0052-3 | PROPblock_1 | declared | 120 | ternary | — | search_blocks |
| 10.1007/s10765-006-0052-3 | PROPblock_2 | declared | 118 | ternary | — | search_blocks |
| 10.1007/s10765-006-0053-2 | PROPblock_11 | declared | 64 | binary | — | search_blocks |
| 10.1007/s10765-006-0053-2 | PROPblock_13 | declared | 80 | binary | — | search_blocks |
| 10.1007/s10765-006-0053-2 | PROPblock_9 | declared | 80 | binary | — | search_blocks |
| 10.1007/s10765-007-0220-0 | PROPblock_1 | declared | 12 | binary | — | search_blocks |
| 10.1007/s10765-007-0220-0 | PROPblock_4 | declared | 54 | ternary | — | search_blocks |
| 10.1007/s10765-007-0259-y | PROPblock_3 | declared | 80 | binary | — | search_blocks |
| 10.1007/s10765-008-0399-8 | PROPblock_16 | declared | 22 | binary | — | search_blocks |
| 10.1007/s10765-008-0399-8 | PROPblock_19 | declared | 22 | binary | — | search_blocks |
| 10.1007/s10765-008-0399-8 | PROPblock_22 | declared | 22 | binary | — | search_blocks |
| 10.1007/s10765-008-0399-8 | PROPblock_25 | declared | 22 | binary | — | search_blocks |
| 10.1007/s10765-008-0444-7 | PROPblock_7 | declared | 33 | binary | — | search_blocks |
| 10.1007/s10765-008-0444-7 | PROPblock_9 | declared | 33 | binary | — | search_blocks |
| 10.1007/s10765-008-0491-0 | PROPblock_1 | declared | 48 | binary | — | search_blocks |
| 10.1007/s10765-008-0491-0 | PROPblock_4 | declared | 48 | binary | — | search_blocks |
| 10.1007/s10765-009-0567-5 | PROPblock_3 | declared | 72 | ternary | — | search_blocks |
| 10.1007/s10765-010-0742-8 | PROPblock_10 | declared | 20 | ternary | — | search_blocks |
| 10.1007/s10765-010-0742-8 | PROPblock_13 | declared | 24 | ternary | — | search_blocks |
| 10.1007/s10765-010-0742-8 | PROPblock_4 | declared | 24 | ternary | — | search_blocks |
| 10.1007/s10765-010-0742-8 | PROPblock_7 | declared | 24 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_10 | declared | 54 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_3 | declared | 54 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_4 | declared | 54 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_5 | declared | 42 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_6 | declared | 42 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_7 | declared | 48 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_8 | declared | 48 | ternary | — | search_blocks |
| 10.1007/s10765-011-0996-9 | PROPblock_9 | declared | 54 | ternary | — | search_blocks |
| 10.1007/s10765-011-1060-5 | PROPblock_1 | declared | 72 | ternary | — | search_blocks |
| 10.1007/s10765-011-1111-y | PROPblock_4 | declared | 30 | ternary | — | search_blocks |
| 10.1007/s10765-011-1111-y | PROPblock_5 | declared | 30 | ternary | — | search_blocks |
| 10.1007/s10765-011-1111-y | PROPblock_6 | declared | 30 | ternary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `search_system_summary` | property=GLOBprop_4, purpose=Count binary viscosit… | 916 | KEEP | 916 | 9.0 |
| 2 | 1 | `search_system_summary` | property=GLOBprop_4, purpose=Count ternary viscosi… | 890 | KEEP | 890 | 8.6 |
| 3 | 1 | `search_blocks` | limit=10, property=GLOBprop_4, purpose=Find exampl… | 1,148 | KEEP | 1100 | 14.8 |
| 4 | 1 | `search_blocks` | limit=10, property=GLOBprop_4, purpose=Find exampl… | 1,252 | KEEP | 1187 | 14.1 |
| 5 | 2 | `search_blocks` | limit=20, property=GLOBprop_4, purpose=Get detaile… | 1,354 | KEEP | 1268 | 13.1 |
| 6 | 2 | `search_blocks` | limit=20, property=GLOBprop_4, purpose=Get detaile… | 1,354 | KEEP | 1258 | 13.6 |
| 7 | 1 | `L1_query` | context=User wants to decide whether …, id_catalog… | 270 | — | — | 220.2 |
| | | **TOTAL (7 tools)** | | **7,184** | | **6,619** | **293.4** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 663 | 10,268 | 1,445 | 9.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,313 | 21,956 | 1,932 | 8.8 |
| 3 | L1-worker | claudeopus46 | 2,065 | 1,236 | 3,301 | 1,270 | 7.8 |
| 4 | L1-worker | claudeopus46 | 2,065 | 1,230 | 3,295 | 1,276 | 7.8 |
| 5 | L1-worker | claudeopus46 | 2,065 | 7,005 | 9,070 | 2,022 | 14.6 |
| 6 | L1-worker | claudeopus46 | 2,065 | 8,435 | 10,500 | 1,632 | 13.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 3,462 | 24,105 | 7,230 | 39.1 |
| 8 | L1-worker | claudeopus46 | 2,065 | 13,482 | 15,547 | 1,615 | 12.6 |
| 9 | L1-worker | claudeopus46 | 2,065 | 16,727 | 18,792 | 1,586 | 13.0 |
| 10 | L1-worker | claudeopus46 | 20,643 | 6,872 | 27,515 | 5,679 | 32.2 |
| 11 | L1-worker | claudeopus46 | 536 | 4,835 | 5,371 | 1,050 | 6.0 |
| 12 | L1-worker | claudeopus46 | 1,356 | 4,955 | 6,311 | 935 | 6.1 |
| 13 | L1-worker | claudeopus46 | 298 | 1,317 | 1,615 | 923 | 3.1 |
| 14 | L1-worker | claudeopus46 | 1,323 | 15,457 | 16,780 | 6,869 | 29.1 |
| 15 | L1-worker | claudeopus46 | 298 | 7,591 | 7,889 | 5,654 | 23.9 |
| 16 | L1-worker | claudeopus46 | 747 | 106,956 | 107,703 | 948 | 10.2 |
| 17 | L0-main | claudeopus46 | 9,605 | 97,447 | 107,052 | 4,917 | 35.3 |
| 18 | L0-main | claudeopus46 | 1,356 | 4,503 | 5,859 | 1,083 | 6.3 |
| 19 | L0-main | claudeopus46 | 1,323 | 6,317 | 7,640 | 2,385 | 13.8 |
| 20 | L0-main | claudeopus46 | 298 | 3,053 | 3,351 | 2,136 | 13.4 |


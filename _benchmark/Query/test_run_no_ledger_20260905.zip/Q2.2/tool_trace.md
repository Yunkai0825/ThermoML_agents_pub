# Q2.2 — Tool Trace

**Prompt:** I am deciding whether to validate a liquid-mixture viscosity model first on binary or ternary systems. Which class has enough experimental measurements across composition to provide the stronger test?

**Summary:** 292.8s  |  2 iterations  |  1 tools

---

### Step 1: `L1_query`
- **Args:** `{"context": "...", "id_catalog": "...", "instruction": "...", "purpose": "..."}`
- **Result size:** 270 chars
- **Elapsed:** 220.2s

---

## Working Memory (final snapshot)

# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| prop | GLOBprop_4 | viscosity_pa_s | Viscosity, Pa*s |
| var | GLOBvar_2 | mole_fraction_{DOIcomp_id} | Mole fraction |
| var | GLOBvar_4 | molality_mol_kg_{DOIcomp_id} | Molality, mol/kg |
| var | GLOBvar_5 | mass_fraction_{DOIcomp_id} | Mass fraction |
| var | GLOBvar_9 | amount_concentration_molarity_mol_dm3_{DOIcomp_id} | Amount concentration (molarity), mol/dm3 |
| var | GLOBvar_11 | solvent_amount_concentration_molarity_mol_dm3_{DOIcomp_id} | Solvent: Amount concentration (molarity), mol/dm3 |
| var | GLOBvar_1 | temperature_k | Temperature, K |
| var | GLOBvar_3 | pressure_kpa | Pressure, kPa |
| constr | GLOBconstr_5 | mass_fraction_{DOIcomp_id} | Mass fraction |
| comp | GLOBcomp_168 | potassium_sulfate | potassium sulfate |
| comp | GLOBcomp_1 | water | water |
| comp | GLOBcomp_12 | hexane | hexane |
| comp | GLOBcomp_13 | cyclohexane | cyclohexane |
| comp | GLOBcomp_21 | decane | decane |
| comp | GLOBcomp_71 | hexadecane | hexadecane |
| comp | GLOBcomp_8 | toluene | toluene |
| comp | GLOBcomp_2 | ethanol | ethanol |
| comp | GLOBcomp_57 | propane | propane |
| comp | GLOBcomp_147 | pentafluoroethane | pentafluoroethane |
| comp | GLOBcomp_127 | difluoromethane | difluoromethane |
| comp | GLOBcomp_250 | 1,1,1-trifluoroethane | 1,1,1-trifluoroethane |
| comp | GLOBcomp_208 | 1,3-dioxolane | 1,3-dioxolane |
| comp | GLOBcomp_1035 | sodium_molybdate | sodium molybdate |
| comp | GLOBcomp_352 | 1,3-benzenediol | 1,3-benzenediol |
| comp | GLOBcomp_466 | 3-pyridinecarboxamide | 3-pyridinecarboxamide |
| comp | GLOBcomp_53 | 2-aminoacetic_acid | 2-aminoacetic acid |
| comp | GLOBcomp_291 | (+)-galactose | (+)-galactose |
| comp | GLOBcomp_74 | (s)-2-aminopropanoic_acid | (S)-2-aminopropanoic acid |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|
| lit | GLOBlit_2 | 2005-abd-azi-1 | 10.1007/s10765-005-5567-5 |
| lit | GLOBlit_6 | 2005-tri--0 | 10.1007/s10765-005-5572-8 |
| lit | GLOBlit_8 | 2005-zeb-bay-0 | 10.1007/s10765-005-8089-2 |
| lit | GLOBlit_23 | 2006-yok-nis-0 | 10.1007/s10765-006-0051-4 |
| lit | GLOBlit_24 | 2006-yok-tak-0 | 10.1007/s10765-006-0052-3 |
| lit | GLOBlit_49 | 2007-roy-dak-0 | 10.1007/s10765-007-0220-0 |
| lit | GLOBlit_73 | 2009-roy-ban-0 | 10.1007/s10765-009-0567-5 |
| lit | GLOBlit_98 | 2010-ali-pat-0 | 10.1007/s10765-010-0742-8 |
| lit | GLOBlit_7152 | 2017-fil-bre-0 | 10.1021/acs.jced.7b00221 |
| lit | GLOBlit_3363 | 2011-hog-tor-0 | 10.1016/j.jct.2011.02.018 |
| lit | GLOBlit_5017 | 2017-con-gom-0 | 10.1016/j.jct.2017.05.001 |
| lit | GLOBlit_6843 | 2016-igl-guz-0 | 10.1021/acs.jced.6b00121 |
| lit | GLOBlit_6965 | 2017-fil-ben-0 | 10.1021/acs.jced.6b00596 |
| lit | GLOBlit_6743 | 2016-ban-agg-0 | 10.1021/acs.jced.5b00845 |
| lit | GLOBlit_10411 | 2014-ban-hun-0 | 10.1021/je5001523 |
| lit | GLOBlit_10589 | 2015-ban-art-0 | 10.1021/je500886a |
| lit | GLOBlit_7366 | 2018-sha-ban-0 | 10.1021/acs.jced.7b00937 |
| lit | GLOBlit_4756 | 2016-ban-sha-0 | 10.1016/j.jct.2016.07.020 |
| lit | GLOBlit_25 | 2006-kum-tom-0 | 10.1007/s10765-006-0053-2 |

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Compare experimental viscosity data availability for binary vs ternary liquid mixtures → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "## Comparison of Binary vs. Ternary Dynamic Viscosity Data in ThermoML\n\n### Binary Liquid Mixtures (system_type = binary)\n\n| Metric | Value |\n|--------|-------|\n| Total data blocks | 3,294 |\n| Distinct literature sources | 1,176 papers |\n| Total data-point observations | 137,229 |\n| Average points per block | ~42 |\n| Temperature range | 20–1023 K |\n\n**Composition coverage:** Many binary blocks provide full mole-fraction sweeps from x = 0 to x = 1, typically with 11–21 evenly spaced composition points per isotherm. Some blocks fix composition and sweep temperature instead. Composition variables include mole fraction (GLOBvar_2), mass fraction (GLOBvar_5), and molality (GLOBvar_4).\n\n**Example systems:**\n\n| DOI | Block | System | Composition range | Points |\n|-----|-------|--------|-------------------|--------|\n| 10.1007/s10765-005-5572-8 (GLOBlit_6) | PROPblock_16 | GLOBcomp_12 + GLOBcomp_13 | x = 0–1 (full) | 15 |\n| 10.1007/s10765-005-5572-8 (GLOBlit_6) | PROPblock_18 | GLOBcomp_12 + GLOBcomp_21 | x = 0–1 (full) | 15 |\n| 10.1007/s10765-005-8089-2 (GLOBlit_8) | PROPblock_3 | GLOBcomp_8 + GLOBcomp_2 | x = 0.125–0.375, T = 293–353 K | 185 |\n| 10.1007/s10765-005-5567-5 (GLOBlit_2) | PROPblock_4 | GLOBcomp_168 + GLOBcomp_1 | molality 0.066–0.407, T = 298–348 K | 172 |\n| 10.1007/s10765-006-0051-4 (GLOBlit_23) | PROPblock_1 | GLOBcomp_57 + GLOBcomp_147 | x fixed at 0.5, T = 298–373 K | 246 |\n\n---\n\n### Ternary Liquid Mixtures (system_type = ternary)\n\n| Metric | Value |\n|--------|-------|\n| Total data blocks | 1,081 |\n| Distinct literature sources | 429 papers |\n| Total data-point observations | 81,066 |\n| Average points per block | ~75 |\n\n**Composition coverage:** Ternary systems have a two-dimensional composition space, so individual blocks tend to contain more data points (~75 vs. ~42 for binary). However, the coverage strategy is typically to vary one component's concentration while constraining the other two (e.g., fixed mass-fraction ratios or fixed molality of one solute), rather than sweeping the full Gibbs triangle. Typical blocks contain 20–120 points. Some ternary entries are gas-phase systems (mass-fraction constrained).\n\n**Example systems:**\n\n| DOI | Block | System | Composition coverage | Points |\n|-----|-------|--------|---------------------|--------|\n| 10.1007/s10765-006-0052-3 (GLOBlit_24) | PROPblock_1 | GLOBcomp_127 + GLOBcomp_147 + GLOBcomp_250 | 2 mass fractions constrained (gas) | 120 |\n| 10.1007/s10765-007-0220-0 (GLOBlit_49) | PROPblock_4 | GLOBcomp_208 + GLOBcomp_1 + GLOBcomp_1035 | w(1,3-dioxolane) = 0.1–0.3, c(Na₂MoO₄) = 0.024–0.101 | 54 |\n| 10.1007/s10765-009-0567-5 (GLOBlit_73) | PROPblock_3 | GLOBcomp_352 + GLOBcomp_466 + GLOBcomp_1 | c(1,3-benzenediol) = 0.05–0.2, c(nicotinamide) = 0.025–0.096 | 72 |\n| 10.1007/s10765-010-0742-8 (GLOBlit_98) | PROPblock_4 | GLOBcomp_53 + GLOBcomp_291 + GLOBcomp_1 | b(glycine) = 0–0.2 | 24 |\n| 10.1007/s10765-010-0742-8 (GLOBlit_98) | PROPblock_7 | GLOBcomp_74 + GLOBcomp_291 + GLOBcomp_1 | b(L-alanine) = 0–0.2 | 24 |\n\n---\n\n### Head-to-Head Comparison\n\n| Feature | Binary | Ternary |\n|---------|--------|---------|\n| Number of blocks | 3,294 | 1,081 |\n| Literature sources | 1,176 | 429 |\n| Total data points | 137,229 | 81,066 |\n| Avg points/block | ~42 | ~75 |\n| Composition dimensionality | 1-D (single x) | 2-D (two independent fractions) |\n| Typical composition coverage | Full x = 0–1 sweeps common (11–21 points/isotherm) | Usually one component varied, others constrained; rarely full triangle |\n| System diversity | ~3× more distinct systems | Fewer systems, but richer per block |\n\n### Implications for Viscosity Model Validation\n\n**Binary systems** offer the stronger foundation for initial model validation: roughly 3× more blocks and literature sources, with straightforward full-range mole-fraction sweeps that make it easy to test predictions across the entire composition domain. The one-dimensional composition space simplifies comparison and error analysis.\n\n**Ternary systems** provide a more demanding test of model predictive capability because the two-dimensional composition space probes cross-interactions among three components simultaneously. However, the data are sparser (about one-third as many blocks), and composition coverage within each block is typically partial — one component is varied while the others are held at a few fixed ratios — rather than a systematic grid over the full Gibbs triangle. This means that while ternary data are excellent for testing extrapolation and multi-component interaction terms, the statistical power per system is lower.\n\n**Recommendation:** Use the abundant binary data for calibration and primary validation, then use ternary data as a stringent out-of-sample test of the model's ability to predict higher-order mixture behavior.",
  "core_claims": [
    "Binary dynamic viscosity data in ThermoML are roughly three times more abundant than ternary data (3,294 blocks from 1,176 sources totaling ~137,229 points vs. 1,081 blocks from 429 sources totaling ~81,066 points).",
    "Binary blocks average ~42 data points each and commonly include full mole-fraction sweeps (x = 0–1), whereas ternary blocks average ~75 points each but typically vary only one component while constraining the others, rarely covering the full Gibbs triangle.",
    "The higher-dimensional composition space of ternary systems provides a more demanding test of multi-component interaction terms in viscosity models, but with sparser and less systematic composition coverage than binary systems.",
    "Binary data are recommended for calibration and primary model validation, while ternary data serve as a stringent out-of-sample test of a model's ability to predict higher-order mixture behavior."
  ],
  "status": "success",
  "summary": "Binary liquid-mixture dynamic viscosity data in ThermoML comprise 3,294 data blocks from 1,176 literature sources totaling 137,229 observations (~42 points per block), with many blocks providing full mole-fraction sweeps (x = 0–1, typically 11–21 points per isotherm) across a one-dimensional composition space. Ternary liquid-mixture data comprise 1,081 blocks from 429 sources totaling 81,066 observations (~75 points per block), covering a two-dimensional composition space but typically varying only one component while constraining the others rather than sweeping the full Gibbs triangle. Binary data thus offer roughly three times more blocks and sources with straightforward full-range composition coverage suited for initial model calibration and validation, while ternary data provide a more demanding but sparser test of multi-component interaction predictions. The recommendation is to use binary data for calibration and primary validation and ternary data as a stringent out-of-sample test of higher-order mixture behavior.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_2",
      "registry_id": "mole_fraction_{DOIcomp_id}",
      "name": "Mole fraction"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_4",
      "registry_id": "molality_mol_kg_{DOIcomp_id}",
      "name": "Molality, mol/kg"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_5",
      "registry_id": "mass_fraction_{DOIcomp_id}",
      "name": "Mass fraction"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_9",
      "registry_id": "amount_concentration_molarity_mol_dm3_{DOIcomp_id}",
      "name": "Amount concentration (molarity), mol/dm3"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_11",
      "registry_id": "solvent_amount_concentration_molarity_mol_dm3_{DOIcomp_id}",
      "name": "Solvent: Amount concentration (molarity), mol/dm3"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_1",
      "registry_id": "temperature_k",
      "name": "Temperature, K"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBvar_3",
      "registry_id": "pressure_kpa",
      "name": "Pressure, kPa"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBconstr_5",
      "registry_id": "mass_fraction_{DOIcomp_id}",
      "name": "Mass fraction"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_168",
      "registry_id": "potassium_sulfate",
      "name": "potassium sulfate"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_12",
      "registry_id": "hexane",
      "name": "hexane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_13",
      "registry_id": "cyclohexane",
      "name": "cyclohexane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_21",
      "registry_id": "decane",
      "name": "decane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_71",
      "registry_id": "hexadecane",
      "name": "hexadecane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_8",
      "registry_id": "toluene",
      "name": "toluene"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_57",
      "registry_id": "propane",
      "name": "propane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_147",
      "registry_id": "pentafluoroethane",
      "name": "pentafluoroethane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_127",
      "registry_id": "difluoromethane",
      "name": "difluoromethane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_250",
      "registry_id": "1,1,1-trifluoroethane",
      "name": "1,1,1-trifluoroethane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_208",
      "registry_id": "1,3-dioxolane",
      "name": "1,3-dioxolane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1035",
      "registry_id": "sodium_molybdate",
      "name": "sodium molybdate"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_352",
      "registry_id": "1,3-benzenediol",
      "name": "1,3-benzenediol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_466",
      "registry_id": "3-pyridinecarboxamide",
      "name": "3-pyridinecarboxamide"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_53",
      "registry_id": "2-aminoacetic_acid",
      "name": "2-aminoacetic acid"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_291",
      "registry_id": "(+)-galactose",
      "name": "(+)-galactose"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_74",
      "registry_id": "(s)-2-aminopropanoic_acid",
      "name": "(S)-2-aminopropanoic acid"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_2",
      "registry_id": "2005-abd-azi-1",
      "name": "10.1007/s10765-005-5567-5"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_6",
      "registry_id": "2005-tri--0",
      "name": "10.1007/s10765-005-5572-8"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_8",
      "registry_id": "2005-zeb-bay-0",
      "name": "10.1007/s10765-005-8089-2"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_23",
      "registry_id": "2006-yok-nis-0",
      "name": "10.1007/s10765-006-0051-4"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_24",
      "registry_id": "2006-yok-tak-0",
      "name": "10.1007/s10765-006-0052-3"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_49",
      "registry_id": "2007-roy-dak-0",
      "name": "10.1007/s10765-007-0220-0"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_73",
      "registry_id": "2009-roy-ban-0",
      "name": "10.1007/s10765-009-0567-5"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_98",
      "registry_id": "2010-ali-pat-0",
      "name": "10.1007/s10765-010-0742-8"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_7152",
      "registry_id": "2017-fil-bre-0",
      "name": "10.1021/acs.jced.7b00221"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_3363",
      "registry_id": "2011-hog-tor-0",
      "name": "10.1016/j.jct.2011.02.018"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_5017",
      "registry_id": "2017-con-gom-0",
      "name": "10.1016/j.jct.2017.05.001"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_6843",
      "registry_id": "2016-igl-guz-0",
      "name": "10.1021/acs.jced.6b00121"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_6965",
      "registry_id": "2017-fil-ben-0",
      "name": "10.1021/acs.jced.6b00596"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_6743",
      "registry_id": "2016-ban-agg-0",
      "name": "10.1021/acs.jced.5b00845"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_10411",
      "registry_id": "2014-ban-hun-0",
      "name": "10.1021/je5001523"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_10589",
      "registry_id": "2015-ban-art-0",
      "name": "10.1021/je500886a"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_7366",
      "registry_id": "2018-sha-ban-0",
      "name": "10.1021/acs.jced.7b00937"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_4756",
      "registry_id": "2016-ban-sha-0",
      "name": "10.1016/j.jct.2016.07.020"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_25",
      "registry_id": "2006-kum-tom-0",
      "name": "10.1007/s10765-006-0053-2"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2",
      "block_number": "PROPblock_4",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_1",
        "GLOBcomp_168"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Binary viscosity; molality (GLOBvar_4) 0.0658–0.407, T 298.15–348.15 K; 172 points. DOI 10.1007/s10765-005-5567-5.",
      "doi": "10.1007/s10765-005-5567-5",
      "lit_id": "2005-abd-azi-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 172,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_168",
          "name": "potassium sulfate",
          "formula": "K2O4S",
          "inchi_key": "OTYBMLCTZGSZBG-UHFFFAOYSA-L",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 575.25,
            "n_unique": 48
          },
          "range_min": 298.15,
          "range_max": 575.25
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 0.1,
            "max": 30.0,
            "n_unique": 4
          },
          "range_min": 0.1,
          "range_max": 30.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_1",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Molality, mol/kg",
            "min": 0.0658,
            "max": 0.407,
            "n_unique": 4
          },
          "range_min": 0.0658,
          "range_max": 0.407
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 9e-05,
            "max": 0.000983,
            "mean": 0.000356,
            "std": 0.000272,
            "n": 172
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 9e-05,
          "range_max": 0.000983
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_168",
          "name": "potassium sulfate",
          "formula": "K2O4S",
          "inchi_key": "OTYBMLCTZGSZBG-UHFFFAOYSA-L",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 172,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_6",
      "block_number": "PROPblock_16",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_12",
        "GLOBcomp_13"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Binary viscosity; full mole-fraction sweep x = 0–1; 15 points. DOI 10.1007/s10765-005-5572-8.",
      "doi": "10.1007/s10765-005-5572-8",
      "lit_id": "2005-tri--0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 15,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 15
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_165",
          "meas_ID": "captub_ufactor_8",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:8",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000294,
            "max": 0.000898,
            "mean": 0.000543,
            "std": 0.00023,
            "n": 15
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000294,
          "range_max": 0.000898
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_13",
          "name": "cyclohexane",
          "formula": "C6H12",
          "inchi_key": "XDTMQSROBMDMFD-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 15,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_6",
      "block_number": "PROPblock_18",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_12",
        "GLOBcomp_21"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Binary viscosity; full mole-fraction sweep x = 0–1; 15 points. DOI 10.1007/s10765-005-5572-8.",
      "doi": "10.1007/s10765-005-5572-8",
      "lit_id": "2005-tri--0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 15,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_21",
          "name": "decane",
          "formula": "C10H22",
          "inchi_key": "DIOQZVSQGTUSAI-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 15
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_165",
          "meas_ID": "captub_ufactor_8",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:8",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000294,
            "max": 0.000859,
            "mean": 0.000527,
            "std": 0.000214,
            "n": 15
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000294,
          "range_max": 0.000859
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_21",
          "name": "decane",
          "formula": "C10H22",
          "inchi_key": "DIOQZVSQGTUSAI-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 15,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_6",
      "block_number": "PROPblock_21",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_12",
        "GLOBcomp_71"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Binary viscosity; full mole-fraction sweep x = 0–1; 15 points. DOI 10.1007/s10765-005-5572-8.",
      "doi": "10.1007/s10765-005-5572-8",
      "lit_id": "2005-tri--0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 15,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_71",
          "name": "hexadecane",
          "formula": "C16H34",
          "inchi_key": "DCAYPVUWAIABOU-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_4",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_4",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 15
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_165",
          "meas_ID": "captub_ufactor_8",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:8",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000294,
            "max": 0.003039,
            "mean": 0.001414,
            "std": 0.001033,
            "n": 15
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000294,
          "range_max": 0.003039
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_71",
          "name": "hexadecane",
          "formula": "C16H34",
          "inchi_key": "DCAYPVUWAIABOU-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 15,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_8",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Binary viscosity; x = 0.125–0.375, T 293.15–353.15 K; 185 points. DOI 10.1007/s10765-005-8089-2.",
      "doi": "10.1007/s10765-005-8089-2",
      "lit_id": "2005-zeb-bay-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 185,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.125,
            "max": 1.0,
            "n_unique": 8
          },
          "range_min": 0.125,
          "range_max": 1.0
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 353.15,
            "n_unique": 4
          },
          "range_min": 293.15,
          "range_max": 353.15
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Pressure, kPa",
            "min": 100.0,
            "max": 100000.0,
            "n_unique": 6
          },
          "range_min": 100.0,
          "range_max": 100000.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000306,
            "max": 0.001955,
            "mean": 0.000782,
            "std": 0.000321,
            "n": 185
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000306,
          "range_max": 0.001955
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 185,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_23",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_57",
        "GLOBcomp_147"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Binary viscosity; x fixed at 0.5, T 298.15–373.15 K; 246 points. DOI 10.1007/s10765-006-0051-4.",
      "doi": "10.1007/s10765-006-0051-4",
      "lit_id": "2006-yok-nis-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 246,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_57",
          "name": "propane",
          "formula": "C3H8",
          "inchi_key": "ATUOYWHBWRKTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_147",
          "name": "pentafluoroethane",
          "formula": "C2HF5",
          "inchi_key": "GTLACDSXYULKMZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.5011,
            "max": 0.7503,
            "n_unique": 2
          },
          "range_min": 0.5011,
          "range_max": 0.7503
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 423.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 423.15
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Pressure, kPa",
            "min": 101.0,
            "max": 6710.2,
            "n_unique": 244
          },
          "range_min": 101.0,
          "range_max": 6710.2
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_75",
          "meas_ID": "oscillating_disk_viscometry",
          "method_standard": "Oscillating disk viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 1.1e-05,
            "max": 2.3e-05,
            "mean": 1.6e-05,
            "std": 3e-06,
            "n": 246
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1.1e-05,
          "range_max": 2.3e-05
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_57",
          "name": "propane",
          "formula": "C3H8",
          "inchi_key": "ATUOYWHBWRKTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_147",
          "name": "pentafluoroethane",
          "formula": "C2HF5",
          "inchi_key": "GTLACDSXYULKMZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 246,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_24",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "ternary",
      "comp_num_ids": [
        "GLOBcomp_127",
        "GLOBcomp_147",
        "GLOBcomp_250"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Ternary gas-phase viscosity; 2 mass fractions constrained; T 298.15–373.15 K; 120 points. DOI 10.1007/s10765-006-0052-3.",
      "doi": "10.1007/s10765-006-0052-3",
      "lit_id": "2006-yok-tak-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_3",
      "n_datapoints": 120,
      "n_components": 3,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_127",
          "name": "difluoromethane",
          "formula": "CH2F2",
          "inchi_key": "RWRIWBAIICGTTQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_147",
          "name": "pentafluoroethane",
          "formula": "C2HF5",
          "inchi_key": "GTLACDSXYULKMZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_250",
          "name": "1,1,1-trifluoroethane",
          "formula": "C2H3F3",
          "inchi_key": "UJPMYEOUBPIPHQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_5",
          "constr_id": "mass_fraction_DOIcomp_1",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "value": 0.23,
          "digits": 2,
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_5",
          "constr_id": "mass_fraction_DOIcomp_2",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "value": 0.25,
          "digits": 2,
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 423.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 423.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.1,
            "max": 7690.0,
            "n_unique": 119
          },
          "range_min": 100.1,
          "range_max": 7690.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_75",
          "meas_ID": "oscillating_disk_viscometry",
          "method_standard": "Oscillating disk viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 1.2e-05,
            "max": 2.5e-05,
            "mean": 1.7e-05,
            "std": 3e-06,
            "n": 120
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1.2e-05,
          "range_max": 2.5e-05
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "ternary",
      "declared_n_components": 3,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_127",
          "name": "difluoromethane",
          "formula": "CH2F2",
          "inchi_key": "RWRIWBAIICGTTQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_147",
          "name": "pentafluoroethane",
          "formula": "C2HF5",
          "inchi_key": "GTLACDSXYULKMZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_250",
          "name": "1,1,1-trifluoroethane",
          "formula": "C2H3F3",
          "inchi_key": "UJPMYEOUBPIPHQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 120,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_24",
      "block_number": "PROPblock_2",
      "BLKsubsys_id": null,
      "system_type": "ternary",
      "comp_num_ids": [
        "GLOBcomp_127",
        "GLOBcomp_147",
        "GLOBcomp_250"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Ternary gas-phase viscosity; 2 mass fractions constrained; T 298.15–373.15 K; 118 points. DOI 10.1007/s10765-006-0052-3.",
      "doi": "10.1007/s10765-006-0052-3",
      "lit_id": "2006-yok-tak-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_3",
      "n_datapoints": 118,
      "n_components": 3,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_127",
          "name": "difluoromethane",
          "formula": "CH2F2",
          "inchi_key": "RWRIWBAIICGTTQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_147",
          "name": "pentafluoroethane",
          "formula": "C2HF5",
          "inchi_key": "GTLACDSXYULKMZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_250",
          "name": "1,1,1-trifluoroethane",
          "formula": "C2H3F3",
          "inchi_key": "UJPMYEOUBPIPHQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_5",
          "constr_id": "mass_fraction_DOIcomp_1",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "value": 0.25,
          "digits": 2,
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_5",
          "constr_id": "mass_fraction_DOIcomp_2",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "value": 0.15,
          "digits": 2,
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 423.15,
            "n_unique": 6
          },
          "range_min": 298.15,
          "range_max": 423.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.8,
            "max": 7487.0,
            "n_unique": 116
          },
          "range_min": 100.8,
          "range_max": 7487.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_75",
          "meas_ID": "oscillating_disk_viscometry",
          "method_standard": "Oscillating disk viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 1.2e-05,
            "max": 2.4e-05,
            "mean": 1.6e-05,
            "std": 3e-06,
            "n": 118
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1.2e-05,
          "range_max": 2.4e-05
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "ternary",
      "declared_n_components": 3,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_127",
          "name": "difluoromethane",
          "formula": "CH2F2",
          "inchi_key": "RWRIWBAIICGTTQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_147",
          "name": "pentafluoroethane",
          "formula": "C2HF5",
          "inchi_key": "GTLACDSXYULKMZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_250",
          "name": "1,1,1-trifluoroethane",
          "formula": "C2H3F3",
          "inchi_key": "UJPMYEOUBPIPHQ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 118,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_49",
      "block_number": "PROPblock_4",
      "BLKsubsys_id": null,
      "system_type": "ternary",
      "comp_num_ids": [
        "GLOBcomp_208",
        "GLOBcomp_1035",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Ternary liquid viscosity; w(1,3-dioxolane) 0.1–0.3, c(Na₂MoO₄) 0.024–0.101; T 303.15–323.15 K; 54 points. DOI 10.1007/s10765-007-0220-0.",
      "doi": "10.1007/s10765-007-0220-0",
      "lit_id": "2007-roy-dak-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_3",
      "n_datapoints": 54,
      "n_components": 3,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_208",
          "name": "1,3-dioxolane",
          "formula": "C3H6O2",
          "inchi_key": "WNXJIVFYUVYPPR-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1035",
          "name": "sodium molybdate",
          "formula": "MoNa2O4",
          "inchi_key": "TVXXNOYZHKPKGW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 303.15,
            "max": 323.15,
            "n_unique": 3
          },
          "range_min": 303.15,
          "range_max": 323.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_1",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.1,
            "max": 0.3,
            "n_unique": 3
          },
          "range_min": 0.1,
          "range_max": 0.3
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_9",
          "var_id": "amount_concentration_molarity_mol_dm3_DOIcomp_3",
          "name": "Amount concentration (molarity), mol/dm3",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Amount concentration (molarity), mol/dm3",
            "min": 0.0236,
            "max": 0.1009,
            "n_unique": 48
          },
          "range_min": 0.0236,
          "range_max": 0.1009
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_165",
          "meas_ID": "captub_ufactor_8",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:8",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000571,
            "max": 0.001008,
            "mean": 0.00076,
            "std": 0.000129,
            "n": 54
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000571,
          "range_max": 0.001008
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "ternary",
      "declared_n_components": 3,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_208",
          "name": "1,3-dioxolane",
          "formula": "C3H6O2",
          "inchi_key": "WNXJIVFYUVYPPR-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1035",
          "name": "sodium molybdate",
          "formula": "MoNa2O4",
          "inchi_key": "TVXXNOYZHKPKGW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 54,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_73",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "ternary",
      "comp_num_ids": [
        "GLOBcomp_466",
        "GLOBcomp_352",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Ternary liquid viscosity; c(1,3-benzenediol) 0.05–0.2, c(nicotinamide) 0.025–0.096; T 298.15–318.15 K; 72 points. DOI 10.1007/s10765-009-0567-5.",
      "doi": "10.1007/s10765-009-0567-5",
      "lit_id": "2009-roy-ban-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_3",
      "n_datapoints": 72,
      "n_components": 3,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_466",
          "name": "3-pyridinecarboxamide",
          "formula": "C6H6N2O",
          "inchi_key": "DFPAKSUCGFBDDF-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_352",
          "name": "1,3-benzenediol",
          "formula": "C6H6O2",
          "inchi_key": "GHMLBKRAJCXXBS-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_352",
          "solvent_num_id": "GLOBsolvent_518",
          "inchi_key": "GHMLBKRAJCXXBS-UHFFFAOYSA-N"
        },
        {
          "component_org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 318.15,
            "n_unique": 3
          },
          "range_min": 298.15,
          "range_max": 318.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_11",
          "var_id": "solvent_amount_concentration_molarity_mol_dm3_DOIcomp_1",
          "name": "Solvent: Amount concentration (molarity), mol/dm3",
          "type": "eSolventComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Solvent: Amount concentration (molarity), mol/dm3",
            "min": 0.05,
            "max": 0.2,
            "n_unique": 4
          },
          "range_min": 0.05,
          "range_max": 0.2
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_9",
          "var_id": "amount_concentration_molarity_mol_dm3_DOIcomp_2",
          "name": "Amount concentration (molarity), mol/dm3",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Amount concentration (molarity), mol/dm3",
            "min": 0.0249,
            "max": 0.0956,
            "n_unique": 27
          },
          "range_min": 0.0249,
          "range_max": 0.0956
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000623,
            "max": 0.001077,
            "mean": 0.000854,
            "std": 0.000125,
            "n": 72
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000623,
          "range_max": 0.001077
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "ternary",
      "declared_n_components": 3,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_466",
          "name": "3-pyridinecarboxamide",
          "formula": "C6H6N2O",
          "inchi_key": "DFPAKSUCGFBDDF-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_352",
          "name": "1,3-benzenediol",
          "formula": "C6H6O2",
          "inchi_key": "GHMLBKRAJCXXBS-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 72,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_98",
      "block_number": "PROPblock_4",
      "BLKsubsys_id": null,
      "system_type": "ternary",
      "comp_num_ids": [
        "GLOBcomp_53",
        "GLOBcomp_291",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Ternary liquid viscosity; b(glycine) 0–0.2; 24 points. DOI 10.1007/s10765-010-0742-8.",
      "doi": "10.1007/s10765-010-0742-8",
      "lit_id": "2010-ali-pat-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_3",
      "n_datapoints": 24,
      "n_components": 3,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_53",
          "name": "2-aminoacetic acid",
          "formula": "C2H5NO2",
          "inchi_key": "DHMQDGOQFOQNFH-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_291",
          "name": "(+)-galactose",
          "formula": "C6H12O6",
          "inchi_key": "GZCGUPFRVQAUEE-KCDKBNATSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_291",
          "solvent_num_id": "GLOBsolvent_132",
          "inchi_key": "GZCGUPFRVQAUEE-KCDKBNATSA-N"
        },
        {
          "component_org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_6",
          "constr_id": "solvent_molality_mol_kg_DOIcomp_5",
          "name": "Solvent: Molality, mol/kg",
          "type": "eSolventComposition",
          "value": 0.1,
          "digits": 1,
          "component_org_num": "DOIcomp_5",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_1",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Molality, mol/kg",
            "min": 0.0,
            "max": 0.2,
            "n_unique": 6
          },
          "range_min": 0.0,
          "range_max": 0.2
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000686,
            "max": 0.000957,
            "mean": 0.00081,
            "std": 9.6e-05,
            "n": 24
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000686,
          "range_max": 0.000957
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "ternary",
      "declared_n_components": 3,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_53",
          "name": "2-aminoacetic acid",
          "formula": "C2H5NO2",
          "inchi_key": "DHMQDGOQFOQNFH-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_291",
          "name": "(+)-galactose",
          "formula": "C6H12O6",
          "inchi_key": "GZCGUPFRVQAUEE-KCDKBNATSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "parent_n_datapoints": 24,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_98",
      "block_number": "PROPblock_7",
      "BLKsubsys_id": null,
      "system_type": "ternary",
      "comp_num_ids": [
        "GLOBcomp_74",
        "GLOBcomp_291",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Ternary liquid viscosity; b(L-alanine) 0–0.2; 24 points. DOI 10.1007/s10765-010-0742-8.",
      "doi": "10.1007/s10765-010-0742-8",
      "lit_id": "2010-ali-pat-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_3",
      "n_datapoints": 24,
      "n_components": 3,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_74",
          "name": "(S)-2-aminopropanoic acid",
          "formula": "C3H7NO2",
          "inchi_key": "QNAYBMKLOCPYGJ-REOHCLBHSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_291",
          "name": "(+)-galactose",
          "formula": "C6H12O6",
          "inchi_key": "GZCGUPFRVQAUEE-KCDKBNATSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_291",
          "solvent_num_id": "GLOBsolvent_132",
          "inchi_key": "GZCGUPFRVQAUEE-KCDKBNATSA-N"
        },
        {
          "component_org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_6",
          "constr_id": "solvent_molality_mol_kg_DOIcomp_5",
          "name": "Solvent: Molality, mol/kg",
          "type": "eSolventComposition",
          "value": 0.1,
          "digits": 1,
          "component_org_num": "DOIcomp_5",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 313.15,
            "n_unique": 4
          },
          "range_min": 298.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_2",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Molality, mol/kg",
            "min": 0.0,
            "max": 0.2,
            "n_unique": 6
          },
          "range_min": 0.0,
          "range_max": 0.2
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000686,
            "max": 0.000981,
            "mean": 0.000818,
            "std": 9.8e-05,
            "n": 24
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000686,
          "range_max": 0.000981
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "ternary",
      "declared_n_components": 3,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_74",
          "name": "(S)-2-aminopropanoic acid",
          "formula": "C3H7NO2",
          "inchi_key": "QNAYBMKLOCPYGJ-REOHCLBHSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_291",
          "name": "(+)-galactose",
          "formula": "C6H12O6",
          "inchi_key": "GZCGUPFRVQAUEE-KCDKBNATSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        }
      ],
      "parent_n_datapoints": 24,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}

---

**Total:** 1 tool calls  |  292.8s  |  OK

# Reference Stats — query-agent

**Run started:** 2026-08-02 19:45:20
**Wall time (at last flush):** 172.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 13,005 | 5,000 | 35,192 | 7,038 | 28.2 | claudeopus46 |
| L1-worker | 17 | 140,475 | 62,414 | 23,416 | 202,889 | 11,934 | 143.0 | claudeopus46 |
| **TOTAL** | **22** | **162,662** | **75,419** | **28,416** | **238,081** | **10,821** | **171.2** | |

**Estimated tokens:** ~59,520 input + ~7,104 output = ~66,624 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 20 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 11 | 0 | 0 | 0 | 0 | 0 |
| `search_id_alignment` | 20 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 20 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 20 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **81** | **12** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (54 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_838 |  | resolve_compound_ids |
| GLOBcomp_1023 |  | resolve_compound_ids |
| GLOBcomp_2943 |  | resolve_compound_ids |
| GLOBcomp_199 |  | resolve_compound_ids |
| GLOBcomp_2520 |  | resolve_compound_ids |
| GLOBcomp_1687 |  | resolve_compound_ids |
| GLOBcomp_633 |  | resolve_compound_ids |
| GLOBcomp_547 |  | resolve_compound_ids |
| GLOBcomp_358 |  | resolve_compound_ids |
| GLOBcomp_600 |  | resolve_compound_ids |
| GLOBcomp_5453 |  | resolve_compound_ids |
| GLOBcomp_6469 |  | resolve_compound_ids |
| GLOBcomp_5307 |  | resolve_compound_ids |
| GLOBcomp_200 |  | resolve_compound_ids |
| GLOBcomp_336 |  | resolve_compound_ids |
| GLOBcomp_397 |  | resolve_compound_ids |
| GLOBcomp_857 |  | resolve_compound_ids |
| GLOBcomp_974 |  | resolve_compound_ids |
| GLOBcomp_1021 |  | resolve_compound_ids |
| GLOBcomp_1051 |  | resolve_compound_ids |
| GLOBcomp_3 |  | resolve_compound_ids, search_id_alignment |
| GLOBcomp_62 |  | search_id_alignment |
| GLOBcomp_103 |  | search_id_alignment |
| GLOBcomp_214 |  | search_id_alignment |
| GLOBcomp_226 |  | resolve_compound_ids, search_id_alignment |
| GLOBcomp_234 |  | resolve_compound_ids, search_id_alignment |
| GLOBcomp_312 |  | search_id_alignment |
| GLOBcomp_708 |  | search_id_alignment |
| GLOBcomp_811 |  | search_id_alignment |
| GLOBcomp_904 |  | resolve_compound_ids, search_id_alignment |
| GLOBcomp_927 |  | search_id_alignment |
| GLOBcomp_937 |  | search_id_alignment |
| GLOBcomp_993 |  | resolve_compound_ids, search_id_alignment |
| GLOBcomp_1016 |  | search_id_alignment |
| GLOBcomp_1066 |  | search_id_alignment |
| GLOBcomp_1072 |  | search_id_alignment |
| GLOBcomp_1233 |  | search_id_alignment |
| GLOBcomp_1459 |  | search_id_alignment |
| GLOBcomp_1506 |  | search_id_alignment |
| GLOBcomp_1953 |  | search_id_alignment |
| GLOBcomp_51 |  | resolve_compound_ids |
| GLOBcomp_151 |  | resolve_compound_ids, search_system_summary |
| GLOBcomp_755 |  | resolve_compound_ids |
| GLOBcomp_861 |  | resolve_compound_ids |
| GLOBcomp_1063 |  | resolve_compound_ids |
| GLOBcomp_3597 |  | resolve_compound_ids |
| GLOBcomp_5761 |  | resolve_compound_ids |
| GLOBcomp_8374 |  | resolve_compound_ids |
| GLOBcomp_2619 |  | resolve_compound_ids |
| GLOBcomp_928 |  | resolve_compound_ids |
| GLOBcomp_2228 |  | resolve_compound_ids |
| GLOBcomp_3443 |  | resolve_compound_ids |
| GLOBcomp_4213 |  | resolve_compound_ids |
| GLOBcomp_8013 |  | resolve_compound_ids |

#### Properties (11 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_65 |  | resolve_property_ids, search_system_summary |
| GLOBprop_110 |  | resolve_property_ids |
| GLOBprop_87 |  | resolve_property_ids |
| GLOBprop_36 |  | resolve_property_ids |
| GLOBprop_97 |  | resolve_property_ids |
| GLOBprop_2 |  | resolve_property_ids |
| GLOBprop_103 |  | resolve_property_ids |
| GLOBprop_15 |  | resolve_property_ids |
| GLOBprop_68 |  | resolve_property_ids |
| GLOBprop_19 |  | resolve_property_ids |
| GLOBprop_46 |  | resolve_property_ids |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 54 |
| Unique Properties | 11 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=20, min_score=40, purpose=Find diamond or ca… | 704 | DISCARD | 639 | 9.8 |
| 2 | 2 | `resolve_property_ids` | limit=20, min_score=40, purpose=Find Gibbs free en… | 900 | KEEP | 900 | 9.8 |
| 3 | 3 | `search_id_alignment` | entity_type=compound, limit=20, purpose=Find eleme… | 665 | DISCARD | 601 | 8.8 |
| 4 | 3 | `resolve_compound_ids` | limit=20, min_score=30, purpose=Find elemental car… | 552 | KEEP | 552 | 10.7 |
| 5 | 4 | `resolve_compound_ids` | limit=20, min_score=30, purpose=Search specificall… | 774 | DISCARD | 709 | 10.6 |
| 6 | 4 | `search_system_summary` | compound=GLOBcomp_151, include_reactions=True, lim… | 585 | DISCARD | 519 | 13.0 |
| 7 | 1 | `L1_query` | context=User wants Gibbs free energy …, id_catalog… | 2,359 | — | — | 146.5 |
| | | **TOTAL (7 tools)** | | **6,539** | | **3,920** | **209.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 5,734 | 5,734 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 528 | 10,133 | 2,287 | 12.6 |
| 2 | L1-worker | claudeopus46 | 20,643 | 995 | 21,638 | 1,004 | 5.5 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,727 | 23,370 | 5,824 | 23.9 |
| 4 | L1-worker | claudeopus46 | 2,065 | 2,050 | 4,115 | 1,091 | 9.1 |
| 5 | L1-worker | claudeopus46 | 2,065 | 1,473 | 3,538 | 1,555 | 9.5 |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,356 | 24,999 | 3,450 | 18.5 |
| 7 | L1-worker | claudeopus46 | 2,065 | 2,437 | 4,502 | 1,153 | 8.5 |
| 8 | L1-worker | claudeopus46 | 2,065 | 1,968 | 4,033 | 1,328 | 9.9 |
| 9 | L1-worker | claudeopus46 | 20,610 | 7,029 | 27,639 | 551 | 4.4 |
| 10 | L1-worker | claudeopus46 | 20,643 | 6,276 | 26,919 | 2,547 | 14.3 |
| 11 | L1-worker | claudeopus46 | 2,065 | 2,035 | 4,100 | 1,196 | 10.2 |
| 12 | L1-worker | claudeopus46 | 2,065 | 578 | 2,643 | 783 | 5.9 |
| 13 | L1-worker | claudeopus46 | 20,643 | 8,368 | 29,011 | 984 | 6.6 |
| 14 | L1-worker | claudeopus46 | 1,323 | 8,962 | 10,285 | 92 | 1.8 |
| 15 | L1-worker | claudeopus46 | 1,356 | 1,115 | 2,471 | 625 | 3.4 |
| 16 | L1-worker | claudeopus46 | 536 | 995 | 1,531 | 606 | 3.6 |
| 17 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.1 |
| 18 | L1-worker | claudeopus46 | 747 | 10,236 | 10,983 | 560 | 5.8 |
| 19 | L0-main | claudeopus46 | 9,605 | 5,762 | 15,367 | 1,264 | 6.2 |
| 20 | L0-main | claudeopus46 | 1,356 | 1,019 | 2,375 | 503 | 2.9 |
| 21 | L0-main | claudeopus46 | 1,323 | 4,534 | 5,857 | 494 | 3.9 |
| 22 | L0-main | claudeopus46 | 298 | 1,162 | 1,460 | 452 | 2.6 |


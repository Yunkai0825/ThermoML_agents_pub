# Q6.2 — Result

**Prompt:** What is the Gibbs free energy of formation for diamond at 1000 K?

**Tool calls:** 1  |  **Time:** 172.2s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

No data found in the ThermoML database for the Gibbs free energy of formation of diamond at 1000 K.

The ThermoML database does not contain an entry for diamond (the diamond allotrope of elemental carbon). While graphite (elemental carbon) is present in the database, no Gibbs free energy of formation data is available for either carbon allotrope. This is because the ThermoML database primarily covers fluid-phase and mixture thermodynamic properties — such as vapor–liquid equilibria, excess properties, densities, viscosities, and activity coefficients — rather than solid-state elemental thermodynamic formation data.

The Gibbs free energy of formation of diamond at 1000 K is a well-known quantity available in standard thermodynamic reference tables (e.g., the NIST-JANAF Thermochemical Tables), but those sources are outside the scope of the ThermoML database.

### Core claims

- The ThermoML database does not contain Gibbs free energy of formation data for diamond at 1000 K.
- The ThermoML database primarily covers fluid-phase and mixture thermodynamic properties rather than solid-state elemental thermodynamic formation data, which explains the absence of this quantity.
- The Gibbs free energy of formation of diamond at 1000 K is available in standard thermodynamic reference tables (e.g., NIST-JANAF), but those sources are outside the scope of ThermoML.

**Confidence:** high

### Suggested follow-ups

- Consult the NIST-JANAF Thermochemical Tables or the NIST Chemistry WebBook for the Gibbs free energy of formation of diamond at 1000 K, as this datum is outside the scope of the ThermoML database.
- Search the ThermoML database for other thermodynamic properties of graphite (GLOBcomp_151, formula C) if fluid-phase or mixture data involving carbon is of interest.

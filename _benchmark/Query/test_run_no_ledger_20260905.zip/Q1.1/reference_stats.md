# Reference Stats — query-agent

**Run started:** 2026-08-02 18:38:37
**Wall time (at last flush):** 195.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 77,012 | 8,988 | 99,199 | 19,839 | 53.2 | claudeopus46 |
| L1-worker | 17 | 177,664 | 92,138 | 20,527 | 269,802 | 15,870 | 141.3 | claudeopus46 |
| **TOTAL** | **22** | **199,851** | **169,150** | **29,515** | **369,001** | **16,772** | **194.5** | |

**Estimated tokens:** ~92,250 input + ~7,378 output = ~99,628 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 3 | 0 | 0 |
| **TOTAL** | **4** | **1** | **3** | **0** | **3** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | resolve_property_ids |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids |
| GLOBvar_3 |  | resolve_ids |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_220 |  | block_search_adv |
| GLOBlit_5201 |  | block_search_adv |
| GLOBlit_9006 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique Variables | 3 |
| Unique References | 3 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | purpose=Resolve ethanol and water to …, queries=['… | 234 | KEEP | 234 | 4.2 |
| 2 | 1 | `resolve_property_ids` | purpose=Confirm property ID for mass …, queries=['… | 276 | KEEP | 276 | 4.6 |
| 3 | 1 | `resolve_ids` | entity_type=variable, purpose=Resolve variable IDs… | 269 | KEEP | 269 | 3.8 |
| 4 | 7 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 695 | KEEP | 695 | 19.7 |
| 5 | 1 | `L1_query` | context=, id_catalog=, instruction=Search for mass… | 21,344 | — | — | 146.6 |
| | | **TOTAL (5 tools)** | | **22,818** | | **1,474** | **178.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 599 | 10,204 | 1,071 | 7.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 951 | 21,594 | 1,337 | 7.8 |
| 3 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 3.5 |
| 4 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 424 | 4.4 |
| 5 | L1-worker | claudeopus46 | 2,065 | 554 | 2,619 | 480 | 3.8 |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,459 | 23,102 | 1,504 | 11.4 |
| 7 | L1-worker | claudeopus46 | 20,643 | 3,342 | 23,985 | 1,278 | 12.7 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,217 | 24,860 | 1,224 | 8.8 |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,137 | 25,780 | 2,007 | 13.0 |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,990 | 26,633 | 1,406 | 10.0 |
| 11 | L1-worker | claudeopus46 | 20,643 | 6,837 | 27,480 | 1,742 | 13.3 |
| 12 | L1-worker | claudeopus46 | 2,065 | 3,462 | 5,527 | 1,222 | 9.2 |
| 13 | L1-worker | claudeopus46 | 20,643 | 5,746 | 26,389 | 2,133 | 13.2 |
| 14 | L1-worker | claudeopus46 | 1,356 | 1,414 | 2,770 | 632 | 3.7 |
| 15 | L1-worker | claudeopus46 | 536 | 1,294 | 1,830 | 853 | 4.6 |
| 16 | L1-worker | claudeopus46 | 1,323 | 13,531 | 14,854 | 1,852 | 9.0 |
| 17 | L1-worker | claudeopus46 | 298 | 2,574 | 2,872 | 1,368 | 6.0 |
| 18 | L1-worker | claudeopus46 | 747 | 33,834 | 34,581 | 653 | 6.9 |
| 19 | L0-main | claudeopus46 | 9,605 | 44,169 | 53,774 | 1,795 | 15.4 |
| 20 | L0-main | claudeopus46 | 1,356 | 1,926 | 3,282 | 851 | 5.1 |
| 21 | L0-main | claudeopus46 | 1,323 | 26,724 | 28,047 | 2,926 | 15.6 |
| 22 | L0-main | claudeopus46 | 298 | 3,594 | 3,892 | 2,345 | 9.6 |


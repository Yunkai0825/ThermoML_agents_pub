# Q1.1 — Result

**Prompt:** I am preparing an equimolar ethanol + water liquid mixture at 25 °C and atmospheric pressure. What experimental density should I expect?

**Tool calls:** 1  |  **Time:** 195.1s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

For an equimolar ethanol + water liquid mixture (x_ethanol = 0.5) at 25 °C (298.15 K) and atmospheric pressure, you should expect a mass density of approximately **860–871 kg/m³**, based on three independent experimental sources in the ThermoML database:

| Source (DOI) | Data block | Mean ρ (kg/m³) | Data points near x = 0.5 |
|---|---|---|---|
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | ≈ 871.2 | 25 |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | ≈ 859.6 | 6 |
| 10.1021/je060335h | PROPblock_1 | ≈ 860.9 | 6 |

A good working estimate is **≈ 860–861 kg/m³** (the two closer-agreement sources), with the first source reporting a somewhat higher value likely due to differences in the exact composition grid sampled or elevated-pressure data points included in its broader dataset (that block spans pressures from 100 to 40,000 kPa).

**Why this value makes physical sense:**

- Pure water at 25 °C has a density of ~997 kg/m³, and pure ethanol ~785 kg/m³.
- A simple mole-fraction-weighted ideal mixing estimate would give roughly 891 kg/m³, but the actual density is lower than that ideal estimate — seemingly contradicting the well-known *negative* excess volume of this system. However, note that at x_ethanol = 0.5 the mixture is actually ~72 wt% ethanol, so it is ethanol-rich by mass.
- The ethanol–water system exhibits strong hydrogen-bonding interactions between the two components, leading to a negative excess volume (the mixture occupies less volume than the sum of the pure-component volumes). This makes the mixture denser than a simple volume-additive prediction, though the density still falls between the two pure-component values.

**Bottom line:** Expect a density of roughly **860 kg/m³** for your equimolar ethanol–water mixture at 25 °C and 1 atm.

### Core claims

- For an equimolar (x_ethanol = 0.5) ethanol + water liquid mixture at 25 °C and atmospheric pressure, the expected mass density is approximately 860–871 kg/m³ based on three independent ThermoML experimental sources, with the two closer-agreement sources converging on approximately 860–861 kg/m³.
- The higher value (~871 kg/m³) from one source likely reflects differences in the exact composition grid sampled or inclusion of elevated-pressure data points (that dataset spans 100–40,000 kPa).
- At x_ethanol = 0.5 the mixture is approximately 72 wt% ethanol, so the density falls between pure water (~997 kg/m³) and pure ethanol (~785 kg/m³) at 25 °C, and is higher than a simple volume-additive prediction due to the well-known negative excess volume arising from strong hydrogen-bonding interactions in the ethanol–water system.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | Mass density (kg/m³) of ethanol + water binary mixture near x(ethanol) ≈ 0.5 at T = 298.15 K. 25 data points matched; mean density ≈ 871.2 kg/m³. Pressure range 100–40000 kPa (includes elevated pressures), which likely accounts for the higher mean relative to the other two sources. |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_19 |  | Mass density (kg/m³) of ethanol + water binary mixture near x(ethanol) ≈ 0.5 at T = 298.15 K and constrained pressure 92.3 kPa. 6 data points matched; mean density ≈ 859.6 kg/m³. |
| GLOBlit_9006 | 10.1021/je060335h | PROPblock_1 |  | Mass density (kg/m³) of ethanol + water binary mixture near x(ethanol) ≈ 0.5 at T = 298.15 K and constrained pressure 101.0 kPa. 6 data points matched; mean density ≈ 860.9 kg/m³. |

### Suggested follow-ups

- Query for excess molar volume data of ethanol + water at x = 0.5 and 298.15 K to quantify the deviation from ideal mixing.
- Retrieve density data at additional temperatures (e.g., 283.15 K, 308.15 K) to examine the temperature dependence of density for this equimolar mixture.
- Compare with speed-of-sound or viscosity data for the same ethanol + water system to build a fuller thermophysical property profile.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density_kg_m3",
    "name": "Mass density, kg/m3"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_{DOIcomp_id}",
    "name": "Mole fraction"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_3",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

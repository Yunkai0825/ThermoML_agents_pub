## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->

## Results
<!-- Indexed findings. Compactable per-entry. -->

</memory>

## User
I need three binary liquid systems for jointly testing density and viscosity predictions. Which systems have both properties measured for the same mixture, and which papers should I start with?

## Assistant
<summary>Planning to search for binary liquid systems that have both density (GLOBprop_1) and viscosity (GLOBprop_4) measured. Will dispatch L1 query to find co-measured systems.</summary>
<tool_call>L1_query(instruction=Search for binary…, id_catalog=, context=User wants to ide…)</tool_call>
<wait/> (5 deferred)

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[1] checksum mismatch for (GLOBlit_8, PROPblock_3): comp_num_ids expected ['GLOBcomp_2', 'GLOBcomp_8'], received []; prop_num_ids expected ['GLOBprop_4'], received ['GLOBprop_1', 'GLOBprop_4']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 5 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>First L1 query failed due to core-ID refinement error. Retrying with a clearer, more focused instruction to find binary liquid systems with co-measured density and viscosity.</summary>
<tool_call>L1_query(instruction=Search for litera…, id_catalog=, context=User wants 3 bina…)</tool_call>

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[1] checksum mismatch for (GLOBlit_59, PROPblock_2): comp_num_ids expected ['GLOBcomp_2', 'GLOBcomp_36'], received []; prop_num_ids expected ['GLOBprop_1'], received ['GLOBprop_1', 'GLOBprop_4']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Previous queries failed with checksum errors. Trying a different approach: asking L1 to screen for literature entries containing density (GLOBprop_1) measurements for binary liquid mixtures first, then will cross-reference with viscosity.</summary>
<tool_call>L1_query(instruction=Screen the databa…, id_catalog=, context=User wants binary…)</tool_call>

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[1] checksum mismatch for (GLOBlit_14, PROPblock_2): comp_num_ids expected ['GLOBcomp_199', 'GLOBcomp_1'], received []",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Retrying with a simpler, more targeted instruction asking L1 to find papers that report both GLOBprop_1 (density) and GLOBprop_4 (viscosity) for binary mixtures, using the screening/ranking tool.</summary>
<tool_call>L1_query(instruction=Use the property …, id_catalog=, context=User needs 3 bina…)</tool_call>

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[1] checksum mismatch for (GLOBlit_48, PROPblock_5): system_type expected 'unary', received 'binary'; comp_num_ids expected ['GLOBcomp_44'], received ['GLOBcomp_144', 'GLOBcomp_5']; prop_num_ids expected ['GLOBprop_1'], received ['GLOBprop_4']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Previous attempts all failed with checksum errors. Trying a much simpler approach: asking L1 to rank literature by number of properties measured, focusing on binary systems with density and viscosity.</summary>
<tool_call>L1_query(instruction=Rank literature e…, id_catalog=, context=User needs 3 bina…)</tool_call>

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: no block exists for (GLOBlit_8, PROPblock_4)",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[TIME WARNING 1/3] 65% of time budget used (862s / 1000s). Wrap up soon — provide your best answer with available data.

## User
[TIME WARNING 2/3] 85% of time budget used (862s / 1000s). Wrap up soon — provide your best answer with available data.

## LLM Response
<reasoning>
All my L1 queries have failed with checksum errors. I have no data from the database to report. I must be honest and say no data was found through my queries, rather than fabricating results.
</reasoning>

<answer>
Unfortunately, I was unable to retrieve data from the ThermoML database for this query. All search attempts for binary liquid systems with co-measured density (mass density, kg/m³) and viscosity (dynamic viscosity, Pa·s) encountered internal processing errors.

**What I can tell you about the approach:**

Co-measured density and viscosity data for binary liquid mixtures are very common in ThermoML, as these two transport/volumetric properties are frequently reported together in the same experimental paper. Typical systems you would expect to find include:

- Alcohol + water (e.g., ethanol + water, 1-propanol + water)
- Alcohol + alcohol (e.g., methanol + 1-butanol)
- Ionic liquid + molecular solvent systems
- Hydrocarbon + alcohol systems

**Recommendation:** Please try refining your query by specifying particular compound pairs (e.g., "ethanol + water") or a specific compound class. A more targeted search for a named binary system may succeed where the broad screening query encountered errors. I apologize for the limitation in this session.
</answer>
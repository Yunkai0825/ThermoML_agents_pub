# Reference Stats — query-agent

**Run started:** 2026-08-02 18:53:49
**Wall time (at last flush):** 879.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 60,607 | 27,684 | 18,371 | 88,291 | 9,810 | 105.5 | claudeopus46 |
| L1-worker | 62 | 464,196 | 452,125 | 163,661 | 916,321 | 14,779 | 826.7 | claudeopus46 |
| **TOTAL** | **71** | **524,803** | **479,809** | **182,032** | **1,004,612** | **14,149** | **932.2** | |

**Estimated tokens:** ~251,153 input + ~45,508 output = ~296,661 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 47 | 2 | 5 | 2 | 18 | 50 | 3,179 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 52 | 1 | 5 | 2 | 18 | 50 | 3,382 |
| `search_blocks` | 50 | 1 | 6 | 3 | 20 | 50 | 2,414 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 69 | 2 | 6 | 4 | 33 | 100 | 6,551 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 52 | 1 | 5 | 2 | 18 | 50 | 3,382 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 82 | 1 | 6 | 5 | 39 | 100 | 5,858 |
| `search_system_registry` | 89 | 1 | 6 | 4 | 35 | 100 | 4,300 |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 237 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 82 | 1 | 6 | 5 | 39 | 100 | 5,858 |
| `search_system_registry` | 89 | 1 | 6 | 4 | 35 | 100 | 4,300 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **614** | **14** | **54** | **31** | **256** | **701** | **39,461** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | resolve_property_ids, search_blocks, search_system_registry |
| GLOBprop_4 |  | resolve_property_ids, search_blocks, search_system_registry |

#### References (59 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2 |  | search_blocks, search_system_registry |
| GLOBlit_4 |  | search_blocks, search_system_registry |
| GLOBlit_5 |  | search_blocks, search_system_registry |
| GLOBlit_6 |  | search_blocks, search_system_registry |
| GLOBlit_8 |  | search_blocks, search_system_registry |
| GLOBlit_11 |  | search_blocks, search_system_registry |
| GLOBlit_12 |  | search_blocks, search_system_registry |
| GLOBlit_14 |  | search_blocks, search_system_registry |
| GLOBlit_15 |  | search_blocks, search_system_registry |
| GLOBlit_16 |  | search_blocks, search_system_registry |
| GLOBlit_23 |  | search_blocks, search_system_registry |
| GLOBlit_25 |  | search_blocks, search_system_registry |
| GLOBlit_26 |  | search_blocks, search_system_registry |
| GLOBlit_35 |  | search_blocks, search_system_registry |
| GLOBlit_37 |  | search_blocks, search_system_registry |
| GLOBlit_48 |  | search_blocks, search_system_registry |
| GLOBlit_49 |  | search_blocks, search_system_registry |
| GLOBlit_50 |  | search_blocks, search_system_registry |
| GLOBlit_53 |  | search_blocks, search_system_registry |
| GLOBlit_56 |  | search_blocks, search_system_registry |
| GLOBlit_57 |  | search_blocks, search_system_registry |
| GLOBlit_58 |  | search_blocks, search_system_registry |
| GLOBlit_60 |  | search_blocks, search_system_registry |
| GLOBlit_62 |  | search_blocks, search_system_registry |
| GLOBlit_69 |  | search_blocks, search_system_registry |
| GLOBlit_71 |  | search_blocks, search_system_registry |
| GLOBlit_73 |  | search_blocks, search_system_registry |
| GLOBlit_76 |  | search_blocks, search_system_registry |
| GLOBlit_84 |  | search_blocks, search_system_registry |
| GLOBlit_89 |  | search_blocks, search_system_registry |
| GLOBlit_94 |  | search_blocks, search_system_registry |
| GLOBlit_97 |  | search_blocks, search_system_registry |
| GLOBlit_98 |  | search_blocks, search_system_registry |
| GLOBlit_99 |  | search_blocks, search_system_registry |
| GLOBlit_59 |  | search_system_registry |
| GLOBlit_67 |  | search_system_registry |
| GLOBlit_68 |  | search_system_registry |
| GLOBlit_78 |  | search_system_registry |
| GLOBlit_80 |  | search_system_registry |
| GLOBlit_81 |  | search_system_registry |
| GLOBlit_86 |  | search_system_registry |
| GLOBlit_87 |  | search_system_registry |
| GLOBlit_88 |  | search_system_registry |
| GLOBlit_96 |  | search_system_registry |
| GLOBlit_105 |  | search_system_registry |
| GLOBlit_113 |  | search_system_registry |
| GLOBlit_119 |  | search_system_registry |
| GLOBlit_120 |  | search_system_registry |
| GLOBlit_121 |  | search_system_registry |
| GLOBlit_126 |  | search_system_registry |
| GLOBlit_128 |  | search_system_registry |
| GLOBlit_129 |  | search_system_registry |
| GLOBlit_130 |  | search_system_registry |
| GLOBlit_145 |  | search_system_registry |
| GLOBlit_151 |  | search_system_registry |
| GLOBlit_155 |  | search_system_registry |
| GLOBlit_156 |  | search_system_registry |
| GLOBlit_169 |  | search_system_registry |
| GLOBlit_178 |  | search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Compounds (120 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 | water | search_blocks, search_system_registry |
| GLOBcomp_168 | potassium sulfate | search_blocks, search_system_registry |
| GLOBcomp_595 | dibromomethane | search_blocks, search_system_registry |
| GLOBcomp_10 | ethyl acetate | search_blocks, search_system_registry |
| GLOBcomp_995 | bromochloromethane | search_blocks, search_system_registry |
| GLOBcomp_86 | 1,2-dichloroethane | search_blocks, search_system_registry |
| GLOBcomp_1355 | 1-bromo-2-chloroethane | search_blocks, search_system_registry |
| GLOBcomp_299 | 3-methylbutyl ethanoate | search_blocks, search_system_registry |
| GLOBcomp_643 | butyl 2-propenoate | search_blocks, search_system_registry |
| GLOBcomp_783 | ethyl propenoate | search_blocks, search_system_registry |
| GLOBcomp_376 | methyl methacrylate | search_blocks, search_system_registry |
| GLOBcomp_108 | styrene | search_blocks, search_system_registry |
| GLOBcomp_12 | hexane | search_blocks, search_system_registry |
| GLOBcomp_13 | cyclohexane | search_blocks, search_system_registry |
| GLOBcomp_21 | decane | search_blocks, search_system_registry |
| GLOBcomp_71 | hexadecane | search_blocks, search_system_registry |
| GLOBcomp_284 | 2,6,10,15,19,23-hexamethyltetracosane | search_blocks, search_system_registry |
| GLOBcomp_2 | ethanol | search_blocks, search_system_registry |
| GLOBcomp_8 | toluene | search_blocks, search_system_registry |
| GLOBcomp_6 | propan-2-ol | search_blocks, search_system_registry |
| GLOBcomp_5 | propan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_7 | butan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_34 | octan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_38 | hexan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_31 | dimethyl sulfoxide | search_blocks, search_system_registry |
| GLOBcomp_77 | heptan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_199 | ammonia | search_blocks, search_system_registry |
| GLOBcomp_127 | difluoromethane | search_blocks, search_system_registry |
| GLOBcomp_147 | pentafluoroethane | search_blocks, search_system_registry |
| GLOBcomp_57 | propane | search_blocks, search_system_registry |
| GLOBcomp_98 | 2-methylpropane | search_blocks, search_system_registry |
| GLOBcomp_102 | butane | search_blocks, search_system_registry |
| GLOBcomp_17 | octane | search_blocks, search_system_registry |
| GLOBcomp_3 | carbon dioxide | search_blocks, search_system_registry |
| GLOBcomp_14 | benzene | search_blocks, search_system_registry |
| GLOBcomp_202 | triethylamine | search_blocks, search_system_registry |
| GLOBcomp_357 | tributylamine | search_blocks, search_system_registry |
| GLOBcomp_156 | tetrahydropyran | search_blocks, search_system_registry |
| GLOBcomp_328 | 2-chloro-2-methylpropane | search_blocks, search_system_registry |
| GLOBcomp_307 | 2-chlorobutane | search_blocks, search_system_registry |
| GLOBcomp_361 | 1-chloro-2-methylpropane | search_blocks, search_system_registry |
| GLOBcomp_131 | 1-chlorobutane | search_blocks, search_system_registry |
| GLOBcomp_144 | aniline | search_blocks, search_system_registry |
| GLOBcomp_29 | 2-methyl-1-propanol | search_blocks, search_system_registry |
| GLOBcomp_44 | 2-methylpropan-2-ol | search_blocks, search_system_registry |
| GLOBcomp_208 | 1,3-dioxolane | search_blocks, search_system_registry |
| GLOBcomp_48 | 2-methoxy-2-methylpropane | search_blocks, search_system_registry |
| GLOBcomp_27 | ethylbenzene | search_blocks, search_system_registry |
| GLOBcomp_37 | 2,2,4-trimethylpentane | search_blocks, search_system_registry |
| GLOBcomp_40 | trichloromethane | search_blocks, search_system_registry |
| GLOBcomp_4 | methanol | search_blocks, search_system_registry |
| GLOBcomp_36 | 1-butyl-3-methylimidazolium tetrafluoroborate | search_blocks, search_system_registry |
| GLOBcomp_15 | acetonitrile | search_blocks, search_system_registry |
| GLOBcomp_63 | N,N-dimethylethanamide | search_blocks, search_system_registry |
| GLOBcomp_96 | chlorobenzene | search_blocks, search_system_registry |
| GLOBcomp_113 | triethylene glycol | search_blocks, search_system_registry |
| GLOBcomp_197 | bromobenzene | search_blocks, search_system_registry |
| GLOBcomp_170 | nitrobenzene | search_blocks, search_system_registry |
| GLOBcomp_111 | diethylene glycol | search_blocks, search_system_registry |
| GLOBcomp_23 | tetrahydrofuran | search_blocks, search_system_registry |
| GLOBcomp_641 | methyl propenoate | search_blocks, search_system_registry |
| GLOBcomp_352 | 1,3-benzenediol | search_blocks, search_system_registry |
| GLOBcomp_628 | chlorodifluoromethane | search_blocks, search_system_registry |
| GLOBcomp_1597 | 1-chloro-1,1-difluoroethane | search_blocks, search_system_registry |
| GLOBcomp_30 | 1,2-dimethylbenzene | search_blocks, search_system_registry |
| GLOBcomp_32 | 1,3-dimethylbenzene | search_blocks, search_system_registry |
| GLOBcomp_28 | 1,4-dimethylbenzene | search_blocks, search_system_registry |
| GLOBcomp_11 | heptane | search_blocks, search_system_registry |
| GLOBcomp_85 | cyclooctane | search_blocks, search_system_registry |
| GLOBcomp_140 | 2-ethoxyethan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_89 | 3-methylbutan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_118 | 2-methoxyethan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_189 | 2-butoxyethan-1-ol | search_blocks, search_system_registry |
| GLOBcomp_52 | diisopropyl ether | search_blocks, search_system_registry |
| GLOBcomp_291 | (+)-galactose | search_blocks, search_system_registry |
| GLOBcomp_283 | cyclohexylamine | search_blocks, search_system_registry |
| GLOBcomp_65 | butyl ethanoate | search_blocks, search_system_registry |
| GLOBcomp_41 | potassium chloride | search_system_registry |
| GLOBcomp_233 | potassium nitrate | search_system_registry |
| GLOBcomp_269 | 1-butanamine | search_system_registry |
| GLOBcomp_1046 | 1-(1-methyl-2-propoxyethoxy)-2-propanol | search_system_registry |
| GLOBcomp_358 | dibutylamine | search_system_registry |
| GLOBcomp_491 | 1-methyl-3-propylimidazolium bromide | search_system_registry |
| GLOBcomp_18 | dimethylformamide | search_system_registry |
| GLOBcomp_1358 | 1,3-dimethylimidazolium chloride | search_system_registry |
| GLOBcomp_821 | cis-1,4-butenedioic acid | search_system_registry |
| GLOBcomp_2259 | 2,3-dihydroxybutanedioic acid | search_system_registry |
| GLOBcomp_39 | butanone | search_system_registry |
| GLOBcomp_940 | 2-methyl-2-propanamine | search_system_registry |
| GLOBcomp_87 | cyclohexanone | search_system_registry |
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_system_registry |
| GLOBcomp_25 | 1,4-dioxane | search_system_registry |
| GLOBcomp_379 | 2,4-pentanedione | search_system_registry |
| GLOBcomp_576 | 1-chloropentane | search_system_registry |
| GLOBcomp_391 | 1-chlorohexane | search_system_registry |
| GLOBcomp_1315 | 1-chloroheptane | search_system_registry |
| GLOBcomp_696 | 1-chlorooctane | search_system_registry |
| GLOBcomp_1514 | dimethyl methanephosphonate | search_system_registry |
| GLOBcomp_1713 | dimethyl phosphonate | search_system_registry |
| GLOBcomp_408 | 2-chlorotoluene | search_system_registry |
| GLOBcomp_59 | decan-1-ol | search_system_registry |
| GLOBcomp_664 | 3-chlorotoluene | search_system_registry |
| GLOBcomp_473 | 4-chlorotoluene | search_system_registry |
| GLOBcomp_389 | 2-amino-2-(hydroxymethyl)-1,3-propanediol | search_system_registry |
| GLOBcomp_264 | 1,2-dichlorobenzene | search_system_registry |
| GLOBcomp_544 | 2-octanol | search_system_registry |
| GLOBcomp_419 | 1,3-dichlorobenzene | search_system_registry |
| GLOBcomp_728 | 1,2,4-trichlorobenzene | search_system_registry |
| GLOBcomp_612 | 2,6-dimethylpyridine | search_system_registry |
| GLOBcomp_365 | 2-methylpyridine | search_system_registry |
| GLOBcomp_246 | sodium ethanoate | search_system_registry |
| GLOBcomp_375 | potassium ethanoate | search_system_registry |
| GLOBcomp_1515 | calcium acetate | search_system_registry |
| GLOBcomp_803 | butyl ethyl ether | search_system_registry |
| GLOBcomp_247 | 2,5,8,11,14-pentaoxapentadecane | search_system_registry |
| GLOBcomp_271 | benzaldehyde | search_system_registry |
| GLOBcomp_255 | 2-ethyl-1-hexanol | search_system_registry |
| GLOBcomp_235 | trichloroethene | search_system_registry |
| GLOBcomp_115 | propyl ethanoate | search_system_registry |
| GLOBcomp_551 | copper sulfate | search_system_registry |

#### Solvents (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_3 |  | search_blocks, search_system_registry |
| GLOBsolvent_5 |  | search_blocks, search_system_registry |
| GLOBsolvent_8 |  | search_blocks, search_system_registry |
| GLOBsolvent_21 |  | search_blocks, search_system_registry |
| GLOBsolvent_24 |  | search_system_registry |

#### Variables (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_blocks, search_system_registry |

#### Phases (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |
| GLOBphase_10 |  | search_blocks, search_system_registry |
| GLOBphase_3 |  | search_blocks, search_system_registry |

#### Measurements (29 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_143 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_153 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_167 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_66 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_170 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_75 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_791 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_437 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_1662 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_147 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_280 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_56 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_179 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_184 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_271 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_308 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_11 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_205 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_227 | Viscosity, Pa*s | search_system_registry |

#### Constraints (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_8 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBconstr_12 | Amount concentration (molarity), mol/dm3 | search_system_registry |
| GLOBconstr_5 | Mass fraction | search_system_registry |
| GLOBconstr_3 | Mole fraction | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Properties | 2 |
| Unique References | 59 |
| Unique Block_Types | 1 |
| Unique Compounds | 120 |
| Unique Solvents | 6 |
| Unique Variables | 6 |
| Unique Phases | 3 |
| Unique Measurements | 29 |
| Unique Constraints | 6 |
| Total DOIs | 59 |
| Unique parent blocks | 200 |
| Explicit block/subsystem targets | 200 |
| Subsystem targets | 0 |
| Target-matched data points | 39,461 |

---

## 3. DOI & Block References

**Unique DOIs:** 59  |  **Parent blocks:** 200  |  **Explicit targets:** 200  |  **Subsystems:** 0  |  **Target-matched datapoints:** 10,158

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-005-5567-5 | 1 | 172 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-5570-x | 4 | 341 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-5571-9 | 4 | 92 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | 8 | 122 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-8089-2 | 1 | 185 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-8101-x | 4 | 40 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-8102-9 | 3 | 33 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-8590-7 | 1 | 277 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-8591-6 | 1 | 102 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-005-8592-5 | 1 | 85 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-006-0051-4 | 1 | 246 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-006-0053-2 | 6 | 448 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-006-0056-z | 2 | 31 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-006-0095-5 | 2 | 182 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-006-0100-z | 4 | 104 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-007-0204-0 | 4 | 504 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-007-0220-0 | 2 | 24 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-007-0223-x | 5 | 906 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-007-0259-y | 2 | 160 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-008-0390-4 | 2 | 264 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-008-0395-z | 5 | 51 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-008-0399-8 | 8 | 264 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-008-0410-4 | 1 | 270 | binary | search_system_registry |
| 10.1007/s10765-008-0444-7 | 4 | 132 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-008-0491-0 | 4 | 192 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-008-0514-x | 2 | 12 | binary | search_system_registry |
| 10.1007/s10765-008-0535-5 | 1 | 194 | binary | search_system_registry |
| 10.1007/s10765-008-0542-6 | 2 | 8 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-009-0562-x | 8 | 352 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-009-0567-5 | 2 | 24 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-009-0579-1 | 2 | 474 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-009-0581-7 | 1 | 80 | binary | search_system_registry |
| 10.1007/s10765-009-0593-3 | 3 | 270 | binary | search_system_registry |
| 10.1007/s10765-009-0602-6 | 1 | 39 | binary | search_system_registry |
| 10.1007/s10765-009-0622-2 | 6 | 84 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-009-0648-5 | 3 | 210 | binary | search_system_registry |
| 10.1007/s10765-009-0651-x | 1 | 48 | binary | search_system_registry |
| 10.1007/s10765-009-0665-4 | 2 | 24 | binary | search_system_registry |
| 10.1007/s10765-009-0667-2 | 20 | 440 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-010-0719-7 | 6 | 198 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-010-0736-6 | 2 | 28 | binary | search_system_registry |
| 10.1007/s10765-010-0737-5 | 6 | 545 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-010-0742-8 | 1 | 4 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-010-0752-6 | 10 | 110 | binary | search_blocks, search_system_registry |
| 10.1007/s10765-010-0860-3 | 3 | 135 | binary | search_system_registry |
| 10.1007/s10765-010-0902-x | 5 | 72 | binary | search_system_registry |
| 10.1007/s10765-011-0989-8 | 2 | 154 | binary | search_system_registry |
| 10.1007/s10765-011-0995-x | 3 | 144 | binary | search_system_registry |
| 10.1007/s10765-011-0996-9 | 2 | 12 | binary | search_system_registry |
| 10.1007/s10765-011-1065-0 | 1 | 40 | binary | search_system_registry |
| 10.1007/s10765-011-1087-7 | 3 | 138 | binary | search_system_registry |
| 10.1007/s10765-011-1100-1 | 3 | 135 | binary | search_system_registry |
| 10.1007/s10765-011-1111-y | 3 | 16 | binary | search_system_registry |
| 10.1007/s10765-012-1371-1 | 6 | 546 | binary | search_system_registry |
| 10.1007/s10765-013-1469-0 | 1 | 110 | binary | search_system_registry |
| 10.1007/s10765-013-1492-1 | 2 | 66 | binary | search_system_registry |
| 10.1007/s10765-013-1526-8 | 3 | 144 | binary | search_system_registry |
| 10.1007/s10765-015-1927-y | 3 | 30 | binary | search_system_registry |
| 10.1007/s10765-016-2089-2 | 1 | 45 | binary | search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-005-5567-5 | PROPblock_4 | declared | 172 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5570-x | PROPblock_11 | declared | 85 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5570-x | PROPblock_12 | declared | 85 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5570-x | PROPblock_13 | declared | 84 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5570-x | PROPblock_14 | declared | 87 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5571-9 | PROPblock_6 | declared | 23 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5571-9 | PROPblock_7 | declared | 23 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5571-9 | PROPblock_8 | declared | 23 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5571-9 | PROPblock_9 | declared | 23 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_16 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_17 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_18 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_20 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_21 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_23 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_24 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-5572-8 | PROPblock_26 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8089-2 | PROPblock_3 | declared | 185 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8101-x | PROPblock_12 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8101-x | PROPblock_14 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8101-x | PROPblock_16 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8101-x | PROPblock_18 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8102-9 | PROPblock_15 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8102-9 | PROPblock_18 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8102-9 | PROPblock_21 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8590-7 | PROPblock_2 | declared | 277 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8591-6 | PROPblock_3 | declared | 102 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-005-8592-5 | PROPblock_4 | declared | 85 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0051-4 | PROPblock_1 | declared | 246 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0053-2 | PROPblock_10 | declared | 80 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0053-2 | PROPblock_11 | declared | 64 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0053-2 | PROPblock_12 | declared | 64 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0053-2 | PROPblock_13 | declared | 80 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0053-2 | PROPblock_14 | declared | 80 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0053-2 | PROPblock_9 | declared | 80 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0056-z | PROPblock_5 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0056-z | PROPblock_6 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0095-5 | PROPblock_10 | declared | 91 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0095-5 | PROPblock_8 | declared | 91 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0100-z | PROPblock_12 | declared | 26 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0100-z | PROPblock_14 | declared | 26 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0100-z | PROPblock_16 | declared | 26 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-006-0100-z | PROPblock_18 | declared | 26 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0204-0 | PROPblock_6 | declared | 126 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0204-0 | PROPblock_7 | declared | 126 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0204-0 | PROPblock_8 | declared | 126 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0204-0 | PROPblock_9 | declared | 126 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0220-0 | PROPblock_1 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0220-0 | PROPblock_2 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0223-x | PROPblock_14 | declared | 191 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0223-x | PROPblock_16 | declared | 195 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0223-x | PROPblock_18 | declared | 195 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0223-x | PROPblock_20 | declared | 195 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0223-x | PROPblock_22 | declared | 130 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0259-y | PROPblock_3 | declared | 80 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-007-0259-y | PROPblock_4 | declared | 80 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0390-4 | PROPblock_4 | declared | 126 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0390-4 | PROPblock_5 | declared | 138 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0395-z | PROPblock_13 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0395-z | PROPblock_14 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0395-z | PROPblock_15 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0395-z | PROPblock_16 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0395-z | PROPblock_17 | declared | 7 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_16 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_18 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_19 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_21 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_22 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_24 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_25 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0399-8 | PROPblock_27 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0410-4 | PROPblock_2 | declared | 270 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0444-7 | PROPblock_10 | declared | 33 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0444-7 | PROPblock_7 | declared | 33 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0444-7 | PROPblock_8 | declared | 33 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0444-7 | PROPblock_9 | declared | 33 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0491-0 | PROPblock_1 | declared | 48 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0491-0 | PROPblock_3 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0491-0 | PROPblock_4 | declared | 48 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-008-0491-0 | PROPblock_6 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0514-x | PROPblock_2 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0514-x | PROPblock_4 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0535-5 | PROPblock_4 | declared | 194 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0542-6 | PROPblock_10 | declared | 4 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0542-6 | PROPblock_8 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_21 | declared | 44 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_24 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_25 | declared | 44 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_28 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_29 | declared | 44 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_32 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_33 | declared | 44 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0562-x | PROPblock_36 | declared | 44 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0567-5 | PROPblock_1 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0567-5 | PROPblock_2 | declared | 12 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0579-1 | PROPblock_1 | declared | 237 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0579-1 | PROPblock_2 | declared | 237 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0581-7 | PROPblock_6 | declared | 80 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0593-3 | PROPblock_10 | declared | 90 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0593-3 | PROPblock_12 | declared | 90 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0593-3 | PROPblock_14 | declared | 90 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0602-6 | PROPblock_2 | declared | 39 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0622-2 | PROPblock_11 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0622-2 | PROPblock_12 | declared | 14 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0622-2 | PROPblock_13 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0622-2 | PROPblock_14 | declared | 13 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0622-2 | PROPblock_15 | declared | 13 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0622-2 | PROPblock_16 | declared | 13 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0648-5 | PROPblock_10 | declared | 75 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0648-5 | PROPblock_12 | declared | 70 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0648-5 | PROPblock_14 | declared | 65 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0651-x | PROPblock_3 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0665-4 | PROPblock_6 | declared | 12 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0665-4 | PROPblock_8 | declared | 12 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_11 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_12 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_13 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_14 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_15 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_16 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_17 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_18 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_19 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_20 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_21 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_22 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_23 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_24 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_25 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_26 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_27 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_28 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_29 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_30 | declared | 22 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0719-7 | PROPblock_17 | declared | 33 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0719-7 | PROPblock_20 | declared | 33 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0719-7 | PROPblock_21 | declared | 33 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0719-7 | PROPblock_24 | declared | 33 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0719-7 | PROPblock_25 | declared | 33 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0719-7 | PROPblock_28 | declared | 33 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0736-6 | PROPblock_2 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0736-6 | PROPblock_4 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0737-5 | PROPblock_11 | declared | 91 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0737-5 | PROPblock_12 | declared | 91 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0737-5 | PROPblock_13 | declared | 91 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0737-5 | PROPblock_14 | declared | 90 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0737-5 | PROPblock_15 | declared | 91 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0737-5 | PROPblock_17 | declared | 91 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0742-8 | PROPblock_1 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_22 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_25 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_28 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_31 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_34 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_37 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_40 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_43 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_46 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0752-6 | PROPblock_49 | declared | 11 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0860-3 | PROPblock_11 | declared | 45 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0860-3 | PROPblock_13 | declared | 45 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0860-3 | PROPblock_9 | declared | 45 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0902-x | PROPblock_13 | declared | 17 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0902-x | PROPblock_16 | declared | 13 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0902-x | PROPblock_19 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0902-x | PROPblock_22 | declared | 15 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0902-x | PROPblock_25 | declared | 13 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-0989-8 | PROPblock_7 | declared | 77 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-0989-8 | PROPblock_9 | declared | 77 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-0995-x | PROPblock_17 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-0995-x | PROPblock_21 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-0995-x | PROPblock_25 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-0996-9 | PROPblock_1 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-0996-9 | PROPblock_2 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1065-0 | PROPblock_2 | declared | 40 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1087-7 | PROPblock_17 | declared | 45 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1087-7 | PROPblock_21 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1087-7 | PROPblock_25 | declared | 45 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1100-1 | PROPblock_7 | declared | 46 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1100-1 | PROPblock_8 | declared | 41 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1100-1 | PROPblock_9 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1111-y | PROPblock_1 | declared | 5 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1111-y | PROPblock_2 | declared | 5 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1111-y | PROPblock_3 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-012-1371-1 | PROPblock_10 | declared | 91 | binary | 2 | search_system_registry |
| 10.1007/s10765-012-1371-1 | PROPblock_11 | declared | 91 | binary | 2 | search_system_registry |
| 10.1007/s10765-012-1371-1 | PROPblock_6 | declared | 91 | binary | 2 | search_system_registry |
| 10.1007/s10765-012-1371-1 | PROPblock_7 | declared | 91 | binary | 2 | search_system_registry |
| 10.1007/s10765-012-1371-1 | PROPblock_8 | declared | 91 | binary | 2 | search_system_registry |
| 10.1007/s10765-012-1371-1 | PROPblock_9 | declared | 91 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1469-0 | PROPblock_8 | declared | 110 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1492-1 | PROPblock_11 | declared | 33 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1492-1 | PROPblock_14 | declared | 33 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1526-8 | PROPblock_19 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1526-8 | PROPblock_23 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1526-8 | PROPblock_27 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-1927-y | PROPblock_15 | declared | 10 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-1927-y | PROPblock_18 | declared | 10 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-1927-y | PROPblock_21 | declared | 10 | binary | 2 | search_system_registry |
| 10.1007/s10765-016-2089-2 | PROPblock_2 | declared | 45 | binary | 2 | search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Verify GLOBprop_1 a… | 338 | KEEP | 338 | 4.1 |
| 2 | 2 | `search_system_registry` | limit=50, property=['GLOBprop_1', 'GLOBprop_4'], p… | 1,425 | KEEP | 1298 | 14.0 |
| 3 | 1 | `L1_query` | context=User wants to identify binary…, id_catalog… | 365 | — | — | 141.1 |
| 4 | 1 | `search_blocks` | limit=50, property=GLOBprop_1, purpose=Find binary… | 1,204 | KEEP | 1084 | 11.7 |
| 5 | 1 | `search_blocks` | limit=50, property=GLOBprop_4, purpose=Find binary… | 1,333 | KEEP | 1257 | 14.7 |
| 6 | 2 | `search_blocks` | limit=20, literature=['GLOBlit_4', 'GLOBlit_5', 'G… | 324 | KEEP | 324 | 6.4 |
| 7 | 2 | `search_blocks` | limit=20, literature=['GLOBlit_2', 'GLOBlit_8', 'G… | 729 | DISCARD | 671 | 7.9 |
| 8 | 3 | `search_system_registry` | limit=100, property=['GLOBprop_1', 'GLOBprop_4'], … | 1,344 | KEEP | 1224 | 16.0 |
| 9 | 2 | `L1_query` | context=User wants 3 binary liquid sy…, id_catalog… | 367 | — | — | 155.6 |
| 10 | 1 | `search_system_registry` | block_type=PureOrMixtureData, limit=50, property=G… | 1,427 | KEEP | 1311 | 15.6 |
| 11 | 3 | `L1_query` | context=User wants binary systems wit…, id_catalog… | 291 | — | — | 58.6 |
| 12 | 1 | `search_system_registry` | limit=100, property=GLOBprop_1, purpose=Find binar… | 1,442 | KEEP | 1313 | 15.7 |
| 13 | 1 | `search_system_registry` | limit=100, property=GLOBprop_4, purpose=Find binar… | 1,556 | KEEP | 1438 | 18.5 |
| 14 | 3 | `search_blocks` | limit=50, literature=['GLOBlit_76', 'GLOBlit_8', '… | 1,041 | KEEP | 1028 | 15.8 |
| 15 | 4 | `L1_query` | context=User needs 3 binary liquid sy…, id_catalog… | 416 | — | — | 183.2 |
| 16 | 2 | `search_system_registry` | limit=100, property=GLOBprop_1, purpose=Find binar… | 1,446 | KEEP | 1317 | 14.7 |
| 17 | 2 | `search_system_registry` | limit=100, property=GLOBprop_4, purpose=Find binar… | 1,435 | KEEP | 1303 | 18.1 |
| 18 | 5 | `L1_query` | context=User needs 3 binary liquid sy…, id_catalog… | 200 | — | — | 236.8 |
| | | **TOTAL (18 tools)** | | **16,683** | | **13,906** | **948.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 7,760 | 7,760 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 8,104 | 8,104 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 656 | 10,261 | 9,913 | 51.0 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,210 | 21,853 | 2,391 | 12.6 |
| 3 | L1-worker | claudeopus46 | 20,643 | 4,329 | 24,972 | 14,274 | 55.3 |
| 4 | L1-worker | claudeopus46 | 2,065 | 473 | 2,538 | 544 | 4.0 |
| 5 | L1-worker | claudeopus46 | 2,065 | 8,788 | 10,853 | 1,694 | 13.3 |
| 6 | L1-worker | claudeopus46 | 20,643 | 6,179 | 26,822 | 3,446 | 18.7 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,606 | 3,962 | 877 | 4.8 |
| 8 | L1-worker | claudeopus46 | 536 | 2,486 | 3,022 | 1,070 | 7.1 |
| 9 | L1-worker | claudeopus46 | 298 | 1,426 | 1,724 | 1,057 | 3.8 |
| 10 | L1-worker | claudeopus46 | 1,323 | 6,842 | 8,165 | 3,536 | 12.7 |
| 11 | L1-worker | claudeopus46 | 298 | 4,258 | 4,556 | 2,761 | 11.2 |
| 12 | L1-worker | claudeopus46 | 1,160 | 10,978 | 12,138 | 2,775 | 11.8 |
| 13 | L0-main | claudeopus46 | 9,605 | 1,569 | 11,174 | 1,352 | 8.5 |
| 14 | L1-worker | claudeopus46 | 20,643 | 1,288 | 21,931 | 1,998 | 10.4 |
| 15 | L1-worker | claudeopus46 | 2,065 | 32,975 | 35,040 | 1,477 | 11.0 |
| 16 | L1-worker | claudeopus46 | 2,065 | 32,419 | 34,484 | 1,650 | 14.0 |
| 17 | L1-worker | claudeopus46 | 20,643 | 4,500 | 25,143 | 2,177 | 13.3 |
| 18 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 831 | 6.1 |
| 19 | L1-worker | claudeopus46 | 2,065 | 531 | 2,596 | 1,113 | 7.7 |
| 20 | L1-worker | claudeopus46 | 20,643 | 6,324 | 26,967 | 3,223 | 20.6 |
| 21 | L1-worker | claudeopus46 | 2,065 | 17,295 | 19,360 | 1,851 | 13.9 |
| 22 | L1-worker | claudeopus46 | 20,610 | 9,055 | 29,665 | 547 | 4.7 |
| 23 | L1-worker | claudeopus46 | 20,643 | 8,302 | 28,945 | 4,765 | 26.3 |
| 24 | L1-worker | claudeopus46 | 1,356 | 2,785 | 4,141 | 873 | 3.9 |
| 25 | L1-worker | claudeopus46 | 536 | 2,665 | 3,201 | 1,165 | 5.7 |
| 26 | L1-worker | claudeopus46 | 1,323 | 11,081 | 12,404 | 2,171 | 8.8 |
| 27 | L1-worker | claudeopus46 | 298 | 2,893 | 3,191 | 1,703 | 6.4 |
| 28 | L1-worker | claudeopus46 | 1,160 | 13,740 | 14,900 | 1,692 | 6.7 |
| 29 | L0-main | claudeopus46 | 9,605 | 2,468 | 12,073 | 1,394 | 8.7 |
| 30 | L1-worker | claudeopus46 | 20,643 | 961 | 21,604 | 751 | 5.6 |
| 31 | L1-worker | claudeopus46 | 2,065 | 8,985 | 11,050 | 1,715 | 14.8 |
| 32 | L1-worker | claudeopus46 | 20,643 | 2,887 | 23,530 | 2,510 | 11.4 |
| 33 | L1-worker | claudeopus46 | 1,356 | 2,241 | 3,597 | 543 | 3.2 |
| 34 | L1-worker | claudeopus46 | 536 | 2,121 | 2,657 | 798 | 4.4 |
| 35 | L1-worker | claudeopus46 | 1,323 | 5,041 | 6,364 | 2,680 | 9.2 |
| 36 | L1-worker | claudeopus46 | 298 | 3,402 | 3,700 | 2,130 | 7.3 |
| 37 | L1-worker | claudeopus46 | 1,160 | 8,388 | 9,548 | 2,157 | 8.2 |
| 38 | L0-main | claudeopus46 | 9,605 | 3,355 | 12,960 | 1,505 | 9.3 |
| 39 | L1-worker | claudeopus46 | 20,643 | 1,119 | 21,762 | 1,723 | 9.5 |
| 40 | L1-worker | claudeopus46 | 2,065 | 17,232 | 19,297 | 1,755 | 14.2 |
| 41 | L1-worker | claudeopus46 | 2,065 | 17,002 | 19,067 | 1,708 | 15.3 |
| 42 | L1-worker | claudeopus46 | 20,643 | 4,835 | 25,478 | 2,197 | 13.6 |
| 43 | L1-worker | claudeopus46 | 20,643 | 7,653 | 28,296 | 5,855 | 30.3 |
| 44 | L1-worker | claudeopus46 | 2,065 | 2,655 | 4,720 | 1,839 | 15.6 |
| 45 | L1-worker | claudeopus46 | 20,610 | 9,399 | 30,009 | 593 | 5.3 |
| 46 | L1-worker | claudeopus46 | 20,643 | 8,646 | 29,289 | 5,585 | 30.5 |
| 47 | L1-worker | claudeopus46 | 20,643 | 14,852 | 35,495 | 2,299 | 9.4 |
| 48 | L1-worker | claudeopus46 | 1,356 | 2,154 | 3,510 | 794 | 4.1 |
| 49 | L1-worker | claudeopus46 | 536 | 2,034 | 2,570 | 1,146 | 5.9 |
| 50 | L1-worker | claudeopus46 | 298 | 1,502 | 1,800 | 1,133 | 4.8 |
| 51 | L1-worker | claudeopus46 | 298 | 1,176 | 1,474 | 782 | 6.9 |
| 52 | L1-worker | claudeopus46 | 1,323 | 9,037 | 10,360 | 3,018 | 13.7 |
| 53 | L1-worker | claudeopus46 | 298 | 3,740 | 4,038 | 2,520 | 9.6 |
| 54 | L1-worker | claudeopus46 | 1,160 | 12,884 | 14,044 | 2,516 | 9.8 |
| 55 | L0-main | claudeopus46 | 9,605 | 4,324 | 13,929 | 1,281 | 7.8 |
| 56 | L1-worker | claudeopus46 | 20,643 | 1,042 | 21,685 | 2,379 | 12.2 |
| 57 | L1-worker | claudeopus46 | 20,643 | 4,149 | 24,792 | 13,119 | 49.3 |
| 58 | L1-worker | claudeopus46 | 2,065 | 17,250 | 19,315 | 1,738 | 13.6 |
| 59 | L1-worker | claudeopus46 | 2,065 | 17,023 | 19,088 | 1,634 | 14.0 |
| 60 | L1-worker | claudeopus46 | 20,643 | 7,046 | 27,689 | 14,964 | 71.4 |
| 61 | L1-worker | claudeopus46 | 20,643 | 22,631 | 43,274 | 5,017 | 28.7 |
| 62 | L1-worker | claudeopus46 | 536 | 3,546 | 4,082 | 1,040 | 6.7 |
| 63 | L1-worker | claudeopus46 | 1,356 | 3,666 | 5,022 | 1,080 | 8.3 |
| 64 | L1-worker | claudeopus46 | 298 | 1,462 | 1,760 | 1,068 | 3.9 |
| 65 | L1-worker | claudeopus46 | 1,323 | 8,989 | 10,312 | 4,589 | 16.9 |
| 66 | L1-worker | claudeopus46 | 298 | 5,311 | 5,609 | 3,308 | 11.8 |
| 67 | L1-worker | claudeopus46 | 1,160 | 14,160 | 15,320 | 3,317 | 12.5 |
| 68 | L0-main | claudeopus46 | 9,605 | 5,340 | 14,945 | 1,294 | 9.3 |
| 69 | L0-main | claudeopus46 | 1,356 | 1,207 | 2,563 | 445 | 3.3 |
| 70 | L0-main | claudeopus46 | 1,323 | 7,480 | 8,803 | 617 | 4.9 |
| 71 | L0-main | claudeopus46 | 298 | 1,285 | 1,583 | 570 | 2.7 |


# Reference Stats — query-agent

**Run started:** 2026-08-02 19:11:12
**Wall time (at last flush):** 1,621.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 41,364 | 89,035 | 31,746 | 130,399 | 18,628 | 162.0 | claudeopus46 |
| L1-worker | 131 | 1,303,713 | 1,338,329 | 251,529 | 2,642,042 | 20,168 | 1508.2 | claudeopus46 |
| **TOTAL** | **138** | **1,345,077** | **1,427,364** | **283,275** | **2,772,441** | **20,090** | **1670.2** | |

**Estimated tokens:** ~693,110 input + ~70,818 output = ~763,928 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 5 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 2 | 2 | 2 | 429 |
| `search_blocks` | 2 | 1 | 3 | 2 | 5 | 6 | 144 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 3 | 1 | 1 | 2 | 1 | 2 | 62 |
| `search_system_registry` | 50 | 1 | 3 | 2 | 43 | 50 | 1,724 |
| `search_system_registry` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 40 | 1 | 3 | 2 | 33 | 50 | 1,266 |
| `search_system_registry` | 11 | 6 | 4 | 3 | 8 | 20 | 267 |
| **TOTAL** | **129** | **16** | **19** | **13** | **96** | **130** | **3,892** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (71 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_4 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_5 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_7 |  | resolve_compound_ids, search_system_registry |
| GLOBcomp_35 | acetic acid | search_blocks, search_system_registry |
| GLOBcomp_64 | 1-ethyl-3-methylimidazolium bis((trifluoromethyl)sulfonyl)imide | search_system_registry |
| GLOBcomp_55 | 1-butyl-3-methylimidazolium hexafluorophosphate | search_system_registry |
| GLOBcomp_69 | oct-1-ene | search_system_registry |
| GLOBcomp_686 | ethyl 3-oxobutanoate | search_system_registry |
| GLOBcomp_21 | decane | search_system_registry |
| GLOBcomp_37 | 2,2,4-trimethylpentane | search_system_registry |
| GLOBcomp_535 | pyrrole | search_system_registry |
| GLOBcomp_115 | propyl ethanoate | search_system_registry |
| GLOBcomp_240 | ethyl methanoate | search_system_registry |
| GLOBcomp_295 | tributyl phosphate | search_system_registry |
| GLOBcomp_301 | 1-butyl-4-methylpyridinium tetrafluoroborate | search_system_registry |
| GLOBcomp_48 | 2-methoxy-2-methylpropane | search_system_registry |
| GLOBcomp_70 | dibutyl ether | search_system_registry |
| GLOBcomp_271 | benzaldehyde | search_system_registry |
| GLOBcomp_178 | cyclohexanol | search_system_registry |
| GLOBcomp_1054 | diethyl ethanedioate | search_system_registry |
| GLOBcomp_11 | heptane | search_system_registry |
| GLOBcomp_170 | nitrobenzene | search_system_registry |
| GLOBcomp_14 | benzene | search_system_registry |
| GLOBcomp_8 | toluene | search_system_registry |
| GLOBcomp_1789 | (-)-fenchone | search_system_registry |
| GLOBcomp_826 | 1-butyl-1-methylpyrrolidinium tetracyanoborate | search_system_registry |
| GLOBcomp_877 | 1-hexylpyridinium bis(trifluromethylsulfonyl)imide | search_system_registry |
| GLOBcomp_189 | 2-butoxyethan-1-ol | search_system_registry |
| GLOBcomp_13 | cyclohexane | search_system_registry |
| GLOBcomp_42 | methylcyclohexane | search_system_registry |
| GLOBcomp_413 | ethane-1,2-diamine | search_system_registry |
| GLOBcomp_1000 | methyl 2-hydroxypropanoate | search_system_registry |
| GLOBcomp_390 | DL-ethyl lactate | search_system_registry |
| GLOBcomp_327 | 1-methylimidazole | search_system_registry |
| GLOBcomp_7670 | ethyl 2-methylpropanoate | search_system_registry |
| GLOBcomp_101 | 4-methylpentan-2-one | search_system_registry |
| GLOBcomp_10 | ethyl acetate | search_system_registry |
| GLOBcomp_6 | propan-2-ol | search_system_registry |
| GLOBcomp_345 | methyl methanoate | search_system_registry |
| GLOBcomp_683 | 1,3-propanediamine | search_system_registry |
| GLOBcomp_1270 | 1,2-propanediamine | search_system_registry |
| GLOBcomp_31 | dimethyl sulfoxide | search_system_registry |
| GLOBcomp_265 | 2,2,2-trifluoroethanol | search_system_registry |
| GLOBcomp_1526 | trimethyl orthophosphate | search_system_registry |
| GLOBcomp_268 | 2-pyrrolidinone | search_system_registry |
| GLOBcomp_133 | formamide | search_system_registry |
| GLOBcomp_9 | acetone | search_system_registry |
| GLOBcomp_17 | octane | search_system_registry |
| GLOBcomp_24 | 1,2-ethanediol | search_system_registry |
| GLOBcomp_631 | .beta.-pinene | search_system_registry |
| GLOBcomp_62 | dimethyl carbonate | search_system_registry |
| GLOBcomp_46 | methyl ethanoate | search_system_registry |
| GLOBcomp_202 | triethylamine | search_system_registry |
| GLOBcomp_12 | hexane | search_system_registry |
| GLOBcomp_379 | 2,4-pentanedione | search_system_registry |
| GLOBcomp_499 | diethyl 1,3-propanedioate | search_system_registry |
| GLOBcomp_52 | diisopropyl ether | search_system_registry |
| GLOBcomp_45 | hex-1-ene | search_system_registry |
| GLOBcomp_357 | tributylamine | search_system_registry |
| GLOBcomp_685 | trioctylamine | search_system_registry |
| GLOBcomp_39 | butanone | search_system_registry |
| GLOBcomp_56 | 1-hexyl-3-methylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_system_registry |
| GLOBcomp_208 | 1,3-dioxolane | search_system_registry |
| GLOBcomp_739 | (-)-3-(N-methylpyrrolidino)pyridine | search_system_registry |
| GLOBcomp_625 | butyl 2-methyl-2-propenoate | search_system_registry |
| GLOBcomp_1472 | isobutyl methacrylate | search_system_registry |
| GLOBcomp_376 | methyl methacrylate | search_system_registry |
| GLOBcomp_263 | 2,3-butanediol | search_system_registry |
| GLOBcomp_444 | (Z)-9-octadecenoic acid | search_system_registry |

#### Properties (11 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 |  | resolve_property_ids, search_blocks, search_system_registry |
| GLOBprop_22 |  | resolve_property_ids |
| GLOBprop_28 |  | resolve_property_ids |
| GLOBprop_90 |  | resolve_property_ids |
| GLOBprop_85 |  | resolve_property_ids |
| GLOBprop_2 | Mole fraction | search_system_registry |
| GLOBprop_3 | Activity coefficient | search_system_registry |
| GLOBprop_4 | Viscosity, Pa*s | search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_system_registry |
| GLOBprop_1 | Mass density, kg/m3 | search_system_registry |
| GLOBprop_6 | Mass fraction | search_system_registry |

#### Variables (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids, search_blocks, search_system_registry |
| GLOBvar_2 |  | resolve_ids, search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_system_registry |

#### References (71 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_5688 |  | block_search_adv, search_blocks |
| GLOBlit_2520 |  | search_blocks |
| GLOBlit_528 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBlit_1482 |  | search_blocks |
| GLOBlit_2574 |  | search_blocks |
| GLOBlit_4181 |  | search_blocks |
| GLOBlit_6377 |  | search_blocks |
| GLOBlit_1766 |  | search_blocks |
| GLOBlit_524 |  | search_system_registry |
| GLOBlit_553 |  | search_system_registry |
| GLOBlit_617 |  | search_system_registry |
| GLOBlit_637 |  | search_system_registry |
| GLOBlit_1128 |  | search_system_registry |
| GLOBlit_1354 |  | search_system_registry |
| GLOBlit_1537 |  | search_system_registry |
| GLOBlit_2543 |  | search_system_registry |
| GLOBlit_2731 |  | search_system_registry |
| GLOBlit_2929 |  | search_system_registry |
| GLOBlit_3040 |  | search_system_registry |
| GLOBlit_3118 |  | search_system_registry |
| GLOBlit_3393 |  | search_system_registry |
| GLOBlit_3581 |  | search_system_registry |
| GLOBlit_3900 |  | search_system_registry |
| GLOBlit_3931 |  | search_system_registry |
| GLOBlit_4238 |  | search_system_registry |
| GLOBlit_4299 |  | search_system_registry |
| GLOBlit_4376 |  | search_system_registry |
| GLOBlit_4402 |  | search_system_registry |
| GLOBlit_4414 |  | search_system_registry |
| GLOBlit_4783 |  | search_system_registry |
| GLOBlit_4847 |  | search_system_registry |
| GLOBlit_4940 |  | search_system_registry |
| GLOBlit_5286 |  | search_system_registry |
| GLOBlit_5405 |  | search_system_registry |
| GLOBlit_5589 |  | search_system_registry |
| GLOBlit_5601 |  | search_system_registry |
| GLOBlit_5627 |  | search_system_registry |
| GLOBlit_5642 |  | search_system_registry |
| GLOBlit_5675 |  | search_system_registry |
| GLOBlit_5720 |  | search_system_registry |
| GLOBlit_5731 |  | search_system_registry |
| GLOBlit_5750 |  | search_system_registry |
| GLOBlit_5779 |  | search_system_registry |
| GLOBlit_5836 |  | search_system_registry |
| GLOBlit_6063 |  | search_system_registry |
| GLOBlit_8042 |  | search_system_registry |
| GLOBlit_8182 |  | search_system_registry |
| GLOBlit_8569 |  | search_system_registry |
| GLOBlit_8588 |  | search_system_registry |
| GLOBlit_8655 |  | search_system_registry |
| GLOBlit_294 |  | search_system_registry |
| GLOBlit_589 |  | search_system_registry |
| GLOBlit_719 |  | search_system_registry |
| GLOBlit_755 |  | search_system_registry |
| GLOBlit_761 |  | search_system_registry |
| GLOBlit_877 |  | search_system_registry |
| GLOBlit_1034 |  | search_system_registry |
| GLOBlit_2583 |  | search_system_registry |
| GLOBlit_2644 |  | search_system_registry |
| GLOBlit_2843 |  | search_system_registry |
| GLOBlit_3128 |  | search_system_registry |
| GLOBlit_3404 |  | search_system_registry |
| GLOBlit_5168 |  | search_system_registry |
| GLOBlit_228 |  | search_system_registry |
| GLOBlit_299 |  | search_system_registry |
| GLOBlit_369 |  | search_system_registry |
| GLOBlit_488 |  | search_system_registry |
| GLOBlit_539 |  | search_system_registry |
| GLOBlit_586 |  | search_system_registry |
| GLOBlit_623 |  | search_system_registry |
| GLOBlit_718 |  | search_system_registry |

#### Block_Types (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv, search_system_registry |
| GLOBblocktype_3 |  | search_system_registry |

#### Phases (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks, search_system_registry |
| GLOBphase_4 |  | search_system_registry |
| GLOBphase_5 |  | search_system_registry |

#### Measurements (26 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_224 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_25 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_44 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_262 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_657 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_747 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_78 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_34 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_200 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_938 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_520 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_790 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_562 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_system_registry |
| GLOBmeas_152 | Mole fraction | search_system_registry |
| GLOBmeas_543 | Activity coefficient | search_system_registry |
| GLOBmeas_1045 | Activity coefficient | search_system_registry |
| GLOBmeas_1042 | Activity coefficient | search_system_registry |
| GLOBmeas_165 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_673 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_153 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_405 | Mole fraction | search_system_registry |
| GLOBmeas_1 | Mole fraction | search_system_registry |
| GLOBmeas_131 | Mass fraction | search_system_registry |

#### Constraints (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_3 | Mole fraction | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 71 |
| Unique Properties | 11 |
| Unique Variables | 4 |
| Unique References | 71 |
| Unique Block_Types | 2 |
| Unique Phases | 3 |
| Unique Measurements | 26 |
| Unique Constraints | 3 |
| Total DOIs | 71 |
| Unique parent blocks | 129 |
| Explicit block/subsystem targets | 130 |
| Subsystem targets | 1 |
| Target-matched data points | 3,892 |

---

## 3. DOI & Block References

**Unique DOIs:** 71  |  **Parent blocks:** 129  |  **Explicit targets:** 130  |  **Subsystems:** 1  |  **Target-matched datapoints:** 3,892

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.12.004 | 2 | 2 | binary | search_system_registry |
| 10.1016/j.fluid.2005.08.001 | 2 | 43 | binary | search_system_registry |
| 10.1016/j.fluid.2005.08.018 | 3 | 13 | binary | search_system_registry |
| 10.1016/j.fluid.2006.02.023 | 3 | 33 | ternary | search_system_registry |
| 10.1016/j.fluid.2007.02.016 | 1 | 18 | ternary | search_system_registry |
| 10.1016/j.fluid.2007.06.001 | 1 | 8 | binary | search_system_registry |
| 10.1016/j.fluid.2007.06.007 | 4 | 102 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2007.07.011 | 5 | 70 | binary, ternary | search_system_registry |
| 10.1016/j.fluid.2007.07.063 | 2 | 18 | binary | search_system_registry |
| 10.1016/j.fluid.2007.12.003 | 3 | 109 | binary, ternary | search_system_registry |
| 10.1016/j.fluid.2007.12.008 | 1 | 84 | binary | search_system_registry |
| 10.1016/j.fluid.2008.03.012 | 1 | 78 | binary | search_system_registry |
| 10.1016/j.fluid.2008.04.010 | 1 | 10 | ternary | search_system_registry |
| 10.1016/j.fluid.2008.06.011 | 1 | 17 | binary | search_system_registry |
| 10.1016/j.fluid.2009.06.013 | 2 | 12 | ternary | search_system_registry |
| 10.1016/j.fluid.2009.06.015 | 4 | 76 | binary | search_system_registry |
| 10.1016/j.fluid.2009.11.010 | 2 | 38 | binary | search_system_registry |
| 10.1016/j.fluid.2009.11.030 | 1 | 113 | binary | search_system_registry |
| 10.1016/j.fluid.2010.08.024 | 4 | 26 | binary | search_system_registry |
| 10.1016/j.fluid.2011.11.005 | 5 | 152 | binary | search_system_registry |
| 10.1016/j.fluid.2012.06.031 | 2 | 26 | binary | search_system_registry |
| 10.1016/j.fluid.2013.10.029 | 2 | 75 | binary | search_system_registry |
| 10.1016/j.fluid.2014.05.031 | 1 | 56 | binary | search_blocks |
| 10.1016/j.fluid.2014.08.022 | 2 | 43 | binary | search_system_registry |
| 10.1016/j.fluid.2015.07.053 | 2 | 62 | binary, ternary | search_blocks |
| 10.1016/j.jct.2005.03.012 | 1 | 416 | binary | search_blocks |
| 10.1016/j.jct.2005.04.015 | 2 | 109 | binary | search_system_registry |
| 10.1016/j.jct.2005.06.018 | 1 | 27 | binary | search_blocks |
| 10.1016/j.jct.2005.07.011 | 1 | 94 | binary | search_system_registry |
| 10.1016/j.jct.2005.12.006 | 3 | 44 | binary | search_system_registry |
| 10.1016/j.jct.2006.08.001 | 2 | 37 | binary | search_system_registry |
| 10.1016/j.jct.2007.06.009 | 1 | 13 | binary | search_system_registry |
| 10.1016/j.jct.2008.02.019 | 2 | 52 | binary | search_system_registry |
| 10.1016/j.jct.2008.12.004 | 1 | 21 | binary | search_system_registry |
| 10.1016/j.jct.2009.07.001 | 2 | 48 | binary | search_system_registry |
| 10.1016/j.jct.2009.07.014 | 2 | 76 | binary | search_system_registry |
| 10.1016/j.jct.2011.05.014 | 2 | 24 | binary | search_system_registry |
| 10.1016/j.jct.2011.05.033 | 2 | 30 | binary | search_system_registry |
| 10.1016/j.jct.2012.02.037 | 2 | 24 | binary | search_system_registry |
| 10.1016/j.jct.2013.05.024 | 1 | 76 | binary | search_system_registry |
| 10.1016/j.jct.2013.06.018 | 1 | 16 | binary | search_system_registry |
| 10.1016/j.jct.2014.05.020 | 1 | 30 | binary | search_blocks |
| 10.1016/j.jct.2014.09.001 | 2 | 19 | binary | search_system_registry |
| 10.1016/j.jct.2015.01.003 | 2 | 76 | binary | search_system_registry |
| 10.1016/j.jct.2015.04.034 | 1 | 44 | binary | search_system_registry |
| 10.1016/j.jct.2015.06.004 | 2 | 73 | binary | search_system_registry |
| 10.1016/j.jct.2015.06.023 | 2 | 30 | binary | search_system_registry |
| 10.1016/j.jct.2016.08.003 | 2 | 18 | binary | search_system_registry |
| 10.1016/j.jct.2016.10.005 | 2 | 74 | binary | search_system_registry |
| 10.1016/j.jct.2016.12.036 | 2 | 18 | binary | search_system_registry |
| 10.1016/j.jct.2018.01.005 | 1 | 44 | binary | search_system_registry |
| 10.1016/j.jct.2018.07.013 | 4 | 44 | binary | search_system_registry |
| 10.1016/j.jct.2018.12.019 | 1 | 13 | binary | search_system_registry |
| 10.1016/j.jct.2019.105884 | 2 | 44 | binary | search_system_registry |
| 10.1016/j.tca.2004.09.012 | 2 | 20 | binary | search_system_registry |
| 10.1016/j.tca.2005.03.009 | 1 | 27 | binary | search_system_registry |
| 10.1016/j.tca.2005.06.011 | 1 | 3 | binary | search_system_registry |
| 10.1016/j.tca.2005.11.041 | 2 | 95 | binary | search_system_registry |
| 10.1016/j.tca.2006.02.028 | 1 | 13 | binary | search_blocks |
| 10.1016/j.tca.2006.08.006 | 2 | 380 | binary | search_system_registry |
| 10.1016/j.tca.2006.10.025 | 2 | 34 | binary | search_system_registry |
| 10.1016/j.tca.2007.04.012 | 1 | 25 | binary | search_system_registry |
| 10.1016/j.tca.2008.02.015 | 1 | 18 | binary | search_system_registry |
| 10.1016/j.tca.2009.03.014 | 1 | 14 | binary | search_system_registry |
| 10.1016/j.tca.2013.02.010 | 1 | 44 | binary | search_system_registry |
| 10.1016/j.tca.2017.05.023 | 1 | 1 | binary | search_blocks |
| 10.1021/je020149l | 3 | 63 | binary | search_system_registry |
| 10.1021/je030207i | 1 | 57 | binary | search_system_registry |
| 10.1021/je050006+ | 1 | 33 | binary | search_system_registry |
| 10.1021/je050052+ | 1 | 72 | binary | search_system_registry |
| 10.1021/je050175u | 1 | 75 | binary | search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.12.004 | PROPblock_10 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2004.12.004 | PROPblock_11 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.08.001 | PROPblock_13 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.08.001 | PROPblock_7 | declared | 23 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_10 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_11 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_12 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.02.023 | PROPblock_43 | declared | 11 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2006.02.023 | PROPblock_44 | declared | 11 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2006.02.023 | PROPblock_45 | declared | 11 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2007.02.016 | PROPblock_2 | declared | 18 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2007.06.001 | PROPblock_15 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.06.007 | PROPblock_1 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.06.007 | PROPblock_2 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.fluid.2007.06.007 | PROPblock_6 | declared | 32 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.06.007 | PROPblock_8 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.011 | PROPblock_10 | declared | 22 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2007.07.011 | PROPblock_11 | declared | 22 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2007.07.011 | PROPblock_3 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.011 | PROPblock_4 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.011 | PROPblock_9 | declared | 22 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2007.07.063 | PROPblock_7 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.063 | PROPblock_8 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.12.003 | PROPblock_7 | declared | 84 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2007.12.003 | PROPblock_8 | declared | 19 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2007.12.003 | PROPblock_9 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.12.008 | PROPblock_2 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.03.012 | PROPblock_4 | declared | 78 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.04.010 | PROPblock_14 | declared | 10 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2008.06.011 | PROPblock_1 | declared | 17 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.06.013 | PROPblock_2 | declared | 6 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2009.06.013 | PROPblock_3 | declared | 6 | ternary | 3 | search_system_registry |
| 10.1016/j.fluid.2009.06.015 | PROPblock_3 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.06.015 | PROPblock_4 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.06.015 | PROPblock_5 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.06.015 | PROPblock_6 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.11.010 | PROPblock_1 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.11.010 | PROPblock_2 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.11.030 | PROPblock_7 | declared | 113 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.08.024 | PROPblock_1 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.08.024 | PROPblock_2 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.08.024 | PROPblock_6 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.08.024 | PROPblock_7 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.005 | PROPblock_10 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.005 | PROPblock_4 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.005 | PROPblock_5 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.005 | PROPblock_6 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.005 | PROPblock_9 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.06.031 | PROPblock_12 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.06.031 | PROPblock_9 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.10.029 | PROPblock_14 | declared | 34 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.10.029 | PROPblock_15 | declared | 41 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.05.031 | PROPblock_4 | declared | 56 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.08.022 | PROPblock_1 | declared | 22 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.08.022 | PROPblock_3 | declared | 21 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.053 | PROPblock_1 | declared | 59 | ternary | — | search_blocks |
| 10.1016/j.fluid.2015.07.053 | PROPblock_1 | BLKsubsys_1 | 3 | binary | — | search_blocks |
| 10.1016/j.jct.2005.03.012 | PROPblock_3 | declared | 416 | binary | — | search_blocks |
| 10.1016/j.jct.2005.04.015 | PROPblock_1 | declared | 56 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.04.015 | PROPblock_3 | declared | 53 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.06.018 | PROPblock_4 | declared | 27 | binary | — | search_blocks |
| 10.1016/j.jct.2005.07.011 | PROPblock_1 | declared | 94 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.12.006 | PROPblock_1 | declared | 21 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.12.006 | PROPblock_5 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.12.006 | PROPblock_9 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.001 | PROPblock_3 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.001 | PROPblock_4 | declared | 21 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.06.009 | PROPblock_7 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.02.019 | PROPblock_12 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.02.019 | PROPblock_9 | declared | 33 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.12.004 | PROPblock_3 | declared | 21 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.07.001 | PROPblock_2 | declared | 21 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.07.001 | PROPblock_3 | declared | 27 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.07.014 | PROPblock_2 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.07.014 | PROPblock_3 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.05.014 | PROPblock_3 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.05.014 | PROPblock_4 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.05.033 | PROPblock_13 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.05.033 | PROPblock_14 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.02.037 | PROPblock_16 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.02.037 | PROPblock_17 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.05.024 | PROPblock_4 | declared | 76 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.018 | PROPblock_1 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2014.05.020 | PROPblock_1 | declared | 30 | binary | — | search_blocks |
| 10.1016/j.jct.2014.09.001 | PROPblock_14 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2014.09.001 | PROPblock_16 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.01.003 | PROPblock_1 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.01.003 | PROPblock_2 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.04.034 | PROPblock_4 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.06.004 | PROPblock_18 | declared | 34 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.06.004 | PROPblock_25 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.06.023 | PROPblock_6 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.06.023 | PROPblock_9 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.08.003 | PROPblock_17 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.08.003 | PROPblock_19 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.10.005 | PROPblock_1 | declared | 37 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.10.005 | PROPblock_2 | declared | 37 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.12.036 | PROPblock_24 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.12.036 | PROPblock_26 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.01.005 | PROPblock_3 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.07.013 | PROPblock_21 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.07.013 | PROPblock_24 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.07.013 | PROPblock_33 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.07.013 | PROPblock_36 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.12.019 | PROPblock_19 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2019.105884 | PROPblock_24 | declared | 22 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2019.105884 | PROPblock_30 | declared | 22 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2004.09.012 | PROPblock_10 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2004.09.012 | PROPblock_11 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2005.03.009 | PROPblock_3 | declared | 27 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2005.06.011 | PROPblock_1 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2005.11.041 | PROPblock_1 | declared | 57 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2005.11.041 | PROPblock_3 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2006.02.028 | PROPblock_1 | declared | 13 | binary | — | search_blocks |
| 10.1016/j.tca.2006.08.006 | PROPblock_13 | declared | 185 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2006.08.006 | PROPblock_15 | declared | 195 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2006.10.025 | PROPblock_22 | declared | 17 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2006.10.025 | PROPblock_24 | declared | 17 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2007.04.012 | PROPblock_12 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2008.02.015 | PROPblock_3 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2009.03.014 | PROPblock_14 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2013.02.010 | PROPblock_8 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2017.05.023 | PROPblock_1 | declared | 1 | binary | — | search_blocks |
| 10.1021/je020149l | PROPblock_10 | declared | 21 | binary | 2 | search_system_registry |
| 10.1021/je020149l | PROPblock_11 | declared | 20 | binary | 2 | search_system_registry |
| 10.1021/je020149l | PROPblock_12 | declared | 22 | binary | 2 | search_system_registry |
| 10.1021/je030207i | PROPblock_17 | declared | 57 | binary | 2 | search_system_registry |
| 10.1021/je050006+ | PROPblock_10 | declared | 33 | binary | 2 | search_system_registry |
| 10.1021/je050052+ | PROPblock_3 | declared | 72 | binary | 2 | search_system_registry |
| 10.1021/je050175u | PROPblock_1 | declared | 75 | binary | 2 | search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve methanol an… | 307 | KEEP | 307 | 3.8 |
| 2 | 1 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 449 | — | — | 164.6 |
| 3 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 234 | KEEP | 234 | 3.6 |
| 4 | 1 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 416 | — | — | 106.6 |
| 5 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve 1-propanol … | 225 | KEEP | 225 | 3.9 |
| 6 | 1 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 320 | — | — | 180.0 |
| 7 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve 1-butanol a… | 232 | KEEP | 232 | 3.6 |
| 8 | 1 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 381 | — | — | 113.1 |
| 9 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 369 | KEEP | 369 | 4.5 |
| 10 | 2 | `L1_query` | instruction=Look up the global component …, purpos… | 1,981 | — | — | 32.9 |
| 11 | 3 | `resolve_property_ids` | limit=5, min_score=50, purpose=Confirm GLOBprop_17… | 321 | KEEP | 321 | 4.5 |
| 12 | 3 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 247 | KEEP | 247 | 3.6 |
| 13 | 10 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_4… | 932 | KEEP | 887 | 21.1 |
| 14 | 12 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=20, p… | 989 | KEEP | 989 | 13.4 |
| 15 | 3 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 15,514 | — | — | 342.9 |
| 16 | 1 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 637 | KEEP | 623 | 20.6 |
| 17 | 5 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_2… | 732 | KEEP | 718 | 22.6 |
| 18 | 9 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_2 AS ethan…, explanat… | 860 | KEEP | 846 | 16.1 |
| 19 | 11 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_2 AS ethan…, explanat… | 838 | KEEP | 810 | 13.1 |
| 20 | 3 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 15,543 | — | — | 254.1 |
| 21 | 1 | `search_blocks` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=50, p… | 674 | DISCARD | 616 | 9.6 |
| 22 | 2 | `search_blocks` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=50, p… | 1,073 | KEEP | 1028 | 20.2 |
| 23 | 3 | `search_system_registry` | compound=GLOBcomp_5, limit=50, property=GLOBprop_1… | 1,404 | KEEP | 1244 | 20.2 |
| 24 | 4 | `search_system_registry` | compound=['GLOBcomp_5', 'GLOBcomp_1'], limit=20, p… | 715 | DISCARD | 648 | 12.0 |
| 25 | 3 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 10,618 | — | — | 142.3 |
| 26 | 1 | `search_blocks` | compound=['GLOBcomp_7', 'GLOBcomp_1'], limit=50, p… | 898 | DISCARD | 840 | 16.4 |
| 27 | 2 | `search_blocks` | compound=['GLOBcomp_7', 'GLOBcomp_1'], limit=50, p… | 753 | DISCARD | 695 | 13.7 |
| 28 | 3 | `search_system_registry` | compound=GLOBcomp_7, limit=50, property=GLOBprop_1… | 1,343 | KEEP | 1171 | 19.3 |
| 29 | 3 | `search_system_registry` | compound=['GLOBcomp_7', 'GLOBcomp_1'], limit=20, p… | 942 | KEEP | 830 | 12.4 |
| 30 | 3 | `L1_query` | context=Investigating whether nonidea…, id_catalog… | 3,932 | — | — | 127.0 |
| | | **TOTAL (30 tools)** | | **63,879** | | **13,880** | **1721.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,885 | 3,885 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 9,980 | 9,980 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 6,679 | 6,679 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 5,454 | 5,454 | 0 | 0.0% |
| 5 | interval=3 | skipped_by_agent | 6,333 | 6,333 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 547 | 10,152 | 3,003 | 14.7 |
| 2 | L1-worker | claudeopus46 | 20,643 | 985 | 21,628 | 707 | 5.3 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,313 | 22,956 | 15,025 | 64.4 |
| 4 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 475 | 3.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,563 | 23,206 | 8,171 | 49.5 |
| 6 | L1-worker | claudeopus46 | 20,643 | 11,355 | 31,998 | 3,058 | 15.5 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,495 | 3,851 | 867 | 6.1 |
| 8 | L1-worker | claudeopus46 | 536 | 2,375 | 2,911 | 918 | 6.7 |
| 9 | L1-worker | claudeopus46 | 1,323 | 4,562 | 5,885 | 2,165 | 9.7 |
| 10 | L1-worker | claudeopus46 | 298 | 1,249 | 1,547 | 855 | 3.9 |
| 11 | L1-worker | claudeopus46 | 298 | 2,887 | 3,185 | 1,587 | 6.8 |
| 12 | L1-worker | claudeopus46 | 1,160 | 7,229 | 8,389 | 1,588 | 8.7 |
| 13 | L1-worker | claudeopus46 | 20,643 | 921 | 21,564 | 624 | 5.3 |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,166 | 22,809 | 947 | 5.4 |
| 15 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 3.5 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,309 | 22,952 | 7,398 | 46.0 |
| 17 | L1-worker | claudeopus46 | 20,643 | 10,328 | 30,971 | 2,872 | 12.7 |
| 18 | L1-worker | claudeopus46 | 1,356 | 3,003 | 4,359 | 1,260 | 6.8 |
| 19 | L1-worker | claudeopus46 | 536 | 2,883 | 3,419 | 1,108 | 7.2 |
| 20 | L1-worker | claudeopus46 | 298 | 1,642 | 1,940 | 1,215 | 4.5 |
| 21 | L1-worker | claudeopus46 | 298 | 1,464 | 1,762 | 1,095 | 4.5 |
| 22 | L1-worker | claudeopus46 | 1,323 | 4,930 | 6,253 | 2,971 | 12.4 |
| 23 | L1-worker | claudeopus46 | 298 | 3,693 | 3,991 | 2,195 | 9.9 |
| 24 | L1-worker | claudeopus46 | 1,160 | 8,494 | 9,654 | 2,182 | 10.5 |
| 25 | L1-worker | claudeopus46 | 20,643 | 930 | 21,573 | 636 | 7.3 |
| 26 | L1-worker | claudeopus46 | 20,643 | 2,187 | 22,830 | 13,645 | 61.6 |
| 27 | L1-worker | claudeopus46 | 2,065 | 448 | 2,513 | 458 | 3.8 |
| 28 | L1-worker | claudeopus46 | 20,643 | 2,343 | 22,986 | 11,035 | 60.0 |
| 29 | L1-worker | claudeopus46 | 20,643 | 13,999 | 34,642 | 2,509 | 11.3 |
| 30 | L1-worker | claudeopus46 | 1,356 | 2,640 | 3,996 | 1,151 | 6.9 |
| 31 | L1-worker | claudeopus46 | 536 | 2,520 | 3,056 | 1,130 | 7.1 |
| 32 | L1-worker | claudeopus46 | 298 | 1,533 | 1,831 | 1,139 | 3.6 |
| 33 | L1-worker | claudeopus46 | 1,323 | 4,576 | 5,899 | 3,499 | 13.7 |
| 34 | L1-worker | claudeopus46 | 298 | 4,221 | 4,519 | 2,624 | 10.8 |
| 35 | L1-worker | claudeopus46 | 1,160 | 8,661 | 9,821 | 2,632 | 11.0 |
| 36 | L1-worker | claudeopus46 | 20,643 | 927 | 21,570 | 615 | 5.4 |
| 37 | L1-worker | claudeopus46 | 20,643 | 2,163 | 22,806 | 827 | 5.1 |
| 38 | L1-worker | claudeopus46 | 2,065 | 447 | 2,512 | 410 | 3.5 |
| 39 | L1-worker | claudeopus46 | 20,643 | 2,285 | 22,928 | 10,115 | 57.6 |
| 40 | L1-worker | claudeopus46 | 20,643 | 13,021 | 33,664 | 2,417 | 10.3 |
| 41 | L1-worker | claudeopus46 | 1,356 | 2,548 | 3,904 | 1,119 | 5.8 |
| 42 | L1-worker | claudeopus46 | 536 | 2,428 | 2,964 | 1,013 | 5.9 |
| 43 | L1-worker | claudeopus46 | 298 | 1,501 | 1,799 | 1,107 | 4.0 |
| 44 | L1-worker | claudeopus46 | 1,323 | 4,485 | 5,808 | 2,762 | 11.7 |
| 45 | L1-worker | claudeopus46 | 298 | 3,484 | 3,782 | 2,085 | 9.1 |
| 46 | L1-worker | claudeopus46 | 1,160 | 7,776 | 8,936 | 2,086 | 9.5 |
| 47 | L0-main | claudeopus46 | 9,605 | 3,084 | 12,689 | 15,085 | 70.7 |
| 48 | L1-worker | claudeopus46 | 20,643 | 790 | 21,433 | 613 | 4.8 |
| 49 | L1-worker | claudeopus46 | 20,643 | 2,024 | 22,667 | 1,274 | 6.4 |
| 50 | L1-worker | claudeopus46 | 2,065 | 667 | 2,732 | 577 | 4.4 |
| 51 | L1-worker | claudeopus46 | 20,643 | 2,302 | 22,945 | 495 | 4.5 |
| 52 | L1-worker | claudeopus46 | 1,356 | 626 | 1,982 | 327 | 3.3 |
| 53 | L1-worker | claudeopus46 | 536 | 506 | 1,042 | 372 | 3.4 |
| 54 | L1-worker | claudeopus46 | 1,323 | 2,430 | 3,753 | 446 | 5.0 |
| 55 | L1-worker | claudeopus46 | 298 | 1,168 | 1,466 | 288 | 2.5 |
| 56 | L1-worker | claudeopus46 | 747 | 3,531 | 4,278 | 396 | 4.0 |
| 57 | L0-main | claudeopus46 | 9,605 | 8,063 | 17,668 | 3,261 | 17.4 |
| 58 | L1-worker | claudeopus46 | 20,643 | 3,401 | 24,044 | 1,474 | 9.6 |
| 59 | L1-worker | claudeopus46 | 20,643 | 5,603 | 26,246 | 12,816 | 66.0 |
| 60 | L1-worker | claudeopus46 | 20,643 | 6,740 | 27,383 | 864 | 4.2 |
| 61 | L1-worker | claudeopus46 | 2,065 | 796 | 2,861 | 517 | 4.4 |
| 62 | L1-worker | claudeopus46 | 2,065 | 513 | 2,578 | 395 | 3.5 |
| 63 | L1-worker | claudeopus46 | 20,610 | 7,471 | 28,081 | 381 | 4.0 |
| 64 | L1-worker | claudeopus46 | 20,643 | 6,718 | 27,361 | 7,504 | 47.0 |
| 65 | L1-worker | claudeopus46 | 20,643 | 7,606 | 28,249 | 1,257 | 9.9 |
| 66 | L1-worker | claudeopus46 | 20,643 | 8,541 | 29,184 | 1,255 | 10.2 |
| 67 | L1-worker | claudeopus46 | 20,643 | 9,405 | 30,048 | 1,408 | 9.0 |
| 68 | L1-worker | claudeopus46 | 20,643 | 10,242 | 30,885 | 1,181 | 9.9 |
| 69 | L1-worker | claudeopus46 | 20,643 | 11,104 | 31,747 | 1,116 | 7.8 |
| 70 | L1-worker | claudeopus46 | 20,643 | 11,983 | 32,626 | 1,040 | 9.7 |
| 71 | L1-worker | claudeopus46 | 2,065 | 1,961 | 4,026 | 1,632 | 12.8 |
| 72 | L1-worker | claudeopus46 | 20,643 | 10,765 | 31,408 | 5,693 | 33.6 |
| 73 | L1-worker | claudeopus46 | 20,643 | 11,858 | 32,501 | 7,579 | 42.1 |
| 74 | L1-worker | claudeopus46 | 2,065 | 4,484 | 6,549 | 1,530 | 12.9 |
| 75 | L1-worker | claudeopus46 | 20,610 | 13,802 | 34,412 | 413 | 4.3 |
| 76 | L1-worker | claudeopus46 | 20,610 | 10,449 | 31,059 | 1,691 | 11.7 |
| 77 | L1-worker | claudeopus46 | 1,356 | 1,822 | 3,178 | 773 | 4.7 |
| 78 | L1-worker | claudeopus46 | 536 | 1,702 | 2,238 | 954 | 5.6 |
| 79 | L1-worker | claudeopus46 | 1,323 | 19,258 | 20,581 | 1,072 | 6.1 |
| 80 | L1-worker | claudeopus46 | 298 | 1,794 | 2,092 | 846 | 4.3 |
| 81 | L1-worker | claudeopus46 | 747 | 33,572 | 34,319 | 808 | 8.8 |
| 82 | L1-worker | claudeopus46 | 20,643 | 18,979 | 39,622 | 745 | 6.0 |
| 83 | L1-worker | claudeopus46 | 2,065 | 8,779 | 10,844 | 1,624 | 13.3 |
| 84 | L1-worker | claudeopus46 | 20,643 | 20,115 | 40,758 | 1,463 | 11.5 |
| 85 | L1-worker | claudeopus46 | 20,643 | 21,081 | 41,724 | 1,367 | 8.9 |
| 86 | L1-worker | claudeopus46 | 20,643 | 21,894 | 42,537 | 1,581 | 10.4 |
| 87 | L1-worker | claudeopus46 | 20,643 | 22,753 | 43,396 | 1,528 | 12.0 |
| 88 | L1-worker | claudeopus46 | 2,065 | 1,969 | 4,034 | 2,003 | 13.8 |
| 89 | L1-worker | claudeopus46 | 20,643 | 22,645 | 43,288 | 2,744 | 18.2 |
| 90 | L1-worker | claudeopus46 | 20,643 | 23,569 | 44,212 | 1,277 | 9.5 |
| 91 | L1-worker | claudeopus46 | 20,643 | 24,379 | 45,022 | 1,024 | 8.0 |
| 92 | L1-worker | claudeopus46 | 20,643 | 25,229 | 45,872 | 1,049 | 8.1 |
| 93 | L1-worker | claudeopus46 | 2,065 | 2,001 | 4,066 | 2,132 | 14.0 |
| 94 | L1-worker | claudeopus46 | 20,610 | 25,996 | 46,606 | 503 | 4.9 |
| 95 | L1-worker | claudeopus46 | 20,643 | 25,243 | 45,886 | 2,178 | 15.0 |
| 96 | L1-worker | claudeopus46 | 20,643 | 26,200 | 46,843 | 2,494 | 16.6 |
| 97 | L1-worker | claudeopus46 | 2,065 | 1,982 | 4,047 | 1,524 | 11.2 |
| 98 | L1-worker | claudeopus46 | 20,643 | 27,106 | 47,749 | 1,903 | 12.9 |
| 99 | L1-worker | claudeopus46 | 20,610 | 9,851 | 30,461 | 2,888 | 19.5 |
| 100 | L1-worker | claudeopus46 | 536 | 2,002 | 2,538 | 838 | 5.0 |
| 101 | L1-worker | claudeopus46 | 1,356 | 2,122 | 3,478 | 812 | 5.1 |
| 102 | L1-worker | claudeopus46 | 1,323 | 20,468 | 21,791 | 1,170 | 7.0 |
| 103 | L1-worker | claudeopus46 | 298 | 1,892 | 2,190 | 944 | 4.3 |
| 104 | L1-worker | claudeopus46 | 747 | 34,814 | 35,561 | 849 | 7.3 |
| 105 | L1-worker | claudeopus46 | 20,643 | 34,598 | 55,241 | 864 | 7.0 |
| 106 | L1-worker | claudeopus46 | 2,065 | 526 | 2,591 | 1,416 | 9.0 |
| 107 | L1-worker | claudeopus46 | 20,643 | 35,793 | 56,436 | 1,065 | 7.3 |
| 108 | L1-worker | claudeopus46 | 2,065 | 4,087 | 6,152 | 2,011 | 16.2 |
| 109 | L1-worker | claudeopus46 | 20,643 | 37,461 | 58,104 | 1,126 | 10.2 |
| 110 | L1-worker | claudeopus46 | 2,065 | 8,763 | 10,828 | 1,528 | 12.6 |
| 111 | L1-worker | claudeopus46 | 20,610 | 40,230 | 60,840 | 566 | 4.4 |
| 112 | L1-worker | claudeopus46 | 20,643 | 39,477 | 60,120 | 1,173 | 8.5 |
| 113 | L1-worker | claudeopus46 | 2,065 | 597 | 2,662 | 1,074 | 6.7 |
| 114 | L1-worker | claudeopus46 | 20,643 | 40,754 | 61,397 | 2,004 | 15.0 |
| 115 | L1-worker | claudeopus46 | 536 | 1,506 | 2,042 | 751 | 5.7 |
| 116 | L1-worker | claudeopus46 | 1,356 | 1,626 | 2,982 | 762 | 5.8 |
| 117 | L1-worker | claudeopus46 | 1,323 | 8,518 | 9,841 | 860 | 10.3 |
| 118 | L1-worker | claudeopus46 | 298 | 1,582 | 1,880 | 696 | 3.8 |
| 119 | L1-worker | claudeopus46 | 1,160 | 9,681 | 10,841 | 710 | 4.0 |
| 120 | L1-worker | claudeopus46 | 747 | 17,929 | 18,676 | 859 | 8.6 |
| 121 | L1-worker | claudeopus46 | 20,643 | 45,282 | 65,925 | 865 | 6.5 |
| 122 | L1-worker | claudeopus46 | 2,065 | 568 | 2,633 | 1,472 | 9.0 |
| 123 | L1-worker | claudeopus46 | 20,643 | 46,674 | 67,317 | 794 | 6.3 |
| 124 | L1-worker | claudeopus46 | 2,065 | 532 | 2,597 | 1,327 | 10.1 |
| 125 | L1-worker | claudeopus46 | 20,643 | 47,955 | 68,598 | 1,278 | 8.2 |
| 126 | L1-worker | claudeopus46 | 2,065 | 8,888 | 10,953 | 1,491 | 12.0 |
| 127 | L1-worker | claudeopus46 | 2,065 | 3,914 | 5,979 | 1,633 | 11.7 |
| 128 | L1-worker | claudeopus46 | 20,610 | 51,796 | 72,406 | 491 | 5.5 |
| 129 | L1-worker | claudeopus46 | 20,643 | 51,043 | 71,686 | 3,838 | 24.3 |
| 130 | L1-worker | claudeopus46 | 1,323 | 9,111 | 10,434 | 92 | 2.0 |
| 131 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.1 |
| 132 | L1-worker | claudeopus46 | 1,356 | 2,179 | 3,535 | 769 | 5.0 |
| 133 | L1-worker | claudeopus46 | 536 | 2,059 | 2,595 | 959 | 5.7 |
| 134 | L1-worker | claudeopus46 | 747 | 11,839 | 12,586 | 652 | 7.8 |
| 135 | L0-main | claudeopus46 | 9,572 | 7,976 | 17,548 | 2,581 | 17.0 |
| 136 | L0-main | claudeopus46 | 1,356 | 2,712 | 4,068 | 930 | 5.3 |
| 137 | L0-main | claudeopus46 | 1,323 | 62,241 | 63,564 | 3,744 | 21.6 |
| 138 | L0-main | claudeopus46 | 298 | 4,412 | 4,710 | 3,142 | 15.3 |


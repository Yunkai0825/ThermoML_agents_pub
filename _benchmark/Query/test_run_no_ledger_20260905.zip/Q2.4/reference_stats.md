# Reference Stats — query-agent

**Run started:** 2026-08-02 18:52:52
**Wall time (at last flush):** 1,099.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 51,002 | 112,146 | 36,512 | 163,148 | 20,393 | 195.1 | claudeopus46 |
| L1-worker | 76 | 580,383 | 767,979 | 166,688 | 1,348,362 | 17,741 | 932.6 | claudeopus46 |
| **TOTAL** | **84** | **631,385** | **880,125** | **203,200** | **1,511,510** | **17,994** | **1127.7** | |

**Estimated tokens:** ~377,877 input + ~50,800 output = ~428,677 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `search_system_summary` | 11 | 1 | 0 | 0 | 69 | 91 | 4,824 |
| `search_system_registry` | 81 | 1 | 5 | 4 | 69 | 91 | 4,824 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 75 | 1 | 6 | 3 | 62 | 100 | 7,683 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 86 | 1 | 6 | 6 | 60 | 100 | 4,954 |
| `search_system_summary` | 11 | 1 | 0 | 0 | 1104 | 2558 | 132,045 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 87 | 1 | 5 | 6 | 48 | 100 | 4,126 |
| `search_system_summary` | 11 | 1 | 0 | 0 | 295 | 753 | 30,819 |
| `search_system_registry` | 154 | 1 | 6 | 6 | 82 | 200 | 7,699 |
| `search_system_summary` | 11 | 1 | 0 | 0 | 1104 | 2558 | 132,045 |
| `search_system_registry` | 159 | 1 | 6 | 6 | 95 | 200 | 7,586 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 11 | 1 | 0 | 0 | 1104 | 2558 | 132,045 |
| `search_system_registry` | 86 | 1 | 6 | 6 | 60 | 100 | 4,954 |
| `search_system_registry` | 159 | 1 | 6 | 6 | 95 | 200 | 7,586 |
| `search_system_registry` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **944** | **13** | **46** | **43** | **4247** | **9609** | **481,190** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (350 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | search_system_registry, search_system_summary |
| GLOBcomp_1 | water | resolve_compound_ids, search_system_registry, search_system_summary |
| GLOBcomp_11 | heptane | search_system_registry, search_system_summary |
| GLOBcomp_42 | methylcyclohexane | search_system_registry, search_system_summary |
| GLOBcomp_538 | methyltrioctylammonium 1,1,1-trifluoro-N-[(trifluoromethyl)sulfonyl]methanesulfonamide | search_system_registry, search_system_summary |
| GLOBcomp_56 | 1-hexyl-3-methylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_system_registry, search_system_summary |
| GLOBcomp_103 | diethyl carbonate | search_system_registry, search_system_summary |
| GLOBcomp_47 | N-methylpyrrolidone | search_system_registry, search_system_summary |
| GLOBcomp_68 | 1-ethyl-3-methylimidazolium ethyl sulfate | search_system_registry, search_system_summary |
| GLOBcomp_121 | 1-methyl-3-octylimidazolium tetrafluoroborate | search_system_registry, search_system_summary |
| GLOBcomp_320 | 3,7-dimethyl-1,6-octadien-3-ol | search_system_registry, search_system_summary |
| GLOBcomp_3032 | benzyldimethylammonium propionate | search_system_registry |
| GLOBcomp_2820 | benzyldimethylammonium hexanoate | search_system_registry |
| GLOBcomp_2696 | N,N-dimethylbenzylammonium acetate | search_system_registry |
| GLOBcomp_158 | 1-butyl-3-methylimidazolium bromide | search_system_registry |
| GLOBcomp_322 | methylcyclopentane | search_system_registry |
| GLOBcomp_40 | trichloromethane | search_system_registry |
| GLOBcomp_152 | anisole | search_system_registry |
| GLOBcomp_13 | cyclohexane | search_system_registry |
| GLOBcomp_72 | cyclopentane | search_system_registry |
| GLOBcomp_302 | 1,3-dimethylimidazolium methylsulfate | search_system_registry |
| GLOBcomp_150 | 1-butyl-3-methylimidazolium methyl sulfate | search_system_registry |
| GLOBcomp_55 | 1-butyl-3-methylimidazolium hexafluorophosphate | search_system_registry |
| GLOBcomp_141 | 1-hexyl-3-methylimidazolium hexafluorophosphate | search_system_registry |
| GLOBcomp_163 | 1-octyl-3-methylimidazolium hexafluorophosphate | search_system_registry |
| GLOBcomp_12 | hexane | search_system_registry |
| GLOBcomp_39 | butanone | search_system_registry |
| GLOBcomp_182 | lithium bromide | search_system_registry |
| GLOBcomp_130 | 2-ethoxy-2-methylpropane | search_system_registry |
| GLOBcomp_779 | 2-hydroxyethylammonium formate | search_system_registry |
| GLOBcomp_519 | 1,3,3-trimethyl-2-oxabicyclo[2.2.2]octane | search_system_registry |
| GLOBcomp_8175 | 2,2'-methylenebisfuran | search_system_registry |
| GLOBcomp_364 | 1-butylpyridinium tetrafluoroborate | search_system_registry |
| GLOBcomp_546 | 2-hydroxyethylammonium acetate | search_system_registry |
| GLOBcomp_37 | 2,2,4-trimethylpentane | search_system_registry |
| GLOBcomp_8 | toluene | search_system_registry |
| GLOBcomp_334 | 1-methyl-3-propylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_system_registry |
| GLOBcomp_415 | 1-butyl-3-methylpyridinium tetrafluoroborate | search_system_registry |
| GLOBcomp_301 | 1-butyl-4-methylpyridinium tetrafluoroborate | search_system_registry |
| GLOBcomp_423 | 1-methyl-1-propylpyrrolidinium bis[(trifluoromethyl)sulfonyl]imide | search_system_registry |
| GLOBcomp_279 | 1-ethyl-3-methylimidazolium methylsulfate | search_system_registry |
| GLOBcomp_2502 | n-butylammonium butanoate | search_system_registry |
| GLOBcomp_682 | tributylmethylammonium bis((trifluoromethyl)sulfonyl)imide | search_system_registry |
| GLOBcomp_634 | choline bis(trifluoromethylsulfonyl)imide | search_system_registry |
| GLOBcomp_346 | butyltrimethylammonium bis(trifluoromethylsulfonyl)imide | search_system_registry |
| GLOBcomp_4784 | 1,2-dimethyl-5-nitroimidazole | search_system_registry |
| GLOBcomp_2998 | 2-methyl-5-nitro-1H-imidazole-1-ethanol | search_system_registry |
| GLOBcomp_58 | glycerol | search_system_registry |
| GLOBcomp_329 | 1-butyl-1-methylpyrrolidinium trifluoromethanesulfonate | search_system_registry |
| GLOBcomp_426 | 1-ethyl-3-methylimidazolium hydrogen sulfate | search_system_registry |
| GLOBcomp_8075 | C-butylresorcin[4]arene | search_system_registry |
| GLOBcomp_1000 | methyl 2-hydroxypropanoate | search_system_registry |
| GLOBcomp_390 | DL-ethyl lactate | search_system_registry |
| GLOBcomp_327 | 1-methylimidazole | search_system_registry |
| GLOBcomp_212 | 2-methylphenol | search_system_registry |
| GLOBcomp_229 | 3-methylphenol | search_system_registry |
| GLOBcomp_223 | 4-methylphenol | search_system_registry |
| GLOBcomp_1369 | butane, 1-(1,1-dimethylethoxy)- | search_system_registry |
| GLOBcomp_268 | 2-pyrrolidinone | search_system_registry |
| GLOBcomp_2610 | N,N-dimethylpropionamide | search_system_registry |
| GLOBcomp_10 | ethyl acetate | search_system_registry |
| GLOBcomp_46 | methyl ethanoate | search_system_registry |
| GLOBcomp_438 | 2-(N,N-dimethylamino)ethanol | search_system_registry |
| GLOBcomp_195 | 2-furaldehyde | search_system_registry |
| GLOBcomp_939 | 2-hydroxymethylfuran | search_system_registry |
| GLOBcomp_154 | propan-1,3-diol | search_system_registry |
| GLOBcomp_63 | N,N-dimethylethanamide | search_system_registry |
| GLOBcomp_317 | 3,6-dioxa-1-octanol | search_system_registry |
| GLOBcomp_35 | acetic acid | search_system_registry |
| GLOBcomp_27 | ethylbenzene | search_system_registry |
| GLOBcomp_631 | .beta.-pinene | search_system_registry |
| GLOBcomp_239 | 2-methyl-1-butanol | search_system_registry |
| GLOBcomp_273 | 1-methyl-3-octylimidazolium chloride | search_system_registry |
| GLOBcomp_64 | 1-ethyl-3-methylimidazolium bis((trifluoromethyl)sulfonyl)imide | search_system_registry |
| GLOBcomp_50 | 1-butyl-3-methylimidazolium bis(trifluoromethylsulfonyl)imide | search_system_registry |
| GLOBcomp_132 | 1-ethyl-3-methylimidazolium trifluoromethanesulfonate | search_system_registry |
| GLOBcomp_81 | N-methyldiethanolamine | search_system_registry, search_system_summary |
| GLOBcomp_262 | triethanolamine | search_system_registry |
| GLOBcomp_854 | 1-ethylpyridinium ethyl sulfate | search_system_registry |
| GLOBcomp_913 | tetrabutylphosphonium bromide | search_system_registry |
| GLOBcomp_24 | 1,2-ethanediol | search_system_registry, search_system_summary |
| GLOBcomp_36 | 1-butyl-3-methylimidazolium tetrafluoroborate | search_system_registry, search_system_summary |
| GLOBcomp_282 | zinc chloride | search_system_registry |
| GLOBcomp_123 | calcium chloride | search_system_registry |
| GLOBcomp_400 | calcium nitrate | search_system_registry |
| GLOBcomp_1003 | (S)-(-)-ethyl lactate | search_system_registry |
| GLOBcomp_730 | N-methylpiperazine | search_system_registry |
| GLOBcomp_14 | benzene | search_system_registry |
| GLOBcomp_96 | chlorobenzene | search_system_registry |
| GLOBcomp_1802 | boldine | search_system_registry |
| GLOBcomp_105 | 1-hexyl-3-methylimidazolium tetrafluoroborate | search_system_registry |
| GLOBcomp_110 | 1-butyl-3-methylimidazolium trifluoromethanesulfonate | search_system_registry |
| GLOBcomp_62 | dimethyl carbonate | search_system_registry |
| GLOBcomp_84 | 1-ethyl-3-methylimidazolium tetrafluoroborate | search_system_registry |
| GLOBcomp_3053 | tetraphenylphosphonium chloride | search_system_registry |
| GLOBcomp_217 | 1,3-dimethylimidazolium dimethylphosphate | search_system_registry |
| GLOBcomp_311 | trihexyl(tetradecyl)phosphonium chloride | search_system_registry |
| GLOBcomp_216 | 2-methylpropyl ethanoate | search_system_registry |
| GLOBcomp_315 | 1-hexyl-3-methylimidazolium trifluoromethanesulfonate | search_system_registry |
| GLOBcomp_1060 | 1-hexyl-3-methylimidazolium dicyanamide | search_system_registry |
| GLOBcomp_347 | trihexyltetradecylphosphonium bis(2,4,4-trimethylpentyl)phosphinate | search_system_registry |
| GLOBcomp_107 | lithium chloride | search_system_registry |
| GLOBcomp_557 | lithium iodide | search_system_registry |
| GLOBcomp_165 | sodium bromide | search_system_registry |
| GLOBcomp_336 | sodium iodide | search_system_registry |
| GLOBcomp_393 | potassium iodide | search_system_registry |
| GLOBcomp_326 | 1,5-pentanedioic acid | search_system_registry |
| GLOBcomp_253 | 1,6-hexanedioic acid | search_system_registry |
| GLOBcomp_3 | carbon dioxide | search_system_registry |
| GLOBcomp_126 | undecane | search_system_registry |
| GLOBcomp_21 | decane | search_system_registry |
| GLOBcomp_1707 | iodoethane | search_system_registry |
| GLOBcomp_387 | propanenitrile | search_system_registry |
| GLOBcomp_191 | 1,3,5-trimethylbenzene | search_system_registry |
| GLOBcomp_133 | formamide | search_system_registry |
| GLOBcomp_982 | (trifluoromethyl)benzene | search_system_registry |
| GLOBcomp_52 | diisopropyl ether | search_system_registry |
| GLOBcomp_697 | 1,3-dimethyl-2-imidazolidinone | search_system_registry |
| GLOBcomp_31 | dimethyl sulfoxide | search_system_registry |
| GLOBcomp_1385 | 4-morpholineethanol | search_system_registry |
| GLOBcomp_627 | zinc bromide | search_system_registry |
| GLOBcomp_199 | ammonia | search_system_registry |
| GLOBcomp_208 | 1,3-dioxolane | search_system_registry |
| GLOBcomp_41 | potassium chloride | search_system_registry, search_system_summary |
| GLOBcomp_233 | potassium nitrate | search_system_registry, search_system_summary |
| GLOBcomp_352 | 1,3-benzenediol | search_system_registry |
| GLOBcomp_1358 | 1,3-dimethylimidazolium chloride | search_system_registry |
| GLOBcomp_821 | cis-1,4-butenedioic acid | search_system_registry |
| GLOBcomp_2259 | 2,3-dihydroxybutanedioic acid | search_system_registry |
| GLOBcomp_291 | (+)-galactose | search_system_registry |
| GLOBcomp_464 | 4-aminobutanoic acid | search_system_registry |
| GLOBcomp_1016 | N,N-dimethylimidodicarbonimidic diamide hydrochloride | search_system_registry |
| GLOBcomp_389 | 2-amino-2-(hydroxymethyl)-1,3-propanediol | search_system_registry |
| GLOBcomp_6845 | L-glutamic acid hydrochloride | search_system_registry |
| GLOBcomp_551 | copper sulfate | search_system_registry |
| GLOBcomp_205 | 1-ethyl-3-methylimidazolium diethyl phosphate | search_system_registry |
| GLOBcomp_550 | 3-methylnonyl 1,2-benzenedioate | search_system_registry |
| GLOBcomp_4 | methanol | search_system_registry |
| GLOBcomp_222 | potassium bromide | search_system_registry |
| GLOBcomp_2030 | copper dinitrate | search_system_registry |
| GLOBcomp_806 | nickel chloride (NiCl2) | search_system_registry |
| GLOBcomp_382 | disodium hydrogen phosphate | search_system_registry |
| GLOBcomp_5 | propan-1-ol | search_system_registry, search_system_summary |
| GLOBcomp_575 | trisodium phosphate | search_system_registry |
| GLOBcomp_90 | D-glucose | search_system_registry, search_system_summary |
| GLOBcomp_252 | 1-ethyl-3-methylimidazolium thiocyanate | search_system_registry |
| GLOBcomp_1826 | 2-methylpiperidine | search_system_registry |
| GLOBcomp_900 | N-methylpiperidine | search_system_registry |
| GLOBcomp_1192 | 1-heptyl-3-methylimidazolium bromide | search_system_registry |
| GLOBcomp_1868 | 1-hexyl-3-methylimidazolium methyl sulfate | search_system_registry |
| GLOBcomp_2982 | 1-hexyl-3-methylimidazolium ethyl sulfate | search_system_registry |
| GLOBcomp_494 | L-ascorbic acid | search_system_registry |
| GLOBcomp_202 | triethylamine | search_system_registry |
| GLOBcomp_20 | butan-2-ol | search_system_registry |
| GLOBcomp_3019 | decanoic acid, 2-[4-[3-[2-(trifluoromethyl)-10H-phenothiazin-10-yl]propyl]-1-piperazinyl]ethyl ester | search_system_registry |
| GLOBcomp_219 | D-xylose | search_system_registry |
| GLOBcomp_374 | D-ribose | search_system_registry |
| GLOBcomp_26 | sodium chloride | search_system_registry, search_system_summary |
| GLOBcomp_293 | potassium citrate | search_system_registry |
| GLOBcomp_567 | ammonium dihydrogen phosphate | search_system_registry |
| GLOBcomp_2246 | urea phosphate | search_system_registry |
| GLOBcomp_261 | 3-hexyl-1-methyl-1H-imidazolium bromide | search_system_registry |
| GLOBcomp_2781 | 2-(hydroxymethyl)piperidine | search_system_registry |
| GLOBcomp_3038 | 3-(hydroxymethyl)piperidine | search_system_registry |
| GLOBcomp_7002 | .alpha.-picolyl alcohol | search_system_registry |
| GLOBcomp_5828 | .beta.-picolyl alcohol | search_system_registry |
| GLOBcomp_215 | magnesium sulfate | search_system_registry |
| GLOBcomp_800 | magnesium bromide (MgBr2) | search_system_registry |
| GLOBcomp_2160 | tetrabutylphosphonium tetrafluoroborate | search_system_registry |
| GLOBcomp_159 | D-fructose | search_system_registry |
| GLOBcomp_1760 | hexyltrimethylammonium bromide | search_system_registry |
| GLOBcomp_6 | propan-2-ol | search_system_registry |
| GLOBcomp_6661 | sodium n-hexylsulfonate | search_system_registry |
| GLOBcomp_737 | di(2-aminoethyl)amine | search_system_registry |
| GLOBcomp_1394 | N,N,N',N'-tetramethyl-1,2-diaminoethane | search_system_registry |
| GLOBcomp_1629 | N,N,N',N'-tetramethyl-1,3-propanediamine | search_system_registry |
| GLOBcomp_619 | N-methyl-1,3-diaminopropane | search_system_registry |
| GLOBcomp_201 | glycylglycine | search_system_registry |
| GLOBcomp_742 | glycyl-L-valine | search_system_registry |
| GLOBcomp_495 | glycyl-L-leucine | search_system_registry |
| GLOBcomp_1131 | lithium metaborate | search_system_registry |
| GLOBcomp_258 | lithium sulfate | search_system_registry |
| GLOBcomp_8008 | 2-hydroxyethylammonium stearate | search_system_registry |
| GLOBcomp_8150 | bis(2-hydroxyethyl)ammonium stearate | search_system_registry |
| GLOBcomp_94 | urea | search_system_registry |
| GLOBcomp_177 | N-methylformamide | search_system_registry |
| GLOBcomp_18 | dimethylformamide | search_system_registry |
| GLOBcomp_1910 | N-ethyl-N-methylpiperidinium bromide | search_system_registry |
| GLOBcomp_3836 | 1-methyl-1-propylpiperidinium bromide | search_system_registry |
| GLOBcomp_3095 | N-butyl-N-methylpiperidinium bromide | search_system_registry |
| GLOBcomp_3196 | sodium 2-naphthalenesulfonate | search_system_registry |
| GLOBcomp_1697 | sodium 1-naphthalene sulfonate | search_system_registry |
| GLOBcomp_53 | 2-aminoacetic acid | search_system_registry, search_system_summary |
| GLOBcomp_120 | D-sucrose | search_system_registry, search_system_summary |
| GLOBcomp_74 | (S)-2-aminopropanoic acid | search_system_registry, search_system_summary |
| GLOBcomp_168 | potassium sulfate | search_system_registry |
| GLOBcomp_489 | ammonium 2-hydroxypropane-1,2,3-tricarboxylate | search_system_registry |
| GLOBcomp_116 | L-valine | search_system_registry, search_system_summary |
| GLOBcomp_3293 | 2-hydroxy-N,N-dimethylethan-1-aminium butyrate | search_system_registry |
| GLOBcomp_160 | tetrabutylammonium bromide | search_system_registry, search_system_summary |
| GLOBcomp_4192 | N-(2-hydroxyethyl)butan-1-aminium butyrate | search_system_registry |
| GLOBcomp_873 | (S)-2-hydroxypropanoic acid | search_system_registry |
| GLOBcomp_2325 | diethylammonium butanoate | search_system_registry |
| GLOBcomp_555 | tetramethylammonium bromide | search_system_registry |
| GLOBcomp_369 | tetraethylammonium bromide | search_system_registry |
| GLOBcomp_493 | tetrapropylammonium bromide | search_system_registry |
| GLOBcomp_5019 | decyl beta.-D-glucopyranoside | search_system_registry |
| GLOBcomp_8167 | cholinium L-phenylalaninate | search_system_registry |
| GLOBcomp_8261 | butanoic acid, heptafluoro-, sodium salt | search_system_registry |
| GLOBcomp_363 | 1,4,7,10,13,16-hexaoxacyclooctadecane | search_system_registry |
| GLOBcomp_44 | 2-methylpropan-2-ol | search_system_registry |
| GLOBcomp_246 | sodium ethanoate | search_system_registry |
| GLOBcomp_221 | L-threonine | search_system_registry |
| GLOBcomp_1037 | magnesium acetate | search_system_registry |
| GLOBcomp_171 | L-serine | search_system_registry |
| GLOBcomp_25 | 1,4-dioxane | search_system_registry |
| GLOBcomp_15 | acetonitrile | search_system_registry |
| GLOBcomp_23 | tetrahydrofuran | search_system_registry |
| GLOBcomp_112 | hydrogen chloride | search_system_registry |
| GLOBcomp_61 | 1,2-propanediol | search_system_registry |
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_system_registry |
| GLOBcomp_381 | tetramethylurea | search_system_registry |
| GLOBcomp_413 | ethane-1,2-diamine | search_system_registry |
| GLOBcomp_5015 | imidazolium chloride | search_system_registry |
| GLOBcomp_920 | 1-methylimidazolium chloride | search_system_registry |
| GLOBcomp_99 | 1-butyl-3-methylimidazolium chloride | search_system_registry |
| GLOBcomp_213 | sodium dihydrogen phosphate | search_system_registry |
| GLOBcomp_517 | 1-methyl-3-octylimidazolium bromide | search_system_registry |
| GLOBcomp_491 | 1-methyl-3-propylimidazolium bromide | search_system_registry |
| GLOBcomp_169 | 1,4-butanediol | search_system_registry |
| GLOBcomp_118 | 2-methoxyethan-1-ol | search_system_registry |
| GLOBcomp_140 | 2-ethoxyethan-1-ol | search_system_registry |
| GLOBcomp_478 | 2-(2-methoxyethoxy)ethanol | search_system_registry |
| GLOBcomp_1395 | trimethylbenzylammonium chloride | search_system_registry |
| GLOBcomp_1986 | benzyltributylammonium chloride | search_system_registry |
| GLOBcomp_2388 | benzyltriethylammonium chloride | search_system_registry |
| GLOBcomp_2914 | glycyl-L-serylglycine | search_system_registry |
| GLOBcomp_2769 | (2S,4R)-4-hydroxypyrrolidine-2-carboxylic acid | search_system_registry |
| GLOBcomp_398 | 1,2-benzenediol | search_system_registry |
| GLOBcomp_343 | 1,4-benzenediol | search_system_registry |
| GLOBcomp_3200 | ammonium citrate, dibasic | search_system_registry |
| GLOBcomp_355 | L-histidine | search_system_registry |
| GLOBcomp_562 | 1-butyl-3-methylimidazolium octyl sulfate | search_system_registry |
| GLOBcomp_781 | thymidine | search_system_registry |
| GLOBcomp_467 | 1-propoxy-2-propanol | search_system_registry |
| GLOBcomp_675 | 3-aminopropanoic acid | search_system_registry |
| GLOBcomp_7855 | potassium 3-methoxy-3-oxopropanoate | search_system_registry |
| GLOBcomp_7847 | potassium 3-ethoxy-3-oxopropanoate | search_system_registry |
| GLOBcomp_6588 | uranium(VI) dinitrate dioxide hexahydrate | search_system_registry |
| GLOBcomp_635 | 1-butyl-3-methylimidazolium iodide | search_system_registry |
| GLOBcomp_203 | 1-butyl-3-methylimidazolium acetate | search_system_registry |
| GLOBcomp_823 | .beta.-cyclodextrin | search_system_registry |
| GLOBcomp_194 | dipotassium hydrogen phosphate | search_system_registry |
| GLOBcomp_1528 | 2,2-bis(hydroxymethyl)-1,3-propanediol | search_system_registry |
| GLOBcomp_134 | magnesium chloride | search_system_registry |
| GLOBcomp_709 | 2-[2-(2-methoxyethoxy)ethoxy]ethanol | search_system_registry |
| GLOBcomp_488 | glycylglycylglycine | search_system_registry |
| GLOBcomp_698 | thiamine hydrochloride | search_system_registry |
| GLOBcomp_639 | 5-hydroxy-6-methyl-3,4-pyridinedimethanol hydrochloride | search_system_registry |
| GLOBcomp_2882 | ethylurea | search_system_registry |
| GLOBcomp_2066 | 1,3-diethylurea | search_system_registry |
| GLOBcomp_1088 | N-butylurea | search_system_registry |
| GLOBcomp_831 | methylurea | search_system_registry |
| GLOBcomp_607 | 1,3-dimethylurea | search_system_registry |
| GLOBcomp_776 | 1-decyl-3-methylimidazolium chloride | search_system_registry |
| GLOBcomp_1846 | 1-dodecyl-3-methylimidazolium chloride | search_system_registry |
| GLOBcomp_456 | L-arginine | search_system_registry |
| GLOBcomp_894 | N-acetylglycine | search_system_registry |
| GLOBcomp_270 | trisodium citrate | search_system_registry |
| GLOBcomp_1178 | .beta.-adenosine | search_system_registry |
| GLOBcomp_926 | cytidine | search_system_registry |
| GLOBcomp_699 | uridine | search_system_registry |
| GLOBcomp_267 | monopotassium phosphate | search_system_registry |
| GLOBcomp_248 | phosphoric acid | search_system_registry |
| GLOBcomp_7060 | lithium dihydrogen phosphate | search_system_registry |
| GLOBcomp_224 | tripotassium phosphate | search_system_registry |
| GLOBcomp_819 | trimethylamine oxide | search_system_registry |
| GLOBcomp_979 | sarcosine | search_system_registry |
| GLOBcomp_2260 | (Dimethylamino)acetic acid | search_system_registry |
| GLOBcomp_502 | (trimethylammonio)acetate | search_system_registry |
| GLOBcomp_313 | citric acid | search_system_registry |
| GLOBcomp_1935 | 3-ethoxy-1-propanamine | search_system_registry |
| GLOBcomp_2043 | cetylpyridinium chloride | search_system_registry |
| GLOBcomp_1250 | N-methyl-N,N-dioctyl-1-octanaminium chloride | search_system_registry |
| GLOBcomp_1182 | 5-methylfurfural | search_system_registry |
| GLOBcomp_719 | butyl 2-hydroxypropanoate | search_system_registry |
| GLOBcomp_641 | methyl propenoate | search_system_registry |
| GLOBcomp_864 | ethyl levulinate | search_system_registry |
| GLOBcomp_1135 | butyl levulinate | search_system_registry |
| GLOBcomp_1289 | 2-tetrahydrofurylmethanol | search_system_registry |
| GLOBcomp_1493 | methyl levulinate | search_system_registry |
| GLOBcomp_1440 | sodium L-ascorbate | search_system_registry |
| GLOBcomp_335 | L-phenylalanine | search_system_registry |
| GLOBcomp_802 | L-arabinose | search_system_registry |
| GLOBcomp_1465 | 2-isopropylaminoethanol | search_system_registry |
| GLOBcomp_189 | 2-butoxyethan-1-ol | search_system_registry |
| GLOBcomp_2358 | 2-(2-methylpropoxy)ethanol | search_system_registry |
| GLOBcomp_377 | dodecyltrimethylammonium bromide | search_system_registry |
| GLOBcomp_761 | tetradecyltrimethylammonium bromide | search_system_registry |
| GLOBcomp_1177 | 3-hydroxypropylammonium formate | search_system_registry |
| GLOBcomp_2719 | guanidinium trifluoromethanesulfonate | search_system_registry |
| GLOBcomp_956 | potassium L-lysinate | search_system_registry |
| GLOBcomp_7 | butan-1-ol | search_system_registry |
| GLOBcomp_22 | pentan-1-ol | search_system_registry |
| GLOBcomp_38 | hexan-1-ol | search_system_registry |
| GLOBcomp_77 | heptan-1-ol | search_system_registry |
| GLOBcomp_34 | octan-1-ol | search_system_registry |
| GLOBcomp_156 | tetrahydropyran | search_system_registry |
| GLOBcomp_48 | 2-methoxy-2-methylpropane | search_system_registry |
| GLOBcomp_124 | 2-methoxy-2-methylbutane | search_system_registry |
| GLOBcomp_1004 | potassium L-prolinate | search_system_registry |
| GLOBcomp_915 | 1,3-dimethylimidazolium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_7255 | 1,3-dihexyl-1H-imidazol-3-ium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_7821 | 1,3-diheptyl-1H-imidazol-3-ium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_7991 | 1,3-dioctyl-1H-imidazol-3-ium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_572 | 1-methyl-3-pentylimidazolium bis(trifluoromethylsulfonyl)imide | search_system_registry |
| GLOBcomp_747 | 1-heptyl-3-methylimidazolium bis(trifluoromethylsulfonyl)amide | search_system_registry |
| GLOBcomp_1560 | 1-methyl-3-nonylimidazolium bis(trifluoromethanesulfonyl)imide | search_system_registry |
| GLOBcomp_6178 | 3-methyl-1-undecyl-1H-imidazol-3-ium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_1534 | 1,3-diethylimidazolium bis[(trifluoromethyl)sulfonyl]imide | search_system_registry |
| GLOBcomp_3750 | 1,3-dipropyl-1H-imidazol-3-ium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_1777 | 1,3-dibutyl-1H-imidazolium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_3359 | 1,3-dipentyl-1H-imidazol-3-ium bis((trifluoromethyl)sulfonyl)amide | search_system_registry |
| GLOBcomp_651 | 1-ethylpyridinium bis[(trifluoromethyl)sulfonyl]imide | search_system_registry |
| GLOBcomp_1614 | 1-ethylpyridinium triflate | search_system_registry |
| GLOBcomp_2850 | N5-aminocarbonyl-L-ornithine | search_system_registry |
| GLOBcomp_1124 | .alpha.-trehalose | search_system_registry |
| GLOBcomp_366 | tetradecyl(trihexyl)phosphonium dicyanamide | search_system_registry |
| GLOBcomp_113 | triethylene glycol | search_system_registry |
| GLOBcomp_2627 | aniline hydrochloride | search_system_registry |
| GLOBcomp_2210 | sodium pyruvate | search_system_registry |
| GLOBcomp_1159 | sodium (S)-2-amino-4-carboxybutanoate | search_system_registry |
| GLOBcomp_8123 | disodium 2-oxo-glutarate | search_system_registry |
| GLOBcomp_3186 | N-methyl-2-oxopyrrolidinium formate | search_system_registry |
| GLOBcomp_2526 | N-methyl-2-oxopyrrolidinium propionate | search_system_registry |
| GLOBcomp_231 | 1-ethyl-3-methylimidazolium chloride | search_system_registry |
| GLOBcomp_187 | ammonium sulfate | search_system_registry |
| GLOBcomp_91 | sodium sulfate | search_system_registry |
| GLOBcomp_6546 | ammonium methanesulfonate | search_system_registry |
| GLOBcomp_5293 | sodium methanesulfonate | search_system_registry |
| GLOBcomp_434 | tetramethylammonium chloride | search_system_registry |
| GLOBcomp_1643 | tetrapropylammonium chloride | search_system_registry |
| GLOBcomp_689 | tetraethylammonium chloride | search_system_registry |
| GLOBcomp_1380 | L-lysine | search_system_registry |
| GLOBcomp_1169 | 1-(dimethylamino)-2-propanol | search_system_registry |
| GLOBcomp_190 | cesium chloride | search_system_registry |
| GLOBcomp_844 | dipotassium L-tartrate | search_system_registry |
| GLOBcomp_65 | butyl ethanoate | search_system_registry |
| GLOBcomp_299 | 3-methylbutyl ethanoate | search_system_registry |
| GLOBcomp_3213 | heptyl ethanoate | search_system_registry |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_8 |  | search_system_registry, search_system_summary |
| GLOBprop_1 | Mass density, kg/m3 | search_system_registry, search_system_summary |

#### References (296 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2459 |  | search_system_registry, search_system_summary |
| GLOBlit_2765 |  | search_system_registry, search_system_summary |
| GLOBlit_2832 |  | search_system_registry, search_system_summary |
| GLOBlit_3347 |  | search_system_registry, search_system_summary |
| GLOBlit_10832 |  | search_system_registry, search_system_summary |
| GLOBlit_4825 |  | search_system_registry, search_system_summary |
| GLOBlit_5201 |  | search_system_registry, search_system_summary |
| GLOBlit_1591 |  | search_system_registry, search_system_summary |
| GLOBlit_10522 |  | search_system_registry, search_system_summary |
| GLOBlit_3425 |  | search_system_registry, search_system_summary |
| GLOBlit_5268 |  | search_system_registry, search_system_summary |
| GLOBlit_2800 |  | search_system_registry, search_system_summary |
| GLOBlit_4813 |  | search_system_registry, search_system_summary |
| GLOBlit_6134 |  | search_system_registry, search_system_summary |
| GLOBlit_3570 |  | search_system_registry, search_system_summary |
| GLOBlit_5152 |  | search_system_registry, search_system_summary |
| GLOBlit_6235 |  | search_system_registry, search_system_summary |
| GLOBlit_6342 |  | search_system_registry, search_system_summary |
| GLOBlit_2707 |  | search_system_registry, search_system_summary |
| GLOBlit_5422 |  | search_system_registry, search_system_summary |
| GLOBlit_349 |  | search_system_registry |
| GLOBlit_978 |  | search_system_registry |
| GLOBlit_2492 |  | search_system_registry |
| GLOBlit_2547 |  | search_system_registry |
| GLOBlit_2568 |  | search_system_registry |
| GLOBlit_2648 |  | search_system_registry |
| GLOBlit_2674 |  | search_system_registry |
| GLOBlit_2680 |  | search_system_registry |
| GLOBlit_2818 |  | search_system_registry |
| GLOBlit_2826 |  | search_system_registry |
| GLOBlit_2931 |  | search_system_registry |
| GLOBlit_3148 |  | search_system_registry |
| GLOBlit_3256 |  | search_system_registry |
| GLOBlit_3274 |  | search_system_registry |
| GLOBlit_3453 |  | search_system_registry |
| GLOBlit_3493 |  | search_system_registry |
| GLOBlit_3972 |  | search_system_registry |
| GLOBlit_4112 |  | search_system_registry |
| GLOBlit_4185 |  | search_system_registry |
| GLOBlit_4415 |  | search_system_registry |
| GLOBlit_4838 |  | search_system_registry |
| GLOBlit_4951 |  | search_system_registry |
| GLOBlit_5207 |  | search_system_registry |
| GLOBlit_5286 |  | search_system_registry |
| GLOBlit_5405 |  | search_system_registry |
| GLOBlit_5634 |  | search_system_registry |
| GLOBlit_5836 |  | search_system_registry |
| GLOBlit_6086 |  | search_system_registry |
| GLOBlit_6119 |  | search_system_registry |
| GLOBlit_6150 |  | search_system_registry |
| GLOBlit_6173 |  | search_system_registry |
| GLOBlit_6203 |  | search_system_registry |
| GLOBlit_6791 |  | search_system_registry |
| GLOBlit_7629 |  | search_system_registry |
| GLOBlit_7699 |  | search_system_registry |
| GLOBlit_8343 |  | search_system_registry |
| GLOBlit_8529 |  | search_system_registry |
| GLOBlit_8569 |  | search_system_registry |
| GLOBlit_8579 |  | search_system_registry |
| GLOBlit_8888 |  | search_system_registry |
| GLOBlit_8899 |  | search_system_registry |
| GLOBlit_8902 |  | search_system_registry |
| GLOBlit_8953 |  | search_system_registry |
| GLOBlit_9372 |  | search_system_registry |
| GLOBlit_10801 |  | search_system_registry |
| GLOBlit_11472 |  | search_system_registry |
| GLOBlit_11504 |  | search_system_registry |
| GLOBlit_11846 |  | search_system_registry |
| GLOBlit_11918 |  | search_system_registry |
| GLOBlit_59 |  | search_system_registry |
| GLOBlit_220 |  | search_system_registry, search_system_summary |
| GLOBlit_223 |  | search_system_registry |
| GLOBlit_237 |  | search_system_registry |
| GLOBlit_247 |  | search_system_registry |
| GLOBlit_267 |  | search_system_registry |
| GLOBlit_272 |  | search_system_registry |
| GLOBlit_323 |  | search_system_registry |
| GLOBlit_455 |  | search_system_registry |
| GLOBlit_516 |  | search_system_registry |
| GLOBlit_563 |  | search_system_registry |
| GLOBlit_659 |  | search_system_registry |
| GLOBlit_672 |  | search_system_registry |
| GLOBlit_725 |  | search_system_registry |
| GLOBlit_817 |  | search_system_registry |
| GLOBlit_858 |  | search_system_registry |
| GLOBlit_949 |  | search_system_registry |
| GLOBlit_990 |  | search_system_registry |
| GLOBlit_1121 |  | search_system_registry |
| GLOBlit_1163 |  | search_system_registry |
| GLOBlit_1220 |  | search_system_registry |
| GLOBlit_1483 |  | search_system_registry |
| GLOBlit_1742 |  | search_system_registry |
| GLOBlit_1770 |  | search_system_registry |
| GLOBlit_1796 |  | search_system_registry |
| GLOBlit_2092 |  | search_system_registry |
| GLOBlit_2283 |  | search_system_registry |
| GLOBlit_2432 |  | search_system_registry, search_system_summary |
| GLOBlit_2477 |  | search_system_registry |
| GLOBlit_2483 |  | search_system_registry |
| GLOBlit_2524 |  | search_system_registry |
| GLOBlit_2550 |  | search_system_registry |
| GLOBlit_2553 |  | search_system_registry |
| GLOBlit_2632 |  | search_system_registry |
| GLOBlit_2724 |  | search_system_registry |
| GLOBlit_2732 |  | search_system_registry |
| GLOBlit_2744 |  | search_system_registry |
| GLOBlit_2753 |  | search_system_registry |
| GLOBlit_2764 |  | search_system_registry |
| GLOBlit_2825 |  | search_system_registry |
| GLOBlit_2888 |  | search_system_registry |
| GLOBlit_2916 |  | search_system_registry |
| GLOBlit_2929 |  | search_system_registry |
| GLOBlit_2934 |  | search_system_registry |
| GLOBlit_2944 |  | search_system_registry |
| GLOBlit_3087 |  | search_system_registry |
| GLOBlit_14 |  | search_system_registry |
| GLOBlit_49 |  | search_system_registry |
| GLOBlit_67 |  | search_system_registry |
| GLOBlit_73 |  | search_system_registry |
| GLOBlit_81 |  | search_system_registry |
| GLOBlit_87 |  | search_system_registry |
| GLOBlit_96 |  | search_system_registry |
| GLOBlit_98 |  | search_system_registry |
| GLOBlit_107 |  | search_system_registry |
| GLOBlit_126 |  | search_system_registry |
| GLOBlit_174 |  | search_system_registry |
| GLOBlit_178 |  | search_system_registry |
| GLOBlit_189 |  | search_system_registry |
| GLOBlit_373 |  | search_system_registry |
| GLOBlit_385 |  | search_system_registry |
| GLOBlit_389 |  | search_system_registry |
| GLOBlit_391 |  | search_system_registry |
| GLOBlit_462 |  | search_system_registry |
| GLOBlit_484 |  | search_system_registry |
| GLOBlit_555 |  | search_system_registry |
| GLOBlit_590 |  | search_system_registry |
| GLOBlit_622 |  | search_system_registry |
| GLOBlit_716 |  | search_system_registry |
| GLOBlit_779 |  | search_system_registry |
| GLOBlit_787 |  | search_system_registry |
| GLOBlit_835 |  | search_system_registry |
| GLOBlit_865 |  | search_system_registry |
| GLOBlit_895 |  | search_system_registry |
| GLOBlit_917 |  | search_system_registry |
| GLOBlit_941 |  | search_system_registry |
| GLOBlit_955 |  | search_system_registry |
| GLOBlit_971 |  | search_system_registry |
| GLOBlit_976 |  | search_system_registry |
| GLOBlit_1049 |  | search_system_registry |
| GLOBlit_1096 |  | search_system_registry |
| GLOBlit_1107 |  | search_system_registry |
| GLOBlit_1117 |  | search_system_registry |
| GLOBlit_1147 |  | search_system_registry |
| GLOBlit_1170 |  | search_system_registry |
| GLOBlit_1214 |  | search_system_registry |
| GLOBlit_1223 |  | search_system_registry |
| GLOBlit_1243 |  | search_system_registry |
| GLOBlit_1249 |  | search_system_registry |
| GLOBlit_1310 |  | search_system_registry |
| GLOBlit_1311 |  | search_system_registry, search_system_summary |
| GLOBlit_1373 |  | search_system_registry |
| GLOBlit_1381 |  | search_system_registry |
| GLOBlit_1415 |  | search_system_registry |
| GLOBlit_1420 |  | search_system_registry |
| GLOBlit_1446 |  | search_system_registry |
| GLOBlit_1488 |  | search_system_registry |
| GLOBlit_1540 |  | search_system_registry |
| GLOBlit_1557 |  | search_system_registry |
| GLOBlit_1562 |  | search_system_registry |
| GLOBlit_9601 |  | search_system_summary |
| GLOBlit_5265 |  | search_system_summary |
| GLOBlit_4052 |  | search_system_summary |
| GLOBlit_3034 |  | search_system_summary |
| GLOBlit_4754 |  | search_system_summary |
| GLOBlit_2749 |  | search_system_summary |
| GLOBlit_2794 |  | search_system_summary |
| GLOBlit_3882 |  | search_system_summary |
| GLOBlit_5017 |  | search_system_summary |
| GLOBlit_2639 |  | search_system_summary |
| GLOBlit_4704 |  | search_system_summary |
| GLOBlit_2567 |  | search_system_summary |
| GLOBlit_5580 |  | search_system_summary |
| GLOBlit_7992 |  | search_system_summary |
| GLOBlit_9783 |  | search_system_summary |
| GLOBlit_4649 |  | search_system_summary |
| GLOBlit_149 |  | search_system_registry |
| GLOBlit_173 |  | search_system_registry |
| GLOBlit_1867 |  | search_system_registry |
| GLOBlit_1890 |  | search_system_registry |
| GLOBlit_1949 |  | search_system_registry |
| GLOBlit_2030 |  | search_system_registry |
| GLOBlit_2124 |  | search_system_registry |
| GLOBlit_2171 |  | search_system_registry |
| GLOBlit_2239 |  | search_system_registry, search_system_summary |
| GLOBlit_2274 |  | search_system_registry |
| GLOBlit_2528 |  | search_system_registry |
| GLOBlit_2535 |  | search_system_registry |
| GLOBlit_2625 |  | search_system_registry |
| GLOBlit_2652 |  | search_system_registry |
| GLOBlit_2673 |  | search_system_registry |
| GLOBlit_2733 |  | search_system_registry |
| GLOBlit_2736 |  | search_system_registry |
| GLOBlit_2820 |  | search_system_registry |
| GLOBlit_2831 |  | search_system_registry |
| GLOBlit_2834 |  | search_system_registry |
| GLOBlit_2842 |  | search_system_registry |
| GLOBlit_2879 |  | search_system_registry |
| GLOBlit_2900 |  | search_system_registry |
| GLOBlit_2911 |  | search_system_registry |
| GLOBlit_3007 |  | search_system_registry, search_system_summary |
| GLOBlit_3009 |  | search_system_registry |
| GLOBlit_3053 |  | search_system_registry |
| GLOBlit_3063 |  | search_system_registry |
| GLOBlit_3139 |  | search_system_registry |
| GLOBlit_3162 |  | search_system_registry |
| GLOBlit_3179 |  | search_system_registry |
| GLOBlit_3239 |  | search_system_registry |
| GLOBlit_3285 |  | search_system_registry, search_system_summary |
| GLOBlit_3307 |  | search_system_registry |
| GLOBlit_3319 |  | search_system_registry |
| GLOBlit_3346 |  | search_system_registry |
| GLOBlit_5043 |  | search_system_summary |
| GLOBlit_8239 |  | search_system_summary |
| GLOBlit_10102 |  | search_system_summary |
| GLOBlit_9821 |  | search_system_summary |
| GLOBlit_10011 |  | search_system_summary |
| GLOBlit_10162 |  | search_system_summary |
| GLOBlit_3781 |  | search_system_registry, search_system_summary |
| GLOBlit_8886 |  | search_system_summary |
| GLOBlit_10594 |  | search_system_summary |
| GLOBlit_4317 |  | search_system_summary |
| GLOBlit_4742 |  | search_system_summary |
| GLOBlit_9777 |  | search_system_summary |
| GLOBlit_3601 |  | search_system_registry, search_system_summary |
| GLOBlit_7113 |  | search_system_summary |
| GLOBlit_9758 |  | search_system_summary |
| GLOBlit_6686 |  | search_system_summary |
| GLOBlit_3429 |  | search_system_registry |
| GLOBlit_3459 |  | search_system_registry |
| GLOBlit_3464 |  | search_system_registry |
| GLOBlit_3496 |  | search_system_registry |
| GLOBlit_3506 |  | search_system_registry |
| GLOBlit_3605 |  | search_system_registry |
| GLOBlit_3623 |  | search_system_registry |
| GLOBlit_3653 |  | search_system_registry |
| GLOBlit_3710 |  | search_system_registry |
| GLOBlit_3754 |  | search_system_registry |
| GLOBlit_3758 |  | search_system_registry |
| GLOBlit_3760 |  | search_system_registry |
| GLOBlit_3764 |  | search_system_registry |
| GLOBlit_3789 |  | search_system_registry |
| GLOBlit_3798 |  | search_system_registry |
| GLOBlit_3802 |  | search_system_registry |
| GLOBlit_3812 |  | search_system_registry |
| GLOBlit_3819 |  | search_system_registry |
| GLOBlit_3875 |  | search_system_registry |
| GLOBlit_3881 |  | search_system_registry |
| GLOBlit_3889 |  | search_system_registry |
| GLOBlit_3912 |  | search_system_registry |
| GLOBlit_3932 |  | search_system_registry |
| GLOBlit_3955 |  | search_system_registry |
| GLOBlit_3962 |  | search_system_registry |
| GLOBlit_3967 |  | search_system_registry |
| GLOBlit_3990 |  | search_system_registry |
| GLOBlit_3991 |  | search_system_registry |
| GLOBlit_4023 |  | search_system_registry |
| GLOBlit_4042 |  | search_system_registry |
| GLOBlit_4053 |  | search_system_registry |
| GLOBlit_4056 |  | search_system_registry |
| GLOBlit_1593 |  | search_system_registry |
| GLOBlit_1623 |  | search_system_registry |
| GLOBlit_1666 |  | search_system_registry |
| GLOBlit_1671 |  | search_system_registry |
| GLOBlit_1691 |  | search_system_registry |
| GLOBlit_1705 |  | search_system_registry |
| GLOBlit_1728 |  | search_system_registry |
| GLOBlit_1733 |  | search_system_registry |
| GLOBlit_1738 |  | search_system_registry |
| GLOBlit_1747 |  | search_system_registry |
| GLOBlit_1753 |  | search_system_registry |
| GLOBlit_1847 |  | search_system_registry |
| GLOBlit_1860 |  | search_system_registry |
| GLOBlit_1904 |  | search_system_registry |
| GLOBlit_1926 |  | search_system_registry |
| GLOBlit_1936 |  | search_system_registry |
| GLOBlit_1975 |  | search_system_registry |
| GLOBlit_2025 |  | search_system_registry |
| GLOBlit_2045 |  | search_system_registry |
| GLOBlit_2046 |  | search_system_registry |
| GLOBlit_2048 |  | search_system_registry |
| GLOBlit_2098 |  | search_system_registry |
| GLOBlit_2101 |  | search_system_registry |
| GLOBlit_2114 |  | search_system_registry |
| GLOBlit_2116 |  | search_system_registry |
| GLOBlit_2159 |  | search_system_registry |
| GLOBlit_2163 |  | search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Constraints (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_system_registry |
| GLOBconstr_1 | Pressure, kPa | search_system_registry |
| GLOBconstr_4 | Frequency, MHz | search_system_registry |
| GLOBconstr_22 | Volume fraction | search_system_registry |
| GLOBconstr_3 | Mole fraction | search_system_registry |
| GLOBconstr_12 | Amount concentration (molarity), mol/dm3 | search_system_registry |
| GLOBconstr_8 | Molality, mol/kg | search_system_registry |
| GLOBconstr_5 | Mass fraction | search_system_registry |

#### Phases (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_system_registry |
| GLOBphase_3 |  | search_system_registry |
| GLOBphase_10 |  | search_system_registry |
| GLOBphase_4 |  | search_system_registry |
| GLOBphase_5 |  | search_system_registry |

#### Variables (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_system_registry |
| GLOBvar_1 | Temperature, K | search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_system_registry |
| GLOBvar_15 | Mass ratio of solute to solvent | search_system_registry |
| GLOBvar_9 | Amount concentration (molarity), mol/dm3 | search_system_registry |
| GLOBvar_5 | Mass fraction | search_system_registry |

#### Measurements (49 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_7 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_20 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_15 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_527 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_181 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_1324 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_206 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_573 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_261 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_209 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_194 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_694 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_18 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_394 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_958 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_277 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_811 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_970 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_138 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_147 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_1691 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_66 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_170 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_141 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_184 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_176 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_6 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_1497 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_167 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_1744 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_143 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_179 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_1662 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_280 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_56 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_153 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_187 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_1494 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_1694 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_861 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_190 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_311 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_845 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_1434 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_608 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_1325 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_767 | Mass density, kg/m3 | search_system_registry |

#### Solvents (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_2 |  | search_system_registry |
| GLOBsolvent_1 |  | search_system_registry |
| GLOBsolvent_11 |  | search_system_registry |
| GLOBsolvent_100 |  | search_system_registry |
| GLOBsolvent_23 |  | search_system_registry |
| GLOBsolvent_68 |  | search_system_registry |
| GLOBsolvent_387 |  | search_system_registry |
| GLOBsolvent_12 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 350 |
| Unique Properties | 2 |
| Unique References | 296 |
| Unique Block_Types | 1 |
| Unique Constraints | 8 |
| Unique Phases | 5 |
| Unique Variables | 7 |
| Unique Measurements | 49 |
| Unique Solvents | 8 |
| Total DOIs | 266 |
| Unique parent blocks | 587 |
| Explicit block/subsystem targets | 587 |
| Subsystem targets | 0 |
| Target-matched data points | 49,412 |

---

## 3. DOI & Block References

**Unique DOIs:** 266  |  **Parent blocks:** 587  |  **Explicit targets:** 587  |  **Subsystems:** 0  |  **Target-matched datapoints:** 26,686

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-005-8590-7 | 1 | 277 | binary | search_system_registry |
| 10.1007/s10765-007-0220-0 | 1 | 12 | binary | search_system_registry |
| 10.1007/s10765-008-0410-4 | 1 | 270 | binary | search_system_registry |
| 10.1007/s10765-008-0514-x | 4 | 27 | binary | search_system_registry |
| 10.1007/s10765-009-0567-5 | 1 | 12 | binary | search_system_registry |
| 10.1007/s10765-009-0602-6 | 1 | 39 | binary | search_system_registry |
| 10.1007/s10765-009-0651-x | 1 | 48 | binary | search_system_registry |
| 10.1007/s10765-010-0736-6 | 4 | 56 | binary | search_system_registry |
| 10.1007/s10765-010-0742-8 | 1 | 5 | binary | search_system_registry |
| 10.1007/s10765-010-0862-1 | 4 | 48 | binary | search_system_registry |
| 10.1007/s10765-011-1065-0 | 1 | 40 | binary | search_system_registry |
| 10.1007/s10765-013-1432-0 | 2 | 12 | binary | search_system_registry |
| 10.1007/s10765-015-2006-0 | 4 | 132 | binary | search_system_registry |
| 10.1007/s10765-015-2009-x | 1 | 24 | binary | search_system_registry |
| 10.1007/s10765-016-2089-2 | 1 | 45 | binary | search_system_registry |
| 10.1007/s10765-018-2359-2 | 1 | 20 | binary | search_system_registry |
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | search_system_registry |
| 10.1016/j.fluid.2004.11.022 | 1 | 39 | binary | search_system_registry |
| 10.1016/j.fluid.2005.01.004 | 2 | 54 | binary | search_system_registry |
| 10.1016/j.fluid.2005.02.015 | 1 | 14 | binary | search_system_registry |
| 10.1016/j.fluid.2005.05.012 | 1 | 39 | binary | search_system_registry |
| 10.1016/j.fluid.2005.05.023 | 1 | 713 | binary | search_system_registry |
| 10.1016/j.fluid.2005.10.022 | 2 | 210 | binary | search_system_registry |
| 10.1016/j.fluid.2006.01.008 | 2 | 26 | binary | search_system_registry |
| 10.1016/j.fluid.2006.03.012 | 1 | 4 | binary | search_system_registry |
| 10.1016/j.fluid.2006.05.007 | 1 | 45 | binary | search_system_registry |
| 10.1016/j.fluid.2006.05.015 | 2 | 156 | binary | search_system_registry |
| 10.1016/j.fluid.2006.05.028 | 2 | 40 | binary | search_system_registry |
| 10.1016/j.fluid.2006.11.005 | 1 | 84 | binary | search_system_registry |
| 10.1016/j.fluid.2006.12.005 | 2 | 10 | binary | search_system_registry |
| 10.1016/j.fluid.2007.01.043 | 2 | 4 | binary | search_system_registry |
| 10.1016/j.fluid.2007.04.030 | 1 | 99 | binary | search_system_registry |
| 10.1016/j.fluid.2007.07.066 | 4 | 220 | binary | search_system_registry |
| 10.1016/j.fluid.2007.08.020 | 1 | 11 | binary | search_system_registry |
| 10.1016/j.fluid.2008.01.004 | 4 | 280 | binary | search_system_registry |
| 10.1016/j.fluid.2008.04.003 | 1 | 35 | binary | search_system_registry |
| 10.1016/j.fluid.2008.09.004 | 6 | 390 | binary | search_system_registry |
| 10.1016/j.fluid.2008.11.001 | 1 | 13 | binary | search_system_registry |
| 10.1016/j.fluid.2009.06.008 | 1 | 42 | binary | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | 7 | 94 | binary | search_system_registry |
| 10.1016/j.fluid.2010.01.002 | 1 | 72 | binary | search_system_registry |
| 10.1016/j.fluid.2010.01.020 | 1 | 78 | binary | search_system_registry |
| 10.1016/j.fluid.2010.03.017 | 2 | 36 | binary | search_system_registry |
| 10.1016/j.fluid.2010.05.001 | 2 | 112 | binary | search_system_registry |
| 10.1016/j.fluid.2010.07.005 | 2 | 60 | binary | search_system_registry |
| 10.1016/j.fluid.2010.08.004 | 2 | 140 | binary | search_system_registry |
| 10.1016/j.fluid.2010.10.005 | 1 | 34 | binary | search_system_registry |
| 10.1016/j.fluid.2011.01.001 | 3 | 168 | binary | search_system_registry |
| 10.1016/j.fluid.2011.02.017 | 1 | 9 | binary | search_system_registry |
| 10.1016/j.fluid.2011.03.008 | 1 | 14 | binary | search_system_registry |
| 10.1016/j.fluid.2011.03.031 | 1 | 29 | binary | search_system_registry |
| 10.1016/j.fluid.2011.05.017 | 1 | 9 | binary | search_system_registry |
| 10.1016/j.fluid.2011.06.008 | 1 | 5 | binary | search_system_registry |
| 10.1016/j.fluid.2011.06.011 | 3 | 364 | binary | search_system_registry |
| 10.1016/j.fluid.2011.07.005 | 1 | 12 | binary | search_system_registry |
| 10.1016/j.fluid.2011.11.028 | 4 | 24 | binary | search_system_registry |
| 10.1016/j.fluid.2012.04.003 | 1 | 6 | binary | search_system_registry |
| 10.1016/j.fluid.2012.05.007 | 2 | 20 | binary | search_system_registry |
| 10.1016/j.fluid.2012.06.002 | 2 | 4 | binary | search_system_registry |
| 10.1016/j.fluid.2012.06.013 | 1 | 14 | binary | search_system_registry |
| 10.1016/j.fluid.2012.08.024 | 2 | 10 | binary | search_system_registry |
| 10.1016/j.fluid.2012.10.004 | 4 | 39 | binary | search_system_registry |
| 10.1016/j.fluid.2012.10.024 | 4 | 348 | binary | search_system_registry |
| 10.1016/j.fluid.2013.01.004 | 2 | 2 | binary | search_system_registry |
| 10.1016/j.fluid.2013.01.022 | 1 | 11 | binary | search_system_registry |
| 10.1016/j.fluid.2013.01.025 | 1 | 85 | binary | search_system_registry |
| 10.1016/j.fluid.2013.03.030 | 2 | 6 | binary | search_system_registry |
| 10.1016/j.fluid.2013.05.006 | 3 | 18 | binary | search_system_registry |
| 10.1016/j.fluid.2013.08.005 | 1 | 20 | binary | search_system_registry |
| 10.1016/j.fluid.2013.08.007 | 1 | 1,110 | binary | search_system_registry |
| 10.1016/j.fluid.2013.11.015 | 2 | 170 | binary | search_system_registry |
| 10.1016/j.fluid.2013.11.028 | 4 | 100 | binary | search_system_registry |
| 10.1016/j.fluid.2014.01.038 | 3 | 24 | binary | search_system_registry |
| 10.1016/j.fluid.2014.01.044 | 1 | 5 | binary | search_system_registry |
| 10.1016/j.fluid.2014.03.019 | 2 | 4 | binary | search_system_registry |
| 10.1016/j.fluid.2014.05.032 | 1 | 140 | binary | search_system_registry |
| 10.1016/j.fluid.2014.05.043 | 2 | 36 | binary | search_system_registry |
| 10.1016/j.fluid.2014.08.026 | 4 | 17 | binary | search_system_registry |
| 10.1016/j.fluid.2014.09.020 | 3 | 120 | binary | search_system_registry |
| 10.1016/j.fluid.2014.09.026 | 2 | 6 | binary | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | 12 | 588 | binary | search_system_registry |
| 10.1016/j.fluid.2014.11.009 | 2 | 36 | binary | search_system_registry |
| 10.1016/j.fluid.2014.12.040 | 1 | 84 | binary | search_system_registry |
| 10.1016/j.fluid.2015.03.031 | 1 | 9 | binary | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | 20 | 146 | binary | search_system_registry |
| 10.1016/j.fluid.2015.04.021 | 2 | 187 | binary | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | 15 | 210 | binary | search_system_registry |
| 10.1016/j.fluid.2015.06.034 | 1 | 4 | binary | search_system_registry |
| 10.1016/j.fluid.2015.06.043 | 2 | 77 | binary | search_system_registry |
| 10.1016/j.fluid.2015.07.004 | 4 | 17 | binary | search_system_registry |
| 10.1016/j.fluid.2015.07.012 | 3 | 248 | binary | search_system_registry |
| 10.1016/j.fluid.2015.07.022 | 1 | 1 | binary | search_system_registry |
| 10.1016/j.fluid.2015.07.030 | 1 | 125 | binary | search_system_registry |
| 10.1016/j.fluid.2015.08.005 | 6 | 116 | binary | search_system_registry |
| 10.1016/j.fluid.2015.09.036 | 2 | 6 | binary | search_system_registry |
| 10.1016/j.fluid.2015.12.053 | 1 | 77 | binary | search_system_registry |
| 10.1016/j.fluid.2016.01.023 | 3 | 17 | binary | search_system_registry |
| 10.1016/j.fluid.2016.01.036 | 2 | 8 | binary | search_system_registry |
| 10.1016/j.fluid.2016.02.035 | 2 | 252 | binary | search_system_registry |
| 10.1016/j.fluid.2016.03.016 | 4 | 92 | binary | search_system_registry |
| 10.1016/j.fluid.2016.05.024 | 2 | 100 | binary | search_system_registry |
| 10.1016/j.fluid.2016.06.019 | 2 | 18 | binary | search_system_registry |
| 10.1016/j.fluid.2016.07.022 | 2 | 8 | binary | search_system_registry |
| 10.1016/j.fluid.2016.08.036 | 1 | 50 | binary | search_system_registry |
| 10.1016/j.fluid.2017.02.002 | 1 | 195 | binary | search_system_registry |
| 10.1016/j.fluid.2017.02.019 | 2 | 80 | binary | search_system_registry |
| 10.1016/j.fluid.2017.04.006 | 2 | 18 | binary | search_system_registry |
| 10.1016/j.fluid.2017.04.007 | 3 | 92 | binary | search_system_registry |
| 10.1016/j.fluid.2017.04.010 | 3 | 6 | binary | search_system_registry |
| 10.1016/j.fluid.2017.09.005 | 3 | 216 | binary | search_system_registry |
| 10.1016/j.fluid.2017.09.012 | 1 | 15 | binary | search_system_registry |
| 10.1016/j.fluid.2017.09.019 | 2 | 129 | binary | search_system_registry |
| 10.1016/j.fluid.2017.10.034 | 2 | 65 | binary | search_system_registry |
| 10.1016/j.fluid.2017.11.009 | 1 | 8 | binary | search_system_registry |
| 10.1016/j.fluid.2017.12.001 | 2 | 178 | binary | search_system_registry |
| 10.1016/j.fluid.2018.01.030 | 1 | 12 | binary | search_system_registry |
| 10.1016/j.fluid.2018.02.003 | 5 | 19 | binary | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | 8 | 94 | binary | search_system_registry |
| 10.1016/j.fluid.2018.08.011 | 1 | 323 | binary | search_system_registry |
| 10.1016/j.fluid.2018.12.017 | 1 | 28 | binary | search_system_registry |
| 10.1016/j.fluid.2019.01.017 | 2 | 15 | binary | search_system_registry |
| 10.1016/j.jct.2004.07.019 | 1 | 565 | binary | search_system_registry |
| 10.1016/j.jct.2004.10.001 | 1 | 899 | binary | search_system_registry |
| 10.1016/j.jct.2004.12.002 | 1 | 84 | binary | search_system_registry |
| 10.1016/j.jct.2004.12.010 | 2 | 175 | binary | search_system_registry |
| 10.1016/j.jct.2005.01.009 | 3 | 115 | binary | search_system_registry |
| 10.1016/j.jct.2005.03.016 | 1 | 791 | binary | search_system_registry |
| 10.1016/j.jct.2005.03.021 | 1 | 162 | binary | search_system_registry |
| 10.1016/j.jct.2005.04.005 | 1 | 15 | binary | search_system_registry |
| 10.1016/j.jct.2005.04.019 | 2 | 24 | binary | search_system_registry |
| 10.1016/j.jct.2005.05.004 | 2 | 23 | binary | search_system_registry |
| 10.1016/j.jct.2005.05.007 | 1 | 19 | binary | search_system_registry |
| 10.1016/j.jct.2005.06.011 | 2 | 44 | binary | search_system_registry |
| 10.1016/j.jct.2005.10.013 | 1 | 24 | binary | search_system_registry |
| 10.1016/j.jct.2005.10.022 | 1 | 33 | binary | search_system_registry |
| 10.1016/j.jct.2005.12.010 | 2 | 78 | binary | search_system_registry |
| 10.1016/j.jct.2006.01.007 | 2 | 12 | binary | search_system_registry |
| 10.1016/j.jct.2006.03.009 | 3 | 15 | binary | search_system_registry |
| 10.1016/j.jct.2006.03.010 | 2 | 84 | binary | search_system_registry |
| 10.1016/j.jct.2006.03.018 | 2 | 44 | binary | search_system_registry |
| 10.1016/j.jct.2006.06.008 | 4 | 156 | binary | search_system_registry |
| 10.1016/j.jct.2006.07.021 | 1 | 102 | binary | search_system_registry |
| 10.1016/j.jct.2006.08.002 | 3 | 301 | binary | search_system_registry |
| 10.1016/j.jct.2006.08.003 | 4 | 20 | binary | search_system_registry |
| 10.1016/j.jct.2006.08.007 | 4 | 34 | binary | search_system_registry |
| 10.1016/j.jct.2006.09.006 | 2 | 21 | binary | search_system_registry |
| 10.1016/j.jct.2006.09.017 | 1 | 27 | binary | search_system_registry |
| 10.1016/j.jct.2006.10.016 | 1 | 55 | binary | search_system_registry |
| 10.1016/j.jct.2006.10.017 | 10 | 392 | binary | search_system_registry |
| 10.1016/j.jct.2007.02.008 | 6 | 234 | binary | search_system_registry |
| 10.1016/j.jct.2007.04.006 | 2 | 36 | binary | search_system_registry |
| 10.1016/j.jct.2007.04.009 | 1 | 12 | binary | search_system_registry |
| 10.1016/j.jct.2007.05.004 | 3 | 115 | binary | search_system_registry |
| 10.1016/j.jct.2007.05.005 | 2 | 78 | binary | search_system_registry |
| 10.1016/j.jct.2007.05.010 | 4 | 36 | binary | search_system_registry |
| 10.1016/j.jct.2007.05.011 | 3 | 585 | binary | search_system_registry |
| 10.1016/j.jct.2007.05.015 | 6 | 195 | binary | search_system_registry |
| 10.1016/j.jct.2007.06.007 | 2 | 80 | binary | search_system_registry |
| 10.1016/j.jct.2007.10.007 | 3 | 33 | binary | search_system_registry |
| 10.1016/j.jct.2007.11.010 | 1 | 100 | binary | search_system_registry |
| 10.1016/j.jct.2008.01.003 | 1 | 130 | binary | search_system_registry |
| 10.1016/j.jct.2008.01.018 | 1 | 120 | binary | search_system_registry |
| 10.1016/j.jct.2008.01.023 | 2 | 25 | binary | search_system_registry |
| 10.1016/j.jct.2008.02.019 | 1 | 28 | binary | search_system_registry |
| 10.1016/j.jct.2008.03.007 | 2 | 39 | binary | search_system_registry |
| 10.1016/j.jct.2008.03.013 | 1 | 39 | binary | search_system_registry |
| 10.1016/j.jct.2008.04.006 | 1 | 39 | binary | search_system_registry |
| 10.1016/j.jct.2008.09.005 | 4 | 325 | binary | search_system_registry |
| 10.1016/j.jct.2008.09.008 | 1 | 10 | binary | search_system_registry |
| 10.1016/j.jct.2009.01.010 | 4 | 64 | binary | search_system_registry |
| 10.1016/j.jct.2009.03.004 | 3 | 150 | binary | search_system_registry |
| 10.1016/j.jct.2009.05.004 | 1 | 441 | binary | search_system_registry |
| 10.1016/j.jct.2009.08.004 | 1 | 5 | binary | search_system_registry |
| 10.1016/j.jct.2009.08.016 | 1 | 26 | binary | search_system_registry |
| 10.1016/j.jct.2009.10.007 | 1 | 75 | binary | search_system_registry |
| 10.1016/j.jct.2009.11.017 | 1 | 57 | binary | search_system_registry |
| 10.1016/j.jct.2010.04.018 | 3 | 110 | binary | search_system_registry |
| 10.1016/j.jct.2010.05.016 | 1 | 20 | binary | search_system_registry |
| 10.1016/j.jct.2010.07.014 | 1 | 33 | binary | search_system_registry |
| 10.1016/j.jct.2010.08.021 | 3 | 348 | binary | search_system_registry |
| 10.1016/j.jct.2010.11.003 | 1 | 80 | binary | search_system_registry |
| 10.1016/j.jct.2010.11.017 | 2 | 84 | binary | search_system_registry |
| 10.1016/j.jct.2011.01.013 | 6 | 72 | binary | search_system_registry |
| 10.1016/j.jct.2011.01.014 | 2 | 390 | binary | search_system_registry |
| 10.1016/j.jct.2011.06.021 | 2 | 143 | binary | search_system_registry |
| 10.1016/j.jct.2011.07.002 | 1 | 10 | binary | search_system_registry |
| 10.1016/j.jct.2011.08.028 | 1 | 13 | binary | search_system_registry |
| 10.1016/j.jct.2011.09.008 | 1 | 145 | binary | search_system_registry |
| 10.1016/j.jct.2011.09.016 | 3 | 133 | binary | search_system_registry |
| 10.1016/j.jct.2011.11.007 | 1 | 42 | binary | search_system_registry |
| 10.1016/j.jct.2011.11.014 | 2 | 138 | binary | search_system_registry |
| 10.1016/j.jct.2011.11.028 | 1 | 91 | binary | search_system_registry |
| 10.1016/j.jct.2012.02.023 | 2 | 89 | binary | search_system_registry |
| 10.1016/j.jct.2012.03.025 | 6 | 330 | binary | search_system_registry |
| 10.1016/j.jct.2012.03.029 | 1 | 4 | binary | search_system_registry |
| 10.1016/j.jct.2012.04.020 | 2 | 52 | binary | search_system_registry |
| 10.1016/j.jct.2012.05.033 | 3 | 34 | binary | search_system_registry |
| 10.1016/j.jct.2012.08.023 | 4 | 87 | binary | search_system_registry |
| 10.1016/j.jct.2012.10.018 | 2 | 80 | binary | search_system_registry |
| 10.1016/j.jct.2012.10.027 | 2 | 78 | binary | search_system_registry |
| 10.1016/j.jct.2012.11.001 | 1 | 24 | binary | search_system_registry |
| 10.1016/j.jct.2012.11.007 | 7 | 35 | binary | search_system_registry |
| 10.1016/j.jct.2012.11.032 | 3 | 447 | binary | search_system_registry |
| 10.1016/j.jct.2012.12.010 | 3 | 115 | binary | search_system_registry |
| 10.1016/j.jct.2012.12.022 | 3 | 100 | binary | search_system_registry |
| 10.1016/j.jct.2012.12.028 | 3 | 168 | binary | search_system_registry |
| 10.1016/j.jct.2013.01.012 | 8 | 120 | binary | search_system_registry |
| 10.1016/j.jct.2013.01.023 | 5 | 25 | binary | search_system_registry |
| 10.1016/j.jct.2013.04.017 | 1 | 104 | binary | search_system_registry |
| 10.1016/j.jct.2013.05.003 | 1 | 227 | binary | search_system_registry |
| 10.1016/j.jct.2013.05.012 | 2 | 60 | binary | search_system_registry |
| 10.1016/j.jct.2013.05.037 | 2 | 8 | binary | search_system_registry |
| 10.1016/j.jct.2013.06.020 | 11 | 243 | binary | search_system_registry |
| 10.1016/j.jct.2013.07.027 | 1 | 84 | binary | search_system_registry |
| 10.1016/j.jct.2013.08.010 | 4 | 132 | binary | search_system_registry |
| 10.1016/j.jct.2013.08.016 | 2 | 88 | binary | search_system_registry |
| 10.1016/j.jct.2013.08.021 | 1 | 39 | binary | search_system_registry |
| 10.1016/j.jct.2013.09.008 | 4 | 78 | binary | search_system_registry |
| 10.1016/j.jct.2013.09.009 | 1 | 1 | binary | search_system_registry |
| 10.1016/j.jct.2013.10.013 | 3 | 145 | binary | search_system_registry |
| 10.1016/j.jct.2013.11.001 | 2 | 2 | binary | search_system_registry |
| 10.1016/j.jct.2013.11.015 | 4 | 165 | binary | search_system_registry |
| 10.1016/j.jct.2013.11.021 | 1 | 20 | binary | search_system_registry |
| 10.1016/j.jct.2014.01.030 | 1 | 39 | binary | search_system_registry |
| 10.1016/j.jct.2014.06.004 | 1 | 13 | binary | search_system_registry |
| 10.1016/j.jct.2015.06.024 | 1 | 40 | binary | search_system_registry |
| 10.1016/j.jct.2016.09.007 | 1 | 105 | binary | search_system_registry |
| 10.1016/j.jct.2016.09.024 | 3 | 168 | binary | search_system_registry |
| 10.1016/j.jct.2016.09.037 | 2 | 60 | binary | search_system_registry |
| 10.1016/j.jct.2017.01.011 | 1 | 40 | binary | search_system_registry |
| 10.1016/j.jct.2017.12.009 | 1 | 84 | binary | search_system_registry |
| 10.1016/j.jct.2018.02.022 | 1 | 152 | binary | search_system_registry |
| 10.1016/j.jct.2018.03.007 | 1 | 44 | binary | search_system_registry |
| 10.1016/j.jct.2018.06.006 | 1 | 119 | binary | search_system_registry |
| 10.1016/j.jct.2018.07.013 | 2 | 26 | binary | search_system_registry |
| 10.1016/j.jct.2018.12.019 | 1 | 65 | binary | search_system_registry |
| 10.1016/j.jct.2018.12.039 | 3 | 78 | binary | search_system_registry |
| 10.1016/j.tca.2005.04.030 | 1 | 28 | binary | search_system_registry |
| 10.1016/j.tca.2009.03.014 | 1 | 14 | binary | search_system_registry |
| 10.1016/j.tca.2013.05.015 | 1 | 40 | binary | search_system_registry |
| 10.1016/j.tca.2013.09.017 | 2 | 10 | binary | search_system_registry |
| 10.1016/j.tca.2013.12.016 | 2 | 96 | binary | search_system_registry |
| 10.1016/j.tca.2014.03.038 | 1 | 33 | binary | search_system_registry |
| 10.1016/j.tca.2014.06.031 | 1 | 13 | binary | search_system_registry |
| 10.1016/j.tca.2014.11.009 | 1 | 64 | binary | search_system_registry |
| 10.1016/j.tca.2015.04.032 | 1 | 84 | binary | search_system_registry |
| 10.1016/j.tca.2016.09.005 | 1 | 84 | binary | search_system_registry |
| 10.1021/acs.jced.5b01000 | 1 | 39 | binary | search_system_registry |
| 10.1021/acs.jced.8b00723 | 1 | 3 | binary | search_system_registry |
| 10.1021/acs.jced.8b01012 | 1 | 44 | binary | search_system_registry |
| 10.1021/je0342825 | 1 | 39 | binary | search_system_registry |
| 10.1021/je049912x | 1 | 20 | binary | search_system_registry |
| 10.1021/je050006+ | 1 | 36 | binary | search_system_registry |
| 10.1021/je0500330 | 1 | 18 | binary | search_system_registry |
| 10.1021/je0601098 | 1 | 12 | binary | search_system_registry |
| 10.1021/je060123k | 1 | 33 | binary | search_system_registry |
| 10.1021/je060126x | 1 | 26 | binary | search_system_registry |
| 10.1021/je060228n | 1 | 36 | binary | search_system_registry |
| 10.1021/je100967k | 1 | 44 | binary | search_system_registry |
| 10.1021/je500594z | 3 | 144 | binary | search_system_registry |
| 10.1021/je7001804 | 1 | 78 | binary | search_system_registry |
| 10.1021/je700245a | 2 | 174 | binary | search_system_registry |
| 10.1021/je800981d | 1 | 33 | binary | search_system_registry |
| 10.1021/je900064e | 1 | 8 | binary | search_system_registry |
| 10.1021/je900888e | 1 | 14 | binary | search_system_registry |
| 10.1021/je9010882 | 1 | 10 | binary | search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-005-8590-7 | PROPblock_2 | declared | 277 | binary | 2 | search_system_registry |
| 10.1007/s10765-007-0220-0 | PROPblock_2 | declared | 12 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0410-4 | PROPblock_2 | declared | 270 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0514-x | PROPblock_1 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0514-x | PROPblock_2 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0514-x | PROPblock_3 | declared | 9 | binary | 2 | search_system_registry |
| 10.1007/s10765-008-0514-x | PROPblock_4 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0567-5 | PROPblock_2 | declared | 12 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0602-6 | PROPblock_2 | declared | 39 | binary | 2 | search_system_registry |
| 10.1007/s10765-009-0651-x | PROPblock_3 | declared | 48 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0736-6 | PROPblock_1 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0736-6 | PROPblock_2 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0736-6 | PROPblock_3 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0736-6 | PROPblock_4 | declared | 14 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0742-8 | PROPblock_3 | declared | 5 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0862-1 | PROPblock_3 | declared | 15 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0862-1 | PROPblock_4 | declared | 15 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0862-1 | PROPblock_5 | declared | 9 | binary | 2 | search_system_registry |
| 10.1007/s10765-010-0862-1 | PROPblock_6 | declared | 9 | binary | 2 | search_system_registry |
| 10.1007/s10765-011-1065-0 | PROPblock_4 | declared | 40 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1432-0 | PROPblock_7 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-013-1432-0 | PROPblock_8 | declared | 6 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-2006-0 | PROPblock_5 | declared | 40 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-2006-0 | PROPblock_6 | declared | 16 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-2006-0 | PROPblock_7 | declared | 40 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-2006-0 | PROPblock_8 | declared | 36 | binary | 2 | search_system_registry |
| 10.1007/s10765-015-2009-x | PROPblock_3 | declared | 24 | binary | 2 | search_system_registry |
| 10.1007/s10765-016-2089-2 | PROPblock_3 | declared | 45 | binary | 2 | search_system_registry |
| 10.1007/s10765-018-2359-2 | PROPblock_4 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2004.11.022 | PROPblock_3 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.01.004 | PROPblock_1 | declared | 27 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.01.004 | PROPblock_2 | declared | 27 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.02.015 | PROPblock_20 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.05.012 | PROPblock_18 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.05.023 | PROPblock_3 | declared | 713 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.10.022 | PROPblock_6 | declared | 96 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2005.10.022 | PROPblock_8 | declared | 114 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.01.008 | PROPblock_27 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.01.008 | PROPblock_28 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.03.012 | PROPblock_6 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.05.007 | PROPblock_1 | declared | 45 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.05.015 | PROPblock_2 | declared | 42 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.05.015 | PROPblock_3 | declared | 114 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.05.028 | PROPblock_7 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.05.028 | PROPblock_9 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.11.005 | PROPblock_4 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.12.005 | PROPblock_3 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2006.12.005 | PROPblock_4 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.01.043 | PROPblock_2 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.01.043 | PROPblock_4 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.04.030 | PROPblock_10 | declared | 99 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.066 | PROPblock_5 | declared | 95 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.066 | PROPblock_6 | declared | 95 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.066 | PROPblock_7 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.07.066 | PROPblock_8 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2007.08.020 | PROPblock_11 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.01.004 | PROPblock_2 | declared | 125 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.01.004 | PROPblock_3 | declared | 125 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.01.004 | PROPblock_4 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.01.004 | PROPblock_5 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.04.003 | PROPblock_2 | declared | 35 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.09.004 | PROPblock_22 | declared | 60 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.09.004 | PROPblock_25 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.09.004 | PROPblock_28 | declared | 60 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.09.004 | PROPblock_31 | declared | 66 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.09.004 | PROPblock_33 | declared | 54 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.09.004 | PROPblock_35 | declared | 66 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2008.11.001 | PROPblock_8 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.06.008 | PROPblock_2 | declared | 42 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_14 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_16 | declared | 28 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_18 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_20 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_22 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_24 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2009.07.010 | PROPblock_26 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.01.002 | PROPblock_19 | declared | 72 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.01.020 | PROPblock_26 | declared | 78 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.03.017 | PROPblock_3 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.03.017 | PROPblock_7 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.05.001 | PROPblock_11 | declared | 52 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.05.001 | PROPblock_7 | declared | 60 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.07.005 | PROPblock_13 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.07.005 | PROPblock_8 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.08.004 | PROPblock_1 | declared | 70 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.08.004 | PROPblock_2 | declared | 70 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2010.10.005 | PROPblock_1 | declared | 34 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.01.001 | PROPblock_7 | declared | 56 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.01.001 | PROPblock_8 | declared | 56 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.01.001 | PROPblock_9 | declared | 56 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.02.017 | PROPblock_2 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.03.008 | PROPblock_6 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.03.031 | PROPblock_2 | declared | 29 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.05.017 | PROPblock_2 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.06.008 | PROPblock_6 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.06.011 | PROPblock_12 | declared | 52 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.06.011 | PROPblock_13 | declared | 52 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.06.011 | PROPblock_15 | declared | 260 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.07.005 | PROPblock_9 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.028 | PROPblock_2 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.028 | PROPblock_4 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.028 | PROPblock_6 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2011.11.028 | PROPblock_8 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.04.003 | PROPblock_1 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.05.007 | PROPblock_6 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.05.007 | PROPblock_9 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.06.002 | PROPblock_5 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.06.002 | PROPblock_8 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.06.013 | PROPblock_17 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.08.024 | PROPblock_6 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.08.024 | PROPblock_8 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.004 | PROPblock_25 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.004 | PROPblock_28 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.004 | PROPblock_31 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.004 | PROPblock_34 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.024 | PROPblock_3 | declared | 54 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.024 | PROPblock_4 | declared | 54 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.024 | PROPblock_5 | declared | 114 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2012.10.024 | PROPblock_6 | declared | 126 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.01.004 | PROPblock_10 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.01.004 | PROPblock_13 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.01.022 | PROPblock_15 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.01.025 | PROPblock_2 | declared | 85 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.03.030 | PROPblock_1 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.03.030 | PROPblock_4 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.05.006 | PROPblock_1 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.05.006 | PROPblock_3 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.05.006 | PROPblock_5 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.08.005 | PROPblock_5 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.08.007 | PROPblock_4 | declared | 1,110 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.11.015 | PROPblock_2 | declared | 85 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.11.015 | PROPblock_3 | declared | 85 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.11.028 | PROPblock_10 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.11.028 | PROPblock_13 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.11.028 | PROPblock_16 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2013.11.028 | PROPblock_7 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.01.038 | PROPblock_1 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.01.038 | PROPblock_2 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.01.038 | PROPblock_3 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.01.044 | PROPblock_3 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.03.019 | PROPblock_14 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.03.019 | PROPblock_17 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.05.043 | PROPblock_2 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.05.043 | PROPblock_4 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.08.026 | PROPblock_1 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.08.026 | PROPblock_3 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.08.026 | PROPblock_5 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.08.026 | PROPblock_7 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.09.020 | PROPblock_1 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.09.020 | PROPblock_4 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.09.020 | PROPblock_7 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.09.026 | PROPblock_11 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.09.026 | PROPblock_13 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_10 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_11 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_12 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_13 | declared | 36 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_14 | declared | 36 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_15 | declared | 36 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_16 | declared | 36 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_5 | declared | 60 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_6 | declared | 60 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_7 | declared | 66 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_8 | declared | 66 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.005 | PROPblock_9 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.009 | PROPblock_6 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.11.009 | PROPblock_8 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2014.12.040 | PROPblock_9 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.031 | PROPblock_2 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_34 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_35 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_37 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_38 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_40 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_41 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_43 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_44 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_46 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_47 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_49 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_50 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_52 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_53 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_55 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_56 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_58 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_59 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_61 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.03.040 | PROPblock_62 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.04.021 | PROPblock_5 | declared | 115 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.04.021 | PROPblock_7 | declared | 72 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_1 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_11 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_13 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_15 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_17 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_19 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_21 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_23 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_25 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_27 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_29 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_3 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_5 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_7 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.05.023 | PROPblock_9 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.06.034 | PROPblock_11 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.06.043 | PROPblock_5 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.06.043 | PROPblock_7 | declared | 59 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.004 | PROPblock_1 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.004 | PROPblock_10 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.004 | PROPblock_5 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.004 | PROPblock_7 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.012 | PROPblock_1 | declared | 80 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.012 | PROPblock_3 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.012 | PROPblock_5 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.022 | PROPblock_13 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.07.030 | PROPblock_9 | declared | 125 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.08.005 | PROPblock_2 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.08.005 | PROPblock_3 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.08.005 | PROPblock_4 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.08.005 | PROPblock_5 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.08.005 | PROPblock_6 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.08.005 | PROPblock_7 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.09.036 | PROPblock_7 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.09.036 | PROPblock_9 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2015.12.053 | PROPblock_2 | declared | 77 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.01.023 | PROPblock_1 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.01.023 | PROPblock_2 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.01.023 | PROPblock_3 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.01.036 | PROPblock_11 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.01.036 | PROPblock_12 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.02.035 | PROPblock_5 | declared | 126 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.02.035 | PROPblock_6 | declared | 126 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.03.016 | PROPblock_12 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.03.016 | PROPblock_13 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.03.016 | PROPblock_14 | declared | 28 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.03.016 | PROPblock_2 | declared | 32 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.05.024 | PROPblock_1 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.05.024 | PROPblock_2 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.06.019 | PROPblock_3 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.06.019 | PROPblock_5 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.07.022 | PROPblock_17 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.07.022 | PROPblock_18 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2016.08.036 | PROPblock_3 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.02.002 | PROPblock_3 | declared | 195 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.02.019 | PROPblock_4 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.02.019 | PROPblock_5 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.006 | PROPblock_10 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.006 | PROPblock_13 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.007 | PROPblock_47 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.007 | PROPblock_49 | declared | 31 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.007 | PROPblock_50 | declared | 31 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.010 | PROPblock_1 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.010 | PROPblock_3 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.04.010 | PROPblock_5 | declared | 2 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.09.005 | PROPblock_1 | declared | 72 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.09.005 | PROPblock_3 | declared | 72 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.09.005 | PROPblock_5 | declared | 72 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.09.012 | PROPblock_1 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.09.019 | PROPblock_6 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.09.019 | PROPblock_8 | declared | 120 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.10.034 | PROPblock_3 | declared | 35 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.10.034 | PROPblock_5 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.11.009 | PROPblock_2 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.12.001 | PROPblock_10 | declared | 90 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2017.12.001 | PROPblock_11 | declared | 88 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.01.030 | PROPblock_3 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.02.003 | PROPblock_45 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.02.003 | PROPblock_49 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.02.003 | PROPblock_52 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.02.003 | PROPblock_55 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.02.003 | PROPblock_58 | declared | 3 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_11 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_12 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_2 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_3 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_5 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_6 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_8 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.03.002 | PROPblock_9 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.08.011 | PROPblock_6 | declared | 323 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2018.12.017 | PROPblock_2 | declared | 28 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2019.01.017 | PROPblock_2 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.fluid.2019.01.017 | PROPblock_4 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2004.10.001 | PROPblock_5 | declared | 899 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2004.12.002 | PROPblock_3 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2004.12.010 | PROPblock_10 | declared | 91 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2004.12.010 | PROPblock_8 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.01.009 | PROPblock_1 | declared | 45 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.01.009 | PROPblock_5 | declared | 35 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.01.009 | PROPblock_6 | declared | 35 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.03.016 | PROPblock_3 | declared | 791 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.03.021 | PROPblock_1 | declared | 162 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.04.005 | PROPblock_3 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.04.019 | PROPblock_23 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.04.019 | PROPblock_24 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.05.004 | PROPblock_16 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.05.004 | PROPblock_22 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.05.007 | PROPblock_16 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.06.011 | PROPblock_47 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.06.011 | PROPblock_48 | declared | 33 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.10.013 | PROPblock_2 | declared | 24 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.10.022 | PROPblock_24 | declared | 33 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.12.010 | PROPblock_23 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2005.12.010 | PROPblock_24 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.01.007 | PROPblock_1 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.01.007 | PROPblock_3 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.03.009 | PROPblock_1 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.03.009 | PROPblock_3 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.03.009 | PROPblock_5 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.03.010 | PROPblock_20 | declared | 42 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.03.010 | PROPblock_21 | declared | 42 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.03.018 | PROPblock_29 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.03.018 | PROPblock_32 | declared | 33 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.06.008 | PROPblock_17 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.06.008 | PROPblock_18 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.06.008 | PROPblock_26 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.06.008 | PROPblock_27 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.07.021 | PROPblock_1 | declared | 102 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_2 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_3 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_4 | declared | 278 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.003 | PROPblock_2 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.003 | PROPblock_4 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.003 | PROPblock_6 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.003 | PROPblock_8 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.007 | PROPblock_1 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.007 | PROPblock_3 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.007 | PROPblock_5 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.08.007 | PROPblock_7 | declared | 7 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.006 | PROPblock_5 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.006 | PROPblock_6 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.09.017 | PROPblock_11 | declared | 27 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.016 | PROPblock_14 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_20 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_21 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_23 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_24 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_28 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_29 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_33 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_34 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_36 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2006.10.017 | PROPblock_37 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_26 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_27 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_29 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_30 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.04.006 | PROPblock_15 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.04.006 | PROPblock_16 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.04.009 | PROPblock_1 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_12 | declared | 37 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_14 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_16 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.005 | PROPblock_25 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.005 | PROPblock_26 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.010 | PROPblock_11 | declared | 8 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.010 | PROPblock_13 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.010 | PROPblock_15 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.010 | PROPblock_9 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.011 | PROPblock_11 | declared | 195 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.011 | PROPblock_12 | declared | 195 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.011 | PROPblock_7 | declared | 195 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.015 | PROPblock_13 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.015 | PROPblock_15 | declared | 35 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.015 | PROPblock_17 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.015 | PROPblock_19 | declared | 27 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.015 | PROPblock_21 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.05.015 | PROPblock_23 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.06.007 | PROPblock_2 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.06.007 | PROPblock_5 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.10.007 | PROPblock_1 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.10.007 | PROPblock_3 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.10.007 | PROPblock_5 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2007.11.010 | PROPblock_7 | declared | 100 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.01.003 | PROPblock_1 | declared | 130 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.01.018 | PROPblock_3 | declared | 120 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.01.023 | PROPblock_16 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.01.023 | PROPblock_26 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.02.019 | PROPblock_7 | declared | 28 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.03.007 | PROPblock_7 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.03.007 | PROPblock_8 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.03.013 | PROPblock_15 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.04.006 | PROPblock_15 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.09.005 | PROPblock_10 | declared | 65 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.09.005 | PROPblock_12 | declared | 105 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.09.005 | PROPblock_6 | declared | 85 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.09.005 | PROPblock_8 | declared | 70 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2008.09.008 | PROPblock_2 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.01.010 | PROPblock_17 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.01.010 | PROPblock_20 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.01.010 | PROPblock_23 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.01.010 | PROPblock_26 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.03.004 | PROPblock_1 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.03.004 | PROPblock_3 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.03.004 | PROPblock_5 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.05.004 | PROPblock_1 | declared | 441 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.08.004 | PROPblock_1 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.08.016 | PROPblock_17 | declared | 26 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.10.007 | PROPblock_2 | declared | 75 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2009.11.017 | PROPblock_3 | declared | 57 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.04.018 | PROPblock_1 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.04.018 | PROPblock_3 | declared | 35 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.04.018 | PROPblock_5 | declared | 35 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.05.016 | PROPblock_17 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.07.014 | PROPblock_14 | declared | 33 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.08.021 | PROPblock_3 | declared | 150 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.08.021 | PROPblock_6 | declared | 96 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.08.021 | PROPblock_9 | declared | 102 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.11.003 | PROPblock_2 | declared | 80 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.11.017 | PROPblock_5 | declared | 54 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2010.11.017 | PROPblock_8 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.013 | PROPblock_11 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.013 | PROPblock_14 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.013 | PROPblock_17 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.013 | PROPblock_2 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.013 | PROPblock_5 | declared | 11 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.013 | PROPblock_8 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.014 | PROPblock_11 | declared | 195 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.01.014 | PROPblock_17 | declared | 195 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.06.021 | PROPblock_1 | declared | 72 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.06.021 | PROPblock_3 | declared | 71 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.07.002 | PROPblock_2 | declared | 10 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.08.028 | PROPblock_21 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.09.008 | PROPblock_3 | declared | 145 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.09.016 | PROPblock_1 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.09.016 | PROPblock_3 | declared | 47 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.09.016 | PROPblock_5 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.11.007 | PROPblock_5 | declared | 42 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.11.014 | PROPblock_3 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.11.014 | PROPblock_6 | declared | 54 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2011.11.028 | PROPblock_1 | declared | 91 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.02.023 | PROPblock_15 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.02.023 | PROPblock_19 | declared | 41 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.03.025 | PROPblock_11 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.03.025 | PROPblock_13 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.03.025 | PROPblock_3 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.03.025 | PROPblock_5 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.03.025 | PROPblock_7 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.03.025 | PROPblock_9 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.03.029 | PROPblock_1 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.04.020 | PROPblock_3 | declared | 32 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.04.020 | PROPblock_5 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.05.033 | PROPblock_3 | declared | 22 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.05.033 | PROPblock_5 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.05.033 | PROPblock_7 | declared | 6 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.08.023 | PROPblock_10 | declared | 18 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.08.023 | PROPblock_12 | declared | 24 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.08.023 | PROPblock_14 | declared | 24 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.08.023 | PROPblock_8 | declared | 21 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.10.018 | PROPblock_2 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.10.018 | PROPblock_4 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.10.027 | PROPblock_2 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.10.027 | PROPblock_6 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.001 | PROPblock_5 | declared | 24 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.007 | PROPblock_11 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.007 | PROPblock_13 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.007 | PROPblock_15 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.007 | PROPblock_3 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.007 | PROPblock_5 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.007 | PROPblock_7 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.007 | PROPblock_9 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.032 | PROPblock_4 | declared | 161 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.032 | PROPblock_6 | declared | 133 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.11.032 | PROPblock_8 | declared | 153 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.010 | PROPblock_4 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.010 | PROPblock_6 | declared | 38 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.010 | PROPblock_8 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.022 | PROPblock_10 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.022 | PROPblock_6 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.022 | PROPblock_8 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.028 | PROPblock_1 | declared | 49 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.028 | PROPblock_2 | declared | 56 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2012.12.028 | PROPblock_3 | declared | 63 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_11 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_14 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_17 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_2 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_20 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_23 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_5 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.012 | PROPblock_8 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.023 | PROPblock_11 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.023 | PROPblock_3 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.023 | PROPblock_5 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.023 | PROPblock_7 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.01.023 | PROPblock_9 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.04.017 | PROPblock_2 | declared | 104 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.05.003 | PROPblock_3 | declared | 227 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.05.012 | PROPblock_6 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.05.012 | PROPblock_8 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.05.037 | PROPblock_11 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.05.037 | PROPblock_7 | declared | 4 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_25 | declared | 22 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_28 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_31 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_34 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_37 | declared | 19 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_40 | declared | 21 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_42 | declared | 24 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_44 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_46 | declared | 23 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_48 | declared | 25 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.06.020 | PROPblock_50 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.07.027 | PROPblock_18 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.08.010 | PROPblock_10 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.08.010 | PROPblock_12 | declared | 16 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.08.010 | PROPblock_14 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.08.010 | PROPblock_16 | declared | 36 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.08.016 | PROPblock_10 | declared | 43 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.08.016 | PROPblock_6 | declared | 45 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.08.021 | PROPblock_20 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.09.008 | PROPblock_14 | declared | 42 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.09.008 | PROPblock_17 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.09.008 | PROPblock_20 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.09.008 | PROPblock_23 | declared | 12 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.09.009 | PROPblock_14 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.10.013 | PROPblock_3 | declared | 55 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.10.013 | PROPblock_5 | declared | 45 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.10.013 | PROPblock_7 | declared | 45 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.11.001 | PROPblock_34 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.11.001 | PROPblock_36 | declared | 1 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.11.015 | PROPblock_10 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.11.015 | PROPblock_12 | declared | 15 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.11.015 | PROPblock_14 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.11.015 | PROPblock_16 | declared | 50 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2013.11.021 | PROPblock_10 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2014.01.030 | PROPblock_25 | declared | 39 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2014.06.004 | PROPblock_17 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.09.007 | PROPblock_16 | declared | 105 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.09.024 | PROPblock_10 | declared | 68 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.09.024 | PROPblock_12 | declared | 20 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.09.024 | PROPblock_8 | declared | 80 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.09.037 | PROPblock_14 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2016.09.037 | PROPblock_16 | declared | 30 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2017.01.011 | PROPblock_8 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2017.12.009 | PROPblock_20 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.03.007 | PROPblock_12 | declared | 44 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.06.006 | PROPblock_12 | declared | 119 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.07.013 | PROPblock_17 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.07.013 | PROPblock_29 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.12.019 | PROPblock_17 | declared | 65 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.12.039 | PROPblock_10 | declared | 26 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.12.039 | PROPblock_12 | declared | 26 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.12.039 | PROPblock_14 | declared | 26 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2005.04.030 | PROPblock_17 | declared | 28 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2009.03.014 | PROPblock_12 | declared | 14 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2013.05.015 | PROPblock_8 | declared | 40 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2013.09.017 | PROPblock_28 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2013.09.017 | PROPblock_49 | declared | 5 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2013.12.016 | PROPblock_4 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2013.12.016 | PROPblock_6 | declared | 48 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2014.03.038 | PROPblock_10 | declared | 33 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2014.06.031 | PROPblock_18 | declared | 13 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2014.11.009 | PROPblock_10 | declared | 64 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2015.04.032 | PROPblock_10 | declared | 84 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2016.09.005 | PROPblock_19 | declared | 84 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.5b01000 | PROPblock_18 | declared | 39 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_13 | declared | 3 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b01012 | PROPblock_17 | declared | 44 | binary | 2 | search_system_registry |
| 10.1021/je0342825 | PROPblock_26 | declared | 39 | binary | 2 | search_system_registry |
| 10.1021/je049912x | PROPblock_14 | declared | 20 | binary | 2 | search_system_registry |
| 10.1021/je050006+ | PROPblock_8 | declared | 36 | binary | 2 | search_system_registry |
| 10.1021/je0500330 | PROPblock_19 | declared | 18 | binary | 2 | search_system_registry |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | 2 | search_system_registry |
| 10.1021/je060123k | PROPblock_23 | declared | 33 | binary | 2 | search_system_registry |
| 10.1021/je060126x | PROPblock_11 | declared | 26 | binary | 2 | search_system_registry |
| 10.1021/je060228n | PROPblock_12 | declared | 36 | binary | 2 | search_system_registry |
| 10.1021/je100967k | PROPblock_23 | declared | 44 | binary | 2 | search_system_registry |
| 10.1021/je500594z | PROPblock_14 | declared | 48 | binary | 2 | search_system_registry |
| 10.1021/je500594z | PROPblock_17 | declared | 48 | binary | 2 | search_system_registry |
| 10.1021/je500594z | PROPblock_20 | declared | 48 | binary | 2 | search_system_registry |
| 10.1021/je7001804 | PROPblock_15 | declared | 78 | binary | 2 | search_system_registry |
| 10.1021/je700245a | PROPblock_1 | declared | 90 | binary | 2 | search_system_registry |
| 10.1021/je700245a | PROPblock_3 | declared | 84 | binary | 2 | search_system_registry |
| 10.1021/je800981d | PROPblock_16 | declared | 33 | binary | 2 | search_system_registry |
| 10.1021/je900064e | PROPblock_5 | declared | 8 | binary | 2 | search_system_registry |
| 10.1021/je900888e | PROPblock_1 | declared | 14 | binary | 2 | search_system_registry |
| 10.1021/je9010882 | PROPblock_17 | declared | 10 | binary | 2 | search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `search_system_summary` | compound=GLOBcomp_2, limit=20, property=GLOBprop_8… | 1,038 | KEEP | 1038 | 26.4 |
| 2 | 2 | `search_system_registry` | compound=GLOBcomp_2, limit=100, property=GLOBprop_… | 1,107 | KEEP | 1001 | 16.9 |
| 3 | 1 | `L1_query` | context=Water is GLOBcomp_2 (CAS 7732…, id_catalog… | 1,155 | — | — | 166.7 |
| 4 | 1 | `search_system_registry` | compound=GLOBcomp_2, limit=100, property=GLOBprop_… | 716 | DISCARD | 649 | 19.1 |
| 5 | 2 | `resolve_compound_ids` | purpose=Find the correct global compo…, queries=wa… | 197 | KEEP | 197 | 4.0 |
| 6 | 3 | `search_system_registry` | compound=GLOBcomp_1, limit=100, property=GLOBprop_… | 1,240 | KEEP | 1140 | 16.9 |
| 7 | 4 | `search_system_summary` | compound=GLOBcomp_1, property=GLOBprop_1, purpose=… | 1,187 | KEEP | 1187 | 10.6 |
| 8 | 1 | `L1_query` | context=Water is GLOBcomp_2 (CAS 7732…, id_catalog… | 303 | — | — | 140.2 |
| 9 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve water compo… | 279 | KEEP | 279 | 4.9 |
| 10 | 2 | `L1_query` | instruction=Find the global compound ID f…, purpos… | 758 | — | — | 19.3 |
| 11 | 1 | `search_system_registry` | compound=GLOBcomp_1, limit=100, property=GLOBprop_… | 1,366 | KEEP | 1308 | 18.0 |
| 12 | 3 | `search_system_summary` | compound=GLOBcomp_1, property=GLOBprop_8, purpose=… | 1,233 | KEEP | 1233 | 14.5 |
| 13 | 3 | `search_system_registry` | compound=GLOBcomp_1, limit=200, property=GLOBprop_… | 1,349 | KEEP | 1349 | 25.1 |
| 14 | 3 | `L1_query` | context=We are assessing the breadth …, id_catalog… | 17,669 | — | — | 149.4 |
| 15 | 2 | `search_system_summary` | compound=GLOBcomp_1, limit=20, property=GLOBprop_1… | 1,252 | KEEP | 1252 | 10.5 |
| 16 | 2 | `search_system_registry` | compound=GLOBcomp_1, limit=200, property=GLOBprop_… | 1,447 | KEEP | 1288 | 15.6 |
| 17 | 3 | `L1_query` | context=We are assessing the breadth …, id_catalog… | 303 | — | — | 171.1 |
| 18 | 2 | `search_system_summary` | compound=GLOBcomp_1, limit=20, property=GLOBprop_1… | 1,117 | KEEP | 1117 | 10.3 |
| 19 | 2 | `search_system_registry` | compound=GLOBcomp_1, limit=100, property=GLOBprop_… | 693 | KEEP | 639 | 29.0 |
| 20 | 3 | `search_system_registry` | compound=GLOBcomp_1, limit=200, property=GLOBprop_… | 162 | — | — | 27.6 |
| 21 | 4 | `L1_query` | context=We already have speed-of-soun…, id_catalog… | 4,864 | — | — | 262.6 |
| | | **TOTAL (21 tools)** | | **39,435** | | **13,677** | **1158.7** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,388 | 4,388 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 6,545 | 6,545 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 5,448 | 5,448 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 670 | 10,275 | 2,397 | 12.7 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,127 | 21,770 | 1,700 | 8.4 |
| 3 | L1-worker | claudeopus46 | 20,643 | 3,555 | 24,198 | 12,056 | 51.3 |
| 4 | L1-worker | claudeopus46 | 2,065 | 1,892 | 3,957 | 1,893 | 19.5 |
| 5 | L1-worker | claudeopus46 | 2,065 | 15,965 | 18,030 | 2,090 | 16.2 |
| 6 | L1-worker | claudeopus46 | 20,643 | 5,806 | 26,449 | 4,930 | 26.0 |
| 7 | L1-worker | claudeopus46 | 1,356 | 2,706 | 4,062 | 1,008 | 5.0 |
| 8 | L1-worker | claudeopus46 | 536 | 2,586 | 3,122 | 984 | 5.2 |
| 9 | L1-worker | claudeopus46 | 1,323 | 7,332 | 8,655 | 2,639 | 11.1 |
| 10 | L1-worker | claudeopus46 | 298 | 3,361 | 3,659 | 2,046 | 8.3 |
| 11 | L1-worker | claudeopus46 | 1,160 | 10,579 | 11,739 | 2,086 | 8.9 |
| 12 | L1-worker | claudeopus46 | 747 | 48,649 | 49,396 | 1,056 | 8.7 |
| 13 | L1-worker | claudeopus46 | 20,643 | 1,167 | 21,810 | 2,088 | 11.5 |
| 14 | L1-worker | claudeopus46 | 2,065 | 17,722 | 19,787 | 1,439 | 11.5 |
| 15 | L1-worker | claudeopus46 | 20,643 | 2,505 | 23,148 | 568 | 6.7 |
| 16 | L1-worker | claudeopus46 | 2,065 | 375 | 2,440 | 425 | 3.8 |
| 17 | L1-worker | claudeopus46 | 20,643 | 3,171 | 23,814 | 836 | 5.8 |
| 18 | L1-worker | claudeopus46 | 2,065 | 17,460 | 19,525 | 1,995 | 15.5 |
| 19 | L1-worker | claudeopus46 | 20,610 | 5,683 | 26,293 | 626 | 5.1 |
| 20 | L1-worker | claudeopus46 | 20,643 | 4,930 | 25,573 | 785 | 6.2 |
| 21 | L1-worker | claudeopus46 | 2,065 | 1,765 | 3,830 | 1,628 | 9.5 |
| 22 | L1-worker | claudeopus46 | 20,643 | 6,678 | 27,321 | 2,476 | 14.7 |
| 23 | L1-worker | claudeopus46 | 1,356 | 2,607 | 3,963 | 828 | 4.3 |
| 24 | L1-worker | claudeopus46 | 536 | 2,487 | 3,023 | 919 | 4.6 |
| 25 | L1-worker | claudeopus46 | 1,323 | 8,816 | 10,139 | 4,138 | 15.4 |
| 26 | L1-worker | claudeopus46 | 298 | 4,860 | 5,158 | 3,325 | 11.3 |
| 27 | L1-worker | claudeopus46 | 1,160 | 14,033 | 15,193 | 2,045 | 11.7 |
| 28 | L0-main | claudeopus46 | 9,605 | 2,809 | 12,414 | 11,106 | 58.5 |
| 29 | L1-worker | claudeopus46 | 20,643 | 623 | 21,266 | 428 | 3.9 |
| 30 | L1-worker | claudeopus46 | 2,065 | 359 | 2,424 | 517 | 4.7 |
| 31 | L1-worker | claudeopus46 | 20,643 | 1,317 | 21,960 | 195 | 2.5 |
| 32 | L1-worker | claudeopus46 | 1,323 | 1,513 | 2,836 | 162 | 2.3 |
| 33 | L1-worker | claudeopus46 | 1,356 | 324 | 1,680 | 142 | 2.5 |
| 34 | L1-worker | claudeopus46 | 536 | 204 | 740 | 167 | 2.9 |
| 35 | L1-worker | claudeopus46 | 298 | 884 | 1,182 | 108 | 2.3 |
| 36 | L1-worker | claudeopus46 | 747 | 1,558 | 2,305 | 356 | 3.1 |
| 37 | L0-main | claudeopus46 | 9,605 | 4,915 | 14,520 | 2,241 | 12.0 |
| 38 | L1-worker | claudeopus46 | 20,643 | 2,119 | 22,762 | 1,603 | 10.4 |
| 39 | L1-worker | claudeopus46 | 2,065 | 17,275 | 19,340 | 2,032 | 16.7 |
| 40 | L1-worker | claudeopus46 | 20,643 | 4,059 | 24,702 | 1,217 | 8.7 |
| 41 | L1-worker | claudeopus46 | 20,643 | 5,032 | 25,675 | 1,115 | 9.0 |
| 42 | L1-worker | claudeopus46 | 2,065 | 1,693 | 3,758 | 1,635 | 13.6 |
| 43 | L1-worker | claudeopus46 | 2,065 | 33,491 | 35,556 | 1,769 | 14.9 |
| 44 | L1-worker | claudeopus46 | 20,610 | 8,672 | 29,282 | 566 | 6.9 |
| 45 | L1-worker | claudeopus46 | 20,643 | 7,919 | 28,562 | 3,251 | 21.0 |
| 46 | L1-worker | claudeopus46 | 1,356 | 2,629 | 3,985 | 1,089 | 5.6 |
| 47 | L1-worker | claudeopus46 | 536 | 2,509 | 3,045 | 1,346 | 6.2 |
| 48 | L1-worker | claudeopus46 | 1,323 | 10,738 | 12,061 | 2,178 | 9.7 |
| 49 | L1-worker | claudeopus46 | 298 | 1,471 | 1,769 | 1,077 | 5.5 |
| 50 | L1-worker | claudeopus46 | 298 | 2,900 | 3,198 | 1,743 | 11.5 |
| 51 | L1-worker | claudeopus46 | 1,160 | 13,630 | 14,790 | 582 | 3.6 |
| 52 | L1-worker | claudeopus46 | 747 | 27,030 | 27,777 | 865 | 9.0 |
| 53 | L1-worker | claudeopus46 | 20,643 | 19,850 | 40,493 | 1,781 | 10.4 |
| 54 | L1-worker | claudeopus46 | 20,643 | 22,359 | 43,002 | 11,906 | 54.9 |
| 55 | L1-worker | claudeopus46 | 2,065 | 1,797 | 3,862 | 1,673 | 9.5 |
| 56 | L1-worker | claudeopus46 | 2,065 | 34,791 | 36,856 | 1,584 | 13.2 |
| 57 | L1-worker | claudeopus46 | 20,643 | 25,069 | 45,712 | 5,356 | 34.5 |
| 58 | L1-worker | claudeopus46 | 1,356 | 2,857 | 4,213 | 1,173 | 5.8 |
| 59 | L1-worker | claudeopus46 | 536 | 2,737 | 3,273 | 1,586 | 7.9 |
| 60 | L1-worker | claudeopus46 | 298 | 1,555 | 1,853 | 1,161 | 4.0 |
| 61 | L1-worker | claudeopus46 | 1,323 | 8,252 | 9,575 | 4,909 | 18.0 |
| 62 | L1-worker | claudeopus46 | 298 | 5,631 | 5,929 | 3,894 | 14.4 |
| 63 | L1-worker | claudeopus46 | 1,160 | 14,472 | 15,632 | 2,729 | 11.9 |
| 64 | L0-main | claudeopus46 | 9,605 | 24,242 | 33,847 | 8,076 | 47.0 |
| 65 | L1-worker | claudeopus46 | 20,643 | 19,891 | 40,534 | 1,296 | 7.6 |
| 66 | L1-worker | claudeopus46 | 20,643 | 21,915 | 42,558 | 13,088 | 51.9 |
| 67 | L1-worker | claudeopus46 | 2,065 | 1,745 | 3,810 | 1,536 | 9.3 |
| 68 | L1-worker | claudeopus46 | 2,065 | 17,393 | 19,458 | 1,497 | 12.8 |
| 69 | L1-worker | claudeopus46 | 2,065 | 17,603 | 19,668 | 1,752 | 15.0 |
| 70 | L1-worker | claudeopus46 | 20,643 | 23,736 | 44,379 | 8,563 | 49.2 |
| 71 | L1-worker | claudeopus46 | 2,065 | 34,768 | 36,833 | 1,521 | 12.1 |
| 72 | L1-worker | claudeopus46 | 2,065 | 34,978 | 37,043 | 1,648 | 13.4 |
| 73 | L1-worker | claudeopus46 | 20,610 | 25,324 | 45,934 | 581 | 4.1 |
| 74 | L1-worker | claudeopus46 | 20,643 | 24,571 | 45,214 | 11,190 | 61.0 |
| 75 | L1-worker | claudeopus46 | 20,643 | 36,510 | 57,153 | 2,296 | 8.4 |
| 76 | L1-worker | claudeopus46 | 1,323 | 7,700 | 9,023 | 89 | 1.9 |
| 77 | L1-worker | claudeopus46 | 298 | 811 | 1,109 | 64 | 1.9 |
| 78 | L1-worker | claudeopus46 | 536 | 2,307 | 2,843 | 1,116 | 4.9 |
| 79 | L1-worker | claudeopus46 | 1,356 | 2,427 | 3,783 | 1,274 | 5.9 |
| 80 | L1-worker | claudeopus46 | 747 | 11,164 | 11,911 | 673 | 6.0 |
| 81 | L0-main | claudeopus46 | 9,605 | 34,807 | 44,412 | 3,696 | 25.5 |
| 82 | L0-main | claudeopus46 | 1,356 | 3,827 | 5,183 | 1,338 | 6.6 |
| 83 | L0-main | claudeopus46 | 1,323 | 35,901 | 37,224 | 4,307 | 20.5 |
| 84 | L0-main | claudeopus46 | 298 | 4,975 | 5,273 | 3,351 | 12.3 |


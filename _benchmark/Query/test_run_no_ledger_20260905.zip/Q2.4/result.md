# Q2.4 — Result

**Prompt:** I want to validate an acoustic model for aqueous mixtures. Is the available speed-of-sound evidence broad enough for this purpose, or is it substantially more limited than the corresponding density evidence?

**Tool calls:** 6  |  **Time:** 1099.6s  |  **Iterations:** 5  |  **Timed out:** False

---

## Answer

## Speed-of-Sound vs. Density Evidence for Aqueous Mixtures in ThermoML

The ThermoML archive holds a substantial body of speed-of-sound data for binary aqueous mixtures, but it is **considerably smaller** than the corresponding density evidence. Here is a side-by-side comparison:

| Metric | Speed of Sound (GLOBprop_8) | Mass Density (GLOBprop_1) | Ratio (ρ / u) |
|--------|----------------------------|---------------------------|---------------|
| Property blocks | 753 | 2,558 | 3.4× |
| Papers | 295 | 1,104 | 3.7× |
| Data points | 30,819 | 132,045 | 4.3× |
| Temperature range | 273.15–596.3 K | 253.15–673.15 K | Density extends ~77 K further |
| Pressure range | 100–120,000 kPa | 6.3–387,800 kPa | Density extends ~3.2× higher |
| Distinct co-solutes | >100 | Several hundred (≥78 in a 200-block sample) | Density covers more systems |

### What the speed-of-sound dataset covers well

Despite being smaller, the speed-of-sound collection is **broad enough to support meaningful acoustic model validation** across diverse chemical families:

- **Inorganic salts:** NaCl (15 blocks), KCl (10), KNO₃ (8), K₂SO₄, MgCl₂, phosphates
- **Amino acids:** glycine (20 blocks — the most-studied co-solute), L-alanine (10), L-valine (10), L-serine, L-threonine, L-histidine, L-phenylalanine, L-arginine, hydroxyproline
- **Sugars:** D-glucose (14), D-sucrose (15), L-arabinose
- **Organic solvents:** DMSO, DMF, THF, 1,4-dioxane, acetonitrile
- **Glycols:** ethylene glycol (8 blocks)
- **Ionic liquids:** imidazolium-based ([C₁C₄im]Br, [C₁C₄im]Cl, [C₁C₄im][BF₄], etc.) and protic ILs (2-hydroxyethylammonium formate/acetate)
- **Quaternary ammonium salts:** TMABr, TEABr, TPABr, TBABr (7 blocks)
- **Ureas:** urea, methylurea, ethylurea, dimethylurea, tetramethylurea
- **Surfactants:** decyl β-D-glucopyranoside (323 data points in one block), sodium perfluorobutanoate

The temperature coverage up to ~596 K and pressures to ~1,200 bar also capture near-critical and high-pressure conditions relevant to geochemistry and process engineering.

### Where the speed-of-sound data is more limited

1. **Volume of evidence:** The density dataset is 3–4× larger by every metric (blocks, papers, data points), so for any given co-solute you will typically find more density data than speed-of-sound data.
2. **Thermodynamic extremes:** Density data extends to ~673 K and ~3,878 bar, whereas speed-of-sound data tops out at ~596 K and ~1,200 bar. Validation of your acoustic model under supercritical or ultra-high-pressure conditions will be constrained.
3. **Chemical diversity:** The density dataset covers several hundred distinct co-solutes vs. >100 for speed of sound. Some systems measured for density may lack corresponding speed-of-sound data entirely.

### Practical recommendation

The speed-of-sound evidence is **broad enough for a credible validation** of an acoustic model across electrolytes, biomolecules, organic co-solvents, and ionic liquids at moderate-to-elevated conditions. However, it is **substantially more limited** than the density evidence — roughly one-third the size — so you should expect:

- Gaps at the highest temperatures (>596 K) and pressures (>1,200 bar).
- Fewer independent data sources per co-solute (useful for cross-validation).
- Some co-solute systems present in the density corpus but absent from the speed-of-sound corpus.

A practical strategy is to use the density data for primary parameterization and the speed-of-sound data for independent validation, leveraging the substantial overlap in top co-solutes (NaCl, glycine, D-glucose, KCl, ethanol, D-sucrose, ethylene glycol, L-alanine) that appear prominently in both datasets.

### Core claims

- The ThermoML speed-of-sound dataset for binary aqueous mixtures is roughly 3–4× smaller than the corresponding density dataset by every metric (753 vs. 2,558 property blocks; 30,819 vs. 132,045 data points; 295 vs. 1,104 papers).
- Speed-of-sound data covers >100 distinct co-solutes spanning inorganic salts, amino acids, sugars, organic solvents, glycols, ionic liquids, quaternary ammonium salts, ureas, and surfactants, making it broad enough for meaningful acoustic model validation across diverse chemical families.
- Density data extends to higher thermodynamic extremes (~673 K and ~3,878 bar) than speed-of-sound data (~596 K and ~1,200 bar), so validation of acoustic models under supercritical or ultra-high-pressure conditions will be constrained by the speed-of-sound corpus.
- Some co-solute systems present in the density corpus are absent from the speed-of-sound corpus, and fewer independent data sources per co-solute are available for speed of sound, limiting cross-validation opportunities.
- A practical strategy is to use density data for primary parameterization and speed-of-sound data for independent validation, leveraging the substantial overlap in top co-solutes (e.g., NaCl, glycine, D-glucose, KCl, ethanol, D-sucrose, ethylene glycol, L-alanine) that appear prominently in both datasets.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_67 | 10.1007/s10765-008-0514-x | PROPblock_1 |  | Speed-of-sound data for water + potassium chloride binary mixture (6 data points, 298.15–323.15 K, 101 kPa). Representative block from the aqueous speed-of-sound screening. |
| GLOBlit_2239 | 10.1016/j.fluid.2018.08.011 | PROPblock_6 |  | Speed-of-sound data for water + decyl β-D-glucopyranoside binary mixture (323 data points, 283.15–323.15 K, 101.3 kPa). Representative block from the aqueous speed-of-sound screening. |

### Suggested follow-ups

- Identify specific co-solute systems that have both speed-of-sound and density data to enable paired validation (e.g., query for blocks containing both GLOBprop_1 and GLOBprop_8 within the same literature source).
- Examine the high-temperature/high-pressure subset of speed-of-sound data (T > 400 K or P > 50,000 kPa) to assess whether those extreme-condition blocks are concentrated in a few papers or spread across independent sources.
- Screen for isentropic compressibility (derived property) data in ThermoML to supplement the speed-of-sound evidence for acoustic model validation.
- Compare the co-solute overlap between the speed-of-sound and density datasets quantitatively — list systems present in the density corpus but absent from the speed-of-sound corpus to identify validation gaps.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_26",
    "registry_id": "sodium chloride",
    "name": "sodium chloride"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_41",
    "registry_id": "potassium chloride",
    "name": "potassium chloride"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_53",
    "registry_id": "glycine",
    "name": "glycine (2-aminoacetic acid)"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_90",
    "registry_id": "D-glucose",
    "name": "D-glucose"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_120",
    "registry_id": "D-sucrose",
    "name": "D-sucrose"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_74",
    "registry_id": "L-alanine",
    "name": "L-alanine"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_116",
    "registry_id": "L-valine",
    "name": "L-valine"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_233",
    "registry_id": "potassium nitrate",
    "name": "potassium nitrate"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_24",
    "registry_id": "1,2-ethanediol",
    "name": "1,2-ethanediol (ethylene glycol)"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_160",
    "registry_id": "tetrabutylammonium bromide",
    "name": "tetrabutylammonium bromide"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_3",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_5019",
    "registry_id": "decyl beta.-D-glucopyranoside",
    "name": "decyl β-D-glucopyranoside"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1247",
    "registry_id": "(+)-galactose",
    "name": "(+)-galactose"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_8",
    "registry_id": "speed_of_sound_m_s",
    "name": "Speed of sound, m/s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density_kg_m3",
    "name": "Mass density, kg/m³"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```

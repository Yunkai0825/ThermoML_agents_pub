# Reference Stats — query-agent

**Run started:** 2026-08-02 18:54:03
**Wall time (at last flush):** 637.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 31,792 | 118,170 | 31,295 | 149,962 | 24,993 | 165.0 | claudeopus46 |
| L1-worker | 30 | 252,791 | 303,903 | 88,769 | 556,694 | 18,556 | 471.7 | claudeopus46 |
| **TOTAL** | **36** | **284,583** | **422,073** | **120,064** | **706,656** | **19,629** | **636.7** | |

**Estimated tokens:** ~176,664 input + ~30,016 output = ~206,680 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 11 | 4 | 4 | 29 | 50 | 3,112 |
| `search_system_summary` | 2 | 0 | 0 | 0 | 73 | 126 | 5,163 |
| `search_system_registry` | 2 | 18 | 7 | 6 | 58 | 100 | 4,354 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 7 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 1 | 18 | 20 | 317 |
| `search_blocks` | 2 | 1 | 3 | 2 | 5 | 6 | 144 |
| `search_blocks` | 2 | 1 | 2 | 2 | 6 | 6 | 163 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **22** | **32** | **18** | **15** | **189** | **308** | **13,253** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks, search_system_registry, search_system_summary |
| GLOBcomp_5494 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry, search_system_summary |
| GLOBcomp_6173 |  | resolve_compound_ids |
| GLOBcomp_6171 |  | resolve_compound_ids |
| GLOBcomp_6172 |  | resolve_compound_ids |
| GLOBcomp_4 |  | resolve_compound_ids |

#### References (65 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_220 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_299 |  | search_blocks, search_system_registry |
| GLOBlit_384 |  | search_blocks, search_system_registry |
| GLOBlit_528 |  | search_blocks, search_system_registry |
| GLOBlit_742 |  | search_blocks, search_system_registry |
| GLOBlit_757 |  | search_blocks, search_system_registry |
| GLOBlit_977 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1184 |  | search_blocks, search_system_registry |
| GLOBlit_1197 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1289 |  | search_blocks, search_system_registry |
| GLOBlit_1482 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1483 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1518 |  | search_blocks, search_system_registry |
| GLOBlit_1742 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1971 |  | search_blocks, search_system_registry |
| GLOBlit_2035 |  | search_blocks, search_system_registry |
| GLOBlit_2092 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_2220 |  | search_blocks, search_system_registry |
| GLOBlit_2300 |  | search_blocks, search_system_registry |
| GLOBlit_2432 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_2574 |  | search_blocks, search_system_registry |
| GLOBlit_2732 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_2825 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_3475 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_3697 |  | search_blocks, search_system_registry |
| GLOBlit_3971 |  | search_blocks, search_system_registry |
| GLOBlit_4181 |  | search_blocks, search_system_registry |
| GLOBlit_4415 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_5073 |  | search_blocks, search_system_registry |
| GLOBlit_5201 |  | search_system_registry, search_system_summary |
| GLOBlit_11136 |  | search_system_summary |
| GLOBlit_9006 |  | search_system_registry, search_system_summary |
| GLOBlit_11574 |  | search_system_summary |
| GLOBlit_10866 |  | search_system_summary |
| GLOBlit_7748 |  | search_system_registry, search_system_summary |
| GLOBlit_10024 |  | search_system_summary |
| GLOBlit_8830 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_5473 |  | search_system_registry |
| GLOBlit_6377 |  | search_blocks, search_system_registry |
| GLOBlit_6628 |  | search_system_registry |
| GLOBlit_6866 |  | search_blocks, search_system_registry |
| GLOBlit_6996 |  | search_system_registry |
| GLOBlit_7085 |  | search_system_registry |
| GLOBlit_7178 |  | search_system_registry |
| GLOBlit_7337 |  | search_blocks, search_system_registry |
| GLOBlit_7425 |  | search_blocks, search_system_registry |
| GLOBlit_7448 |  | search_system_registry |
| GLOBlit_7483 |  | search_system_registry |
| GLOBlit_7629 |  | search_system_registry |
| GLOBlit_7676 |  | search_system_registry |
| GLOBlit_7794 |  | search_system_registry |
| GLOBlit_8050 |  | search_system_registry |
| GLOBlit_8151 |  | search_system_registry |
| GLOBlit_8381 |  | search_system_registry |
| GLOBlit_8445 |  | search_system_registry |
| GLOBlit_8511 |  | search_system_registry |
| GLOBlit_8888 |  | search_system_registry |
| GLOBlit_8949 |  | search_system_registry |
| GLOBlit_9599 |  | search_blocks, search_system_registry |
| GLOBlit_9630 |  | search_blocks, search_system_registry |
| GLOBlit_9693 |  | search_blocks, search_system_registry |
| GLOBlit_9930 |  | search_blocks, search_system_registry |
| GLOBlit_10130 |  | search_blocks |
| GLOBlit_11485 |  | search_blocks |
| GLOBlit_11778 |  | search_blocks |

#### Properties (18 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_3 | Activity coefficient | search_blocks, search_system_registry |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBprop_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBprop_44 | Relative permittivity at zero frequency | search_blocks, search_system_registry |
| GLOBprop_58 | Azeotropic temperature, K | search_blocks, search_system_registry |
| GLOBprop_45 | Azeotropic composition: mole fraction | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_system_registry |
| GLOBprop_62 | Azeotropic pressure, kPa | search_system_registry |
| GLOBprop_7 | Refractive index (Na D-line) | search_system_registry |
| GLOBprop_18 | Electrical conductivity, S/m | search_system_registry |
| GLOBprop_34 | Thermal conductivity, W/m/K | search_system_registry |
| GLOBprop_27 | Henry's Law constant (mole fraction scale), kPa | search_system_registry |
| GLOBprop_29 | Binary diffusion coefficient, m2/s | search_system_registry |

#### Measurements (46 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_543 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_1045 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_1042 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_5 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_1362 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_2137 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_131 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_1 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_10 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_664 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_66 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_1153 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_1355 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_161 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_1497 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_53 | Relative permittivity at zero frequency | search_blocks, search_system_registry |
| GLOBmeas_39 | Azeotropic temperature, K | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_24 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_18 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_11 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_system_registry |
| GLOBmeas_3 | Refractive index (Na D-line) | search_system_registry |
| GLOBmeas_8 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_system_registry |
| GLOBmeas_14 | Electrical conductivity, S/m | search_system_registry |
| GLOBmeas_193 | Thermal conductivity, W/m/K | search_system_registry |
| GLOBmeas_163 | Refractive index (Na D-line) | search_system_registry |
| GLOBmeas_236 | Mass density, kg/m3 | search_system_registry |
| GLOBmeas_145 | Mole fraction | search_system_registry |
| GLOBmeas_38 | Binary diffusion coefficient, m2/s | search_system_registry |
| GLOBmeas_276 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_150 | Mole fraction | search_system_registry |
| GLOBmeas_15 | Speed of sound, m/s | search_system_registry |
| GLOBmeas_205 | Viscosity, Pa*s | search_system_registry |
| GLOBmeas_155 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_2090 | Boiling temperature at pressure P, K | search_blocks |

#### Phases (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |
| GLOBphase_3 |  | search_blocks, search_system_registry |
| GLOBphase_10 |  | search_blocks, search_system_registry |

#### Variables (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_system_registry |
| GLOBvar_15 | Mass ratio of solute to solvent | search_system_registry |
| GLOBvar_18 | Volume fraction | search_system_registry |

#### Constraints (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_3 | Mole fraction | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_4 | Frequency, MHz | search_blocks, search_system_registry |
| GLOBconstr_5 | Mass fraction | search_system_registry |
| GLOBconstr_8 | Molality, mol/kg | search_system_registry |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_2 |  | search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 7 |
| Unique References | 65 |
| Unique Properties | 18 |
| Unique Measurements | 46 |
| Unique Phases | 3 |
| Unique Variables | 7 |
| Unique Constraints | 6 |
| Unique Solvents | 2 |
| Unique Block_Types | 1 |
| Total DOIs | 61 |
| Unique parent blocks | 103 |
| Explicit block/subsystem targets | 103 |
| Subsystem targets | 0 |
| Target-matched data points | 8,090 |

---

## 3. DOI & Block References

**Unique DOIs:** 61  |  **Parent blocks:** 103  |  **Explicit targets:** 103  |  **Subsystems:** 0  |  **Target-matched datapoints:** 4,386

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | 3 | 13 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2006.04.017 | 1 | 28 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2007.06.007 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.10.002 | 2 | 10 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.11.014 | 2 | 36 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2011.06.009 | 2 | 90 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.11.026 | 2 | 48 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.12.014 | 2 | 152 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.07.001 | 1 | 42 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.031 | 1 | 56 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.032 | 1 | 140 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.07.022 | 2 | 14 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.07.012 | 2 | 168 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.08.030 | 1 | 4 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.03.010 | 2 | 34 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.005 | 2 | 144 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2018.07.014 | 1 | 17 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2019.03.019 | 2 | 32 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2004.07.019 | 1 | 565 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2005.06.018 | 1 | 27 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | 4 | 326 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | 2 | 74 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2011.10.009 | 1 | 70 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.08.009 | 1 | 14 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | 4 | 34 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2014.05.020 | 1 | 30 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2015.06.024 | 2 | 80 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.07.021 | 2 | 48 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | 3 | 496 | binary | search_system_registry |
| 10.1016/j.jct.2019.02.027 | 1 | 9 | binary | search_system_registry |
| 10.1016/j.tca.2017.05.023 | 1 | 1 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00485 | 1 | 2 | binary | search_system_registry |
| 10.1021/acs.jced.6b00197 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00725 | 2 | 2 | binary | search_system_registry |
| 10.1021/acs.jced.6b01058 | 1 | 12 | binary | search_system_registry |
| 10.1021/acs.jced.7b00299 | 3 | 5 | binary | search_system_registry |
| 10.1021/acs.jced.7b00827 | 2 | 42 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00005 | 1 | 10 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00086 | 3 | 18 | binary | search_system_registry |
| 10.1021/acs.jced.8b00181 | 2 | 12 | binary | search_system_registry |
| 10.1021/acs.jced.8b00723 | 2 | 6 | binary | search_system_registry |
| 10.1021/acs.jced.8b00939 | 2 | 18 | binary | search_system_registry |
| 10.1021/acs.jced.8b01147 | 1 | 68 | binary | search_system_registry |
| 10.1021/acs.jced.9b00026 | 1 | 10 | binary | search_system_registry |
| 10.1021/je020173z | 2 | 48 | binary | search_system_registry |
| 10.1021/je030146o | 1 | 12 | binary | search_system_registry |
| 10.1021/je0495942 | 2 | 2 | binary | search_system_registry |
| 10.1021/je0497303 | 1 | 6 | binary | search_system_registry |
| 10.1021/je049875+ | 1 | 5 | binary | search_system_registry |
| 10.1021/je050537y | 2 | 56 | binary | search_blocks, search_system_registry |
| 10.1021/je0601098 | 2 | 24 | binary | search_system_registry |
| 10.1021/je060219e | 1 | 26 | binary | search_system_registry |
| 10.1021/je060335h | 1 | 164 | binary | search_system_registry |
| 10.1021/je2005209 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1021/je200655s | 2 | 32 | binary | search_blocks, search_system_registry |
| 10.1021/je2008704 | 2 | 42 | binary | search_blocks, search_system_registry |
| 10.1021/je3007138 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1021/je400238j | 1 | 8 | binary | search_blocks |
| 10.1021/je900002p | 1 | 9 | binary | search_blocks |
| 10.1021/je900719z | 1 | 15 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_4 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_5 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_6 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2006.04.017 | PROPblock_3 | declared | 28 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2007.06.007 | PROPblock_1 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2007.06.007 | PROPblock_2 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.10.002 | PROPblock_17 | declared | 5 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.10.002 | PROPblock_18 | declared | 5 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.11.014 | PROPblock_2 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.11.014 | PROPblock_3 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2011.06.009 | PROPblock_1 | declared | 45 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2011.06.009 | PROPblock_2 | declared | 45 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.11.026 | PROPblock_4 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.11.026 | PROPblock_5 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.12.014 | PROPblock_2 | declared | 76 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.12.014 | PROPblock_3 | declared | 76 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.07.001 | PROPblock_6 | declared | 42 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.031 | PROPblock_4 | declared | 56 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.07.022 | PROPblock_1 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.07.022 | PROPblock_2 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.07.012 | PROPblock_3 | declared | 84 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.07.012 | PROPblock_4 | declared | 84 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.08.030 | PROPblock_1 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.03.010 | PROPblock_7 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.03.010 | PROPblock_8 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.005 | PROPblock_3 | declared | 72 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.005 | PROPblock_4 | declared | 72 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2018.07.014 | PROPblock_4 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2019.03.019 | PROPblock_8 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2019.03.019 | PROPblock_9 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2005.06.018 | PROPblock_4 | declared | 27 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_1 | declared | 25 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_2 | declared | 19 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_3 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_4 | declared | 278 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_11 | declared | 37 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_12 | declared | 37 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2011.10.009 | PROPblock_3 | declared | 70 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.08.009 | PROPblock_18 | declared | 14 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_10 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_11 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_12 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_9 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2014.05.020 | PROPblock_1 | declared | 30 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2015.06.024 | PROPblock_7 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.07.021 | PROPblock_3 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.07.021 | PROPblock_4 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_21 | declared | 100 | binary | 2 | search_system_registry |
| 10.1016/j.jct.2019.02.027 | PROPblock_21 | declared | 9 | binary | 2 | search_system_registry |
| 10.1016/j.tca.2017.05.023 | PROPblock_1 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00485 | PROPblock_8 | declared | 2 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.6b00197 | PROPblock_11 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00197 | PROPblock_12 | declared | 15 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.6b00725 | PROPblock_15 | declared | 1 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.6b00725 | PROPblock_16 | declared | 1 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.6b01058 | PROPblock_7 | declared | 12 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.7b00299 | PROPblock_10 | declared | 2 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.7b00299 | PROPblock_11 | declared | 2 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.7b00299 | PROPblock_12 | declared | 1 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.7b00827 | PROPblock_12 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00827 | PROPblock_13 | declared | 21 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00005 | PROPblock_5 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00086 | PROPblock_46 | declared | 6 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00086 | PROPblock_47 | declared | 6 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00086 | PROPblock_48 | declared | 6 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00181 | PROPblock_10 | declared | 6 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00181 | PROPblock_11 | declared | 6 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_12 | declared | 3 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_13 | declared | 3 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00939 | PROPblock_17 | declared | 9 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b00939 | PROPblock_18 | declared | 9 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.8b01147 | PROPblock_6 | declared | 68 | binary | 2 | search_system_registry |
| 10.1021/acs.jced.9b00026 | PROPblock_16 | declared | 10 | binary | 2 | search_system_registry |
| 10.1021/je020173z | PROPblock_4 | declared | 24 | binary | 2 | search_system_registry |
| 10.1021/je020173z | PROPblock_5 | declared | 24 | binary | 2 | search_system_registry |
| 10.1021/je030146o | PROPblock_1 | declared | 12 | binary | 2 | search_system_registry |
| 10.1021/je0495942 | PROPblock_1 | declared | 1 | binary | 2 | search_system_registry |
| 10.1021/je0495942 | PROPblock_2 | declared | 1 | binary | 2 | search_system_registry |
| 10.1021/je0497303 | PROPblock_2 | declared | 6 | binary | 2 | search_system_registry |
| 10.1021/je049875+ | PROPblock_1 | declared | 5 | binary | 2 | search_system_registry |
| 10.1021/je050537y | PROPblock_1 | declared | 28 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je050537y | PROPblock_2 | declared | 28 | binary | 2 | search_system_registry |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | 2 | search_system_registry |
| 10.1021/je0601098 | PROPblock_20 | declared | 12 | binary | 2 | search_system_registry |
| 10.1021/je060219e | PROPblock_1 | declared | 26 | binary | 2 | search_system_registry |
| 10.1021/je060335h | PROPblock_1 | declared | 164 | binary | 2 | search_system_registry |
| 10.1021/je2005209 | PROPblock_2 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je2005209 | PROPblock_3 | declared | 15 | binary | 2 | search_system_registry |
| 10.1021/je200655s | PROPblock_5 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je200655s | PROPblock_6 | declared | 16 | binary | 2 | search_system_registry |
| 10.1021/je2008704 | PROPblock_4 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je2008704 | PROPblock_5 | declared | 21 | binary | 2 | search_system_registry |
| 10.1021/je3007138 | PROPblock_2 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je3007138 | PROPblock_3 | declared | 15 | binary | 2 | search_system_registry |
| 10.1021/je400238j | PROPblock_5 | declared | 8 | binary | — | search_blocks |
| 10.1021/je900002p | PROPblock_2 | declared | 9 | binary | — | search_blocks |
| 10.1021/je900719z | PROPblock_3 | declared | 15 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 274 | KEEP | 274 | 5.4 |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 897 | KEEP | 883 | 17.0 |
| 3 | 4 | `search_system_summary` | compound=['GLOBcomp_2', 'GLOBcomp_1'], purpose=Get… | 1,120 | KEEP | 1120 | 9.3 |
| 4 | 4 | `search_system_registry` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=100, … | 1,373 | KEEP | 1179 | 15.6 |
| 5 | 1 | `L1_query` | instruction=Search for the binary system …, purpos… | 278 | — | — | 315.1 |
| 6 | 1 | `resolve_compound_ids` | purpose=Resolve ethanol and water to …, queries=['… | 368 | KEEP | 368 | 7.4 |
| 7 | 2 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 1,186 | KEEP | 1186 | 20.1 |
| 8 | 2 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 731 | KEEP | 716 | 21.3 |
| 9 | 2 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, p… | 1,359 | KEEP | 1359 | 22.7 |
| 10 | 2 | `L1_query` | instruction=Search for ethanol (CAS 64-17…, purpos… | 270 | — | — | 165.4 |
| | | **TOTAL (10 tools)** | | **7,856** | | **7,085** | **599.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,725 | 3,725 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 692 | 10,297 | 1,937 | 11.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,431 | 22,074 | 577 | 6.9 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,629 | 23,272 | 906 | 5.7 |
| 4 | L1-worker | claudeopus46 | 2,065 | 550 | 2,615 | 615 | 4.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,814 | 23,457 | 13,932 | 65.6 |
| 6 | L1-worker | claudeopus46 | 2,065 | 31,277 | 33,342 | 1,703 | 15.8 |
| 7 | L1-worker | claudeopus46 | 20,610 | 5,020 | 25,630 | 643 | 5.0 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,267 | 24,910 | 1,519 | 9.7 |
| 9 | L1-worker | claudeopus46 | 2,065 | 1,610 | 3,675 | 1,505 | 8.5 |
| 10 | L1-worker | claudeopus46 | 2,065 | 15,150 | 17,215 | 1,709 | 13.9 |
| 11 | L1-worker | claudeopus46 | 20,643 | 7,558 | 28,201 | 2,984 | 17.2 |
| 12 | L1-worker | claudeopus46 | 20,643 | 8,504 | 29,147 | 17,497 | 78.4 |
| 13 | L1-worker | claudeopus46 | 20,643 | 9,469 | 30,112 | 4,855 | 30.7 |
| 14 | L1-worker | claudeopus46 | 1,356 | 3,901 | 5,257 | 1,195 | 6.3 |
| 15 | L1-worker | claudeopus46 | 536 | 3,781 | 4,317 | 1,246 | 6.8 |
| 16 | L1-worker | claudeopus46 | 298 | 1,577 | 1,875 | 1,183 | 4.8 |
| 17 | L1-worker | claudeopus46 | 1,323 | 14,726 | 16,049 | 4,456 | 18.2 |
| 18 | L1-worker | claudeopus46 | 298 | 5,178 | 5,476 | 3,547 | 14.1 |
| 19 | L1-worker | claudeopus46 | 1,160 | 20,232 | 21,392 | 3,572 | 14.6 |
| 20 | L0-main | claudeopus46 | 9,605 | 1,496 | 11,101 | 15,910 | 75.2 |
| 21 | L1-worker | claudeopus46 | 20,643 | 1,135 | 21,778 | 821 | 5.2 |
| 22 | L1-worker | claudeopus46 | 2,065 | 811 | 2,876 | 687 | 6.4 |
| 23 | L1-worker | claudeopus46 | 20,643 | 2,003 | 22,646 | 1,589 | 8.3 |
| 24 | L1-worker | claudeopus46 | 2,065 | 12,360 | 14,425 | 1,551 | 12.4 |
| 25 | L1-worker | claudeopus46 | 2,065 | 8,724 | 10,789 | 1,501 | 12.1 |
| 26 | L1-worker | claudeopus46 | 2,065 | 8,362 | 10,427 | 1,661 | 13.5 |
| 27 | L1-worker | claudeopus46 | 20,643 | 6,145 | 26,788 | 3,740 | 24.1 |
| 28 | L1-worker | claudeopus46 | 536 | 2,201 | 2,737 | 738 | 4.6 |
| 29 | L1-worker | claudeopus46 | 1,356 | 2,321 | 3,677 | 998 | 5.4 |
| 30 | L1-worker | claudeopus46 | 1,323 | 8,654 | 9,977 | 6,057 | 24.1 |
| 31 | L1-worker | claudeopus46 | 298 | 6,779 | 7,077 | 4,912 | 19.5 |
| 32 | L1-worker | claudeopus46 | 747 | 104,734 | 105,481 | 870 | 9.2 |
| 33 | L0-main | claudeopus46 | 9,605 | 99,786 | 109,391 | 5,392 | 35.5 |
| 34 | L0-main | claudeopus46 | 1,356 | 4,456 | 5,812 | 1,324 | 9.2 |
| 35 | L0-main | claudeopus46 | 1,323 | 7,504 | 8,827 | 3,568 | 19.9 |
| 36 | L0-main | claudeopus46 | 298 | 4,236 | 4,534 | 3,164 | 13.9 |


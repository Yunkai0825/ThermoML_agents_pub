# Q3.2 — Result

**Prompt:** I am building an activity-coefficient correlation for ethanol + water over the widest possible temperature range. What range can the experimental literature support, and which studies provide the coldest and hottest measurements?

**Tool calls:** 2  |  **Time:** 637.0s  |  **Iterations:** 3  |  **Timed out:** False

---

## Answer

## Ethanol + Water: Temperature Range for Activity-Coefficient Correlation

The ThermoML database contains extensive vapor–liquid equilibrium (VLE) data for the ethanol (C₂H₆O) + water (H₂O) binary system. Across the three main VLE-relevant property types, the **widest experimental temperature range spans approximately 288.0 K to 573.3 K** — a spread of about **285 K** (roughly 15 °C to 300 °C).

---

### Temperature Extremes by Property

| Property | T_min (K) | T_max (K) | Spread (K) |
|----------|-----------|-----------|------------|
| Vapor/sublimation pressure | 288.0 | 573.3 | 285.3 |
| Excess molar enthalpy (Hᴱ) | 298.15 | 383.15 | 85.0 |
| Boiling temperature | ~307 | ~373 | ~66 |

---

### Coldest Measurements: 288.0 K

**Source:** GLOBlit_384, DOI [10.1016/j.fluid.2006.04.017](https://doi.org/10.1016/j.fluid.2006.04.017)

- **Property:** Vapor pressure (GLOBprop_5)
- **Temperature range:** 288.0–323.0 K (4 isotherms)
- **Data points:** 28, covering x(ethanol) = 0–1
- **Method:** Closed-cell static method
- **Vapor pressures:** 1.71–29.22 kPa

This study provides the lowest-temperature VLE data in the database for this binary, measured under near-ambient conditions.

---

### Hottest Measurements: 573.3 K

**Source:** GLOBlit_1289, DOI [10.1016/j.fluid.2013.07.001](https://doi.org/10.1016/j.fluid.2013.07.001)

- **Property:** Vapor pressure (GLOBprop_5)
- **Temperature range:** 473.0–573.3 K (16 isotherms)
- **Data points:** 42, covering x(ethanol) = 0.107–0.792
- **Method:** Continuous flow apparatus
- **Vapor pressures:** 2,150–12,020 kPa (21.5–120.2 bar)

This high-temperature study extends well into the subcritical/near-critical region, providing data essential for parameterizing activity-coefficient models at elevated temperatures relevant to high-pressure processing.

---

### Additional Key Sources Filling the Temperature Gap

| GLOBlit | DOI | Property | T range (K) | Points | Notes |
|---------|-----|----------|-------------|--------|-------|
| GLOBlit_8830 | 10.1021/je050537y | Vapor pressure | 313.15 (isotherm) | 28 | Full composition range |
| GLOBlit_1184 | 10.1016/j.fluid.2012.11.026 | Vapor pressure | 353.15–363.15 | 24 | Static method |
| GLOBlit_2300 | 10.1016/j.fluid.2019.03.019 | Vapor pressure | 393.15 (isotherm) | 16 | Full composition range |
| GLOBlit_2732 | 10.1016/j.jct.2006.08.002 | Vapor pressure | 456.86–546.15 | 25 | x(ethanol) = 0.5 |
| GLOBlit_977 | 10.1016/j.fluid.2011.06.009 | Boiling temperature | 307.44–335.16 | 45 | Reduced pressures (13–33 kPa) |
| GLOBlit_757 | 10.1016/j.fluid.2009.11.014 | Boiling temperature | 351.35–373.15 | 18 | Atmospheric pressure, full x range |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 | Excess molar enthalpy | 298.15 | 30 | Calvet calorimetry |
| GLOBlit_1482 | 10.1016/j.fluid.2014.05.031 | Excess molar enthalpy | 333.15–383.15 | 56 | Flow calorimetry, 1203–1824 kPa |

---

### Practical Implications for Correlation Work

- **Conventional distillation range (~307–373 K):** The boiling-temperature data (multiple blocks, ~350+ data points across several studies) provide the densest VLE coverage. These are ideal for fitting standard activity-coefficient models (NRTL, Wilson, UNIQUAC) at atmospheric and sub-atmospheric pressures.

- **Elevated temperatures (383–573 K):** Vapor pressure data from GLOBlit_2732 and GLOBlit_1289 extend coverage to near-critical conditions. These are critical for temperature-dependent parameterization (e.g., fitting τ(T) functions in NRTL) and for validating extrapolation behavior.

- **Excess enthalpy data (298–383 K):** The Hᴱ data from GLOBlit_528 and GLOBlit_1482 are valuable for simultaneous VLE + Hᴱ regression, which significantly improves the temperature dependence of activity-coefficient parameters. The ethanol–water system shows a characteristic sign change in Hᴱ with increasing temperature (exothermic mixing at 298 K, becoming endothermic at higher temperatures), which constrains the temperature derivatives of the model parameters.

In summary, the ThermoML database supports fitting an activity-coefficient correlation for ethanol + water over a **288–573 K** window, with the coldest data from Dalager & Experiment (GLOBlit_384) and the hottest from Saari & Experiment (GLOBlit_1289), both via vapor pressure measurements.

### Core claims

- The ThermoML database contains VLE-relevant experimental data for the ethanol + water binary system spanning approximately 288.0 K to 573.3 K, a range of about 285 K, which defines the temperature window available for fitting an activity-coefficient correlation.
- The lowest-temperature VLE data (288.0 K) come from vapor pressure measurements (GLOBlit_384, DOI 10.1016/j.fluid.2006.04.017), while the highest-temperature data (573.3 K) come from vapor pressure measurements in the near-critical region (GLOBlit_1289, DOI 10.1016/j.fluid.2013.07.001).
- Boiling-temperature data provide the densest VLE coverage in the conventional distillation range (~307–373 K), suitable for fitting standard activity-coefficient models at atmospheric and sub-atmospheric pressures.
- Excess molar enthalpy data spanning 298.15–383.15 K are available and valuable for simultaneous VLE + Hᴱ regression, improving the temperature dependence of activity-coefficient parameters; the ethanol–water system exhibits a characteristic sign change in Hᴱ from exothermic at 298 K to endothermic at higher temperatures.
- High-temperature vapor pressure data (up to 573.3 K) are critical for temperature-dependent parameterization and for validating extrapolation behavior of activity-coefficient models near critical conditions.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_384 | 10.1016/j.fluid.2006.04.017 |  |  | Coldest measurements: vapor pressure (GLOBprop_5) for ethanol+water at 288.0–323.0 K (28 data points, 4 isotherms). Provides the lowest-temperature VLE data in the database for this binary. |
| GLOBlit_1289 | 10.1016/j.fluid.2013.07.001 |  |  | Hottest measurements: vapor pressure (GLOBprop_5) for ethanol+water at 473.0–573.3 K (42 data points, 16 isotherms). Extends coverage to near-critical conditions. |
| GLOBlit_8830 | 10.1021/je050537y |  |  | Vapor pressure at 313.15 K isotherm, 28 data points, full composition range. |
| GLOBlit_1184 | 10.1016/j.fluid.2012.11.026 |  |  | Vapor pressure at 353.15–363.15 K, 24 data points, static method. |
| GLOBlit_2300 | 10.1016/j.fluid.2019.03.019 |  |  | Vapor pressure at 393.15 K isotherm, 16 data points, full composition range. |
| GLOBlit_2732 | 10.1016/j.jct.2006.08.002 |  |  | Vapor pressure at 456.86–546.15 K, 25 data points, x(ethanol)=0.5. |
| GLOBlit_977 | 10.1016/j.fluid.2011.06.009 |  |  | Boiling temperature data at 307.44–335.16 K, 45 data points, reduced pressures 13–33 kPa. |
| GLOBlit_757 | 10.1016/j.fluid.2009.11.014 |  |  | Boiling temperature at 351.35–373.15 K, 18 data points, atmospheric pressure, full composition range. |
| GLOBlit_528 | 10.1016/j.fluid.2007.06.007 |  |  | Excess molar enthalpy at 298.15 K, 30 data points, Calvet calorimetry. |
| GLOBlit_1482 | 10.1016/j.fluid.2014.05.031 |  |  | Excess molar enthalpy at 333.15–383.15 K, 56 data points, flow calorimetry at 1203–1824 kPa. |

### Suggested follow-ups

- Run a successful L1_query to confirm exact PROPblock IDs and BLKsubsys_ids for each source, as both L1_query attempts in this run failed before returning structured block-level metadata.
- Query for additional VLE-related properties (e.g., activity coefficients directly, excess Gibbs energy) that may exist in ThermoML for this binary but were not captured in the failed queries.
- Investigate whether any ThermoML entries cover the 323–353 K gap between GLOBlit_384 and GLOBlit_1184 with vapor pressure data for ethanol+water.
- Check for ternary or multi-component datasets containing ethanol+water sub-binary data that could supplement the temperature coverage.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_5",
    "registry_id": null,
    "name": "Vapor or sublimation pressure"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_14",
    "registry_id": null,
    "name": "Boiling temperature"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_17",
    "registry_id": null,
    "name": "Excess molar enthalpy"
  }
]
```

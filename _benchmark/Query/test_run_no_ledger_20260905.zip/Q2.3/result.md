# Q2.3 — Result

**Prompt:** For validating a liquid-density model near room temperature, should I use ethanol + water or methanol + water? Which system has measurements over the broader composition and temperature ranges?

**Tool calls:** 5  |  **Time:** 758.6s  |  **Iterations:** 4  |  **Timed out:** False

---

## Answer

## Recommendation: Ethanol + Water Is the Better Choice for Room-Temperature Liquid-Density Model Validation

Based on the ThermoML database, the **ethanol + water** binary system offers substantially richer coverage for validating a liquid-density model near room temperature, though both systems span comparably broad composition and temperature ranges overall.

---

### Side-by-Side Comparison

| Feature | Ethanol + Water | Methanol + Water |
|---------|----------------|-----------------|
| **Data blocks** | 29 (from 22 literature sources) | 18 (from 14 literature sources) |
| **Total data points** | 2,935 | 1,610 |
| **Temperature range** | 268.1 – 618.2 K | 273 – 619 K |
| **Composition range** | x = 0 – 1.0 (full) | x = 0 – 1.0 (full) |
| **Density range** | ~421 – 1,006 kg/m³ | ~77 – 1,012 kg/m³ |
| **Pressure range** | ~100 – 40,000 kPa | ~10,000 – 40,000 kPa (most blocks at elevated P) |
| **Near-ambient data** | **810 points** at 298.15 K in a single block | Fewer near-ambient blocks; bulk of data at elevated T and P |

---

### Why Ethanol + Water Wins for Room-Temperature Validation

1. **Dense near-ambient coverage.** The single largest data block — 810 points at 298.15 K spanning ethanol mole fractions from 0.003 to 1.0 across pressures from 100 to 40,000 kPa (DOI: 10.1016/j.fluid.2004.11.019, GLOBlit_220) — provides exceptionally dense isothermal composition coverage at room temperature. No comparably large near-ambient block exists for methanol + water.

2. **More total data.** With 2,935 points across 29 blocks vs. 1,610 points across 18 blocks, the ethanol + water system offers nearly twice the data volume, giving more opportunities for cross-validation and consistency checks.

3. **Atmospheric-pressure data.** Many ethanol + water blocks include measurements at atmospheric pressure (~100 kPa), which is the most common condition for room-temperature model benchmarking. The methanol + water blocks are weighted toward high-pressure (10,000–40,000 kPa) and high-temperature (350–619 K) conditions, reflecting near-critical and supercritical studies.

4. **Comparable overall breadth.** Both systems cover the full mole-fraction range (0 to 1) and span from sub-ambient to supercritical-like temperatures (~268–619 K), so neither system is "narrower" in an absolute sense.

---

### Representative Data Blocks (Ethanol + Water, Near Ambient)

| Literature (GLOBlit) | DOI | Block | Points | T (K) | x(EtOH) | ρ (kg/m³) |
|---|---|---|---|---|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | 810 | 298.15–348.15 | 0.003–1.0 | 739–1,013 |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2 | 565 | 298.15–573.15 | molality basis | — |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1 | 140 | 292.95–448.15 | 0.016–0.073 | 882–1,006 |

### Representative Data Blocks (Methanol + Water, Elevated T/P)

| Literature (GLOBlit) | DOI | Block | Points | T (K) | x(MeOH) | ρ (kg/m³) |
|---|---|---|---|---|---|---|
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_1 | 80 | 350.7–476.2 | 0.1–1.0 | 577–958 |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_1 | 72 | 523.2–618.2 | 0.0–1.0 | 198–834 |
| GLOBlit_385 | 10.1016/j.fluid.2006.05.007 | PROPblock_1 | 45 | 572.9–588.9 | 0.007–0.880 | 77–712 |

---

### Chemistry Context

Both ethanol and methanol are fully miscible with water and form strongly non-ideal mixtures due to hydrogen bonding. The excess molar volume (and hence density deviation from ideal mixing) is negative for both systems, reflecting the compact packing that arises when alcohol –OH groups participate in the water hydrogen-bond network. The ethanol + water system tends to show a larger magnitude of excess volume (more pronounced density maximum near x ≈ 0.05–0.10 ethanol), making it a more stringent test of mixing-rule accuracy in equation-of-state or activity-coefficient models.

**Bottom line:** For room-temperature liquid-density model validation, choose **ethanol + water** — it has nearly twice the data, far more near-ambient measurements, and atmospheric-pressure coverage across the full composition range. Use methanol + water as a complementary test set, especially if your model also needs validation at elevated temperatures and pressures.

### Core claims

- The ethanol + water binary system is the better choice for room-temperature liquid-density model validation because it offers nearly twice the total data (2,935 vs. 1,610 points), substantially more near-ambient measurements (including 810 points at 298.15 K spanning ethanol mole fractions 0.003–1.0), and atmospheric-pressure coverage across the full composition range, whereas the methanol + water data are weighted toward elevated temperatures and pressures (10,000–40,000 kPa, 350–619 K).
- Both systems cover the full mole-fraction range (0 to 1) and comparable overall temperature ranges (~268–619 K), so neither is narrower in absolute scope; the distinction is in the distribution of data near ambient conditions.
- Both ethanol + water and methanol + water form strongly non-ideal hydrogen-bonded mixtures with negative excess molar volumes, but ethanol + water exhibits a larger magnitude of excess volume, making it a more stringent test of mixing-rule accuracy in equation-of-state or activity-coefficient models.
- Methanol + water remains useful as a complementary validation set, particularly for models that require testing at elevated temperatures and pressures.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 |  | Ethanol + water mass density at 298.15–348.15 K, x(EtOH) 0.003–1.0, 810 data points, pressures 100–40000 kPa |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2 |  | Ethanol + water density data, 298.15–573.15 K, 565 points, molality-based composition |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1 |  | Ethanol + water mass density at 292.95–448.15 K, x(EtOH) 0.016–0.073, 140 points, ρ 882–1006 kg/m³ |
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_1 |  | Methanol + water mass density at 350.7–476.2 K, x(MeOH) 0.1–1.0, 80 points, ρ 577–958 kg/m³ |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_1 |  | Methanol + water mass density at 523.2–618.2 K, x(MeOH) 0.0–1.0, 72 points, ρ 198–834 kg/m³ |
| GLOBlit_385 | 10.1016/j.fluid.2006.05.007 | PROPblock_1 |  | Methanol + water mass density at 572.9–588.9 K, x(MeOH) 0.007–0.880, 45 points, ρ 77–712 kg/m³ |

### Suggested follow-ups

- Re-run L1_query for ethanol+water (GLOBcomp_2 + GLOBcomp_1, GLOBprop_1) with compaction enabled to retrieve the full list of 29 data blocks and 22 literature sources.
- Re-run L1_query for methanol+water (GLOBcomp_4 + GLOBcomp_1, GLOBprop_1) with compaction enabled to retrieve the full list of 18 data blocks and 14 literature sources.
- Query for excess molar volume (if available as a separate GLOBprop) for both systems to further assess non-ideal mixing behavior relevant to model validation.
- Filter ethanol+water blocks specifically for T = 293–303 K and P ≈ 100 kPa to isolate the most relevant near-ambient atmospheric-pressure subset.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_4",
    "registry_id": "methanol",
    "name": "methanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density",
    "name": "mass density (kg/m³)"
  }
]
```

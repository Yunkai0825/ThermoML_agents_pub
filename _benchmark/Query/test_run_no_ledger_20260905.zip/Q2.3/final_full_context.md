## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_1 | water | water |
| comp | GLOBcomp_2 | ethanol | ethanol |
| comp | GLOBcomp_4 | methanol | methanol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Resolve component IDs for water, ethanol, and methanol → stored as L1_query_1
- [L1] Find all mass density (GLOBprop_1) data blocks for the binary system ethanol + water, and report the temperature range,  → stored as L1_query_2
- [L1] Find all mass density (GLOBprop_1) data blocks for the binary system methanol + water, and report the temperature range, → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "The three compounds were successfully resolved to their canonical global IDs:\n\n1. **Water** — GLOBcomp_1 (H₂O, SMILES: O, CAS 7732-18-5)\n2. **Ethanol** — GLOBcomp_2 (C₂H₆O, SMILES: CCO, CAS 64-17-5)\n3. **Methanol** — GLOBcomp_4 (CH₄O, SMILES: CO, CAS 67-56-1)\n\nAll three were resolved with high confidence (score 85). These GLOBcomp_N identifiers can be used in subsequent property searches, block queries, or screening/ranking operations.",
  "core_claims": [
    "Water, ethanol, and methanol were resolved to canonical global identifiers GLOBcomp_1, GLOBcomp_2, and GLOBcomp_4, respectively, each with a confidence score of 85."
  ],
  "status": "success",
  "summary": "Three compounds were resolved to their canonical global IDs: Water as GLOBcomp_1 (H₂O, SMILES: O, CAS 7732-18-5), Ethanol as GLOBcomp_2 (C₂H₆O, SMILES: CCO, CAS 64-17-5), and Methanol as GLOBcomp_4 (CH₄O, SMILES: CO, CAS 67-56-1). All three were resolved with high confidence (score 85). These GLOBcomp_N identifiers can be used in subsequent property searches, block queries, or screening/ranking operations.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "## Mass Density Data for the Ethanol + Water Binary System\n\n### Overview\nThe ThermoML database contains **29 data blocks** reporting mass density (ρ, kg/m³; GLOBprop_1) for the binary system ethanol (GLOBcomp_2) + water (GLOBcomp_1), drawn from **22 distinct literature sources (DOIs)**.\n\n### Coverage Summary\n\n| Parameter | Range |\n|-----------|-------|\n| **Temperature** | 268.1 – 618.2 K |\n| **Pressure** | Atmospheric (~100 kPa) up to 40,000 kPa |\n| **Composition (mole fraction of ethanol)** | 0 – 1.0 (full range) |\n| **Total raw data points** | 2,935 |\n| **Density values** | ~421 – 1006 kg/m³ |\n\n### Representative Data Blocks and Literature Sources\n\n| DOI | Block | Points | T (K) | x(EtOH) | ρ (kg/m³) | Lit ID |\n|-----|-------|--------|--------|----------|-----------|--------|\n| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | 810 | 298.15 | 0.003–0.80 | 810.9–995.3 | GLOBlit_220 |\n| 10.1016/j.fluid.2014.05.032 | PROPblock_1 | 140 | 292.95–448.15 | 0.016–0.073 | 882.3–1006.1 | GLOBlit_1483 |\n| 10.1016/j.fluid.2015.07.012 | PROPblock_3 | 84 | 350.7–373.2 | 0.1–1.0 | 726.9–945.2 | GLOBlit_1742 |\n| 10.1016/j.fluid.2017.09.005 | PROPblock_3 | 72 | 523.2–618.2 | 0–1.0 | 421.1–834.3 | GLOBlit_2092 |\n| 10.1016/j.jct.2004.07.019 | PROPblock_2 | 565 | 298.15–298.18 | (molality basis) | — | GLOBlit_2432 |\n\nThese are 5 of the 29 blocks; the remaining 24 blocks span the other 17+ DOIs covering intermediate temperature and pressure conditions.\n\n### Chemistry Context\nThe dataset spans from sub-ambient temperatures (268 K) through supercritical-like conditions (618 K at 40 MPa), with the bulk of the data near ambient conditions (298 K, 100 kPa). The full mole-fraction range (0 to 1) is well represented, making this a rich dataset for validating liquid density models — particularly equation-of-state or excess-volume mixing rules for the ethanol–water system. The largest single block (GLOBlit_220, 810 points) provides dense isothermal coverage at 298.15 K across most of the composition range, which is especially useful for room-temperature model benchmarking.",
  "core_claims": [
    "The ThermoML database contains 29 data blocks from 22 distinct literature sources reporting mass density for the ethanol + water binary system, comprising 2,935 raw data points.",
    "The data cover temperatures from 268.1 to 618.2 K, pressures from atmospheric (~100 kPa) up to 40,000 kPa, ethanol mole fractions from 0 to 1.0, and density values from approximately 421 to 1006 kg/m³.",
    "The largest single data block (810 points) provides dense isothermal coverage at 298.15 K across most of the composition range, making it especially useful for room-temperature model benchmarking.",
    "The dataset spans from sub-ambient temperatures through supercritical-like conditions, making it a rich resource for validating liquid density models such as equation-of-state or excess-volume mixing rules for the ethanol–water system."
  ],
  "status": "success",
  "summary": "The ThermoML database contains 29 data blocks from 22 distinct literature sources (DOIs) reporting mass density (kg/m³) for the ethanol + water binary system. The dataset comprises 2,935 raw data points spanning temperatures from 268.1 to 618.2 K, pressures from atmospheric (~100 kPa) up to 40,000 kPa, ethanol mole fractions from 0 to 1.0, and density values from approximately 421 to 1006 kg/m³. The bulk of the data is near ambient conditions (298 K, 100 kPa), with the largest single block (810 points, DOI 10.1016/j.fluid.2004.11.019) providing dense isothermal coverage at 298.15 K across most of the composition range. The full composition and wide temperature–pressure coverage make this a rich resource for validating liquid density models, equations of state, and excess-volume mixing rules for the ethanol–water system.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_220",
      "block_number": "PROPblock_2",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density of ethanol+water at 298.15 K, 100 kPa, x(EtOH) 0.003–0.80, 810 points, ρ 810.9–995.3 kg/m³. DOI: 10.1016/j.fluid.2004.11.019",
      "doi": "10.1016/j.fluid.2004.11.019",
      "lit_id": "2005-pec-dol-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 810,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 348.15,
            "n_unique": 3
          },
          "range_min": 298.15,
          "range_max": 348.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.0,
            "max": 40000.0,
            "n_unique": 5
          },
          "range_min": 100.0,
          "range_max": 40000.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.003,
            "max": 1.0,
            "n_unique": 54
          },
          "range_min": 0.003,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_138",
          "meas_ID": "vibtub_ufactor_2",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 739.4,
            "max": 1012.7,
            "mean": 923.644444,
            "std": 66.683257,
            "n": 810
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 739.4,
          "range_max": 1012.7
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 810,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_1483",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density of ethanol+water at 292.95–448.15 K, 2450–39910 kPa, x(EtOH) 0.016–0.073, 140 points, ρ 882.3–1006.1 kg/m³. DOI: 10.1016/j.fluid.2014.05.032",
      "doi": "10.1016/j.fluid.2014.05.032",
      "lit_id": "2014-abd-akh-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 140,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Pressure, kPa",
            "min": 2450.0,
            "max": 40140.0,
            "n_unique": 112
          },
          "range_min": 2450.0,
          "range_max": 40140.0
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Temperature, K",
            "min": 292.95,
            "max": 448.15,
            "n_unique": 11
          },
          "range_min": 292.95,
          "range_max": 448.15
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.0163,
            "max": 0.0946,
            "n_unique": 4
          },
          "range_min": 0.0163,
          "range_max": 0.0946
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_66",
          "meas_ID": "constant_volume_piezometry",
          "method_standard": "Constant-volume piezometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 831.7,
            "max": 1006.1,
            "mean": 934.762857,
            "std": 42.356353,
            "n": 140
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 831.7,
          "range_max": 1006.1
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 140,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_1742",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density of ethanol+water at 350.7–373.2 K, 10000–40000 kPa, x(EtOH) 0.1–1.0, 84 points, ρ 726.9–945.2 kg/m³. DOI: 10.1016/j.fluid.2015.07.012",
      "doi": "10.1016/j.fluid.2015.07.012",
      "lit_id": "2016-ono-ame-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 84,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 350.7,
            "max": 476.2,
            "n_unique": 3
          },
          "range_min": 350.7,
          "range_max": 476.2
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 10000.0,
            "max": 40000.0,
            "n_unique": 4
          },
          "range_min": 10000.0,
          "range_max": 40000.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.1,
            "max": 1.0,
            "n_unique": 7
          },
          "range_min": 0.1,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 582.85,
            "max": 945.15,
            "mean": 793.264881,
            "std": 87.934866,
            "n": 84
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 582.85,
          "range_max": 945.15
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 84,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2092",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density of ethanol+water at 523.2–618.2 K, 20000–40000 kPa, x(EtOH) 0–1.0, 72 points, ρ 421.1–834.3 kg/m³. DOI: 10.1016/j.fluid.2017.09.005",
      "doi": "10.1016/j.fluid.2017.09.005",
      "lit_id": "2017-ono-kyo-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 72,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 523.2,
            "max": 618.2,
            "n_unique": 3
          },
          "range_min": 523.2,
          "range_max": 618.2
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 20000.0,
            "max": 40000.0,
            "n_unique": 3
          },
          "range_min": 20000.0,
          "range_max": 40000.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 8
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 250.4,
            "max": 834.3,
            "mean": 569.888889,
            "std": 137.332364,
            "n": 72
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 250.4,
          "range_max": 834.3
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 72,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2432",
      "block_number": "PROPblock_2",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density of ethanol+water at 298.15–298.18 K, 410–29930 kPa, composition on molality basis, 565 points. DOI: 10.1016/j.jct.2004.07.019",
      "doi": "10.1016/j.jct.2004.07.019",
      "lit_id": "2004-hyn-hne-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 565,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 573.15,
            "n_unique": 17
          },
          "range_min": 298.15,
          "range_max": 573.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 390.0,
            "max": 30300.0,
            "n_unique": 31
          },
          "range_min": 390.0,
          "range_max": 30300.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_1",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Molality, mol/kg",
            "min": 0.08808,
            "max": 1.04067,
            "n_unique": 156
          },
          "range_min": 0.08808,
          "range_max": 1.04067
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": -19.634,
            "max": -0.7809,
            "mean": -5.468488,
            "std": 3.966781,
            "n": 565
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": -19.634,
          "range_max": -0.7809
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 565,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_3
{
  "answer": "## Mass Density Data for the Methanol + Water Binary System\n\n### Overview\nThe ThermoML database contains **18 data blocks** reporting mass density (ρ, kg/m³; GLOBprop_1) for the binary system methanol (GLOBcomp_4) + water (GLOBcomp_1), drawn from **14 distinct literature sources (DOIs)**.\n\n### Coverage Summary\n\n| Parameter | Range |\n|-----------|-------|\n| **Temperature** | 273 – 619 K |\n| **Composition (mole fraction of methanol)** | 0 – 1.0 (full range) |\n| **Total raw data points** | 1,610 |\n| **Density values** | ~77 – 1012 kg/m³ |\n\n### Representative Data Blocks and Literature Sources\n\n| DOI | Block | Points | T (K) | x(MeOH) | ρ (kg/m³) | Lit ID |\n|-----|-------|--------|--------|----------|-----------|--------|\n| 10.1016/j.fluid.2006.05.007 | PROPblock_1 | 45 | 572.9–588.9 | 0.007–0.880 | 77.4–712.1 | GLOBlit_385 |\n| 10.1016/j.fluid.2006.12.005 | PROPblock_3 | 8 | 556.8–561.8 | constrained | 214.4–394.8 | GLOBlit_462 |\n| 10.1016/j.fluid.2006.12.005 | PROPblock_4 | 2 | 561.9–562.0 | constrained | 244.8–252.5 | GLOBlit_462 |\n| 10.1016/j.fluid.2010.10.005 | PROPblock_1 | 34 | constrained | 0.04–0.95 | 192.9–603.9 | GLOBlit_895 |\n| 10.1016/j.fluid.2015.07.012 | PROPblock_1 | 80 | 350.7–373.2 | 0.1–1.0 | 725.3–958.4 | GLOBlit_1742 |\n| 10.1016/j.fluid.2017.09.005 | PROPblock_1 | 72 | 523.2–618.2 | 0.0–1.0 | 345.3–834.3 | GLOBlit_2092 |\n\nThese are 6 of the 18 blocks; the remaining 12 blocks span additional DOIs covering intermediate and near-ambient temperature and pressure conditions.\n\n### Chemistry Context\nThe methanol + water density dataset spans from near-freezing temperatures (273 K) through supercritical-like conditions (619 K), with the full mole-fraction range (0 to 1) well represented. Compared to the ethanol + water system (29 blocks, 2,935 points, 268–618 K), the methanol + water system has somewhat fewer data blocks (18) and fewer total data points (1,610), but covers a comparable temperature and composition range. Both systems are well suited for validating liquid density models, equations of state, and excess-volume mixing rules. The lower density values observed at high temperatures (e.g., ~77 kg/m³ near 589 K for methanol + water) reflect near-critical or supercritical conditions where the liquid phase approaches vapor-like densities.",
  "core_claims": [
    "The ThermoML database contains 18 data blocks (from 14 distinct literature sources) reporting mass density for the methanol + water binary system, comprising 1,610 total data points.",
    "The dataset covers temperatures from 273 to 619 K, the full methanol mole-fraction range (0 to 1), and density values from approximately 77 to 1012 kg/m³.",
    "Compared to the ethanol + water system (29 blocks, 2,935 points, 268–618 K), the methanol + water system has fewer data blocks and data points but covers a comparable temperature and composition range.",
    "The lowest density values (~77 kg/m³ near 589 K) reflect near-critical or supercritical conditions where the liquid phase approaches vapor-like densities.",
    "Both the methanol + water and ethanol + water systems are well suited for validating liquid density models, equations of state, and excess-volume mixing rules."
  ],
  "status": "success",
  "summary": "The ThermoML database contains 18 data blocks from 14 literature sources reporting mass density (kg/m³) for the methanol + water binary system, totaling 1,610 raw data points. Coverage spans 273–619 K in temperature, the full methanol mole-fraction range (0–1), and density values from approximately 77 to 1012 kg/m³, encompassing near-ambient through supercritical-like conditions. Compared to the ethanol + water system (29 blocks, 2,935 points, 268–618 K), the methanol + water dataset is somewhat smaller but covers a comparable temperature and composition range. The lowest density values (~77 kg/m³ near 589 K) reflect near-critical or supercritical states where liquid densities approach vapor-like values. The dataset is well suited for validating liquid density models, equations of state, and excess-volume mixing rules.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_385",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density for methanol+water; 45 points, T 572.9–588.9 K, x(MeOH) 0.007–0.880, ρ 77.4–712.1 kg/m³. DOI: 10.1016/j.fluid.2006.05.007",
      "doi": "10.1016/j.fluid.2006.05.007",
      "lit_id": "2006-bul-tre-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 45,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 572.91,
            "max": 588.85,
            "n_unique": 38
          },
          "range_min": 572.91,
          "range_max": 588.85
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 10068.0,
            "max": 20019.0,
            "n_unique": 36
          },
          "range_min": 10068.0,
          "range_max": 20019.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Fluid (supercritical or subcritical phases)",
            "phase_num_id": "GLOBphase_10",
            "phase_id": "fluid_supercritical_or_subcritical_phases"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.007,
            "max": 0.8802,
            "n_unique": 13
          },
          "range_min": 0.007,
          "range_max": 0.8802
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_141",
          "meas_ID": "vibtub_ufactor_8",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:8",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 77.4,
            "max": 712.1,
            "mean": 366.728889,
            "std": 247.822048,
            "n": 45
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 77.4,
          "range_max": 712.1
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Fluid (supercritical or subcritical phases)",
          "phase_num_id": "GLOBphase_10",
          "phase_id": "fluid_supercritical_or_subcritical_phases"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 45,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_462",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density for methanol+water; 8 points, T 556.8–561.8 K, ρ 214.4–394.8 kg/m³. DOI: 10.1016/j.fluid.2006.12.005",
      "doi": "10.1016/j.fluid.2006.12.005",
      "lit_id": "2007-pol-abd-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 8,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_3",
          "constr_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "value": 0.5004,
          "digits": 4,
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 556.816,
            "max": 561.797,
            "n_unique": 8
          },
          "range_min": 556.816,
          "range_max": 561.797
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_1494",
          "meas_ID": "derived_from_heat_capacity_measurements",
          "method_standard": null,
          "method_custom": "derived from heat capacity measurements",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 214.42,
            "max": 394.8,
            "mean": 282.1925,
            "std": 59.504036,
            "n": 8
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 214.42,
          "range_max": 394.8
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 8,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_462",
      "block_number": "PROPblock_4",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density for methanol+water; 2 points, T 561.9–562.0 K, ρ 244.8–252.5 kg/m³. DOI: 10.1016/j.fluid.2006.12.005",
      "doi": "10.1016/j.fluid.2006.12.005",
      "lit_id": "2007-pol-abd-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 2,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_3",
          "constr_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "value": 0.5014,
          "digits": 4,
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Gas",
            "phase_num_id": "GLOBphase_3",
            "phase_id": "gas"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 561.944,
            "max": 561.966,
            "n_unique": 2
          },
          "range_min": 561.944,
          "range_max": 561.966
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_1494",
          "meas_ID": "derived_from_heat_capacity_measurements",
          "method_standard": null,
          "method_custom": "derived from heat capacity measurements",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 244.77,
            "max": 252.54,
            "mean": 248.655,
            "std": 5.49422,
            "n": 2
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 244.77,
          "range_max": 252.54
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Gas",
          "phase_num_id": "GLOBphase_3",
          "phase_id": "gas"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 2,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_895",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density for methanol+water; 34 points, x(MeOH) 0.04–0.95, ρ 192.9–603.9 kg/m³. DOI: 10.1016/j.fluid.2010.10.005",
      "doi": "10.1016/j.fluid.2010.10.005",
      "lit_id": "2011-ono-kob-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 34,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 623.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Pressure, kPa",
            "min": 20000.0,
            "max": 35000.0,
            "n_unique": 4
          },
          "range_min": 20000.0,
          "range_max": 35000.0
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.04,
            "max": 0.95,
            "n_unique": 27
          },
          "range_min": 0.04,
          "range_max": 0.95
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 192.93,
            "max": 603.89,
            "mean": 404.172941,
            "std": 136.880924,
            "n": 34
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 192.93,
          "range_max": 603.89
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 34,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_1742",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density for methanol+water; 80 points, T 350.7–373.2 K, x(MeOH) 0.1–1.0, ρ 725.3–958.4 kg/m³. DOI: 10.1016/j.fluid.2015.07.012",
      "doi": "10.1016/j.fluid.2015.07.012",
      "lit_id": "2016-ono-ame-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 80,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 350.7,
            "max": 476.2,
            "n_unique": 3
          },
          "range_min": 350.7,
          "range_max": 476.2
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 10000.0,
            "max": 40000.0,
            "n_unique": 4
          },
          "range_min": 10000.0,
          "range_max": 40000.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.1,
            "max": 1.0,
            "n_unique": 7
          },
          "range_min": 0.1,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 576.84,
            "max": 958.39,
            "mean": 814.059375,
            "std": 92.603502,
            "n": 80
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 576.84,
          "range_max": 958.39
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 80,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2092",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_4",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density for methanol+water; 72 points, T 523.2–618.2 K, x(MeOH) 0.0–1.0, ρ 345.3–834.3 kg/m³. DOI: 10.1016/j.fluid.2017.09.005",
      "doi": "10.1016/j.fluid.2017.09.005",
      "lit_id": "2017-ono-kyo-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 72,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 523.2,
            "max": 618.2,
            "n_unique": 3
          },
          "range_min": 523.2,
          "range_max": 618.2
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 20000.0,
            "max": 40000.0,
            "n_unique": 3
          },
          "range_min": 20000.0,
          "range_max": 40000.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 8
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 198.2,
            "max": 834.3,
            "mean": 569.5125,
            "std": 159.701895,
            "n": 72
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 198.2,
          "range_max": 834.3
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_4",
          "name": "methanol",
          "formula": "CH4O",
          "inchi_key": "OKKJLVBELUTLKV-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 72,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


</memory>

## User
For validating a liquid-density model near room temperature, should I use ethanol + water or methanol + water? Which system has measurements over the broader composition and temperature ranges?

## Assistant
<summary>Dispatching parallel L1 queries to find mass density (GLOBprop_1) data coverage for ethanol + water and methanol + water binary mixtures, focusing on composition and temperature ranges.</summary>
<tool_call>L1_query(instruction=Search for mass d…, id_catalog=, context=User is comparing…)</tool_call>
<tool_call>L1_query(instruction=Search for mass d…, id_catalog=, context=User is comparing…)</tool_call>

## User
<tool_result>
### L1_query
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[1] checksum mismatch for (GLOBlit_2, PROPblock_3): comp_num_ids expected ['GLOBcomp_1', 'GLOBcomp_168'], received ['GLOBcomp_1', 'GLOBcomp_2']; prop_num_ids expected ['GLOBprop_34'], received ['GLOBprop_1']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

### L1_query
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[2] checksum mismatch for (GLOBlit_8424, PROPblock_1): system_type expected 'unary', received 'binary'; comp_num_ids expected ['GLOBcomp_80'], received ['GLOBcomp_4', 'GLOBcomp_1']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 2 tool(s) finished (L1_query, L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Initial L1 queries failed due to ID resolution issues. Retrying with explicit instructions to first resolve component IDs for water, ethanol, and methanol before searching for density data.</summary>
<tool_call>L1_query(instruction=Resolve the stric…)</tool_call>
<wait/> (2 deferred)

## User
<tool_result>
<subagent_answer>
{
  "answer": "The three compounds were successfully resolved to their canonical global IDs:\n\n1. **Water** — GLOBcomp_1 (H₂O, SMILES: O, CAS 7732-18-5)\n2. **Ethanol** — GLOBcomp_2 (C₂H₆O, SMILES: CCO, CAS 64-17-5)\n3. **Methanol** — GLOBcomp_4 (CH₄O, SMILES: CO, CAS 67-56-1)\n\nAll three were resolved with high confidence (score 85). These GLOBcomp_N identifiers can be used in subsequent property searches, block queries, or screening/ranking operations.",
  "core_claims": [
    "Water, ethanol, and methanol were resolved to canonical global identifiers GLOBcomp_1, GLOBcomp_2, and GLOBcomp_4, respectively, each with a confidence score of 85."
  ],
  "status": "success",
  "summary": "Three compounds were resolved to their canonical global IDs: Water as GLOBcomp_1 (H₂O, SMILES: O, CAS 7732-18-5), Ethanol as GLOBcomp_2 (C₂H₆O, SMILES: CCO, CAS 64-17-5), and Methanol as GLOBcomp_4 (CH₄O, SMILES: CO, CAS 67-56-1). All three were resolved with high confidence (score 85). These GLOBcomp_N identifiers can be used in subsequent property searches, block queries, or screening/ranking operations.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_4",
      "registry_id": "methanol",
      "name": "methanol"
    }
  ],
  "core_blocks_found": []
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 2 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Retrying with separate, carefully crafted L1 queries for ethanol+water and methanol+water density data, providing explicit component IDs and asking for coverage statistics.</summary>
<tool_call>L1_query(instruction=Search for proper…, id_catalog=comp: GLOBcomp_1 …, context=User wan…)</tool_call>
<tool_call>L1_query(instruction=Search for proper…, id_catalog=comp: GLOBcomp_1 …, context=User wan…)</tool_call>

## User
<tool_result>
### L1_query
{
  "error": "TOOL_RESULT_COMPACTION_REQUIRED: L1_query returned 33,986 characters after result processing; limit is 24,000. Register or repair its deterministic and agentic compaction pipeline.",
  "error_code": "TOOL_RESULT_COMPACTION_REQUIRED",
  "tool": "L1_query"
}

### L1_query
{
  "error": "TOOL_RESULT_COMPACTION_REQUIRED: L1_query returned 38,263 characters after result processing; limit is 24,000. Register or repair its deterministic and agentic compaction pipeline.",
  "error_code": "TOOL_RESULT_COMPACTION_REQUIRED",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 2 tool(s) finished (L1_query, L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[TIME WARNING 1/3] 65% of time budget used (697s / 1000s). Wrap up soon — provide your best answer with available data.

## LLM Response


<reasoning>
I already have all the data I need from the previous L1 queries (L1_query_2 and L1_query_3) stored in working memory. Let me compile the comparison answer from those results.

Ethanol + Water (from L1_query_2):
- 29 data blocks from 22 literature sources
- 2,935 raw data points
- Temperature: 268.1 – 618.2 K
- Pressure: ~100 kPa up to 40,000 kPa
- Composition: x(EtOH) = 0 – 1.0 (full range)
- Density: ~421 – 1006 kg/m³
- Largest single block: 810 points at 298.15 K (GLOBlit_220)

Methanol + Water (from L1_query_3):
- 18 data blocks from 14 literature sources
- 1,610 raw data points
- Temperature: 273 – 619 K
- Composition: x(MeOH) = 0 – 1.0 (full range)
- Density: ~77 – 1012 kg/m³

Both cover the full composition range and similar temperature ranges. But ethanol+water has significantly more data (29 vs 18 blocks, 2935 vs 1610 points), and critically has much more near-ambient data (the 810-point block at 298.15 K). For room-temperature model validation, ethanol+water is clearly superior.
</reasoning>

<answer>
## Recommendation: Ethanol + Water Is the Better Choice for Room-Temperature Liquid-Density Model Validation

Based on the ThermoML database, the **ethanol + water** binary system offers substantially richer coverage for validating a liquid-density model near room temperature, though both systems span comparably broad composition and temperature ranges overall.

---

### Side-by-Side Comparison

| Feature | Ethanol + Water | Methanol + Water |
|---------|----------------|-----------------|
| **Data blocks** | 29 (from 22 literature sources) | 18 (from 14 literature sources) |
| **Total data points** | 2,935 | 1,610 |
| **Temperature range** | 268.1 – 618.2 K | 273 – 619 K |
| **Composition range** | x = 0 – 1.0 (full) | x = 0 – 1.0 (full) |
| **Density range** | ~421 – 1,006 kg/m³ | ~77 – 1,012 kg/m³ |
| **Pressure range** | ~100 – 40,000 kPa | ~10,000 – 40,000 kPa (most blocks at elevated P) |
| **Near-ambient data** | **810 points** at 298.15 K in a single block | Fewer near-ambient blocks; bulk of data at elevated T and P |

---

### Why Ethanol + Water Wins for Room-Temperature Validation

1. **Dense near-ambient coverage.** The single largest data block — 810 points at 298.15 K spanning ethanol mole fractions from 0.003 to 1.0 across pressures from 100 to 40,000 kPa (DOI: 10.1016/j.fluid.2004.11.019, GLOBlit_220) — provides exceptionally dense isothermal composition coverage at room temperature. No comparably large near-ambient block exists for methanol + water.

2. **More total data.** With 2,935 points across 29 blocks vs. 1,610 points across 18 blocks, the ethanol + water system offers nearly twice the data volume, giving more opportunities for cross-validation and consistency checks.

3. **Atmospheric-pressure data.** Many ethanol + water blocks include measurements at atmospheric pressure (~100 kPa), which is the most common condition for room-temperature model benchmarking. The methanol + water blocks are weighted toward high-pressure (10,000–40,000 kPa) and high-temperature (350–619 K) conditions, reflecting near-critical and supercritical studies.

4. **Comparable overall breadth.** Both systems cover the full mole-fraction range (0 to 1) and span from sub-ambient to supercritical-like temperatures (~268–619 K), so neither system is "narrower" in an absolute sense.

---

### Representative Data Blocks (Ethanol + Water, Near Ambient)

| Literature (GLOBlit) | DOI | Block | Points | T (K) | x(EtOH) | ρ (kg/m³) |
|---|---|---|---|---|---|---|
| GLOBlit_220 | 10.1016/j.fluid.2004.11.019 | PROPblock_2 | 810 | 298.15–348.15 | 0.003–1.0 | 739–1,013 |
| GLOBlit_2432 | 10.1016/j.jct.2004.07.019 | PROPblock_2 | 565 | 298.15–573.15 | molality basis | — |
| GLOBlit_1483 | 10.1016/j.fluid.2014.05.032 | PROPblock_1 | 140 | 292.95–448.15 | 0.016–0.073 | 882–1,006 |

### Representative Data Blocks (Methanol + Water, Elevated T/P)

| Literature (GLOBlit) | DOI | Block | Points | T (K) | x(MeOH) | ρ (kg/m³) |
|---|---|---|---|---|---|---|
| GLOBlit_1742 | 10.1016/j.fluid.2015.07.012 | PROPblock_1 | 80 | 350.7–476.2 | 0.1–1.0 | 577–958 |
| GLOBlit_2092 | 10.1016/j.fluid.2017.09.005 | PROPblock_1 | 72 | 523.2–618.2 | 0.0–1.0 | 198–834 |
| GLOBlit_385 | 10.1016/j.fluid.2006.05.007 | PROPblock_1 | 45 | 572.9–588.9 | 0.007–0.880 | 77–712 |

---

### Chemistry Context

Both ethanol and methanol are fully miscible with water and form strongly non-ideal mixtures due to hydrogen bonding. The excess molar volume (and hence density deviation from ideal mixing) is negative for both systems, reflecting the compact packing that arises when alcohol –OH groups participate in the water hydrogen-bond network. The ethanol + water system tends to show a larger magnitude of excess volume (more pronounced density maximum near x ≈ 0.05–0.10 ethanol), making it a more stringent test of mixing-rule accuracy in equation-of-state or activity-coefficient models.

**Bottom line:** For room-temperature liquid-density model validation, choose **ethanol + water** — it has nearly twice the data, far more near-ambient measurements, and atmospheric-pressure coverage across the full composition range. Use methanol + water as a complementary test set, especially if your model also needs validation at elevated temperatures and pressures.
</answer>
# Reference Stats — query-agent

**Run started:** 2026-08-02 18:52:38
**Wall time (at last flush):** 758.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 110,196 | 27,144 | 151,891 | 18,986 | 139.1 | claudeopus46 |
| L1-worker | 55 | 431,757 | 409,156 | 124,981 | 840,913 | 15,289 | 662.2 | claudeopus46 |
| **TOTAL** | **63** | **473,452** | **519,352** | **152,125** | **992,804** | **15,758** | **801.3** | |

**Estimated tokens:** ~248,201 input + ~38,031 output = ~286,232 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 2 | 1 | 0 | 0 | 17 | 18 | 1,610 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 6 | 5 | 27 | 29 | 2,895 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 7 | 3 | 17 | 18 | 1,610 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **15** | **3** | **16** | **8** | **61** | **65** | **6,115** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_summary |
| GLOBcomp_4 |  | resolve_compound_ids, search_blocks, search_system_summary |
| GLOBcomp_5494 |  | resolve_compound_ids |
| GLOBcomp_6173 |  | resolve_compound_ids |

#### Variables (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids, search_blocks |
| GLOBvar_2 |  | resolve_ids, search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |
| GLOBvar_4 | Molality, mol/kg | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_15 | Mass ratio of solute to solvent | search_blocks |
| GLOBvar_18 | Volume fraction | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | search_blocks, search_system_summary |

#### References (36 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2432 |  | search_blocks, search_system_summary |
| GLOBlit_8254 |  | search_blocks, search_system_summary |
| GLOBlit_8424 |  | search_blocks, search_system_summary |
| GLOBlit_10866 |  | search_blocks, search_system_summary |
| GLOBlit_1742 |  | search_blocks, search_system_summary |
| GLOBlit_2092 |  | search_blocks, search_system_summary |
| GLOBlit_385 |  | search_blocks, search_system_summary |
| GLOBlit_2825 |  | search_blocks, search_system_summary |
| GLOBlit_895 |  | search_blocks, search_system_summary |
| GLOBlit_9571 |  | search_blocks, search_system_summary |
| GLOBlit_5533 |  | search_blocks, search_system_summary |
| GLOBlit_7085 |  | search_blocks, search_system_summary |
| GLOBlit_8888 |  | search_blocks, search_system_summary |
| GLOBlit_462 |  | search_blocks, search_system_summary |
| GLOBlit_8869 |  | search_blocks, search_system_summary |
| GLOBlit_8155 |  | search_blocks, search_system_summary |
| GLOBlit_7629 |  | search_blocks, search_system_summary |
| GLOBlit_220 |  | search_blocks |
| GLOBlit_1483 |  | search_blocks |
| GLOBlit_2732 |  | search_blocks |
| GLOBlit_3475 |  | search_blocks |
| GLOBlit_4415 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_5473 |  | search_blocks |
| GLOBlit_7178 |  | search_blocks |
| GLOBlit_7448 |  | search_blocks |
| GLOBlit_7676 |  | search_blocks |
| GLOBlit_8050 |  | search_blocks |
| GLOBlit_9006 |  | search_blocks |
| GLOBlit_10159 |  | search_blocks |
| GLOBlit_10699 |  | search_blocks |
| GLOBlit_11005 |  | search_blocks |
| GLOBlit_11136 |  | search_blocks |
| GLOBlit_11459 |  | search_blocks |
| GLOBlit_11504 |  | search_blocks |
| GLOBlit_11792 |  | search_blocks |

#### Measurements (14 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_66 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_1497 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_236 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_203 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_212 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_153 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_1494 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_170 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_280 | Mass density, kg/m3 | search_blocks |

#### Phases (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |
| GLOBphase_3 |  | search_blocks |
| GLOBphase_10 |  | search_blocks |

#### Solvents (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |
| GLOBsolvent_2 |  | search_blocks |
| GLOBsolvent_3 |  | search_blocks |

#### Constraints (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_3 | Mole fraction | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_8 | Molality, mol/kg | search_blocks |
| GLOBconstr_22 | Volume fraction | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 5 |
| Unique Variables | 7 |
| Unique Properties | 1 |
| Unique References | 36 |
| Unique Measurements | 14 |
| Unique Phases | 3 |
| Unique Solvents | 3 |
| Unique Constraints | 5 |
| Total DOIs | 36 |
| Unique parent blocks | 47 |
| Explicit block/subsystem targets | 47 |
| Subsystem targets | 0 |
| Target-matched data points | 4,505 |

---

## 3. DOI & Block References

**Unique DOIs:** 36  |  **Parent blocks:** 47  |  **Explicit targets:** 47  |  **Subsystems:** 0  |  **Target-matched datapoints:** 4,505

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | search_blocks |
| 10.1016/j.fluid.2006.05.007 | 1 | 45 | binary | search_blocks |
| 10.1016/j.fluid.2006.12.005 | 2 | 10 | binary | search_blocks |
| 10.1016/j.fluid.2010.10.005 | 1 | 34 | binary | search_blocks |
| 10.1016/j.fluid.2014.05.032 | 1 | 140 | binary | search_blocks |
| 10.1016/j.fluid.2015.07.012 | 2 | 164 | binary | search_blocks |
| 10.1016/j.fluid.2017.09.005 | 2 | 144 | binary | search_blocks |
| 10.1016/j.jct.2004.07.019 | 2 | 1,161 | binary | search_blocks |
| 10.1016/j.jct.2006.08.002 | 3 | 301 | binary | search_blocks |
| 10.1016/j.jct.2007.05.004 | 2 | 76 | binary | search_blocks |
| 10.1016/j.jct.2011.10.009 | 1 | 70 | binary | search_blocks |
| 10.1016/j.jct.2015.06.024 | 1 | 40 | binary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 244 | binary | search_blocks |
| 10.1016/j.jct.2019.02.027 | 1 | 9 | binary | search_blocks |
| 10.1016/j.jct.2019.05.013 | 1 | 12 | binary | search_blocks |
| 10.1021/acs.jced.6b01058 | 2 | 24 | binary | search_blocks |
| 10.1021/acs.jced.7b00299 | 1 | 2 | binary | search_blocks |
| 10.1021/acs.jced.8b00086 | 1 | 6 | binary | search_blocks |
| 10.1021/acs.jced.8b00723 | 2 | 6 | binary | search_blocks |
| 10.1021/acs.jced.8b00939 | 1 | 9 | binary | search_blocks |
| 10.1021/je020173z | 1 | 24 | binary | search_blocks |
| 10.1021/je0301500 | 1 | 5 | binary | search_blocks |
| 10.1021/je034101z | 1 | 401 | binary | search_blocks |
| 10.1021/je049691v | 1 | 180 | binary | search_blocks |
| 10.1021/je0600810 | 1 | 9 | binary | search_blocks |
| 10.1021/je0601098 | 2 | 24 | binary | search_blocks |
| 10.1021/je060335h | 1 | 164 | binary | search_blocks |
| 10.1021/je2003622 | 1 | 16 | binary | search_blocks |
| 10.1021/je4003515 | 1 | 23 | binary | search_blocks |
| 10.1021/je600565m | 1 | 18 | binary | search_blocks |
| 10.1021/je700300y | 2 | 168 | binary | search_blocks |
| 10.1021/je700618y | 1 | 15 | binary | search_blocks |
| 10.1021/je800150h | 1 | 108 | binary | search_blocks |
| 10.1021/je800942u | 1 | 18 | binary | search_blocks |
| 10.1021/je900064e | 1 | 10 | binary | search_blocks |
| 10.1021/je900743e | 1 | 15 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.05.007 | PROPblock_1 | declared | 45 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.12.005 | PROPblock_3 | declared | 8 | binary | — | search_blocks |
| 10.1016/j.fluid.2006.12.005 | PROPblock_4 | declared | 2 | binary | — | search_blocks |
| 10.1016/j.fluid.2010.10.005 | PROPblock_1 | declared | 34 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.07.012 | PROPblock_1 | declared | 80 | binary | — | search_blocks |
| 10.1016/j.fluid.2015.07.012 | PROPblock_3 | declared | 84 | binary | — | search_blocks |
| 10.1016/j.fluid.2017.09.005 | PROPblock_1 | declared | 72 | binary | — | search_blocks |
| 10.1016/j.fluid.2017.09.005 | PROPblock_3 | declared | 72 | binary | — | search_blocks |
| 10.1016/j.jct.2004.07.019 | PROPblock_1 | declared | 596 | binary | — | search_blocks |
| 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | — | search_blocks |
| 10.1016/j.jct.2006.08.002 | PROPblock_2 | declared | 19 | binary | — | search_blocks |
| 10.1016/j.jct.2006.08.002 | PROPblock_3 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2006.08.002 | PROPblock_4 | declared | 278 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.004 | PROPblock_10 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.004 | PROPblock_12 | declared | 37 | binary | — | search_blocks |
| 10.1016/j.jct.2011.10.009 | PROPblock_3 | declared | 70 | binary | — | search_blocks |
| 10.1016/j.jct.2015.06.024 | PROPblock_7 | declared | 40 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | — | search_blocks |
| 10.1016/j.jct.2019.02.027 | PROPblock_21 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.jct.2019.05.013 | PROPblock_2 | declared | 12 | binary | — | search_blocks |
| 10.1021/acs.jced.6b01058 | PROPblock_6 | declared | 12 | binary | — | search_blocks |
| 10.1021/acs.jced.6b01058 | PROPblock_7 | declared | 12 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00299 | PROPblock_10 | declared | 2 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00086 | PROPblock_46 | declared | 6 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00723 | PROPblock_10 | declared | 3 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00723 | PROPblock_12 | declared | 3 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00939 | PROPblock_17 | declared | 9 | binary | — | search_blocks |
| 10.1021/je020173z | PROPblock_5 | declared | 24 | binary | — | search_blocks |
| 10.1021/je0301500 | PROPblock_13 | declared | 5 | binary | — | search_blocks |
| 10.1021/je034101z | PROPblock_4 | declared | 401 | binary | — | search_blocks |
| 10.1021/je049691v | PROPblock_3 | declared | 180 | binary | — | search_blocks |
| 10.1021/je0600810 | PROPblock_4 | declared | 9 | binary | — | search_blocks |
| 10.1021/je0601098 | PROPblock_18 | declared | 12 | binary | — | search_blocks |
| 10.1021/je0601098 | PROPblock_20 | declared | 12 | binary | — | search_blocks |
| 10.1021/je060335h | PROPblock_1 | declared | 164 | binary | — | search_blocks |
| 10.1021/je2003622 | PROPblock_2 | declared | 16 | binary | — | search_blocks |
| 10.1021/je4003515 | PROPblock_7 | declared | 23 | binary | — | search_blocks |
| 10.1021/je600565m | PROPblock_6 | declared | 18 | binary | — | search_blocks |
| 10.1021/je700300y | PROPblock_6 | declared | 84 | binary | — | search_blocks |
| 10.1021/je700300y | PROPblock_7 | declared | 84 | binary | — | search_blocks |
| 10.1021/je700618y | PROPblock_9 | declared | 15 | binary | — | search_blocks |
| 10.1021/je800150h | PROPblock_9 | declared | 108 | binary | — | search_blocks |
| 10.1021/je800942u | PROPblock_6 | declared | 18 | binary | — | search_blocks |
| 10.1021/je900064e | PROPblock_6 | declared | 10 | binary | — | search_blocks |
| 10.1021/je900743e | PROPblock_3 | declared | 15 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve ethanol and… | 234 | KEEP | 234 | 6.1 |
| 2 | 4 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 287 | KEEP | 287 | 3.7 |
| 3 | 1 | `L1_query` | context=User is comparing ethanol+wat…, id_catalog… | 380 | — | — | 281.3 |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve methanol an… | 328 | KEEP | 328 | 3.9 |
| 5 | 4 | `search_system_summary` | compound=['GLOBcomp_4', 'GLOBcomp_1'], property=GL… | 888 | KEEP | 888 | 16.0 |
| 6 | 4 | `resolve_ids` | entity_type=variable, limit=5, min_score=80, purpo… | 326 | KEEP | 326 | 4.0 |
| 7 | 1 | `L1_query` | context=User is comparing ethanol+wat…, id_catalog… | 353 | — | — | 179.2 |
| 8 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve GLOBcomp_N … | 307 | KEEP | 307 | 6.3 |
| 9 | 2 | `L1_query` | instruction=Resolve the strict global com…, purpos… | 1,580 | — | — | 32.5 |
| 10 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_2'], limit=50, p… | 1,112 | KEEP | 1097 | 15.9 |
| 11 | 3 | `L1_query` | context=User wants to compare ethanol…, id_catalog… | 270 | — | — | 69.0 |
| 12 | 1 | `search_blocks` | compound=['GLOBcomp_4', 'GLOBcomp_1'], limit=50, p… | 1,081 | KEEP | 1081 | 14.4 |
| 13 | 3 | `L1_query` | context=User wants to compare ethanol…, id_catalog… | 270 | — | — | 66.4 |
| | | **TOTAL (13 tools)** | | **7,416** | | **4,548** | **698.7** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 656 | 10,261 | 2,303 | 10.6 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,191 | 21,834 | 812 | 9.1 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,624 | 23,267 | 14,393 | 52.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 6.0 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,816 | 23,459 | 14,345 | 54.0 |
| 6 | L1-worker | claudeopus46 | 20,643 | 17,782 | 38,425 | 8,786 | 53.4 |
| 7 | L1-worker | claudeopus46 | 2,065 | 473 | 2,538 | 469 | 3.6 |
| 8 | L1-worker | claudeopus46 | 20,643 | 18,117 | 38,760 | 9,924 | 53.4 |
| 9 | L1-worker | claudeopus46 | 20,643 | 28,662 | 49,305 | 2,651 | 11.8 |
| 10 | L1-worker | claudeopus46 | 536 | 2,662 | 3,198 | 935 | 5.2 |
| 11 | L1-worker | claudeopus46 | 1,356 | 2,782 | 4,138 | 941 | 5.6 |
| 12 | L1-worker | claudeopus46 | 298 | 1,323 | 1,621 | 929 | 3.4 |
| 13 | L1-worker | claudeopus46 | 1,323 | 5,875 | 7,198 | 2,438 | 11.3 |
| 14 | L1-worker | claudeopus46 | 298 | 3,160 | 3,458 | 1,782 | 7.5 |
| 15 | L1-worker | claudeopus46 | 1,160 | 8,846 | 10,006 | 2,224 | 9.5 |
| 16 | L1-worker | claudeopus46 | 298 | 2,946 | 3,244 | 1,769 | 7.8 |
| 17 | L1-worker | claudeopus46 | 20,643 | 1,194 | 21,837 | 761 | 5.6 |
| 18 | L1-worker | claudeopus46 | 20,643 | 2,576 | 23,219 | 824 | 4.9 |
| 19 | L1-worker | claudeopus46 | 2,065 | 438 | 2,503 | 505 | 3.8 |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,794 | 23,437 | 3,921 | 23.8 |
| 21 | L1-worker | claudeopus46 | 20,643 | 7,443 | 28,086 | 913 | 4.6 |
| 22 | L1-worker | claudeopus46 | 2,065 | 1,236 | 3,301 | 1,256 | 8.3 |
| 23 | L1-worker | claudeopus46 | 2,065 | 390 | 2,455 | 455 | 3.8 |
| 24 | L1-worker | claudeopus46 | 20,643 | 8,674 | 29,317 | 13,590 | 75.1 |
| 25 | L1-worker | claudeopus46 | 20,643 | 22,885 | 43,528 | 3,321 | 17.0 |
| 26 | L1-worker | claudeopus46 | 1,356 | 2,938 | 4,294 | 892 | 5.0 |
| 27 | L1-worker | claudeopus46 | 536 | 2,818 | 3,354 | 1,092 | 6.0 |
| 28 | L1-worker | claudeopus46 | 1,323 | 7,680 | 9,003 | 2,247 | 9.7 |
| 29 | L1-worker | claudeopus46 | 298 | 2,969 | 3,267 | 1,617 | 6.6 |
| 30 | L1-worker | claudeopus46 | 1,160 | 10,463 | 11,623 | 1,614 | 6.6 |
| 31 | L0-main | claudeopus46 | 9,605 | 2,075 | 11,680 | 9,559 | 45.0 |
| 32 | L1-worker | claudeopus46 | 20,643 | 801 | 21,444 | 602 | 5.4 |
| 33 | L1-worker | claudeopus46 | 20,643 | 2,024 | 22,667 | 1,069 | 5.7 |
| 34 | L1-worker | claudeopus46 | 2,065 | 670 | 2,735 | 640 | 4.7 |
| 35 | L1-worker | claudeopus46 | 20,643 | 2,225 | 22,868 | 460 | 4.7 |
| 36 | L1-worker | claudeopus46 | 1,356 | 589 | 1,945 | 184 | 2.9 |
| 37 | L1-worker | claudeopus46 | 1,323 | 2,317 | 3,640 | 304 | 3.0 |
| 38 | L1-worker | claudeopus46 | 536 | 469 | 1,005 | 423 | 3.0 |
| 39 | L1-worker | claudeopus46 | 298 | 1,026 | 1,324 | 198 | 2.4 |
| 40 | L1-worker | claudeopus46 | 747 | 3,006 | 3,753 | 458 | 4.1 |
| 41 | L0-main | claudeopus46 | 9,605 | 5,951 | 15,556 | 2,408 | 12.1 |
| 42 | L1-worker | claudeopus46 | 20,643 | 3,165 | 23,808 | 1,068 | 6.9 |
| 43 | L1-worker | claudeopus46 | 2,065 | 19,056 | 21,121 | 1,565 | 14.4 |
| 44 | L1-worker | claudeopus46 | 20,643 | 4,796 | 25,439 | 2,955 | 17.4 |
| 45 | L1-worker | claudeopus46 | 536 | 2,104 | 2,640 | 845 | 4.2 |
| 46 | L1-worker | claudeopus46 | 1,356 | 2,224 | 3,580 | 838 | 4.3 |
| 47 | L1-worker | claudeopus46 | 1,323 | 5,263 | 6,586 | 2,163 | 9.5 |
| 48 | L1-worker | claudeopus46 | 298 | 2,885 | 3,183 | 1,640 | 7.9 |
| 49 | L1-worker | claudeopus46 | 747 | 37,763 | 38,510 | 1,024 | 10.0 |
| 50 | L1-worker | claudeopus46 | 20,643 | 37,286 | 57,929 | 842 | 6.0 |
| 51 | L1-worker | claudeopus46 | 2,065 | 12,011 | 14,076 | 1,466 | 13.2 |
| 52 | L1-worker | claudeopus46 | 20,643 | 38,878 | 59,521 | 2,930 | 17.6 |
| 53 | L1-worker | claudeopus46 | 1,356 | 2,441 | 3,797 | 882 | 4.3 |
| 54 | L1-worker | claudeopus46 | 536 | 2,321 | 2,857 | 857 | 5.1 |
| 55 | L1-worker | claudeopus46 | 298 | 1,213 | 1,511 | 844 | 3.3 |
| 56 | L1-worker | claudeopus46 | 1,323 | 5,362 | 6,685 | 2,211 | 9.9 |
| 57 | L1-worker | claudeopus46 | 298 | 2,933 | 3,231 | 1,829 | 8.7 |
| 58 | L1-worker | claudeopus46 | 747 | 42,134 | 42,881 | 866 | 8.6 |
| 59 | L0-main | claudeopus46 | 9,605 | 79,820 | 89,425 | 5,324 | 34.5 |
| 60 | L0-main | claudeopus46 | 1,356 | 4,424 | 5,780 | 1,212 | 6.5 |
| 61 | L0-main | claudeopus46 | 298 | 1,594 | 1,892 | 1,200 | 3.7 |
| 62 | L0-main | claudeopus46 | 1,323 | 12,260 | 13,583 | 2,748 | 16.1 |
| 63 | L0-main | claudeopus46 | 298 | 3,416 | 3,714 | 2,390 | 10.6 |


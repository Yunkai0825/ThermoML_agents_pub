# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_2 | ethanol | ethanol |
| comp | GLOBcomp_1 | water | water |
| prop | GLOBprop_4 | viscosity_pa_s | Viscosity, Pa*s |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find viscosity (dynamic) data for ethanol + water mixtures at 2000 K → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "No dynamic viscosity data exists for ethanol + water binary mixtures at 2000 K in the ThermoML database.\n\nThe database contains viscosity (Pa·s) data for the ethanol (GLOBcomp_2) + water (GLOBcomp_1) binary system, but the available temperature range is **268.1 K to 618.2 K** — far below the requested 2000 K. The maximum recorded temperature (618.2 K) is approximately 1382 K below the target.\n\nThis is physically expected: ethanol boils at ~351 K and water at ~373 K at atmospheric pressure. Even under the high pressures present in the dataset (10,000–40,000 kPa, i.e., ~100–400 atm), which elevate boiling points significantly, the system does not approach 2000 K. At 2000 K, both components would be well into the gas phase or decomposed, making conventional liquid viscosity measurements infeasible.\n\n**Available data summary:**\n- **Temperature range:** 268.1 – 618.2 K\n- **Pressure range:** 10,000 – 40,000 kPa\n- **Total data points:** 534 across 14 publications\n- **Representative source:** DOI 10.1021/je800150h (GLOBlit_11136, 108 data points)\n\nIn short, 2000 K viscosity data for ethanol + water does not exist in ThermoML, and such measurements would be extraordinary given the thermal stability limits of these compounds.",
  "core_claims": [
    "No dynamic viscosity data for ethanol + water binary mixtures at 2000 K exists in the ThermoML database; the available viscosity data span a temperature range of 268.1–618.2 K at pressures of 10,000–40,000 kPa, totaling 534 data points across 14 publications.",
    "At 2000 K, both ethanol and water would be in the gas phase or thermally decomposed, making conventional liquid viscosity measurements infeasible even under elevated pressures, so the absence of such data is physically expected."
  ],
  "status": "no_results",
  "summary": "No dynamic viscosity data exists for ethanol + water binary mixtures at 2000 K in the ThermoML database. The available viscosity data for this system spans 268.1–618.2 K at pressures of 10,000–40,000 kPa, totaling 534 data points across 14 publications. The requested 2000 K is approximately 1382 K above the maximum recorded temperature. At 2000 K both components would be in the gas phase or decomposed, making conventional liquid viscosity measurements infeasible even under high pressure. A representative source is DOI 10.1021/je800150h (108 data points).",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_4",
      "registry_id": "viscosity_pa_s",
      "name": "Viscosity, Pa*s"
    }
  ],
  "core_blocks_found": []
}


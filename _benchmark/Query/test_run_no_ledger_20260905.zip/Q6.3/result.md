# Q6.3 — Result

**Prompt:** What is the viscosity of ethanol + water mixtures at 2000 K?

**Tool calls:** 1  |  **Time:** 161.5s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

**No data found in the ThermoML database for the viscosity of ethanol + water mixtures at 2000 K.**

The ThermoML database does contain dynamic viscosity data for the ethanol + water binary system, but the available temperature range is **268.1 K to 618.2 K** — far below the requested 2000 K. The highest recorded temperature in the dataset (618.2 K) was measured under elevated pressures of 10,000–40,000 kPa (~100–400 atm). Even under those conditions, the system is roughly 1,382 K below the target temperature.

**Why this data doesn't (and likely can't) exist:**

- Ethanol boils at ~351 K and water at ~373 K at atmospheric pressure. At 2000 K, both components would be deep into the gas phase or thermally decomposed — ethanol undergoes pyrolysis well below 1000 K.
- Conventional liquid-phase viscosity measurements are therefore infeasible at 2000 K for this system, even under very high pressures.

**What is available:**

| Parameter | Range |
|-----------|-------|
| Temperature | 268.1 – 618.2 K |
| Pressure | 10,000 – 40,000 kPa |
| Total data points | 534 |
| Number of publications | 14 |
| Representative source | DOI 10.1021/je800150h (GLOBlit_11136), 108 data points |

If you are interested in the viscosity of ethanol + water mixtures within the available temperature range (roughly 268–618 K), I'd be happy to help retrieve specific values.

### Core claims

- The ThermoML database contains no viscosity data for ethanol + water mixtures at 2000 K; the available dynamic viscosity data for this binary system span only 268.1–618.2 K (with pressures of 10,000–40,000 kPa), comprising 534 data points across 14 publications.
- At 2000 K, both ethanol and water would be in the gas phase or thermally decomposed (ethanol undergoes pyrolysis well below 1000 K), making conventional liquid-phase viscosity measurements infeasible for this system at that temperature, even under very high pressures.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11136 | 10.1021/je800150h |  |  | Representative source for ethanol + water dynamic viscosity data (108 data points); temperature range 268.1–618.2 K, pressures 10,000–40,000 kPa. No data at 2000 K. |

### Suggested follow-ups

- Retrieve viscosity data for ethanol + water mixtures within the available temperature range (268–618 K) at specific compositions or pressures.
- Query gas-phase viscosity or transport property databases (e.g., NIST) for ethanol and water vapor at high temperatures closer to 2000 K.
- Investigate ethanol pyrolysis/decomposition kinetics to understand why liquid-phase measurements are infeasible above ~700 K.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "ethanol",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  }
]
```

# Reference Stats — query-agent

**Run started:** 2026-08-02 19:48:08
**Wall time (at last flush):** 161.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 16,574 | 7,560 | 38,761 | 7,752 | 41.3 | claudeopus46 |
| L1-worker | 13 | 113,637 | 35,912 | 23,617 | 149,549 | 11,503 | 129.2 | claudeopus46 |
| **TOTAL** | **18** | **135,824** | **52,486** | **31,177** | **188,310** | **10,461** | **170.5** | |

**Estimated tokens:** ~47,077 input + ~7,794 output = ~54,871 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 2 | 1 | 0 | 0 | 14 | 14 | 534 |
| **TOTAL** | **4** | **2** | **0** | **0** | **14** | **14** | **534** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_system_summary |
| GLOBcomp_1 |  | resolve_compound_ids, search_system_summary |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_system_summary |

#### References (14 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_11136 |  | search_system_summary |
| GLOBlit_5201 |  | search_system_summary |
| GLOBlit_1742 |  | search_system_summary |
| GLOBlit_2092 |  | search_system_summary |
| GLOBlit_2825 |  | search_system_summary |
| GLOBlit_8949 |  | search_system_summary |
| GLOBlit_10159 |  | search_system_summary |
| GLOBlit_11459 |  | search_system_summary |
| GLOBlit_10699 |  | search_system_summary |
| GLOBlit_11005 |  | search_system_summary |
| GLOBlit_11792 |  | search_system_summary |
| GLOBlit_7676 |  | search_system_summary |
| GLOBlit_7448 |  | search_system_summary |
| GLOBlit_7178 |  | search_system_summary |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique References | 14 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve ethanol and… | 234 | KEEP | 234 | 3.9 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=80, purpose=Confirm GLOBprop_4 … | 288 | KEEP | 288 | 4.2 |
| 3 | 3 | `search_system_summary` | compound=['GLOBcomp_2', 'GLOBcomp_1'], property=GL… | 846 | KEEP | 846 | 8.8 |
| 4 | 1 | `L1_query` | context=User asks for viscosity of et…, id_catalog… | 2,880 | — | — | 123.7 |
| | | **TOTAL (4 tools)** | | **4,248** | | **1,368** | **140.6** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,282 | 4,282 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 523 | 10,128 | 2,994 | 17.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 987 | 21,630 | 1,175 | 8.1 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,890 | 23,533 | 13,456 | 52.5 |
| 4 | L1-worker | claudeopus46 | 2,065 | 437 | 2,502 | 412 | 3.7 |
| 5 | L1-worker | claudeopus46 | 2,065 | 356 | 2,421 | 466 | 4.0 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,416 | 24,059 | 2,862 | 17.2 |
| 7 | L1-worker | claudeopus46 | 2,065 | 1,297 | 3,362 | 1,213 | 8.4 |
| 8 | L1-worker | claudeopus46 | 20,610 | 5,577 | 26,187 | 506 | 4.4 |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,824 | 25,467 | 1,254 | 11.7 |
| 10 | L1-worker | claudeopus46 | 1,323 | 5,323 | 6,646 | 307 | 3.1 |
| 11 | L1-worker | claudeopus46 | 1,356 | 1,385 | 2,741 | 510 | 3.6 |
| 12 | L1-worker | claudeopus46 | 536 | 1,265 | 1,801 | 574 | 3.9 |
| 13 | L1-worker | claudeopus46 | 298 | 1,029 | 1,327 | 201 | 3.1 |
| 14 | L1-worker | claudeopus46 | 747 | 7,126 | 7,873 | 681 | 5.5 |
| 15 | L0-main | claudeopus46 | 9,605 | 7,058 | 16,663 | 1,568 | 8.6 |
| 16 | L0-main | claudeopus46 | 1,356 | 1,514 | 2,870 | 553 | 3.8 |
| 17 | L0-main | claudeopus46 | 1,323 | 5,607 | 6,930 | 1,204 | 6.7 |
| 18 | L0-main | claudeopus46 | 298 | 1,872 | 2,170 | 1,241 | 4.7 |


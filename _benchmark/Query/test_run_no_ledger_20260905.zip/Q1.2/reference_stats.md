# Reference Stats — query-agent

**Run started:** 2026-08-02 18:38:45
**Wall time (at last flush):** 370.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 22,485 | 65,019 | 11,596 | 87,504 | 14,584 | 70.9 | claudeopus46 |
| L1-worker | 16 | 155,221 | 128,005 | 67,172 | 283,226 | 17,701 | 324.8 | claudeopus46 |
| **TOTAL** | **22** | **177,706** | **193,024** | **78,768** | **370,730** | **16,851** | **395.7** | |

**Estimated tokens:** ~92,682 input + ~19,692 output = ~112,374 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 8 | 2 | 2 | 5 | 9 | 449 |
| `search_system_registry` | 2 | 5 | 2 | 1 | 3 | 6 | 400 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **6** | **13** | **4** | **3** | **8** | **15** | **849** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_12 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks, search_system_registry |

#### References (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_294 |  | search_blocks |
| GLOBlit_2800 |  | search_blocks, search_system_registry |
| GLOBlit_8445 |  | search_blocks |
| GLOBlit_10821 |  | search_blocks, search_system_registry |
| GLOBlit_11449 |  | search_blocks, search_system_registry |

#### Properties (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBprop_28 | Excess molar volume, m3/mol | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_29 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |

#### Measurements (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_29 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_38 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBmeas_342 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_284 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks, search_system_registry |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 5 |
| Unique Properties | 8 |
| Unique Measurements | 9 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 2 |
| Unique Block_Types | 1 |
| Total DOIs | 5 |
| Unique parent blocks | 9 |
| Explicit block/subsystem targets | 9 |
| Subsystem targets | 0 |
| Target-matched data points | 849 |

---

## 3. DOI & Block References

**Unique DOIs:** 5  |  **Parent blocks:** 9  |  **Explicit targets:** 9  |  **Subsystems:** 0  |  **Target-matched datapoints:** 449

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2005.08.001 | 2 | 40 | binary | search_blocks |
| 10.1016/j.jct.2007.02.008 | 3 | 117 | binary | search_blocks, search_system_registry |
| 10.1021/je0497303 | 1 | 9 | binary | search_blocks |
| 10.1021/je700215z | 1 | 77 | binary | search_blocks, search_system_registry |
| 10.1021/je800925v | 2 | 206 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | declared | 23 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | declared | 39 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | declared | 39 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | declared | 39 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0497303 | PROPblock_8 | declared | 9 | binary | — | search_blocks |
| 10.1021/je700215z | PROPblock_5 | declared | 77 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je800925v | PROPblock_10 | declared | 103 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je800925v | PROPblock_9 | declared | 103 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve hexane and … | 242 | KEEP | 242 | 3.8 |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,254 | KEEP | 1166 | 19.7 |
| 3 | 4 | `search_system_registry` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,097 | KEEP | 971 | 12.3 |
| 4 | 1 | `L1_query` | context=User wants a comprehensive li…, id_catalog… | 270 | — | — | 318.7 |
| | | **TOTAL (4 tools)** | | **2,863** | | **2,379** | **354.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,724 | 3,724 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 578 | 10,183 | 1,331 | 8.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,168 | 21,811 | 546 | 4.6 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,335 | 22,978 | 13,832 | 50.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 465 | 2,530 | 441 | 3.7 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,507 | 23,150 | 12,587 | 48.9 |
| 6 | L1-worker | claudeopus46 | 2,065 | 6,224 | 8,289 | 1,623 | 12.0 |
| 7 | L1-worker | claudeopus46 | 20,610 | 5,019 | 25,629 | 404 | 3.6 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,266 | 24,909 | 13,104 | 70.0 |
| 9 | L1-worker | claudeopus46 | 2,065 | 5,223 | 7,288 | 1,551 | 11.2 |
| 10 | L1-worker | claudeopus46 | 20,643 | 6,139 | 26,782 | 9,270 | 53.3 |
| 11 | L1-worker | claudeopus46 | 20,643 | 16,158 | 36,801 | 2,952 | 12.6 |
| 12 | L1-worker | claudeopus46 | 536 | 2,963 | 3,499 | 895 | 6.1 |
| 13 | L1-worker | claudeopus46 | 1,356 | 3,083 | 4,439 | 1,179 | 6.3 |
| 14 | L1-worker | claudeopus46 | 298 | 1,561 | 1,859 | 1,167 | 4.3 |
| 15 | L1-worker | claudeopus46 | 1,323 | 8,642 | 9,965 | 3,700 | 16.0 |
| 16 | L1-worker | claudeopus46 | 298 | 4,422 | 4,720 | 2,825 | 11.5 |
| 17 | L1-worker | claudeopus46 | 747 | 57,830 | 58,577 | 1,096 | 10.1 |
| 18 | L0-main | claudeopus46 | 9,605 | 51,977 | 61,582 | 3,404 | 23.2 |
| 19 | L0-main | claudeopus46 | 1,323 | 4,742 | 6,065 | 2,345 | 12.8 |
| 20 | L0-main | claudeopus46 | 1,356 | 3,120 | 4,476 | 1,207 | 15.3 |
| 21 | L0-main | claudeopus46 | 298 | 1,589 | 1,887 | 1,195 | 4.2 |
| 22 | L0-main | claudeopus46 | 298 | 3,013 | 3,311 | 2,114 | 7.1 |


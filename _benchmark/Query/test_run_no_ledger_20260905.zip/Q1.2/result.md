# Q1.2 — Result

**Prompt:** For an equimolar liquid mixture of hexane + ethanol near 25 °C, which thermophysical properties have been measured?

**Tool calls:** 1  |  **Time:** 370.6s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

## Thermophysical Properties Measured for an Equimolar Liquid Mixture of Hexane + Ethanol near 25 °C

The ThermoML database contains **8 distinct thermophysical properties** measured for the binary system hexane (C₆H₁₄) + ethanol (C₂H₆O), reported across **5 literature sources**. Here is a complete summary, with representative values at or near equimolar composition (x_ethanol ≈ 0.5) and T ≈ 298.15 K where available:

### Properties with Representative Values at x ≈ 0.5, T = 298.15 K

| # | Property | Value | Unit | Block | Source (DOI) |
|---|----------|-------|------|-------|--------------|
| 1 | **Mass density** | 705.7 | kg/m³ | PROPblock_24 | 10.1016/j.jct.2007.02.008 (GLOBlit_2800) |
| 2 | **Refractive index** (Na D-line) | 1.3598 | — | PROPblock_22 | 10.1016/j.jct.2007.02.008 (GLOBlit_2800) |
| 3 | **Speed of sound** | 1082.3 | m/s | PROPblock_23 | 10.1016/j.jct.2007.02.008 (GLOBlit_2800) |
| 4 | **Excess molar enthalpy** (Hᴱ) | 1244 | J/mol | PROPblock_5 | 10.1016/j.fluid.2005.08.001 (GLOBlit_294) |
| 5 | **Excess molar volume** (Vᴱ) | 0.55–0.59 | cm³/mol | PROPblock_6 | 10.1016/j.fluid.2005.08.001 (GLOBlit_294) |
| 6 | **Binary diffusion coefficient** | 1.81 × 10⁻⁹ | m²/s | PROPblock_8 | 10.1021/je0497303 (GLOBlit_8445) |

### Additional Properties Available (data across the composition range, not limited to x = 0.5)

| # | Property | Data Points | T Range | Source (DOI) |
|---|----------|-------------|---------|--------------|
| 7 | **Dynamic viscosity** | 103 | 273–298 K | 10.1021/je800925v (GLOBlit_11449) |
| 8 | **Surface tension** (liquid–gas) | 77 | 283–313 K | 10.1021/je700215z (GLOBlit_10821) |

### Chemistry Insight

Hexane + ethanol is a classic **strongly non-ideal** binary system. The non-polar hexane disrupts ethanol's hydrogen-bonding network upon mixing, which is clearly reflected in the measured data:

- **Large positive Hᴱ** (~1244 J/mol at x = 0.5): The endothermic mixing indicates that breaking ethanol–ethanol hydrogen bonds costs more energy than is recovered from the weak hexane–ethanol van der Waals interactions.
- **Positive Vᴱ** (~0.55–0.59 cm³/mol): Volume expansion on mixing is consistent with the disrupted molecular packing when hydrogen-bonded ethanol clusters are broken apart.
- **Mass density** (705.7 kg/m³) lies between pure ethanol (~789 kg/m³) and pure hexane (~655 kg/m³), shifted slightly below the linear average due to the positive excess volume.
- **Speed of sound** (1082.3 m/s) and **refractive index** (1.3598) provide complementary information about the mixture's compressibility and polarizability.
- **Binary diffusion coefficient** (1.81 × 10⁻⁹ m²/s) characterizes molecular transport in this moderately viscous liquid mixture.

All data span temperatures of approximately 273–313 K and cover the full composition range (x_ethanol from 0 to 1), making this one of the better-characterized binary systems in ThermoML for thermodynamic modeling and equation-of-state validation.

### Core claims

- The ThermoML database reports 8 distinct thermophysical properties for the binary hexane + ethanol system across 5 literature sources: mass density, refractive index, speed of sound, excess molar enthalpy, excess molar volume, binary diffusion coefficient, dynamic viscosity, and surface tension.
- At equimolar composition (x_ethanol ≈ 0.5) and T ≈ 298.15 K, representative values include mass density of 705.7 kg/m³, refractive index of 1.3598, speed of sound of 1082.3 m/s, excess molar enthalpy of ~1244 J/mol, excess molar volume of ~0.55–0.59 cm³/mol, and binary diffusion coefficient of 1.81 × 10⁻⁹ m²/s.
- The large positive excess molar enthalpy and positive excess molar volume at equimolar composition reflect the strongly non-ideal character of the mixture, attributed to the disruption of ethanol hydrogen-bonding networks by non-polar hexane upon mixing.
- The mass density at x ≈ 0.5 lies between those of pure ethanol (~789 kg/m³) and pure hexane (~655 kg/m³), shifted slightly below the linear average, consistent with the positive excess volume.
- The available data span approximately 273–313 K and cover the full composition range (x_ethanol from 0 to 1).

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_24 |  | Mass density of hexane + ethanol binary mixture |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_22 |  | Refractive index (Na D-line) of hexane + ethanol binary mixture |
| GLOBlit_2800 | 10.1016/j.jct.2007.02.008 | PROPblock_23 |  | Speed of sound of hexane + ethanol binary mixture |
| GLOBlit_294 | 10.1016/j.fluid.2005.08.001 | PROPblock_5 |  | Excess molar enthalpy of hexane + ethanol binary mixture |
| GLOBlit_294 | 10.1016/j.fluid.2005.08.001 | PROPblock_6 |  | Excess molar volume of hexane + ethanol binary mixture |
| GLOBlit_8445 | 10.1021/je0497303 | PROPblock_8 |  | Binary diffusion coefficient of hexane + ethanol binary mixture |
| GLOBlit_11449 | 10.1021/je800925v |  |  | Dynamic viscosity of hexane + ethanol binary mixture across composition range, T = 273–298 K |
| GLOBlit_10821 | 10.1021/je700215z |  |  | Surface tension (liquid–gas) of hexane + ethanol binary mixture, T = 283–313 K |

### Suggested follow-ups

- Retrieve the specific compound global IDs for hexane and ethanol to confirm their registry entries in the ThermoML database.
- Query individual PROPblock entries for viscosity (GLOBlit_11449) and surface tension (GLOBlit_10821) to obtain their exact block IDs and data at x = 0.5.
- Investigate whether additional properties (e.g., vapor-liquid equilibrium data, heat capacity) exist for this binary system under different search criteria.
- Compare measured excess molar enthalpy and excess molar volume values against UNIFAC or NRTL model predictions for hexane + ethanol.

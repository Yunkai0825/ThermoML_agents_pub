# Reference Stats — query-agent

**Run started:** 2026-08-02 19:38:13
**Wall time (at last flush):** 1,166.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 31,759 | 14,290 | 16,168 | 46,049 | 7,674 | 84.4 | claudeopus46 |
| L1-worker | 71 | 575,638 | 456,134 | 230,043 | 1,031,772 | 14,532 | 1118.6 | claudeopus46 |
| **TOTAL** | **77** | **607,397** | **470,424** | **246,211** | **1,077,821** | **13,997** | **1203.0** | |

**Estimated tokens:** ~269,455 input + ~61,552 output = ~331,007 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 5 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 11 | 0 | 0 | 0 | 231 | 616 | 13,252 |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 16 | 6 | 5 | 28 | 50 | 2,088 |
| `search_system_summary` | 11 | 0 | 0 | 0 | 97 | 248 | 8,044 |
| `search_system_summary` | 11 | 0 | 0 | 0 | 58 | 181 | 5,025 |
| `search_blocks` | 2 | 15 | 5 | 5 | 18 | 34 | 1,780 |
| `search_blocks` | 2 | 9 | 5 | 4 | 15 | 28 | 2,079 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 16 | 6 | 5 | 28 | 50 | 2,088 |
| `search_system_summary` | 2 | 0 | 0 | 0 | 32 | 59 | 2,584 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 9 | 5 | 4 | 15 | 28 | 2,079 |
| `search_system_registry` | 2 | 9 | 5 | 4 | 15 | 28 | 2,079 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **83** | **74** | **32** | **27** | **537** | **1322** | **41,098** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (41 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry, search_system_summary |
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks, search_system_summary |
| GLOBcomp_2199 |  | resolve_compound_ids |
| GLOBcomp_5558 |  | resolve_compound_ids |
| GLOBcomp_113 |  | resolve_compound_ids, search_system_summary |
| GLOBcomp_61 |  | resolve_compound_ids, search_blocks, search_system_summary |
| GLOBcomp_704 |  | resolve_compound_ids |
| GLOBcomp_478 |  | resolve_compound_ids |
| GLOBcomp_2227 |  | resolve_compound_ids |
| GLOBcomp_2 |  | resolve_compound_ids, search_system_summary |
| GLOBcomp_100 | choline chloride | search_system_summary |
| GLOBcomp_8 | toluene | search_system_summary |
| GLOBcomp_605 | methyltriphenylphosphonium bromide | search_system_summary |
| GLOBcomp_855 | 2-(diethylamino)ethanol hydrochloride | search_system_summary |
| GLOBcomp_18 | dimethylformamide | search_system_summary |
| GLOBcomp_1395 | trimethylbenzylammonium chloride | search_system_summary |
| GLOBcomp_36 | 1-butyl-3-methylimidazolium tetrafluoroborate | search_system_summary |
| GLOBcomp_25 | 1,4-dioxane | search_system_summary |
| GLOBcomp_111 |  | resolve_compound_ids, search_blocks, search_system_registry, search_system_summary |
| GLOBcomp_597 |  | resolve_compound_ids |
| GLOBcomp_1925 |  | resolve_compound_ids |
| GLOBcomp_7096 |  | resolve_compound_ids |
| GLOBcomp_4913 |  | resolve_compound_ids |
| GLOBcomp_8068 |  | resolve_compound_ids |
| GLOBcomp_4 | methanol | search_system_summary |
| GLOBcomp_154 | propan-1,3-diol | search_system_summary |
| GLOBcomp_146 | 4-methyl-1,3-dioxolan-2-one | search_system_summary |
| GLOBcomp_3 | carbon dioxide | search_system_summary |
| GLOBcomp_38 | hexan-1-ol | search_system_summary |
| GLOBcomp_237 | 1,2-butanediol | search_system_summary |
| GLOBcomp_390 | DL-ethyl lactate | search_system_summary |
| GLOBcomp_11 | heptane | search_system_summary |
| GLOBcomp_1986 | benzyltributylammonium chloride | search_system_summary |
| GLOBcomp_20 | butan-2-ol | search_system_summary |
| GLOBcomp_169 | 1,4-butanediol | search_system_summary |
| GLOBcomp_157 | sulfolane | search_system_summary |
| GLOBcomp_251 |  | resolve_compound_ids |
| GLOBcomp_1741 |  | resolve_compound_ids |
| GLOBcomp_5309 |  | resolve_compound_ids |
| GLOBcomp_167 |  | resolve_compound_ids |
| GLOBcomp_549 |  | resolve_compound_ids |

#### References (91 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_9116 |  | search_system_summary |
| GLOBlit_11122 |  | search_system_summary |
| GLOBlit_5201 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1318 |  | search_system_summary |
| GLOBlit_8182 |  | search_system_summary |
| GLOBlit_11115 |  | search_system_summary |
| GLOBlit_10102 |  | search_system_summary |
| GLOBlit_2335 |  | search_system_summary |
| GLOBlit_8533 |  | search_system_summary |
| GLOBlit_8038 |  | search_blocks, search_system_summary |
| GLOBlit_6951 |  | search_blocks, search_system_summary |
| GLOBlit_3832 |  | search_system_summary |
| GLOBlit_1283 |  | search_blocks, search_system_summary |
| GLOBlit_11865 |  | search_system_summary |
| GLOBlit_2299 |  | search_system_summary |
| GLOBlit_10244 |  | search_system_summary |
| GLOBlit_10165 |  | search_system_summary |
| GLOBlit_3038 |  | search_system_summary |
| GLOBlit_8748 |  | search_system_summary |
| GLOBlit_8773 |  | search_system_summary |
| GLOBlit_721 |  | search_blocks, search_system_registry |
| GLOBlit_1223 |  | search_blocks, search_system_summary |
| GLOBlit_1381 |  | search_blocks |
| GLOBlit_1400 |  | search_blocks |
| GLOBlit_2268 |  | search_blocks |
| GLOBlit_2605 |  | search_blocks, search_system_summary |
| GLOBlit_2656 |  | search_blocks |
| GLOBlit_2831 |  | search_blocks |
| GLOBlit_3286 |  | search_blocks, search_system_summary |
| GLOBlit_4021 |  | search_blocks |
| GLOBlit_5254 |  | search_blocks, search_system_registry |
| GLOBlit_5274 |  | search_blocks |
| GLOBlit_5843 |  | search_blocks, search_system_registry |
| GLOBlit_6630 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_6686 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_6879 |  | search_blocks |
| GLOBlit_7228 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7369 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7440 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_8106 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_8324 |  | search_blocks, search_system_summary |
| GLOBlit_8553 |  | search_blocks |
| GLOBlit_8736 |  | search_blocks, search_system_summary |
| GLOBlit_9693 |  | search_blocks, search_system_summary |
| GLOBlit_4607 |  | search_system_summary |
| GLOBlit_6775 |  | search_blocks, search_system_summary |
| GLOBlit_8239 |  | search_blocks, search_system_summary |
| GLOBlit_5720 |  | search_system_summary |
| GLOBlit_1831 |  | search_system_summary |
| GLOBlit_7276 |  | search_system_summary |
| GLOBlit_8214 |  | search_system_summary |
| GLOBlit_1623 |  | search_blocks, search_system_summary |
| GLOBlit_3784 |  | search_system_summary |
| GLOBlit_7545 |  | search_blocks, search_system_summary |
| GLOBlit_1454 |  | search_system_summary |
| GLOBlit_3674 |  | search_system_summary |
| GLOBlit_6074 |  | search_system_summary |
| GLOBlit_4744 |  | search_system_summary |
| GLOBlit_9758 |  | search_blocks, search_system_summary |
| GLOBlit_10650 |  | search_system_summary |
| GLOBlit_6070 |  | search_system_summary |
| GLOBlit_11337 |  | search_system_summary |
| GLOBlit_11868 |  | search_system_summary |
| GLOBlit_4754 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_9959 |  | search_system_summary |
| GLOBlit_11031 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_170 |  | search_system_summary |
| GLOBlit_1463 |  | search_system_summary |
| GLOBlit_10341 |  | search_system_summary |
| GLOBlit_6166 |  | search_system_summary |
| GLOBlit_9382 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7495 |  | search_system_summary |
| GLOBlit_10412 |  | search_system_summary |
| GLOBlit_1044 |  | search_system_summary |
| GLOBlit_58 |  | search_system_summary |
| GLOBlit_5029 |  | search_system_summary |
| GLOBlit_2867 |  | search_system_summary |
| GLOBlit_8679 |  | search_system_summary |
| GLOBlit_2574 |  | search_blocks |
| GLOBlit_2979 |  | search_blocks |
| GLOBlit_3180 |  | search_blocks |
| GLOBlit_5233 |  | search_blocks |
| GLOBlit_5826 |  | search_blocks, search_system_registry |
| GLOBlit_5907 |  | search_blocks |
| GLOBlit_8556 |  | search_blocks |
| GLOBlit_8686 |  | search_blocks |
| GLOBlit_10313 |  | search_blocks |
| GLOBlit_11906 |  | search_blocks, search_system_summary |
| GLOBlit_10111 |  | search_blocks, search_system_registry |
| GLOBlit_11186 |  | search_system_summary |
| GLOBlit_11506 |  | search_system_summary |

#### Properties (18 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_29 | Binary diffusion coefficient, m2/s | search_blocks, search_system_registry |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_28 | Excess molar volume, m3/mol | search_blocks |
| GLOBprop_85 | Excess molar heat capacity, J/K/mol | search_blocks |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBprop_84 | Partial molar volume, m3/mol | search_blocks |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBprop_2 | Mole fraction | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks, search_system_registry |
| GLOBprop_34 | Thermal conductivity, W/m/K | search_blocks, search_system_registry |
| GLOBprop_44 | Relative permittivity at zero frequency | search_blocks |
| GLOBprop_11 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBprop_74 | Specific volume, m3/kg | search_blocks |

#### Measurements (42 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_38 | Binary diffusion coefficient, m2/s | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_29 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_9 | Excess molar heat capacity, J/K/mol | search_blocks |
| GLOBmeas_658 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBmeas_276 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_1187 | Partial molar volume, m3/mol | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_143 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_192 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_5 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_1 | Mole fraction | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_212 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_227 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_41 | Thermal conductivity, W/m/K | search_blocks, search_system_registry |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_184 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_164 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_46 | Relative permittivity at zero frequency | search_blocks |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_153 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_6 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_132 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_193 | Thermal conductivity, W/m/K | search_blocks |
| GLOBmeas_33 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_17 | Molar heat capacity at constant pressure, J/K/mol | search_blocks, search_system_registry |
| GLOBmeas_130 | Solid-liquid equilibrium temperature, K | search_blocks |
| GLOBmeas_20 | Speed of sound, m/s | search_blocks |
| GLOBmeas_194 | Speed of sound, m/s | search_blocks |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_1716 | Relative permittivity at zero frequency | search_blocks |
| GLOBmeas_171 | Vapor or sublimation pressure, kPa | search_blocks |
| GLOBmeas_65 | Specific volume, m3/kg | search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry |

#### Phases (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |
| GLOBphase_3 |  | search_blocks |

#### Variables (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_18 | Volume fraction | search_blocks |

#### Constraints (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_3 | Mole fraction | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBconstr_5 | Mass fraction | search_blocks |
| GLOBconstr_4 | Frequency, MHz | search_blocks, search_system_registry |
| GLOBconstr_22 | Volume fraction | search_blocks |

#### Solvents (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_12 |  | search_blocks |
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_23 |  | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 41 |
| Unique References | 91 |
| Unique Properties | 18 |
| Unique Measurements | 42 |
| Unique Phases | 2 |
| Unique Variables | 6 |
| Unique Constraints | 6 |
| Unique Solvents | 3 |
| Unique Block_Types | 1 |
| Total DOIs | 47 |
| Unique parent blocks | 112 |
| Explicit block/subsystem targets | 112 |
| Subsystem targets | 0 |
| Target-matched data points | 12,193 |

---

## 3. DOI & Block References

**Unique DOIs:** 47  |  **Parent blocks:** 112  |  **Explicit targets:** 112  |  **Subsystems:** 0  |  **Target-matched datapoints:** 5,947

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2009.07.002 | 5 | 55 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.01.025 | 1 | 85 | binary | search_blocks |
| 10.1016/j.fluid.2013.06.041 | 4 | 399 | binary | search_blocks |
| 10.1016/j.fluid.2013.11.028 | 1 | 5 | binary | search_blocks |
| 10.1016/j.fluid.2014.01.003 | 1 | 9 | binary | search_blocks |
| 10.1016/j.fluid.2014.12.040 | 2 | 168 | binary | search_blocks |
| 10.1016/j.fluid.2018.11.035 | 2 | 12 | binary | search_blocks |
| 10.1016/j.jct.2005.06.018 | 1 | 36 | binary | search_blocks |
| 10.1016/j.jct.2005.08.015 | 2 | 68 | binary | search_blocks |
| 10.1016/j.jct.2006.01.011 | 2 | 20 | binary | search_blocks |
| 10.1016/j.jct.2007.05.010 | 4 | 36 | binary | search_blocks |
| 10.1016/j.jct.2008.07.005 | 1 | 96 | binary | search_blocks |
| 10.1016/j.jct.2009.11.018 | 2 | 28 | binary | search_blocks |
| 10.1016/j.jct.2010.09.003 | 1 | 54 | binary | search_blocks |
| 10.1016/j.jct.2013.10.010 | 1 | 4 | binary | search_blocks |
| 10.1016/j.jct.2016.07.016 | 1 | 588 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | 6 | 912 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.04.007 | 4 | 16 | binary | search_blocks |
| 10.1016/j.jct.2018.05.016 | 4 | 48 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.06.021 | 1 | 15 | binary | search_blocks |
| 10.1016/j.tca.2009.01.008 | 2 | 60 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2009.06.004 | 2 | 26 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2010.10.012 | 1 | 5 | binary | search_blocks |
| 10.1021/acs.jced.5b00498 | 4 | 280 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00662 | 4 | 160 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00964 | 2 | 39 | binary | search_blocks |
| 10.1021/acs.jced.6b00264 | 2 | 12 | binary | search_blocks |
| 10.1021/acs.jced.6b00526 | 3 | 236 | binary | search_blocks |
| 10.1021/acs.jced.7b00501 | 4 | 128 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00945 | 4 | 123 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00058 | 4 | 80 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00403 | 3 | 291 | binary | search_blocks |
| 10.1021/je020140j | 3 | 249 | binary | search_blocks |
| 10.1021/je025610o | 6 | 154 | binary | search_blocks, search_system_registry |
| 10.1021/je0340755 | 3 | 375 | binary | search_blocks |
| 10.1021/je0342522 | 2 | 84 | binary | search_blocks |
| 10.1021/je049955d | 1 | 15 | binary | search_blocks |
| 10.1021/je049960h | 3 | 84 | binary | search_blocks |
| 10.1021/je050237g | 1 | 28 | binary | search_blocks |
| 10.1021/je050353j | 1 | 35 | binary | search_blocks |
| 10.1021/je1009976 | 2 | 170 | binary | search_blocks, search_system_registry |
| 10.1021/je2008704 | 1 | 19 | binary | search_blocks |
| 10.1021/je201184b | 2 | 212 | binary | search_blocks |
| 10.1021/je400158p | 1 | 4 | binary | search_blocks, search_system_registry |
| 10.1021/je4009014 | 1 | 73 | binary | search_blocks |
| 10.1021/je700672f | 2 | 286 | binary | search_blocks, search_system_registry |
| 10.1021/je9010568 | 2 | 65 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2009.07.002 | PROPblock_1 | declared | 5 | binary | — | search_blocks |
| 10.1016/j.fluid.2009.07.002 | PROPblock_2 | declared | 5 | binary | — | search_blocks |
| 10.1016/j.fluid.2009.07.002 | PROPblock_3 | declared | 20 | binary | — | search_blocks |
| 10.1016/j.fluid.2009.07.002 | PROPblock_4 | declared | 5 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.07.002 | PROPblock_5 | declared | 20 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.01.025 | PROPblock_2 | declared | 85 | binary | — | search_blocks |
| 10.1016/j.fluid.2013.06.041 | PROPblock_11 | declared | 135 | binary | — | search_blocks |
| 10.1016/j.fluid.2013.06.041 | PROPblock_12 | declared | 79 | binary | — | search_blocks |
| 10.1016/j.fluid.2013.06.041 | PROPblock_13 | declared | 100 | binary | — | search_blocks |
| 10.1016/j.fluid.2013.06.041 | PROPblock_14 | declared | 85 | binary | — | search_blocks |
| 10.1016/j.fluid.2013.11.028 | PROPblock_6 | declared | 5 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.01.003 | PROPblock_9 | declared | 9 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.12.040 | PROPblock_10 | declared | 84 | binary | — | search_blocks |
| 10.1016/j.fluid.2014.12.040 | PROPblock_9 | declared | 84 | binary | — | search_blocks |
| 10.1016/j.fluid.2018.11.035 | PROPblock_2 | declared | 6 | binary | — | search_blocks |
| 10.1016/j.fluid.2018.11.035 | PROPblock_3 | declared | 6 | binary | — | search_blocks |
| 10.1016/j.jct.2005.06.018 | PROPblock_1 | declared | 36 | binary | — | search_blocks |
| 10.1016/j.jct.2005.08.015 | PROPblock_1 | declared | 35 | binary | — | search_blocks |
| 10.1016/j.jct.2005.08.015 | PROPblock_2 | declared | 33 | binary | — | search_blocks |
| 10.1016/j.jct.2006.01.011 | PROPblock_12 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.010 | PROPblock_10 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.010 | PROPblock_11 | declared | 8 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.010 | PROPblock_12 | declared | 8 | binary | — | search_blocks |
| 10.1016/j.jct.2007.05.010 | PROPblock_9 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2008.07.005 | PROPblock_6 | declared | 96 | binary | — | search_blocks |
| 10.1016/j.jct.2009.11.018 | PROPblock_5 | declared | 14 | binary | — | search_blocks |
| 10.1016/j.jct.2009.11.018 | PROPblock_6 | declared | 14 | binary | — | search_blocks |
| 10.1016/j.jct.2010.09.003 | PROPblock_4 | declared | 54 | binary | — | search_blocks |
| 10.1016/j.jct.2013.10.010 | PROPblock_2 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2016.07.016 | PROPblock_1 | declared | 588 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_22 | declared | 224 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_23 | declared | 148 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_25 | declared | 224 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_26 | declared | 148 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_27 | declared | 84 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.04.007 | PROPblock_1 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2018.04.007 | PROPblock_2 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2018.04.007 | PROPblock_3 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2018.04.007 | PROPblock_4 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2018.05.016 | PROPblock_11 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.05.016 | PROPblock_12 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.05.016 | PROPblock_7 | declared | 12 | binary | — | search_blocks |
| 10.1016/j.jct.2018.05.016 | PROPblock_8 | declared | 12 | binary | — | search_blocks |
| 10.1016/j.jct.2018.06.021 | PROPblock_10 | declared | 15 | binary | — | search_blocks |
| 10.1016/j.tca.2009.01.008 | PROPblock_6 | declared | 30 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2009.01.008 | PROPblock_9 | declared | 30 | binary | — | search_blocks |
| 10.1016/j.tca.2009.06.004 | PROPblock_1 | declared | 13 | binary | — | search_blocks |
| 10.1016/j.tca.2009.06.004 | PROPblock_2 | declared | 13 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2010.10.012 | PROPblock_2 | declared | 5 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00498 | PROPblock_1 | declared | 70 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00498 | PROPblock_2 | declared | 70 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00498 | PROPblock_3 | declared | 70 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00498 | PROPblock_4 | declared | 70 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00662 | PROPblock_45 | declared | 50 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00662 | PROPblock_46 | declared | 50 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00662 | PROPblock_55 | declared | 30 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00662 | PROPblock_56 | declared | 30 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00964 | PROPblock_15 | declared | 36 | binary | — | search_blocks |
| 10.1021/acs.jced.5b00964 | PROPblock_16 | declared | 3 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00264 | PROPblock_10 | declared | 6 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00264 | PROPblock_11 | declared | 6 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00526 | PROPblock_16 | declared | 133 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00526 | PROPblock_17 | declared | 70 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00501 | PROPblock_10 | declared | 32 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00501 | PROPblock_13 | declared | 32 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00501 | PROPblock_14 | declared | 32 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00501 | PROPblock_9 | declared | 32 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00945 | PROPblock_2 | declared | 49 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00945 | PROPblock_3 | declared | 10 | binary | — | search_blocks |
| 10.1021/acs.jced.7b00945 | PROPblock_4 | declared | 54 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00945 | PROPblock_5 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00058 | PROPblock_10 | declared | 20 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00058 | PROPblock_13 | declared | 20 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00058 | PROPblock_14 | declared | 20 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00058 | PROPblock_9 | declared | 20 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00403 | PROPblock_13 | declared | 105 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00403 | PROPblock_14 | declared | 105 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00403 | PROPblock_15 | declared | 81 | binary | — | search_blocks |
| 10.1021/je020140j | PROPblock_4 | declared | 77 | binary | — | search_blocks |
| 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | — | search_blocks |
| 10.1021/je020140j | PROPblock_6 | declared | 95 | binary | — | search_blocks |
| 10.1021/je025610o | PROPblock_4 | declared | 19 | binary | — | search_blocks |
| 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | — | search_blocks |
| 10.1021/je025610o | PROPblock_6 | declared | 30 | binary | — | search_blocks |
| 10.1021/je025610o | PROPblock_7 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je025610o | PROPblock_8 | declared | 27 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je025610o | PROPblock_9 | declared | 27 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0340755 | PROPblock_28 | declared | 125 | binary | — | search_blocks |
| 10.1021/je0340755 | PROPblock_29 | declared | 125 | binary | — | search_blocks |
| 10.1021/je0340755 | PROPblock_30 | declared | 125 | binary | — | search_blocks |
| 10.1021/je0342522 | PROPblock_5 | declared | 42 | binary | — | search_blocks |
| 10.1021/je0342522 | PROPblock_6 | declared | 42 | binary | — | search_blocks |
| 10.1021/je049955d | PROPblock_16 | declared | 15 | binary | — | search_blocks |
| 10.1021/je049960h | PROPblock_10 | declared | 21 | binary | — | search_blocks |
| 10.1021/je049960h | PROPblock_11 | declared | 30 | binary | — | search_blocks |
| 10.1021/je049960h | PROPblock_12 | declared | 33 | binary | — | search_blocks |
| 10.1021/je050237g | PROPblock_1 | declared | 28 | binary | — | search_blocks |
| 10.1021/je050353j | PROPblock_3 | declared | 35 | binary | — | search_blocks |
| 10.1021/je1009976 | PROPblock_3 | declared | 85 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je1009976 | PROPblock_4 | declared | 85 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je2008704 | PROPblock_6 | declared | 19 | binary | — | search_blocks |
| 10.1021/je201184b | PROPblock_1 | declared | 106 | binary | — | search_blocks |
| 10.1021/je201184b | PROPblock_2 | declared | 106 | binary | — | search_blocks |
| 10.1021/je400158p | PROPblock_1 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je4009014 | PROPblock_5 | declared | 73 | binary | — | search_blocks |
| 10.1021/je700672f | PROPblock_3 | declared | 91 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700672f | PROPblock_4 | declared | 195 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je9010568 | PROPblock_7 | declared | 44 | binary | — | search_blocks |
| 10.1021/je9010568 | PROPblock_8 | declared | 21 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 952 | KEEP | 952 | 11.3 |
| 2 | 3 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve alternative… | 618 | KEEP | 618 | 10.3 |
| 3 | 3 | `search_system_summary` | compound=GLOBcomp_24, purpose=Find summary of ethy… | 1,341 | KEEP | 1323 | 16.9 |
| 4 | 4 | `resolve_compound_ids` | limit=10, min_score=40, purpose=Resolve diethylene… | 291 | KEEP | 291 | 5.4 |
| 5 | 4 | `search_blocks` | compound=['GLOBcomp_24', 'GLOBcomp_1'], limit=50, … | 1,488 | KEEP | 1204 | 15.9 |
| 6 | 4 | `search_system_summary` | compound=GLOBcomp_61, purpose=Summarize propylene … | 1,272 | KEEP | 1272 | 17.2 |
| 7 | 5 | `search_system_summary` | compound=GLOBcomp_111, purpose=Survey diethylene g… | 1,463 | KEEP | 1463 | 9.9 |
| 8 | 5 | `search_blocks` | compound=['GLOBcomp_61', 'GLOBcomp_1'], limit=50, … | 1,277 | KEEP | 1142 | 13.4 |
| 9 | 5 | `search_blocks` | compound=['GLOBcomp_111', 'GLOBcomp_1'], limit=50,… | 1,177 | KEEP | 1177 | 14.2 |
| 10 | 1 | `L1_query` | instruction=Search for binary mixtures of…, purpos… | 321 | — | — | 455.6 |
| 11 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve ethylene gl… | 262 | KEEP | 262 | 3.9 |
| 12 | 3 | `search_blocks` | compound=['GLOBcomp_24', 'GLOBcomp_1'], limit=50, … | 1,275 | KEEP | 1275 | 22.8 |
| 13 | 3 | `search_system_summary` | compound=['GLOBcomp_24', 'GLOBcomp_1'], purpose=Ge… | 1,093 | KEEP | 1093 | 8.5 |
| 14 | 2 | `L1_query` | instruction=Search for binary mixture dat…, purpos… | 277 | — | — | 213.0 |
| 15 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve compound I… | 377 | KEEP | 377 | 10.1 |
| 16 | 2 | `L1_query` | instruction=Search for binary mixture dat…, purpos… | 383 | — | — | 178.1 |
| 17 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Find global IDs for… | 218 | KEEP | 218 | 3.8 |
| 18 | 2 | `search_blocks` | compound=['GLOBcomp_111', 'GLOBcomp_1'], limit=50,… | 1,155 | KEEP | 1140 | 19.9 |
| 19 | 3 | `search_system_registry` | compound=['GLOBcomp_111', 'GLOBcomp_1'], limit=50,… | 1,238 | KEEP | 1045 | 18.9 |
| 20 | 2 | `L1_query` | instruction=Search for binary mixture dat…, purpos… | 278 | — | — | 137.4 |
| 21 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve triethylene… | 262 | KEEP | 262 | 5.8 |
| 22 | 2 | `L1_query` | instruction=Search for binary mixture dat…, purpos… | 418 | — | — | 101.5 |
| | | **TOTAL (22 tools)** | | **17,436** | | **15,114** | **1293.8** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 5,640 | 5,640 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,849 | 4,849 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 4,458 | 4,458 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 514 | 10,119 | 10,823 | 51.4 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,010 | 21,653 | 897 | 5.5 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,528 | 23,171 | 15,584 | 56.4 |
| 4 | L1-worker | claudeopus46 | 2,065 | 805 | 2,870 | 1,910 | 10.8 |
| 5 | L1-worker | claudeopus46 | 20,643 | 3,459 | 24,102 | 13,843 | 68.7 |
| 6 | L1-worker | claudeopus46 | 2,065 | 802 | 2,867 | 1,362 | 9.6 |
| 7 | L1-worker | claudeopus46 | 2,065 | 2,085 | 4,150 | 1,886 | 9.2 |
| 8 | L1-worker | claudeopus46 | 20,610 | 6,935 | 27,545 | 435 | 4.1 |
| 9 | L1-worker | claudeopus46 | 20,643 | 6,182 | 26,825 | 1,576 | 9.5 |
| 10 | L1-worker | claudeopus46 | 2,065 | 1,224 | 3,289 | 461 | 4.5 |
| 11 | L1-worker | claudeopus46 | 2,065 | 32,917 | 34,982 | 1,518 | 13.4 |
| 12 | L1-worker | claudeopus46 | 2,065 | 1,981 | 4,046 | 1,784 | 9.8 |
| 13 | L1-worker | claudeopus46 | 20,643 | 10,137 | 30,780 | 13,151 | 74.2 |
| 14 | L1-worker | claudeopus46 | 2,065 | 2,068 | 4,133 | 1,792 | 9.5 |
| 15 | L1-worker | claudeopus46 | 2,065 | 22,583 | 24,648 | 1,763 | 12.5 |
| 16 | L1-worker | claudeopus46 | 2,065 | 19,540 | 21,605 | 1,716 | 13.3 |
| 17 | L1-worker | claudeopus46 | 20,643 | 15,305 | 35,948 | 5,812 | 32.9 |
| 18 | L1-worker | claudeopus46 | 1,356 | 5,943 | 7,299 | 1,258 | 6.5 |
| 19 | L1-worker | claudeopus46 | 536 | 5,823 | 6,359 | 1,324 | 7.9 |
| 20 | L1-worker | claudeopus46 | 298 | 1,640 | 1,938 | 1,246 | 4.0 |
| 21 | L1-worker | claudeopus46 | 1,323 | 20,846 | 22,169 | 9,494 | 32.5 |
| 22 | L1-worker | claudeopus46 | 298 | 10,216 | 10,514 | 7,528 | 27.7 |
| 23 | L1-worker | claudeopus46 | 1,160 | 32,798 | 33,958 | 7,509 | 28.1 |
| 24 | L0-main | claudeopus46 | 9,605 | 1,347 | 10,952 | 2,255 | 10.2 |
| 25 | L1-worker | claudeopus46 | 20,643 | 854 | 21,497 | 676 | 5.1 |
| 26 | L1-worker | claudeopus46 | 20,643 | 2,151 | 22,794 | 14,679 | 50.1 |
| 27 | L1-worker | claudeopus46 | 2,065 | 510 | 2,575 | 494 | 3.8 |
| 28 | L1-worker | claudeopus46 | 20,643 | 2,357 | 23,000 | 12,103 | 59.5 |
| 29 | L1-worker | claudeopus46 | 2,065 | 32,968 | 35,033 | 1,665 | 14.6 |
| 30 | L1-worker | claudeopus46 | 2,065 | 1,558 | 3,623 | 1,394 | 8.0 |
| 31 | L1-worker | claudeopus46 | 20,610 | 6,144 | 26,754 | 366 | 3.9 |
| 32 | L1-worker | claudeopus46 | 20,643 | 5,391 | 26,034 | 3,071 | 18.3 |
| 33 | L1-worker | claudeopus46 | 1,356 | 3,200 | 4,556 | 847 | 6.0 |
| 34 | L1-worker | claudeopus46 | 536 | 3,080 | 3,616 | 1,145 | 8.3 |
| 35 | L1-worker | claudeopus46 | 1,323 | 8,169 | 9,492 | 3,741 | 17.8 |
| 36 | L1-worker | claudeopus46 | 298 | 4,463 | 4,761 | 2,828 | 10.8 |
| 37 | L1-worker | claudeopus46 | 1,160 | 12,447 | 13,607 | 2,840 | 11.4 |
| 38 | L1-worker | claudeopus46 | 20,643 | 856 | 21,499 | 597 | 5.7 |
| 39 | L1-worker | claudeopus46 | 20,643 | 2,074 | 22,717 | 13,202 | 49.8 |
| 40 | L1-worker | claudeopus46 | 2,065 | 1,204 | 3,269 | 1,214 | 9.5 |
| 41 | L1-worker | claudeopus46 | 20,643 | 2,381 | 23,024 | 10,932 | 49.7 |
| 42 | L1-worker | claudeopus46 | 20,643 | 13,934 | 34,577 | 4,157 | 17.7 |
| 43 | L1-worker | claudeopus46 | 1,356 | 4,288 | 5,644 | 869 | 5.2 |
| 44 | L1-worker | claudeopus46 | 298 | 1,251 | 1,549 | 857 | 3.2 |
| 45 | L1-worker | claudeopus46 | 536 | 4,168 | 4,704 | 1,312 | 10.2 |
| 46 | L1-worker | claudeopus46 | 1,323 | 6,339 | 7,662 | 4,105 | 18.6 |
| 47 | L1-worker | claudeopus46 | 298 | 4,827 | 5,125 | 3,032 | 13.0 |
| 48 | L1-worker | claudeopus46 | 1,160 | 11,087 | 12,247 | 3,044 | 12.8 |
| 49 | L1-worker | claudeopus46 | 20,643 | 842 | 21,485 | 573 | 5.0 |
| 50 | L1-worker | claudeopus46 | 2,065 | 453 | 2,518 | 421 | 3.7 |
| 51 | L1-worker | claudeopus46 | 20,643 | 1,540 | 22,183 | 768 | 8.7 |
| 52 | L1-worker | claudeopus46 | 2,065 | 19,543 | 21,608 | 1,602 | 12.5 |
| 53 | L1-worker | claudeopus46 | 20,643 | 3,191 | 23,834 | 1,124 | 11.2 |
| 54 | L1-worker | claudeopus46 | 2,065 | 4,872 | 6,937 | 1,687 | 11.7 |
| 55 | L1-worker | claudeopus46 | 20,610 | 5,753 | 26,363 | 371 | 4.3 |
| 56 | L1-worker | claudeopus46 | 20,643 | 5,000 | 25,643 | 4,220 | 25.3 |
| 57 | L1-worker | claudeopus46 | 1,356 | 3,041 | 4,397 | 850 | 5.3 |
| 58 | L1-worker | claudeopus46 | 536 | 2,921 | 3,457 | 1,264 | 7.3 |
| 59 | L1-worker | claudeopus46 | 298 | 1,232 | 1,530 | 838 | 3.3 |
| 60 | L1-worker | claudeopus46 | 298 | 1,620 | 1,918 | 1,251 | 4.3 |
| 61 | L1-worker | claudeopus46 | 1,323 | 7,716 | 9,039 | 3,810 | 14.7 |
| 62 | L1-worker | claudeopus46 | 298 | 4,532 | 4,830 | 2,817 | 12.5 |
| 63 | L1-worker | claudeopus46 | 1,160 | 12,064 | 13,224 | 2,783 | 11.4 |
| 64 | L1-worker | claudeopus46 | 20,643 | 844 | 21,487 | 675 | 5.4 |
| 65 | L1-worker | claudeopus46 | 20,643 | 2,140 | 22,783 | 935 | 5.6 |
| 66 | L1-worker | claudeopus46 | 2,065 | 512 | 2,577 | 481 | 5.5 |
| 67 | L1-worker | claudeopus46 | 20,643 | 2,325 | 22,968 | 6,644 | 32.7 |
| 68 | L1-worker | claudeopus46 | 20,643 | 9,544 | 30,187 | 2,610 | 9.9 |
| 69 | L1-worker | claudeopus46 | 1,356 | 2,739 | 4,095 | 948 | 5.2 |
| 70 | L1-worker | claudeopus46 | 536 | 2,619 | 3,155 | 680 | 7.9 |
| 71 | L1-worker | claudeopus46 | 1,323 | 4,635 | 5,958 | 3,947 | 15.5 |
| 72 | L1-worker | claudeopus46 | 298 | 4,669 | 4,967 | 2,874 | 11.7 |
| 73 | L1-worker | claudeopus46 | 1,160 | 9,259 | 10,419 | 2,851 | 14.4 |
| 74 | L0-main | claudeopus46 | 9,572 | 3,536 | 13,108 | 1,222 | 8.6 |
| 75 | L0-main | claudeopus46 | 1,356 | 1,353 | 2,709 | 532 | 5.0 |
| 76 | L0-main | claudeopus46 | 1,323 | 6,178 | 7,501 | 694 | 6.1 |
| 77 | L0-main | claudeopus46 | 298 | 1,362 | 1,660 | 642 | 3.1 |


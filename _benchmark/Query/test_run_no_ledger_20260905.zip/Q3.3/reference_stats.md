# Reference Stats — query-agent

**Run started:** 2026-08-02 19:04:40
**Wall time (at last flush):** 1,348.5 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 60,574 | 34,594 | 30,414 | 95,168 | 10,574 | 153.2 | claudeopus46 |
| L1-worker | 78 | 663,546 | 684,677 | 249,709 | 1,348,223 | 17,284 | 1229.2 | claudeopus46 |
| **TOTAL** | **87** | **724,120** | **719,271** | **280,123** | **1,443,391** | **16,590** | **1382.4** | |

**Estimated tokens:** ~360,847 input + ~70,030 output = ~430,877 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 14 | 6 | 5 | 27 | 50 | 2,504 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 14 | 6 | 5 | 27 | 50 | 2,504 |
| `search_system_registry` | 2 | 17 | 6 | 5 | 39 | 71 | 2,967 |
| `search_blocks` | 2 | 17 | 6 | 5 | 39 | 71 | 2,967 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_summary` | 2 | 0 | 0 | 0 | 39 | 71 | 2,967 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 2 | 17 | 6 | 5 | 39 | 71 | 2,967 |
| `search_blocks` | 2 | 17 | 6 | 5 | 39 | 71 | 2,967 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 2 | 4 | 0 | 1 | 2 | 1,248 |
| `search_blocks` | 2 | 1 | 3 | 0 | 1 | 1 | 529 |
| `search_blocks` | 2 | 4 | 2 | 1 | 1 | 4 | 36 |
| `search_blocks` | 2 | 3 | 2 | 1 | 1 | 3 | 37 |
| `search_blocks` | 2 | 2 | 1 | 1 | 1 | 2 | 28 |
| `search_blocks` | 2 | 1 | 2 | 0 | 1 | 1 | 60 |
| `search_blocks` | 2 | 2 | 1 | 1 | 1 | 2 | 34 |
| `search_blocks` | 2 | 2 | 1 | 1 | 1 | 2 | 30 |
| `search_blocks` | 2 | 1 | 2 | 0 | 1 | 1 | 48 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 45 |
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 1 | 17 |
| `search_system_summary` | 2 | 0 | 0 | 0 | 39 | 71 | 2,967 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **44** | **116** | **57** | **37** | **299** | **546** | **24,922** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_6 |  | resolve_compound_ids, search_blocks, search_system_registry, search_system_summary |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry, search_system_summary |

#### References (39 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_378 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1311 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1423 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1801 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1827 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_1910 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_2096 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_2432 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_2687 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_2892 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_4843 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_4959 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_5240 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_5585 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_6409 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_6553 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_6822 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7238 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7312 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7474 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7483 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7500 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7596 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7629 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7665 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_7735 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_8447 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_8629 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_9129 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_9722 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_10006 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_10701 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_10907 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_10926 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_11042 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_11130 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_11142 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_11513 |  | search_blocks, search_system_registry, search_system_summary |
| GLOBlit_11872 |  | search_blocks, search_system_registry, search_system_summary |

#### Properties (17 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks, search_system_registry |
| GLOBprop_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBprop_58 | Azeotropic temperature, K | search_blocks, search_system_registry |
| GLOBprop_45 | Azeotropic composition: mole fraction | search_blocks, search_system_registry |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBprop_18 | Electrical conductivity, S/m | search_blocks, search_system_registry |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBprop_63 | Heat capacity at constant pressure per volume, J/K/m3 | search_blocks, search_system_registry |
| GLOBprop_55 | Henry's Law constant (molality scale), kPa*kg/mol | search_blocks, search_system_registry |
| GLOBprop_3 | Activity coefficient | search_blocks, search_system_registry |
| GLOBprop_32 | Amount concentration (molarity), mol/dm3 | search_blocks, search_system_registry |

#### Measurements (25 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_171 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_12 | Molar heat capacity at constant pressure, J/K/mol | search_blocks, search_system_registry |
| GLOBmeas_5 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_1 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_39 | Azeotropic temperature, K | search_blocks, search_system_registry |
| GLOBmeas_192 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_132 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_14 | Electrical conductivity, S/m | search_blocks, search_system_registry |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBmeas_137 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_967 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_297 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_146 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_145 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_1043 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_1366 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_866 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_155 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_189 | Mole fraction | search_blocks, search_system_registry |

#### Phases (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |
| GLOBphase_3 |  | search_blocks, search_system_registry |

#### Variables (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_15 | Mass ratio of solute to solvent | search_blocks, search_system_registry |

#### Constraints (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_4 | Frequency, MHz | search_blocks, search_system_registry |
| GLOBconstr_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBconstr_3 | Mole fraction | search_blocks, search_system_registry |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 39 |
| Unique Properties | 17 |
| Unique Measurements | 25 |
| Unique Phases | 2 |
| Unique Variables | 6 |
| Unique Constraints | 5 |
| Unique Solvents | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 39 |
| Unique parent blocks | 71 |
| Explicit block/subsystem targets | 71 |
| Subsystem targets | 0 |
| Target-matched data points | 18,988 |

---

## 3. DOI & Block References

**Unique DOIs:** 39  |  **Parent blocks:** 71  |  **Explicit targets:** 71  |  **Subsystems:** 0  |  **Target-matched datapoints:** 2,967

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2006.03.021 | 1 | 48 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.08.007 | 2 | 1,248 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.02.006 | 4 | 36 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.09.052 | 1 | 17 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.11.034 | 2 | 28 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.04.007 | 1 | 60 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.010 | 3 | 37 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2004.07.019 | 1 | 529 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.04.006 | 2 | 34 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.12.002 | 1 | 45 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2016.10.001 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.02.005 | 2 | 62 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.04.017 | 2 | 6 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.105880 | 3 | 36 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2017.12.010 | 1 | 24 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00200 | 1 | 2 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00019 | 2 | 12 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00523 | 2 | 36 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00755 | 2 | 34 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00160 | 2 | 36 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00181 | 2 | 12 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00228 | 2 | 40 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00610 | 1 | 2 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | 2 | 6 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00895 | 2 | 46 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b01116 | 2 | 22 | binary | search_blocks, search_system_registry |
| 10.1021/je049738c | 2 | 16 | binary | search_blocks, search_system_registry |
| 10.1021/je0501336 | 2 | 18 | binary | search_blocks, search_system_registry |
| 10.1021/je1001329 | 1 | 11 | binary | search_blocks, search_system_registry |
| 10.1021/je201010s | 2 | 38 | binary | search_blocks, search_system_registry |
| 10.1021/je3010535 | 1 | 4 | binary | search_blocks, search_system_registry |
| 10.1021/je600567z | 3 | 7 | binary | search_blocks, search_system_registry |
| 10.1021/je7003808 | 2 | 22 | binary | search_blocks, search_system_registry |
| 10.1021/je700418a | 1 | 1 | binary | search_blocks, search_system_registry |
| 10.1021/je700700f | 3 | 39 | binary | search_blocks, search_system_registry |
| 10.1021/je8001305 | 1 | 209 | binary | search_blocks, search_system_registry |
| 10.1021/je800158z | 1 | 56 | binary | search_blocks, search_system_registry |
| 10.1021/je9000922 | 2 | 22 | binary | search_blocks, search_system_registry |
| 10.1021/je900966r | 2 | 36 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2006.03.021 | PROPblock_1 | declared | 48 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.08.007 | PROPblock_4 | declared | 1,110 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.08.007 | PROPblock_5 | declared | 138 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.02.006 | PROPblock_11 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.02.006 | PROPblock_12 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.02.006 | PROPblock_13 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.02.006 | PROPblock_14 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.09.052 | PROPblock_13 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.11.034 | PROPblock_1 | declared | 14 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.11.034 | PROPblock_2 | declared | 14 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.04.007 | PROPblock_2 | declared | 60 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.010 | PROPblock_5 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.010 | PROPblock_6 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.010 | PROPblock_7 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2004.07.019 | PROPblock_4 | declared | 529 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.04.006 | PROPblock_3 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.04.006 | PROPblock_4 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.12.002 | PROPblock_1 | declared | 45 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2016.10.001 | PROPblock_10 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2016.10.001 | PROPblock_9 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.02.005 | PROPblock_3 | declared | 31 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.02.005 | PROPblock_4 | declared | 31 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.04.017 | PROPblock_4 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.04.017 | PROPblock_5 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.105880 | PROPblock_10 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.105880 | PROPblock_11 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.105880 | PROPblock_12 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2017.12.010 | PROPblock_7 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00200 | PROPblock_21 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00019 | PROPblock_13 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00019 | PROPblock_14 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00523 | PROPblock_3 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00523 | PROPblock_4 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00755 | PROPblock_2 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00755 | PROPblock_3 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00160 | PROPblock_15 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00160 | PROPblock_16 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00181 | PROPblock_6 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00181 | PROPblock_7 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00228 | PROPblock_4 | declared | 20 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00228 | PROPblock_5 | declared | 20 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00610 | PROPblock_10 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_14 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_15 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00895 | PROPblock_1 | declared | 23 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00895 | PROPblock_2 | declared | 23 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b01116 | PROPblock_10 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b01116 | PROPblock_9 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je049738c | PROPblock_27 | declared | 8 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je049738c | PROPblock_28 | declared | 8 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0501336 | PROPblock_1 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0501336 | PROPblock_2 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je1001329 | PROPblock_5 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je201010s | PROPblock_7 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je201010s | PROPblock_8 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je3010535 | PROPblock_86 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je600567z | PROPblock_1 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je600567z | PROPblock_2 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je600567z | PROPblock_3 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je7003808 | PROPblock_1 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je7003808 | PROPblock_2 | declared | 11 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700418a | PROPblock_3 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700700f | PROPblock_15 | declared | 13 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700700f | PROPblock_16 | declared | 13 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je700700f | PROPblock_17 | declared | 13 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je8001305 | PROPblock_1 | declared | 209 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je800158z | PROPblock_4 | declared | 56 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je9000922 | PROPblock_2 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je9000922 | PROPblock_3 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je900966r | PROPblock_5 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je900966r | PROPblock_6 | declared | 30 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 222 | KEEP | 222 | 3.9 |
| 2 | 1 | `L1_query` | context=User wants the most complete …, id_catalog… | 414 | — | — | 161.2 |
| 3 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve compound I… | 214 | KEEP | 214 | 4.1 |
| 4 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, p… | 1,208 | KEEP | 1193 | 20.8 |
| 5 | 2 | `L1_query` | instruction=Search for all studies (liter…, purpos… | 119 | — | — | 375.3 |
| 6 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve global comp… | 200 | KEEP | 200 | 3.7 |
| 7 | 3 | `L1_query` | instruction=Find the global compound IDs …, purpos… | 1,281 | — | — | 31.4 |
| 8 | 1 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, p… | 1,451 | KEEP | 1269 | 20.1 |
| 9 | 2 | `search_system_registry` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=100, … | 1,142 | KEEP | 978 | 17.5 |
| 10 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=100, … | 493 | — | — | 8.4 |
| 11 | 4 | `search_system_summary` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, p… | 1,234 | KEEP | 1234 | 9.3 |
| 12 | 4 | `L1_query` | context=User wants to find the most c…, id_catalog… | 277 | — | — | 201.5 |
| 13 | 1 | `search_system_registry` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=100, … | 1,248 | KEEP | 1069 | 14.6 |
| 14 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=80, p… | 493 | KEEP | 1144 | 7.9 |
| 15 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=10, l… | 1,144 | KEEP | 1412 | 14.1 |
| 16 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=10, l… | 1,427 | KEEP | 1226 | 13.8 |
| 17 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, l… | 1,226 | KEEP | 1200 | 13.2 |
| 18 | 4 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, l… | 1,200 | KEEP | 1207 | 13.2 |
| 19 | 5 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, l… | 1,207 | KEEP | 1003 | 12.5 |
| 20 | 5 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, l… | 1,018 | KEEP | 1084 | 9.9 |
| 21 | 6 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=10, l… | 1,084 | KEEP | 1194 | 10.5 |
| 22 | 6 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=10, l… | 1,194 | KEEP | 1099 | 12.9 |
| 23 | 7 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, l… | 1,099 | KEEP | 1102 | 15.2 |
| 24 | 7 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, l… | 1,117 | KEEP | 1170 | 11.8 |
| 25 | 7 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=50, l… | 1,185 | — | — | 11.8 |
| 26 | 7 | `search_system_summary` | compound=['GLOBcomp_1', 'GLOBcomp_6'], limit=20, p… | 1,139 | KEEP | 1139 | 9.2 |
| 27 | 5 | `L1_query` | context=The user wants to know which …, id_catalog… | 271 | — | — | 428.5 |
| | | **TOTAL (27 tools)** | | **24,307** | | **20,359** | **1456.3** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,544 | 3,544 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 5,674 | 5,674 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 7,034 | 7,034 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 16,111 | 16,111 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 664 | 10,269 | 1,355 | 8.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,193 | 21,836 | 539 | 4.8 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,353 | 22,996 | 838 | 5.3 |
| 4 | L1-worker | claudeopus46 | 2,065 | 444 | 2,509 | 395 | 3.8 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,474 | 23,117 | 11,381 | 52.7 |
| 6 | L1-worker | claudeopus46 | 20,643 | 14,476 | 35,119 | 3,857 | 17.8 |
| 7 | L1-worker | claudeopus46 | 536 | 3,868 | 4,404 | 1,097 | 6.1 |
| 8 | L1-worker | claudeopus46 | 1,356 | 3,988 | 5,344 | 960 | 7.5 |
| 9 | L1-worker | claudeopus46 | 1,323 | 6,179 | 7,502 | 8,215 | 28.3 |
| 10 | L1-worker | claudeopus46 | 298 | 8,937 | 9,235 | 6,716 | 24.0 |
| 11 | L1-worker | claudeopus46 | 1,160 | 16,421 | 17,581 | 6,620 | 23.8 |
| 12 | L0-main | claudeopus46 | 9,605 | 1,604 | 11,209 | 13,092 | 55.5 |
| 13 | L1-worker | claudeopus46 | 20,643 | 1,082 | 21,725 | 555 | 4.9 |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,258 | 22,901 | 15,256 | 49.7 |
| 15 | L1-worker | claudeopus46 | 2,065 | 444 | 2,509 | 489 | 3.9 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,393 | 23,036 | 14,512 | 50.7 |
| 17 | L1-worker | claudeopus46 | 2,065 | 30,770 | 32,835 | 1,703 | 13.4 |
| 18 | L1-worker | claudeopus46 | 20,610 | 4,839 | 25,449 | 617 | 4.6 |
| 19 | L1-worker | claudeopus46 | 20,643 | 4,086 | 24,729 | 11,825 | 59.1 |
| 20 | L1-worker | claudeopus46 | 20,643 | 16,532 | 37,175 | 5,587 | 23.7 |
| 21 | L1-worker | claudeopus46 | 1,356 | 5,718 | 7,074 | 945 | 4.9 |
| 22 | L1-worker | claudeopus46 | 536 | 5,598 | 6,134 | 1,284 | 6.3 |
| 23 | L1-worker | claudeopus46 | 298 | 1,327 | 1,625 | 895 | 3.3 |
| 24 | L1-worker | claudeopus46 | 1,323 | 9,486 | 10,809 | 8,628 | 33.3 |
| 25 | L1-worker | claudeopus46 | 298 | 9,350 | 9,648 | 7,148 | 28.1 |
| 26 | L1-worker | claudeopus46 | 1,160 | 20,314 | 21,474 | 13,338 | 48.0 |
| 27 | L1-worker | claudeopus46 | 298 | 14,060 | 14,358 | 13,338 | 47.2 |
| 28 | L0-main | claudeopus46 | 9,605 | 2,201 | 11,806 | 724 | 5.4 |
| 29 | L1-worker | claudeopus46 | 20,643 | 748 | 21,391 | 624 | 4.5 |
| 30 | L1-worker | claudeopus46 | 20,643 | 1,993 | 22,636 | 994 | 7.0 |
| 31 | L1-worker | claudeopus46 | 2,065 | 523 | 2,588 | 368 | 3.5 |
| 32 | L1-worker | claudeopus46 | 20,643 | 2,121 | 22,764 | 390 | 3.8 |
| 33 | L1-worker | claudeopus46 | 1,356 | 521 | 1,877 | 239 | 2.7 |
| 34 | L1-worker | claudeopus46 | 536 | 401 | 937 | 253 | 3.0 |
| 35 | L1-worker | claudeopus46 | 1,323 | 2,097 | 3,420 | 233 | 5.0 |
| 36 | L1-worker | claudeopus46 | 298 | 955 | 1,253 | 153 | 2.2 |
| 37 | L1-worker | claudeopus46 | 747 | 2,540 | 3,287 | 466 | 4.6 |
| 38 | L0-main | claudeopus46 | 9,605 | 5,401 | 15,006 | 1,547 | 15.2 |
| 39 | L1-worker | claudeopus46 | 20,643 | 2,861 | 23,504 | 844 | 6.0 |
| 40 | L1-worker | claudeopus46 | 2,065 | 30,733 | 32,798 | 1,597 | 13.4 |
| 41 | L1-worker | claudeopus46 | 20,643 | 4,834 | 25,477 | 1,097 | 7.5 |
| 42 | L1-worker | claudeopus46 | 2,065 | 11,048 | 13,113 | 1,902 | 16.9 |
| 43 | L1-worker | claudeopus46 | 20,643 | 6,576 | 27,219 | 1,962 | 12.9 |
| 44 | L1-worker | claudeopus46 | 20,610 | 8,434 | 29,044 | 583 | 4.2 |
| 45 | L1-worker | claudeopus46 | 20,643 | 7,681 | 28,324 | 2,494 | 16.4 |
| 46 | L1-worker | claudeopus46 | 2,065 | 1,600 | 3,665 | 1,571 | 8.8 |
| 47 | L1-worker | claudeopus46 | 20,643 | 9,498 | 30,141 | 6,709 | 35.9 |
| 48 | L1-worker | claudeopus46 | 1,356 | 4,599 | 5,955 | 1,225 | 7.3 |
| 49 | L1-worker | claudeopus46 | 536 | 4,479 | 5,015 | 1,224 | 7.3 |
| 50 | L1-worker | claudeopus46 | 298 | 1,607 | 1,905 | 1,213 | 6.5 |
| 51 | L1-worker | claudeopus46 | 1,323 | 12,127 | 13,450 | 6,341 | 23.6 |
| 52 | L1-worker | claudeopus46 | 298 | 7,063 | 7,361 | 5,015 | 19.0 |
| 53 | L1-worker | claudeopus46 | 1,160 | 19,869 | 21,029 | 5,028 | 19.6 |
| 54 | L0-main | claudeopus46 | 9,605 | 6,476 | 16,081 | 9,377 | 42.6 |
| 55 | L1-worker | claudeopus46 | 20,643 | 2,862 | 23,505 | 1,046 | 6.4 |
| 56 | L1-worker | claudeopus46 | 2,065 | 11,037 | 13,102 | 1,583 | 13.8 |
| 57 | L1-worker | claudeopus46 | 20,643 | 4,669 | 25,312 | 959 | 8.8 |
| 58 | L1-worker | claudeopus46 | 20,643 | 5,710 | 26,353 | 2,572 | 15.0 |
| 59 | L1-worker | claudeopus46 | 2,065 | 6,141 | 8,206 | 1,800 | 13.9 |
| 60 | L1-worker | claudeopus46 | 2,065 | 2,852 | 4,917 | 1,934 | 13.7 |
| 61 | L1-worker | claudeopus46 | 20,610 | 9,794 | 30,404 | 636 | 5.1 |
| 62 | L1-worker | claudeopus46 | 20,643 | 9,041 | 29,684 | 2,193 | 14.8 |
| 63 | L1-worker | claudeopus46 | 2,065 | 6,371 | 8,436 | 1,558 | 13.0 |
| 64 | L1-worker | claudeopus46 | 2,065 | 5,269 | 7,334 | 1,584 | 13.1 |
| 65 | L1-worker | claudeopus46 | 20,643 | 12,206 | 32,849 | 2,762 | 17.0 |
| 66 | L1-worker | claudeopus46 | 2,065 | 3,646 | 5,711 | 1,516 | 12.4 |
| 67 | L1-worker | claudeopus46 | 2,065 | 2,426 | 4,491 | 1,429 | 9.7 |
| 68 | L1-worker | claudeopus46 | 20,643 | 15,207 | 35,850 | 2,428 | 15.7 |
| 69 | L1-worker | claudeopus46 | 2,065 | 3,823 | 5,888 | 1,392 | 10.3 |
| 70 | L1-worker | claudeopus46 | 2,065 | 3,787 | 5,852 | 1,501 | 12.8 |
| 71 | L1-worker | claudeopus46 | 20,610 | 18,948 | 39,558 | 424 | 5.1 |
| 72 | L1-worker | claudeopus46 | 20,643 | 18,193 | 38,836 | 15,927 | 78.3 |
| 73 | L1-worker | claudeopus46 | 2,065 | 3,541 | 5,606 | 1,479 | 15.0 |
| 74 | L1-worker | claudeopus46 | 2,065 | 3,121 | 5,186 | 1,525 | 11.5 |
| 75 | L1-worker | claudeopus46 | 2,065 | 2,425 | 4,490 | 1,678 | 11.5 |
| 76 | L1-worker | claudeopus46 | 2,065 | 1,558 | 3,623 | 1,492 | 8.7 |
| 77 | L1-worker | claudeopus46 | 20,643 | 20,553 | 41,196 | 3,468 | 24.8 |
| 78 | L1-worker | claudeopus46 | 1,356 | 3,599 | 4,955 | 1,012 | 6.3 |
| 79 | L1-worker | claudeopus46 | 536 | 3,479 | 4,015 | 1,445 | 8.3 |
| 80 | L1-worker | claudeopus46 | 298 | 1,394 | 1,692 | 1,000 | 3.7 |
| 81 | L1-worker | claudeopus46 | 1,323 | 27,294 | 28,617 | 7,209 | 29.7 |
| 82 | L1-worker | claudeopus46 | 298 | 7,931 | 8,229 | 6,001 | 24.5 |
| 83 | L1-worker | claudeopus46 | 747 | 134,302 | 135,049 | 893 | 9.5 |
| 84 | L0-main | claudeopus46 | 9,572 | 5,626 | 15,198 | 1,765 | 12.1 |
| 85 | L0-main | claudeopus46 | 1,356 | 1,896 | 3,252 | 652 | 3.6 |
| 86 | L0-main | claudeopus46 | 1,323 | 9,040 | 10,363 | 1,018 | 6.7 |
| 87 | L0-main | claudeopus46 | 298 | 1,686 | 1,984 | 884 | 3.6 |


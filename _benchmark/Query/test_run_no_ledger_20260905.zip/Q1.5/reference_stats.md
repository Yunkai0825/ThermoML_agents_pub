# Reference Stats — query-agent

**Run started:** 2026-08-02 18:41:52
**Wall time (at last flush):** 731.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 216,110 | 23,298 | 257,805 | 32,225 | 135.0 | claudeopus46 |
| L1-worker | 57 | 505,488 | 1,018,116 | 88,751 | 1,523,604 | 26,729 | 576.7 | claudeopus46 |
| **TOTAL** | **65** | **547,183** | **1,234,226** | **112,049** | **1,781,409** | **27,406** | **711.7** | |

**Estimated tokens:** ~445,352 input + ~28,012 output = ~473,364 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 2 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 49 | 50 | 249 |
| `search_blocks` | 1 | 1 | 1 | 1 | 1 | 1 | 7 |
| `resolve_measurement_ids` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 49 | 50 | 249 |
| `resolve_measurement_ids` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 49 | 50 | 249 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 1 | 1 | 1 | 1 | 7 |
| `search_blocks` | 1 | 1 | 2 | 1 | 49 | 50 | 249 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 1 | 0 | 0 | 0 | 48 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 10 | 10 | 26 |
| `search_blocks` | 1 | 1 | 2 | 1 | 10 | 10 | 44 |
| `resolve_measurement_ids` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 20 | 20 | 120 |
| **TOTAL** | **11** | **11** | **16** | **9** | **286** | **242** | **1,200** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | block_search_adv, resolve_compound_ids, search_blocks |

#### Properties (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_blocks |
| GLOBprop_40 |  | resolve_property_ids, search_blocks |

#### References (62 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8 |  | block_search_adv, search_blocks |
| GLOBlit_267 |  | block_search_adv, search_blocks |
| GLOBlit_288 |  | block_search_adv, search_blocks |
| GLOBlit_349 |  | block_search_adv, search_blocks |
| GLOBlit_359 |  | block_search_adv, search_blocks |
| GLOBlit_499 |  | block_search_adv, search_blocks |
| GLOBlit_1969 |  | block_search_adv, search_blocks |
| GLOBlit_2547 |  | block_search_adv, search_blocks |
| GLOBlit_2568 |  | block_search_adv, search_blocks |
| GLOBlit_2580 |  | block_search_adv, search_blocks |
| GLOBlit_2632 |  | block_search_adv, search_blocks |
| GLOBlit_2648 |  | block_search_adv, search_blocks |
| GLOBlit_2674 |  | block_search_adv, search_blocks |
| GLOBlit_2680 |  | block_search_adv, search_blocks |
| GLOBlit_2707 |  | block_search_adv, search_blocks |
| GLOBlit_2825 |  | block_search_adv, search_blocks |
| GLOBlit_2934 |  | block_search_adv, search_blocks |
| GLOBlit_2944 |  | block_search_adv, search_blocks |
| GLOBlit_3116 |  | block_search_adv, search_blocks |
| GLOBlit_3224 |  | block_search_adv, search_blocks |
| GLOBlit_3572 |  | block_search_adv, search_blocks |
| GLOBlit_3711 |  | block_search_adv, search_blocks |
| GLOBlit_3748 |  | block_search_adv, search_blocks |
| GLOBlit_3988 |  | block_search_adv, search_blocks |
| GLOBlit_4013 |  | block_search_adv, search_blocks |
| GLOBlit_4060 |  | block_search_adv, search_blocks |
| GLOBlit_4369 |  | block_search_adv, search_blocks |
| GLOBlit_4485 |  | block_search_adv, search_blocks |
| GLOBlit_4940 |  | block_search_adv, search_blocks |
| GLOBlit_5074 |  | block_search_adv, search_blocks |
| GLOBlit_5201 |  | block_search_adv, search_blocks |
| GLOBlit_5465 |  | block_search_adv, search_blocks |
| GLOBlit_5522 |  | block_search_adv, search_blocks |
| GLOBlit_6540 |  | block_search_adv, search_blocks |
| GLOBlit_6543 |  | block_search_adv, search_blocks |
| GLOBlit_6567 |  | block_search_adv, search_blocks |
| GLOBlit_6598 |  | block_search_adv, search_blocks |
| GLOBlit_6791 |  | block_search_adv, search_blocks |
| GLOBlit_6838 |  | block_search_adv, search_blocks |
| GLOBlit_6957 |  | block_search_adv, search_blocks |
| GLOBlit_7168 |  | block_search_adv, search_blocks |
| GLOBlit_7178 |  | block_search_adv, search_blocks |
| GLOBlit_7184 |  | block_search_adv, search_blocks |
| GLOBlit_7368 |  | block_search_adv, search_blocks |
| GLOBlit_7448 |  | block_search_adv, search_blocks |
| GLOBlit_7648 |  | search_blocks |
| GLOBlit_7676 |  | search_blocks |
| GLOBlit_7681 |  | search_blocks |
| GLOBlit_7699 |  | search_blocks |
| GLOBlit_8774 |  | search_blocks |
| GLOBlit_369 |  | block_search_adv |
| GLOBlit_559 |  | block_search_adv |
| GLOBlit_2764 |  | block_search_adv |
| GLOBlit_8363 |  | search_blocks |
| GLOBlit_8483 |  | search_blocks |
| GLOBlit_8529 |  | search_blocks |
| GLOBlit_8797 |  | search_blocks |
| GLOBlit_8899 |  | search_blocks |
| GLOBlit_8902 |  | search_blocks |
| GLOBlit_8595 |  | search_blocks |
| GLOBlit_8647 |  | search_blocks |
| GLOBlit_9642 |  | search_blocks |

#### Measurements (28 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_8 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_140 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_497 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_234 | Viscosity, Pa*s | resolve_measurement_ids, search_blocks |
| GLOBmeas_1532 |  | resolve_measurement_ids |
| GLOBmeas_2055 |  | resolve_measurement_ids |
| GLOBmeas_2250 |  | resolve_measurement_ids |
| GLOBmeas_1930 |  | resolve_measurement_ids |
| GLOBmeas_1676 |  | resolve_measurement_ids |
| GLOBmeas_129 |  | resolve_measurement_ids |
| GLOBmeas_693 |  | resolve_measurement_ids |
| GLOBmeas_1673 |  | resolve_measurement_ids |
| GLOBmeas_1345 |  | resolve_measurement_ids |
| GLOBmeas_1620 |  | resolve_measurement_ids |
| GLOBmeas_75 |  | resolve_measurement_ids |
| GLOBmeas_1574 |  | resolve_measurement_ids |
| GLOBmeas_645 |  | resolve_measurement_ids |
| GLOBmeas_1008 |  | resolve_measurement_ids |
| GLOBmeas_499 |  | resolve_measurement_ids |
| GLOBmeas_1387 |  | resolve_measurement_ids |
| GLOBmeas_1082 |  | resolve_measurement_ids |
| GLOBmeas_51 |  | resolve_measurement_ids |
| GLOBmeas_1376 |  | resolve_measurement_ids |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_2 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Properties | 2 |
| Unique References | 62 |
| Unique Measurements | 28 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 59 |
| Unique parent blocks | 60 |
| Explicit block/subsystem targets | 60 |
| Subsystem targets | 0 |
| Target-matched data points | 1,200 |

---

## 3. DOI & Block References

**Unique DOIs:** 59  |  **Parent blocks:** 60  |  **Explicit targets:** 60  |  **Subsystems:** 0  |  **Target-matched datapoints:** 283

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-005-8089-2 | 1 | 23 | unary | search_blocks |
| 10.1016/j.fluid.2005.05.012 | 1 | 3 | unary | search_blocks |
| 10.1016/j.fluid.2005.07.010 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2006.01.008 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2006.01.030 | 2 | 23 | unary | search_blocks |
| 10.1016/j.fluid.2007.03.021 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2016.08.022 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.04.019 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2005.06.011 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.07.008 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2005.10.022 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2005.12.010 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2006.03.010 | 1 | 2 | unary | search_blocks |
| 10.1016/j.jct.2006.03.018 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2006.06.008 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2007.05.004 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2008.03.013 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2008.04.006 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2009.06.023 | 1 | 11 | unary | search_blocks |
| 10.1016/j.jct.2010.03.022 | 1 | 23 | unary | search_blocks |
| 10.1016/j.jct.2012.02.027 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2012.08.024 | 1 | 7 | unary | search_blocks |
| 10.1016/j.jct.2012.10.008 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2013.09.006 | 1 | 3 | unary | search_blocks |
| 10.1016/j.jct.2013.09.044 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2013.11.026 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2015.04.027 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2015.08.036 | 1 | 5 | unary | search_blocks |
| 10.1016/j.jct.2016.12.036 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2017.07.022 | 1 | 7 | unary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2019.02.019 | 1 | 4 | unary | search_blocks |
| 10.1016/j.jct.2019.04.023 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b00152 | 1 | 27 | unary | search_blocks |
| 10.1021/acs.jced.5b00162 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.5b00259 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b00365 | 1 | 7 | unary | search_blocks |
| 10.1021/acs.jced.5b01000 | 1 | 3 | unary | search_blocks |
| 10.1021/acs.jced.6b00096 | 1 | 2 | unary | search_blocks |
| 10.1021/acs.jced.6b00563 | 1 | 3 | unary | search_blocks |
| 10.1021/acs.jced.7b00267 | 1 | 9 | unary | search_blocks |
| 10.1021/acs.jced.7b00299 | 1 | 2 | unary | search_blocks |
| 10.1021/acs.jced.7b00321 | 1 | 4 | unary | search_blocks |
| 10.1021/acs.jced.7b00944 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00086 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00793 | 1 | 4 | unary | search_blocks |
| 10.1021/acs.jced.8b00939 | 1 | 1 | unary | search_blocks |
| 10.1021/acs.jced.8b00965 | 1 | 5 | unary | search_blocks |
| 10.1021/acs.jced.8b01012 | 1 | 4 | unary | search_blocks |
| 10.1021/je049556i | 1 | 3 | unary | search_blocks |
| 10.1021/je049808f | 1 | 1 | unary | search_blocks |
| 10.1021/je049912x | 1 | 2 | unary | search_blocks |
| 10.1021/je0500633 | 1 | 3 | unary | search_blocks |
| 10.1021/je0501639 | 1 | 3 | unary | search_blocks |
| 10.1021/je050416y | 1 | 7 | unary | search_blocks |
| 10.1021/je050463q | 1 | 6 | unary | search_blocks |
| 10.1021/je060123k | 1 | 3 | unary | search_blocks |
| 10.1021/je060126x | 1 | 1 | unary | search_blocks |
| 10.1021/je200707b | 1 | 5 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-005-8089-2 | PROPblock_1 | declared | 23 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.05.012 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2005.07.010 | PROPblock_9 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.008 | PROPblock_11 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.030 | PROPblock_1 | declared | 20 | unary | — | search_blocks |
| 10.1016/j.fluid.2006.01.030 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.fluid.2007.03.021 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2016.08.022 | PROPblock_6 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.04.019 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.06.011 | PROPblock_26 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.07.008 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.10.022 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2005.12.010 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.03.010 | PROPblock_7 | declared | 2 | unary | — | search_blocks |
| 10.1016/j.jct.2006.03.018 | PROPblock_6 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2006.06.008 | PROPblock_13 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2007.05.004 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2008.03.013 | PROPblock_5 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2008.04.006 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2009.06.023 | PROPblock_1 | declared | 11 | unary | — | search_blocks |
| 10.1016/j.jct.2010.03.022 | PROPblock_2 | declared | 23 | unary | — | search_blocks |
| 10.1016/j.jct.2012.02.027 | PROPblock_11 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2012.08.024 | PROPblock_4 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2012.10.008 | PROPblock_6 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2013.09.006 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1016/j.jct.2013.09.044 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.11.026 | PROPblock_17 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2015.04.027 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2015.08.036 | PROPblock_2 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.jct.2016.12.036 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2017.07.022 | PROPblock_2 | declared | 7 | unary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_3 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2019.02.019 | PROPblock_6 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.jct.2019.04.023 | PROPblock_5 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00152 | PROPblock_10 | declared | 27 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00162 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00259 | PROPblock_6 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b00365 | PROPblock_4 | declared | 7 | unary | — | search_blocks |
| 10.1021/acs.jced.5b01000 | PROPblock_12 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00096 | PROPblock_2 | declared | 2 | unary | — | search_blocks |
| 10.1021/acs.jced.6b00563 | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00267 | PROPblock_2 | declared | 9 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00299 | PROPblock_2 | declared | 2 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00321 | PROPblock_10 | declared | 4 | unary | — | search_blocks |
| 10.1021/acs.jced.7b00944 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00086 | PROPblock_17 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00793 | PROPblock_2 | declared | 4 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00939 | PROPblock_12 | declared | 1 | unary | — | search_blocks |
| 10.1021/acs.jced.8b00965 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1021/acs.jced.8b01012 | PROPblock_6 | declared | 4 | unary | — | search_blocks |
| 10.1021/je049556i | PROPblock_3 | declared | 3 | unary | — | search_blocks |
| 10.1021/je049808f | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1021/je049912x | PROPblock_4 | declared | 2 | unary | — | search_blocks |
| 10.1021/je0500633 | PROPblock_1 | declared | 3 | unary | — | search_blocks |
| 10.1021/je0501639 | PROPblock_2 | declared | 3 | unary | — | search_blocks |
| 10.1021/je050416y | PROPblock_7 | declared | 7 | unary | — | search_blocks |
| 10.1021/je050463q | PROPblock_1 | declared | 6 | unary | — | search_blocks |
| 10.1021/je060123k | PROPblock_10 | declared | 3 | unary | — | search_blocks |
| 10.1021/je060126x | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1021/je200707b | PROPblock_5 | declared | 5 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve ethanol to … | 236 | KEEP | 236 | 4.6 |
| 2 | 1 | `resolve_property_ids` | limit=5, min_score=70, purpose=Confirm property ID… | 433 | KEEP | 433 | 4.7 |
| 3 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_2 AS eth'], explanati… | 784 | DISCARD | 723 | 16.5 |
| 4 | 7 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 1,111 | KEEP | 1111 | 20.6 |
| 5 | 7 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 1,155 | KEEP | 1125 | 12.3 |
| 6 | 8 | `resolve_measurement_ids` | purpose=Identify measurement method n…, queries=['… | 349 | KEEP | 349 | 5.2 |
| 7 | 1 | `L1_query` | context=User wants to know how viscos…, id_catalog… | 270 | — | — | 197.6 |
| 8 | 1 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 839 | KEEP | 755 | 20.2 |
| 9 | 2 | `resolve_measurement_ids` | purpose=Resolve measurement method ID…, queries=['… | 729 | KEEP | 729 | 5.4 |
| 10 | 2 | `L1_query` | context=Previous query found 50 dynam…, id_catalog… | 706 | — | — | 102.2 |
| 11 | 1 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 144 | KEEP | 832 | 30.4 |
| 12 | 1 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 862 | — | — | 11.1 |
| 13 | 2 | `search_blocks` | compound=GLOBcomp_2, limit=50, property=GLOBprop_4… | 144 | KEEP | 1098 | 24.3 |
| 14 | 5 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_2 AS ethan…, explanat… | 924 | KEEP | 924 | 29.8 |
| 15 | 6 | `search_blocks` | compound=GLOBcomp_2, limit=10, measurement=GLOBmea… | 1,113 | KEEP | 1139 | 19.0 |
| 16 | 6 | `search_blocks` | compound=GLOBcomp_2, limit=10, measurement=GLOBmea… | 1,154 | KEEP | 473 | 12.9 |
| 17 | 6 | `resolve_measurement_ids` | purpose=Find other viscometry method …, queries=['… | 1,470 | KEEP | 1470 | 11.0 |
| 18 | 7 | `search_blocks` | compound=GLOBcomp_2, limit=20, measurement=['GLOBm… | 485 | — | — | 21.8 |
| 19 | 3 | `L1_query` | context=User asks what measurement me…, id_catalog… | 23,599 | — | — | 307.2 |
| | | **TOTAL (19 tools)** | | **36,507** | | **11,397** | **856.8** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,849 | 4,849 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 10,500 | 10,500 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 589 | 10,194 | 1,285 | 7.9 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,111 | 21,754 | 1,127 | 7.6 |
| 3 | L1-worker | claudeopus46 | 2,065 | 377 | 2,442 | 439 | 4.1 |
| 4 | L1-worker | claudeopus46 | 2,065 | 495 | 2,560 | 660 | 4.5 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,415 | 23,058 | 1,864 | 12.4 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,615 | 24,258 | 1,161 | 7.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 4,382 | 25,025 | 978 | 7.9 |
| 8 | L1-worker | claudeopus46 | 20,643 | 5,262 | 25,905 | 1,508 | 10.2 |
| 9 | L1-worker | claudeopus46 | 20,643 | 6,078 | 26,721 | 1,874 | 11.5 |
| 10 | L1-worker | claudeopus46 | 2,065 | 1,071 | 3,136 | 1,875 | 10.5 |
| 11 | L1-worker | claudeopus46 | 20,610 | 6,219 | 26,829 | 539 | 4.5 |
| 12 | L1-worker | claudeopus46 | 20,643 | 5,466 | 26,109 | 1,576 | 9.5 |
| 13 | L1-worker | claudeopus46 | 2,065 | 27,327 | 29,392 | 1,688 | 13.3 |
| 14 | L1-worker | claudeopus46 | 2,065 | 1,892 | 3,957 | 1,707 | 11.9 |
| 15 | L1-worker | claudeopus46 | 20,643 | 8,436 | 29,079 | 809 | 6.1 |
| 16 | L1-worker | claudeopus46 | 2,065 | 496 | 2,561 | 733 | 5.1 |
| 17 | L1-worker | claudeopus46 | 20,643 | 9,341 | 29,984 | 3,849 | 26.5 |
| 18 | L1-worker | claudeopus46 | 1,356 | 3,428 | 4,784 | 1,019 | 6.1 |
| 19 | L1-worker | claudeopus46 | 536 | 3,308 | 3,844 | 1,083 | 6.9 |
| 20 | L1-worker | claudeopus46 | 298 | 1,401 | 1,699 | 1,007 | 3.6 |
| 21 | L1-worker | claudeopus46 | 1,323 | 18,031 | 19,354 | 2,562 | 11.2 |
| 22 | L1-worker | claudeopus46 | 298 | 3,284 | 3,582 | 2,099 | 8.4 |
| 23 | L1-worker | claudeopus46 | 747 | 54,205 | 54,952 | 836 | 8.4 |
| 24 | L0-main | claudeopus46 | 9,605 | 38,928 | 48,533 | 2,175 | 14.1 |
| 25 | L1-worker | claudeopus46 | 20,643 | 39,115 | 59,758 | 1,264 | 8.6 |
| 26 | L1-worker | claudeopus46 | 2,065 | 27,323 | 29,388 | 1,500 | 11.2 |
| 27 | L1-worker | claudeopus46 | 20,643 | 40,512 | 61,155 | 1,232 | 8.2 |
| 28 | L1-worker | claudeopus46 | 2,065 | 870 | 2,935 | 983 | 5.2 |
| 29 | L1-worker | claudeopus46 | 20,643 | 41,859 | 62,502 | 4,362 | 26.2 |
| 30 | L1-worker | claudeopus46 | 536 | 3,231 | 3,767 | 825 | 4.5 |
| 31 | L1-worker | claudeopus46 | 1,356 | 3,351 | 4,707 | 1,017 | 5.4 |
| 32 | L1-worker | claudeopus46 | 1,323 | 7,476 | 8,799 | 2,474 | 10.2 |
| 33 | L1-worker | claudeopus46 | 298 | 3,196 | 3,494 | 2,098 | 8.1 |
| 34 | L1-worker | claudeopus46 | 1,160 | 10,579 | 11,739 | 2,098 | 8.1 |
| 35 | L1-worker | claudeopus46 | 747 | 38,111 | 38,858 | 607 | 6.1 |
| 36 | L0-main | claudeopus46 | 9,605 | 40,322 | 49,927 | 1,854 | 15.5 |
| 37 | L1-worker | claudeopus46 | 20,643 | 39,227 | 59,870 | 2,049 | 11.7 |
| 38 | L1-worker | claudeopus46 | 2,065 | 27,313 | 29,378 | 1,282 | 10.4 |
| 39 | L1-worker | claudeopus46 | 2,065 | 27,523 | 29,588 | 1,305 | 12.0 |
| 40 | L1-worker | claudeopus46 | 2,065 | 1,874 | 3,939 | 1,423 | 10.7 |
| 41 | L1-worker | claudeopus46 | 20,643 | 40,998 | 61,641 | 933 | 6.0 |
| 42 | L1-worker | claudeopus46 | 2,065 | 27,305 | 29,370 | 1,302 | 11.1 |
| 43 | L1-worker | claudeopus46 | 2,065 | 27,515 | 29,580 | 1,319 | 11.7 |
| 44 | L1-worker | claudeopus46 | 20,643 | 41,698 | 62,341 | 1,965 | 12.6 |
| 45 | L1-worker | claudeopus46 | 20,643 | 42,605 | 63,248 | 2,091 | 14.6 |
| 46 | L1-worker | claudeopus46 | 20,643 | 43,461 | 64,104 | 1,778 | 11.9 |
| 47 | L1-worker | claudeopus46 | 2,065 | 31,549 | 33,614 | 2,098 | 15.4 |
| 48 | L1-worker | claudeopus46 | 20,643 | 44,086 | 64,729 | 2,646 | 16.4 |
| 49 | L1-worker | claudeopus46 | 2,065 | 5,920 | 7,985 | 1,386 | 11.5 |
| 50 | L1-worker | claudeopus46 | 2,065 | 5,850 | 7,915 | 1,468 | 12.3 |
| 51 | L1-worker | claudeopus46 | 2,065 | 1,794 | 3,859 | 2,083 | 10.4 |
| 52 | L1-worker | claudeopus46 | 20,610 | 49,420 | 70,030 | 513 | 5.5 |
| 53 | L1-worker | claudeopus46 | 20,643 | 48,665 | 69,308 | 2,169 | 18.4 |
| 54 | L1-worker | claudeopus46 | 2,065 | 11,509 | 13,574 | 1,992 | 14.1 |
| 55 | L1-worker | claudeopus46 | 20,643 | 49,923 | 70,566 | 3,530 | 21.2 |
| 56 | L1-worker | claudeopus46 | 1,356 | 3,132 | 4,488 | 1,227 | 5.8 |
| 57 | L1-worker | claudeopus46 | 536 | 3,012 | 3,548 | 1,133 | 6.6 |
| 58 | L1-worker | claudeopus46 | 1,323 | 18,204 | 19,527 | 1,514 | 8.7 |
| 59 | L1-worker | claudeopus46 | 298 | 2,236 | 2,534 | 1,254 | 8.9 |
| 60 | L1-worker | claudeopus46 | 747 | 40,034 | 40,781 | 838 | 9.1 |
| 61 | L0-main | claudeopus46 | 9,605 | 88,193 | 97,798 | 5,914 | 39.5 |
| 62 | L0-main | claudeopus46 | 1,356 | 4,944 | 6,300 | 1,303 | 7.1 |
| 63 | L0-main | claudeopus46 | 298 | 1,685 | 1,983 | 1,291 | 4.0 |
| 64 | L0-main | claudeopus46 | 1,323 | 35,562 | 36,885 | 5,219 | 28.4 |
| 65 | L0-main | claudeopus46 | 298 | 5,887 | 6,185 | 4,257 | 18.5 |


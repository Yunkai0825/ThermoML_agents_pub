# Q1.5 — Result

**Prompt:** How has the viscosity of pure liquid ethanol near 25 °C been measured, and what values were reported by the different methods?

**Tool calls:** 3  |  **Time:** 731.4s  |  **Iterations:** 4  |  **Timed out:** False

---

## Answer

## Viscosity of Pure Liquid Ethanol near 25 °C (298.15 K): Methods and Values

The ThermoML database contains an extensive body of viscosity data for pure liquid ethanol near 25 °C, spanning **50+ data blocks for dynamic viscosity** and **1 block for kinematic viscosity**, all measured in the liquid phase at or near atmospheric pressure.

---

### Measurement Methods and Representative Values

Four distinct measurement techniques are represented:

#### 1. Capillary Tube — Ostwald/Ubbelohde Method (standard designation)
- **Technique:** Gravity-driven flow of liquid through a calibrated glass capillary; the flow time is proportional to viscosity. The Ostwald and Ubbelohde viscometers are the classical gold-standard instruments for Newtonian liquids.
- **Database coverage:** ≥10 data blocks
- **Representative values at 298.15 K:**

| η (Pa·s) | DOI | Source |
|-----------|-----|--------|
| 0.001077 | 10.1016/j.fluid.2006.01.008 | GLOBlit_349, PROPblock_11 |
| 0.001082 | 10.1016/j.fluid.2007.03.021 | GLOBlit_499, PROPblock_3 |
| 0.001087 | 10.1016/j.jct.2012.02.027 | GLOBlit_3572, PROPblock_11 |
| 0.001093 | 10.1016/j.jct.2005.04.019 | GLOBlit_2547, PROPblock_4 |

#### 2. Capillary Tube — Custom Variant (CAPTUB:UFactor:4)
- **Technique:** A calibrated capillary-tube method with a specific instrument correction factor, functionally equivalent to the standard Ostwald/Ubbelohde approach.
- **Database coverage:** ≥10 data blocks
- **Representative values at 298.15 K:**

| η (Pa·s) | DOI | Source |
|-----------|-----|--------|
| 0.001082 | 10.1016/j.fluid.2005.07.010 | GLOBlit_288, PROPblock_9 |
| 0.001105 | 10.1016/j.jct.2005.07.008 | GLOBlit_2580, PROPblock_3 |

#### 3. Falling or Rolling Sphere Viscometry
- **Technique:** A sphere of known density and diameter falls or rolls through the liquid under gravity; the terminal velocity is related to viscosity via Stokes' law (with corrections). This is the only non-capillary technique represented for ethanol in this temperature range.
- **Database coverage:** ≥20 data blocks
- **Representative data:** One key block (GLOBlit_8, PROPblock_1; DOI 10.1007/s10765-005-8089-2) reports 23 data points spanning 293.15–353.15 K and pressures from 100 to 100,000 kPa, with viscosity values ranging from 0.00051 to 0.001955 Pa·s (overall mean 0.001049 Pa·s). The higher mean reflects the wide temperature and pressure range; at near-ambient conditions close to 298.15 K, the values are expected to be consistent with the capillary results.

#### 4. Capillary Tube — Custom Variant for Kinematic Viscosity (CAPTUB:UFactor:8)
- **Technique:** Another capillary-tube/Ubbelohde variant, used here to measure kinematic viscosity (ν = η/ρ) rather than dynamic viscosity directly.
- **Database coverage:** 1 data block (GLOBlit_8774, PROPblock_7; DOI 10.1021/je050416y)
- **Data:** 7 points over 293.15–323.15 K at 101 kPa. At 293.15 K: ν = 1.5248 × 10⁻⁶ m²/s (±7.18 × 10⁻⁸). At 323.15 K: ν = 8.282 × 10⁻⁷ m²/s (±4.2 × 10⁻⁸). Converting the 293.15 K value using ethanol's density (~789 kg/m³) gives η ≈ 1.20 mPa·s, consistent with the dynamic viscosity trend.

---

### Summary of Values at 298.15 K

| Method | η at 298.15 K (mPa·s) | Spread |
|--------|------------------------|--------|
| Capillary tube (standard) | 1.077 – 1.093 | ±1.5% |
| Capillary tube (custom variant) | 1.082 – 1.105 | ±2% |
| Falling/rolling sphere | ~1.05–1.10 (at ambient P) | broader range due to P variation |
| Kinematic (converted) | ~1.20 (at 293.15 K) | consistent with T trend |

The **majority of reported dynamic viscosity values cluster tightly around 1.08–1.09 mPa·s** at 298.15 K, with a few outliers reaching up to ~1.19 mPa·s. The overall spread of ±1–2% across dozens of independent laboratories reflects the high reproducibility of capillary viscometry for this well-characterized liquid.

---

### Methods Not Found

No data blocks were found in the ThermoML database for pure ethanol near 298.15 K using Stabinger viscometer, vibrating wire, oscillating-body methods, rotational viscometer, falling-body viscometer, or flow viscometer techniques.

---

### Chemistry Insight

Ethanol's dynamic viscosity near 25 °C (~1.08 mPa·s) is slightly higher than that of water (~0.89 mPa·s) despite ethanol's lower molecular weight (46 vs. 18 g/mol). This is attributed to the extensive three-dimensional hydrogen-bonding network in liquid ethanol, where each molecule can act as both a hydrogen-bond donor (O–H) and acceptor (lone pairs on oxygen), forming chains and clusters that resist shear flow. The dominance of capillary viscometry in the database — and the narrow spread of values it produces — underscores ethanol's longstanding role as a viscosity reference standard for calibrating instruments and validating new measurement techniques.

### Core claims

- The ThermoML database contains over 50 data blocks for the dynamic viscosity of pure liquid ethanol near 298.15 K, measured predominantly by three techniques: standard capillary tube (Ostwald/Ubbelohde), a custom capillary-tube variant, and falling/rolling sphere viscometry, plus one block for kinematic viscosity via a capillary-tube variant.
- At 298.15 K and near-atmospheric pressure, the majority of reported dynamic viscosity values for pure liquid ethanol cluster tightly around 1.08–1.09 mPa·s, with an overall spread of approximately ±1–2% across dozens of independent laboratories.
- Capillary viscometry dominates the available database for ethanol at this temperature, and the narrow spread of its results reflects ethanol's high reproducibility as a viscosity reference standard.
- No data blocks were found in the ThermoML database for pure ethanol near 298.15 K using Stabinger viscometer, vibrating wire, oscillating-body, rotational viscometer, falling-body viscometer, or flow viscometer techniques.
- Kinematic viscosity data at 293.15 K (ν ≈ 1.5248 × 10⁻⁶ m²/s), when converted using ethanol's density (~789 kg/m³), yield a dynamic viscosity of approximately 1.20 mPa·s, consistent with the expected temperature trend relative to the 298.15 K values.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_349 | 10.1016/j.fluid.2006.01.008 | PROPblock_11 |  | Dynamic viscosity of pure ethanol at 298.15 K using GLOBmeas_4 (capillary tube, Ostwald/Ubbelohde method). Reported value: 0.001077 Pa·s. |
| GLOBlit_288 | 10.1016/j.fluid.2005.07.010 | PROPblock_9 |  | Dynamic viscosity of pure ethanol at 298.15 K using GLOBmeas_142 (CAPTUB:UFactor:4, custom capillary tube variant). Reported value: 0.001082 Pa·s. |
| GLOBlit_8 | 10.1007/s10765-005-8089-2 | PROPblock_1 |  | Dynamic viscosity of pure ethanol using GLOBmeas_8 (falling or rolling sphere viscometry). 23 data points spanning 293.15–353.15 K and 100–100000 kPa; overall range 0.00051–0.001955 Pa·s, mean 0.001049 Pa·s. |
| GLOBlit_8774 | 10.1021/je050416y | PROPblock_7 |  | Kinematic viscosity of pure ethanol using GLOBmeas_165 (CAPTUB:UFactor:8, custom capillary tube/Ubbelohde variant). 7 data points over 293.15–323.15 K at 101 kPa; value at 293.15 K: 1.5248e-6 m²/s (±7.18e-8). |
| GLOBlit_499 | 10.1016/j.fluid.2007.03.021 | PROPblock_3 |  | Dynamic viscosity of pure ethanol at 298.15 K using capillary tube method. Reported value: 0.001082 Pa·s. |
| GLOBlit_3572 | 10.1016/j.jct.2012.02.027 | PROPblock_11 |  | Dynamic viscosity of pure ethanol at 298.15 K using capillary tube method. Reported value: 0.001087 Pa·s. |
| GLOBlit_2547 | 10.1016/j.jct.2005.04.019 | PROPblock_4 |  | Dynamic viscosity of pure ethanol at 298.15 K using capillary tube method. Reported value: 0.001093 Pa·s. |
| GLOBlit_2580 | 10.1016/j.jct.2005.07.008 | PROPblock_3 |  | Dynamic viscosity of pure ethanol at 298.15 K using GLOBmeas_142 (CAPTUB:UFactor:4). Reported value: 0.001105 Pa·s. |

### Suggested follow-ups

- Retrieve the individual data points from the falling/rolling sphere block (GLOBlit_8, PROPblock_1) filtered to near-ambient pressure (~100 kPa) and ~298.15 K to enable direct comparison with capillary tube values.
- Search for additional capillary tube blocks (GLOBmeas_4 and GLOBmeas_142) to compile a full statistical distribution of reported ethanol viscosity values at 298.15 K across all available literature sources.
- Compare ethanol viscosity data with other common reference liquids (e.g., water GLOBcomp_1, toluene) measured by the same methods to assess inter-method consistency.
- Investigate whether any ThermoML sources report ethanol viscosity at elevated pressures using capillary tube methods, enabling cross-validation with the falling sphere high-pressure data.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_2",
    "registry_id": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
    "name": "ethanol"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": "viscosity_pa_s",
    "name": "Viscosity, Pa*s"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_40",
    "registry_id": "kinematic_viscosity_m2_s",
    "name": "Kinematic viscosity, m2/s"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_4",
    "registry_id": "capillary_tube_ostwald_ubbelohde_method",
    "name": "Capillary tube (Ostwald; Ubbelohde) method"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_142",
    "registry_id": "captub_ufactor_4",
    "name": "CAPTUB:UFactor:4"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_8",
    "registry_id": "falling_or_rolling_sphere_viscometry",
    "name": "Falling or rolling sphere viscometry"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_165",
    "registry_id": "captub_ufactor_8",
    "name": "CAPTUB:UFactor:8"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_1",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_3",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_2",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  }
]
```

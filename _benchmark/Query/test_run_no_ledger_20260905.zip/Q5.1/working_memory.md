# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_6 | propan-2-ol | propan-2-ol |
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find viscosity data for isopropanol (2-propanol) + water binary mixtures → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "## Dynamic Viscosity Data for Propan-2-ol (Isopropanol) + Water Binary Mixtures\n\nTwo ThermoML data blocks were found containing dynamic viscosity (η, Pa·s) measurements for the propan-2-ol + water binary system:\n\n---\n\n### Block 1 — PROPblock_15\n- **DOI:** 10.1021/je700700f (GLOBlit_11042)\n- **Temperature:** 298.15 K (fixed)\n- **Pressure:** 101.0 kPa\n- **Composition range:** Full mole fraction range, x(propan-2-ol) = 0.0 to 1.0\n- **Data points:** 13\n- **Method:** Capillary viscometry (Ubbelohde)\n\n**Complete dataset at 298.15 K:**\n\n| x(propan-2-ol) | η (Pa·s) |\n|---|---|\n| 0.0000 | 0.000890 |\n| 0.0201 | 0.001190 |\n| 0.0526 | 0.001700 |\n| 0.1000 | 0.002530 |\n| 0.1500 | 0.003180 |\n| 0.2000 | 0.003660 |\n| 0.3000 | 0.003880 |\n| 0.4000 | 0.003640 |\n| 0.5000 | 0.003250 |\n| 0.6000 | 0.002870 |\n| 0.7000 | 0.002530 |\n| 0.8000 | 0.002260 |\n| 1.0000 | 0.002040 |\n\n**Chemistry insight:** The data show the classic viscosity maximum characteristic of alcohol–water mixtures. The viscosity peaks near x(propan-2-ol) ≈ 0.3 at η ≈ 0.00388 Pa·s, which is roughly 4.4× the viscosity of pure water (0.000890 Pa·s) and about 1.9× that of pure propan-2-ol (0.002040 Pa·s). This maximum arises from enhanced hydrogen-bonding networks and microheterogeneity in the water-rich region, where hydrophobic hydration of the isopropyl group creates structured water cages that resist flow.\n\n---\n\n### Block 2 — PROPblock_12\n- **DOI:** 10.1016/j.jct.2019.105880 (GLOBlit_5585)\n- **Temperature range:** 288.15–303.15 K\n- **Pressure:** 100.0 kPa\n- **Composition range:** Mass fraction w(propan-2-ol) = 0.1–0.3\n- **Data points:** 12\n- **Method:** Falling/rolling sphere viscometry\n\nThis block provides temperature-dependent viscosity data in the water-rich composition region, complementing the isothermal full-range data from Block 1.\n\n---\n\n**Compounds:** propan-2-ol (GLOBcomp_6, C₃H₈O, CAS 67-63-0) and water (GLOBcomp_1, H₂O, CAS 7732-18-5). Property: dynamic viscosity (GLOBprop_4, Pa·s).",
  "core_claims": [
    "At 298.15 K and 101.0 kPa, dynamic viscosity data for propan-2-ol + water mixtures across the full mole fraction range exhibit a classic viscosity maximum near x(propan-2-ol) ≈ 0.3, reaching approximately 0.00388 Pa·s—about 4.4 times the viscosity of pure water and 1.9 times that of pure propan-2-ol.",
    "The viscosity maximum is attributed to enhanced hydrogen-bonding networks and microheterogeneity in the water-rich region, where hydrophobic hydration of the isopropyl group creates structured water cages that resist flow.",
    "A second, complementary dataset covers the water-rich composition region (mass fraction 0.1–0.3 propan-2-ol) over a temperature range of 288.15–303.15 K at 100.0 kPa, providing temperature-dependent viscosity information."
  ],
  "status": "success",
  "summary": "Dynamic viscosity (Pa·s) data for the propan-2-ol (CAS 67-63-0) + water (CAS 7732-18-5) binary system were found in two ThermoML blocks. Block 1 (DOI 10.1021/je700700f) provides 13 data points at 298.15 K and 101.0 kPa spanning the full mole-fraction range x(propan-2-ol) = 0–1, measured by Ubbelohde capillary viscometry; a classic viscosity maximum of ~0.00388 Pa·s occurs near x ≈ 0.3, roughly 4.4× the pure-water value and 1.9× the pure-propan-2-ol value, attributed to enhanced hydrogen-bonding networks and hydrophobic hydration. Block 2 (DOI 10.1016/j.jct.2019.105880) supplies 12 data points in the water-rich region (mass fraction 0.1–0.3) over 288.15–303.15 K at 100.0 kPa, measured by falling/rolling sphere viscometry, providing complementary temperature-dependent information.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_6",
      "registry_id": "propan-2-ol",
      "name": "propan-2-ol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_11042",
      "block_number": "PROPblock_15",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_6",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for propan-2-ol + water binary system at 298.15 K and 101.0 kPa, spanning the full mole fraction range x(propan-2-ol) = 0.0–1.0 (13 data points). Measured by capillary (Ubbelohde) viscometry. DOI: 10.1021/je700700f.",
      "doi": "10.1021/je700700f",
      "lit_id": "2008-gon-cal-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 13,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_4",
          "meas_ID": "capillary_tube_ostwald_ubbelohde_method",
          "method_standard": "Capillary tube (Ostwald; Ubbelohde) method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.00089,
            "max": 0.003087,
            "mean": 0.002306,
            "std": 0.000598,
            "n": 13
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.00089,
          "range_max": 0.003087
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 13,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_5585",
      "block_number": "PROPblock_12",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_1",
        "GLOBcomp_6"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Dynamic viscosity (Pa·s) for propan-2-ol + water binary system over 288.15–303.15 K at 100.0 kPa, mass fraction w(propan-2-ol) = 0.1–0.3 (12 data points). Measured by falling/rolling sphere viscometry. DOI: 10.1016/j.jct.2019.105880.",
      "doi": "10.1016/j.jct.2019.105880",
      "lit_id": "2019-meh-haj-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 12,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 100.0,
          "digits": 1,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 288.15,
            "max": 303.15,
            "n_unique": 4
          },
          "range_min": 288.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_5",
          "var_id": "mass_fraction_DOIcomp_3",
          "name": "Mass fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mass fraction",
            "min": 0.1,
            "max": 0.3,
            "n_unique": 3
          },
          "range_min": 0.1,
          "range_max": 0.3
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_8",
          "meas_ID": "falling_or_rolling_sphere_viscometry",
          "method_standard": "Falling or rolling sphere viscometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.001208,
            "max": 0.004014,
            "mean": 0.002279,
            "std": 0.000823,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.001208,
          "range_max": 0.004014
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


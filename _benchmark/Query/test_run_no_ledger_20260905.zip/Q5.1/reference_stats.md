# Reference Stats — query-agent

**Run started:** 2026-08-02 19:34:47
**Wall time (at last flush):** 246.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 58,814 | 15,761 | 81,001 | 16,200 | 83.8 | claudeopus46 |
| L1-worker | 15 | 132,811 | 64,885 | 33,366 | 197,696 | 13,179 | 183.2 | claudeopus46 |
| **TOTAL** | **20** | **154,998** | **123,699** | **49,127** | **278,697** | **13,934** | **267.0** | |

**Estimated tokens:** ~69,674 input + ~12,281 output = ~81,955 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 2 | 2 | 2 | 25 |
| **TOTAL** | **4** | **1** | **3** | **2** | **2** | **2** | **25** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_6 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### References (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_5585 |  | search_blocks |
| GLOBlit_11042 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique References | 2 |
| Unique Properties | 1 |
| Unique Measurements | 2 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Total DOIs | 2 |
| Unique parent blocks | 2 |
| Explicit block/subsystem targets | 2 |
| Subsystem targets | 0 |
| Target-matched data points | 25 |

---

## 3. DOI & Block References

**Unique DOIs:** 2  |  **Parent blocks:** 2  |  **Explicit targets:** 2  |  **Subsystems:** 0  |  **Target-matched datapoints:** 25

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2019.105880 | 1 | 12 | binary | search_blocks |
| 10.1021/je700700f | 1 | 13 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2019.105880 | PROPblock_12 | declared | 12 | binary | — | search_blocks |
| 10.1021/je700700f | PROPblock_15 | declared | 13 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 243 | KEEP | 243 | 4.3 |
| 2 | 3 | `search_blocks` | compound=['GLOBcomp_6', 'GLOBcomp_1'], limit=50, p… | 1,101 | KEEP | 1070 | 14.1 |
| 3 | 1 | `L1_query` | context=, id_catalog=, instruction=Search for dyna… | 15,627 | — | — | 166.5 |
| | | **TOTAL (3 tools)** | | **16,971** | | **1,313** | **184.9** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,330 | 3,330 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 506 | 10,111 | 8,045 | 39.8 |
| 2 | L1-worker | claudeopus46 | 20,643 | 852 | 21,495 | 625 | 5.0 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,098 | 22,741 | 837 | 5.2 |
| 4 | L1-worker | claudeopus46 | 2,065 | 445 | 2,510 | 417 | 4.2 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,241 | 22,884 | 13,588 | 64.6 |
| 6 | L1-worker | claudeopus46 | 2,065 | 4,360 | 6,425 | 1,680 | 13.6 |
| 7 | L1-worker | claudeopus46 | 20,610 | 4,625 | 25,235 | 524 | 4.2 |
| 8 | L1-worker | claudeopus46 | 20,643 | 3,872 | 24,515 | 7,625 | 42.6 |
| 9 | L1-worker | claudeopus46 | 20,643 | 12,118 | 32,761 | 1,988 | 7.4 |
| 10 | L1-worker | claudeopus46 | 1,356 | 2,119 | 3,475 | 782 | 4.9 |
| 11 | L1-worker | claudeopus46 | 536 | 1,999 | 2,535 | 816 | 5.9 |
| 12 | L1-worker | claudeopus46 | 1,323 | 5,580 | 6,903 | 1,253 | 6.6 |
| 13 | L1-worker | claudeopus46 | 298 | 1,164 | 1,462 | 770 | 3.6 |
| 14 | L1-worker | claudeopus46 | 298 | 1,172 | 1,470 | 803 | 3.6 |
| 15 | L1-worker | claudeopus46 | 298 | 1,975 | 2,273 | 972 | 4.6 |
| 16 | L1-worker | claudeopus46 | 747 | 20,265 | 21,012 | 686 | 7.2 |
| 17 | L0-main | claudeopus46 | 9,605 | 32,413 | 42,018 | 2,396 | 17.7 |
| 18 | L0-main | claudeopus46 | 1,356 | 2,344 | 3,700 | 882 | 4.6 |
| 19 | L0-main | claudeopus46 | 1,323 | 20,438 | 21,761 | 2,445 | 14.2 |
| 20 | L0-main | claudeopus46 | 298 | 3,113 | 3,411 | 1,993 | 7.5 |


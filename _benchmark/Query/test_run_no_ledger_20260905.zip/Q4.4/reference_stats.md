# Reference Stats — query-agent

**Run started:** 2026-08-02 19:23:08
**Wall time (at last flush):** 948.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 32,090 | 123,170 | 51,985 | 155,260 | 22,180 | 250.1 | claudeopus46 |
| L1-worker | 76 | 635,318 | 381,721 | 141,850 | 1,017,039 | 13,382 | 769.2 | claudeopus46 |
| **TOTAL** | **83** | **667,408** | **504,891** | **193,835** | **1,172,299** | **14,124** | **1019.3** | |

**Estimated tokens:** ~293,074 input + ~48,458 output = ~341,532 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 1 | 3 | 3 | 171 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 2 | 0 | 0 |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 1 | 3 | 3 | 204 |
| **TOTAL** | **26** | **6** | **6** | **2** | **8** | **6** | **375** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (13 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_18 |  | resolve_compound_ids |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_31 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_47 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1061 |  | resolve_compound_ids |
| GLOBcomp_268 |  | resolve_compound_ids |
| GLOBcomp_3089 |  | resolve_compound_ids |
| GLOBcomp_3210 |  | resolve_compound_ids |
| GLOBcomp_3578 |  | resolve_compound_ids |
| GLOBcomp_2105 |  | resolve_compound_ids |
| GLOBcomp_3079 |  | resolve_compound_ids |
| GLOBcomp_4410 |  | resolve_compound_ids |
| GLOBcomp_4541 |  | resolve_compound_ids |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_blocks |

#### References (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2781 |  | block_search_adv, search_blocks |
| GLOBlit_5953 |  | block_search_adv, search_blocks |
| GLOBlit_11517 |  | search_blocks |
| GLOBlit_8238 |  | search_blocks |
| GLOBlit_8242 |  | search_blocks |
| GLOBlit_9372 |  | search_blocks |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | resolve_ids, search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 13 |
| Unique Properties | 1 |
| Unique References | 6 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 6 |
| Unique parent blocks | 6 |
| Explicit block/subsystem targets | 6 |
| Subsystem targets | 0 |
| Target-matched data points | 375 |

---

## 3. DOI & Block References

**Unique DOIs:** 6  |  **Parent blocks:** 6  |  **Explicit targets:** 6  |  **Subsystems:** 0  |  **Target-matched datapoints:** 375

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.12.012 | 1 | 120 | binary | search_blocks |
| 10.1016/j.tca.2011.08.013 | 1 | 16 | binary | search_blocks |
| 10.1021/je034073k | 1 | 65 | binary | search_blocks |
| 10.1021/je0340809 | 1 | 95 | binary | search_blocks |
| 10.1021/je100967k | 1 | 44 | binary | search_blocks |
| 10.1021/je9001027 | 1 | 35 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.12.012 | PROPblock_3 | declared | 120 | binary | — | search_blocks |
| 10.1016/j.tca.2011.08.013 | PROPblock_10 | declared | 16 | binary | — | search_blocks |
| 10.1021/je034073k | PROPblock_3 | declared | 65 | binary | — | search_blocks |
| 10.1021/je0340809 | PROPblock_17 | declared | 95 | binary | — | search_blocks |
| 10.1021/je100967k | PROPblock_17 | declared | 44 | binary | — | search_blocks |
| 10.1021/je9001027 | PROPblock_3 | declared | 35 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMF and wat… | 300 | KEEP | 300 | 3.9 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Confirm property ID… | 257 | KEEP | 257 | 6.8 |
| 3 | 1 | `L1_query` | instruction=Search for binary mixture vis…, purpos… | 381 | — | — | 94.4 |
| 4 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMSO and wa… | 239 | KEEP | 239 | 4.0 |
| 5 | 1 | `L1_query` | instruction=Search for binary mixture vis…, purpos… | 383 | — | — | 111.0 |
| 6 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve NMP and wat… | 242 | KEEP | 242 | 4.3 |
| 7 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Confirm property ID… | 248 | KEEP | 248 | 4.1 |
| 8 | 1 | `L1_query` | instruction=Search for binary mixture vis…, purpos… | 449 | — | — | 111.1 |
| 9 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMF and wat… | 300 | KEEP | 300 | 3.9 |
| 10 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Verify GLOBprop_4 i… | 259 | KEEP | 259 | 3.9 |
| 11 | 2 | `L1_query` | instruction=Search for dynamic viscosity …, purpos… | 416 | — | — | 169.5 |
| 12 | 1 | `resolve_compound_ids` | purpose=Resolve DMSO and water to glo…, queries=['… | 240 | KEEP | 240 | 3.8 |
| 13 | 1 | `resolve_property_ids` | purpose=Verify property ID for dynami…, queries=['… | 281 | KEEP | 281 | 4.5 |
| 14 | 2 | `search_blocks` | compound=['GLOBcomp_31', 'GLOBcomp_1'], limit=50, … | 996 | KEEP | 996 | 22.1 |
| 15 | 7 | `resolve_ids` | entity_type=variable, purpose=Resolve mole fractio… | 334 | KEEP | 334 | 4.8 |
| 16 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_3… | 1,006 | KEEP | 976 | 15.4 |
| 17 | 2 | `L1_query` | instruction=Search for dynamic viscosity …, purpos… | 22,867 | — | — | 148.2 |
| 18 | 1 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Find compound ID f… | 223 | KEEP | 223 | 6.0 |
| 19 | 2 | `search_blocks` | compound=['GLOBcomp_47', 'GLOBcomp_1'], limit=50, … | 1,508 | KEEP | 1508 | 17.9 |
| 20 | 2 | `L1_query` | instruction=Search for dynamic viscosity …, purpos… | 21,813 | — | — | 73.9 |
| | | **TOTAL (20 tools)** | | **52,742** | | **6,403** | **813.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 589 | 10,194 | 20,217 | 86.9 |
| 2 | L1-worker | claudeopus46 | 20,643 | 874 | 21,517 | 870 | 5.7 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,472 | 23,115 | 1,185 | 7.2 |
| 4 | L1-worker | claudeopus46 | 2,065 | 446 | 2,511 | 474 | 3.7 |
| 5 | L1-worker | claudeopus46 | 2,065 | 364 | 2,429 | 493 | 6.6 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,013 | 23,656 | 6,288 | 32.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 9,876 | 30,519 | 1,800 | 6.4 |
| 8 | L1-worker | claudeopus46 | 1,356 | 1,929 | 3,285 | 808 | 4.4 |
| 9 | L1-worker | claudeopus46 | 536 | 1,809 | 2,345 | 875 | 5.1 |
| 10 | L1-worker | claudeopus46 | 1,323 | 4,648 | 5,971 | 3,048 | 12.5 |
| 11 | L1-worker | claudeopus46 | 298 | 3,770 | 4,068 | 2,272 | 9.0 |
| 12 | L1-worker | claudeopus46 | 1,160 | 8,288 | 9,448 | 2,179 | 9.5 |
| 13 | L1-worker | claudeopus46 | 20,643 | 822 | 21,465 | 594 | 4.6 |
| 14 | L1-worker | claudeopus46 | 20,643 | 2,037 | 22,680 | 7,747 | 35.6 |
| 15 | L1-worker | claudeopus46 | 2,065 | 469 | 2,534 | 400 | 3.6 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,185 | 22,828 | 5,502 | 30.9 |
| 17 | L1-worker | claudeopus46 | 20,643 | 8,308 | 28,951 | 2,403 | 8.8 |
| 18 | L1-worker | claudeopus46 | 1,356 | 2,236 | 3,592 | 725 | 4.6 |
| 19 | L1-worker | claudeopus46 | 536 | 2,116 | 2,652 | 787 | 5.7 |
| 20 | L1-worker | claudeopus46 | 1,323 | 4,095 | 5,418 | 2,538 | 10.1 |
| 21 | L1-worker | claudeopus46 | 298 | 3,260 | 3,558 | 1,960 | 7.6 |
| 22 | L1-worker | claudeopus46 | 1,160 | 7,107 | 8,267 | 1,923 | 7.8 |
| 23 | L1-worker | claudeopus46 | 20,643 | 808 | 21,451 | 873 | 5.6 |
| 24 | L1-worker | claudeopus46 | 20,643 | 2,409 | 23,052 | 8,877 | 36.7 |
| 25 | L1-worker | claudeopus46 | 2,065 | 450 | 2,515 | 416 | 4.1 |
| 26 | L1-worker | claudeopus46 | 2,065 | 364 | 2,429 | 482 | 4.0 |
| 27 | L1-worker | claudeopus46 | 20,643 | 2,904 | 23,547 | 4,549 | 24.9 |
| 28 | L1-worker | claudeopus46 | 20,643 | 8,074 | 28,717 | 1,748 | 6.9 |
| 29 | L1-worker | claudeopus46 | 1,356 | 1,577 | 2,933 | 726 | 4.2 |
| 30 | L1-worker | claudeopus46 | 298 | 1,108 | 1,406 | 714 | 3.1 |
| 31 | L1-worker | claudeopus46 | 536 | 1,457 | 1,993 | 831 | 8.7 |
| 32 | L1-worker | claudeopus46 | 1,323 | 4,210 | 5,533 | 2,469 | 10.5 |
| 33 | L1-worker | claudeopus46 | 298 | 3,191 | 3,489 | 1,813 | 10.2 |
| 34 | L1-worker | claudeopus46 | 1,160 | 7,001 | 8,161 | 1,457 | 6.8 |
| 35 | L0-main | claudeopus46 | 9,605 | 2,604 | 12,209 | 15,402 | 72.5 |
| 36 | L1-worker | claudeopus46 | 20,643 | 821 | 21,464 | 977 | 6.0 |
| 37 | L1-worker | claudeopus46 | 20,643 | 2,526 | 23,169 | 10,819 | 53.3 |
| 38 | L1-worker | claudeopus46 | 2,065 | 446 | 2,511 | 474 | 3.8 |
| 39 | L1-worker | claudeopus46 | 2,065 | 364 | 2,429 | 455 | 3.7 |
| 40 | L1-worker | claudeopus46 | 20,643 | 3,083 | 23,726 | 13,299 | 55.6 |
| 41 | L1-worker | claudeopus46 | 20,643 | 17,003 | 37,646 | 3,902 | 23.7 |
| 42 | L1-worker | claudeopus46 | 536 | 2,369 | 2,905 | 754 | 4.9 |
| 43 | L1-worker | claudeopus46 | 1,356 | 2,489 | 3,845 | 941 | 5.0 |
| 44 | L1-worker | claudeopus46 | 298 | 1,323 | 1,621 | 929 | 3.7 |
| 45 | L1-worker | claudeopus46 | 1,323 | 5,203 | 6,526 | 2,070 | 9.8 |
| 46 | L1-worker | claudeopus46 | 298 | 2,792 | 3,090 | 1,513 | 6.6 |
| 47 | L1-worker | claudeopus46 | 1,160 | 7,815 | 8,975 | 902 | 5.8 |
| 48 | L1-worker | claudeopus46 | 20,643 | 820 | 21,463 | 957 | 6.3 |
| 49 | L1-worker | claudeopus46 | 2,065 | 448 | 2,513 | 422 | 3.6 |
| 50 | L1-worker | claudeopus46 | 2,065 | 366 | 2,431 | 531 | 4.3 |
| 51 | L1-worker | claudeopus46 | 20,643 | 1,931 | 22,574 | 771 | 6.4 |
| 52 | L1-worker | claudeopus46 | 2,065 | 7,501 | 9,566 | 1,702 | 14.4 |
| 53 | L1-worker | claudeopus46 | 20,643 | 3,446 | 24,089 | 1,278 | 9.8 |
| 54 | L1-worker | claudeopus46 | 20,643 | 4,341 | 24,984 | 940 | 7.4 |
| 55 | L1-worker | claudeopus46 | 20,643 | 5,168 | 25,811 | 1,004 | 7.3 |
| 56 | L1-worker | claudeopus46 | 20,643 | 6,028 | 26,671 | 830 | 6.1 |
| 57 | L1-worker | claudeopus46 | 20,643 | 6,722 | 27,365 | 515 | 5.8 |
| 58 | L1-worker | claudeopus46 | 2,065 | 402 | 2,467 | 595 | 4.6 |
| 59 | L1-worker | claudeopus46 | 20,643 | 5,798 | 26,441 | 1,175 | 8.3 |
| 60 | L1-worker | claudeopus46 | 2,065 | 2,346 | 4,411 | 2,081 | 13.6 |
| 61 | L1-worker | claudeopus46 | 20,643 | 7,346 | 27,989 | 1,740 | 12.0 |
| 62 | L1-worker | claudeopus46 | 1,356 | 1,871 | 3,227 | 1,194 | 6.6 |
| 63 | L1-worker | claudeopus46 | 536 | 1,751 | 2,287 | 1,027 | 6.8 |
| 64 | L1-worker | claudeopus46 | 1,323 | 11,934 | 13,257 | 2,141 | 10.5 |
| 65 | L1-worker | claudeopus46 | 298 | 1,576 | 1,874 | 1,182 | 4.4 |
| 66 | L1-worker | claudeopus46 | 298 | 2,863 | 3,161 | 1,631 | 6.7 |
| 67 | L1-worker | claudeopus46 | 747 | 33,891 | 34,638 | 936 | 9.1 |
| 68 | L1-worker | claudeopus46 | 20,643 | 24,200 | 44,843 | 640 | 5.9 |
| 69 | L1-worker | claudeopus46 | 2,065 | 1,257 | 3,322 | 586 | 5.3 |
| 70 | L1-worker | claudeopus46 | 20,643 | 24,870 | 45,513 | 746 | 6.0 |
| 71 | L1-worker | claudeopus46 | 2,065 | 8,465 | 10,530 | 1,773 | 17.5 |
| 72 | L1-worker | claudeopus46 | 20,643 | 26,861 | 47,504 | 2,109 | 12.8 |
| 73 | L1-worker | claudeopus46 | 1,356 | 2,068 | 3,424 | 920 | 4.8 |
| 74 | L1-worker | claudeopus46 | 536 | 1,948 | 2,484 | 982 | 5.7 |
| 75 | L1-worker | claudeopus46 | 1,323 | 5,534 | 6,857 | 1,625 | 7.8 |
| 76 | L1-worker | claudeopus46 | 298 | 1,302 | 1,600 | 908 | 3.5 |
| 77 | L1-worker | claudeopus46 | 298 | 2,347 | 2,645 | 1,245 | 7.8 |
| 78 | L1-worker | claudeopus46 | 747 | 26,409 | 27,156 | 803 | 8.4 |
| 79 | L0-main | claudeopus46 | 9,605 | 49,789 | 59,394 | 4,814 | 32.3 |
| 80 | L0-main | claudeopus46 | 1,356 | 4,313 | 5,669 | 1,211 | 7.4 |
| 81 | L0-main | claudeopus46 | 298 | 1,593 | 1,891 | 1,199 | 4.1 |
| 82 | L0-main | claudeopus46 | 1,323 | 58,570 | 59,893 | 5,044 | 26.2 |
| 83 | L0-main | claudeopus46 | 298 | 5,712 | 6,010 | 4,098 | 20.7 |


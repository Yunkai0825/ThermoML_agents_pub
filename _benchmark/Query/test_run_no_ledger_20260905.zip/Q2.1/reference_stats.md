# Reference Stats — query-agent

**Run started:** 2026-08-02 18:44:55
**Wall time (at last flush):** 476.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 166,745 | 19,080 | 208,440 | 26,055 | 109.6 | claudeopus46 |
| L1-worker | 41 | 298,765 | 454,353 | 78,637 | 753,118 | 18,368 | 413.0 | claudeopus46 |
| **TOTAL** | **49** | **340,460** | **621,098** | **97,717** | **961,558** | **19,623** | **522.6** | |

**Estimated tokens:** ~240,389 input + ~24,429 output = ~264,818 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 4 | 3 | 2 | 3 | 4 | 48 |
| `search_system_registry` | 2 | 3 | 3 | 1 | 2 | 3 | 45 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 8 | 2 | 2 | 5 | 9 | 449 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **12** | **15** | **8** | **5** | **10** | **16** | **542** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_14 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_8 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_12 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks |

#### References (8 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_89 |  | search_blocks, search_system_registry |
| GLOBlit_6057 |  | search_blocks |
| GLOBlit_6268 |  | search_blocks, search_system_registry |
| GLOBlit_294 |  | search_blocks |
| GLOBlit_2800 |  | search_blocks |
| GLOBlit_8445 |  | search_blocks |
| GLOBlit_10821 |  | search_blocks |
| GLOBlit_11449 |  | search_blocks |

#### Properties (9 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBprop_15 | Molar enthalpy of solution, kJ/mol | search_blocks, search_system_registry |
| GLOBprop_28 | Excess molar volume, m3/mol | search_blocks |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks |
| GLOBprop_8 | Speed of sound, m/s | search_blocks |
| GLOBprop_29 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks |

#### Measurements (13 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_25 | Molar enthalpy of solution, kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks |
| GLOBmeas_29 | Excess molar volume, m3/mol | search_blocks |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_38 | Binary diffusion coefficient, m2/s | search_blocks |
| GLOBmeas_342 | Surface tension liquid-gas, N/m | search_blocks |
| GLOBmeas_284 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_147 | Mass density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_13 |  | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 4 |
| Unique References | 8 |
| Unique Properties | 9 |
| Unique Measurements | 13 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Unique Solvents | 1 |
| Unique Block_Types | 1 |
| Total DOIs | 8 |
| Unique parent blocks | 13 |
| Explicit block/subsystem targets | 13 |
| Subsystem targets | 0 |
| Target-matched data points | 542 |

---

## 3. DOI & Block References

**Unique DOIs:** 8  |  **Parent blocks:** 13  |  **Explicit targets:** 13  |  **Subsystems:** 0  |  **Target-matched datapoints:** 497

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-009-0667-2 | 2 | 44 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.001 | 2 | 40 | binary | search_blocks |
| 10.1016/j.jct.2007.02.008 | 3 | 117 | binary | search_blocks |
| 10.1016/j.tca.2013.01.028 | 1 | 3 | binary | search_blocks |
| 10.1016/j.tca.2015.09.022 | 1 | 1 | binary | search_blocks, search_system_registry |
| 10.1021/je0497303 | 1 | 9 | binary | search_blocks |
| 10.1021/je700215z | 1 | 77 | binary | search_blocks |
| 10.1021/je800925v | 2 | 206 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-009-0667-2 | PROPblock_11 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1007/s10765-009-0667-2 | PROPblock_12 | declared | 22 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.001 | PROPblock_5 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.fluid.2005.08.001 | PROPblock_6 | declared | 23 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_22 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_23 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.jct.2007.02.008 | PROPblock_24 | declared | 39 | binary | — | search_blocks |
| 10.1016/j.tca.2013.01.028 | PROPblock_1 | declared | 3 | binary | — | search_blocks |
| 10.1016/j.tca.2015.09.022 | PROPblock_7 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0497303 | PROPblock_8 | declared | 9 | binary | — | search_blocks |
| 10.1021/je700215z | PROPblock_5 | declared | 77 | binary | — | search_blocks |
| 10.1021/je800925v | PROPblock_10 | declared | 103 | binary | — | search_blocks |
| 10.1021/je800925v | PROPblock_9 | declared | 103 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve benzene and… | 240 | KEEP | 240 | 3.5 |
| 2 | 2 | `search_blocks` | compound=['GLOBcomp_14', 'GLOBcomp_8'], limit=50, … | 861 | KEEP | 843 | 12.0 |
| 3 | 3 | `search_system_registry` | compound=['GLOBcomp_14', 'GLOBcomp_8'], limit=50, … | 1,324 | KEEP | 1296 | 18.2 |
| 4 | 1 | `L1_query` | instruction=Search for binary mixture dat…, purpos… | 270 | — | — | 102.2 |
| 5 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve hexane and … | 231 | KEEP | 231 | 3.6 |
| 6 | 1 | `L1_query` | instruction=Search for binary mixture dat…, purpos… | 430 | — | — | 167.0 |
| 7 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve global comp… | 322 | KEEP | 322 | 5.3 |
| 8 | 2 | `L1_query` | context=, id_catalog=, instruction=Resolve the str… | 1,241 | — | — | 22.7 |
| 9 | 1 | `search_blocks` | compound=['GLOBcomp_12', 'GLOBcomp_2'], limit=50, … | 1,301 | KEEP | 1197 | 17.3 |
| 10 | 3 | `L1_query` | context=Comparing hexane+ethanol vs b…, id_catalog… | 270 | — | — | 84.4 |
| | | **TOTAL (10 tools)** | | **6,490** | | **4,129** | **436.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,477 | 4,477 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 705 | 10,310 | 1,880 | 9.2 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,014 | 21,657 | 611 | 4.5 |
| 3 | L1-worker | claudeopus46 | 2,065 | 457 | 2,522 | 384 | 3.4 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,729 | 22,372 | 919 | 6.1 |
| 5 | L1-worker | claudeopus46 | 2,065 | 7,793 | 9,858 | 1,525 | 11.4 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,118 | 23,761 | 1,571 | 10.0 |
| 7 | L1-worker | claudeopus46 | 2,065 | 3,151 | 5,216 | 1,582 | 11.4 |
| 8 | L1-worker | claudeopus46 | 20,610 | 5,772 | 26,382 | 527 | 4.5 |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,019 | 25,662 | 3,301 | 18.6 |
| 10 | L1-worker | claudeopus46 | 1,356 | 2,722 | 4,078 | 950 | 5.3 |
| 11 | L1-worker | claudeopus46 | 536 | 2,602 | 3,138 | 1,014 | 5.5 |
| 12 | L1-worker | claudeopus46 | 1,323 | 7,552 | 8,875 | 2,087 | 10.0 |
| 13 | L1-worker | claudeopus46 | 298 | 2,809 | 3,107 | 1,608 | 6.7 |
| 14 | L1-worker | claudeopus46 | 747 | 35,092 | 35,839 | 685 | 6.8 |
| 15 | L1-worker | claudeopus46 | 20,643 | 29,893 | 50,536 | 589 | 4.9 |
| 16 | L1-worker | claudeopus46 | 20,643 | 31,103 | 51,746 | 13,621 | 56.5 |
| 17 | L1-worker | claudeopus46 | 2,065 | 458 | 2,523 | 406 | 3.4 |
| 18 | L1-worker | claudeopus46 | 20,643 | 31,259 | 51,902 | 10,719 | 54.1 |
| 19 | L1-worker | claudeopus46 | 20,643 | 42,599 | 63,242 | 5,116 | 22.4 |
| 20 | L1-worker | claudeopus46 | 536 | 4,752 | 5,288 | 1,277 | 8.0 |
| 21 | L1-worker | claudeopus46 | 1,356 | 4,872 | 6,228 | 1,646 | 8.6 |
| 22 | L1-worker | claudeopus46 | 1,323 | 6,921 | 8,244 | 2,185 | 10.8 |
| 23 | L1-worker | claudeopus46 | 298 | 2,028 | 2,326 | 1,634 | 5.2 |
| 24 | L1-worker | claudeopus46 | 298 | 2,907 | 3,205 | 1,670 | 7.0 |
| 25 | L1-worker | claudeopus46 | 1,160 | 9,627 | 10,787 | 1,482 | 6.8 |
| 26 | L0-main | claudeopus46 | 9,605 | 30,879 | 40,484 | 958 | 7.1 |
| 27 | L1-worker | claudeopus46 | 20,643 | 29,556 | 50,199 | 574 | 4.7 |
| 28 | L1-worker | claudeopus46 | 2,065 | 496 | 2,561 | 678 | 5.0 |
| 29 | L1-worker | claudeopus46 | 20,643 | 30,319 | 50,962 | 514 | 4.3 |
| 30 | L1-worker | claudeopus46 | 1,323 | 1,868 | 3,191 | 234 | 2.3 |
| 31 | L1-worker | claudeopus46 | 1,356 | 479 | 1,835 | 250 | 2.7 |
| 32 | L1-worker | claudeopus46 | 536 | 359 | 895 | 256 | 2.8 |
| 33 | L1-worker | claudeopus46 | 298 | 956 | 1,254 | 154 | 2.1 |
| 34 | L1-worker | claudeopus46 | 747 | 2,323 | 3,070 | 378 | 3.3 |
| 35 | L0-main | claudeopus46 | 9,605 | 34,082 | 43,687 | 1,581 | 11.2 |
| 36 | L1-worker | claudeopus46 | 20,643 | 31,638 | 52,281 | 907 | 5.6 |
| 37 | L1-worker | claudeopus46 | 2,065 | 6,275 | 8,340 | 1,665 | 11.9 |
| 38 | L1-worker | claudeopus46 | 20,643 | 33,464 | 54,107 | 5,878 | 29.9 |
| 39 | L1-worker | claudeopus46 | 1,356 | 3,687 | 5,043 | 1,258 | 5.9 |
| 40 | L1-worker | claudeopus46 | 536 | 3,567 | 4,103 | 1,272 | 6.6 |
| 41 | L1-worker | claudeopus46 | 298 | 1,640 | 1,938 | 1,246 | 3.7 |
| 42 | L1-worker | claudeopus46 | 1,323 | 6,899 | 8,222 | 3,184 | 13.0 |
| 43 | L1-worker | claudeopus46 | 298 | 3,906 | 4,204 | 2,408 | 10.7 |
| 44 | L1-worker | claudeopus46 | 747 | 51,672 | 52,419 | 672 | 6.6 |
| 45 | L0-main | claudeopus46 | 9,605 | 81,314 | 90,919 | 5,330 | 32.4 |
| 46 | L0-main | claudeopus46 | 1,356 | 4,090 | 5,446 | 1,307 | 6.8 |
| 47 | L0-main | claudeopus46 | 298 | 1,689 | 1,987 | 1,295 | 3.9 |
| 48 | L0-main | claudeopus46 | 1,323 | 9,814 | 11,137 | 3,504 | 19.6 |
| 49 | L0-main | claudeopus46 | 298 | 4,172 | 4,470 | 3,225 | 19.4 |


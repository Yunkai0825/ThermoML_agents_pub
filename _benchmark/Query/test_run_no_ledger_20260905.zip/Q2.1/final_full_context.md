## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_14 | benzene | benzene |
| comp | GLOBcomp_8 | toluene | toluene |
| comp | GLOBcomp_12 | hexane | hexane |
| comp | GLOBcomp_2 | ethanol | ethanol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all available mixture properties for benzene + toluene binary system near room temperature (290-310 K), including c → stored as L1_query_1
- [L1] Resolve compound IDs for hexane and ethanol → stored as L1_query_2
- [L1] Find all available mixture property types for hexane + ethanol binary system near room temperature (288-313 K) → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "## Benzene + Toluene Binary Mixture Properties Near Room Temperature (288–313 K)\n\nThe ThermoML database contains **4 distinct mixture property types** for the benzene (GLOBcomp_14) + toluene (GLOBcomp_8) binary system in the 288–313 K range, distributed across 4 data blocks from 3 literature sources:\n\n### Property Summary\n\n| # | Property | Global ID | Temperature (K) | Composition Range | Data Points | Literature / DOI |\n|---|----------|-----------|-----------------|-------------------|-------------|------------------|\n| 1 | **Viscosity** (Pa·s) | GLOBprop_4 | 308.15–313.15 | x(benzene) = 0.0–1.0 (full range) | 22 | GLOBlit_89 / 10.1007/s10765-009-0667-2 |\n| 2 | **Mass density** (kg/m³) | GLOBprop_1 | 308.15–313.15 | x(benzene) = 0.0–1.0 (full range) | 22 | GLOBlit_89 / 10.1007/s10765-009-0667-2 |\n| 3 | **Excess molar enthalpy** (kJ/mol) | GLOBprop_17 | 303.15 (fixed) | x(toluene) = 0.247–0.769 (mid-range) | 3 | GLOBlit_6057 / 10.1016/j.tca.2013.01.028 |\n| 4 | **Molar enthalpy of solution** (kJ/mol) | GLOBprop_15 | 298.15 | x(toluene) = 0.0 (dilute limit) | 1 | GLOBlit_6268 / 10.1016/j.tca.2015.09.022 |\n\n### Representative Data Values\n- **Viscosity** ranges from 0.000468 to 0.000527 Pa·s across the full composition range at 308–313 K and 101 kPa (measured by capillary tube/U-factor method).\n- **Mass density** starts at ~848.3 kg/m³ (toluene-rich end) across the full composition range at the same conditions (vibrating tube densimetry).\n- **Excess molar enthalpy** data at 303.15 K covers the central composition region (x(toluene) ≈ 0.25–0.77), consistent with calorimetric mixing studies.\n- **Molar enthalpy of solution** has a single data point at 298.15 K at the dilute toluene limit, measured by titration calorimetry.\n\n### Chemistry Insight\nBenzene and toluene form a nearly ideal mixture (both are aromatic hydrocarbons with similar molecular sizes and intermolecular forces). The transport properties (viscosity, density) are well-covered across the full composition range, while the thermodynamic mixing properties (excess enthalpy, enthalpy of solution) have more limited composition coverage. The small excess molar enthalpies expected for this system reflect the weak non-ideality typical of chemically similar aromatic pairs.\n\n### Source Literature\n- **GLOBlit_89** (DOI: 10.1007/s10765-009-0667-2) — viscosity and density, full composition, 2 temperatures\n- **GLOBlit_6057** (DOI: 10.1016/j.tca.2013.01.028) — excess molar enthalpy at 303.15 K\n- **GLOBlit_6268** (DOI: 10.1016/j.tca.2015.09.022) — molar enthalpy of solution at 298.15 K",
  "core_claims": [
    "The ThermoML database contains four distinct mixture property types for the benzene + toluene binary system in the 288–313 K range: viscosity, mass density, excess molar enthalpy, and molar enthalpy of solution, drawn from three literature sources.",
    "Viscosity and mass density data cover the full benzene mole-fraction range (0.0–1.0) at 308.15–313.15 K and 101 kPa, with viscosity values spanning approximately 0.000468–0.000527 Pa·s and mass density starting near 848.3 kg/m³ at the toluene-rich end.",
    "Excess molar enthalpy data are limited to the central composition region (x(toluene) ≈ 0.25–0.77) at 303.15 K, and molar enthalpy of solution consists of a single data point at 298.15 K at the dilute toluene limit.",
    "Benzene and toluene form a nearly ideal mixture owing to their similar aromatic structures and intermolecular forces, and the small excess molar enthalpies expected for this system reflect weak non-ideality."
  ],
  "status": "success",
  "summary": "The ThermoML database contains 4 distinct mixture property types for the benzene (GLOBcomp_14) + toluene (GLOBcomp_8) binary system in the 288–313 K range, reported across 4 data blocks from 3 literature sources. The properties are: (1) viscosity (GLOBprop_4, 308–313 K, full composition range, 22 points, GLOBlit_89), (2) mass density (GLOBprop_1, 308–313 K, full composition range, 22 points, GLOBlit_89), (3) excess molar enthalpy (GLOBprop_17, 303.15 K, x(toluene) 0.247–0.769, 3 points, GLOBlit_6057), and (4) molar enthalpy of solution (GLOBprop_15, 298.15 K, dilute toluene limit, 1 point, GLOBlit_6268). Viscosity values range from about 0.000468 to 0.000527 Pa·s and density starts near 848.3 kg/m³ at the toluene-rich end. The system is nearly ideal, with small excess enthalpies reflecting the weak non-ideality typical of chemically similar aromatic hydrocarbon pairs. Transport properties cover the full composition range while thermodynamic mixing properties have more limited coverage.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_14",
      "registry_id": "benzene",
      "name": "benzene"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_8",
      "registry_id": "toluene",
      "name": "toluene"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_89",
      "block_number": "PROPblock_11",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Viscosity (Pa·s) for benzene + toluene binary system at 308.15–313.15 K, x(benzene) = 0.0–1.0, 101 kPa. 22 data points measured by capillary tube/U-factor method. DOI: 10.1007/s10765-009-0667-2",
      "doi": "10.1007/s10765-009-0667-2",
      "lit_id": "2009-els-asf-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 22,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 308.15,
            "max": 313.15,
            "n_unique": 2
          },
          "range_min": 308.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000468,
            "max": 0.000527,
            "mean": 0.00049,
            "std": 1.8e-05,
            "n": 22
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000468,
          "range_max": 0.000527
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 22,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_89",
      "block_number": "PROPblock_12",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m³) for benzene + toluene binary system at 308.15–313.15 K, x(benzene) = 0.0–1.0, 101 kPa. 22 data points measured by vibrating tube densimetry. DOI: 10.1007/s10765-009-0667-2",
      "doi": "10.1007/s10765-009-0667-2",
      "lit_id": "2009-els-asf-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 22,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 308.15,
            "max": 313.15,
            "n_unique": 2
          },
          "range_min": 308.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 848.3,
            "max": 862.9,
            "mean": 854.15,
            "std": 3.946397,
            "n": 22
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 848.3,
          "range_max": 862.9
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 22,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_6057",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy (kJ/mol) for benzene + toluene binary system at 303.15 K, x(toluene) = 0.247–0.769. 3 data points from calorimetric mixing study. DOI: 10.1016/j.tca.2013.01.028",
      "doi": "10.1016/j.tca.2013.01.028",
      "lit_id": "2013-did-ait-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 3,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 303.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.247,
            "max": 0.7685,
            "n_unique": 3
          },
          "range_min": 0.247,
          "range_max": 0.7685
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_13",
          "meas_ID": "calvet_calorimetry",
          "method_standard": "Calvet calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": 0.0477,
            "max": 0.0713,
            "mean": 0.057767,
            "std": 0.012176,
            "n": 3
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0477,
          "range_max": 0.0713
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 3,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_6268",
      "block_number": "PROPblock_7",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_15"
      ],
      "description": "Molar enthalpy of solution (kJ/mol) for benzene + toluene binary system at 298.15 K, x(toluene) = 0.0 (dilute limit). 1 data point measured by titration calorimetry. DOI: 10.1016/j.tca.2015.09.022",
      "doi": "10.1016/j.tca.2015.09.022",
      "lit_id": "2015-sol-var-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 1,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_9_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_14",
          "solvent_num_id": "GLOBsolvent_13",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N"
        }
      ],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_8",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_8",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 0.0,
            "n_unique": 1
          },
          "range_min": 0.0,
          "range_max": 0.0
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.0,
            "max": 100.0,
            "n_unique": 1
          },
          "range_min": 100.0,
          "range_max": 100.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 298.15,
            "n_unique": 1
          },
          "range_min": 298.15,
          "range_max": 298.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_15",
          "prop_ID": "molar_enthalpy_of_solution_kj_mol",
          "name": "Molar enthalpy of solution, kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_25",
          "meas_ID": "titration_calorimetry",
          "method_standard": "Titration calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar enthalpy of solution, kJ/mol",
            "min": 0.28,
            "max": 0.28,
            "mean": 0.28,
            "std": 0,
            "n": 1
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.28,
          "range_max": 0.28
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_9_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "parent_n_datapoints": 1,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_2
{
  "answer": "The resolved global compound IDs from the ThermoML database are:\n\n- **Hexane** (n-hexane, C₆H₁₄): **GLOBcomp_12**, SMILES: CCCCCC\n- **Ethanol** (C₂H₆O): **GLOBcomp_2**, SMILES: CCO\n\nBoth compounds were resolved with exact name matches (score 100). These canonical IDs can be used for subsequent searches in the ThermoML database.",
  "core_claims": [
    "In the ThermoML database, hexane (n-hexane, C₆H₁₄) is assigned global compound ID GLOBcomp_12 with SMILES CCCCCC, and ethanol (C₂H₆O) is assigned global compound ID GLOBcomp_2 with SMILES CCO, both resolved via exact name matches."
  ],
  "status": "success",
  "summary": "The ThermoML global compound IDs were resolved as follows: hexane (n-hexane, C₆H₁₄) corresponds to GLOBcomp_12 (SMILES: CCCCCC), and ethanol (C₂H₆O) corresponds to GLOBcomp_2 (SMILES: CCO). Both were matched by exact name with a score of 100.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_12",
      "registry_id": "hexane",
      "name": "hexane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    }
  ],
  "core_blocks_found": []
}
### L1_query_3
{
  "answer": "## Hexane + Ethanol Binary Mixture Properties Near Room Temperature (288–313 K)\n\nThe ThermoML database contains **8 distinct mixture property types** for the hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary system in the 283–313 K range, distributed across **9 data blocks** from **4 literature sources**:\n\n### Property Summary\n\n| # | Property | GLOBprop ID | T range (K) | x(ethanol) range | Data Points | Literature / DOI |\n|---|----------|-------------|-------------|------------------|-------------|------------------|\n| 1 | **Excess molar enthalpy** (kJ/mol) | GLOBprop_17 | constrained (within range) | 0.054–0.953 | 17 (9 in T window) | GLOBlit_294 / 10.1016/j.fluid.2005.08.001 |\n| 2 | **Excess molar volume** (m³/mol) | GLOBprop_28 | constrained (within range) | 0.042–0.950 | 23 (9 in T window) | GLOBlit_294 / 10.1016/j.fluid.2005.08.001 |\n| 3 | **Refractive index** (Na D-line) | GLOBprop_7 | 293.15–303.15 | 0.0–1.0 (full range) | 39 (13 in T window) | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |\n| 4 | **Speed of sound** (m/s) | GLOBprop_8 | 293.15–303.15 | 0.0–1.0 (full range) | 39 (24 in T window) | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |\n| 5 | **Mass density** (kg/m³) | GLOBprop_1 | 293.15–303.15 | 0.0–1.0 (full range) | 39 (15 in T window) | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |\n| 6 | **Binary diffusion coefficient** (m²/s) | GLOBprop_29 | constrained (within range) | 0.0–1.0 (full range) | 9 (2 in T window) | GLOBlit_8445 / 10.1021/je0497303 |\n| 7 | **Surface tension liquid–gas** (N/m) | GLOBprop_13 | 283.15–303.15 | (available) | (available) | GLOBlit_10821 / 10.1021/je700215z |\n| 8 | *(additional property from GLOBlit_10821)* | — | 283.15–303.15 | — | — | GLOBlit_10821 / 10.1021/je700215z |\n\n*(The 8th distinct property type and a 9th data block are also present from GLOBlit_10821 but were truncated in the search return.)*\n\n### Key Observations\n\n- **Composition coverage**: Three properties (refractive index, speed of sound, mass density) span the full mole-fraction range (0.0–1.0), while excess molar enthalpy and excess molar volume cover the central composition region (~0.04–0.95).\n- **Temperature coverage**: Most data fall in the 293–303 K range; surface tension data extend down to 283 K.\n- **Property diversity**: The hexane + ethanol system offers 8 distinct property types — significantly more than the 4 found for benzene + toluene — spanning volumetric (density), acoustic (speed of sound), optical (refractive index), transport (diffusion coefficient, surface tension), and excess thermodynamic (excess enthalpy, excess volume) categories.\n\n### Chemistry Insight\n\nHexane + ethanol is a strongly non-ideal system due to the large polarity mismatch between the nonpolar alkane and the hydrogen-bonding alcohol. This non-ideality drives measurably large excess properties (positive excess enthalpy and volume) and makes the system a much more demanding test case for mixture-property models compared to the nearly ideal benzene + toluene pair. The broader property-type coverage in the database reflects the greater experimental interest in characterizing this challenging system.\n\n### Source Literature\n- **GLOBlit_294** (DOI: 10.1016/j.fluid.2005.08.001) — excess molar enthalpy and excess molar volume\n- **GLOBlit_2800** (DOI: 10.1016/j.jct.2007.02.008) — refractive index, speed of sound, mass density\n- **GLOBlit_8445** (DOI: 10.1021/je0497303) — binary diffusion coefficient\n- **GLOBlit_10821** (DOI: 10.1021/je700215z) — surface tension and at least one additional property",
  "core_claims": [
    "The ThermoML database contains 8 distinct mixture property types for the hexane + ethanol binary system in the 283–313 K range, spanning volumetric (density), acoustic (speed of sound), optical (refractive index), transport (diffusion coefficient, surface tension), and excess thermodynamic (excess molar enthalpy, excess molar volume) categories, distributed across 9 data blocks from 4 literature sources.",
    "Three properties (refractive index, speed of sound, mass density) cover the full ethanol mole-fraction range (0.0–1.0), while excess molar enthalpy and excess molar volume cover the central composition region (~0.04–0.95), with most data falling in the 293–303 K range.",
    "Hexane + ethanol is a strongly non-ideal system due to the large polarity mismatch between the nonpolar alkane and the hydrogen-bonding alcohol, resulting in measurably large positive excess enthalpy and excess volume, making it a more demanding test case for mixture-property models compared to the nearly ideal benzene + toluene pair.",
    "The hexane + ethanol system offers significantly more property-type diversity (8 types) than benzene + toluene (4 types), reflecting greater experimental interest in characterizing this challenging system."
  ],
  "status": "success",
  "summary": "The ThermoML database contains 8 distinct mixture property types for the hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary system in the 283–313 K range, distributed across 9 data blocks from 4 literature sources. The properties are: excess molar enthalpy (GLOBprop_17), excess molar volume (GLOBprop_28), refractive index (GLOBprop_7), speed of sound (GLOBprop_8), mass density (GLOBprop_1), binary diffusion coefficient (GLOBprop_29), surface tension liquid–gas (GLOBprop_13), and at least one additional property from GLOBlit_10821. Most data fall in the 293–303 K range; surface tension data extend to 283 K. Three properties (refractive index, speed of sound, density) span the full mole-fraction range (0–1), while excess enthalpy and volume cover ~0.04–0.95. Sources are GLOBlit_294 (10.1016/j.fluid.2005.08.001), GLOBlit_2800 (10.1016/j.jct.2007.02.008), GLOBlit_8445 (10.1021/je0497303), and GLOBlit_10821 (10.1021/je700215z). The system is strongly non-ideal due to polarity mismatch between nonpolar hexane and hydrogen-bonding ethanol, yielding large positive excess enthalpy and volume, making it a demanding test case for mixture models and explaining the broader property-type coverage compared to nearly ideal systems like benzene + toluene.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_12",
      "registry_id": "hexane",
      "name": "hexane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_294",
      "block_number": "PROPblock_5",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy (kJ/mol) for hexane + ethanol; x(ethanol) 0.0544–0.9528; 17 raw points, 9 in T window. DOI: 10.1016/j.fluid.2005.08.001",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_id": "2005-kwa-rez-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 17,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0544,
            "max": 0.9528,
            "n_unique": 17
          },
          "range_min": 0.0544,
          "range_max": 0.9528
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_12",
          "meas_ID": "flow_calorimetry",
          "method_standard": "Flow calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": 0.1216,
            "max": 0.5795,
            "mean": 0.458288,
            "std": 0.136978,
            "n": 17
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.1216,
          "range_max": 0.5795
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 17,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_294",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_28"
      ],
      "description": "Excess molar volume (m³/mol) for hexane + ethanol; x(ethanol) 0.0417–0.9497; 23 raw points, 9 in T window. DOI: 10.1016/j.fluid.2005.08.001",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_id": "2005-kwa-rez-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 23,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0417,
            "max": 0.9497,
            "n_unique": 23
          },
          "range_min": 0.0417,
          "range_max": 0.9497
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_28",
          "prop_ID": "excess_molar_volume_m3_mol",
          "name": "Excess molar volume, m3/mol",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_29",
          "meas_ID": "calculated_with_densities_of_this_investigation",
          "method_standard": "Calculated with densities of this investigation",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar volume, m3/mol",
            "min": 0.0,
            "max": 0.0,
            "mean": 0.0,
            "std": 0.0,
            "n": 23
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0,
          "range_max": 0.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 23,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2800",
      "block_number": "PROPblock_22",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_7"
      ],
      "description": "Refractive index (Na D-line) for hexane + ethanol; x(ethanol) 0–1; T 293.15–303.15 K; 39 raw points, 13 in T window. DOI: 10.1016/j.jct.2007.02.008",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_7",
          "prop_ID": "refractive_index_na_dline",
          "name": "Refractive index (Na D-line)",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_3",
          "meas_ID": "standard_abbe_refractometry",
          "method_standard": "Standard Abbe refractometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Refractive index (Na D-line)",
            "min": 1.35725,
            "max": 1.37495,
            "mean": 1.366087,
            "std": 0.004865,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1.35725,
          "range_max": 1.37495
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2800",
      "block_number": "PROPblock_23",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_8"
      ],
      "description": "Speed of sound (m/s) for hexane + ethanol; x(ethanol) 0–1; T 293.15–303.15 K; 39 raw points, 24 in T window. DOI: 10.1016/j.jct.2007.02.008",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_8",
          "prop_ID": "speed_of_sound_m_s",
          "name": "Speed of sound, m/s",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_7",
          "meas_ID": "sing_around_technique_in_a_fixed_path_interferometer",
          "method_standard": "Sing-around technique in a fixed-path interferometer",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Speed of sound, m/s",
            "min": 1046.0,
            "max": 1160.0,
            "mean": 1088.25641,
            "std": 29.810558,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1046.0,
          "range_max": 1160.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2800",
      "block_number": "PROPblock_24",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m³) for hexane + ethanol; x(ethanol) 0–1; T 293.15–303.15 K; 39 raw points, 15 in T window. DOI: 10.1016/j.jct.2007.02.008",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_134",
          "meas_ID": "vibtub_ufactor_4",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 650.4,
            "max": 789.3,
            "mean": 704.112821,
            "std": 44.155706,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 650.4,
          "range_max": 789.3
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_8445",
      "block_number": "PROPblock_8",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_29"
      ],
      "description": "Binary diffusion coefficient (m²/s) for hexane + ethanol; x(ethanol) 0–1; 9 raw points, 2 in T window. DOI: 10.1021/je0497303",
      "doi": "10.1021/je0497303",
      "lit_id": "2005-bos-bar-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 9,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.3,
          "digits": 4,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 9
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_29",
          "prop_ID": "binary_diffusion_coefficient_m2_s",
          "name": "Binary diffusion coefficient, m2/s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_38",
          "meas_ID": "taylor_dispersion_method",
          "method_standard": "Taylor dispersion method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Binary diffusion coefficient, m2/s",
            "min": 0.0,
            "max": 0.0,
            "mean": 0.0,
            "std": 0.0,
            "n": 9
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0,
          "range_max": 0.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "parent_n_datapoints": 9,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_10821",
      "block_number": "PROPblock_5",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_13"
      ],
      "description": "Surface tension liquid-gas (N/m) for hexane + ethanol; T 283.15–303.15 K. DOI: 10.1021/je700215z. Search result was truncated; at least one additional property and block from this literature source may exist.",
      "doi": "10.1021/je700215z",
      "lit_id": "2007-gin-vil-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 77,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 283.15,
            "max": 313.15,
            "n_unique": 7
          },
          "range_min": 283.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0855,
            "max": 0.932,
            "n_unique": 11
          },
          "range_min": 0.0855,
          "range_max": 0.932
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_13",
          "prop_ID": "surface_tension_liquidgas_n_m",
          "name": "Surface tension liquid-gas, N/m",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_342",
          "meas_ID": "dropv_ufactor_2",
          "method_standard": null,
          "method_custom": "DROPV:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Surface tension liquid-gas, N/m",
            "min": 0.0162,
            "max": 0.02211,
            "mean": 0.018729,
            "std": 0.001475,
            "n": 77
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0162,
          "range_max": 0.02211
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 77,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


</memory>

## User
I need a binary liquid for testing a mixture-property model near room temperature. Between benzene + toluene and hexane + ethanol, which would let me test the model over a wider composition range and against more types of measured properties?

## Assistant
<summary>Planning two L1 queries to compare available mixture property data for benzene+toluene and hexane+ethanol near room temperature. Need composition ranges and property type counts for both systems.</summary>
<tool_call>L1_query(instruction=Search for binary…)</tool_call>
<tool_call>L1_query(instruction=Search for binary…)</tool_call>

## User
<tool_result>
### L1_query
{
  "error": "TOOL_RESULT_COMPACTION_REQUIRED: L1_query returned 28,644 characters after result processing; limit is 24,000. Register or repair its deterministic and agentic compaction pipeline.",
  "error_code": "TOOL_RESULT_COMPACTION_REQUIRED",
  "tool": "L1_query"
}

### L1_query
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[1] checksum mismatch for (GLOBlit_5937, PROPblock_2): comp_num_ids expected ['GLOBcomp_1874', 'GLOBcomp_11'], received ['GLOBcomp_12', 'GLOBcomp_2']; prop_num_ids expected ['GLOBprop_20'], received ['GLOBprop_1', 'GLOBprop_18', 'GLOBprop_6', 'GLOBprop_55']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 2 tool(s) finished (L1_query, L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Both initial queries failed. I already have benzene+toluene data in memory. Now need to query hexane+ethanol mixture properties near room temperature. Will first resolve hexane and ethanol compound IDs, then search for their binary mixture data.</summary>
<tool_call>L1_query(instruction=Resolve the stric…, id_catalog=, context=)</tool_call>

## User
<tool_result>
<subagent_answer>
{
  "answer": "The resolved global compound IDs from the ThermoML database are:\n\n- **Hexane** (n-hexane, C₆H₁₄): **GLOBcomp_12**, SMILES: CCCCCC\n- **Ethanol** (C₂H₆O): **GLOBcomp_2**, SMILES: CCO\n\nBoth compounds were resolved with exact name matches (score 100). These canonical IDs can be used for subsequent searches in the ThermoML database.",
  "core_claims": [
    "In the ThermoML database, hexane (n-hexane, C₆H₁₄) is assigned global compound ID GLOBcomp_12 with SMILES CCCCCC, and ethanol (C₂H₆O) is assigned global compound ID GLOBcomp_2 with SMILES CCO, both resolved via exact name matches."
  ],
  "status": "success",
  "summary": "The ThermoML global compound IDs were resolved as follows: hexane (n-hexane, C₆H₁₄) corresponds to GLOBcomp_12 (SMILES: CCCCCC), and ethanol (C₂H₆O) corresponds to GLOBcomp_2 (SMILES: CCO). Both were matched by exact name with a score of 100.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_12",
      "registry_id": "hexane",
      "name": "hexane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    }
  ],
  "core_blocks_found": []
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Compound IDs confirmed: hexane=GLOBcomp_12, ethanol=GLOBcomp_2. Now querying for hexane+ethanol binary mixture properties near room temperature (288-313 K) to compare with benzene+toluene data already in memory.</summary>
<tool_call>L1_query(instruction=Search for all da…, id_catalog=comp: GLOBcomp_12…, context=Comparin…)</tool_call>

## User
<tool_result>
{
  "error": "TOOL_RESULT_COMPACTION_REQUIRED: L1_query returned 46,264 characters after result processing; limit is 24,000. Register or repair its deterministic and agentic compaction pipeline.",
  "error_code": "TOOL_RESULT_COMPACTION_REQUIRED",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## LLM Response
<reasoning>
I already have all the data I need in working memory from previous queries (L1_query_1 for benzene+toluene and L1_query_3 for hexane+ethanol). Let me compile the comparison from the existing results.

**Benzene + Toluene (GLOBcomp_14 + GLOBcomp_8):**
- 4 property types: viscosity, mass density, excess molar enthalpy, molar enthalpy of solution
- Composition coverage: viscosity and density cover full range x=0–1; excess enthalpy covers x(toluene)=0.247–0.769; enthalpy of solution at dilute limit only
- Temperature: 298–313 K
- 3 literature sources, 4 data blocks, ~48 data points total

**Hexane + Ethanol (GLOBcomp_12 + GLOBcomp_2):**
- 7–8 property types: excess molar enthalpy, excess molar volume, refractive index, speed of sound, mass density, binary diffusion coefficient, surface tension, plus possibly one more
- Composition coverage: refractive index, speed of sound, density, diffusion coefficient all cover full range x=0–1; excess enthalpy covers x(ethanol)=0.054–0.953; excess volume covers x(ethanol)=0.042–0.950; surface tension covers x(ethanol)=0.086–0.932
- Temperature: 283–313 K
- 4 literature sources, 7+ data blocks, ~240+ data points total

Clear winner: hexane + ethanol for both criteria (more property types and wider composition coverage).

I have all the data needed to answer. Let me provide the final answer.
</reasoning>

<answer>
## Recommendation: Hexane + Ethanol Is the Better Test System

For testing a mixture-property model near room temperature, **hexane + ethanol** is clearly superior on both criteria — composition coverage and property-type diversity.

---

### Side-by-Side Comparison

| Feature | Benzene + Toluene | Hexane + Ethanol |
|---------|-------------------|------------------|
| **Distinct property types** | 4 | ≥ 7 |
| **Total data points** | ~48 | ~240+ |
| **Literature sources** | 3 | 4 |
| **Temperature range** | 298–313 K | 283–313 K |

---

### Property-Type Coverage

**Benzene + Toluene** (4 properties):

| Property | ID | Composition range | T (K) | Points | Source |
|----------|----|-------------------|--------|--------|--------|
| Viscosity (Pa·s) | GLOBprop_4 | x(benzene) = 0–1 | 308–313 | 22 | GLOBlit_89 / 10.1007/s10765-009-0667-2 |
| Mass density (kg/m³) | GLOBprop_1 | x(benzene) = 0–1 | 308–313 | 22 | GLOBlit_89 / 10.1007/s10765-009-0667-2 |
| Excess molar enthalpy (kJ/mol) | GLOBprop_17 | x(toluene) = 0.25–0.77 | 303 | 3 | GLOBlit_6057 / 10.1016/j.tca.2013.01.028 |
| Molar enthalpy of solution (kJ/mol) | GLOBprop_15 | dilute limit only | 298 | 1 | GLOBlit_6268 / 10.1016/j.tca.2015.09.022 |

**Hexane + Ethanol** (≥ 7 properties):

| Property | ID | Composition range | T (K) | Points | Source |
|----------|----|-------------------|--------|--------|--------|
| Mass density (kg/m³) | GLOBprop_1 | x(ethanol) = 0–1 | 293–303 | 39 | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |
| Refractive index (Na D-line) | GLOBprop_7 | x(ethanol) = 0–1 | 293–303 | 39 | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |
| Speed of sound (m/s) | GLOBprop_8 | x(ethanol) = 0–1 | 293–303 | 39 | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |
| Surface tension (N/m) | GLOBprop_13 | x(ethanol) = 0.09–0.93 | 283–313 | 77 | GLOBlit_10821 / 10.1021/je700215z |
| Excess molar enthalpy (kJ/mol) | GLOBprop_17 | x(ethanol) = 0.05–0.95 | 298 | 17 | GLOBlit_294 / 10.1016/j.fluid.2005.08.001 |
| Excess molar volume (m³/mol) | GLOBprop_28 | x(ethanol) = 0.04–0.95 | 298 | 23 | GLOBlit_294 / 10.1016/j.fluid.2005.08.001 |
| Binary diffusion coefficient (m²/s) | GLOBprop_29 | x(ethanol) = 0–1 | 298 | 9 | GLOBlit_8445 / 10.1021/je0497303 |

---

### Composition-Range Advantage

- **Hexane + ethanol**: Four properties (density, refractive index, speed of sound, diffusion coefficient) span the **full mole-fraction range** (0 to 1). Excess enthalpy and excess volume cover nearly the full range (x ≈ 0.04–0.95), and surface tension covers x ≈ 0.09–0.93.
- **Benzene + toluene**: Only viscosity and density span the full range; excess enthalpy is limited to the central region (x ≈ 0.25–0.77), and the enthalpy of solution is a single dilute-limit point.

---

### Chemistry Rationale

The hexane + ethanol system is **strongly non-ideal** because of the large polarity mismatch between the nonpolar alkane (hexane) and the hydrogen-bonding alcohol (ethanol). This drives measurably large excess properties — for example, the excess molar enthalpy reaches up to **0.58 kJ/mol** at 298 K, roughly an order of magnitude larger than the **~0.05–0.07 kJ/mol** values seen for benzene + toluene at 303 K. The strong non-ideality makes hexane + ethanol a far more demanding and informative benchmark for any mixture model.

In contrast, benzene and toluene are both aromatic hydrocarbons with similar molecular sizes and dispersion-dominated interactions, forming a **nearly ideal mixture** with very small excess properties — useful as a sanity check but not a rigorous test.

---

### Bottom Line

Choose **hexane + ethanol** for model testing. It provides roughly **twice as many property types** (≥7 vs. 4), **five times as many data points** (~240+ vs. ~48), **broader composition coverage** across most properties, and the strong non-ideality that will genuinely challenge your model's ability to capture hydrogen-bonding and polarity-mismatch effects.
</answer>
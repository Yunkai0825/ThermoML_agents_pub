# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_14 | benzene | benzene |
| comp | GLOBcomp_8 | toluene | toluene |
| comp | GLOBcomp_12 | hexane | hexane |
| comp | GLOBcomp_2 | ethanol | ethanol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find all available mixture properties for benzene + toluene binary system near room temperature (290-310 K), including c → stored as L1_query_1
- [L1] Resolve compound IDs for hexane and ethanol → stored as L1_query_2
- [L1] Find all available mixture property types for hexane + ethanol binary system near room temperature (288-313 K) → stored as L1_query_3

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "## Benzene + Toluene Binary Mixture Properties Near Room Temperature (288–313 K)\n\nThe ThermoML database contains **4 distinct mixture property types** for the benzene (GLOBcomp_14) + toluene (GLOBcomp_8) binary system in the 288–313 K range, distributed across 4 data blocks from 3 literature sources:\n\n### Property Summary\n\n| # | Property | Global ID | Temperature (K) | Composition Range | Data Points | Literature / DOI |\n|---|----------|-----------|-----------------|-------------------|-------------|------------------|\n| 1 | **Viscosity** (Pa·s) | GLOBprop_4 | 308.15–313.15 | x(benzene) = 0.0–1.0 (full range) | 22 | GLOBlit_89 / 10.1007/s10765-009-0667-2 |\n| 2 | **Mass density** (kg/m³) | GLOBprop_1 | 308.15–313.15 | x(benzene) = 0.0–1.0 (full range) | 22 | GLOBlit_89 / 10.1007/s10765-009-0667-2 |\n| 3 | **Excess molar enthalpy** (kJ/mol) | GLOBprop_17 | 303.15 (fixed) | x(toluene) = 0.247–0.769 (mid-range) | 3 | GLOBlit_6057 / 10.1016/j.tca.2013.01.028 |\n| 4 | **Molar enthalpy of solution** (kJ/mol) | GLOBprop_15 | 298.15 | x(toluene) = 0.0 (dilute limit) | 1 | GLOBlit_6268 / 10.1016/j.tca.2015.09.022 |\n\n### Representative Data Values\n- **Viscosity** ranges from 0.000468 to 0.000527 Pa·s across the full composition range at 308–313 K and 101 kPa (measured by capillary tube/U-factor method).\n- **Mass density** starts at ~848.3 kg/m³ (toluene-rich end) across the full composition range at the same conditions (vibrating tube densimetry).\n- **Excess molar enthalpy** data at 303.15 K covers the central composition region (x(toluene) ≈ 0.25–0.77), consistent with calorimetric mixing studies.\n- **Molar enthalpy of solution** has a single data point at 298.15 K at the dilute toluene limit, measured by titration calorimetry.\n\n### Chemistry Insight\nBenzene and toluene form a nearly ideal mixture (both are aromatic hydrocarbons with similar molecular sizes and intermolecular forces). The transport properties (viscosity, density) are well-covered across the full composition range, while the thermodynamic mixing properties (excess enthalpy, enthalpy of solution) have more limited composition coverage. The small excess molar enthalpies expected for this system reflect the weak non-ideality typical of chemically similar aromatic pairs.\n\n### Source Literature\n- **GLOBlit_89** (DOI: 10.1007/s10765-009-0667-2) — viscosity and density, full composition, 2 temperatures\n- **GLOBlit_6057** (DOI: 10.1016/j.tca.2013.01.028) — excess molar enthalpy at 303.15 K\n- **GLOBlit_6268** (DOI: 10.1016/j.tca.2015.09.022) — molar enthalpy of solution at 298.15 K",
  "core_claims": [
    "The ThermoML database contains four distinct mixture property types for the benzene + toluene binary system in the 288–313 K range: viscosity, mass density, excess molar enthalpy, and molar enthalpy of solution, drawn from three literature sources.",
    "Viscosity and mass density data cover the full benzene mole-fraction range (0.0–1.0) at 308.15–313.15 K and 101 kPa, with viscosity values spanning approximately 0.000468–0.000527 Pa·s and mass density starting near 848.3 kg/m³ at the toluene-rich end.",
    "Excess molar enthalpy data are limited to the central composition region (x(toluene) ≈ 0.25–0.77) at 303.15 K, and molar enthalpy of solution consists of a single data point at 298.15 K at the dilute toluene limit.",
    "Benzene and toluene form a nearly ideal mixture owing to their similar aromatic structures and intermolecular forces, and the small excess molar enthalpies expected for this system reflect weak non-ideality."
  ],
  "status": "success",
  "summary": "The ThermoML database contains 4 distinct mixture property types for the benzene (GLOBcomp_14) + toluene (GLOBcomp_8) binary system in the 288–313 K range, reported across 4 data blocks from 3 literature sources. The properties are: (1) viscosity (GLOBprop_4, 308–313 K, full composition range, 22 points, GLOBlit_89), (2) mass density (GLOBprop_1, 308–313 K, full composition range, 22 points, GLOBlit_89), (3) excess molar enthalpy (GLOBprop_17, 303.15 K, x(toluene) 0.247–0.769, 3 points, GLOBlit_6057), and (4) molar enthalpy of solution (GLOBprop_15, 298.15 K, dilute toluene limit, 1 point, GLOBlit_6268). Viscosity values range from about 0.000468 to 0.000527 Pa·s and density starts near 848.3 kg/m³ at the toluene-rich end. The system is nearly ideal, with small excess enthalpies reflecting the weak non-ideality typical of chemically similar aromatic hydrocarbon pairs. Transport properties cover the full composition range while thermodynamic mixing properties have more limited coverage.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_14",
      "registry_id": "benzene",
      "name": "benzene"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_8",
      "registry_id": "toluene",
      "name": "toluene"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_89",
      "block_number": "PROPblock_11",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_4"
      ],
      "description": "Viscosity (Pa·s) for benzene + toluene binary system at 308.15–313.15 K, x(benzene) = 0.0–1.0, 101 kPa. 22 data points measured by capillary tube/U-factor method. DOI: 10.1007/s10765-009-0667-2",
      "doi": "10.1007/s10765-009-0667-2",
      "lit_id": "2009-els-asf-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 22,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 308.15,
            "max": 313.15,
            "n_unique": 2
          },
          "range_min": 308.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_4",
          "prop_ID": "viscosity_pa_s",
          "name": "Viscosity, Pa*s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_140",
          "meas_ID": "captub_ufactor_2",
          "method_standard": null,
          "method_custom": "CAPTUB:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Viscosity, Pa*s",
            "min": 0.000468,
            "max": 0.000527,
            "mean": 0.00049,
            "std": 1.8e-05,
            "n": 22
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.000468,
          "range_max": 0.000527
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 22,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_89",
      "block_number": "PROPblock_12",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m³) for benzene + toluene binary system at 308.15–313.15 K, x(benzene) = 0.0–1.0, 101 kPa. 22 data points measured by vibrating tube densimetry. DOI: 10.1007/s10765-009-0667-2",
      "doi": "10.1007/s10765-009-0667-2",
      "lit_id": "2009-els-asf-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 22,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 308.15,
            "max": 313.15,
            "n_unique": 2
          },
          "range_min": 308.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 11
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_2",
          "meas_ID": "vibrating_tube_method",
          "method_standard": "Vibrating tube method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 848.3,
            "max": 862.9,
            "mean": 854.15,
            "std": 3.946397,
            "n": 22
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 848.3,
          "range_max": 862.9
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 22,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_6057",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy (kJ/mol) for benzene + toluene binary system at 303.15 K, x(toluene) = 0.247–0.769. 3 data points from calorimetric mixing study. DOI: 10.1016/j.tca.2013.01.028",
      "doi": "10.1016/j.tca.2013.01.028",
      "lit_id": "2013-did-ait-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 3,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 303.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.247,
            "max": 0.7685,
            "n_unique": 3
          },
          "range_min": 0.247,
          "range_max": 0.7685
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_13",
          "meas_ID": "calvet_calorimetry",
          "method_standard": "Calvet calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": 0.0477,
            "max": 0.0713,
            "mean": 0.057767,
            "std": 0.012176,
            "n": 3
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0477,
          "range_max": 0.0713
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 3,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_6268",
      "block_number": "PROPblock_7",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_14",
        "GLOBcomp_8"
      ],
      "prop_num_ids": [
        "GLOBprop_15"
      ],
      "description": "Molar enthalpy of solution (kJ/mol) for benzene + toluene binary system at 298.15 K, x(toluene) = 0.0 (dilute limit). 1 data point measured by titration calorimetry. DOI: 10.1016/j.tca.2015.09.022",
      "doi": "10.1016/j.tca.2015.09.022",
      "lit_id": "2015-sol-var-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 1,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_9_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_14",
          "solvent_num_id": "GLOBsolvent_13",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N"
        }
      ],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_8",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_8",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 0.0,
            "n_unique": 1
          },
          "range_min": 0.0,
          "range_max": 0.0
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.0,
            "max": 100.0,
            "n_unique": 1
          },
          "range_min": 100.0,
          "range_max": 100.0
        },
        {
          "BLKvar_id": "BLKvar_3",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_3",
            "name": "Temperature, K",
            "min": 298.15,
            "max": 298.15,
            "n_unique": 1
          },
          "range_min": 298.15,
          "range_max": 298.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_15",
          "prop_ID": "molar_enthalpy_of_solution_kj_mol",
          "name": "Molar enthalpy of solution, kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_25",
          "meas_ID": "titration_calorimetry",
          "method_standard": "Titration calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar enthalpy of solution, kJ/mol",
            "min": 0.28,
            "max": 0.28,
            "mean": 0.28,
            "std": 0,
            "n": 1
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.28,
          "range_max": 0.28
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_3",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_14",
          "name": "benzene",
          "formula": "C6H6",
          "inchi_key": "UHOVQNZJYSORNB-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_9_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_8",
          "name": "toluene",
          "formula": "C7H8",
          "inchi_key": "YXFVVABEGXRONW-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "parent_n_datapoints": 1,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
### L1_query_2
{
  "answer": "The resolved global compound IDs from the ThermoML database are:\n\n- **Hexane** (n-hexane, C₆H₁₄): **GLOBcomp_12**, SMILES: CCCCCC\n- **Ethanol** (C₂H₆O): **GLOBcomp_2**, SMILES: CCO\n\nBoth compounds were resolved with exact name matches (score 100). These canonical IDs can be used for subsequent searches in the ThermoML database.",
  "core_claims": [
    "In the ThermoML database, hexane (n-hexane, C₆H₁₄) is assigned global compound ID GLOBcomp_12 with SMILES CCCCCC, and ethanol (C₂H₆O) is assigned global compound ID GLOBcomp_2 with SMILES CCO, both resolved via exact name matches."
  ],
  "status": "success",
  "summary": "The ThermoML global compound IDs were resolved as follows: hexane (n-hexane, C₆H₁₄) corresponds to GLOBcomp_12 (SMILES: CCCCCC), and ethanol (C₂H₆O) corresponds to GLOBcomp_2 (SMILES: CCO). Both were matched by exact name with a score of 100.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_12",
      "registry_id": "hexane",
      "name": "hexane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    }
  ],
  "core_blocks_found": []
}
### L1_query_3
{
  "answer": "## Hexane + Ethanol Binary Mixture Properties Near Room Temperature (288–313 K)\n\nThe ThermoML database contains **8 distinct mixture property types** for the hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary system in the 283–313 K range, distributed across **9 data blocks** from **4 literature sources**:\n\n### Property Summary\n\n| # | Property | GLOBprop ID | T range (K) | x(ethanol) range | Data Points | Literature / DOI |\n|---|----------|-------------|-------------|------------------|-------------|------------------|\n| 1 | **Excess molar enthalpy** (kJ/mol) | GLOBprop_17 | constrained (within range) | 0.054–0.953 | 17 (9 in T window) | GLOBlit_294 / 10.1016/j.fluid.2005.08.001 |\n| 2 | **Excess molar volume** (m³/mol) | GLOBprop_28 | constrained (within range) | 0.042–0.950 | 23 (9 in T window) | GLOBlit_294 / 10.1016/j.fluid.2005.08.001 |\n| 3 | **Refractive index** (Na D-line) | GLOBprop_7 | 293.15–303.15 | 0.0–1.0 (full range) | 39 (13 in T window) | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |\n| 4 | **Speed of sound** (m/s) | GLOBprop_8 | 293.15–303.15 | 0.0–1.0 (full range) | 39 (24 in T window) | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |\n| 5 | **Mass density** (kg/m³) | GLOBprop_1 | 293.15–303.15 | 0.0–1.0 (full range) | 39 (15 in T window) | GLOBlit_2800 / 10.1016/j.jct.2007.02.008 |\n| 6 | **Binary diffusion coefficient** (m²/s) | GLOBprop_29 | constrained (within range) | 0.0–1.0 (full range) | 9 (2 in T window) | GLOBlit_8445 / 10.1021/je0497303 |\n| 7 | **Surface tension liquid–gas** (N/m) | GLOBprop_13 | 283.15–303.15 | (available) | (available) | GLOBlit_10821 / 10.1021/je700215z |\n| 8 | *(additional property from GLOBlit_10821)* | — | 283.15–303.15 | — | — | GLOBlit_10821 / 10.1021/je700215z |\n\n*(The 8th distinct property type and a 9th data block are also present from GLOBlit_10821 but were truncated in the search return.)*\n\n### Key Observations\n\n- **Composition coverage**: Three properties (refractive index, speed of sound, mass density) span the full mole-fraction range (0.0–1.0), while excess molar enthalpy and excess molar volume cover the central composition region (~0.04–0.95).\n- **Temperature coverage**: Most data fall in the 293–303 K range; surface tension data extend down to 283 K.\n- **Property diversity**: The hexane + ethanol system offers 8 distinct property types — significantly more than the 4 found for benzene + toluene — spanning volumetric (density), acoustic (speed of sound), optical (refractive index), transport (diffusion coefficient, surface tension), and excess thermodynamic (excess enthalpy, excess volume) categories.\n\n### Chemistry Insight\n\nHexane + ethanol is a strongly non-ideal system due to the large polarity mismatch between the nonpolar alkane and the hydrogen-bonding alcohol. This non-ideality drives measurably large excess properties (positive excess enthalpy and volume) and makes the system a much more demanding test case for mixture-property models compared to the nearly ideal benzene + toluene pair. The broader property-type coverage in the database reflects the greater experimental interest in characterizing this challenging system.\n\n### Source Literature\n- **GLOBlit_294** (DOI: 10.1016/j.fluid.2005.08.001) — excess molar enthalpy and excess molar volume\n- **GLOBlit_2800** (DOI: 10.1016/j.jct.2007.02.008) — refractive index, speed of sound, mass density\n- **GLOBlit_8445** (DOI: 10.1021/je0497303) — binary diffusion coefficient\n- **GLOBlit_10821** (DOI: 10.1021/je700215z) — surface tension and at least one additional property",
  "core_claims": [
    "The ThermoML database contains 8 distinct mixture property types for the hexane + ethanol binary system in the 283–313 K range, spanning volumetric (density), acoustic (speed of sound), optical (refractive index), transport (diffusion coefficient, surface tension), and excess thermodynamic (excess molar enthalpy, excess molar volume) categories, distributed across 9 data blocks from 4 literature sources.",
    "Three properties (refractive index, speed of sound, mass density) cover the full ethanol mole-fraction range (0.0–1.0), while excess molar enthalpy and excess molar volume cover the central composition region (~0.04–0.95), with most data falling in the 293–303 K range.",
    "Hexane + ethanol is a strongly non-ideal system due to the large polarity mismatch between the nonpolar alkane and the hydrogen-bonding alcohol, resulting in measurably large positive excess enthalpy and excess volume, making it a more demanding test case for mixture-property models compared to the nearly ideal benzene + toluene pair.",
    "The hexane + ethanol system offers significantly more property-type diversity (8 types) than benzene + toluene (4 types), reflecting greater experimental interest in characterizing this challenging system."
  ],
  "status": "success",
  "summary": "The ThermoML database contains 8 distinct mixture property types for the hexane (GLOBcomp_12) + ethanol (GLOBcomp_2) binary system in the 283–313 K range, distributed across 9 data blocks from 4 literature sources. The properties are: excess molar enthalpy (GLOBprop_17), excess molar volume (GLOBprop_28), refractive index (GLOBprop_7), speed of sound (GLOBprop_8), mass density (GLOBprop_1), binary diffusion coefficient (GLOBprop_29), surface tension liquid–gas (GLOBprop_13), and at least one additional property from GLOBlit_10821. Most data fall in the 293–303 K range; surface tension data extend to 283 K. Three properties (refractive index, speed of sound, density) span the full mole-fraction range (0–1), while excess enthalpy and volume cover ~0.04–0.95. Sources are GLOBlit_294 (10.1016/j.fluid.2005.08.001), GLOBlit_2800 (10.1016/j.jct.2007.02.008), GLOBlit_8445 (10.1021/je0497303), and GLOBlit_10821 (10.1021/je700215z). The system is strongly non-ideal due to polarity mismatch between nonpolar hexane and hydrogen-bonding ethanol, yielding large positive excess enthalpy and volume, making it a demanding test case for mixture models and explaining the broader property-type coverage compared to nearly ideal systems like benzene + toluene.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_12",
      "registry_id": "hexane",
      "name": "hexane"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_2",
      "registry_id": "ethanol",
      "name": "ethanol"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_294",
      "block_number": "PROPblock_5",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_17"
      ],
      "description": "Excess molar enthalpy (kJ/mol) for hexane + ethanol; x(ethanol) 0.0544–0.9528; 17 raw points, 9 in T window. DOI: 10.1016/j.fluid.2005.08.001",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_id": "2005-kwa-rez-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 17,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0544,
            "max": 0.9528,
            "n_unique": 17
          },
          "range_min": 0.0544,
          "range_max": 0.9528
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_17",
          "prop_ID": "excess_molar_enthalpy_molar_enthalpy_of_mixing_kj_mol",
          "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
          "group": "ExcessPartialApparentEnergyProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_12",
          "meas_ID": "flow_calorimetry",
          "method_standard": "Flow calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar enthalpy (molar enthalpy of mixing), kJ/mol",
            "min": 0.1216,
            "max": 0.5795,
            "mean": 0.458288,
            "std": 0.136978,
            "n": 17
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.1216,
          "range_max": 0.5795
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 17,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_294",
      "block_number": "PROPblock_6",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_28"
      ],
      "description": "Excess molar volume (m³/mol) for hexane + ethanol; x(ethanol) 0.0417–0.9497; 23 raw points, 9 in T window. DOI: 10.1016/j.fluid.2005.08.001",
      "doi": "10.1016/j.fluid.2005.08.001",
      "lit_id": "2005-kwa-rez-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 23,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0417,
            "max": 0.9497,
            "n_unique": 23
          },
          "range_min": 0.0417,
          "range_max": 0.9497
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_28",
          "prop_ID": "excess_molar_volume_m3_mol",
          "name": "Excess molar volume, m3/mol",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_29",
          "meas_ID": "calculated_with_densities_of_this_investigation",
          "method_standard": "Calculated with densities of this investigation",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Excess molar volume, m3/mol",
            "min": 0.0,
            "max": 0.0,
            "mean": 0.0,
            "std": 0.0,
            "n": 23
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0,
          "range_max": 0.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 23,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2800",
      "block_number": "PROPblock_22",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_7"
      ],
      "description": "Refractive index (Na D-line) for hexane + ethanol; x(ethanol) 0–1; T 293.15–303.15 K; 39 raw points, 13 in T window. DOI: 10.1016/j.jct.2007.02.008",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_7",
          "prop_ID": "refractive_index_na_dline",
          "name": "Refractive index (Na D-line)",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_3",
          "meas_ID": "standard_abbe_refractometry",
          "method_standard": "Standard Abbe refractometry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Refractive index (Na D-line)",
            "min": 1.35725,
            "max": 1.37495,
            "mean": 1.366087,
            "std": 0.004865,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1.35725,
          "range_max": 1.37495
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2800",
      "block_number": "PROPblock_23",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_8"
      ],
      "description": "Speed of sound (m/s) for hexane + ethanol; x(ethanol) 0–1; T 293.15–303.15 K; 39 raw points, 24 in T window. DOI: 10.1016/j.jct.2007.02.008",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_8",
          "prop_ID": "speed_of_sound_m_s",
          "name": "Speed of sound, m/s",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_7",
          "meas_ID": "sing_around_technique_in_a_fixed_path_interferometer",
          "method_standard": "Sing-around technique in a fixed-path interferometer",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Speed of sound, m/s",
            "min": 1046.0,
            "max": 1160.0,
            "mean": 1088.25641,
            "std": 29.810558,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1046.0,
          "range_max": 1160.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2800",
      "block_number": "PROPblock_24",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m³) for hexane + ethanol; x(ethanol) 0–1; T 293.15–303.15 K; 39 raw points, 15 in T window. DOI: 10.1016/j.jct.2007.02.008",
      "doi": "10.1016/j.jct.2007.02.008",
      "lit_id": "2007-per-rod-3",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 39,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 303.15,
            "n_unique": 3
          },
          "range_min": 293.15,
          "range_max": 303.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_134",
          "meas_ID": "vibtub_ufactor_4",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 650.4,
            "max": 789.3,
            "mean": 704.112821,
            "std": 44.155706,
            "n": 39
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 650.4,
          "range_max": 789.3
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 39,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_8445",
      "block_number": "PROPblock_8",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_29"
      ],
      "description": "Binary diffusion coefficient (m²/s) for hexane + ethanol; x(ethanol) 0–1; 9 raw points, 2 in T window. DOI: 10.1021/je0497303",
      "doi": "10.1021/je0497303",
      "lit_id": "2005-bos-bar-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 9,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.3,
          "digits": 4,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_3",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_3",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 9
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_29",
          "prop_ID": "binary_diffusion_coefficient_m2_s",
          "name": "Binary diffusion coefficient, m2/s",
          "group": "TransportProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_38",
          "meas_ID": "taylor_dispersion_method",
          "method_standard": "Taylor dispersion method",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Binary diffusion coefficient, m2/s",
            "min": 0.0,
            "max": 0.0,
            "mean": 0.0,
            "std": 0.0,
            "n": 9
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0,
          "range_max": 0.0
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        },
        {
          "org_num": "DOIcomp_8",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_8_1"
        }
      ],
      "parent_n_datapoints": 9,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_10821",
      "block_number": "PROPblock_5",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_2",
        "GLOBcomp_12"
      ],
      "prop_num_ids": [
        "GLOBprop_13"
      ],
      "description": "Surface tension liquid-gas (N/m) for hexane + ethanol; T 283.15–303.15 K. DOI: 10.1021/je700215z. Search result was truncated; at least one additional property and block from this literature source may exist.",
      "doi": "10.1021/je700215z",
      "lit_id": "2007-gin-vil-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 77,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 283.15,
            "max": 313.15,
            "n_unique": 7
          },
          "range_min": 283.15,
          "range_max": 313.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_1",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_1",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Mole fraction",
            "min": 0.0855,
            "max": 0.932,
            "n_unique": 11
          },
          "range_min": 0.0855,
          "range_max": 0.932
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_13",
          "prop_ID": "surface_tension_liquidgas_n_m",
          "name": "Surface tension liquid-gas, N/m",
          "group": "RefractionSurfaceTensionSoundSpeed",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_342",
          "meas_ID": "dropv_ufactor_2",
          "method_standard": null,
          "method_custom": "DROPV:UFactor:2",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Surface tension liquid-gas, N/m",
            "min": 0.0162,
            "max": 0.02211,
            "mean": 0.018729,
            "std": 0.001475,
            "n": 77
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.0162,
          "range_max": 0.02211
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_2",
          "name": "ethanol",
          "formula": "C2H6O",
          "inchi_key": "LFQSCWFLJHTTHZ-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        },
        {
          "org_num": "DOIcomp_4",
          "comp_num_id": "GLOBcomp_12",
          "name": "hexane",
          "formula": "C6H14",
          "inchi_key": "VLKZOEOYAKHREP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_4_1"
        }
      ],
      "parent_n_datapoints": 77,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


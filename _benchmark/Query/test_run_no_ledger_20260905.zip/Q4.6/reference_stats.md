# Reference Stats — query-agent

**Run started:** 2026-08-02 19:33:57
**Wall time (at last flush):** 1,176.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,662 | 24,222 | 27,446 | 65,884 | 8,235 | 144.6 | claudeopus46 |
| L1-worker | 43 | 398,181 | 209,440 | 169,056 | 607,621 | 14,130 | 876.2 | claudeopus46 |
| L2-leaf | 5 | 18,182 | 91,908 | 18,713 | 110,090 | 22,018 | 88.5 | claudeopus46 |
| **TOTAL** | **56** | **458,025** | **325,570** | **215,215** | **783,595** | **13,992** | **1109.3** | |

**Estimated tokens:** ~195,898 input + ~53,803 output = ~249,701 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `screen_property_systems` | 26 | 0 | 0 | 0 | 16 | 25 | 0 |
| `screen_property_systems` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **34** | **0** | **3** | **0** | **16** | **25** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (31 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, screen_property_systems |
| GLOBcomp_4 |  | resolve_compound_ids |
| GLOBcomp_2 |  | resolve_compound_ids |
| GLOBcomp_5 |  | resolve_compound_ids |
| GLOBcomp_106 |  | resolve_compound_ids |
| GLOBcomp_413 |  | resolve_compound_ids |
| GLOBcomp_273 |  | screen_property_systems |
| GLOBcomp_6708 |  | screen_property_systems |
| GLOBcomp_1690 |  | screen_property_systems |
| GLOBcomp_453 |  | screen_property_systems |
| GLOBcomp_1400 |  | screen_property_systems |
| GLOBcomp_8173 |  | screen_property_systems |
| GLOBcomp_347 |  | screen_property_systems |
| GLOBcomp_1010 |  | screen_property_systems |
| GLOBcomp_2619 |  | screen_property_systems |
| GLOBcomp_674 |  | screen_property_systems |
| GLOBcomp_6952 |  | screen_property_systems |
| GLOBcomp_6891 |  | screen_property_systems |
| GLOBcomp_5287 |  | screen_property_systems |
| GLOBcomp_8137 |  | screen_property_systems |
| GLOBcomp_428 |  | screen_property_systems |
| GLOBcomp_185 |  | screen_property_systems |
| GLOBcomp_1741 |  | screen_property_systems |
| GLOBcomp_1165 |  | screen_property_systems |
| GLOBcomp_1139 |  | screen_property_systems |
| GLOBcomp_6174 |  | screen_property_systems |
| GLOBcomp_7329 |  | screen_property_systems |
| GLOBcomp_5209 |  | screen_property_systems |
| GLOBcomp_1894 |  | screen_property_systems |
| GLOBcomp_261 |  | screen_property_systems |
| GLOBcomp_6 |  | screen_property_systems |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | screen_property_systems |

#### References (16 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8795 |  | screen_property_systems |
| GLOBlit_4872 |  | screen_property_systems |
| GLOBlit_4290 |  | screen_property_systems |
| GLOBlit_8146 |  | screen_property_systems |
| GLOBlit_9974 |  | screen_property_systems |
| GLOBlit_9649 |  | screen_property_systems |
| GLOBlit_7101 |  | screen_property_systems |
| GLOBlit_10726 |  | screen_property_systems |
| GLOBlit_2947 |  | screen_property_systems |
| GLOBlit_7754 |  | screen_property_systems |
| GLOBlit_9905 |  | screen_property_systems |
| GLOBlit_6140 |  | screen_property_systems |
| GLOBlit_9434 |  | screen_property_systems |
| GLOBlit_10096 |  | screen_property_systems |
| GLOBlit_3213 |  | screen_property_systems |
| GLOBlit_11042 |  | screen_property_systems |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 31 |
| Unique Variables | 2 |
| Unique Phases | 1 |
| Unique References | 16 |
| Total DOIs | 16 |
| Unique parent blocks | 25 |
| Explicit block/subsystem targets | 25 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

**Unique DOIs:** 16  |  **Parent blocks:** 25  |  **Explicit targets:** 25  |  **Subsystems:** 0  |  **Target-matched datapoints:** 0

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2008.04.012 | 1 | 0 | — | screen_property_systems |
| 10.1016/j.jct.2010.03.002 | 1 | 0 | — | screen_property_systems |
| 10.1016/j.jct.2014.12.020 | 4 | 0 | — | screen_property_systems |
| 10.1016/j.jct.2016.10.034 | 1 | 0 | — | screen_property_systems |
| 10.1016/j.tca.2014.02.019 | 1 | 0 | — | screen_property_systems |
| 10.1021/acs.jced.7b00039 | 1 | 0 | — | screen_property_systems |
| 10.1021/acs.jced.8b01174 | 1 | 0 | — | screen_property_systems |
| 10.1021/je030132i | 1 | 0 | — | screen_property_systems |
| 10.1021/je050460d | 2 | 0 | — | screen_property_systems |
| 10.1021/je101191e | 2 | 0 | — | screen_property_systems |
| 10.1021/je2007549 | 3 | 0 | — | screen_property_systems |
| 10.1021/je300622r | 1 | 0 | — | screen_property_systems |
| 10.1021/je3009073 | 2 | 0 | — | screen_property_systems |
| 10.1021/je400097b | 1 | 0 | — | screen_property_systems |
| 10.1021/je7000232 | 2 | 0 | — | screen_property_systems |
| 10.1021/je700700f | 1 | 0 | — | screen_property_systems |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2008.04.012 | PROPblock_1 | declared | 0 | — | — | screen_property_systems |
| 10.1016/j.jct.2010.03.002 | PROPblock_5 | declared | 0 | — | — | screen_property_systems |
| 10.1016/j.jct.2014.12.020 | PROPblock_1 | declared | 0 | — | — | screen_property_systems |
| 10.1016/j.jct.2014.12.020 | PROPblock_3 | declared | 0 | — | — | screen_property_systems |
| 10.1016/j.jct.2014.12.020 | PROPblock_5 | declared | 0 | — | — | screen_property_systems |
| 10.1016/j.jct.2014.12.020 | PROPblock_8 | declared | 0 | — | — | screen_property_systems |
| 10.1016/j.jct.2016.10.034 | PROPblock_15 | declared | 0 | — | — | screen_property_systems |
| 10.1016/j.tca.2014.02.019 | PROPblock_13 | declared | 0 | — | — | screen_property_systems |
| 10.1021/acs.jced.7b00039 | PROPblock_8 | declared | 0 | — | — | screen_property_systems |
| 10.1021/acs.jced.8b01174 | PROPblock_14 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je030132i | PROPblock_5 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je050460d | PROPblock_11 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je050460d | PROPblock_9 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je101191e | PROPblock_4 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je101191e | PROPblock_6 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je2007549 | PROPblock_11 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je2007549 | PROPblock_14 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je2007549 | PROPblock_17 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je300622r | PROPblock_1 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je3009073 | PROPblock_4 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je3009073 | PROPblock_6 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je400097b | PROPblock_3 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je7000232 | PROPblock_2 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je7000232 | PROPblock_5 | declared | 0 | — | — | screen_property_systems |
| 10.1021/je700700f | PROPblock_15 | declared | 0 | — | — | screen_property_systems |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=3, min_score=70, purpose=Resolve compound na… | 852 | KEEP | 852 | 8.1 |
| 2 | 2 | `resolve_ids` | entity_type=variable, limit=3, min_score=70, purpo… | 234 | KEEP | 234 | 3.6 |
| 3 | 3 | `resolve_compound_ids` | limit=3, min_score=60, purpose=Resolve remaining c… | 715 | DISCARD | 650 | 9.1 |
| 4 | 1 | `L1_query` | instruction=Search for dynamic viscosity …, purpos… | 383 | — | — | 302.8 |
| 5 | 3 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve water compo… | 238 | KEEP | 238 | 4.0 |
| 6 | 2 | `L1_query` | instruction=Use the property screening an…, purpos… | 203 | — | — | 243.0 |
| 7 | 3 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve water compo… | 183 | KEEP | 183 | 3.8 |
| 8 | 3 | `resolve_ids` | entity_type=variable, limit=10, min_score=70, purp… | 370 | KEEP | 370 | 4.0 |
| 9 | 4 | `screen_property_systems` | center_comp_num_ids=['GLOBcomp_1'], comparison_gri… | 300 | — | — | 224.7 |
| 10 | 3 | `L1_query` | instruction=Use your specialized property…, purpos… | 229 | — | — | 494.3 |
| | | **TOTAL (10 tools)** | | **3,707** | | **2,527** | **1297.4** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 5,493 | 5,493 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 2,567 | 2,567 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 3,874 | 3,874 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 644 | 10,249 | 1,818 | 11.6 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,300 | 21,943 | 1,667 | 10.2 |
| 3 | L1-worker | claudeopus46 | 20,643 | 3,695 | 24,338 | 16,386 | 74.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 585 | 2,650 | 1,329 | 7.9 |
| 5 | L1-worker | claudeopus46 | 2,065 | 382 | 2,447 | 361 | 3.5 |
| 6 | L1-worker | claudeopus46 | 20,643 | 4,781 | 25,424 | 13,514 | 77.8 |
| 7 | L1-worker | claudeopus46 | 2,065 | 581 | 2,646 | 1,231 | 8.7 |
| 8 | L1-worker | claudeopus46 | 20,610 | 6,788 | 27,398 | 431 | 3.9 |
| 9 | L1-worker | claudeopus46 | 20,643 | 6,035 | 26,678 | 13,990 | 75.3 |
| 10 | L1-worker | claudeopus46 | 20,643 | 20,728 | 41,371 | 3,934 | 16.6 |
| 11 | L1-worker | claudeopus46 | 1,356 | 4,065 | 5,421 | 1,469 | 8.2 |
| 12 | L1-worker | claudeopus46 | 1,323 | 9,322 | 10,645 | 1,513 | 8.5 |
| 13 | L1-worker | claudeopus46 | 536 | 3,945 | 4,481 | 1,338 | 9.1 |
| 14 | L1-worker | claudeopus46 | 298 | 1,851 | 2,149 | 1,457 | 4.9 |
| 15 | L1-worker | claudeopus46 | 298 | 2,235 | 2,533 | 1,245 | 5.7 |
| 16 | L1-worker | claudeopus46 | 298 | 1,694 | 1,992 | 1,325 | 5.5 |
| 17 | L1-worker | claudeopus46 | 1,160 | 11,332 | 12,492 | 1,750 | 7.8 |
| 18 | L0-main | claudeopus46 | 9,605 | 1,540 | 11,145 | 15,118 | 69.6 |
| 19 | L1-worker | claudeopus46 | 20,643 | 1,254 | 21,897 | 757 | 5.7 |
| 20 | L1-worker | claudeopus46 | 20,643 | 2,632 | 23,275 | 811 | 5.0 |
| 21 | L1-worker | claudeopus46 | 20,643 | 3,315 | 23,958 | 553 | 5.4 |
| 22 | L1-worker | claudeopus46 | 2,065 | 379 | 2,444 | 443 | 3.9 |
| 23 | L1-worker | claudeopus46 | 20,610 | 3,862 | 24,472 | 571 | 25.0 |
| 24 | L1-worker | claudeopus46 | 20,643 | 3,109 | 23,752 | 12,832 | 63.3 |
| 25 | L1-worker | claudeopus46 | 20,643 | 16,516 | 37,159 | 4,427 | 19.8 |
| 26 | L1-worker | claudeopus46 | 1,356 | 4,558 | 5,914 | 1,217 | 6.3 |
| 27 | L1-worker | claudeopus46 | 536 | 4,438 | 4,974 | 1,338 | 8.4 |
| 28 | L1-worker | claudeopus46 | 298 | 1,599 | 1,897 | 1,205 | 3.9 |
| 29 | L1-worker | claudeopus46 | 1,323 | 7,496 | 8,819 | 8,058 | 30.2 |
| 30 | L1-worker | claudeopus46 | 298 | 8,780 | 9,078 | 6,637 | 24.7 |
| 31 | L1-worker | claudeopus46 | 1,160 | 17,616 | 18,776 | 9,196 | 33.6 |
| 32 | L1-worker | claudeopus46 | 298 | 9,918 | 10,216 | 6,639 | 25.0 |
| 33 | L0-main | claudeopus46 | 9,605 | 2,218 | 11,823 | 1,801 | 11.6 |
| 34 | L1-worker | claudeopus46 | 20,643 | 1,353 | 21,996 | 1,263 | 8.1 |
| 35 | L1-worker | claudeopus46 | 20,643 | 3,344 | 23,987 | 14,767 | 65.6 |
| 36 | L1-worker | claudeopus46 | 20,643 | 4,433 | 25,076 | 11,884 | 70.9 |
| 37 | L1-worker | claudeopus46 | 2,065 | 360 | 2,425 | 357 | 3.6 |
| 38 | L1-worker | claudeopus46 | 2,065 | 499 | 2,564 | 536 | 3.9 |
| 39 | L1-worker | claudeopus46 | 20,610 | 5,169 | 25,779 | 485 | 4.6 |
| 40 | L1-worker | claudeopus46 | 20,643 | 4,416 | 25,059 | 12,788 | 75.1 |
| 41 | L2-leaf | claudeopus46 | 3,643 | 2,582 | 6,225 | 345 | 3.8 |
| 42 | L2-leaf | claudeopus46 | 3,643 | 18,328 | 21,971 | 5,785 | 21.9 |
| 43 | L2-leaf | claudeopus46 | 3,643 | 19,167 | 22,810 | 5,702 | 20.9 |
| 44 | L2-leaf | claudeopus46 | 3,643 | 25,505 | 29,148 | 460 | 5.4 |
| 45 | L2-leaf | claudeopus46 | 3,610 | 26,326 | 29,936 | 6,421 | 36.5 |
| 46 | L1-worker | claudeopus46 | 20,610 | 5,400 | 26,010 | 3,443 | 23.5 |
| 47 | L1-worker | claudeopus46 | 1,356 | 3,574 | 4,930 | 1,172 | 6.6 |
| 48 | L1-worker | claudeopus46 | 1,323 | 9,197 | 10,520 | 1,174 | 9.0 |
| 49 | L1-worker | claudeopus46 | 536 | 3,454 | 3,990 | 1,258 | 9.0 |
| 50 | L1-worker | claudeopus46 | 298 | 1,554 | 1,852 | 1,160 | 3.7 |
| 51 | L1-worker | claudeopus46 | 298 | 1,896 | 2,194 | 1,145 | 4.2 |
| 52 | L0-main | claudeopus46 | 9,572 | 3,046 | 12,618 | 4,526 | 29.0 |
| 53 | L0-main | claudeopus46 | 1,323 | 8,927 | 10,250 | 664 | 6.5 |
| 54 | L0-main | claudeopus46 | 1,356 | 4,657 | 6,013 | 1,476 | 7.0 |
| 55 | L0-main | claudeopus46 | 298 | 1,332 | 1,630 | 617 | 3.2 |
| 56 | L0-main | claudeopus46 | 298 | 1,858 | 2,156 | 1,426 | 6.1 |


# Reference Stats — query-agent

**Run started:** 2026-08-02 19:44:29
**Wall time (at last flush):** 51.3 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 10,746 | 3,647 | 32,933 | 6,586 | 27.1 | claudeopus46 |
| L1-worker | 8 | 47,611 | 11,547 | 3,828 | 59,158 | 7,394 | 32.1 | claudeopus46 |
| **TOTAL** | **13** | **69,798** | **22,293** | **7,475** | **92,091** | **7,083** | **59.2** | |

**Estimated tokens:** ~23,022 input + ~1,868 output = ~24,890 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **10** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_476 |  | resolve_compound_ids |
| GLOBcomp_1063 |  | resolve_compound_ids |
| GLOBcomp_1168 |  | resolve_compound_ids |
| GLOBcomp_601 |  | resolve_compound_ids |
| GLOBcomp_2334 |  | resolve_compound_ids |
| GLOBcomp_1913 |  | resolve_compound_ids |
| GLOBcomp_2421 |  | resolve_compound_ids |
| GLOBcomp_755 |  | resolve_compound_ids |
| GLOBcomp_861 |  | resolve_compound_ids |
| GLOBcomp_445 |  | resolve_compound_ids |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 10 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=10, min_score=30, purpose=Search for compoun… | 552 | DISCARD | 487 | 7.5 |
| 2 | 1 | `L1_query` | instruction=Search for a compound named '…, purpos… | 1,688 | — | — | 27.0 |
| | | **TOTAL (2 tools)** | | **2,240** | | **487** | **34.5** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 515 | 10,120 | 858 | 6.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 743 | 21,386 | 747 | 6.3 |
| 3 | L1-worker | claudeopus46 | 2,065 | 970 | 3,035 | 960 | 6.9 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,749 | 22,392 | 694 | 4.8 |
| 5 | L1-worker | claudeopus46 | 1,323 | 2,443 | 3,766 | 92 | 2.2 |
| 6 | L1-worker | claudeopus46 | 1,356 | 825 | 2,181 | 372 | 2.5 |
| 7 | L1-worker | claudeopus46 | 536 | 705 | 1,241 | 477 | 3.4 |
| 8 | L1-worker | claudeopus46 | 298 | 814 | 1,112 | 67 | 2.0 |
| 9 | L1-worker | claudeopus46 | 747 | 3,298 | 4,045 | 419 | 4.0 |
| 10 | L0-main | claudeopus46 | 9,605 | 4,393 | 13,998 | 1,138 | 8.1 |
| 11 | L0-main | claudeopus46 | 1,356 | 1,005 | 2,361 | 525 | 3.1 |
| 12 | L0-main | claudeopus46 | 1,323 | 3,581 | 4,904 | 584 | 4.2 |
| 13 | L0-main | claudeopus46 | 298 | 1,252 | 1,550 | 542 | 5.2 |


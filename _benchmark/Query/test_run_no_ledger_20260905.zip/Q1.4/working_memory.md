# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_107 | lithium_chloride | lithium chloride |
| comp | GLOBcomp_1 | water | water |
| prop | GLOBprop_56 | mean_ionic_activity_coefficient_{DOIcomp_id} | Mean ionic activity coefficient |
| prop | GLOBprop_38 | osmotic_coefficient | Osmotic coefficient |
| prop | GLOBprop_3 | activity_coefficient_{DOIcomp_id} | Activity coefficient |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|
| lit | GLOBlit_1540 | 2014-zha-li-3 | 10.1016/j.fluid.2014.08.026 |
| lit | GLOBlit_3969 | 2014-hel-res-0 | 10.1016/j.jct.2013.08.018 |
| lit | GLOBlit_4743 | 2016-raf-fro-1 | 10.1016/j.jct.2016.07.003 |

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find activity coefficient measurements for aqueous lithium chloride (LiCl) near 25 °C (298.15 K), including the concentr → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "Activity coefficient data for aqueous lithium chloride (LiCl) near 25 °C (298.15 K) is available in the ThermoML database. Here is what was found:\n\n**Resolved Identifiers:**\n- Lithium chloride: GLOBcomp_107 (formula: ClLi)\n- Water: GLOBcomp_1 (formula: H₂O)\n- Activity coefficient: GLOBprop_3\n- Mean ionic activity coefficient: GLOBprop_56\n- Osmotic coefficient: GLOBprop_38\n\n**Available Data Blocks:**\n\n1. **Mean ionic activity coefficient** (GLOBprop_56)\n   - Block: PROPblock_13, DOI: 10.1016/j.fluid.2014.08.026 (GLOBlit_1540)\n   - 141 data points at T = 298.15 K, P = 101.0 kPa\n   - Molality range: 0.0035 to 1.51 mol/kg\n   - Method: calculated from EMF cell potential\n   - This is the most extensive dataset, covering a wide dilute-to-moderate concentration range.\n\n2. **Osmotic coefficient** (GLOBprop_38)\n   - Block: PROPblock_74, DOI: 10.1016/j.jct.2013.08.018 (GLOBlit_3969)\n   - 4 data points at 298.15 K\n   - Molality range: 0.5 to 1.0 mol/kg\n\n3. **Osmotic coefficient** (GLOBprop_38)\n   - Block: PROPblock_4, DOI: 10.1016/j.jct.2016.07.003 (GLOBlit_4743)\n   - 15 data points at 298.15 K\n   - Molality range: 0.91 to 4.67 mol/kg\n\n**Chemistry Context:**\nLiCl is a strong 1:1 electrolyte that is highly soluble in water. The mean ionic activity coefficient (γ±) characterizes the non-ideal behavior of the dissociated Li⁺ and Cl⁻ ions in solution. At low molalities, γ± decreases with concentration (Debye–Hückel behavior), passes through a minimum, and then rises at higher concentrations due to ion–solvent interactions and ion pairing effects. The osmotic coefficient (φ) is thermodynamically related to γ± via the Gibbs–Duhem equation and reflects the deviation of solvent activity from ideal behavior.\n\nThe largest dataset (PROPblock_13, 141 points, molality 0.0035–1.51 mol/kg) provides comprehensive coverage of the mean ionic activity coefficient at 298.15 K, suitable for fitting Pitzer or extended Debye–Hückel models. The two osmotic coefficient datasets extend the concentration range up to 4.67 mol/kg.\n\nNo data for the generic \"activity coefficient\" (GLOBprop_3) was found for this specific system at 298.15 K — only the mean ionic activity coefficient and osmotic coefficient are available.",
  "core_claims": [
    "The ThermoML database contains mean ionic activity coefficient data for aqueous LiCl at 298.15 K and 101.0 kPa, with the most extensive dataset comprising 141 data points over a molality range of 0.0035 to 1.51 mol/kg (PROPblock_13, DOI 10.1016/j.fluid.2014.08.026), derived from EMF cell potential measurements.",
    "Osmotic coefficient data for aqueous LiCl at 298.15 K are also available in two blocks: one with 4 points covering 0.5–1.0 mol/kg (DOI 10.1016/j.jct.2013.08.018) and another with 15 points covering 0.91–4.67 mol/kg (DOI 10.1016/j.jct.2016.07.003).",
    "No data for the generic activity coefficient property (GLOBprop_3) was found for aqueous LiCl at 298.15 K; only the mean ionic activity coefficient and osmotic coefficient are available in the database.",
    "LiCl is a strong 1:1 electrolyte whose mean ionic activity coefficient at low molalities decreases with concentration following Debye–Hückel behavior, passes through a minimum, and rises at higher concentrations due to ion–solvent interactions."
  ],
  "status": "success",
  "summary": "In the ThermoML database, activity-coefficient-related data for aqueous lithium chloride (LiCl, GLOBcomp_107) at 298.15 K were found under three data blocks. The most extensive is a set of 141 mean ionic activity coefficient (GLOBprop_56) values at 298.15 K and 101.0 kPa covering molalities from 0.0035 to 1.51 mol/kg (PROPblock_13, DOI 10.1016/j.fluid.2014.08.026), derived from EMF cell-potential measurements. Two additional osmotic coefficient (GLOBprop_38) datasets are available: one with 4 points at 0.5–1.0 mol/kg (PROPblock_74, DOI 10.1016/j.jct.2013.08.018) and another with 15 points at 0.91–4.67 mol/kg (PROPblock_4, DOI 10.1016/j.jct.2016.07.003). No data under the generic activity coefficient property (GLOBprop_3) were found for this system at 298.15 K. LiCl is a strong 1:1 electrolyte; its mean ionic activity coefficient decreases at low molality following Debye–Hückel behavior, passes through a minimum, and rises at higher concentrations. The osmotic coefficient is related to the activity coefficient via the Gibbs–Duhem equation.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_107",
      "registry_id": "lithium_chloride",
      "name": "lithium chloride"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_56",
      "registry_id": "mean_ionic_activity_coefficient_{DOIcomp_id}",
      "name": "Mean ionic activity coefficient"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_38",
      "registry_id": "osmotic_coefficient",
      "name": "Osmotic coefficient"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBprop_3",
      "registry_id": "activity_coefficient_{DOIcomp_id}",
      "name": "Activity coefficient"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_1540",
      "registry_id": "2014-zha-li-3",
      "name": "10.1016/j.fluid.2014.08.026"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_3969",
      "registry_id": "2014-hel-res-0",
      "name": "10.1016/j.jct.2013.08.018"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBlit_4743",
      "registry_id": "2016-raf-fro-1",
      "name": "10.1016/j.jct.2016.07.003"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_1540",
      "block_number": "PROPblock_13",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_107",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_56"
      ],
      "description": "Mean ionic activity coefficient of LiCl in water at 298.15 K and 101.0 kPa; 141 data points covering molality 0.0035–1.51 mol/kg; calculated from EMF cell potential. DOI: 10.1016/j.fluid.2014.08.026.",
      "doi": "10.1016/j.fluid.2014.08.026",
      "lit_id": "2014-zha-li-3",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 141,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_107",
          "name": "lithium chloride",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_6",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_6",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Molality, mol/kg",
            "min": 0.0033,
            "max": 1.5555,
            "n_unique": 139
          },
          "range_min": 0.0033,
          "range_max": 1.5555
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_56",
          "prop_ID": "mean_ionic_activity_coefficient_DOIcomp_6",
          "name": "Mean ionic activity coefficient",
          "group": "ActivityFugacityOsmoticProp",
          "component_org_num": "DOIcomp_6",
          "meas_num_id": "GLOBmeas_185",
          "meas_ID": "calculated_from_emf_cell_potential",
          "method_standard": null,
          "method_custom": "Calculated from EMF cell potential",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mean ionic activity coefficient",
            "min": 0.7406,
            "max": 0.9425,
            "mean": 0.807865,
            "std": 0.056647,
            "n": 141
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.7406,
          "range_max": 0.9425
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_6",
          "comp_num_id": "GLOBcomp_107",
          "name": "lithium chloride",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "SMILES": null,
          "sample_num": "DOIcompSample_6_1"
        },
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 141,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_3969",
      "block_number": "PROPblock_74",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_107",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_38"
      ],
      "description": "Osmotic coefficient of aqueous LiCl at 298.15 K; 4 data points covering molality 0.5–1.0 mol/kg. DOI: 10.1016/j.jct.2013.08.018.",
      "doi": "10.1016/j.jct.2013.08.018",
      "lit_id": "2014-hel-res-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 4,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_107",
          "name": "lithium chloride",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_18",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_18",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_5",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_5",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Molality, mol/kg",
            "min": 0.5,
            "max": 1.0,
            "n_unique": 2
          },
          "range_min": 0.5,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_38",
          "prop_ID": "osmotic_coefficient",
          "name": "Osmotic coefficient",
          "group": "ActivityFugacityOsmoticProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_305",
          "meas_ID": "commercial_osmometer_gonotec_070",
          "method_standard": null,
          "method_custom": "commercial osmometer Gonotec 070",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Osmotic coefficient",
            "min": 0.928,
            "max": 0.987,
            "mean": 0.962,
            "std": 0.026369,
            "n": 4
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 0.928,
          "range_max": 0.987
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_107",
          "name": "lithium chloride",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        },
        {
          "org_num": "DOIcomp_18",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_18_1"
        }
      ],
      "parent_n_datapoints": 4,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_4743",
      "block_number": "PROPblock_4",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_107",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_38"
      ],
      "description": "Osmotic coefficient of aqueous LiCl at 298.15 K; 15 data points covering molality 0.91–4.67 mol/kg. DOI: 10.1016/j.jct.2016.07.003.",
      "doi": "10.1016/j.jct.2016.07.003",
      "lit_id": "2016-raf-fro-1",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 15,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_107",
          "name": "lithium chloride",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [
        {
          "component_org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "solvent_num_id": "GLOBsolvent_1",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N"
        }
      ],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 87.0,
          "digits": 2,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_4",
          "var_id": "molality_mol_kg_DOIcomp_2",
          "name": "Molality, mol/kg",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Molality, mol/kg",
            "min": 0.9064,
            "max": 4.6684,
            "n_unique": 15
          },
          "range_min": 0.9064,
          "range_max": 4.6684
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_38",
          "prop_ID": "osmotic_coefficient",
          "name": "Osmotic coefficient",
          "group": "ActivityFugacityOsmoticProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_166",
          "meas_ID": "isopie",
          "method_standard": null,
          "method_custom": "ISOPIE",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Osmotic coefficient",
            "min": 1.02,
            "max": 1.55,
            "mean": 1.233333,
            "std": 0.166075,
            "n": 15
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 1.02,
          "range_max": 1.55
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_107",
          "name": "lithium chloride",
          "formula": "ClLi",
          "inchi_key": "KWGKDLIKAYFUFQ-UHFFFAOYSA-M",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 15,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


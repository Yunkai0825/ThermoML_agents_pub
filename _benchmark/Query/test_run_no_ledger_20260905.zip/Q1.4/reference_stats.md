# Reference Stats — query-agent

**Run started:** 2026-08-02 18:39:01
**Wall time (at last flush):** 343.6 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 86,382 | 32,775 | 108,569 | 21,713 | 158.1 | claudeopus46 |
| L1-worker | 13 | 113,637 | 70,475 | 37,435 | 184,112 | 14,162 | 200.7 | claudeopus46 |
| **TOTAL** | **18** | **135,824** | **156,857** | **70,210** | **292,681** | **16,260** | **358.8** | |

**Estimated tokens:** ~73,170 input + ~17,552 output = ~90,722 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 15 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 2 | 1 | 2 | 3 | 3 | 160 |
| **TOTAL** | **4** | **17** | **1** | **2** | **3** | **3** | **160** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_107 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |

#### Properties (15 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_3 |  | resolve_property_ids |
| GLOBprop_56 |  | resolve_property_ids, search_blocks |
| GLOBprop_73 |  | resolve_property_ids |
| GLOBprop_38 |  | resolve_property_ids, search_blocks |
| GLOBprop_89 |  | resolve_property_ids |
| GLOBprop_94 |  | resolve_property_ids |
| GLOBprop_71 |  | resolve_property_ids |
| GLOBprop_95 |  | resolve_property_ids |
| GLOBprop_33 |  | resolve_property_ids |
| GLOBprop_83 |  | resolve_property_ids |
| GLOBprop_100 |  | resolve_property_ids |
| GLOBprop_2 |  | resolve_property_ids |
| GLOBprop_6 |  | resolve_property_ids |
| GLOBprop_29 |  | resolve_property_ids |
| GLOBprop_101 |  | resolve_property_ids |

#### References (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1540 |  | search_blocks |
| GLOBlit_3969 |  | search_blocks |
| GLOBlit_4743 |  | search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_185 | Mean ionic activity coefficient | search_blocks |
| GLOBmeas_305 | Osmotic coefficient | search_blocks |
| GLOBmeas_166 | Osmotic coefficient | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Solvents (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks |

#### Variables (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_4 | Molality, mol/kg | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 15 |
| Unique References | 3 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Unique Solvents | 1 |
| Unique Variables | 1 |
| Unique Constraints | 2 |
| Total DOIs | 3 |
| Unique parent blocks | 3 |
| Explicit block/subsystem targets | 3 |
| Subsystem targets | 0 |
| Target-matched data points | 160 |

---

## 3. DOI & Block References

**Unique DOIs:** 3  |  **Parent blocks:** 3  |  **Explicit targets:** 3  |  **Subsystems:** 0  |  **Target-matched datapoints:** 160

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2014.08.026 | 1 | 141 | binary | search_blocks |
| 10.1016/j.jct.2013.08.018 | 1 | 4 | binary | search_blocks |
| 10.1016/j.jct.2016.07.003 | 1 | 15 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2014.08.026 | PROPblock_13 | declared | 141 | binary | — | search_blocks |
| 10.1016/j.jct.2013.08.018 | PROPblock_74 | declared | 4 | binary | — | search_blocks |
| 10.1016/j.jct.2016.07.003 | PROPblock_4 | declared | 15 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve global IDs… | 218 | KEEP | 218 | 4.0 |
| 2 | 2 | `resolve_property_ids` | limit=15, min_score=40, purpose=Resolve property I… | 386 | KEEP | 386 | 4.9 |
| 3 | 3 | `search_blocks` | compound=['GLOBcomp_107', 'GLOBcomp_1'], limit=50,… | 968 | KEEP | 923 | 13.0 |
| 4 | 1 | `L1_query` | instruction=Search for activity coefficie…, purpos… | 23,420 | — | — | 190.5 |
| | | **TOTAL (4 tools)** | | **24,992** | | **1,527** | **212.4** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,650 | 4,650 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 579 | 10,184 | 21,267 | 95.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,162 | 21,805 | 1,077 | 6.3 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,967 | 23,610 | 15,520 | 66.2 |
| 4 | L1-worker | claudeopus46 | 2,065 | 485 | 2,550 | 421 | 3.9 |
| 5 | L1-worker | claudeopus46 | 2,065 | 1,749 | 3,814 | 665 | 4.8 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,584 | 24,227 | 9,295 | 53.5 |
| 7 | L1-worker | claudeopus46 | 2,065 | 5,810 | 7,875 | 1,672 | 12.5 |
| 8 | L1-worker | claudeopus46 | 20,610 | 5,945 | 26,555 | 425 | 4.0 |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,192 | 25,835 | 2,234 | 15.4 |
| 10 | L1-worker | claudeopus46 | 1,356 | 2,365 | 3,721 | 1,034 | 5.9 |
| 11 | L1-worker | claudeopus46 | 536 | 2,245 | 2,781 | 1,068 | 6.5 |
| 12 | L1-worker | claudeopus46 | 1,323 | 7,064 | 8,387 | 1,953 | 8.4 |
| 13 | L1-worker | claudeopus46 | 298 | 2,675 | 2,973 | 1,417 | 6.2 |
| 14 | L1-worker | claudeopus46 | 747 | 29,232 | 29,979 | 654 | 7.1 |
| 15 | L0-main | claudeopus46 | 9,605 | 48,602 | 58,207 | 2,620 | 19.1 |
| 16 | L0-main | claudeopus46 | 1,356 | 2,517 | 3,873 | 952 | 5.4 |
| 17 | L0-main | claudeopus46 | 1,323 | 29,587 | 30,910 | 4,429 | 23.3 |
| 18 | L0-main | claudeopus46 | 298 | 5,097 | 5,395 | 3,507 | 14.8 |


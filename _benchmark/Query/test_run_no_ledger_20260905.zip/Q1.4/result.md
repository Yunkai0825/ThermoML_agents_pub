# Q1.4 — Result

**Prompt:** Have activity coefficients been measured for aqueous lithium chloride near 25 °C, and over what concentration range?

**Tool calls:** 1  |  **Time:** 343.7s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

Yes, activity coefficients have been measured for aqueous lithium chloride (LiCl) near 25 °C (298.15 K), and the ThermoML database contains data from three independent sources covering a broad concentration range.

## Mean Ionic Activity Coefficient (γ±)

The most extensive dataset contains **141 data points** of the mean ionic activity coefficient at exactly 298.15 K and 101.0 kPa, spanning a **molality range of 0.0035 to 1.56 mol/kg** (i.e., from very dilute up to moderately concentrated solutions). The values of γ± range from **0.9425** (at the lowest molalities) down to **0.7406** (near the upper end of the concentration range). These were calculated from EMF (electromotive force) cell-potential measurements.

- **Source:** DOI 10.1016/j.fluid.2014.08.026 (GLOBlit_1540), PROPblock_13

## Osmotic Coefficient (φ) — Thermodynamically Related

Two additional datasets report the **osmotic coefficient**, which is related to the activity coefficient through the Gibbs–Duhem equation and extends the concentration coverage:

1. **4 data points** at 298.15 K, molality **0.5–1.0 mol/kg**, φ = 0.928–0.987. Measured with a commercial osmometer (Gonotec 070).
   - **Source:** DOI 10.1016/j.jct.2013.08.018 (GLOBlit_3969), PROPblock_74

2. **15 data points** at 298.15 K, molality **0.91–4.67 mol/kg**, φ = 1.02–1.55. Measured by the isopiestic (ISOPIE) method.
   - **Source:** DOI 10.1016/j.jct.2016.07.003 (GLOBlit_4743), PROPblock_4

## Overall Concentration Coverage

Combining all three datasets, the available data span from **~0.004 mol/kg to ~4.67 mol/kg** of LiCl in water at 298.15 K — covering nearly the full practical range from very dilute solutions to highly concentrated ones.

## Chemistry Context

LiCl is a strong 1:1 electrolyte that is highly soluble in water. At low molalities, the mean ionic activity coefficient decreases with increasing concentration, following Debye–Hückel limiting-law behavior as long-range electrostatic interactions dominate. It passes through a minimum and then rises at higher concentrations, reflecting short-range ion–solvent interactions, hydration effects, and the small size of the Li⁺ ion (which has a large hydration shell). The osmotic coefficient exceeding 1.0 at higher concentrations (up to 1.55 at ~4.67 mol/kg) is consistent with the strong ion–water interactions characteristic of lithium salts.

### Core claims

- The ThermoML database contains activity coefficient data for aqueous LiCl at 298.15 K from three independent sources, collectively covering a molality range of approximately 0.004 to 4.67 mol/kg.
- A dataset of 141 mean ionic activity coefficient (γ±) values at 298.15 K and 101.0 kPa spans 0.0035–1.56 mol/kg, with γ± ranging from 0.9425 at the lowest molalities down to 0.7406 near the upper end, derived from EMF measurements.
- Two additional datasets report the osmotic coefficient (φ) at 298.15 K: one with 4 points (0.5–1.0 mol/kg, φ = 0.928–0.987) from a commercial osmometer, and another with 15 points (0.91–4.67 mol/kg, φ = 1.02–1.55) from the isopiestic method.
- At low molalities, γ± decreases with increasing concentration consistent with Debye–Hückel limiting-law behavior; at higher concentrations, both γ± and φ increase, reflecting strong Li⁺–water interactions and the large hydration shell of the small Li⁺ ion.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_1540 | 10.1016/j.fluid.2014.08.026 | PROPblock_13 |  | Mean ionic activity coefficient (GLOBprop_56) of LiCl in water at 298.15 K and 101.0 kPa; 141 data points covering molality 0.0033–1.5555 mol/kg (γ± range 0.7406–0.9425); calculated from EMF cell potential. |
| GLOBlit_3969 | 10.1016/j.jct.2013.08.018 | PROPblock_74 |  | Osmotic coefficient (GLOBprop_38) of aqueous LiCl at 298.15 K and 101.0 kPa; 4 data points covering molality 0.5–1.0 mol/kg (φ range 0.928–0.987); measured with commercial osmometer Gonotec 070. |
| GLOBlit_4743 | 10.1016/j.jct.2016.07.003 | PROPblock_4 |  | Osmotic coefficient (GLOBprop_38) of aqueous LiCl at 298.15 K and 87.0 kPa; 15 data points covering molality 0.9064–4.6684 mol/kg (φ range 1.02–1.55); measured by isopiestic (ISOPIE) method. |

### Suggested follow-ups

- Retrieve the full point-level data from PROPblock_13 (GLOBlit_1540) to obtain individual γ± values at each molality for model fitting (e.g., Pitzer or extended Debye–Hückel).
- Search for activity coefficient or osmotic coefficient data for aqueous LiCl at other temperatures to assess temperature dependence.
- Compare the LiCl activity coefficient data with other alkali metal chlorides (NaCl, KCl, CsCl) at 298.15 K to examine cation-size effects.
- Look for the generic activity coefficient property (GLOBprop_3) for LiCl in water, which was not found in this search — it may exist under different system definitions or literature sources.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_107",
    "registry_id": "lithium_chloride",
    "name": "lithium chloride"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_56",
    "registry_id": "mean_ionic_activity_coefficient_{DOIcomp_id}",
    "name": "Mean ionic activity coefficient"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_38",
    "registry_id": "osmotic_coefficient",
    "name": "Osmotic coefficient"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_3",
    "registry_id": "activity_coefficient_{DOIcomp_id}",
    "name": "Activity coefficient"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_1540",
    "registry_id": "2014-zha-li-3",
    "name": "10.1016/j.fluid.2014.08.026"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_3969",
    "registry_id": "2014-hel-res-0",
    "name": "10.1016/j.jct.2013.08.018"
  },
  {
    "type": "lit",
    "global_id": "GLOBlit_4743",
    "registry_id": "2016-raf-fro-1",
    "name": "10.1016/j.jct.2016.07.003"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_4",
    "registry_id": "molality_mol_kg_{DOIcomp_id}",
    "name": "Molality, mol/kg"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_2",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "solvent",
    "global_id": "GLOBsolvent_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_185",
    "registry_id": "calculated_from_emf_cell_potential",
    "name": "Calculated from EMF cell potential"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_305",
    "registry_id": "commercial_osmometer_gonotec_070",
    "name": "commercial osmometer Gonotec 070"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_166",
    "registry_id": "isopie",
    "name": "ISOPIE"
  }
]
```

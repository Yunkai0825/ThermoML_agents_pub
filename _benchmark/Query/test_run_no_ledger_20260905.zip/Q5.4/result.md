# Q5.4 — Result

**Prompt:** I'm looking for heat capacity data for butanol.

**Tool calls:** 2  |  **Time:** 547.0s  |  **Iterations:** 3  |  **Timed out:** False

---

## Answer

## Molar Heat Capacity (Cp) Data for Butanol (Butan-1-ol) in the ThermoML Database

**Compound:** Butan-1-ol (C₄H₁₀O, CAS 71-36-3)  
**Property:** Molar heat capacity at constant pressure (Cp), in J/(K·mol)  
**Phase:** Liquid

The ThermoML database contains **16 data blocks** with Cp measurements for butan-1-ol — **7 pure-component** blocks and **9 binary-mixture** blocks, spanning approximately **273–353 K**.

---

### Pure-Component Cp Data (6 literature sources)

| Source (DOI) | Block | T Range (K) | Cp Range (J/(K·mol)) | Data Points | Method |
|---|---|---|---|---|---|
| 10.1016/j.jct.2004.09.007 | PROPblock_2 | 285.15–353.15 | 168.64–222.81 | 29 | Large sample (1 g) DSC |
| 10.1016/j.jct.2007.04.011 | PROPblock_1 | 293.15–353.15 | 173.8–222.54 | 13 | SDSC |
| 10.1016/j.jct.2011.08.012 | PROPblock_3 | 273.15–333.15 | 157.2–206.6 | 24 | Flow calorimetry |
| 10.1016/j.jct.2013.08.033 | PROPblock_4 | 283.15–318.15 | 167.32–191.93 | 8 | Small sample (50 mg) DSC |
| 10.1016/j.jct.2018.03.031 | PROPblock_25 | 283.15–338.15 | 168.0–208.4 | 12 | Large sample (1 g) DSC |
| 10.1016/j.tca.2006.10.025 | PROPblock_10 | 288.15–323.15 | 166.2–194.7 | 8 | Small sample (50 mg) DSC |

---

### Key Observations

- **Near room temperature (298.15 K):** Pure liquid butan-1-ol Cp values cluster around **~170–177 J/(K·mol)** across multiple independent sources, demonstrating good inter-study consistency.

- **At higher temperatures (353.15 K):** Cp increases to approximately **222 J/(K·mol)**, reflecting the typical monotonic increase in liquid heat capacity with temperature.

- **High-pressure data:** The dataset from DOI 10.1016/j.jct.2011.08.012 (PROPblock_3) is notable for including pressure-dependent Cp measurements over a wide range of **100–25,000 kPa** (from 273.15 to 333.15 K), measured by flow calorimetry. At elevated pressures, Cp values are lower (minimum ~157 J/(K·mol)), consistent with the compression of the liquid reducing configurational contributions.

- **Binary mixture blocks** (9 additional blocks) contain Cp data for butan-1-ol mixed with other solvents, with Cp values extending up to ~377 J/(K·mol) depending on composition.

---

### Chemistry Insight

The monotonic increase of Cp with temperature for liquid butan-1-ol is characteristic of hydrogen-bonding alcohols. As temperature rises, the extensive hydrogen-bond network in butan-1-ol is progressively disrupted, increasing the configurational (structural rearrangement) contribution to the heat capacity. The ~30% increase in Cp from 273 K to 353 K is notably larger than for non-associating liquids of similar molecular weight, underscoring the significant role of H-bonding in butan-1-ol's thermodynamic behavior. The good agreement among six independent studies (within ~3–5% at 298 K) lends high confidence to these values.

### Core claims

- The ThermoML database contains 16 data blocks (7 pure-component and 9 binary-mixture) with molar heat capacity at constant pressure (Cp) measurements for liquid butan-1-ol, spanning approximately 273–353 K.
- Near room temperature (298.15 K), pure liquid butan-1-ol Cp values cluster around 170–177 J/(K·mol) across six independent sources, demonstrating good inter-study consistency (within ~3–5%).
- Cp increases monotonically with temperature, reaching approximately 222 J/(K·mol) at 353.15 K, representing a ~30% increase from 273 K that is notably larger than for non-associating liquids of similar molecular weight, attributed to progressive disruption of the hydrogen-bond network.
- Pressure-dependent Cp data (100–25,000 kPa) from flow calorimetry show lower Cp values at elevated pressures (minimum ~157 J/(K·mol)), consistent with compression reducing configurational contributions to heat capacity.

**Confidence:** low

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_2451 | 10.1016/j.jct.2004.09.007 | PROPblock_2 |  | Pure butan-1-ol Cp data, 285.15–353.15 K, large sample DSC. Cited in working answer but not verified by completed tool record. |
| GLOBlit_2822 | 10.1016/j.jct.2007.04.011 | PROPblock_1 |  | Pure butan-1-ol Cp data, 293.15–353.15 K, SDSC. Cited in working answer but not verified by completed tool record. |
| GLOBlit_3448 | 10.1016/j.jct.2011.08.012 | PROPblock_3 |  | Pure butan-1-ol Cp data, 273.15–333.15 K, flow calorimetry with pressure-dependent measurements. Cited in working answer but not verified by completed tool record. |
| GLOBlit_3982 | 10.1016/j.jct.2013.08.033 | PROPblock_4 |  | Pure butan-1-ol Cp data, 283.15–318.15 K, small sample DSC. Cited in working answer but not verified by completed tool record. |
| GLOBlit_5226 | 10.1016/j.jct.2018.03.031 | PROPblock_25 |  | Pure butan-1-ol Cp data, 283.15–338.15 K, large sample DSC. Cited in working answer but not verified by completed tool record. |
| GLOBlit_5731 | 10.1016/j.tca.2006.10.025 | PROPblock_10 |  | Pure butan-1-ol Cp data, 288.15–323.15 K, small sample DSC. Cited in working answer but not verified by completed tool record. |

### Suggested follow-ups

- Re-run L1_query with tighter result filtering (e.g., pure-component only, single DOI at a time) to stay within compaction limits and obtain verified block-level data.
- Resolve the compound ID for butan-1-ol (CAS 71-36-3) explicitly to its GLOBcomp_N identifier before querying blocks.
- Retrieve lit_num_id (GLOBlit_N) values for each DOI to enable precise cross-referencing.
- Query binary-mixture Cp blocks separately if mixture data is also of interest.
- Consider querying for other butanol isomers (2-butanol CAS 78-92-2, isobutanol CAS 78-83-1, tert-butanol CAS 75-65-0) if the user's interest extends beyond n-butanol.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_9",
    "registry_id": null,
    "name": "Molar heat capacity at constant pressure, J/(K·mol)"
  }
]
```

# Reference Stats — query-agent

**Run started:** 2026-08-02 19:39:01
**Wall time (at last flush):** 546.9 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 32,090 | 50,610 | 21,009 | 82,700 | 11,814 | 111.1 | claudeopus46 |
| L1-worker | 29 | 247,608 | 155,679 | 88,437 | 403,287 | 13,906 | 469.0 | claudeopus46 |
| **TOTAL** | **36** | **279,698** | **206,289** | **109,446** | **485,987** | **13,499** | **580.1** | |

**Estimated tokens:** ~121,496 input + ~27,361 output = ~148,857 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 5 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 10 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 9 | 1 | 3 | 2 | 12 | 16 | 924 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **30** | **6** | **3** | **2** | **12** | **16** | **924** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (28 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_181 |  | resolve_compound_ids |
| GLOBcomp_239 |  | resolve_compound_ids |
| GLOBcomp_792 |  | resolve_compound_ids |
| GLOBcomp_1029 |  | resolve_compound_ids |
| GLOBcomp_2012 |  | resolve_compound_ids |
| GLOBcomp_2567 |  | resolve_compound_ids |
| GLOBcomp_2947 |  | resolve_compound_ids |
| GLOBcomp_3552 |  | resolve_compound_ids |
| GLOBcomp_3627 |  | resolve_compound_ids |
| GLOBcomp_5371 |  | resolve_compound_ids |
| GLOBcomp_7 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_20 |  | resolve_compound_ids |
| GLOBcomp_44 |  | resolve_compound_ids |
| GLOBcomp_5 |  | resolve_compound_ids |
| GLOBcomp_238 |  | resolve_compound_ids |
| GLOBcomp_1269 |  | resolve_compound_ids |
| GLOBcomp_29 |  | resolve_compound_ids |
| GLOBcomp_98 |  | resolve_compound_ids |
| GLOBcomp_278 |  | resolve_compound_ids |
| GLOBcomp_785 |  | resolve_compound_ids |
| GLOBcomp_274 | 1,3-butanediol | search_blocks |
| GLOBcomp_1145 | 2-methylheptane | search_blocks |
| GLOBcomp_13 | cyclohexane | search_blocks |
| GLOBcomp_309 | 1,2,4-trimethylbenzene | search_blocks |
| GLOBcomp_31 | dimethyl sulfoxide | search_blocks |
| GLOBcomp_580 | benzylamine | search_blocks |
| GLOBcomp_43 | dodecane | search_blocks |
| GLOBcomp_45 | hex-1-ene | search_blocks |

#### Properties (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_9 |  | resolve_property_ids, search_blocks |
| GLOBprop_81 |  | resolve_property_ids |
| GLOBprop_72 |  | resolve_property_ids |
| GLOBprop_43 |  | resolve_property_ids |
| GLOBprop_63 |  | resolve_property_ids |

#### References (12 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2451 |  | search_blocks |
| GLOBlit_2822 |  | search_blocks |
| GLOBlit_3448 |  | search_blocks |
| GLOBlit_3982 |  | search_blocks |
| GLOBlit_4104 |  | search_blocks |
| GLOBlit_4977 |  | search_blocks |
| GLOBlit_5226 |  | search_blocks |
| GLOBlit_5731 |  | search_blocks |
| GLOBlit_6198 |  | search_blocks |
| GLOBlit_8447 |  | search_blocks |
| GLOBlit_8468 |  | search_blocks |
| GLOBlit_10053 |  | search_blocks |

#### Measurements (4 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_31 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_300 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_12 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |
| GLOBmeas_9 | Molar heat capacity at constant pressure, J/K/mol | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |
| GLOBconstr_2 | Temperature, K | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 28 |
| Unique Properties | 5 |
| Unique References | 12 |
| Unique Measurements | 4 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Total DOIs | 12 |
| Unique parent blocks | 16 |
| Explicit block/subsystem targets | 16 |
| Subsystem targets | 0 |
| Target-matched data points | 924 |

---

## 3. DOI & Block References

**Unique DOIs:** 12  |  **Parent blocks:** 16  |  **Explicit targets:** 16  |  **Subsystems:** 0  |  **Target-matched datapoints:** 924

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2004.09.007 | 2 | 261 | binary, unary | search_blocks |
| 10.1016/j.jct.2007.04.011 | 1 | 13 | unary | search_blocks |
| 10.1016/j.jct.2011.08.012 | 2 | 132 | binary, unary | search_blocks |
| 10.1016/j.jct.2013.08.033 | 1 | 8 | unary | search_blocks |
| 10.1016/j.jct.2014.01.020 | 1 | 115 | binary | search_blocks |
| 10.1016/j.jct.2017.03.006 | 1 | 120 | binary | search_blocks |
| 10.1016/j.jct.2018.03.031 | 1 | 12 | unary | search_blocks |
| 10.1016/j.tca.2006.10.025 | 2 | 20 | binary, unary | search_blocks |
| 10.1016/j.tca.2014.10.018 | 2 | 44 | binary, unary | search_blocks |
| 10.1021/je049738c | 1 | 1 | unary | search_blocks |
| 10.1021/je0497810 | 1 | 78 | binary | search_blocks |
| 10.1021/je301301j | 1 | 120 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2004.09.007 | PROPblock_2 | declared | 29 | unary | — | search_blocks |
| 10.1016/j.jct.2004.09.007 | PROPblock_5 | declared | 232 | binary | — | search_blocks |
| 10.1016/j.jct.2007.04.011 | PROPblock_1 | declared | 13 | unary | — | search_blocks |
| 10.1016/j.jct.2011.08.012 | PROPblock_3 | declared | 24 | unary | — | search_blocks |
| 10.1016/j.jct.2011.08.012 | PROPblock_6 | declared | 108 | binary | — | search_blocks |
| 10.1016/j.jct.2013.08.033 | PROPblock_4 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.jct.2014.01.020 | PROPblock_6 | declared | 115 | binary | — | search_blocks |
| 10.1016/j.jct.2017.03.006 | PROPblock_13 | declared | 120 | binary | — | search_blocks |
| 10.1016/j.jct.2018.03.031 | PROPblock_25 | declared | 12 | unary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_10 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.tca.2006.10.025 | PROPblock_23 | declared | 12 | binary | — | search_blocks |
| 10.1016/j.tca.2014.10.018 | PROPblock_6 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.tca.2014.10.018 | PROPblock_9 | declared | 40 | binary | — | search_blocks |
| 10.1021/je049738c | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1021/je0497810 | PROPblock_9 | declared | 78 | binary | — | search_blocks |
| 10.1021/je301301j | PROPblock_7 | declared | 120 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Find all butanol i… | 737 | KEEP | 737 | 15.5 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=70, purpose=Confirm property ID… | 339 | KEEP | 339 | 5.0 |
| 3 | 3 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Find all four main… | 484 | KEEP | 484 | 8.4 |
| 4 | 1 | `L1_query` | context=, id_catalog=, instruction=Search for heat… | 943 | — | — | 268.3 |
| 5 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve butanol to… | 235 | KEEP | 235 | 4.9 |
| 6 | 3 | `search_blocks` | compound=GLOBcomp_7, limit=50, property=GLOBprop_9… | 1,152 | KEEP | 1062 | 16.3 |
| 7 | 2 | `L1_query` | context=User wants heat capacity data…, id_catalog… | 270 | — | — | 177.6 |
| | | **TOTAL (7 tools)** | | **4,160** | | **2,857** | **496.0** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,469 | 4,469 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 3,681 | 3,681 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 510 | 10,115 | 1,175 | 8.0 |
| 2 | L1-worker | claudeopus46 | 20,643 | 977 | 21,620 | 1,146 | 6.8 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,851 | 23,494 | 14,806 | 62.0 |
| 4 | L1-worker | claudeopus46 | 2,065 | 1,148 | 3,213 | 2,006 | 15.2 |
| 5 | L1-worker | claudeopus46 | 2,065 | 922 | 2,987 | 515 | 4.9 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,949 | 24,592 | 11,249 | 61.8 |
| 7 | L1-worker | claudeopus46 | 2,065 | 1,134 | 3,199 | 1,079 | 7.7 |
| 8 | L1-worker | claudeopus46 | 20,610 | 5,764 | 26,374 | 350 | 3.3 |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,011 | 25,654 | 10,474 | 60.5 |
| 10 | L1-worker | claudeopus46 | 20,643 | 16,106 | 36,749 | 2,559 | 13.1 |
| 11 | L1-worker | claudeopus46 | 1,356 | 2,690 | 4,046 | 887 | 4.9 |
| 12 | L1-worker | claudeopus46 | 536 | 2,570 | 3,106 | 1,066 | 6.9 |
| 13 | L1-worker | claudeopus46 | 1,323 | 7,274 | 8,597 | 2,691 | 11.8 |
| 14 | L1-worker | claudeopus46 | 298 | 3,413 | 3,711 | 1,990 | 8.0 |
| 15 | L1-worker | claudeopus46 | 1,160 | 10,350 | 11,510 | 291 | 3.5 |
| 16 | L1-worker | claudeopus46 | 747 | 11,687 | 12,434 | 844 | 7.6 |
| 17 | L0-main | claudeopus46 | 9,605 | 1,941 | 11,546 | 9,664 | 46.5 |
| 18 | L1-worker | claudeopus46 | 20,643 | 1,208 | 21,851 | 587 | 4.7 |
| 19 | L1-worker | claudeopus46 | 20,643 | 2,416 | 23,059 | 13,950 | 60.0 |
| 20 | L1-worker | claudeopus46 | 2,065 | 389 | 2,454 | 508 | 4.5 |
| 21 | L1-worker | claudeopus46 | 20,643 | 2,570 | 23,213 | 7,814 | 42.4 |
| 22 | L1-worker | claudeopus46 | 2,065 | 10,592 | 12,657 | 1,475 | 13.3 |
| 23 | L1-worker | claudeopus46 | 20,610 | 4,976 | 25,586 | 462 | 4.0 |
| 24 | L1-worker | claudeopus46 | 20,643 | 4,223 | 24,866 | 3,049 | 17.7 |
| 25 | L1-worker | claudeopus46 | 1,356 | 2,646 | 4,002 | 813 | 5.0 |
| 26 | L1-worker | claudeopus46 | 536 | 2,526 | 3,062 | 900 | 5.6 |
| 27 | L1-worker | claudeopus46 | 298 | 1,195 | 1,493 | 801 | 3.4 |
| 28 | L1-worker | claudeopus46 | 298 | 1,256 | 1,554 | 887 | 3.6 |
| 29 | L1-worker | claudeopus46 | 1,323 | 6,211 | 7,534 | 2,347 | 9.6 |
| 30 | L1-worker | claudeopus46 | 298 | 3,069 | 3,367 | 1,942 | 8.4 |
| 31 | L1-worker | claudeopus46 | 747 | 36,556 | 37,303 | 949 | 8.8 |
| 32 | L0-main | claudeopus46 | 9,605 | 34,497 | 44,102 | 3,475 | 24.6 |
| 33 | L0-main | claudeopus46 | 1,356 | 2,978 | 4,334 | 942 | 5.1 |
| 34 | L0-main | claudeopus46 | 298 | 1,324 | 1,622 | 930 | 5.5 |
| 35 | L0-main | claudeopus46 | 1,323 | 6,162 | 7,485 | 2,530 | 13.6 |
| 36 | L0-main | claudeopus46 | 298 | 3,198 | 3,496 | 2,293 | 7.8 |


# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_7 | butan-1-ol | butan-1-ol |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Find molar heat capacity (Cp) data for butanol in ThermoML database → stored as L1_query_1

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "**Molar Heat Capacity (Cp) Data for Butanol (Butan-1-ol) in ThermoML**\n\n**Compound:** Butan-1-ol (GLOBcomp_7), formula C₄H₁₀O, SMILES: CCCCO, CAS 71-36-3  \n**Property:** Molar heat capacity at constant pressure (GLOBprop_9), units: J/(K·mol)\n\nThe ThermoML database contains **16 data blocks** with Cp measurements for butan-1-ol — **7 pure-component (unary)** blocks and **9 binary mixture** blocks, all in the **liquid phase**, spanning approximately **273–353 K** with Cp values ranging from ~149 to ~377 J/(K·mol) (the higher values correspond to mixture compositions).\n\n### Pure-Component (Unary) Cp Data Blocks\n\n| Literature ID | DOI | Block | Data Points | T Range (K) | Cp Range (J/K/mol) | Measurement Method |\n|---|---|---|---|---|---|---|\n| GLOBlit_2451 | 10.1016/j.jct.2004.09.007 | PROPblock_2 | 29→11 | 285.15–353.15 | 168.64–222.81 | GLOBmeas_31 |\n| GLOBlit_2822 | 10.1016/j.jct.2007.04.011 | PROPblock_1 | 13→8 | 293.15–353.15 | 173.8–222.54 | GLOBmeas_300 |\n| GLOBlit_3448 | 10.1016/j.jct.2011.08.012 | PROPblock_3 | 24→12 | 273.15–333.15 | 157.2–206.6 | GLOBmeas_12 |\n| GLOBlit_3982 | 10.1016/j.jct.2013.08.033 | PROPblock_4 | 8→8 | 283.15–318.15 | 167.32–191.93 | GLOBmeas_9 |\n| GLOBlit_5226 | 10.1016/j.jct.2018.03.031 | PROPblock_25 | 12→8 | 283.15–338.15 | 168–208.4 | GLOBmeas_31 |\n| GLOBlit_5731 | 10.1016/j.tca.2006.10.025 | PROPblock_10 | 8→8 | 288.15–323.15 | 166.2–194.7 | GLOBmeas_9 |\n\n**Additional binary mixture blocks** (9 blocks) contain Cp data for butan-1-ol in mixtures with other solvents, with Cp values extending up to ~377 J/(K·mol) depending on composition.\n\n### Representative Data Points\n\n- At **298.15 K** (near room temperature), pure liquid butan-1-ol Cp values cluster around **~170–177 J/(K·mol)** across multiple sources, showing good inter-study consistency.\n- At **353.15 K**, Cp increases to approximately **222 J/(K·mol)**, reflecting the typical increase in liquid heat capacity with temperature.\n- The GLOBlit_3448 dataset (10.1016/j.jct.2011.08.012) is notable for including **high-pressure data** (100–25,000 kPa), providing pressure-dependent Cp measurements from 273.15 to 333.15 K.\n\n### Chemistry Insight\n\nThe monotonic increase of Cp with temperature for liquid butan-1-ol is characteristic of hydrogen-bonding alcohols, where thermal disruption of the H-bond network progressively increases the configurational contribution to heat capacity. The values are consistent with butan-1-ol's molecular weight and intermolecular interactions.",
  "core_claims": [
    "The ThermoML database contains 16 data blocks (7 pure-component and 9 binary mixture) with molar heat capacity at constant pressure (Cp) measurements for liquid butan-1-ol (CAS 71-36-3), spanning approximately 273–353 K and Cp values from ~149 to ~377 J/(K·mol).",
    "At 298.15 K, pure liquid butan-1-ol Cp values cluster around ~170–177 J/(K·mol) across multiple sources, showing good inter-study consistency.",
    "Cp increases monotonically with temperature for pure liquid butan-1-ol, reaching approximately 222 J/(K·mol) at 353.15 K, consistent with the behavior of hydrogen-bonding alcohols.",
    "One dataset (DOI 10.1016/j.jct.2011.08.012) includes high-pressure Cp data (100–25,000 kPa) from 273.15 to 333.15 K, while the remaining data blocks cover conditions near ambient pressure."
  ],
  "status": "success",
  "summary": "The ThermoML database contains 16 data blocks with molar heat capacity at constant pressure (Cp) measurements for pure liquid butan-1-ol (CAS 71-36-3, C₄H₁₀O): 7 pure-component blocks and 9 binary mixture blocks, spanning approximately 273–353 K. Pure-component Cp values range from ~149 to ~223 J/(K·mol), with room-temperature (298.15 K) values clustering around 170–177 J/(K·mol) across multiple sources, showing good inter-study consistency. At 353.15 K, Cp increases to approximately 222 J/(K·mol). Six pure-component literature sources are identified by DOI, employing various measurement methods. One dataset (DOI 10.1016/j.jct.2011.08.012) includes high-pressure data (100–25,000 kPa). Binary mixture blocks extend Cp values up to ~377 J/(K·mol) depending on composition. The monotonic increase of Cp with temperature is characteristic of hydrogen-bonding alcohols.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_7",
      "registry_id": "butan-1-ol",
      "name": "butan-1-ol"
    }
  ],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_2451",
      "block_number": "PROPblock_2",
      "BLKsubsys_id": null,
      "system_type": "unary",
      "comp_num_ids": [
        "GLOBcomp_7"
      ],
      "prop_num_ids": [
        "GLOBprop_9"
      ],
      "description": "Molar heat capacity at constant pressure for pure liquid butan-1-ol, 285.15–353.15 K, Cp 168.64–222.81 J/(K·mol). DOI: 10.1016/j.jct.2004.09.007",
      "doi": "10.1016/j.jct.2004.09.007",
      "lit_id": "2005-zor-cho-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_2",
      "n_datapoints": 29,
      "n_components": 1,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.3,
          "digits": 4,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 285.15,
            "max": 353.15,
            "n_unique": 29
          },
          "range_min": 285.15,
          "range_max": 353.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_9",
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "group": "HeatCapacityAndDerivedProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_31",
          "meas_ID": "large_sample_1g_dsc",
          "method_standard": "Large sample (1 g) DSC",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "min": 168.64,
            "max": 222.81,
            "mean": 193.243448,
            "std": 17.042161,
            "n": 29
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 168.64,
          "range_max": 222.81
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "unary",
      "declared_n_components": 1,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 29,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_2822",
      "block_number": "PROPblock_1",
      "BLKsubsys_id": null,
      "system_type": "unary",
      "comp_num_ids": [
        "GLOBcomp_7"
      ],
      "prop_num_ids": [
        "GLOBprop_9"
      ],
      "description": "Molar heat capacity at constant pressure for pure liquid butan-1-ol, 293.15–353.15 K, Cp 173.8–222.54 J/(K·mol). DOI: 10.1016/j.jct.2007.04.011",
      "doi": "10.1016/j.jct.2007.04.011",
      "lit_id": "2007-zor-gor-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_2",
      "n_datapoints": 13,
      "n_components": 1,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 293.15,
            "max": 353.15,
            "n_unique": 13
          },
          "range_min": 293.15,
          "range_max": 353.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_9",
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "group": "HeatCapacityAndDerivedProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_300",
          "meas_ID": "sdsc_ufactor_0_5",
          "method_standard": null,
          "method_custom": "SDSC:UFactor:0.5",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "min": 173.8,
            "max": 222.54,
            "mean": 196.963846,
            "std": 15.971749,
            "n": 13
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 173.8,
          "range_max": 222.54
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "unary",
      "declared_n_components": 1,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_1"
        }
      ],
      "parent_n_datapoints": 13,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_3448",
      "block_number": "PROPblock_3",
      "BLKsubsys_id": null,
      "system_type": "unary",
      "comp_num_ids": [
        "GLOBcomp_7"
      ],
      "prop_num_ids": [
        "GLOBprop_9"
      ],
      "description": "Molar heat capacity at constant pressure for pure liquid butan-1-ol, 273.15–333.15 K, Cp 157.2–206.6 J/(K·mol), pressure range 100–25000 kPa. DOI: 10.1016/j.jct.2011.08.012",
      "doi": "10.1016/j.jct.2011.08.012",
      "lit_id": "2012-tor-seg-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_2",
      "n_datapoints": 24,
      "n_components": 1,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "solvents": [],
      "constraints": [],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 273.15,
            "max": 333.15,
            "n_unique": 4
          },
          "range_min": 273.15,
          "range_max": 333.15
        },
        {
          "BLKvar_id": "BLKvar_2",
          "var_num_id": "GLOBvar_3",
          "var_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_2",
            "name": "Pressure, kPa",
            "min": 100.0,
            "max": 25000.0,
            "n_unique": 6
          },
          "range_min": 100.0,
          "range_max": 25000.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_9",
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "group": "HeatCapacityAndDerivedProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_12",
          "meas_ID": "flow_calorimetry",
          "method_standard": "Flow calorimetry",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "min": 157.2,
            "max": 206.6,
            "mean": 180.8,
            "std": 17.265749,
            "n": 24
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 157.2,
          "range_max": 206.6
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "unary",
      "declared_n_components": 1,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        }
      ],
      "parent_n_datapoints": 24,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_3982",
      "block_number": "PROPblock_4",
      "BLKsubsys_id": null,
      "system_type": "unary",
      "comp_num_ids": [
        "GLOBcomp_7"
      ],
      "prop_num_ids": [
        "GLOBprop_9"
      ],
      "description": "Molar heat capacity at constant pressure for pure liquid butan-1-ol, 283.15–318.15 K, Cp 167.32–191.93 J/(K·mol). DOI: 10.1016/j.jct.2013.08.033",
      "doi": "10.1016/j.jct.2013.08.033",
      "lit_id": "2014-zor-gor-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_2",
      "n_datapoints": 8,
      "n_components": 1,
      "compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_2"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 283.15,
            "max": 318.15,
            "n_unique": 8
          },
          "range_min": 283.15,
          "range_max": 318.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_9",
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "group": "HeatCapacityAndDerivedProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_9",
          "meas_ID": "small_sample_50mg_dsc",
          "method_standard": "Small sample (50 mg) DSC",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "min": 167.32,
            "max": 191.93,
            "mean": 179.05875,
            "std": 8.621111,
            "n": 8
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 167.32,
          "range_max": 191.93
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "unary",
      "declared_n_components": 1,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_1",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_1_2"
        }
      ],
      "parent_n_datapoints": 8,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_5226",
      "block_number": "PROPblock_25",
      "BLKsubsys_id": null,
      "system_type": "unary",
      "comp_num_ids": [
        "GLOBcomp_7"
      ],
      "prop_num_ids": [
        "GLOBprop_9"
      ],
      "description": "Molar heat capacity at constant pressure for pure liquid butan-1-ol, 283.15–338.15 K, Cp 168–208.4 J/(K·mol). DOI: 10.1016/j.jct.2018.03.031",
      "doi": "10.1016/j.jct.2018.03.031",
      "lit_id": "2018-sal-tei-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_2",
      "n_datapoints": 12,
      "n_components": 1,
      "compounds": [
        {
          "org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_9_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 283.15,
            "max": 338.15,
            "n_unique": 12
          },
          "range_min": 283.15,
          "range_max": 338.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_9",
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "group": "HeatCapacityAndDerivedProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_31",
          "meas_ID": "large_sample_1g_dsc",
          "method_standard": "Large sample (1 g) DSC",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "min": 168.0,
            "max": 208.4,
            "mean": 187.033333,
            "std": 13.246772,
            "n": 12
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 168.0,
          "range_max": 208.4
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "unary",
      "declared_n_components": 1,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_9",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_9_1"
        }
      ],
      "parent_n_datapoints": 12,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    },
    {
      "lit_num_id": "GLOBlit_5731",
      "block_number": "PROPblock_10",
      "BLKsubsys_id": null,
      "system_type": "unary",
      "comp_num_ids": [
        "GLOBcomp_7"
      ],
      "prop_num_ids": [
        "GLOBprop_9"
      ],
      "description": "Molar heat capacity at constant pressure for pure liquid butan-1-ol, 288.15–323.15 K, Cp 166.2–194.7 J/(K·mol). DOI: 10.1016/j.tca.2006.10.025",
      "doi": "10.1016/j.tca.2006.10.025",
      "lit_id": "2007-rub-fra-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_2",
      "n_datapoints": 8,
      "n_components": 1,
      "compounds": [
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.325,
          "digits": 6,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_1",
          "var_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Temperature, K",
            "min": 288.15,
            "max": 323.15,
            "n_unique": 8
          },
          "range_min": 288.15,
          "range_max": 323.15
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_9",
          "prop_ID": "molar_heat_capacity_at_constant_pressure_j_k_mol",
          "name": "Molar heat capacity at constant pressure, J/K/mol",
          "group": "HeatCapacityAndDerivedProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_9",
          "meas_ID": "small_sample_50mg_dsc",
          "method_standard": "Small sample (50 mg) DSC",
          "method_custom": null,
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Molar heat capacity at constant pressure, J/K/mol",
            "min": 166.2,
            "max": 194.7,
            "mean": 180.8875,
            "std": 9.701316,
            "n": 8
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 166.2,
          "range_max": 194.7
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "unary",
      "declared_n_components": 1,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_5",
          "comp_num_id": "GLOBcomp_7",
          "name": "butan-1-ol",
          "formula": "C4H10O",
          "inchi_key": "LRHPLDYGYMQRHN-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_5_1"
        }
      ],
      "parent_n_datapoints": 8,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


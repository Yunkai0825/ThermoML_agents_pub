# Q4.5 — Result

**Prompt:** How strongly does water + ethylene glycol deviate from ideal mixing in its transport properties, and what's the chemical reason behind?

**Tool calls:** 2  |  **Time:** 408.3s  |  **Iterations:** 3  |  **Timed out:** False

---

## Answer

## Deviation of Water + Ethylene Glycol from Ideal Mixing in Transport Properties

The water (H₂O) + ethylene glycol (1,2-ethanediol, C₂H₆O₂) binary system shows a **remarkably strong positive deviation** from ideal mixing in its dynamic viscosity — the key liquid-phase transport property available in the ThermoML database.

### Quantitative Evidence

Seven independent data blocks in ThermoML report dynamic viscosity for this binary system, spanning temperatures from ~293 K to ~450 K and covering the full composition range. The most comprehensive dataset comes from DOI 10.1021/je020140j (GLOBlit_8038, PROPblock_5; 77 data points, 293–353 K).

At **293.15 K** and ~101 kPa, comparing measured viscosity against the Arrhenius (logarithmic) ideal mixing rule (ln η_mix = x₁ ln η₁ + x₂ ln η₂):

| x(ethylene glycol) | η measured (Pa·s) | η ideal (Pa·s) | η_meas / η_ideal |
|---|---|---|---|
| 0.0000 (pure water) | 0.001002 | 0.001002 | 1.00 |
| 0.0501 | 0.001310 | 0.001148 | 1.14 |
| 0.1002 | 0.001790 | 0.001316 | 1.36 |
| 0.1998 | 0.003180 | 0.001728 | 1.84 |
| 0.2999 | 0.005140 | 0.002269 | 2.27 |
| 0.3999 | 0.007590 | 0.002980 | **2.55** |
| 0.5000 | 0.009930 | 0.003912 | **2.54** |
| 0.5999 | 0.012100 | 0.005135 | 2.36 |
| 0.6999 | 0.014100 | 0.006741 | 2.09 |
| 0.8001 | 0.016200 | 0.008849 | 1.83 |
| 1.0000 (pure EG) | 0.020100 | 0.020100 | 1.00 |

The **maximum deviation occurs near x(EG) ≈ 0.4–0.5**, where the measured viscosity is roughly **2.5 times** the value predicted by ideal logarithmic mixing. This is an exceptionally large excess viscosity effect for a binary liquid mixture.

### Temperature Dependence of the Deviation

Data extending to ~450 K (DOI 10.1021/je025610o, GLOBlit_8106, PROPblock_5; 30 points at x(EG) = 0.25–0.75) show that the excess viscosity progressively diminishes with increasing temperature. At the highest temperatures, viscosities of both pure components and mixtures converge toward much lower values (η drops from ~0.012 Pa·s near 296 K to ~0.0004 Pa·s near 450 K), and the relative deviation from ideality shrinks as thermal energy disrupts the molecular interactions responsible for the anomaly.

### Chemical Explanation

The pronounced positive viscosity deviation arises from **extensive cross-hydrogen bonding between unlike molecules**:

1. **Bifunctional hydrogen bonding:** Ethylene glycol possesses **two hydroxyl groups (–OH)** on adjacent carbon atoms. Each –OH can simultaneously act as both a hydrogen-bond donor and acceptor. This bifunctionality allows a single EG molecule to bridge between multiple water molecules, creating larger, more interconnected hydrogen-bonded clusters than exist in either pure liquid.

2. **Enhanced network formation:** In pure water, the tetrahedral hydrogen-bond network is already extensive but relatively dynamic. When EG is added, its two –OH groups insert into the water network and cross-link it, effectively increasing the average cluster size and the cooperativity of hydrogen bonding. This produces supramolecular aggregates with larger effective hydrodynamic radii.

3. **Increased intermolecular friction:** These extended, cross-associated networks resist shear flow more strongly than the networks in either pure component, manifesting as viscosities far above what composition-weighted mixing would predict.

4. **Composition of maximum deviation:** The peak near equimolar composition (x ≈ 0.4–0.5) reflects the stoichiometry that maximizes the number of water–EG cross-hydrogen bonds. At this composition, nearly every molecule has an unlike neighbor available for cross-association.

5. **Temperature reduction of excess:** At elevated temperatures, thermal energy increasingly disrupts these hydrogen-bond networks, reducing the lifetime and extent of cross-associated clusters, which progressively diminishes the excess viscosity.

### Data Sources

| DOI | Literature ID | Block | Points | T Range (K) | Composition Basis |
|-----|--------------|-------|--------|-------------|-------------------|
| 10.1021/je020140j | GLOBlit_8038 | PROPblock_5 | 77 | 293–353 | x(EG) |
| 10.1016/j.jct.2018.02.022 | GLOBlit_5201 | PROPblock_24 | 84 | 293–308 | x(EG) |
| 10.1021/je800271e | GLOBlit_11186 | PROPblock_4 | 52 | 308–323 | x(EG) |
| 10.1021/acs.jced.6b00526 | GLOBlit_6951 | PROPblock_18 | 33 | 293–303 | x(water) |
| 10.1021/je025610o | GLOBlit_8106 | PROPblock_5 | 30 | 296–450 | x(EG) |
| 10.1016/j.jct.2006.01.011 | GLOBlit_2656 | PROPblock_13 | 10 | 293 (fixed) | w(EG) |
| 10.1021/je9000697 | GLOBlit_11506 | PROPblock_1 | 16 | 298–318 | w(EG) |

In summary, the water + ethylene glycol system is a textbook example of strong positive viscosity deviation driven by cross-hydrogen bonding, with measured viscosities reaching ~2.5× the ideal prediction at intermediate compositions near room temperature.

### Core claims

- The water + ethylene glycol binary system exhibits a strong positive deviation from ideal (Arrhenius logarithmic) mixing in dynamic viscosity, with measured viscosities reaching approximately 2.5 times the ideal prediction at intermediate compositions (x(EG) ≈ 0.4–0.5) near 293 K.
- The maximum excess viscosity occurs near equimolar composition, reflecting the stoichiometry that maximizes cross-hydrogen bonding between water and ethylene glycol's two hydroxyl groups.
- The positive viscosity deviation diminishes progressively with increasing temperature (up to ~450 K), as thermal energy disrupts the cross-associated hydrogen-bond networks responsible for the anomaly.
- The pronounced excess viscosity is attributed to extensive cross-hydrogen bonding: ethylene glycol's bifunctional –OH groups bridge and cross-link the water hydrogen-bond network, forming larger supramolecular aggregates with increased resistance to shear flow.

**Confidence:** low

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_8038 | 10.1021/je020140j | PROPblock_5 |  | Dynamic viscosity of water + ethylene glycol binary mixture, 77 data points, 293–353 K, mole fraction basis |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 | PROPblock_24 |  | Dynamic viscosity of water + ethylene glycol binary mixture, 84 data points, 293–308 K, mole fraction basis |
| GLOBlit_11186 | 10.1021/je800271e | PROPblock_4 |  | Dynamic viscosity of water + ethylene glycol binary mixture, 52 data points, 308–323 K, mole fraction basis |
| GLOBlit_6951 | 10.1021/acs.jced.6b00526 | PROPblock_18 |  | Dynamic viscosity of water + ethylene glycol binary mixture, 33 data points, 293–303 K, mole fraction of water basis |
| GLOBlit_8106 | 10.1021/je025610o | PROPblock_5 |  | Dynamic viscosity of water + ethylene glycol binary mixture, 30 data points, 296–450 K, mole fraction basis |
| GLOBlit_2656 | 10.1016/j.jct.2006.01.011 | PROPblock_13 |  | Dynamic viscosity of water + ethylene glycol binary mixture, 10 data points, 293 K fixed, mass fraction basis |
| GLOBlit_11506 | 10.1021/je9000697 | PROPblock_1 |  | Dynamic viscosity of water + ethylene glycol binary mixture, 16 data points, 298–318 K, mass fraction basis |

### Suggested follow-ups

- Retrieve the resolved GLOBcomp IDs for water and ethylene glycol to confirm compound identity mapping in ThermoML.
- Query for excess molar volume or excess enthalpy data for water + ethylene glycol to complement the transport-property deviation analysis.
- Compare viscosity deviations of water + ethylene glycol with water + propylene glycol or water + glycerol to assess the role of hydroxyl group count and spacing.

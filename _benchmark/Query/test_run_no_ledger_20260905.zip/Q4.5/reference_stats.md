# Reference Stats — query-agent

**Run started:** 2026-08-02 19:27:09
**Wall time (at last flush):** 408.2 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 32,090 | 67,024 | 14,324 | 99,114 | 14,159 | 78.2 | claudeopus46 |
| L1-worker | 27 | 226,251 | 155,141 | 65,347 | 381,392 | 14,125 | 366.2 | claudeopus46 |
| **TOTAL** | **34** | **258,341** | **222,165** | **79,671** | **480,506** | **14,132** | **444.4** | |

**Estimated tokens:** ~120,126 input + ~19,917 output = ~140,043 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 2 | 7 | 7 | 302 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **6** | **3** | **3** | **2** | **7** | **7** | **302** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks |
| GLOBcomp_24 |  | resolve_compound_ids, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 |  | resolve_property_ids, search_blocks |

#### References (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2656 |  | search_blocks |
| GLOBlit_5201 |  | search_blocks |
| GLOBlit_6951 |  | search_blocks |
| GLOBlit_8038 |  | search_blocks |
| GLOBlit_8106 |  | search_blocks |
| GLOBlit_11186 |  | search_blocks |
| GLOBlit_11506 |  | search_blocks |

#### Measurements (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_227 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_142 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_165 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_5 | Mass fraction | search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_2 | Mole fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Properties | 1 |
| Unique References | 7 |
| Unique Measurements | 6 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Total DOIs | 7 |
| Unique parent blocks | 7 |
| Explicit block/subsystem targets | 7 |
| Subsystem targets | 0 |
| Target-matched data points | 302 |

---

## 3. DOI & Block References

**Unique DOIs:** 7  |  **Parent blocks:** 7  |  **Explicit targets:** 7  |  **Subsystems:** 0  |  **Target-matched datapoints:** 302

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2006.01.011 | 1 | 10 | binary | search_blocks |
| 10.1016/j.jct.2018.02.022 | 1 | 84 | binary | search_blocks |
| 10.1021/acs.jced.6b00526 | 1 | 33 | binary | search_blocks |
| 10.1021/je020140j | 1 | 77 | binary | search_blocks |
| 10.1021/je025610o | 1 | 30 | binary | search_blocks |
| 10.1021/je800271e | 1 | 52 | binary | search_blocks |
| 10.1021/je9000697 | 1 | 16 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2006.01.011 | PROPblock_13 | declared | 10 | binary | — | search_blocks |
| 10.1016/j.jct.2018.02.022 | PROPblock_24 | declared | 84 | binary | — | search_blocks |
| 10.1021/acs.jced.6b00526 | PROPblock_18 | declared | 33 | binary | — | search_blocks |
| 10.1021/je020140j | PROPblock_5 | declared | 77 | binary | — | search_blocks |
| 10.1021/je025610o | PROPblock_5 | declared | 30 | binary | — | search_blocks |
| 10.1021/je800271e | PROPblock_4 | declared | 52 | binary | — | search_blocks |
| 10.1021/je9000697 | PROPblock_1 | declared | 16 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve compound ID… | 243 | KEEP | 243 | 5.0 |
| 2 | 2 | `resolve_property_ids` | limit=5, min_score=50, purpose=Confirm the propert… | 251 | KEEP | 251 | 3.8 |
| 3 | 1 | `L1_query` | context=User wants to understand how …, id_catalog… | 354 | — | — | 97.5 |
| 4 | 2 | `resolve_compound_ids` | limit=10, min_score=50, purpose=Resolve compound I… | 230 | KEEP | 230 | 4.4 |
| 5 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Confirm property I… | 251 | KEEP | 251 | 3.8 |
| 6 | 3 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_24'], limit=50, … | 1,443 | KEEP | 1306 | 13.6 |
| 7 | 2 | `L1_query` | context=User asks how strongly water …, id_catalog… | 270 | — | — | 240.9 |
| | | **TOTAL (7 tools)** | | **3,042** | | **2,281** | **369.0** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 4,722 | 4,722 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 598 | 10,203 | 1,500 | 8.8 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,055 | 21,698 | 1,062 | 6.7 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,845 | 23,488 | 1,723 | 8.1 |
| 4 | L1-worker | claudeopus46 | 2,065 | 480 | 2,545 | 457 | 4.7 |
| 5 | L1-worker | claudeopus46 | 2,065 | 368 | 2,433 | 454 | 3.6 |
| 6 | L1-worker | claudeopus46 | 20,643 | 3,367 | 24,010 | 6,717 | 40.7 |
| 7 | L1-worker | claudeopus46 | 20,643 | 10,659 | 31,302 | 2,817 | 10.9 |
| 8 | L1-worker | claudeopus46 | 536 | 2,407 | 2,943 | 666 | 4.8 |
| 9 | L1-worker | claudeopus46 | 1,356 | 2,527 | 3,883 | 1,046 | 5.3 |
| 10 | L1-worker | claudeopus46 | 298 | 1,022 | 1,320 | 653 | 3.1 |
| 11 | L1-worker | claudeopus46 | 1,323 | 5,429 | 6,752 | 1,553 | 8.2 |
| 12 | L1-worker | claudeopus46 | 298 | 2,275 | 2,573 | 1,147 | 8.3 |
| 13 | L1-worker | claudeopus46 | 1,160 | 7,464 | 8,624 | 1,134 | 5.2 |
| 14 | L0-main | claudeopus46 | 9,605 | 1,460 | 11,065 | 1,124 | 6.8 |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,038 | 21,681 | 1,046 | 6.8 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,812 | 23,455 | 13,751 | 68.8 |
| 17 | L1-worker | claudeopus46 | 2,065 | 472 | 2,537 | 438 | 4.3 |
| 18 | L1-worker | claudeopus46 | 2,065 | 364 | 2,429 | 447 | 3.7 |
| 19 | L1-worker | claudeopus46 | 20,643 | 3,281 | 23,924 | 8,142 | 45.7 |
| 20 | L1-worker | claudeopus46 | 2,065 | 10,352 | 12,417 | 1,665 | 13.0 |
| 21 | L1-worker | claudeopus46 | 20,610 | 6,017 | 26,627 | 600 | 7.0 |
| 22 | L1-worker | claudeopus46 | 20,643 | 5,264 | 25,907 | 7,214 | 46.4 |
| 23 | L1-worker | claudeopus46 | 20,643 | 13,099 | 33,742 | 3,137 | 14.2 |
| 24 | L1-worker | claudeopus46 | 1,356 | 3,268 | 4,624 | 935 | 5.4 |
| 25 | L1-worker | claudeopus46 | 536 | 3,148 | 3,684 | 905 | 6.3 |
| 26 | L1-worker | claudeopus46 | 1,323 | 8,107 | 9,430 | 3,495 | 12.5 |
| 27 | L1-worker | claudeopus46 | 298 | 1,261 | 1,559 | 892 | 6.5 |
| 28 | L1-worker | claudeopus46 | 298 | 4,217 | 4,515 | 2,693 | 9.7 |
| 29 | L1-worker | claudeopus46 | 747 | 52,543 | 53,290 | 558 | 6.3 |
| 30 | L0-main | claudeopus46 | 9,605 | 48,064 | 57,669 | 5,370 | 35.7 |
| 31 | L0-main | claudeopus46 | 1,356 | 4,985 | 6,341 | 971 | 5.6 |
| 32 | L0-main | claudeopus46 | 298 | 1,353 | 1,651 | 959 | 3.2 |
| 33 | L0-main | claudeopus46 | 1,323 | 7,594 | 8,917 | 2,302 | 11.4 |
| 34 | L0-main | claudeopus46 | 298 | 2,970 | 3,268 | 2,098 | 6.7 |


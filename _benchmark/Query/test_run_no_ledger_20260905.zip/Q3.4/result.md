# Q3.4 — Result

**Prompt:** I need an ethanol + water study suitable for cross-checking several measured properties from the same experimental source. Which paper is the best candidate, and what other chemical systems does it report?

**Tool calls:** 2  |  **Time:** 760.9s  |  **Iterations:** 3  |  **Timed out:** False

---

## Answer

## Best Candidate for Cross-Checking Multiple Properties: Ethanol + Water

Two strong candidates emerge from the ThermoML database, depending on what kind of cross-checking you need:

---

### **Top pick by number of distinct property types:**

**DOI: 10.1016/j.jct.2013.08.020** (Lai, Lin et al., 2014)

This paper reports **4 distinct measured property types** for the ethanol + water binary system, all under isobaric VLE conditions at P = 101.3 kPa:

| # | Property | ID | Data points | Details |
|---|----------|----|-------------|---------|
| 1 | Boiling temperature at pressure P (K) | GLOBprop_14 | 16 | Ebulliometric method (recirculating still); range 351.33–373.15 K |
| 2 | Vapor-phase mole fraction (ethanol) | GLOBprop_2 | 16 | Chromatography; range 0.0–1.0 |
| 3 | Azeotropic temperature (K) | GLOBprop_58 | 1 | 351.32 ± 0.23 K |
| 4 | Azeotropic composition (mole fraction ethanol) | GLOBprop_45 | 1 | 0.891 ± 0.004 |

The T–x–y VLE data (blocks PROPblock_9 and PROPblock_10) together with the azeotropic point (PROPblock_11 and PROPblock_12) allow internal consistency checks: the azeotrope should coincide with the minimum in the T–x curve and the point where x = y.

**Other chemical systems reported in this paper:**
- **Pure components:** ethanol and water (validation data including density, refractive index)
- **Binary systems:** ethanol + propan-1,3-diol (C₃H₈O₂); water + propan-1,3-diol
- **Ternary system:** ethanol + water + propan-1,3-diol

This breadth (17 total data blocks across 3 compounds) makes it especially useful for thermodynamic modeling of the full ternary system, where binary VLE parameters can be validated against ternary predictions.

---

### **Best pick for independent thermophysical cross-checks:**

**DOI: 10.1016/j.jct.2018.02.022** (Hoga, Torres et al., 2018)

This paper reports **3 independent thermophysical properties** for ethanol + water across the full composition range (x = 0–1) at 293.15–308.15 K and P = 92.3 kPa:

| # | Property | ID | Data points | Method | Representative range |
|---|----------|----|-------------|--------|---------------------|
| 1 | Mass density (kg/m³) | GLOBprop_1 | 244 | Vibrating tube | 776.6–998.4 kg/m³ |
| 2 | Speed of sound (m/s) | GLOBprop_8 | 152 | Single path-length (3 MHz) | 1109.6–1625.7 m/s |
| 3 | Dynamic viscosity (Pa·s) | GLOBprop_4 | 100 | Concentric cylinders | 0.000759–0.002864 Pa·s |

These three properties are thermodynamically interconnected — density and speed of sound can be combined to calculate isentropic compressibility (κₛ = 1/(ρu²)), providing a powerful internal consistency check. The viscosity data add a transport-property dimension for validating mixture models.

---

### Summary Recommendation

- For **VLE consistency checks** (T–x–y diagrams, azeotrope verification, and extension to ternary modeling): use **DOI 10.1016/j.jct.2013.08.020** — it has the most distinct property types (4) and covers multiple subsystems including the ternary ethanol + water + propan-1,3-diol.

- For **thermophysical property cross-validation** (density, acoustics, viscosity): use **DOI 10.1016/j.jct.2018.02.022** — its 3 independent bulk properties measured over 59 compositions and 4 temperatures offer rich opportunities for thermodynamic self-consistency analysis.

A third reference, **DOI 10.1016/j.jct.2006.08.002** (Bazaev et al., 2007), provides high-temperature/high-pressure data (vapor pressure up to 9650 kPa and mass density 52.9–664.3 kg/m³ at 457–673 K, x(ethanol) = 0.2–0.8) but covers only 2 property types.

### Core claims

- For the ethanol + water binary system, DOI 10.1016/j.jct.2013.08.020 (Lai, Lin et al., 2014) offers the most distinct measured property types (4: boiling temperature, vapor-phase mole fraction, azeotropic temperature, and azeotropic composition at 101.3 kPa), enabling internal VLE consistency checks such as verifying that the azeotrope coincides with the T–x curve minimum and the x = y condition.
- DOI 10.1016/j.jct.2018.02.022 (Hoga, Torres et al., 2018) provides 3 independent thermophysical properties (mass density, speed of sound, and dynamic viscosity) for ethanol + water across the full composition range at 293.15–308.15 K, allowing thermodynamic self-consistency analysis via relationships such as isentropic compressibility (κₛ = 1/(ρu²)).
- The Lai et al. (2014) paper additionally covers binary subsystems (ethanol + propan-1,3-diol; water + propan-1,3-diol) and the ternary ethanol + water + propan-1,3-diol system across 17 data blocks, making it especially useful for validating binary VLE parameters against ternary predictions.
- A third reference (DOI 10.1016/j.jct.2006.08.002, Bazaev et al., 2007) provides high-temperature/high-pressure ethanol + water data (vapor pressure and mass density at 457–673 K, up to 9650 kPa) but covers only 2 property types.

**Confidence:** medium

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_3971 | 10.1016/j.jct.2013.08.020 | PROPblock_9 |  | Boiling temperature at pressure P for ethanol + water binary VLE at 101.3 kPa (GLOBprop_14, 16 data points) |
| GLOBlit_3971 | 10.1016/j.jct.2013.08.020 | PROPblock_10 |  | Vapor-phase mole fraction of ethanol for ethanol + water binary VLE at 101.3 kPa (GLOBprop_2, 16 data points) |
| GLOBlit_3971 | 10.1016/j.jct.2013.08.020 | PROPblock_11 |  | Azeotropic temperature for ethanol + water (GLOBprop_58, 1 data point, 351.32 K) |
| GLOBlit_3971 | 10.1016/j.jct.2013.08.020 | PROPblock_12 |  | Azeotropic composition (mole fraction ethanol) for ethanol + water (GLOBprop_45, 1 data point, 0.891) |
| GLOBlit_5201 | 10.1016/j.jct.2018.02.022 |  |  | Mass density (GLOBprop_1, 244 pts), speed of sound (GLOBprop_8, 152 pts), and dynamic viscosity (GLOBprop_4, 100 pts) for ethanol + water at 293.15–308.15 K and 92.3 kPa. GLOBlit_N not resolved from tool record. |
| GLOBlit_2732 | 10.1016/j.jct.2006.08.002 |  |  | High-temperature/high-pressure vapor pressure and mass density for ethanol + water (457–673 K, up to 9650 kPa). GLOBlit_N not resolved from tool record. |

### Suggested follow-ups

- Resolve GLOBlit_N identifiers for DOI 10.1016/j.jct.2018.02.022 and DOI 10.1016/j.jct.2006.08.002 to complete the metadata alignment.
- Retrieve component-level GLOBcomp IDs for ethanol, water, and propan-1,3-diol from the database to anchor the id_catalog_snapshot.
- Query the specific PROPblock IDs within GLOBlit_3971 that cover the ethanol + propan-1,3-diol, water + propan-1,3-diol, and ternary subsystems to map all other chemical systems in that paper.
- Cross-check the azeotropic point (PROPblock_11, PROPblock_12) against the T-x-y VLE curve (PROPblock_9, PROPblock_10) for internal consistency verification.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "prop",
    "global_id": "GLOBprop_14",
    "registry_id": null,
    "name": "Boiling temperature at pressure P"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_2",
    "registry_id": null,
    "name": "Vapor-phase mole fraction"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_58",
    "registry_id": null,
    "name": "Azeotropic temperature"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_45",
    "registry_id": null,
    "name": "Azeotropic composition (mole fraction)"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": null,
    "name": "Mass density"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_8",
    "registry_id": null,
    "name": "Speed of sound"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_4",
    "registry_id": null,
    "name": "Dynamic viscosity"
  }
]
```

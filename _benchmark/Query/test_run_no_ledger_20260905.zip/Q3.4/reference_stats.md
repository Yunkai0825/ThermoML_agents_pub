# Reference Stats — query-agent

**Run started:** 2026-08-02 19:05:17
**Wall time (at last flush):** 760.8 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 7 | 32,090 | 88,374 | 33,395 | 120,464 | 17,209 | 180.6 | claudeopus46 |
| L1-worker | 47 | 432,084 | 733,197 | 110,011 | 1,165,281 | 24,793 | 622.8 | claudeopus46 |
| **TOTAL** | **54** | **464,174** | **821,571** | **143,406** | **1,285,745** | **23,810** | **803.4** | |

**Estimated tokens:** ~321,436 input + ~35,851 output = ~357,287 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 2 | 18 | 7 | 6 | 58 | 100 | 4,354 |
| `search_blocks` | 2 | 18 | 7 | 6 | 58 | 100 | 4,354 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 2 | 3 | 1 | 1 | 4 | 326 |
| `search_blocks` | 2 | 4 | 2 | 1 | 1 | 4 | 34 |
| `search_blocks` | 2 | 3 | 2 | 2 | 1 | 3 | 496 |
| `search_blocks` | 2 | 1 | 1 | 1 | 1 | 3 | 13 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_system_registry` | 2 | 18 | 7 | 6 | 58 | 100 | 4,354 |
| `search_blocks` | 2 | 2 | 3 | 1 | 1 | 4 | 326 |
| `search_blocks` | 2 | 4 | 2 | 1 | 1 | 4 | 34 |
| `search_blocks` | 2 | 3 | 2 | 2 | 1 | 3 | 496 |
| `search_blocks` | 3 | 7 | 3 | 1 | 1 | 17 | 151 |
| `search_id_alignment` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **28** | **80** | **39** | **28** | **182** | **342** | **14,938** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_2 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_1 |  | resolve_compound_ids, search_blocks, search_system_registry |
| GLOBcomp_154 | propan-1,3-diol | search_blocks, search_id_alignment |

#### References (58 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_220 |  | search_blocks, search_system_registry |
| GLOBlit_299 |  | search_blocks, search_system_registry |
| GLOBlit_384 |  | search_blocks, search_system_registry |
| GLOBlit_528 |  | search_blocks, search_system_registry |
| GLOBlit_742 |  | search_blocks, search_system_registry |
| GLOBlit_757 |  | search_blocks, search_system_registry |
| GLOBlit_977 |  | search_blocks, search_system_registry |
| GLOBlit_1184 |  | search_blocks, search_system_registry |
| GLOBlit_1197 |  | search_blocks, search_system_registry |
| GLOBlit_1289 |  | search_blocks, search_system_registry |
| GLOBlit_1482 |  | search_blocks, search_system_registry |
| GLOBlit_1483 |  | search_blocks, search_system_registry |
| GLOBlit_1518 |  | search_blocks, search_system_registry |
| GLOBlit_1742 |  | search_blocks, search_system_registry |
| GLOBlit_1971 |  | search_blocks, search_system_registry |
| GLOBlit_2035 |  | search_blocks, search_system_registry |
| GLOBlit_2092 |  | search_blocks, search_system_registry |
| GLOBlit_2220 |  | search_blocks, search_system_registry |
| GLOBlit_2300 |  | search_blocks, search_system_registry |
| GLOBlit_2432 |  | search_blocks, search_system_registry |
| GLOBlit_2574 |  | search_blocks, search_system_registry |
| GLOBlit_2732 |  | search_blocks, search_system_registry |
| GLOBlit_2825 |  | search_blocks, search_system_registry |
| GLOBlit_3475 |  | search_blocks, search_system_registry |
| GLOBlit_3697 |  | search_blocks, search_system_registry |
| GLOBlit_3971 |  | search_blocks, search_system_registry |
| GLOBlit_4181 |  | search_blocks, search_system_registry |
| GLOBlit_4415 |  | search_blocks, search_system_registry |
| GLOBlit_5073 |  | search_blocks, search_system_registry |
| GLOBlit_5201 |  | search_blocks, search_system_registry |
| GLOBlit_5473 |  | search_blocks, search_system_registry |
| GLOBlit_6377 |  | search_blocks, search_system_registry |
| GLOBlit_6628 |  | search_blocks, search_system_registry |
| GLOBlit_6866 |  | search_blocks, search_system_registry |
| GLOBlit_6996 |  | search_blocks, search_system_registry |
| GLOBlit_7085 |  | search_blocks, search_system_registry |
| GLOBlit_7178 |  | search_blocks, search_system_registry |
| GLOBlit_7337 |  | search_blocks, search_system_registry |
| GLOBlit_7425 |  | search_blocks, search_system_registry |
| GLOBlit_7448 |  | search_blocks, search_system_registry |
| GLOBlit_7483 |  | search_blocks, search_system_registry |
| GLOBlit_7629 |  | search_blocks, search_system_registry |
| GLOBlit_7676 |  | search_blocks, search_system_registry |
| GLOBlit_7748 |  | search_blocks, search_system_registry |
| GLOBlit_7794 |  | search_blocks, search_system_registry |
| GLOBlit_8050 |  | search_blocks, search_system_registry |
| GLOBlit_8151 |  | search_blocks, search_system_registry |
| GLOBlit_8381 |  | search_blocks, search_system_registry |
| GLOBlit_8445 |  | search_blocks, search_system_registry |
| GLOBlit_8511 |  | search_blocks, search_system_registry |
| GLOBlit_8830 |  | search_blocks, search_system_registry |
| GLOBlit_8888 |  | search_blocks, search_system_registry |
| GLOBlit_8949 |  | search_blocks, search_system_registry |
| GLOBlit_9006 |  | search_blocks, search_system_registry |
| GLOBlit_9599 |  | search_blocks, search_system_registry |
| GLOBlit_9630 |  | search_blocks, search_system_registry |
| GLOBlit_9693 |  | search_blocks, search_system_registry |
| GLOBlit_9930 |  | search_blocks, search_system_registry |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | search_system_registry |

#### Variables (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks, search_system_registry |
| GLOBvar_3 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBvar_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBvar_4 | Molality, mol/kg | search_blocks, search_system_registry |
| GLOBvar_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBvar_15 | Mass ratio of solute to solvent | search_blocks, search_system_registry |
| GLOBvar_18 | Volume fraction | search_blocks, search_system_registry |

#### Phases (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks, search_system_registry |
| GLOBphase_3 |  | search_blocks, search_system_registry |
| GLOBphase_10 |  | search_blocks, search_system_registry |

#### Properties (18 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBprop_3 | Activity coefficient | search_blocks, search_system_registry |
| GLOBprop_5 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBprop_17 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBprop_14 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBprop_2 | Mole fraction | search_blocks, search_system_registry |
| GLOBprop_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBprop_44 | Relative permittivity at zero frequency | search_blocks, search_system_registry |
| GLOBprop_58 | Azeotropic temperature, K | search_blocks, search_system_registry |
| GLOBprop_45 | Azeotropic composition: mole fraction | search_blocks, search_system_registry |
| GLOBprop_8 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBprop_13 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBprop_62 | Azeotropic pressure, kPa | search_blocks, search_system_registry |
| GLOBprop_7 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBprop_18 | Electrical conductivity, S/m | search_blocks, search_system_registry |
| GLOBprop_34 | Thermal conductivity, W/m/K | search_blocks, search_system_registry |
| GLOBprop_27 | Henry's Law constant (mole fraction scale), kPa | search_blocks, search_system_registry |
| GLOBprop_29 | Binary diffusion coefficient, m2/s | search_blocks, search_system_registry |

#### Measurements (45 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_543 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_1045 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_1042 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_133 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_13 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_5 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_1362 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_2137 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_131 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_1 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_10 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_664 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_12 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_66 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_1153 | Activity coefficient | search_blocks, search_system_registry |
| GLOBmeas_1355 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |
| GLOBmeas_169 | Excess molar enthalpy (molar enthalpy of mixing), kJ/mol | search_blocks, search_system_registry |
| GLOBmeas_161 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_1497 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_53 | Relative permittivity at zero frequency | search_blocks, search_system_registry |
| GLOBmeas_39 | Azeotropic temperature, K | search_blocks, search_system_registry |
| GLOBmeas_7 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_24 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_18 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_11 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_36 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_3 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_19 | Surface tension liquid-gas, N/m | search_blocks, search_system_registry |
| GLOBmeas_14 | Electrical conductivity, S/m | search_blocks, search_system_registry |
| GLOBmeas_193 | Thermal conductivity, W/m/K | search_blocks, search_system_registry |
| GLOBmeas_163 | Refractive index (Na D-line) | search_blocks, search_system_registry |
| GLOBmeas_236 | Mass density, kg/m3 | search_blocks, search_system_registry |
| GLOBmeas_145 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_38 | Binary diffusion coefficient, m2/s | search_blocks, search_system_registry |
| GLOBmeas_276 | Vapor or sublimation pressure, kPa | search_blocks, search_system_registry |
| GLOBmeas_150 | Mole fraction | search_blocks, search_system_registry |
| GLOBmeas_15 | Speed of sound, m/s | search_blocks, search_system_registry |
| GLOBmeas_205 | Viscosity, Pa*s | search_blocks, search_system_registry |
| GLOBmeas_155 | Boiling temperature at pressure P, K | search_blocks, search_system_registry |

#### Constraints (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_3 | Mole fraction | search_blocks, search_system_registry |
| GLOBconstr_2 | Temperature, K | search_blocks, search_system_registry |
| GLOBconstr_1 | Pressure, kPa | search_blocks, search_system_registry |
| GLOBconstr_4 | Frequency, MHz | search_blocks, search_system_registry |
| GLOBconstr_5 | Mass fraction | search_blocks, search_system_registry |
| GLOBconstr_8 | Molality, mol/kg | search_blocks, search_system_registry |

#### Solvents (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBsolvent_1 |  | search_blocks, search_system_registry |
| GLOBsolvent_2 |  | search_blocks, search_system_registry |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 3 |
| Unique References | 58 |
| Unique Block_Types | 1 |
| Unique Variables | 7 |
| Unique Phases | 3 |
| Unique Properties | 18 |
| Unique Measurements | 45 |
| Unique Constraints | 6 |
| Unique Solvents | 2 |
| Total DOIs | 58 |
| Unique parent blocks | 113 |
| Explicit block/subsystem targets | 113 |
| Subsystem targets | 0 |
| Target-matched data points | 14,938 |

---

## 3. DOI & Block References

**Unique DOIs:** 58  |  **Parent blocks:** 113  |  **Explicit targets:** 113  |  **Subsystems:** 0  |  **Target-matched datapoints:** 4,471

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.fluid.2004.11.019 | 1 | 810 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | 3 | 13 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2006.04.017 | 1 | 28 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2007.06.007 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.10.002 | 2 | 10 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.11.014 | 2 | 36 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2011.06.009 | 2 | 90 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.11.026 | 2 | 48 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.12.014 | 2 | 152 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.07.001 | 1 | 42 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.031 | 1 | 56 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.032 | 1 | 140 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.07.022 | 2 | 14 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.07.012 | 2 | 168 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.08.030 | 1 | 4 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.03.010 | 2 | 34 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.005 | 2 | 144 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2018.07.014 | 1 | 17 | binary | search_blocks, search_system_registry |
| 10.1016/j.fluid.2019.03.019 | 2 | 32 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2004.07.019 | 1 | 565 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2005.06.018 | 1 | 27 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | 4 | 326 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | 2 | 74 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2011.10.009 | 1 | 70 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.08.009 | 1 | 14 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | 17 | 151 | binary, ternary, unary | search_blocks, search_system_registry |
| 10.1016/j.jct.2014.05.020 | 1 | 30 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2015.06.024 | 2 | 80 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.07.021 | 2 | 48 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | 3 | 496 | binary | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.02.027 | 1 | 9 | binary | search_blocks, search_system_registry |
| 10.1016/j.tca.2017.05.023 | 1 | 1 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00485 | 1 | 2 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00197 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00725 | 2 | 2 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b01058 | 1 | 12 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00299 | 3 | 5 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00827 | 2 | 42 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00005 | 1 | 10 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00086 | 3 | 18 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00181 | 2 | 12 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | 2 | 6 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00939 | 2 | 18 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b01147 | 1 | 68 | binary | search_blocks, search_system_registry |
| 10.1021/acs.jced.9b00026 | 1 | 10 | binary | search_blocks, search_system_registry |
| 10.1021/je020173z | 2 | 48 | binary | search_blocks, search_system_registry |
| 10.1021/je030146o | 1 | 12 | binary | search_blocks, search_system_registry |
| 10.1021/je0495942 | 2 | 2 | binary | search_blocks, search_system_registry |
| 10.1021/je0497303 | 1 | 6 | binary | search_blocks, search_system_registry |
| 10.1021/je049875+ | 1 | 5 | binary | search_blocks, search_system_registry |
| 10.1021/je050537y | 2 | 56 | binary | search_blocks, search_system_registry |
| 10.1021/je0601098 | 2 | 24 | binary | search_blocks, search_system_registry |
| 10.1021/je060219e | 1 | 26 | binary | search_blocks, search_system_registry |
| 10.1021/je060335h | 1 | 164 | binary | search_blocks, search_system_registry |
| 10.1021/je2005209 | 2 | 30 | binary | search_blocks, search_system_registry |
| 10.1021/je200655s | 2 | 32 | binary | search_blocks, search_system_registry |
| 10.1021/je2008704 | 2 | 42 | binary | search_blocks, search_system_registry |
| 10.1021/je3007138 | 2 | 30 | binary | search_blocks, search_system_registry |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.fluid.2004.11.019 | PROPblock_2 | declared | 810 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_4 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_5 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2005.08.018 | PROPblock_6 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2006.04.017 | PROPblock_3 | declared | 28 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2007.06.007 | PROPblock_1 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2007.06.007 | PROPblock_2 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.10.002 | PROPblock_17 | declared | 5 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.10.002 | PROPblock_18 | declared | 5 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.11.014 | PROPblock_2 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2009.11.014 | PROPblock_3 | declared | 18 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2011.06.009 | PROPblock_1 | declared | 45 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2011.06.009 | PROPblock_2 | declared | 45 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.11.026 | PROPblock_4 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.11.026 | PROPblock_5 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.12.014 | PROPblock_2 | declared | 76 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2012.12.014 | PROPblock_3 | declared | 76 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2013.07.001 | PROPblock_6 | declared | 42 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.031 | PROPblock_4 | declared | 56 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.05.032 | PROPblock_1 | declared | 140 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.07.022 | PROPblock_1 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2014.07.022 | PROPblock_2 | declared | 7 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.07.012 | PROPblock_3 | declared | 84 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2015.07.012 | PROPblock_4 | declared | 84 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2016.08.030 | PROPblock_1 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.03.010 | PROPblock_7 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.03.010 | PROPblock_8 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.005 | PROPblock_3 | declared | 72 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2017.09.005 | PROPblock_4 | declared | 72 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2018.07.014 | PROPblock_4 | declared | 17 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2019.03.019 | PROPblock_8 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.fluid.2019.03.019 | PROPblock_9 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2004.07.019 | PROPblock_2 | declared | 565 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2005.06.018 | PROPblock_4 | declared | 27 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_1 | declared | 25 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_2 | declared | 19 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_3 | declared | 4 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2006.08.002 | PROPblock_4 | declared | 278 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_11 | declared | 37 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2007.05.004 | PROPblock_12 | declared | 37 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2011.10.009 | PROPblock_3 | declared | 70 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2012.08.009 | PROPblock_18 | declared | 14 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_10 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_11 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_12 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2013.08.020 | PROPblock_13 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_14 | declared | 18 | binary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_15 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_16 | declared | 17 | binary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_17 | declared | 39 | ternary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_3 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_4 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_5 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_8 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2013.08.020 | PROPblock_9 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2014.05.020 | PROPblock_1 | declared | 30 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2015.06.024 | PROPblock_7 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2015.06.024 | PROPblock_8 | declared | 40 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.07.021 | PROPblock_3 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2017.07.021 | PROPblock_4 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_19 | declared | 244 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_20 | declared | 152 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2018.02.022 | PROPblock_21 | declared | 100 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.jct.2019.02.027 | PROPblock_21 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1016/j.tca.2017.05.023 | PROPblock_1 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.5b00485 | PROPblock_8 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00197 | PROPblock_11 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00197 | PROPblock_12 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00725 | PROPblock_15 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b00725 | PROPblock_16 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.6b01058 | PROPblock_7 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00299 | PROPblock_10 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00299 | PROPblock_11 | declared | 2 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00299 | PROPblock_12 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00827 | PROPblock_12 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.7b00827 | PROPblock_13 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00005 | PROPblock_5 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00086 | PROPblock_46 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00086 | PROPblock_47 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00086 | PROPblock_48 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00181 | PROPblock_10 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00181 | PROPblock_11 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_12 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00723 | PROPblock_13 | declared | 3 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00939 | PROPblock_17 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b00939 | PROPblock_18 | declared | 9 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.8b01147 | PROPblock_6 | declared | 68 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/acs.jced.9b00026 | PROPblock_16 | declared | 10 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je020173z | PROPblock_4 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je020173z | PROPblock_5 | declared | 24 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je030146o | PROPblock_1 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0495942 | PROPblock_1 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0495942 | PROPblock_2 | declared | 1 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0497303 | PROPblock_2 | declared | 6 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je049875+ | PROPblock_1 | declared | 5 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je050537y | PROPblock_1 | declared | 28 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je050537y | PROPblock_2 | declared | 28 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0601098 | PROPblock_19 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je0601098 | PROPblock_20 | declared | 12 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je060219e | PROPblock_1 | declared | 26 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je060335h | PROPblock_1 | declared | 164 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je2005209 | PROPblock_2 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je2005209 | PROPblock_3 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je200655s | PROPblock_5 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je200655s | PROPblock_6 | declared | 16 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je2008704 | PROPblock_4 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je2008704 | PROPblock_5 | declared | 21 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je3007138 | PROPblock_2 | declared | 15 | binary | 2 | search_blocks, search_system_registry |
| 10.1021/je3007138 | PROPblock_3 | declared | 15 | binary | 2 | search_blocks, search_system_registry |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=80, purpose=Resolve ethanol and… | 317 | KEEP | 317 | 3.6 |
| 2 | 3 | `search_system_registry` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=100, … | 851 | KEEP | 792 | 26.1 |
| 3 | 5 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=100, … | 495 | KEEP | 1087 | 2.3 |
| 4 | 7 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, l… | 1,087 | KEEP | 1182 | 14.4 |
| 5 | 7 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, l… | 1,182 | KEEP | 1083 | 12.5 |
| 6 | 7 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, l… | 1,083 | KEEP | 1035 | 11.1 |
| 7 | 7 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=10, l… | 1,035 | KEEP | 1179 | 12.2 |
| 8 | 1 | `L1_query` | context=Looking for a paper suitable …, id_catalog… | 1,157 | — | — | 385.7 |
| 9 | 2 | `resolve_compound_ids` | purpose=Resolve ethanol and water com…, queries=['… | 246 | KEEP | 246 | 4.0 |
| 10 | 3 | `search_system_registry` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=100, … | 799 | KEEP | 710 | 14.1 |
| 11 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, l… | 1,179 | KEEP | 1064 | 14.7 |
| 12 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, l… | 1,064 | KEEP | 1064 | 10.8 |
| 13 | 4 | `search_blocks` | compound=['GLOBcomp_2', 'GLOBcomp_1'], limit=50, l… | 1,064 | KEEP | 782 | 11.2 |
| 14 | 5 | `search_blocks` | limit=50, literature=GLOBlit_3971, purpose=Find al… | 782 | — | — | 13.4 |
| 15 | 8 | `search_id_alignment` | entity_type=compound, limit=5, purpose=Identify GL… | 177 | KEEP | 177 | 4.0 |
| 16 | 2 | `L1_query` | context=, id_catalog=, instruction=Search for lite… | 270 | — | — | 220.1 |
| | | **TOTAL (16 tools)** | | **12,788** | | **10,718** | **760.2** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 21,525 | 21,525 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 3,016 | 3,016 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 668 | 10,273 | 1,359 | 7.3 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,119 | 21,762 | 18,678 | 87.4 |
| 3 | L1-worker | claudeopus46 | 20,643 | 20,418 | 41,061 | 612 | 8.0 |
| 4 | L1-worker | claudeopus46 | 2,065 | 446 | 2,511 | 505 | 3.6 |
| 5 | L1-worker | claudeopus46 | 20,643 | 20,655 | 41,298 | 860 | 6.4 |
| 6 | L1-worker | claudeopus46 | 2,065 | 15,155 | 17,220 | 1,338 | 11.5 |
| 7 | L1-worker | claudeopus46 | 2,065 | 15,365 | 17,430 | 1,803 | 13.7 |
| 8 | L1-worker | claudeopus46 | 20,610 | 22,822 | 43,432 | 621 | 5.7 |
| 9 | L1-worker | claudeopus46 | 20,643 | 22,067 | 42,710 | 9,782 | 45.7 |
| 10 | L1-worker | claudeopus46 | 20,643 | 32,424 | 53,067 | 768 | 6.2 |
| 11 | L1-worker | claudeopus46 | 20,643 | 32,914 | 53,557 | 8,803 | 38.3 |
| 12 | L1-worker | claudeopus46 | 20,643 | 42,338 | 62,981 | 1,623 | 8.0 |
| 13 | L1-worker | claudeopus46 | 2,065 | 7,928 | 9,993 | 1,818 | 14.3 |
| 14 | L1-worker | claudeopus46 | 2,065 | 6,178 | 8,243 | 1,602 | 12.2 |
| 15 | L1-worker | claudeopus46 | 2,065 | 6,763 | 8,828 | 1,492 | 10.9 |
| 16 | L1-worker | claudeopus46 | 2,065 | 5,173 | 7,238 | 1,473 | 12.0 |
| 17 | L1-worker | claudeopus46 | 20,643 | 44,199 | 64,842 | 3,799 | 21.6 |
| 18 | L1-worker | claudeopus46 | 1,356 | 2,408 | 3,764 | 1,109 | 5.3 |
| 19 | L1-worker | claudeopus46 | 536 | 2,288 | 2,824 | 1,177 | 5.4 |
| 20 | L1-worker | claudeopus46 | 1,323 | 13,215 | 14,538 | 4,908 | 20.6 |
| 21 | L1-worker | claudeopus46 | 298 | 5,630 | 5,928 | 3,999 | 16.4 |
| 22 | L1-worker | claudeopus46 | 747 | 89,688 | 90,435 | 1,272 | 10.8 |
| 23 | L1-worker | claudeopus46 | 1,160 | 20,467 | 21,627 | 3,999 | 16.6 |
| 24 | L1-worker | claudeopus46 | 747 | 89,688 | 90,435 | 1,063 | 9.6 |
| 25 | L0-main | claudeopus46 | 9,605 | 2,347 | 11,952 | 17,073 | 81.3 |
| 26 | L1-worker | claudeopus46 | 20,643 | 1,254 | 21,897 | 728 | 7.0 |
| 27 | L1-worker | claudeopus46 | 20,643 | 1,905 | 22,548 | 444 | 4.3 |
| 28 | L1-worker | claudeopus46 | 2,065 | 460 | 2,525 | 377 | 3.8 |
| 29 | L1-worker | claudeopus46 | 20,643 | 2,207 | 22,850 | 969 | 6.5 |
| 30 | L1-worker | claudeopus46 | 2,065 | 15,144 | 17,209 | 1,780 | 13.4 |
| 31 | L1-worker | claudeopus46 | 20,610 | 4,311 | 24,921 | 641 | 5.5 |
| 32 | L1-worker | claudeopus46 | 20,643 | 3,558 | 24,201 | 1,742 | 9.5 |
| 33 | L1-worker | claudeopus46 | 2,065 | 7,964 | 10,029 | 1,888 | 14.4 |
| 34 | L1-worker | claudeopus46 | 2,065 | 6,214 | 8,279 | 1,280 | 10.6 |
| 35 | L1-worker | claudeopus46 | 2,065 | 6,799 | 8,864 | 1,355 | 11.0 |
| 36 | L1-worker | claudeopus46 | 20,643 | 7,748 | 28,391 | 1,561 | 9.5 |
| 37 | L1-worker | claudeopus46 | 2,065 | 9,990 | 12,055 | 1,536 | 13.1 |
| 38 | L1-worker | claudeopus46 | 20,643 | 9,059 | 29,702 | 1,864 | 12.2 |
| 39 | L1-worker | claudeopus46 | 20,643 | 11,498 | 32,141 | 4,410 | 24.8 |
| 40 | L1-worker | claudeopus46 | 20,643 | 12,168 | 32,811 | 514 | 3.6 |
| 41 | L1-worker | claudeopus46 | 2,065 | 430 | 2,495 | 325 | 3.7 |
| 42 | L1-worker | claudeopus46 | 20,643 | 11,925 | 32,568 | 1,907 | 13.0 |
| 43 | L1-worker | claudeopus46 | 1,356 | 2,038 | 3,394 | 913 | 4.5 |
| 44 | L1-worker | claudeopus46 | 536 | 1,918 | 2,454 | 1,041 | 6.2 |
| 45 | L1-worker | claudeopus46 | 298 | 1,295 | 1,593 | 901 | 3.7 |
| 46 | L1-worker | claudeopus46 | 298 | 1,397 | 1,695 | 1,028 | 4.3 |
| 47 | L1-worker | claudeopus46 | 1,323 | 13,009 | 14,332 | 5,193 | 22.1 |
| 48 | L1-worker | claudeopus46 | 298 | 5,915 | 6,213 | 3,709 | 15.8 |
| 49 | L1-worker | claudeopus46 | 747 | 75,643 | 76,390 | 801 | 10.1 |
| 50 | L0-main | claudeopus46 | 9,605 | 68,352 | 77,957 | 6,051 | 37.5 |
| 51 | L0-main | claudeopus46 | 1,323 | 7,475 | 8,798 | 3,476 | 17.3 |
| 52 | L0-main | claudeopus46 | 1,356 | 3,694 | 5,050 | 1,312 | 21.7 |
| 53 | L0-main | claudeopus46 | 298 | 1,694 | 1,992 | 1,300 | 4.5 |
| 54 | L0-main | claudeopus46 | 298 | 4,144 | 4,442 | 2,824 | 11.0 |


# Reference Stats — query-agent

**Run started:** 2026-08-02 19:48:16
**Wall time (at last flush):** 257.0 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 31,792 | 50,955 | 6,978 | 82,747 | 13,791 | 51.4 | claudeopus46 |
| L1-worker | 22 | 200,915 | 115,586 | 37,547 | 316,501 | 14,386 | 221.1 | claudeopus46 |
| **TOTAL** | **28** | **232,707** | **166,541** | **44,525** | **399,248** | **14,258** | **272.5** | |

**Estimated tokens:** ~99,812 input + ~11,131 output = ~110,943 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 1 | 1 | 2 | 1 | 10 | 10 | 28 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **3** | **1** | **2** | **1** | **10** | **10** | **28** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_31 |  | resolve_compound_ids, search_blocks |

#### References (10 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_57 |  | search_blocks |
| GLOBlit_86 |  | search_blocks |
| GLOBlit_779 |  | search_blocks |
| GLOBlit_938 |  | search_blocks |
| GLOBlit_1246 |  | search_blocks |
| GLOBlit_1559 |  | search_blocks |
| GLOBlit_1775 |  | search_blocks |
| GLOBlit_2404 |  | search_blocks |
| GLOBlit_2435 |  | search_blocks |
| GLOBlit_2588 |  | search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 | Mass density, kg/m3 | search_blocks |

#### Measurements (5 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_138 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_179 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_2 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_141 | Mass density, kg/m3 | search_blocks |
| GLOBmeas_134 | Mass density, kg/m3 | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | search_blocks |

#### Variables (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_3 | Pressure, kPa | search_blocks |

#### Constraints (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique References | 10 |
| Unique Properties | 1 |
| Unique Measurements | 5 |
| Unique Phases | 1 |
| Unique Variables | 2 |
| Unique Constraints | 1 |
| Total DOIs | 10 |
| Unique parent blocks | 10 |
| Explicit block/subsystem targets | 10 |
| Subsystem targets | 0 |
| Target-matched data points | 28 |

---

## 3. DOI & Block References

**Unique DOIs:** 10  |  **Parent blocks:** 10  |  **Explicit targets:** 10  |  **Subsystems:** 0  |  **Target-matched datapoints:** 28

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1007/s10765-008-0395-z | 1 | 1 | unary | search_blocks |
| 10.1007/s10765-009-0648-5 | 1 | 5 | unary | search_blocks |
| 10.1016/j.fluid.2010.01.002 | 1 | 4 | unary | search_blocks |
| 10.1016/j.fluid.2011.02.010 | 1 | 5 | unary | search_blocks |
| 10.1016/j.fluid.2013.05.001 | 1 | 1 | unary | search_blocks |
| 10.1016/j.fluid.2014.09.022 | 1 | 8 | unary | search_blocks |
| 10.1016/j.fluid.2015.08.014 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2004.04.004 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2004.07.024 | 1 | 1 | unary | search_blocks |
| 10.1016/j.jct.2005.07.018 | 1 | 1 | unary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1007/s10765-008-0395-z | PROPblock_7 | declared | 1 | unary | — | search_blocks |
| 10.1007/s10765-009-0648-5 | PROPblock_4 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.fluid.2010.01.002 | PROPblock_3 | declared | 4 | unary | — | search_blocks |
| 10.1016/j.fluid.2011.02.010 | PROPblock_3 | declared | 5 | unary | — | search_blocks |
| 10.1016/j.fluid.2013.05.001 | PROPblock_1 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.fluid.2014.09.022 | PROPblock_1 | declared | 8 | unary | — | search_blocks |
| 10.1016/j.fluid.2015.08.014 | PROPblock_6 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2004.04.004 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2004.07.024 | PROPblock_2 | declared | 1 | unary | — | search_blocks |
| 10.1016/j.jct.2005.07.018 | PROPblock_9 | declared | 1 | unary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve DMSO to its… | 269 | KEEP | 269 | 5.0 |
| 2 | 1 | `L1_query` | context=User needs density of pure li…, id_catalog… | 436 | — | — | 111.8 |
| 3 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Find GLOBcomp ID fo… | 310 | KEEP | 310 | 4.7 |
| 4 | 4 | `search_blocks` | compound=GLOBcomp_31, limit=10, property=GLOBprop_… | 1,170 | KEEP | 1152 | 12.6 |
| 5 | 2 | `L1_query` | context=User needs density of pure li…, id_catalog… | 270 | — | — | 96.1 |
| | | **TOTAL (5 tools)** | | **2,455** | | **1,731** | **230.2** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 605 | 10,210 | 807 | 9.8 |
| 2 | L1-worker | claudeopus46 | 20,643 | 916 | 21,559 | 609 | 5.4 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,146 | 22,789 | 939 | 5.6 |
| 4 | L1-worker | claudeopus46 | 2,065 | 387 | 2,452 | 499 | 4.3 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,276 | 22,919 | 12,246 | 61.4 |
| 6 | L1-worker | claudeopus46 | 20,643 | 15,097 | 35,740 | 1,391 | 6.6 |
| 7 | L1-worker | claudeopus46 | 1,356 | 1,522 | 2,878 | 495 | 3.9 |
| 8 | L1-worker | claudeopus46 | 536 | 1,402 | 1,938 | 499 | 5.5 |
| 9 | L1-worker | claudeopus46 | 1,323 | 3,454 | 4,777 | 2,380 | 11.2 |
| 10 | L1-worker | claudeopus46 | 298 | 3,102 | 3,400 | 1,859 | 7.3 |
| 11 | L1-worker | claudeopus46 | 1,160 | 6,712 | 7,872 | 1,874 | 8.4 |
| 12 | L0-main | claudeopus46 | 9,605 | 1,485 | 11,090 | 1,084 | 8.2 |
| 13 | L1-worker | claudeopus46 | 20,643 | 1,027 | 21,670 | 679 | 5.5 |
| 14 | L1-worker | claudeopus46 | 2,065 | 408 | 2,473 | 552 | 4.3 |
| 15 | L1-worker | claudeopus46 | 20,643 | 1,785 | 22,428 | 981 | 8.1 |
| 16 | L1-worker | claudeopus46 | 20,643 | 2,632 | 23,275 | 864 | 6.9 |
| 17 | L1-worker | claudeopus46 | 20,643 | 3,583 | 24,226 | 1,099 | 14.5 |
| 18 | L1-worker | claudeopus46 | 2,065 | 6,035 | 8,100 | 1,481 | 11.8 |
| 19 | L1-worker | claudeopus46 | 20,643 | 4,292 | 24,935 | 1,697 | 11.6 |
| 20 | L1-worker | claudeopus46 | 1,356 | 1,535 | 2,891 | 421 | 3.4 |
| 21 | L1-worker | claudeopus46 | 536 | 1,415 | 1,951 | 641 | 4.7 |
| 22 | L1-worker | claudeopus46 | 1,323 | 7,203 | 8,526 | 3,222 | 12.1 |
| 23 | L1-worker | claudeopus46 | 298 | 3,944 | 4,242 | 2,445 | 11.8 |
| 24 | L1-worker | claudeopus46 | 747 | 44,713 | 45,460 | 674 | 6.8 |
| 25 | L0-main | claudeopus46 | 9,605 | 41,076 | 50,681 | 1,837 | 15.0 |
| 26 | L0-main | claudeopus46 | 1,356 | 1,548 | 2,904 | 395 | 3.0 |
| 27 | L0-main | claudeopus46 | 1,323 | 4,096 | 5,419 | 1,477 | 9.6 |
| 28 | L0-main | claudeopus46 | 298 | 2,145 | 2,443 | 1,378 | 5.8 |


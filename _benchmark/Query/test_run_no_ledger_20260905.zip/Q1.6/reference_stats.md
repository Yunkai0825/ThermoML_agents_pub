# Reference Stats — query-agent

**Run started:** 2026-08-02 18:44:44
**Wall time (at last flush):** 180.7 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 5 | 22,187 | 44,208 | 9,092 | 66,395 | 13,279 | 49.2 | claudeopus46 |
| L1-worker | 17 | 196,242 | 108,994 | 19,598 | 305,236 | 17,955 | 131.8 | claudeopus46 |
| **TOTAL** | **22** | **218,429** | **153,202** | **28,690** | **371,631** | **16,892** | **181.0** | |

**Estimated tokens:** ~92,907 input + ~7,172 output = ~100,079 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 1 | 0 | 0 | 0 | 7 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **0** | **3** | **0** | **7** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_3 |  | resolve_ids |
| GLOBvar_10 |  | resolve_ids |

#### References (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_1310 |  | block_search_adv |
| GLOBlit_1986 |  | block_search_adv |
| GLOBlit_3019 |  | block_search_adv |
| GLOBlit_3054 |  | block_search_adv |
| GLOBlit_4832 |  | block_search_adv |
| GLOBlit_7221 |  | block_search_adv |
| GLOBlit_7754 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_2 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 1 |
| Unique Variables | 3 |
| Unique References | 7 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve water compo… | 262 | KEEP | 262 | 4.6 |
| 2 | 2 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 536 | KEEP | 536 | 4.9 |
| 3 | 8 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 1,012 | KEEP | 1012 | 18.8 |
| 4 | 1 | `L1_query` | context=User wants the isobaric heat …, id_catalog… | 270 | — | — | 134.6 |
| | | **TOTAL (4 tools)** | | **2,080** | | **1,810** | **162.9** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 562 | 10,167 | 1,180 | 8.1 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,117 | 21,760 | 755 | 6.3 |
| 3 | L1-worker | claudeopus46 | 2,065 | 357 | 2,422 | 478 | 4.0 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,843 | 22,486 | 1,075 | 8.0 |
| 5 | L1-worker | claudeopus46 | 2,065 | 550 | 2,615 | 745 | 4.8 |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,898 | 23,541 | 1,108 | 9.9 |
| 7 | L1-worker | claudeopus46 | 20,643 | 3,769 | 24,412 | 1,022 | 8.6 |
| 8 | L1-worker | claudeopus46 | 20,643 | 4,642 | 25,285 | 979 | 8.0 |
| 9 | L1-worker | claudeopus46 | 20,643 | 5,375 | 26,018 | 925 | 8.5 |
| 10 | L1-worker | claudeopus46 | 20,643 | 6,180 | 26,823 | 917 | 6.7 |
| 11 | L1-worker | claudeopus46 | 20,643 | 7,055 | 27,698 | 2,094 | 14.5 |
| 12 | L1-worker | claudeopus46 | 2,065 | 5,582 | 7,647 | 1,474 | 11.2 |
| 13 | L1-worker | claudeopus46 | 20,643 | 6,365 | 27,008 | 1,640 | 9.3 |
| 14 | L1-worker | claudeopus46 | 1,356 | 1,450 | 2,806 | 456 | 3.0 |
| 15 | L1-worker | claudeopus46 | 536 | 1,330 | 1,866 | 700 | 4.8 |
| 16 | L1-worker | claudeopus46 | 1,323 | 12,105 | 13,428 | 2,721 | 10.3 |
| 17 | L1-worker | claudeopus46 | 298 | 3,443 | 3,741 | 2,034 | 8.5 |
| 18 | L1-worker | claudeopus46 | 747 | 44,933 | 45,680 | 475 | 5.4 |
| 19 | L0-main | claudeopus46 | 9,605 | 35,540 | 45,145 | 2,614 | 17.8 |
| 20 | L0-main | claudeopus46 | 1,356 | 1,691 | 3,047 | 511 | 3.7 |
| 21 | L0-main | claudeopus46 | 1,323 | 3,208 | 4,531 | 2,539 | 11.2 |
| 22 | L0-main | claudeopus46 | 298 | 3,207 | 3,505 | 2,248 | 8.4 |


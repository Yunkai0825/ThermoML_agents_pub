# Reference Stats — query-agent

**Run started:** 2026-08-02 19:08:28
**Wall time (at last flush):** 879.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 8 | 41,695 | 178,343 | 24,238 | 220,038 | 27,504 | 146.2 | claudeopus46 |
| L1-worker | 87 | 897,133 | 984,052 | 110,238 | 1,881,185 | 21,622 | 763.6 | claudeopus46 |
| **TOTAL** | **95** | **938,828** | **1,162,395** | **134,476** | **2,101,223** | **22,118** | **909.8** | |

**Estimated tokens:** ~525,305 input + ~33,619 output = ~558,924 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 3 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 2 | 4 | 4 | 177 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 1 | 2 | 2 | 86 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `search_blocks` | 2 | 1 | 2 | 1 | 1 | 1 | 80 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| `search_blocks` | 2 | 1 | 3 | 1 | 2 | 2 | 86 |
| **TOTAL** | **17** | **4** | **11** | **6** | **12** | **9** | **429** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_18 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids, search_blocks |
| GLOBcomp_15 |  | block_search_adv, resolve_compound_ids, search_blocks |

#### References (7 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_8676 |  | block_search_adv, search_blocks |
| GLOBlit_9900 |  | search_blocks |
| GLOBlit_11030 |  | search_blocks |
| GLOBlit_11207 |  | search_blocks |
| GLOBlit_4124 |  | search_blocks |
| GLOBlit_7481 |  | block_search_adv, search_blocks |
| GLOBlit_2602 |  | block_search_adv, search_blocks |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_4 | Viscosity, Pa*s | search_blocks |

#### Measurements (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBmeas_140 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_4 | Viscosity, Pa*s | search_blocks |
| GLOBmeas_8 | Viscosity, Pa*s | search_blocks |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv, search_blocks |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_2 | Mole fraction | resolve_ids, search_blocks |
| GLOBvar_1 | Temperature, K | search_blocks |
| GLOBvar_5 | Mass fraction | search_blocks |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_2 | Temperature, K | resolve_ids, search_blocks |
| GLOBconstr_1 | Pressure, kPa | search_blocks |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 3 |
| Unique References | 7 |
| Unique Properties | 1 |
| Unique Measurements | 3 |
| Unique Phases | 1 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Unique Block_Types | 1 |
| Total DOIs | 7 |
| Unique parent blocks | 7 |
| Explicit block/subsystem targets | 7 |
| Subsystem targets | 0 |
| Target-matched data points | 429 |

---

## 3. DOI & Block References

**Unique DOIs:** 7  |  **Parent blocks:** 7  |  **Explicit targets:** 7  |  **Subsystems:** 0  |  **Target-matched datapoints:** 343

| DOI | Blocks | Datapoints | System types | Source tools |
|-----|-------:|-----------:|--------------|--------------|
| 10.1016/j.jct.2005.08.009 | 1 | 80 | binary | search_blocks |
| 10.1016/j.jct.2014.02.019 | 1 | 20 | binary | search_blocks |
| 10.1021/acs.jced.8b00176 | 1 | 66 | binary | search_blocks |
| 10.1021/je050209y | 1 | 11 | binary | search_blocks |
| 10.1021/je300608v | 1 | 60 | binary | search_blocks |
| 10.1021/je700671t | 1 | 98 | binary | search_blocks |
| 10.1021/je800330d | 1 | 8 | binary | search_blocks |

<details><summary>Block detail</summary>

| DOI | Block | Target | Datapoints | System | nComp | Source tools |
|-----|------:|--------|-----------:|--------|------:|--------------|
| 10.1016/j.jct.2005.08.009 | PROPblock_3 | declared | 80 | binary | — | search_blocks |
| 10.1016/j.jct.2014.02.019 | PROPblock_6 | declared | 20 | binary | — | search_blocks |
| 10.1021/acs.jced.8b00176 | PROPblock_18 | declared | 66 | binary | — | search_blocks |
| 10.1021/je050209y | PROPblock_9 | declared | 11 | binary | — | search_blocks |
| 10.1021/je300608v | PROPblock_3 | declared | 60 | binary | — | search_blocks |
| 10.1021/je700671t | PROPblock_3 | declared | 98 | binary | — | search_blocks |
| 10.1021/je800330d | PROPblock_3 | declared | 8 | binary | — | search_blocks |

</details>

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 1 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Find compound IDs f… | 324 | KEEP | 324 | 3.8 |
| 2 | 2 | `search_blocks` | compound=['GLOBcomp_18', 'GLOBcomp_1',…, limit=50,… | 712 | DISCARD | 654 | 10.7 |
| 3 | 3 | `search_blocks` | compound=['GLOBcomp_18', 'GLOBcomp_1',…, limit=50,… | 703 | DISCARD | 645 | 19.0 |
| 4 | 1 | `L1_query` | context=User wants viscosity of equim…, id_catalog… | 2,276 | — | — | 76.6 |
| 5 | 2 | `search_blocks` | compound=['GLOBcomp_18', 'GLOBcomp_1'], limit=50, … | 750 | KEEP | 750 | 23.2 |
| 6 | 4 | `resolve_ids` | entity_type=variable, limit=5, min_score=50, purpo… | 279 | KEEP | 279 | 4.2 |
| 7 | 6 | `resolve_ids` | entity_type=constraint, limit=5, min_score=50, pur… | 293 | KEEP | 293 | 6.0 |
| 8 | 12 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_1… | 1,018 | KEEP | 988 | 20.8 |
| 9 | 2 | `L1_query` | context=User wants to estimate ternar…, id_catalog… | 15,893 | — | — | 202.9 |
| 10 | 1 | `search_blocks` | compound=['GLOBcomp_18', 'GLOBcomp_15'], limit=20,… | 865 | KEEP | 835 | 13.4 |
| 11 | 5 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_18 AS dmf'…, explanat… | 1,029 | KEEP | 1014 | 13.2 |
| 12 | 2 | `L1_query` | context=User wants to estimate ternar…, id_catalog… | 707 | — | — | 157.0 |
| 13 | 2 | `search_blocks` | compound=['GLOBcomp_1', 'GLOBcomp_15'], limit=50, … | 1,151 | KEEP | 1121 | 12.5 |
| 14 | 6 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_1 AS wat',…, explanat… | 1,132 | KEEP | 1117 | 14.6 |
| 15 | 2 | `L1_query` | context=User wants to estimate ternar…, id_catalog… | 10,393 | — | — | 136.8 |
| 16 | 1 | `search_blocks` | compound=['GLOBcomp_18', 'GLOBcomp_15'], limit=20,… | 1,139 | KEEP | 1079 | 17.0 |
| 17 | 3 | `L1_query` | context=This is the third binary pair…, id_catalog… | 16,924 | — | — | 168.8 |
| | | **TOTAL (17 tools)** | | **55,588** | | **9,099** | **900.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,664 | 3,664 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,294 | 4,294 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 7,561 | 7,561 | 0 | 0.0% |
| 4 | interval=3 | skipped_by_agent | 5,557 | 5,557 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 700 | 10,305 | 1,175 | 7.7 |
| 2 | L1-worker | claudeopus46 | 20,643 | 943 | 21,586 | 829 | 6.1 |
| 3 | L1-worker | claudeopus46 | 2,065 | 544 | 2,609 | 497 | 3.7 |
| 4 | L1-worker | claudeopus46 | 20,643 | 1,731 | 22,374 | 963 | 8.1 |
| 5 | L1-worker | claudeopus46 | 2,065 | 602 | 2,667 | 1,147 | 7.3 |
| 6 | L1-worker | claudeopus46 | 20,643 | 2,945 | 23,588 | 936 | 7.1 |
| 7 | L1-worker | claudeopus46 | 2,065 | 525 | 2,590 | 899 | 8.1 |
| 8 | L1-worker | claudeopus46 | 20,610 | 4,959 | 25,569 | 577 | 3.8 |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,206 | 24,849 | 1,069 | 6.6 |
| 10 | L1-worker | claudeopus46 | 1,323 | 5,073 | 6,396 | 309 | 2.8 |
| 11 | L1-worker | claudeopus46 | 1,356 | 928 | 2,284 | 416 | 2.9 |
| 12 | L1-worker | claudeopus46 | 536 | 808 | 1,344 | 509 | 3.6 |
| 13 | L1-worker | claudeopus46 | 298 | 1,031 | 1,329 | 203 | 2.7 |
| 14 | L1-worker | claudeopus46 | 747 | 6,316 | 7,063 | 560 | 5.1 |
| 15 | L0-main | claudeopus46 | 9,605 | 6,040 | 15,645 | 2,424 | 10.0 |
| 16 | L1-worker | claudeopus46 | 20,643 | 3,591 | 24,234 | 1,027 | 7.1 |
| 17 | L1-worker | claudeopus46 | 20,643 | 4,279 | 24,922 | 699 | 4.9 |
| 18 | L1-worker | claudeopus46 | 2,065 | 8,699 | 10,764 | 1,840 | 15.1 |
| 19 | L1-worker | claudeopus46 | 20,643 | 5,207 | 25,850 | 818 | 6.4 |
| 20 | L1-worker | claudeopus46 | 20,643 | 5,938 | 26,581 | 569 | 4.4 |
| 21 | L1-worker | claudeopus46 | 2,065 | 403 | 2,468 | 463 | 4.2 |
| 22 | L1-worker | claudeopus46 | 20,643 | 6,332 | 26,975 | 1,314 | 9.3 |
| 23 | L1-worker | claudeopus46 | 20,643 | 7,065 | 27,708 | 502 | 7.0 |
| 24 | L1-worker | claudeopus46 | 2,065 | 404 | 2,469 | 502 | 6.0 |
| 25 | L1-worker | claudeopus46 | 20,610 | 8,194 | 28,804 | 428 | 3.4 |
| 26 | L1-worker | claudeopus46 | 20,643 | 7,441 | 28,084 | 1,230 | 8.8 |
| 27 | L1-worker | claudeopus46 | 20,643 | 8,384 | 29,027 | 1,010 | 7.9 |
| 28 | L1-worker | claudeopus46 | 20,643 | 9,179 | 29,822 | 1,356 | 9.2 |
| 29 | L1-worker | claudeopus46 | 20,643 | 9,920 | 30,563 | 962 | 7.4 |
| 30 | L1-worker | claudeopus46 | 20,643 | 10,718 | 31,361 | 1,186 | 10.2 |
| 31 | L1-worker | claudeopus46 | 20,643 | 11,608 | 32,251 | 1,077 | 7.8 |
| 32 | L1-worker | claudeopus46 | 2,065 | 1,890 | 3,955 | 1,742 | 11.9 |
| 33 | L1-worker | claudeopus46 | 20,610 | 11,612 | 32,222 | 601 | 6.7 |
| 34 | L1-worker | claudeopus46 | 20,610 | 8,020 | 28,630 | 2,957 | 19.9 |
| 35 | L1-worker | claudeopus46 | 1,356 | 2,276 | 3,632 | 1,010 | 5.1 |
| 36 | L1-worker | claudeopus46 | 536 | 2,156 | 2,692 | 1,017 | 5.9 |
| 37 | L1-worker | claudeopus46 | 1,323 | 17,130 | 18,453 | 1,536 | 9.0 |
| 38 | L1-worker | claudeopus46 | 298 | 1,373 | 1,671 | 1,004 | 4.0 |
| 39 | L1-worker | claudeopus46 | 298 | 2,258 | 2,556 | 1,211 | 4.9 |
| 40 | L1-worker | claudeopus46 | 1,160 | 18,947 | 20,107 | 835 | 4.2 |
| 41 | L1-worker | claudeopus46 | 747 | 31,872 | 32,619 | 824 | 8.3 |
| 42 | L1-worker | claudeopus46 | 20,643 | 19,584 | 40,227 | 855 | 6.2 |
| 43 | L1-worker | claudeopus46 | 2,065 | 5,306 | 7,371 | 1,622 | 12.9 |
| 44 | L1-worker | claudeopus46 | 20,643 | 20,937 | 41,580 | 1,442 | 10.8 |
| 45 | L1-worker | claudeopus46 | 20,643 | 21,955 | 42,598 | 1,303 | 9.7 |
| 46 | L1-worker | claudeopus46 | 20,643 | 22,786 | 43,429 | 1,186 | 9.5 |
| 47 | L1-worker | claudeopus46 | 20,643 | 23,584 | 44,227 | 928 | 7.9 |
| 48 | L1-worker | claudeopus46 | 2,065 | 1,827 | 3,892 | 1,654 | 11.2 |
| 49 | L1-worker | claudeopus46 | 20,643 | 23,720 | 44,363 | 4,352 | 28.6 |
| 50 | L1-worker | claudeopus46 | 1,356 | 2,505 | 3,861 | 1,052 | 5.1 |
| 51 | L1-worker | claudeopus46 | 536 | 2,385 | 2,921 | 1,081 | 6.4 |
| 52 | L1-worker | claudeopus46 | 1,323 | 10,959 | 12,282 | 1,250 | 8.3 |
| 53 | L1-worker | claudeopus46 | 298 | 1,434 | 1,732 | 1,040 | 3.9 |
| 54 | L1-worker | claudeopus46 | 298 | 1,972 | 2,270 | 1,024 | 4.4 |
| 55 | L1-worker | claudeopus46 | 747 | 26,470 | 27,217 | 2,464 | 18.4 |
| 56 | L1-worker | claudeopus46 | 298 | 2,823 | 3,121 | 733 | 3.3 |
| 57 | L1-worker | claudeopus46 | 1,160 | 13,118 | 14,278 | 969 | 4.5 |
| 58 | L1-worker | claudeopus46 | 747 | 26,415 | 27,162 | 2,035 | 13.8 |
| 59 | L1-worker | claudeopus46 | 298 | 2,394 | 2,692 | 613 | 3.5 |
| 60 | L1-worker | claudeopus46 | 20,643 | 19,560 | 40,203 | 879 | 6.1 |
| 61 | L1-worker | claudeopus46 | 20,643 | 20,297 | 40,940 | 767 | 5.2 |
| 62 | L1-worker | claudeopus46 | 2,065 | 3,131 | 5,196 | 1,516 | 12.0 |
| 63 | L1-worker | claudeopus46 | 20,643 | 21,583 | 42,226 | 1,862 | 14.0 |
| 64 | L1-worker | claudeopus46 | 20,643 | 22,493 | 43,136 | 1,232 | 8.7 |
| 65 | L1-worker | claudeopus46 | 20,643 | 23,458 | 44,101 | 2,169 | 13.2 |
| 66 | L1-worker | claudeopus46 | 20,643 | 24,315 | 44,958 | 2,118 | 14.0 |
| 67 | L1-worker | claudeopus46 | 2,065 | 1,846 | 3,911 | 2,317 | 13.5 |
| 68 | L1-worker | claudeopus46 | 20,610 | 25,427 | 46,037 | 562 | 4.9 |
| 69 | L1-worker | claudeopus46 | 20,643 | 24,674 | 45,317 | 3,614 | 25.1 |
| 70 | L1-worker | claudeopus46 | 536 | 2,329 | 2,865 | 883 | 5.3 |
| 71 | L1-worker | claudeopus46 | 1,356 | 2,449 | 3,805 | 1,039 | 5.5 |
| 72 | L1-worker | claudeopus46 | 1,323 | 12,388 | 13,711 | 719 | 7.0 |
| 73 | L1-worker | claudeopus46 | 298 | 1,239 | 1,537 | 870 | 3.7 |
| 74 | L1-worker | claudeopus46 | 298 | 1,441 | 1,739 | 592 | 3.1 |
| 75 | L1-worker | claudeopus46 | 747 | 21,631 | 22,378 | 650 | 7.1 |
| 76 | L0-main | claudeopus46 | 9,605 | 34,329 | 43,934 | 1,817 | 13.3 |
| 77 | L1-worker | claudeopus46 | 20,643 | 30,284 | 50,927 | 857 | 6.3 |
| 78 | L1-worker | claudeopus46 | 2,065 | 5,294 | 7,359 | 1,490 | 12.3 |
| 79 | L1-worker | claudeopus46 | 20,643 | 31,926 | 52,569 | 8,105 | 50.4 |
| 80 | L1-worker | claudeopus46 | 20,643 | 32,898 | 53,541 | 1,422 | 10.5 |
| 81 | L1-worker | claudeopus46 | 20,643 | 33,719 | 54,362 | 1,915 | 12.8 |
| 82 | L1-worker | claudeopus46 | 20,643 | 34,547 | 55,190 | 1,083 | 8.4 |
| 83 | L1-worker | claudeopus46 | 20,643 | 35,451 | 56,094 | 1,648 | 13.6 |
| 84 | L1-worker | claudeopus46 | 20,643 | 36,302 | 56,945 | 3,823 | 26.5 |
| 85 | L1-worker | claudeopus46 | 536 | 2,815 | 3,351 | 1,188 | 6.4 |
| 86 | L1-worker | claudeopus46 | 1,323 | 12,655 | 13,978 | 1,043 | 6.7 |
| 87 | L1-worker | claudeopus46 | 1,356 | 2,935 | 4,291 | 953 | 6.9 |
| 88 | L1-worker | claudeopus46 | 298 | 1,765 | 2,063 | 817 | 3.9 |
| 89 | L1-worker | claudeopus46 | 298 | 1,335 | 1,633 | 941 | 5.1 |
| 90 | L1-worker | claudeopus46 | 747 | 28,184 | 28,931 | 927 | 10.1 |
| 91 | L0-main | claudeopus46 | 9,605 | 68,928 | 78,533 | 9,892 | 72.4 |
| 92 | L0-main | claudeopus46 | 1,356 | 4,153 | 5,509 | 1,045 | 6.2 |
| 93 | L0-main | claudeopus46 | 298 | 1,427 | 1,725 | 1,033 | 3.9 |
| 94 | L0-main | claudeopus46 | 1,323 | 58,434 | 59,757 | 3,664 | 20.4 |
| 95 | L0-main | claudeopus46 | 298 | 4,332 | 4,630 | 3,188 | 12.3 |


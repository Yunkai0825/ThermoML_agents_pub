# Q5.3 — Result

**Prompt:** Find density data for salt water.

**Tool calls:** 1  |  **Time:** 335.4s  |  **Iterations:** 2  |  **Timed out:** False

---

## Answer

The ThermoML database contains extensive mass density data for the sodium chloride (NaCl) + water binary system — commonly known as "salt water." Here is a summary of what's available:

## Overall Coverage

- **63 data blocks** of liquid-phase mass density measurements
- **Measurement method:** Vibrating-tube densimetry (used across all blocks)
- **Temperature range:** ~278 K to ~368 K (~5 °C to ~95 °C)
- **Pressure:** Predominantly atmospheric (101.325 kPa)
- **Composition range:** Dilute (~0.1 mol/kg NaCl) up to near saturation (~6.0 mol/kg, ≈26 wt%)
- **Composition variables:** Molality (mol/kg) or mole fraction, depending on the source

## Representative Data Points

| DOI | Block | T (K) | Molality (mol/kg) | Density (kg/m³) |
|-----|-------|--------|-------------------|-----------------|
| 10.1021/je060382+ | PROPblock_1 | 278.15 | 0.1 | 1003.42 |
| 10.1021/je060009y | PROPblock_1 | 288.15 | 0.171 | 1003.77 |
| 10.1021/je0602275 | PROPblock_1 | 293.15 | 0.1 | 1002.36 |
| 10.1021/je700232s | PROPblock_1 | 293.15 | 0.110 | 1002.55 |
| 10.1021/je700232s | PROPblock_2 | 293.15 | 0.110 | 1002.58 |
| 10.1021/je060382+ | PROPblock_1 | 298.15 | 6.0 | 1189.18 |
| 10.1021/je700232s | PROPblock_1 | 293.15 | 6.0 | 1195.95 |
| 10.1021/je700232s | PROPblock_2 | 293.15 | 6.0 | 1195.98 |

## Key Chemical Insights

- **Dilute solutions** (~0.1 mol/kg NaCl): Density is only slightly above pure water (~998 kg/m³ at 293 K), measuring around **1002–1004 kg/m³**. The dissolved Na⁺ and Cl⁻ ions and their hydration shells add mass but occupy relatively little additional volume at low concentrations.

- **Concentrated solutions** (~6.0 mol/kg, near saturation): Density increases substantially to **~1189–1196 kg/m³** — roughly 20% higher than pure water. At these concentrations, a significant fraction of the solution mass comes from the dissolved salt, and electrostriction (compression of water molecules around ions) further contributes to the density increase.

- **Temperature dependence:** At any given NaCl concentration, density decreases with increasing temperature, consistent with normal thermal expansion behavior.

## Notable Data Sources

| DOI | Blocks | Data Points | Temperature Range |
|-----|--------|-------------|-------------------|
| 10.1021/je060382+ | 1 block | 100 points | 278–368 K |
| 10.1021/je800049k | 11 blocks | 66 points each | 293–343 K |
| 10.1021/je700232s | 2 blocks | 66 points each | 293–343 K |
| 10.1021/je049918z | 1 block | 12 points | 293–298 K |
| 10.1021/je050261u | 1 block | 12 points | 293–298 K |

The most comprehensive single dataset is from DOI 10.1021/je060382+ with 100 data points spanning nearly 90 K in temperature. The dataset from DOI 10.1021/je800049k provides the most systematic coverage with 11 separate measurement blocks.

### Core claims

- The ThermoML database contains 63 data blocks of liquid-phase mass density measurements for the NaCl + water binary system, all obtained by vibrating-tube densimetry, covering temperatures from ~278 K to ~368 K at predominantly atmospheric pressure (101.325 kPa) and NaCl molalities from ~0.1 to ~6.0 mol/kg (near saturation).
- Dilute NaCl solutions (~0.1 mol/kg) have densities only slightly above pure water (~1002–1004 kg/m³ at 293 K), whereas concentrated solutions (~6.0 mol/kg) reach ~1189–1196 kg/m³, roughly 20% higher than pure water, reflecting the combined effects of dissolved-salt mass and electrostriction.
- At any given NaCl concentration, density decreases with increasing temperature, consistent with normal thermal expansion behavior.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_9032 | 10.1021/je060382+ | PROPblock_1 |  | 100 data points of mass density for NaCl + water, 278–368 K, molality 0.1–6.0 mol/kg, vibrating-tube densimetry |
| GLOBlit_8697 | 10.1021/je050261u | PROPblock_1 |  | 12 data points of mass density for NaCl + water at 293–298 K, mole fraction composition variable |

### Suggested follow-ups

- Query for apparent molar volume or excess molar volume data for NaCl + water to complement the density measurements.
- Search for density data at elevated pressures (beyond atmospheric 101.325 kPa) for NaCl + water.
- Look for density data of other common salt water systems such as KCl + water or MgCl2 + water for comparison.
- Retrieve speed-of-sound data for NaCl + water, which is often measured alongside density by vibrating-tube instruments.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_26",
    "registry_id": "sodium_chloride",
    "name": "sodium chloride"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density",
    "name": "mass density"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_3",
    "registry_id": "liquid",
    "name": "liquid"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_1",
    "registry_id": "vibrating_tube",
    "name": "vibrating tube"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_14",
    "registry_id": "molality",
    "name": "molality (mol/kg)"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_3",
    "registry_id": "mole_fraction",
    "name": "mole fraction"
  }
]
```

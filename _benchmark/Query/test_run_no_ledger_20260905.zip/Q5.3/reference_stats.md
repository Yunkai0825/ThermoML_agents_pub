# Reference Stats — query-agent

**Run started:** 2026-08-02 19:38:53
**Wall time (at last flush):** 335.4 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 6 | 22,485 | 27,569 | 22,846 | 50,054 | 8,342 | 109.4 | claudeopus46 |
| L1-worker | 15 | 152,284 | 126,382 | 47,827 | 278,666 | 18,577 | 247.0 | claudeopus46 |
| **TOTAL** | **21** | **174,769** | **153,951** | **70,673** | **328,720** | **15,653** | **356.4** | |

**Estimated tokens:** ~82,180 input + ~17,668 output = ~99,848 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| **TOTAL** | **2** | **0** | **0** | **0** | **0** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_26 |  | resolve_compound_ids |
| GLOBcomp_1 |  | resolve_compound_ids |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve NaCl and wa… | 218 | KEEP | 218 | 4.0 |
| 2 | 1 | `L1_query` | context=Salt water = aqueous NaCl sol…, id_catalog… | 4,600 | — | — | 233.6 |
| | | **TOTAL (2 tools)** | | **4,818** | | **218** | **237.6** |

---

## 5. Compaction Events

*(no compaction events recorded)*

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 496 | 10,101 | 12,150 | 59.5 |
| 2 | L1-worker | claudeopus46 | 20,643 | 911 | 21,554 | 614 | 4.8 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,146 | 22,789 | 871 | 5.7 |
| 4 | L1-worker | claudeopus46 | 2,065 | 458 | 2,523 | 414 | 3.9 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,276 | 22,919 | 15,355 | 60.4 |
| 6 | L1-worker | claudeopus46 | 20,643 | 18,252 | 38,895 | 5,964 | 31.0 |
| 7 | L1-worker | claudeopus46 | 20,643 | 19,072 | 39,715 | 6,338 | 33.9 |
| 8 | L1-worker | claudeopus46 | 20,643 | 19,925 | 40,568 | 5,832 | 34.7 |
| 9 | L1-worker | claudeopus46 | 20,643 | 20,769 | 41,412 | 3,299 | 22.8 |
| 10 | L1-worker | claudeopus46 | 1,356 | 2,584 | 3,940 | 779 | 4.7 |
| 11 | L1-worker | claudeopus46 | 536 | 2,464 | 3,000 | 942 | 5.5 |
| 12 | L1-worker | claudeopus46 | 298 | 1,161 | 1,459 | 767 | 4.9 |
| 13 | L1-worker | claudeopus46 | 1,323 | 8,470 | 9,793 | 3,122 | 14.5 |
| 14 | L1-worker | claudeopus46 | 298 | 3,844 | 4,142 | 2,445 | 10.0 |
| 15 | L1-worker | claudeopus46 | 1,160 | 11,981 | 13,141 | 154 | 2.8 |
| 16 | L1-worker | claudeopus46 | 747 | 12,069 | 12,816 | 931 | 7.4 |
| 17 | L0-main | claudeopus46 | 9,605 | 10,347 | 19,952 | 3,106 | 17.2 |
| 18 | L0-main | claudeopus46 | 1,356 | 2,950 | 4,306 | 786 | 4.9 |
| 19 | L0-main | claudeopus46 | 298 | 1,168 | 1,466 | 774 | 3.1 |
| 20 | L0-main | claudeopus46 | 1,323 | 8,661 | 9,984 | 3,279 | 14.9 |
| 21 | L0-main | claudeopus46 | 298 | 3,947 | 4,245 | 2,751 | 9.8 |


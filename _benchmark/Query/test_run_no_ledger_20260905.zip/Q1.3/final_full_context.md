## System Prompt
# ThermoML Query Orchestrator

Top-level agent: interprets user questions, manages working memory,
dispatches L1 workers for database searches, integrates results.

You have NO direct database access — every fact must come from L1 returns.

**Chemistry-context hint:** When useful and tool-supported, use existing output fields to add a brief chemistry insight and one or a few representative data points with values, units, conditions, compounds, and DOI/block provenance. Mark inference, never invent data, and delegation-only roles should preserve rather than create this context.

## Core Rules

- ALWAYS call L1_query first for any data question.
- L1_query results, canonical IDs, and history are saved automatically by the
  runtime. Do not repeat that persistence with memory_add_result,
  memory_catalog_add, or memory_append_history.
- Final answer MUST contain actual data/numbers inline. NEVER say "saved to memory" as the answer.
- If L1 returns no_results: say "No data found in the ThermoML database for [X]". Do NOT fabricate.
- NEVER fabricate DOIs, block numbers, values, or cite external sources (JANAF, WebBook, textbooks).
- LITERATURE IDENTITY: `GLOBlit_N` is the authoritative literature
  identifier — prefer it in reasoning, memory, and delegation context. A DOI
  is coupled display metadata: whenever a DOI is reported, place its
  tool-returned `GLOBlit_N` next to it. Never emit an unpaired DOI; a final
  answer citing a DOI no tool coupled to a `GLOBlit_N` is scrubbed as
  unverifiable.
- Partial data: state what was found AND what is missing.
- Compact History (>30 entries) / Results (>10 entries) proactively.
- You can delegate property/system screening and ranking questions to
  `L1_query`. State the ranking direction, centre compounds, composition grid,
  numeric state constraints, and—when the question concerns solvent
  interactions—the exact centre-component mole fraction that should drive
  ranking. L1 owns the specialized ranking tool; L0 still has no direct
  database access.

## Agent-Emitted Markers

You MUST wrap your output in exactly these markers:

**During tool-calling turns:**
```
<reasoning>
... your thinking/planning (DISCARDED from memory after each turn) ...
</reasoning>
<summary>
... 1-3 sentence conclusion of what you did or plan to do (KEPT in memory, ≤400 chars) ...
</summary>
<tool_call>{"name": "L1_query", "arguments": {"purpose": "...", "instruction": "..."}}</tool_call>
<wait/>
```

**For the final answer (no more tool calls):**
```
<answer>
... your complete answer to the user's question — any length ...
Include all key numbers, DOIs, block numbers, temperature ranges.
For counts: state the count. For listings: include top 5+ entries.
</answer>
```

Rules:
- `<reasoning>` = extended thinking. Stripped after each turn, never persists.
- `<summary>` = brief conclusion. Persists in memory. Max 400 chars.
- `<tool_call>` MUST come AFTER `</summary>` and BEFORE `<wait/>`.
- `<answer>` = full final response to user. Can be as long as needed. All markers stripped from output.
- `<summary>` ≠ `<answer>`: summary is a brief memory note; answer is the complete user-facing response.
- `<answer>` must NEVER mention internal mechanics (working memory, L1 queries, memory keys, agent systems). Present data as if it came directly from the database. The user cannot see your memory or tool calls.

## Common Property IDs

| prop_num_id | Property | Unit |
|:-----------:|----------|------|
| GLOBprop_1  | Mass density | kg/m³ |
| GLOBprop_4  | Viscosity (dynamic) | Pa·s |
| GLOBprop_5  | Vapor/sublimation pressure | kPa |
| GLOBprop_7  | Refractive index (Na D-line) | — |
| GLOBprop_8  | Speed of sound | m/s |
| GLOBprop_9  | Molar Cp (constant pressure) | J/(K·mol) |
| GLOBprop_10 | Molar enthalpy of transition/fusion | kJ/mol |
| GLOBprop_11 | Solid–liquid equilibrium temperature | K |
| GLOBprop_13 | Surface tension (liquid–gas) | N/m |
| GLOBprop_14 | Boiling temperature at pressure P | K |
| GLOBprop_17 | Excess molar enthalpy (Hᴱ) | kJ/mol |
| GLOBprop_18 | Electrical conductivity | S/m |
| GLOBprop_40 | Kinematic viscosity | m²/s |

These are the ACTUAL database IDs. Do NOT guess property IDs.

## ID Conventions

- Every `*_num_id` is a typed global string (`GLOBcomp_N`, `GLOBprop_N`,
  `GLOBvar_N`, `GLOBconstr_N`, `GLOBmeas_N`, `GLOBphase_N`, `GLOBlit_N`,
  `GLOBsolvent_N`, `GLOBblocktype_N`, or `GLOBrxntype_N`). It is never a
  number. DOI compounds are `DOIcomp_N`; block declarations are `BLKprop_N`,
  `BLKvar_N`, and `BLKconstr_N`; blocks are `PROPblock_N` or `RXNblock_N`.
- Reject rather than normalize legacy IDs (`comp_N`, `prop_N`, `block_N`) or
  bare numbers. Never reconstruct, strip, or translate ID prefixes.
- Apply L1's core_id_updates to the ID Catalog immediately.
- Do NOT call memory_catalog_remove unless correcting an error.

# Tools

## memory
- memory_read(section=None) — read working memory or a section
- memory_append_history(line) — append log entry to History
- memory_add_result(key, body) — store named result in Results
- memory_catalog_add(type_, global_id, registry_id, name) — add a strict global ID to the ID Catalog; type_ is one of comp, prop, var, constr, meas, phase, lit, solvent, blocktype, rxntype and must match the GLOB* prefix
- memory_catalog_remove(type_, global_id) — remove an exact global ID from the ID Catalog
- memory_catalog_list() — list ID Catalog as JSON
- memory_compact(section, summary_text) — compact a section
- memory_reset() — reset working memory

## L1_workers
- L1_query(purpose, instruction, id_catalog, context) — dispatch query worker (max 2000 tok return)

# Prompt Template

## User Question
{{purpose}}

## Working Memory
{{context}}

## ID Catalog
{{id_catalog}}

# Phases

## phase_1: understand_and_plan
tools: [memory]
guidance: |
  Read working memory / ID Catalog. Interpret question, plan queries.

## phase_2: dispatch_and_integrate
tools: [L1_workers, memory]
guidance: |
  Dispatch L1_query with precise purpose+instruction. The runtime
  automatically persists its result, canonical IDs, and history. Inspect the
  returned result or memory_read as needed; do not duplicate persistence.
  Re-dispatch if partial results.
  For multi-part questions, dispatch multiple L1_query calls.
  For rankings, explicitly ask L1 to use its specialized property screening
  and ranking tool after resolving strict global IDs.

## phase_3: answer
tools: [memory]
guidance: |
  Wrap only the complete answer text in <answer> tags. Include actual
  data/numbers and concise chemical explanations supported by the completed
  work. Do not emit JSON, core claims, source objects, or other schema fields.
  Parallel tool-free post-answer agents create the core claims and ID/metadata
  fields after termination.

## Tool Calling

Format — one or more tool calls per turn:

<reasoning>
... internal reasoning (discarded each turn) ...
</reasoning>
<summary>
... 2-5 sentence conclusion (kept in memory, ≤600 chars) ...
</summary>
<tool_call>{"name": "tool_a", "arguments": {"p1": "v1"}}</tool_call>
<tool_call>{"name": "tool_b", "arguments": {"p2": 123}}</tool_call>
<wait/>

Final answer (no more tool calls):

<answer>
... complete answer — any length, markers stripped ...
</answer>

Rules:
- Batch independent tool calls in one turn — add multiple <tool_call>…</tool_call> blocks before <wait/>. All execute before the next turn.
- <tool_call> MUST come AFTER </summary> and BEFORE <wait/>. Arguments must be valid JSON.
- <answer> must NEVER mention internal mechanics (working memory, queries, memory keys, agent systems).
- If a tool returns an error, try a different approach or adjust parameters.

Available tools:
- L1_query(purpose, instruction, id_catalog='', context='') — Callable wrapper that auto-persists L1 query results in working memory.
- memory_add_result(key, body) — Add a named result entry to the Results section.
- memory_append_history(line) — Append a one-line entry to the History section.
- memory_catalog_add(type_, global_id, registry_id, name) — Add a row to the protected ID Catalog.
- memory_catalog_list() — List all entries in the ID Catalog as JSON.
- memory_catalog_remove(type_, global_id) — Remove a row from the ID Catalog.
- memory_compact(section, summary_text=None) — Compact a section by replacing it with a summary.
- memory_read(section=None) — Read the full working memory or a specific section.
- memory_reset() — Reset the working memory to an empty template.

# Working-agent final-answer contract

When the chemistry exploration is complete, emit exactly one
`<answer>...</answer>` block containing the full user-facing answer text.
The answer should include concise chemical insight, explanations, and useful
examples when supported by the completed work.

Do not emit JSON, core_claims arrays, source objects, identifier catalogs, schema
fields, or any other separate machine-facing structure in the final answer.
Identifiers or citations may appear naturally inside the answer text when
they are needed to explain a supported result, but they must not be emitted
as an additional structure. Two parallel, tool-free post-answer agents will
distill core_claims and organize ID/metadata fields after this agent terminates.
Earlier instructions that ask you to assemble final JSON are superseded by
this contract.

# Final-answer precedence

The working-agent final-answer contract above has precedence over all earlier phase guidance. Final output is answer text only; the parallel post-answer agents create every JSON field after termination.

## Working Memory
<memory>
# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_6 | propan-2-ol | propan-2-ol |
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Resolve compound IDs for propan-2-ol and water → stored as L1_query_1
- [L1] Find density data for propan-2-ol + water binary mixture at 298.15 K near equimolar composition → stored as L1_query_2

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "The two compounds have been resolved to their canonical global IDs in the ThermoML database:\n\n1. **Propan-2-ol** (isopropanol, CAS 67-63-0): **GLOBcomp_6** — molecular formula C₃H₈O, SMILES CC(C)O\n2. **Water** (CAS 7732-18-5): **GLOBcomp_1** — molecular formula H₂O, SMILES O\n\nBoth were matched with 100% confidence via exact name matching.",
  "core_claims": [
    "In the ThermoML database, propan-2-ol (isopropanol, CAS 67-63-0, molecular formula C₃H₈O, SMILES CC(C)O) is identified as GLOBcomp_6, and water (CAS 7732-18-5, molecular formula H₂O, SMILES O) is identified as GLOBcomp_1, both matched with 100% confidence via exact name matching."
  ],
  "status": "success",
  "summary": "Propan-2-ol (isopropanol, CAS 67-63-0) is identified as GLOBcomp_6 (C₃H₈O, SMILES CC(C)O) and water (CAS 7732-18-5) is identified as GLOBcomp_1 (H₂O, SMILES O) in the ThermoML database. Both assignments were made with 100% confidence via exact name matching.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_6",
      "registry_id": "propan-2-ol",
      "name": "propan-2-ol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "A search of the ThermoML database found one data block containing mass density measurements for the binary mixture of propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) at 298.15 K near equimolar composition:\n\n**Literature source:** DOI 10.1021/je700700f (GLOBlit_11042)  \n**Block:** PROPblock_17  \n**System:** Binary (propan-2-ol + water)  \n**Temperature:** 298.15 K (fixed constraint)  \n**Total data points in block:** 13 (covering the full composition range)  \n**Points near equimolar (x_propan-2-ol ∈ 0.4–0.6):** 2 data points  \n**Mean density at near-equimolar compositions:** ~831.15 kg/m³\n\n**Block-level ID mappings:**\n- BLKvar_1 → GLOBvar_2 (mole fraction of propan-2-ol) — independent variable\n- BLKprop_1 → GLOBprop_1 (mass density, kg/m³) — measured property\n- BLKconstr_2 → GLOBconstr_2 (temperature, K, fixed at 298.15) — constraint\n\n**Chemistry insight:** The density of ~831 kg/m³ at near-equimolar composition is intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³) at 298.15 K. The propan-2-ol + water system is well known for exhibiting significant excess volume (negative), meaning the mixture is denser than ideal mixing would predict, due to restructuring of hydrogen-bond networks when the alcohol disrupts water's tetrahedral structure.",
  "core_claims": [
    "In the ThermoML database (DOI 10.1021/je700700f), the binary mixture of propan-2-ol and water at 298.15 K has a mass density of approximately 831 kg/m³ at near-equimolar compositions (mole fraction of propan-2-ol between 0.4 and 0.6), based on 2 data points from a 13-point composition series.",
    "The measured near-equimolar density of ~831 kg/m³ is intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³) at 298.15 K, and the propan-2-ol + water system is known to exhibit significant negative excess volume due to hydrogen-bond network restructuring."
  ],
  "status": "success",
  "summary": "A ThermoML data block (PROPblock_17) from DOI 10.1021/je700700f (GLOBlit_11042) reports mass density measurements for the binary mixture of propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) at 298.15 K across 13 compositions. The block-level variable BLKvar_1 maps to GLOBvar_2 (mole fraction of propan-2-ol, independent variable), BLKprop_1 maps to GLOBprop_1 (mass density in kg/m³, measured property), and BLKconstr_2 maps to GLOBconstr_2 (temperature fixed at 298.15 K). Two data points fall near equimolar composition (x_propan-2-ol ∈ 0.4–0.6), yielding a mean density of approximately 831.15 kg/m³, intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³). The system is noted for significant negative excess volume arising from hydrogen-bond network restructuring.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_11042",
      "block_number": "PROPblock_17",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_6",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m³) measurements for propan-2-ol + water binary mixture at 298.15 K. DOI 10.1021/je700700f. Block contains 13 data points across the full composition range; 2 points fall within mole fraction of propan-2-ol 0.4–0.6, with a mean density of ~831.15 kg/m³. Block-level mappings: BLKvar_1→GLOBvar_2 (mole fraction of propan-2-ol), BLKprop_1→GLOBprop_1 (mass density), BLKconstr_2→GLOBconstr_2 (temperature fixed at 298.15 K).",
      "doi": "10.1021/je700700f",
      "lit_id": "2008-gon-cal-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 13,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_134",
          "meas_ID": "vibtub_ufactor_4",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 780.7,
            "max": 997.2,
            "mean": 861.961538,
            "std": 75.59908,
            "n": 13
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 780.7,
          "range_max": 997.2
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 13,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


</memory>

## User
What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

## Assistant
<summary>Searching for density (GLOBprop_1) data for propan-2-ol + water binary mixture at 298.15 K, atmospheric pressure, at equimolar composition (x = 0.5).</summary>
<tool_call>L1_query(instruction=Search for mass d…, id_catalog=, context=Property: mass de…)</tool_call>

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: The second core block (GLOBlit_2694, PROPblock_1) is completely wrong. The block metadata shows it is a unary system for methyl methanoate (GLOBcomp_345), measuring refractive index (GLOBprop_7) \u2014 it has nothing to do with propan-2-ol + water density. The DOI listed in the block (10.1016/j.jct.2006.05.004) also differs from the DOI claimed in the answer (10.1016/j.fluid.2005.12.009). This block must be removed from core_blocks_found, and the corresponding claims about bracketing compositions (x=0.4536, x=0.5464) and interpolated density (~848 kg/m\u00b3) from that source must be removed from the answer and core_claims, since they are not supported by any retrieved block. Additionally, for PROPblock_10 (GLOBlit_5585), the block's composition variable is mass fraction (range 0.1\u20130.3), not mole fraction, and the density range is 945\u2013983 kg/m\u00b3 \u2014 the claim of 849.58 kg/m\u00b3 at x=0.5 is not supported by this block's data range. The answer needs to be corrected to reflect only what the actual retrieved block data supports. For PROPblock_4 (GLOBlit_2432), the composition variable is molality (not mole fraction), so the claim of x(propan-2-ol)=0.5 is unsupported. These inconsistencies between the answer text and the authoritative block metadata must be resolved.",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>First L1 query failed due to ID refinement issues. Retrying with a more precise instruction focusing on binary mixture density of propan-2-ol + water at 298.15 K and mole fraction 0.5.</summary>
<tool_call>L1_query(instruction=Search for mass d…, id_catalog=, context=User wants the de…)</tool_call>

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[2] checksum mismatch for (GLOBlit_459, PROPblock_1): comp_num_ids expected ['GLOBcomp_17', 'GLOBcomp_16'], received ['GLOBcomp_24', 'GLOBcomp_33']; prop_num_ids expected ['GLOBprop_89'], received ['GLOBprop_2']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Two L1 queries failed. Retrying with simplified instruction asking L1 to find density blocks for propan-2-ol + water binary mixture, focusing on identifying the correct compound and literature IDs first.</summary>
<tool_call>L1_query(instruction=Step 1: Resolve c…, id_catalog=, context=The user asks for…)</tool_call>

## User
<tool_result>
{
  "error": "query-L1 core-ID refinement exhausted 2 cycles: construct_core_blocks_found: core_blocks_found[1] checksum mismatch for (GLOBlit_1113, PROPblock_1): comp_num_ids expected ['GLOBcomp_275', 'GLOBcomp_1'], received ['GLOBcomp_6', 'GLOBcomp_1']; prop_num_ids expected ['GLOBprop_2'], received ['GLOBprop_1']",
  "error_code": "TOOL_EXECUTION_ERROR",
  "tool": "L1_query"
}

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## Assistant
<summary>Three L1 queries failed due to block checksum mismatches. Trying a minimal query asking L1 to only resolve compound IDs for propan-2-ol and water first, without searching for data blocks.</summary>
<tool_call>L1_query(instruction=Resolve the stric…, id_catalog=, context=)</tool_call>

## User
<tool_result>
<subagent_answer>
{
  "answer": "The two compounds have been resolved to their canonical global IDs in the ThermoML database:\n\n1. **Propan-2-ol** (isopropanol, CAS 67-63-0): **GLOBcomp_6** — molecular formula C₃H₈O, SMILES CC(C)O\n2. **Water** (CAS 7732-18-5): **GLOBcomp_1** — molecular formula H₂O, SMILES O\n\nBoth were matched with 100% confidence via exact name matching.",
  "core_claims": [
    "In the ThermoML database, propan-2-ol (isopropanol, CAS 67-63-0, molecular formula C₃H₈O, SMILES CC(C)O) is identified as GLOBcomp_6, and water (CAS 7732-18-5, molecular formula H₂O, SMILES O) is identified as GLOBcomp_1, both matched with 100% confidence via exact name matching."
  ],
  "status": "success",
  "summary": "Propan-2-ol (isopropanol, CAS 67-63-0) is identified as GLOBcomp_6 (C₃H₈O, SMILES CC(C)O) and water (CAS 7732-18-5) is identified as GLOBcomp_1 (H₂O, SMILES O) in the ThermoML database. Both assignments were made with 100% confidence via exact name matching.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_6",
      "registry_id": "propan-2-ol",
      "name": "propan-2-ol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": []
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[TIME WARNING 1/3] 65% of time budget used (683s / 1000s). Wrap up soon — provide your best answer with available data.

## Assistant
<summary>Confirmed compound IDs. Trying one final focused L1 query to find density (GLOBprop_1) data for the binary system GLOBcomp_6 + GLOBcomp_1 at 298.15 K using the screening tool.</summary>
<tool_call>L1_query(instruction=Use the property …, id_catalog=comp | GLOBcomp_6…, context=User wan…)</tool_call>

## User
<tool_result>
<subagent_answer>
{
  "answer": "A search of the ThermoML database found one data block containing mass density measurements for the binary mixture of propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) at 298.15 K near equimolar composition:\n\n**Literature source:** DOI 10.1021/je700700f (GLOBlit_11042)  \n**Block:** PROPblock_17  \n**System:** Binary (propan-2-ol + water)  \n**Temperature:** 298.15 K (fixed constraint)  \n**Total data points in block:** 13 (covering the full composition range)  \n**Points near equimolar (x_propan-2-ol ∈ 0.4–0.6):** 2 data points  \n**Mean density at near-equimolar compositions:** ~831.15 kg/m³\n\n**Block-level ID mappings:**\n- BLKvar_1 → GLOBvar_2 (mole fraction of propan-2-ol) — independent variable\n- BLKprop_1 → GLOBprop_1 (mass density, kg/m³) — measured property\n- BLKconstr_2 → GLOBconstr_2 (temperature, K, fixed at 298.15) — constraint\n\n**Chemistry insight:** The density of ~831 kg/m³ at near-equimolar composition is intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³) at 298.15 K. The propan-2-ol + water system is well known for exhibiting significant excess volume (negative), meaning the mixture is denser than ideal mixing would predict, due to restructuring of hydrogen-bond networks when the alcohol disrupts water's tetrahedral structure.",
  "core_claims": [
    "In the ThermoML database (DOI 10.1021/je700700f), the binary mixture of propan-2-ol and water at 298.15 K has a mass density of approximately 831 kg/m³ at near-equimolar compositions (mole fraction of propan-2-ol between 0.4 and 0.6), based on 2 data points from a 13-point composition series.",
    "The measured near-equimolar density of ~831 kg/m³ is intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³) at 298.15 K, and the propan-2-ol + water system is known to exhibit significant negative excess volume due to hydrogen-bond network restructuring."
  ],
  "status": "success",
  "summary": "A ThermoML data block (PROPblock_17) from DOI 10.1021/je700700f (GLOBlit_11042) reports mass density measurements for the binary mixture of propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) at 298.15 K across 13 compositions. The block-level variable BLKvar_1 maps to GLOBvar_2 (mole fraction of propan-2-ol, independent variable), BLKprop_1 maps to GLOBprop_1 (mass density in kg/m³, measured property), and BLKconstr_2 maps to GLOBconstr_2 (temperature fixed at 298.15 K). Two data points fall near equimolar composition (x_propan-2-ol ∈ 0.4–0.6), yielding a mean density of approximately 831.15 kg/m³, intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³). The system is noted for significant negative excess volume arising from hydrogen-bond network restructuring.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_11042",
      "block_number": "PROPblock_17",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_6",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m³) measurements for propan-2-ol + water binary mixture at 298.15 K. DOI 10.1021/je700700f. Block contains 13 data points across the full composition range; 2 points fall within mole fraction of propan-2-ol 0.4–0.6, with a mean density of ~831.15 kg/m³. Block-level mappings: BLKvar_1→GLOBvar_2 (mole fraction of propan-2-ol), BLKprop_1→GLOBprop_1 (mass density), BLKconstr_2→GLOBconstr_2 (temperature fixed at 298.15 K).",
      "doi": "10.1021/je700700f",
      "lit_id": "2008-gon-cal-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 13,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_134",
          "meas_ID": "vibtub_ufactor_4",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 780.7,
            "max": 997.2,
            "mean": 861.961538,
            "std": 75.59908,
            "n": 13
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 780.7,
          "range_max": 997.2
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 13,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}
</subagent_answer>

[WAIT BARRIER COMPLETE] 1 tool(s) finished (L1_query). 0 deferred call(s) were discarded. Use the results above to plan your next tool calls with correct IDs/DOIs — do NOT guess.
</tool_result>

## User
[TIME WARNING 2/3] 85% of time budget used (857s / 1000s). Wrap up soon — provide your best answer with available data.

## LLM Response
<answer>
The ThermoML database contains mass density measurements for the binary liquid mixture of propan-2-ol (isopropanol, C₃H₈O) + water (H₂O) at 25 °C (298.15 K) and atmospheric pressure (101 kPa).

**Source:** DOI 10.1021/je700700f (GLOBlit_11042), data block PROPblock_17

This block reports 13 data points spanning the full composition range (mole fraction of propan-2-ol from 0 to 1), with measured densities ranging from **780.7 kg/m³** (pure propan-2-ol) to **997.2 kg/m³** (pure water). Two data points fall near equimolar composition (mole fraction of propan-2-ol between 0.4 and 0.6), yielding a mean density of approximately **831 kg/m³** at near-equimolar conditions.

**Key details:**
- **Property:** Mass density (kg/m³)
- **Temperature:** 298.15 K (fixed constraint)
- **Pressure:** 101 kPa (atmospheric)
- **Phase:** Liquid
- **Composition variable:** Mole fraction of propan-2-ol
- **Measurement method:** Vibrating tube densimeter (uncertainty evaluated at 95% confidence level via propagation of standard uncertainties)

**Chemistry insight:** The near-equimolar density of ~831 kg/m³ lies between the pure-component values of ~781 kg/m³ (propan-2-ol) and ~997 kg/m³ (water) at 298.15 K. The propan-2-ol + water system is well known for exhibiting significant negative excess volume — the mixture is denser than ideal (volume-additive) mixing would predict. This arises because propan-2-ol molecules partially disrupt water's tetrahedral hydrogen-bond network, allowing more efficient molecular packing in the mixed state.
</answer>
# Reference Stats — query-agent

**Run started:** 2026-08-02 18:38:53
**Wall time (at last flush):** 896.1 s

---

## 1. Argo API Call Summary

| Tier | Calls | System (chars) | Prompt (chars) | Response (chars) | Total sent | Avg Context | Total time (s) | Model(s) |
|------|------:|---------------:|---------------:|-----------------:|-----------:|------------:|---------------:|----------|
| L0-main | 9 | 60,607 | 69,684 | 14,049 | 130,291 | 14,476 | 89.5 | claudeopus46 |
| L1-worker | 79 | 818,251 | 402,671 | 137,369 | 1,220,922 | 15,454 | 830.3 | claudeopus46 |
| **TOTAL** | **88** | **878,858** | **472,355** | **151,418** | **1,351,213** | **15,354** | **919.8** | |

**Estimated tokens:** ~337,803 input + ~37,854 output = ~375,657 total
*(rough estimate: 1 token ≈ 4 chars)*

---

## 2. Data Complexity Summary

### 2a. Raw Tool-Return Counters

*Direct counts from raw tool results, before agent condensation.*

| Tool | Compounds | Properties | Variables | Constraints | DOIs | Blocks | Datapoints |
|------|----------:|-----------:|----------:|------------:|-----:|-------:|-----------:|
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| `block_search_adv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 5 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 2 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 2 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `L1_query` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_compound_ids` | 2 | 0 | 0 | 0 | 0 | 0 | 0 |
| `resolve_property_ids` | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 3 | 0 | 0 | 0 | 0 |
| `resolve_ids` | 0 | 0 | 0 | 2 | 0 | 0 | 0 |
| `block_search_adv` | 2 | 0 | 0 | 0 | 1 | 0 | 0 |
| **TOTAL** | **12** | **1** | **8** | **5** | **6** | **0** | **0** |

### 2b. Agent-Condensed Data Complexity

*Deduplicated entities and DOI references after agent processing.*

#### Compounds (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBcomp_6 |  | block_search_adv, resolve_compound_ids |
| GLOBcomp_1 |  | block_search_adv, resolve_compound_ids |

#### Variables (3 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBvar_1 |  | resolve_ids |
| GLOBvar_2 |  | resolve_ids |
| GLOBvar_3 |  | resolve_ids |

#### Constraints (2 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBconstr_1 |  | resolve_ids |
| GLOBconstr_2 |  | resolve_ids |

#### References (6 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBlit_2432 |  | block_search_adv |
| GLOBlit_5585 |  | block_search_adv |
| GLOBlit_6822 |  | block_search_adv |
| GLOBlit_7474 |  | block_search_adv |
| GLOBlit_11872 |  | block_search_adv |
| GLOBlit_11042 |  | block_search_adv |

#### Block_Types (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBblocktype_1 |  | block_search_adv |

#### Phases (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBphase_1 |  | block_search_adv |

#### Properties (1 unique)

| ID | Name | Source tools |
|---:|------|-------------|
| GLOBprop_1 |  | resolve_property_ids |

#### Aggregate Counts (Condensed)

| Metric | Count |
|--------|------:|
| Unique Compounds | 2 |
| Unique Variables | 3 |
| Unique Constraints | 2 |
| Unique References | 6 |
| Unique Block_Types | 1 |
| Unique Phases | 1 |
| Unique Properties | 1 |
| Total DOIs | 0 |
| Unique parent blocks | 0 |
| Explicit block/subsystem targets | 0 |
| Subsystem targets | 0 |
| Target-matched data points | 0 |

---

## 3. DOI & Block References

*(no DOI/block references recorded)*

---

## 4. Tool Results (pre-compaction)

| # | Iter | Tool | Args | Raw (chars) | Subagent | Out (chars) | Time (s) |
|--:|-----:|------|------|------------:|----------|------------:|---------:|
| 1 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 223 | KEEP | 223 | 3.8 |
| 2 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 337 | KEEP | 337 | 4.2 |
| 3 | 3 | `resolve_ids` | entity_type=constraint, limit=5, min_score=70, pur… | 236 | KEEP | 236 | 4.0 |
| 4 | 8 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_6 AS ipa',…, explanat… | 888 | DISCARD | 827 | 17.3 |
| 5 | 10 | `block_search_adv` | compounds=['REQUIRE GLOBcomp_6 AS ipa',…, explanat… | 721 | KEEP | 691 | 19.8 |
| 6 | 1 | `L1_query` | context=Property: mass density (GLOBp…, id_catalog… | 1,428 | — | — | 307.9 |
| 7 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 261 | KEEP | 261 | 6.6 |
| 8 | 2 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 335 | KEEP | 335 | 4.9 |
| 9 | 3 | `resolve_ids` | entity_type=variable, limit=5, min_score=70, purpo… | 359 | KEEP | 359 | 5.4 |
| 10 | 3 | `resolve_ids` | entity_type=constraint, limit=5, min_score=70, pur… | 320 | KEEP | 320 | 4.0 |
| 11 | 2 | `L1_query` | context=User wants the density of an …, id_catalog… | 384 | — | — | 220.1 |
| 12 | 2 | `resolve_compound_ids` | limit=5, min_score=70, purpose=Resolve compound ID… | 195 | KEEP | 195 | 4.3 |
| 13 | 3 | `L1_query` | context=The user asks for the density…, id_catalog… | 382 | — | — | 91.9 |
| 14 | 2 | `resolve_compound_ids` | limit=5, min_score=50, purpose=Resolve global comp… | 271 | KEEP | 271 | 4.4 |
| 15 | 4 | `L1_query` | context=, id_catalog=, instruction=Resolve the str… | 1,323 | — | — | 27.1 |
| 16 | 2 | `resolve_property_ids` | limit=10, min_score=50, purpose=Resolve mass densi… | 298 | KEEP | 298 | 4.2 |
| 17 | 2 | `resolve_ids` | entity_type=variable, limit=10, min_score=50, purp… | 298 | KEEP | 298 | 3.8 |
| 18 | 2 | `resolve_ids` | entity_type=constraint, limit=10, min_score=50, pu… | 314 | KEEP | 314 | 4.2 |
| 19 | 6 | `block_search_adv` | compound_match=all, compounds=['REQUIRE GLOBcomp_6… | 1,085 | KEEP | 1069 | 13.8 |
| 20 | 5 | `L1_query` | context=User wants density of equimol…, id_catalog… | 8,721 | — | — | 162.8 |
| | | **TOTAL (20 tools)** | | **18,379** | | **6,034** | **914.5** |

---

## 5. Compaction Events

| # | Trigger | Outcome | Before (chars) | After (chars) | Saved (chars) | Saved (%) |
|--:|---------|---------|---------------:|--------------:|--------------:|----------:|
| 1 | interval=3 | skipped_by_agent | 3,475 | 3,475 | 0 | 0.0% |
| 2 | interval=3 | skipped_by_agent | 4,835 | 4,835 | 0 | 0.0% |
| 3 | interval=3 | skipped_by_agent | 6,267 | 6,267 | 0 | 0.0% |

---

## 6. Argo Call Detail Log

| # | Tier | Model | System | Prompt | Context | Response | Time (s) |
|--:|------|-------|-------:|-------:|--------:|---------:|---------:|
| 1 | L0-main | claudeopus46 | 9,605 | 580 | 10,185 | 1,353 | 8.6 |
| 2 | L1-worker | claudeopus46 | 20,643 | 1,214 | 21,857 | 747 | 6.0 |
| 3 | L1-worker | claudeopus46 | 20,643 | 2,582 | 23,225 | 10,440 | 50.1 |
| 4 | L1-worker | claudeopus46 | 2,065 | 476 | 2,541 | 389 | 3.6 |
| 5 | L1-worker | claudeopus46 | 20,643 | 2,742 | 23,385 | 9,815 | 52.4 |
| 6 | L1-worker | claudeopus46 | 2,065 | 497 | 2,562 | 532 | 4.1 |
| 7 | L1-worker | claudeopus46 | 2,065 | 382 | 2,447 | 411 | 4.0 |
| 8 | L1-worker | claudeopus46 | 20,610 | 4,770 | 25,380 | 416 | 3.7 |
| 9 | L1-worker | claudeopus46 | 20,643 | 4,017 | 24,660 | 4,317 | 28.5 |
| 10 | L1-worker | claudeopus46 | 20,643 | 5,027 | 25,670 | 1,509 | 11.0 |
| 11 | L1-worker | claudeopus46 | 20,643 | 5,889 | 26,532 | 1,480 | 10.2 |
| 12 | L1-worker | claudeopus46 | 20,643 | 7,944 | 28,587 | 1,054 | 5.2 |
| 13 | L1-worker | claudeopus46 | 20,643 | 8,740 | 29,383 | 1,381 | 7.1 |
| 14 | L1-worker | claudeopus46 | 2,065 | 1,255 | 3,320 | 1,474 | 8.7 |
| 15 | L1-worker | claudeopus46 | 20,643 | 8,275 | 28,918 | 1,224 | 7.0 |
| 16 | L1-worker | claudeopus46 | 20,643 | 10,074 | 30,717 | 783 | 6.0 |
| 17 | L1-worker | claudeopus46 | 2,065 | 4,124 | 6,189 | 1,864 | 13.3 |
| 18 | L1-worker | claudeopus46 | 20,643 | 10,944 | 31,587 | 4,729 | 27.3 |
| 19 | L1-worker | claudeopus46 | 20,643 | 16,248 | 36,891 | 1,900 | 7.3 |
| 20 | L1-worker | claudeopus46 | 1,356 | 2,031 | 3,387 | 756 | 4.5 |
| 21 | L1-worker | claudeopus46 | 536 | 1,911 | 2,447 | 916 | 5.7 |
| 22 | L1-worker | claudeopus46 | 1,323 | 13,953 | 15,276 | 1,460 | 8.6 |
| 23 | L1-worker | claudeopus46 | 298 | 2,182 | 2,480 | 1,135 | 8.4 |
| 24 | L1-worker | claudeopus46 | 1,160 | 15,894 | 17,054 | 1,072 | 6.7 |
| 25 | L1-worker | claudeopus46 | 747 | 33,083 | 33,830 | 1,299 | 11.7 |
| 26 | L0-main | claudeopus46 | 9,605 | 2,515 | 12,120 | 1,439 | 9.6 |
| 27 | L1-worker | claudeopus46 | 20,643 | 1,421 | 22,064 | 1,132 | 8.1 |
| 28 | L1-worker | claudeopus46 | 20,643 | 3,281 | 23,924 | 12,502 | 65.6 |
| 29 | L1-worker | claudeopus46 | 2,065 | 475 | 2,540 | 466 | 6.5 |
| 30 | L1-worker | claudeopus46 | 2,065 | 394 | 2,459 | 584 | 4.7 |
| 31 | L1-worker | claudeopus46 | 20,643 | 3,905 | 24,548 | 8,097 | 46.3 |
| 32 | L1-worker | claudeopus46 | 2,065 | 460 | 2,525 | 508 | 5.2 |
| 33 | L1-worker | claudeopus46 | 2,065 | 497 | 2,562 | 478 | 3.9 |
| 34 | L1-worker | claudeopus46 | 20,610 | 6,130 | 26,740 | 408 | 3.3 |
| 35 | L1-worker | claudeopus46 | 20,643 | 5,377 | 26,020 | 8,054 | 41.9 |
| 36 | L1-worker | claudeopus46 | 20,643 | 14,006 | 34,649 | 1,893 | 7.1 |
| 37 | L1-worker | claudeopus46 | 1,356 | 2,024 | 3,380 | 654 | 4.2 |
| 38 | L1-worker | claudeopus46 | 536 | 1,904 | 2,440 | 839 | 5.4 |
| 39 | L1-worker | claudeopus46 | 1,323 | 6,839 | 8,162 | 2,216 | 10.5 |
| 40 | L1-worker | claudeopus46 | 298 | 2,938 | 3,236 | 1,638 | 7.4 |
| 41 | L1-worker | claudeopus46 | 1,160 | 9,557 | 10,717 | 1,648 | 7.9 |
| 42 | L0-main | claudeopus46 | 9,605 | 3,441 | 13,046 | 1,498 | 10.5 |
| 43 | L1-worker | claudeopus46 | 20,643 | 1,344 | 21,987 | 519 | 4.3 |
| 44 | L1-worker | claudeopus46 | 20,643 | 2,484 | 23,127 | 854 | 5.3 |
| 45 | L1-worker | claudeopus46 | 2,065 | 439 | 2,504 | 361 | 4.2 |
| 46 | L1-worker | claudeopus46 | 20,643 | 2,599 | 23,242 | 5,228 | 35.8 |
| 47 | L1-worker | claudeopus46 | 20,643 | 8,448 | 29,091 | 1,888 | 10.4 |
| 48 | L1-worker | claudeopus46 | 536 | 1,529 | 2,065 | 549 | 3.7 |
| 49 | L1-worker | claudeopus46 | 1,356 | 1,649 | 3,005 | 606 | 3.9 |
| 50 | L1-worker | claudeopus46 | 298 | 905 | 1,203 | 536 | 2.8 |
| 51 | L1-worker | claudeopus46 | 1,323 | 3,959 | 5,282 | 2,726 | 11.3 |
| 52 | L1-worker | claudeopus46 | 298 | 3,448 | 3,746 | 2,049 | 8.9 |
| 53 | L1-worker | claudeopus46 | 1,160 | 7,281 | 8,441 | 2,191 | 10.8 |
| 54 | L0-main | claudeopus46 | 9,605 | 4,384 | 13,989 | 945 | 6.8 |
| 55 | L1-worker | claudeopus46 | 20,643 | 779 | 21,422 | 599 | 4.6 |
| 56 | L1-worker | claudeopus46 | 20,643 | 1,999 | 22,642 | 924 | 5.4 |
| 57 | L1-worker | claudeopus46 | 2,065 | 506 | 2,571 | 485 | 4.2 |
| 58 | L1-worker | claudeopus46 | 20,643 | 2,198 | 22,841 | 359 | 3.8 |
| 59 | L1-worker | claudeopus46 | 1,323 | 2,151 | 3,474 | 233 | 2.4 |
| 60 | L1-worker | claudeopus46 | 1,356 | 490 | 1,846 | 300 | 2.9 |
| 61 | L1-worker | claudeopus46 | 536 | 370 | 906 | 272 | 3.2 |
| 62 | L1-worker | claudeopus46 | 298 | 955 | 1,253 | 153 | 2.1 |
| 63 | L1-worker | claudeopus46 | 747 | 2,605 | 3,352 | 405 | 4.1 |
| 64 | L0-main | claudeopus46 | 9,605 | 7,831 | 17,436 | 1,601 | 10.9 |
| 65 | L1-worker | claudeopus46 | 20,643 | 2,950 | 23,593 | 1,502 | 7.6 |
| 66 | L1-worker | claudeopus46 | 20,643 | 4,413 | 25,056 | 1,239 | 6.2 |
| 67 | L1-worker | claudeopus46 | 2,065 | 370 | 2,435 | 538 | 4.1 |
| 68 | L1-worker | claudeopus46 | 2,065 | 593 | 2,658 | 500 | 3.6 |
| 69 | L1-worker | claudeopus46 | 2,065 | 489 | 2,554 | 507 | 4.2 |
| 70 | L1-worker | claudeopus46 | 20,643 | 5,314 | 25,957 | 2,886 | 16.8 |
| 71 | L1-worker | claudeopus46 | 20,643 | 6,328 | 26,971 | 1,692 | 10.9 |
| 72 | L1-worker | claudeopus46 | 20,643 | 7,280 | 27,923 | 1,242 | 8.2 |
| 73 | L1-worker | claudeopus46 | 20,643 | 8,115 | 28,758 | 1,695 | 18.7 |
| 74 | L1-worker | claudeopus46 | 2,065 | 1,996 | 4,061 | 1,826 | 11.5 |
| 75 | L1-worker | claudeopus46 | 20,610 | 9,105 | 29,715 | 454 | 5.0 |
| 76 | L1-worker | claudeopus46 | 20,643 | 8,352 | 28,995 | 1,324 | 9.1 |
| 77 | L1-worker | claudeopus46 | 20,643 | 9,304 | 29,947 | 1,443 | 10.0 |
| 78 | L1-worker | claudeopus46 | 20,643 | 10,142 | 30,785 | 1,507 | 11.2 |
| 79 | L1-worker | claudeopus46 | 20,643 | 10,965 | 31,608 | 1,853 | 12.6 |
| 80 | L1-worker | claudeopus46 | 1,356 | 1,430 | 2,786 | 594 | 4.2 |
| 81 | L1-worker | claudeopus46 | 536 | 1,310 | 1,846 | 803 | 4.7 |
| 82 | L1-worker | claudeopus46 | 1,323 | 17,971 | 19,294 | 802 | 6.4 |
| 83 | L1-worker | claudeopus46 | 298 | 1,524 | 1,822 | 675 | 3.7 |
| 84 | L1-worker | claudeopus46 | 747 | 25,120 | 25,867 | 830 | 8.4 |
| 85 | L0-main | claudeopus46 | 9,605 | 26,049 | 35,654 | 1,554 | 11.6 |
| 86 | L0-main | claudeopus46 | 1,356 | 1,685 | 3,041 | 774 | 4.4 |
| 87 | L0-main | claudeopus46 | 1,323 | 19,862 | 21,185 | 2,669 | 17.2 |
| 88 | L0-main | claudeopus46 | 298 | 3,337 | 3,635 | 2,216 | 9.9 |


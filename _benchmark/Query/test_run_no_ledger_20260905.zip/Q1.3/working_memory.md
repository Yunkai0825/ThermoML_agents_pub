# Working Memory

## ID Catalog
<!-- PROTECTED — never compacted. Auto-populated by catalog ops. -->
### Resolved Entities
| type | global_id | registry_id | name |
|------|--------|----|------|
| comp | GLOBcomp_6 | propan-2-ol | propan-2-ol |
| comp | GLOBcomp_1 | water | water |

### Reference IDs
| type | global_id | registry_id | name |
|------|--------|----|------|

## History
<!-- Append-only log. Compactable when >30 entries. -->
- [L1] Resolve compound IDs for propan-2-ol and water → stored as L1_query_1
- [L1] Find density data for propan-2-ol + water binary mixture at 298.15 K near equimolar composition → stored as L1_query_2

## Results
<!-- Indexed findings. Compactable per-entry. -->
### L1_query_1
{
  "answer": "The two compounds have been resolved to their canonical global IDs in the ThermoML database:\n\n1. **Propan-2-ol** (isopropanol, CAS 67-63-0): **GLOBcomp_6** — molecular formula C₃H₈O, SMILES CC(C)O\n2. **Water** (CAS 7732-18-5): **GLOBcomp_1** — molecular formula H₂O, SMILES O\n\nBoth were matched with 100% confidence via exact name matching.",
  "core_claims": [
    "In the ThermoML database, propan-2-ol (isopropanol, CAS 67-63-0, molecular formula C₃H₈O, SMILES CC(C)O) is identified as GLOBcomp_6, and water (CAS 7732-18-5, molecular formula H₂O, SMILES O) is identified as GLOBcomp_1, both matched with 100% confidence via exact name matching."
  ],
  "status": "success",
  "summary": "Propan-2-ol (isopropanol, CAS 67-63-0) is identified as GLOBcomp_6 (C₃H₈O, SMILES CC(C)O) and water (CAS 7732-18-5) is identified as GLOBcomp_1 (H₂O, SMILES O) in the ThermoML database. Both assignments were made with 100% confidence via exact name matching.",
  "core_id_updates": [
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_6",
      "registry_id": "propan-2-ol",
      "name": "propan-2-ol"
    },
    {
      "action": "add",
      "core_GLOB_id": "GLOBcomp_1",
      "registry_id": "water",
      "name": "water"
    }
  ],
  "core_blocks_found": []
}
### L1_query_2
{
  "answer": "A search of the ThermoML database found one data block containing mass density measurements for the binary mixture of propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) at 298.15 K near equimolar composition:\n\n**Literature source:** DOI 10.1021/je700700f (GLOBlit_11042)  \n**Block:** PROPblock_17  \n**System:** Binary (propan-2-ol + water)  \n**Temperature:** 298.15 K (fixed constraint)  \n**Total data points in block:** 13 (covering the full composition range)  \n**Points near equimolar (x_propan-2-ol ∈ 0.4–0.6):** 2 data points  \n**Mean density at near-equimolar compositions:** ~831.15 kg/m³\n\n**Block-level ID mappings:**\n- BLKvar_1 → GLOBvar_2 (mole fraction of propan-2-ol) — independent variable\n- BLKprop_1 → GLOBprop_1 (mass density, kg/m³) — measured property\n- BLKconstr_2 → GLOBconstr_2 (temperature, K, fixed at 298.15) — constraint\n\n**Chemistry insight:** The density of ~831 kg/m³ at near-equimolar composition is intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³) at 298.15 K. The propan-2-ol + water system is well known for exhibiting significant excess volume (negative), meaning the mixture is denser than ideal mixing would predict, due to restructuring of hydrogen-bond networks when the alcohol disrupts water's tetrahedral structure.",
  "core_claims": [
    "In the ThermoML database (DOI 10.1021/je700700f), the binary mixture of propan-2-ol and water at 298.15 K has a mass density of approximately 831 kg/m³ at near-equimolar compositions (mole fraction of propan-2-ol between 0.4 and 0.6), based on 2 data points from a 13-point composition series.",
    "The measured near-equimolar density of ~831 kg/m³ is intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³) at 298.15 K, and the propan-2-ol + water system is known to exhibit significant negative excess volume due to hydrogen-bond network restructuring."
  ],
  "status": "success",
  "summary": "A ThermoML data block (PROPblock_17) from DOI 10.1021/je700700f (GLOBlit_11042) reports mass density measurements for the binary mixture of propan-2-ol (GLOBcomp_6) + water (GLOBcomp_1) at 298.15 K across 13 compositions. The block-level variable BLKvar_1 maps to GLOBvar_2 (mole fraction of propan-2-ol, independent variable), BLKprop_1 maps to GLOBprop_1 (mass density in kg/m³, measured property), and BLKconstr_2 maps to GLOBconstr_2 (temperature fixed at 298.15 K). Two data points fall near equimolar composition (x_propan-2-ol ∈ 0.4–0.6), yielding a mean density of approximately 831.15 kg/m³, intermediate between pure water (~997 kg/m³) and pure propan-2-ol (~781 kg/m³). The system is noted for significant negative excess volume arising from hydrogen-bond network restructuring.",
  "core_id_updates": [],
  "core_blocks_found": [
    {
      "lit_num_id": "GLOBlit_11042",
      "block_number": "PROPblock_17",
      "BLKsubsys_id": null,
      "system_type": "binary",
      "comp_num_ids": [
        "GLOBcomp_6",
        "GLOBcomp_1"
      ],
      "prop_num_ids": [
        "GLOBprop_1"
      ],
      "description": "Mass density (kg/m³) measurements for propan-2-ol + water binary mixture at 298.15 K. DOI 10.1021/je700700f. Block contains 13 data points across the full composition range; 2 points fall within mole fraction of propan-2-ol 0.4–0.6, with a mean density of ~831.15 kg/m³. Block-level mappings: BLKvar_1→GLOBvar_2 (mole fraction of propan-2-ol), BLKprop_1→GLOBprop_1 (mass density), BLKconstr_2→GLOBconstr_2 (temperature fixed at 298.15 K).",
      "doi": "10.1021/je700700f",
      "lit_id": "2008-gon-cal-0",
      "block_type": "PureOrMixtureData",
      "blocktype_num_id": "GLOBblocktype_1",
      "n_datapoints": 13,
      "n_components": 2,
      "compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "solvents": [],
      "constraints": [
        {
          "BLKconstr_id": "BLKconstr_1",
          "constr_num_id": "GLOBconstr_1",
          "constr_id": "pressure_kpa",
          "name": "Pressure, kPa",
          "type": "ePressure",
          "value": 101.0,
          "digits": 3,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        },
        {
          "BLKconstr_id": "BLKconstr_2",
          "constr_num_id": "GLOBconstr_2",
          "constr_id": "temperature_k",
          "name": "Temperature, K",
          "type": "eTemperature",
          "value": 298.15,
          "digits": 5,
          "component_org_num": null,
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          }
        }
      ],
      "variables": [
        {
          "BLKvar_id": "BLKvar_1",
          "var_num_id": "GLOBvar_2",
          "var_id": "mole_fraction_DOIcomp_2",
          "name": "Mole fraction",
          "type": "eComponentComposition",
          "component_org_num": "DOIcomp_2",
          "phase": {
            "phase": "Liquid",
            "phase_num_id": "GLOBphase_1",
            "phase_id": "liquid"
          },
          "range": {
            "BLKvar_id": "BLKvar_1",
            "name": "Mole fraction",
            "min": 0.0,
            "max": 1.0,
            "n_unique": 13
          },
          "range_min": 0.0,
          "range_max": 1.0
        }
      ],
      "properties": [
        {
          "BLKprop_id": "BLKprop_1",
          "prop_num_id": "GLOBprop_1",
          "prop_ID": "mass_density_kg_m3",
          "name": "Mass density, kg/m3",
          "group": "VolumetricProp",
          "component_org_num": null,
          "meas_num_id": "GLOBmeas_134",
          "meas_ID": "vibtub_ufactor_4",
          "method_standard": null,
          "method_custom": "VIBTUB:UFactor:4",
          "range": {
            "BLKprop_id": "BLKprop_1",
            "name": "Mass density, kg/m3",
            "min": 780.7,
            "max": 997.2,
            "mean": 861.961538,
            "std": 75.59908,
            "n": 13
          },
          "uncertainty": {
            "evaluation_method": "Propagation of evaluated standard uncertainties",
            "confidence_level": 95,
            "evaluator": "Data file compiler",
            "assessment_num": "BLKpropAssessment_1_1"
          },
          "range_min": 780.7,
          "range_max": 997.2
        }
      ],
      "phases": [
        {
          "owner_id": "BLKprop_1",
          "role": "property_phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKvar_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_1",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        },
        {
          "owner_id": "BLKconstr_2",
          "role": "phase",
          "phase": "Liquid",
          "phase_num_id": "GLOBphase_1",
          "phase_id": "liquid"
        }
      ],
      "reaction_type": null,
      "participants": [],
      "notes": null,
      "declared_system_type": "binary",
      "declared_n_components": 2,
      "declared_compounds": [
        {
          "org_num": "DOIcomp_2",
          "comp_num_id": "GLOBcomp_6",
          "name": "propan-2-ol",
          "formula": "C3H8O",
          "inchi_key": "KFZMGEQAYNKOFK-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_2_1"
        },
        {
          "org_num": "DOIcomp_3",
          "comp_num_id": "GLOBcomp_1",
          "name": "water",
          "formula": "H2O",
          "inchi_key": "XLYOFNOQVPJJNP-UHFFFAOYSA-N",
          "SMILES": null,
          "sample_num": "DOIcompSample_3_1"
        }
      ],
      "parent_n_datapoints": 13,
      "subsystem_scope": null,
      "subsystem_point_runs": [],
      "subsystem_path_class": null,
      "subsystem_evidence_quality": null,
      "subsystem_condition_ranges": []
    }
  ]
}


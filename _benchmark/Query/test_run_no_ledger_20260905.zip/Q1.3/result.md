# Q1.3 — Result

**Prompt:** What density has been measured for an equimolar propan-2-ol + water liquid mixture at 25 °C and atmospheric pressure?

**Tool calls:** 5  |  **Time:** 896.1s  |  **Iterations:** 6  |  **Timed out:** False

---

## Answer

The ThermoML database contains mass density measurements for the binary liquid mixture of propan-2-ol (isopropanol, C₃H₈O) + water (H₂O) at 25 °C (298.15 K) and atmospheric pressure (101 kPa).

**Source:** DOI 10.1021/je700700f (GLOBlit_11042), data block PROPblock_17

This block reports 13 data points spanning the full composition range (mole fraction of propan-2-ol from 0 to 1), with measured densities ranging from **780.7 kg/m³** (pure propan-2-ol) to **997.2 kg/m³** (pure water). Two data points fall near equimolar composition (mole fraction of propan-2-ol between 0.4 and 0.6), yielding a mean density of approximately **831 kg/m³** at near-equimolar conditions.

**Key details:**
- **Property:** Mass density (kg/m³)
- **Temperature:** 298.15 K (fixed constraint)
- **Pressure:** 101 kPa (atmospheric)
- **Phase:** Liquid
- **Composition variable:** Mole fraction of propan-2-ol
- **Measurement method:** Vibrating tube densimeter (uncertainty evaluated at 95% confidence level via propagation of standard uncertainties)

**Chemistry insight:** The near-equimolar density of ~831 kg/m³ lies between the pure-component values of ~781 kg/m³ (propan-2-ol) and ~997 kg/m³ (water) at 298.15 K. The propan-2-ol + water system is well known for exhibiting significant negative excess volume — the mixture is denser than ideal (volume-additive) mixing would predict. This arises because propan-2-ol molecules partially disrupt water's tetrahedral hydrogen-bond network, allowing more efficient molecular packing in the mixed state.

### Core claims

- The ThermoML database (DOI 10.1021/je700700f) reports mass density measurements for the binary liquid mixture of propan-2-ol + water at 298.15 K and 101 kPa, spanning the full composition range with densities from approximately 780.7 kg/m³ (pure propan-2-ol) to 997.2 kg/m³ (pure water).
- At near-equimolar composition (mole fraction of propan-2-ol between 0.4 and 0.6), the mean measured density is approximately 831 kg/m³, which lies between the pure-component values.
- The propan-2-ol + water system exhibits significant negative excess volume, meaning the mixture is denser than ideal volume-additive mixing would predict, attributed to more efficient molecular packing when propan-2-ol partially disrupts water's tetrahedral hydrogen-bond network.

**Confidence:** high

### Sources

| lit num id | doi | block | BLKsubsys id | description |
| --- | --- | --- | --- | --- |
| GLOBlit_11042 | 10.1021/je700700f | PROPblock_17 |  | Mass density (kg/m³) measurements for propan-2-ol + water binary liquid mixture at 298.15 K and 101 kPa. Block contains 13 data points spanning the full composition range (mole fraction of propan-2-ol 0 to 1), with density ranging from 780.7 kg/m³ (pure propan-2-ol) to 997.2 kg/m³ (pure water). Two data points near equimolar composition (x ∈ 0.4–0.6) yield a mean density of ~831 kg/m³. Block-level mappings: BLKvar_1→GLOBvar_2 (mole fraction of propan-2-ol), BLKprop_1→GLOBprop_1 (mass density), BLKconstr_1→GLOBconstr_1 (pressure 101 kPa), BLKconstr_2→GLOBconstr_2 (temperature 298.15 K). Measurement method: vibrating tube densimeter (GLOBmeas_134), uncertainty at 95% confidence level. |

### Suggested follow-ups

- Request individual data-point values from PROPblock_17 to obtain the exact mole fractions and densities of the two near-equimolar points, enabling precise interpolation to x = 0.5.
- Search for excess molar volume data (GLOBprop_2 or related) for propan-2-ol + water at 298.15 K to quantify the non-ideal mixing behavior.
- Compare density data from additional literature sources for propan-2-ol + water at 298.15 K to assess inter-laboratory consistency.

---

## ID Catalog Snapshot (structured ledger)

Workflow-assembled identifier catalog; rendered by the browser.

```json
[
  {
    "type": "comp",
    "global_id": "GLOBcomp_6",
    "registry_id": "propan-2-ol",
    "name": "propan-2-ol"
  },
  {
    "type": "comp",
    "global_id": "GLOBcomp_1",
    "registry_id": "water",
    "name": "water"
  },
  {
    "type": "prop",
    "global_id": "GLOBprop_1",
    "registry_id": "mass_density_kg_m3",
    "name": "Mass density, kg/m3"
  },
  {
    "type": "var",
    "global_id": "GLOBvar_2",
    "registry_id": "mole_fraction_DOIcomp_2",
    "name": "Mole fraction"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_1",
    "registry_id": "pressure_kpa",
    "name": "Pressure, kPa"
  },
  {
    "type": "constr",
    "global_id": "GLOBconstr_2",
    "registry_id": "temperature_k",
    "name": "Temperature, K"
  },
  {
    "type": "phase",
    "global_id": "GLOBphase_1",
    "registry_id": "liquid",
    "name": "Liquid"
  },
  {
    "type": "meas",
    "global_id": "GLOBmeas_134",
    "registry_id": "vibtub_ufactor_4",
    "name": "VIBTUB:UFactor:4"
  },
  {
    "type": "blocktype",
    "global_id": "GLOBblocktype_1",
    "registry_id": "PureOrMixtureData",
    "name": "PureOrMixtureData"
  }
]
```
